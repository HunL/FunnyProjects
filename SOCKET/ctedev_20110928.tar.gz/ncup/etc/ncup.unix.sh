# set environment variables for NCUP

# path 
PATH=$APPHOME/ncup/bin:$APPHOME/ncup/sbin:$PATH;export PATH
PATH=$APPHOME/stlm/bin:$PATH;export PATH
export FEHOME=$APPHOME/ncup

HSMHOME=$APPHOME/hsm;export HSMHOME
LIBPATH=$APPHOME/ncup/lib:$LIBPATH;export LIBPATH
LIB_PATH=/lib:/usr/lib:$LIBPATH;export LIB_PATH
LD_LIBPARY_PATH=$LIB_PATH;export LD_LIBPARY_PATH
LD_LIBRARY_PATH=$APPHOME/ncup/lib:$LD_LIBRARY_PATH

THIS_IP_ADDR=10.2.47.43
export THIS_IP_ADDR
OTHER_IP_ADDR=10.2.47.44
export OTHER_IP_ADDR

BINDIR=$APPHOME/ncup/bin
export BINDIR
LIBDIR=$APPHOME/ncup/lib
export LIBDIR
BNDDIR=$APPHOME/bnd
export BNDDIR
SRCDIR=$APPHOME/ncup/src
export SRCDIR
INCDIR=$APPHOME/ncup/include
export INCDIR
LOGDIR=$APPHOME/ncup/log
export LOGDIR
FILDIR=$APPHOME/fil
export FILDIR
TMPDIR=$APPHOME/tmp
export TMPDIR

#GFHEADER
GFHEADER_CFG_PATH=$APPHOME/ncup/etc/gfheader.ini
export GFHEADER_CFG_PATH

export TRSHOME=$FEHOME/
export TRSPARAMFILE=$FEHOME/etc/bfTrans.ini

#ͬ����־ģʽ
export LOG_FILE_PATH=$APPHOME/log
export LOG_MODE=1
export LOG_SIZE=10000
export LOG_SWITCH_MODE=3

export TOPSOAP_CFG_PATH=$FEHOME/etc/soapcfg/
export TL_DBPWD_FILE=$APPHOME/ncup/etc/dbpwd.ini
