# alias
CURDATE=`date '+%Y%m%d'`

alias c='clear'
alias mv='mv -i '
alias rm='rm -i '
alias cp='cp -i '
alias ls='/bin/ls -CF '
alias la='/bin/ls -aldF '
alias lt='/bin/ls -ltr '
alias l='/bin/ls -lF '
alias lf='/bin/ls -F '
alias h='history'


alias cdn='cd $APPHOME/ncup/'
alias cds='cd $APPHOME/ncup/src'
alias cdr='cd $APPHOME/ncup/rpt'
alias cdl='cd $APPHOME/ncup/log/`date +%Y%m%d`'
alias cdb='cd $APPHOME/ncup/bin'
alias cdi='cd $APPHOME/ncup/include'
alias cdsw='cd $APPHOME/personal/sw'
alias cgrep='find . -name "*c" | xargs grep '

alias conndev='db2 connect to cteprod user ctedb using ctedb123'
alias disconn='db2 connect reset'
alias cde='cd $APPHOME/ncup/etc'

alias l="ls -lrt"
alias c="clear"
alias vim="vi"
alias search="$APPHOME/search.sh"
alias cdsw="cd  $APPHOME/personal/sw"
alias cdot="cd $APPHOME/ncup/log/$CURDATE"

SRV_USAGE_KEY=0
export SRV_USAGE_KEY
