#==========================#
# Set DB2 Environment      #
#==========================#
DBNAME=cteprod;export DBNAME
DBUSER=ctedb;export DBUSER
DBPWD=ctedb123;export DBPWD
export DBLINK="$DBNAME user $DBUSER using $DBPWD"

#DB2_HOME=/opt/IBM/db2/V9.5
DB2_HOME=/opt/ibm/db2/V9.5
export DB2_HOME
DB2PATH=/opt/ibm/db2/V9.5
export DB2PATH
DB2INSTPATH=/home/db2inst1
export DB2INSTPATH
DB2INSTANCE=db2inst1
export DB2INSTANCE

DB2DBDFT=cteprod
export DB2DBDFT
SQLCMD=db2
export SQLCMD

#source ${DB2INSTPATH}/sqllib
. $DB2INSTPATH/sqllib/db2profile

# path 
PATH=$PATH:$DB2INSTPATH/sqllib/bin
export PATH
