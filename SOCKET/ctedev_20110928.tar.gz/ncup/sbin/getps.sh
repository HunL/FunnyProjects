db2 "select srv_name from tbl_srv_inf" >ps.tmp
CNT=`wc -l ps.tmp|awk '{print $1}'`
awk -v CNT=$CNT '{if (NR>3 && NR<=CNT-3) print $0}' ps.tmp > ps.ls
rm -f ps.tmp
