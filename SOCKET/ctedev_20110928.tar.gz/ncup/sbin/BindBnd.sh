
cd $APPHOME/ncup/bnd

db2 connect to $DBNAME user $DBUSER using $DBPWD

if [ $# -lt 1 ]
then
    for i in `ls *.bnd`
    do
    echo "====[db2 bind $i]===="
    db2 bind $i action replace blocking all grant public sqlerror continue
    done

else
    echo "====[db2 bind $1]===="
    db2 bind $1 action replace blocking all grant public sqlerror continue

fi

db2 disconnect all
