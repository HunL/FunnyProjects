db2 "select srv_name,msq_key from tbl_msq_inf a, tbl_srv_inf b where a.msq_int_id=b.msq_int_id order by msq_key"|awk 'NR>3 {print $0}' >1.tmp
head -`wc -l 1.tmp|awk '{print $1-3}'` 1.tmp >msq.ls
/bin/rm -f 1.tmp 2.tmp
