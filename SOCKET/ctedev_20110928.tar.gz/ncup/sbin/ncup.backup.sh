#!/usr/bin/ksh

CURDATE=`date '+%Y%m%d'`
CURTIME=`date '+%Y%m%d%H%M%S'`
LOGFILE=SrcBackup.log

PSEQ=`echo $CURDATE|cut -c 3-8`00

PNAME="SrcBackup.sh"
PDISC="Դ�򱸷�"
APPHOME=/home/ctedev/dev
cd $APPHOME
tar cvf cte.ncup.src.$CURTIME.tar .exrc .profile ncup/install ncup/db ncup/Simulator ncup/etc ncup/include ncup/sbin ncup/mak ncup/src >/dev/null 2>&1
mv cte.ncup.src.$CURTIME.tar $HOME/backup >/dev/null 2>&1
cd $HOME/backup
gzip cte.ncup.src.$CURTIME.tar >/dev/null 2>&1
