db2 "select REMOTE_ADDR,OUT_SOCK_NUM,substr(LINE_DSP,1,20) from tbl_line_cfg where usage_key=0"|awk 'NR>3 {print $0}' >3.tmp
head -`wc -l 3.tmp|awk '{print $1-3}'` 3.tmp >net.ls
/bin/rm -f 3.tmp
