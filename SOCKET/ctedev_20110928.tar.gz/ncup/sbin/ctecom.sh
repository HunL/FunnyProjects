#!/bin/sh
cd /home/ctecom/dev/ncup
rm -f ctecom.tar
tar cvf ctecom.tar bin lib bnd
ftp -n 10.2.48.47 <<EOF >/dev/null 2>&1
user ctetst ctetst
cd /home/ctetst/ncup
bin
put ctecom.tar
bye
EOF
