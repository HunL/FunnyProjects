#!/bin/sh
# FileName: topmon.sh
# Function: check topfe 
# Temporary files will be put in $APPHOME/topmon.cs
# Made by ChenLiang on 2005/06/27
# Copyright (c) 2003 Huateng Software Systems Co. Ltd.
# All Rights Reserved

PROGS="Bridge|CommCom|CommCup|CommP|Daemon|Manage|PackSend|SavFwd|Switch|ToCtl"

colour()
{
  case $1 in 
    black_green)
      echo '[40;32m\c'
      ;;
    black_yellow)
      echo '[40;33m\c'
      ;;
    black_white)
      echo '[40;37m\c'
      ;;
    black_cyan)
      echo '[40;36m\c'
      ;;
    black_purple)
      echo '[40;35m\c'
      ;;
    red_yellow)
      echo '[41;33m\c'
      ;;
  esac
}

CheckP()
{
	P=`grep -c $1 < $APPHOME/topmon.cs`
	if [ $P = 0 ]; then
		if [ $TOPERR = 0 ]; then
echo '======== ������ ======== ��ǰ������ ============= Ӧ�ý����� ========'
		fi
		colour red_yellow 
		echo '|     '$2'        |      '$P'      |             '$3'                 |'
		TOPERR=1
	fi
}

CheckQ()
{
	count=`ipcs -oq | egrep "$1" | awk '{print $7}'`
	if test "${count}" = ""
	then
		colour red_yellow
		echo "$1[$2] queue not found !!!"
		QUEERR=1
	else
		if [ $count -gt "1" ]; then
			colour red_yellow
			echo "$2 \c"
			ipcs -oq | grep "$1"
			QUEERR=1
		fi
	fi
}

while [ 1 ]
do

TOPERR=0

ps -u $LOGNAME|egrep $PROGS > $HOME/topmon.cs
clear
echo
colour black_white 
echo '                      ��TOPFEǰ��ϵͳ���̼�ء�                      '
echo '====================================================================='

#CheckP ������ ��Ļ��ʾ(Ϊ����Ļ����) ��������
CheckP Bridge 	Bridge** 2
CheckP Switch 	Switch** 2
CheckP PackSend PackSend 2 
CheckP ToCtl 	ToCtl*** 1
CheckP SavFwd 	SavFwd** 2
CheckP CommCup 	CommCup* 9
CheckP CommP 	CommP*** n
CheckP Manage 	Manage** 1
CheckP Daemon 	Daemon** 1

colour black_white 
if [ $TOPERR = 0 ]; then
echo
echo '                     TOPFE��ǰ��ϵͳ������������                   '
echo
fi
echo '====================================================================='
rm -f $HOME/topmon.cs

echo
QUEERR=0
colour black_white 
echo '                      ��TOPFEǰ��ϵͳ���м�ء�                      '
echo '====================================================================='

#CheckQ 0x00989681 Bridge**
#CheckQ 0x00989682 Switch**
#CheckQ 0x00989683 PackSend 
#CheckQ 0x00989684 Manage**
#CheckQ 0x00989685 ToCtl***
#CheckQ 0x00989686 CommCup*
#CheckQ 0x00989687 CommEsbost 
#CheckQ 0x00989688 CommEsbost 
#CheckQ 0x00989689 CommP***
#CheckQ 0x00004e20 HSM*****
#CheckQ 0x00004e21 HSM*****

colour black_white 
if [ $QUEERR = 0 ]; then
echo
echo  '                     TOPFE��ǰ��ϵͳ������������                   '
echo
fi
echo '====================================================================='

sleep 1 
done
