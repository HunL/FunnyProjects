cat $FEHOME/sbin/msq.ls|while read i
do
	QID=`echo $i|awk '{printf "0x%08x", $2}'`
	PID=`echo $i|awk '{printf "%s", $1}'`
	echo "$QID,$PID"
	ipcs -qo|grep $QID|awk -v PID="$PID" '{print $3,$7,$8,PID}'
done
