## set var

#####################################
# ����
#####################################
unloadone_db ( ) {
    TBL=$1

    EXP=$1.data

    db2 connect to posdbonl user posdbonl using nature38
#    db2 connect to $DBPOSONL_NAME user $DBPOSONL_USER using $DBPOSONL_PASSWORD
    db2 "export to $EXP of del modified by coldel, select * from $TBL with ur" > unload.log

    nexp=`grep "Number of rows exported" unload.log | awk -F: '{print $2}'`
    echo " ok ! ($nexp)\n"

    db2 connect reset > /dev/null
}

loadone_db ( ) {
    tab=$1
    echo $tab

    db2 connect to posdbonl user posdbonl using nature38 
#    db2 connect to $DBPOSONL_NAME user $DBPOSONL_USER using $DBPOSONL_PASSWORD

    db2 import from $tab.data of del replace into $tab

    db2 connect reset
    db2 terminate
}
echo "================================ ��ʼ��װ ============================"
echo "Begin load Onl Data "

. $HOME/POS/etc/DbSetEnv.sh

CURDATE=`date "+%Y%m%d"`
echo "$CURDATE"

###################
echo "����Ŀ¼..."
mkdir -p $HOME/POS/backup/data/$CURDATE
if [ $? -ne "0" ]
then
    echo "!! ����Ŀ¼ʧ��\n"
    exit
fi
echo "��������Ŀ¼�ɹ�\n"

cd $HOME/POS/backup/data/$CURDATE
unloadone_db tbl_bmp_inf
unloadone_db tbl_buf_dsp
unloadone_db tbl_con_inf
unloadone_db tbl_dst_txn_inf
unloadone_db tbl_fld_dsp
unloadone_db tbl_fld_inf
unloadone_db tbl_ipc_inf
unloadone_db tbl_msg_inf
unloadone_db tbl_route_inf
unloadone_db tbl_txn_inf

cd $HOME/POS/data/20090423
loadone_db tbl_bmp_inf
loadone_db tbl_buf_dsp
loadone_db tbl_con_inf
loadone_db tbl_dst_txn_inf
loadone_db tbl_fld_dsp
loadone_db tbl_fld_inf
loadone_db tbl_ipc_inf
loadone_db tbl_msg_inf
loadone_db tbl_route_inf
loadone_db tbl_txn_inf

echo "================================ ��װ���� ============================"
exit 0

