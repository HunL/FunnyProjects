# set environment variables for NCUP

# path 
PATH=$HOME/ncup/bin:$HOME/ncup/sbin:$PATH;export PATH
PATH=$HOME/stlm/bin:$PATH;export PATH
export FEHOME=$HOME/ncup

HSMHOME=$HOME/hsm;export HSMHOME
LIBPATH=$HOME/ncup/lib:$LIBPATH;export LIBPATH
LIB_PATH=/lib:/usr/lib:$LIBPATH;export LIB_PATH
LD_LIBPARY_PATH=$LIB_PATH;export LD_LIBPARY_PATH
LD_LIBRARY_PATH=$HOME/ncup/lib:$LD_LIBRARY_PATH

#LIBPATH=$LIBPATH:$HOME/ncup/lib;export LIBPATH
#LIBPATH=$LIBPATH:$LD_LIBRARY_PATH
#export LIBPATH

THIS_IP_ADDR=10.2.47.44
export THIS_IP_ADDR
OTHER_IP_ADDR=10.2.47.43
export OTHER_IP_ADDR

BINDIR=$HOME/bin
export BINDIR
LIBDIR=$HOME/lib
export LIBDIR
BNDDIR=$HOME/bnd
export BNDDIR
SRCDIR=$HOME/src
export SRCDIR
INCDIR=$HOME/include
export INCDIR
LOGDIR=$HOME/log
export LOGDIR
FILDIR=$HOME/fil
export FILDIR
TMPDIR=$HOME/tmp
export TMPDIR


#ͬ����־ģʽ
export LOG_FILE_PATH=$HOME/log
export LOG_MODE=3
export LOG_SIZE=10000
export LOG_SWITCH_MODE=3

#���ս��׼�鿪��: 0-�ر� 1-��
export RISK_TXN_CHECK=1

