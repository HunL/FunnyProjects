# alias
alias c='clear'
alias mv='mv -i '
alias rm='rm -i '
alias cp='cp -i '
alias ls='/bin/ls -CF '
alias la='/bin/ls -aldF '
alias lt='/bin/ls -ltr '
alias l='/bin/ls -l '
alias lf='/bin/ls -F '
alias h='history'


alias cdn='cd ~/ncup/'
alias cds='cd ~/ncup/src'
alias cdr='cd ~/ncup/rpt'
DATELOAD=`date +"%Y%m%d"`
alias cdl='cd ~/ncup/log/${DATELOAD}/'
alias cdb='cd ~/ncup/bin'
alias cdsb='cd ~/ncup/sbin'
alias cdi='cd ~/ncup/include'
alias cdss='cd ~/ncup/src/Switch'
alias cdm='cd ~/ncup/src/Manage'
alias cdcust='cd ~/ncup/src/Cust'
alias cdcom='cd ~/ncup/src/Comm'
alias cgrep='find . -name "*.*c" | xargs grep -n'
alias hgrep='find . -name "*.h" | xargs grep -n'
alias conndev='db2 connect to pospdb user pospdb using pospdb'
alias disconn='db2 connect reset'
SRV_USAGE_KEY=1
export SRV_USAGE_KEY

