#==========================#
# Set DB2 Environment      #
#==========================#
DBNAME=pospdb;export DBNAME
DBUSER=pospdb;export DBUSER
DBPWD=pospdb;export DBPWD
export DBLINK="$DBNAME user $DBUSER using $DBPWD"

DB2_HOME=/home/db2inst1/sqllib
export DB2_HOME
DB2PATH=/home/db2inst1/sqllib
export DB2PATH
DB2INSTPATH=/home/db2inst1
export DB2INSTPATH
DB2INSTANCE=tplinst1
export DB2INSTANCE

DB2DBDFT=pospdb
export DB2DBDFT
SQLCMD=db2
export SQLCMD

#source ${DB2INSTPATH}/sqllib
. ${DB2INSTPATH}/sqllib/db2profile

# path 
PATH=$PATH:$DB2INSTPATH/sqllib/bin
export PATH
# for Monitor MSQ
ON_MON_MSQ_KEY=410010
export ON_MON_MSQ_KEY

#pwdpath
SADBSUserPwdFile=$HOME/ncup/etc/dbpwd.ini
export SADBSUserPwdFile
