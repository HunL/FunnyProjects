## set var

if [ $# -lt 1 ]
then
  echo "Usage: $0 <���������> "
  exit 1
fi

tab=$1
echo $tab
 
echo "Begin load Onl Data "

#. $HOME/POS/etc/DbSetEnv.sh

#db2 connect to $DBPOSONL_NAME user $DBPOSONL_USER using $DBPOSONL_PASSWORD >> LoadOne.log
db2 connect to $DBNAME user $DBUSER using $DBPWD >> LoadOne.log

db2 delete from $tab >> LoadOne.log
db2 import from $tab.data of del insert into $tab >> LoadOne.log

db2 connect reset
db2 terminate

