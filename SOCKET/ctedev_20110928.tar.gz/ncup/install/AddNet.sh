if [ $# != 3 ]; then
    echo "������������ȷ!Usage:AddNet.sh usagekey:<POSP1Ϊ1 POSP2Ϊ2>  <����IP> <�˿�>"
    exit 1
fi

UsKey=$1
Ip=$2
InPort=$3

TBL=tbl_line_cfg
EXP=tbl_line_cfg.data


db2 connect to $DBNAME user $DBUSER using $DBPWD > addnet.log
db2 "export to $EXP of del modified by coldel, select * from $TBL where usage_key=$UsKey and srv_id='1600' order by usage_key, srv_id, line_index" > addnet.log

NetCount=0
Port=0
LineIndex=0

cat tbl_line_cfg.data | while read line
do
    NetLineIndex=`echo $line | cut -d',' -f3`
    if [ $NetLineIndex -eq $LineIndex ]; then
	    continue;
    fi
 
    NetIpList[$NetCount]=`echo $line | cut -d',' -f5`
    NetPort=`echo $line | cut -d',' -f6` 
    if [ $NetPort -gt $Port ]; then
        Port=$NetPort
    fi

    if [ $NetLineIndex -gt $LineIndex ]; then
        LineIndex=$NetLineIndex
    fi
	NetCount=`expr $NetCount + 1`
done  
 
echo "֧�ֵ��������������100  ��ǰ��������: $NetCount"
rm -f tbl_line_cfg.data

let count=0
len=${#NetIpList[*]}
while [ $count -lt $len ]
do
   KEY1=${NetIpList[$count]}

KEY2=`echo $KEY1 | sed 's/ //g'`
KEY3=`echo $KEY2 | sed 's/"//g'`

   if [ "$KEY3" = "$Ip" ]
   then
       echo "������������"
       exit
   fi
   count=`expr $count + 1`
done

LineIndex=`expr $LineIndex + 1`

Lindex1=`echo $LineIndex | awk '{printf "%02d",$1}'`

db2 "insert into tbl_line_cfg (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values ($UsKey, '1600', $LineIndex, '0.0.0.0', '$Ip', $InPort, $InPort, 'NAC')" > addnet.log
db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values ($UsKey, '1600', '$Lindex1', '00', '01', 'NAC')" > addnet.log

db2 connect reset >> addnet.log
db2 terminate >> addnet.log

echo "������: $Ip ����Ķ˿�Ϊ��$InPort"
