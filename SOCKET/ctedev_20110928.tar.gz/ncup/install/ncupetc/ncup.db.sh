#==========================#
# Set DB2 Environment      #
#==========================#
DBNAME=<posdbonl_name>;export DBNAME
DBUSER=<posdbonl_user>;export DBUSER
DBPWD=<posdbonl_pass>;export DBPWD
export DBLINK="$DBNAME user $DBUSER using $DBPWD"
DBHISNAME=<posdbhis_name>;export DBHISNAME
DBHISUSER=<posdbhis_user>;export DBHISUSER
DBHISPWD=<posdbhis_pass>;export DBHISPWD
export DBHISLINK="$DBHISNAME user $DBHISUSER using $DBHISPWD"
