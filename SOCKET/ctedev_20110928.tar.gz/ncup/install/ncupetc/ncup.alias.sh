# alias
alias c='clear'
alias mv='mv -i '
alias rm='rm -i '
alias cp='cp -i '
alias ls='/bin/ls -CF '
alias la='/bin/ls -aldF '
alias lt='/bin/ls -ltr '
alias l='/bin/ls -l '
alias lf='/bin/ls -F '
alias h='history'
alias sql='dbaccess $DBNAME'

alias cdn='cd ~/ncup/'
alias cds='cd ~/ncup/src'
alias cdr='cd ~/ncup/rpt'
alias cdl='cd ~/ncup/log'
alias cdb='cd ~/ncup/bin'
alias cdi='cd ~/ncup/include'
alias cdh='cd ~/hsm'
alias conndev='db2 connect to <posdbonl_name> user <posdbhis_user> using <posdbhis_pass>'
alias disconn='db2 connect reset'
SRV_USAGE_KEY=<srv_usage_key>
export SRV_USAGE_KEY

