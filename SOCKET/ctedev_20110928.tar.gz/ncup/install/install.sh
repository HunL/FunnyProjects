#!/usr/bin/ksh
##
## install.sh  ��ϵͳӦ�ð�װ����
##


###################################################
##                ��������                       ##
###################################################

print_log( ) {
    echo "\t$1"
}

print_delay( ) {
    sleep $1
    echo "$2"
}

##
## function: print_ver( )
## ��ӡ�汾��Ϣ
## ����1����ϵͳ����
## ����2����װ�����ļ���
##
print_ver( ) {
#    sub=$1
#    fCfg=$2
#    subName=`sed -n "/"$sub"_sysname/"p $fCfg | awk -F= '{print $2}'`
    print_log "\n"
    print_log "+--------------------------------------------------------------------+"
    print_log "  Copyright 2009, TongLink Co., Ltd.  All right reserved."
    print_log "  "
    print_log "  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF TONGLINK CO.,"
    print_log "  LTD.  THE CONTENTS OF THIS FILE MAY NOT BE DISCLOSED TO THIRD"
    print_log "  PARTIES, COPIED OR DUPLICATED IN ANY FORM, IN WHOLE OR IN PART,"
    print_log "  WITHOUT THE PRIOR WRITTEN PERMISSION OF CHINA UNIONPAY CO., LTD."
    print_log "  "
    print_log "  \$Id: install.sh,v 1.1.1.1 2011/08/19 10:56:07 ctedev Exp $"
    print_log "  "
    print_log "  CTE ��װ����"
    print_log "  "
    print_log "  2010/07/10  Created by "
    print_log "+--------------------------------------------------------------------+\n"

}

##
## function: print_env( )
## ��ʾ��ǰ��������
##
print_env( ) {
    fEnv=$1
    env > env.log
    while read line
    do
        line1=`echo $line|awk -F= '{print $1}'`
        line2=`echo $line|awk -F= '{print $2}'`
        if [ "$line2" = "" ]
        then
            continue
        fi

        var=`echo $line1|awk '{print $NF}'`
        sed -n "/$var/"p env.log
#        sleep 1
    done < $fEnv
    rm -f env.log
}


##
## function: replace_env( )
## �滻�ļ��еĻ�������
## ����1�����滻���ļ���
##
replace_env( ) {
    file=$1
    temp=$1.tmp

    env > env.log
    while read line
    do
        var=`echo $line|awk -F= '{print $1}'`
        value=`echo $line|awk -F= '{print $2}'`
        if [ "$var" = "" ]
        then
            continue
        fi

        echo $value | sed 's/\//\\\//g' > tttt
        newVal=`cat tttt`

        sed "s/<\$$var>/$newVal/g" $file > $temp
        mv $temp $file
    done < env.log
    rm -f tttt
    rm -f env.log
}


##
## function: replace_cfg( )
## ���ݰ�װ�����ļ��滻���������ļ��е���Ӧֵ
## ����1�����滻���ļ�
## ����2����װ�����ļ�
##
replace_cfg( ) {
    file=$1
    temp=$1.tmp
    modelfile=$2
 
    while read line
    do
        var=`echo $line|awk -F= '{print $1}'`
        value=`echo $line|awk -F= '{print $2}'`

        if [ "$value" = "" ]
        then
            continue
        fi

        if [ $FLAG = 2 ]
        then
            if [ "$var" = "srv_usage_key" ]
            then
                value=$FLAG
            fi
        fi

        echo $value | sed 's/\//\\\//g' > tttt
        newVal=`cat tttt`
        sed "s/<$var>/$newVal/g" $file > $temp
        mv $temp $file
    done < $modelfile
    rm -f tttt
}


##
## function: catalog_db( )
## ΪӦ���û���Ŀ���ݿ�
## ����1: Ҫ��Ŀ�����ݿ����
## ����2: ��װ�����ļ�
##
catalog_db( ) {
    print_log "     ��Ŀ "$1"db ...\c"
    dbIp=`sed -n "/posdb"$1"_hostip/"p $2| awk -F= '{print $2}'`
    dbSvc=`sed -n "/posdb"$1"_service/"p $2| awk -F= '{print $2}'`
    dbItn=`sed -n "/posdb"$1"_instance/"p $2| awk -F= '{print $2}'`
    dbNm=`sed -n "/posdb"$1"_name/"p $2| awk -F= '{print $2}'`

    db2set db2codepage=1386
    db2set db2comm=tcpip

    db2 catalog tcpip node $1"node" remote $dbIp server $dbSvc >> install.log 
    db2 catalog db $dbNm at node $1"node" authentication server >> install.log
    db2 terminate >> install.log
    print_log " ���"
}

uncatalog_db( ) {
    print_log "     ��Ŀ "$1"db ...\c"
    dbIp=`sed -n "/posdb"$1"_hostip/"p $2| awk -F= '{print $2}'`
    dbSvc=`sed -n "/posdb"$1"_service/"p $2| awk -F= '{print $2}'`
    dbItn=`sed -n "/posdb"$1"_instance/"p $2| awk -F= '{print $2}'`
    dbNm=`sed -n "/posdb"$1"_name/"p $2| awk -F= '{print $2}'`

    db2 uncatalog db $dbNm 
    db2 uncatalog node $1"node" 
    db2 terminate >> install.log
    print_log " ���"
}

##
## function: connect_db( )
## �������ݿ�
## ����1: ���ݿ����
## ����2: ��װ�����ļ�
##
connect_db( ) {
    cfg=$2
    dbName=`sed -n "/posdb"$1"_name/"p $cfg | awk -F= '{print $2}'`
    dbUser=`sed -n "/posdb"$1"_user/"p $cfg | awk -F= '{print $2}'`
    dbPass=`sed -n "/posdb"$1"_pass/"p $cfg | awk -F= '{print $2}'`
    db2 connect to $dbName user $dbUser using $dbPass >> install.log
}    

##
## function: bind_dbfile( )
## �����ݿ��ļ�
## ����1: ���ݿ����
## ����2: ��װ�����ļ�
##
bind_dbfile( ) {
    connect_db $1 $2 
    ls $APPHOME/bnd/$1/*.bnd > tttt
    while read fBnd
    do
        print_log " ���ļ� $fBnd"
        db2 bind $fBnd >> install.log
    done < tttt
    db2 connect reset >> install.log
    rm -f tttt
}

##
## function: check_env( )
## ��黷������
## ����1: Ҫ���Ļ��������б�
##
check_env( ) {
    sEnv=$1
    for loop in $sEnv
    do
        haha=`env|sed -n "/$loop/"p`
        if [ "$haha" = "" ]
        then
            print_log "!! Warning: δ��⵽�������� $loop\n"
            return 1
        fi
    done
    return 0
}

##
## replace_db()
## �滻���ݿ�Ĳ���
## ����1:
##
replace_db( ) {
   connect_db $1 $2  >> install.log

#  update ��tbl_line_cfg
   dbposSrvId=`sed -n "/pos_srv_id/"p $2| awk -F= '{printf $2}'` 
   dbposUsageKey1=`sed -n "/pos_usage_key1/"p $2| awk -F= '{printf $2}'` 
   dbposIpOne1=`sed -n "/pos_ip_one1/"p $2| awk -F= '{printf $2}'` 
   dbposInPortOne1=`sed -n "/pos_in_port_one1/"p $2| awk -F= '{print $2}'`
   dbposOutPortOne1=`sed -n "/pos_out_port_one1/"p $2| awk -F= '{print $2}'`

   dbposIpTwo1=`sed -n "/pos_ip_two1/"p $2| awk -F= '{printf $2}'` 
   dbposInPortTwo1=`sed -n "/pos_in_port_two1/"p $2| awk -F= '{print $2}'`
   dbposOutPortTwo1=`sed -n "/pos_out_port_two1/"p $2| awk -F= '{print $2}'`

   dbposUsageKey2=`sed -n "/pos_usage_key2/"p $2| awk -F= '{printf $2}'` 
   dbposIpOne2=`sed -n "/pos_ip_one2/"p $2| awk -F= '{printf $2}'` 
   dbposInPortOne2=`sed -n "/pos_in_port_one2/"p $2| awk -F= '{print $2}'`
   dbposOutPortOne2=`sed -n "/pos_out_port_one2/"p $2| awk -F= '{print $2}'`

   dbposIpTwo2=`sed -n "/pos_ip_two2/"p $2| awk -F= '{printf $2}'` 
   dbposInPortTwo2=`sed -n "/pos_in_port_two2/"p $2| awk -F= '{print $2}'`
   dbposOutPortTwo2=`sed -n "/pos_out_port_two2/"p $2| awk -F= '{print $2}'`

   dbapsSrvId=`sed -n "/aps_srv_id/"p $2| awk -F= '{printf $2}'` 
   dbapsIp1=`sed -n "/aps_ip1/"p $2| awk -F= '{print $2}'`
   dbapsInPort1=`sed -n "/aps_in_port1/"p $2| awk -F= '{print $2}'`
   dbapsOutPort1=`sed -n "/aps_out_port1/"p $2| awk -F= '{print $2}'`

   dbapsIp2=`sed -n "/aps_ip2/"p $2| awk -F= '{print $2}'`
   dbapsInPort2=`sed -n "/aps_in_port2/"p $2| awk -F= '{print $2}'`
   dbapsOutPort2=`sed -n "/aps_out_port2/"p $2| awk -F= '{print $2}'`

   dbpospSrvId=`sed -n "/posp_srv_id/"p $2| awk -F= '{printf $2}'` 
   dbpospIp1=`sed -n "/posp_ip1/"p $2| awk -F= '{print $2}'`
   dbpospInPort1=`sed -n "/posp_in_port1/"p $2| awk -F= '{print $2}'`
   dbpospOutPort1=`sed -n "/posp_out_port1/"p $2| awk -F= '{print $2}'`
   dbpospIp2=`sed -n "/posp_ip2/"p $2| awk -F= '{print $2}'`
   dbpospInPort2=`sed -n "/posp_in_port2/"p $2| awk -F= '{print $2}'`
   dbpospOutPort2=`sed -n "/posp_out_port2/"p $2| awk -F= '{print $2}'`
   dbpos_localaddr1=0.0.0.0
   
   db2 "delete from tbl_line_cfg" >> install.log
   db2 "delete from tbl_line_inf" >> install.log

   if [ "$dbposIpOne1" != "" ] 
   then
      db2 "insert into TBL_LINE_CFG (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values (1, '1600', 1, '$dbpos_localaddr1', '$dbposIpOne1', $dbposInPortOne1, $dbposOutPortOne1, 'NAC1')" >> install.log
      db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values (1,'1600','01', '00', '01', 'NAC')" >> install.log
   fi
 
   if [ "$dbposIpTwo1" != "" ] 
   then
      db2 "insert into TBL_LINE_CFG (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values (1, '1600', 2, '$dbpos_localaddr1', '$dbposIpTwo1', $dbposInPortTwo1, $dbposOutPortTwo1, 'NAC2')" >> install.log
      db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values (1,'1600','02', '00', '01', 'NAC2')" >> install.log
   fi

   if [ "$dbposIpOne2" != "" ] 
   then
      db2 "insert into TBL_LINE_CFG (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values (2, '1600', 1, '$dbpos_localaddr1', '$dbposIpOne2', $dbposInPortOne2, $dbposOutPortOne2, 'NAC1')" >> install.log
      db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values (2,'1600','01', '00', '01', 'NAC1')" >> install.log
   fi

   if [ "$dbposIpTwo2" != "" ] 
   then
      db2 "insert into TBL_LINE_CFG (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values (2, '1600', 2, '$dbpos_localaddr1', '$dbposIpTwo2', $dbposInPortTwo2, $dbposOutPortTwo2, 'NAC2')" >> install.log
      db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values (2,'1600','02', '00', '01', 'NAC2')" >> install.log
   fi

   if [ "$dbapsIp1" != "" ]
   then 
      db2 "insert into TBL_LINE_CFG (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values (1, '1700', 1, '$dbpos_localaddr1', '$dbapsIp1', $dbapsInPort1, $dbapsOutPort1, 'APS1')" >> install.log
      db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values (1,'1700','01', '00', '01', 'APS1')" >> install.log
   fi

   if [ "$dbapsIp2" != "" ]
   then 
      db2 "insert into TBL_LINE_CFG (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values (2, '1700', 1, '$dbpos_localaddr1', '$dbapsIp2', $dbapsInPort2, $dbapsOutPort2, 'APS2')" >> install.log
      db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values (2,'1700','02', '00', '01', 'APS2')" >> install.log
   fi

if [ "$dbpospIp1" != "" ]
   then
      db2 "insert into TBL_LINE_CFG (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values (1, '1900', 1, '$dbpos_localaddr1', '$dbpospIp1', $dbpospInPort1, $dbpospOutPort1, 'POSP1')" >> install.log
      db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values (1,'1900','01', '00', '01', 'APS2')" >> install.log
   fi

   if [ "$dbpospIp2" != "" ]
   then
      db2 "insert into TBL_LINE_CFG (USAGE_KEY, SRV_ID, LINE_INDEX, LOCAL_ADDR, REMOTE_ADDR, IN_SOCK_NUM, OUT_SOCK_NUM, LINE_DSP) values (2, '1900', 1, '$dbpos_localaddr1', '$dbpospIp2', $dbpospInPort2, $dbpospOutPort2, 'POSP2')" >> install.log
      db2 "insert into tbl_line_inf (usage_key, srv_id, line_index, line_state, line_max, line_dsp) values (2,'1900','01', '00', '01', 'POSP2')" >> install.log
   fi
 

#  update ��tbl_srv_inf
   
   dbSrvId1=`sed -n "/srv_id1/"p $2|awk -F= '{print $2}'`
   dbSrvName1=`sed -n "/srv_name1/"p $2|awk -F= '{print $2}'`
   dbSrvNum1=`sed -n "/srv_num1/"p $2|awk -F= '{print $2}'` 
   dbSrvId2=`sed -n "/srv_id2/"p $2|awk -F= '{print $2}'`
   dbSrvName2=`sed -n "/srv_name2/"p $2|awk -F= '{print $2}'` 
   dbSrvNum2=`sed -n "/srv_num2/"p $2|awk -F= '{print $2}'` 
   dbSrvId3=`sed -n "/srv_id3/"p $2|awk -F= '{print $2}'`
   dbSrvName3=`sed -n "/srv_name3/"p $2|awk -F= '{print $2}'` 
   dbSrvNum3=`sed -n "/srv_num3/"p $2|awk -F= '{print $2}'` 
   dbSrvId4=`sed -n "/srv_id4/"p $2|awk -F= '{print $2}'`
   dbSrvName4=`sed -n "/srv_name4/"p $2|awk -F= '{print $2}'` 
   dbSrvNum4=`sed -n "/srv_num4/"p $2|awk -F= '{print $2}'` 
   dbSrvId5=`sed -n "/srv_id5/"p $2|awk -F= '{print $2}'`
   dbSrvName5=`sed -n "/srv_name5/"p $2|awk -F= '{print $2}'` 
   dbSrvNum5=`sed -n "/srv_num5/"p $2|awk -F= '{print $2}'` 
   dbSrvId6=`sed -n "/srv_id6/"p $2|awk -F= '{print $2}'`
   dbSrvName6=`sed -n "/srv_name6/"p $2|awk -F= '{print $2}'` 
   dbSrvNum6=`sed -n "/srv_num6/"p $2|awk -F= '{print $2}'` 
  
   if [ "$dbSrvNum1" != "" ]
   then
        db2 "update tbl_srv_inf set srv_num='$dbSrvNum1' where srv_id ='$dbSrvId1' and srv_name='$dbSrvName1'" >> install.log
   fi
 
   if [ "$dbSrvNum2" != "" ]
   then
        db2 "update tbl_srv_inf set srv_num='$dbSrvNum2' where srv_id ='$dbSrvId2' and srv_name='$dbSrvName2'" >> install.log
   fi

   if [ "$dbSrvNum3" != "" ]
   then
        db2 "update tbl_srv_inf set srv_num='$dbSrvNum3' where srv_id ='$dbSrvId3' and srv_name='$dbSrvName3'" >> install.log
   fi

   if [ "$dbSrvNum4" != "" ]
   then
        db2 "update tbl_srv_inf set srv_num='$dbSrvNum4' where srv_id ='$dbSrvId4' and srv_name='$dbSrvName4'" >> install.log
   fi

   if [ "$dbSrvNum5" != "" ]
   then
        db2 "update tbl_srv_inf set srv_num='$dbSrvNum5' where srv_id ='$dbSrvId5' and srv_name='$dbSrvName5'" >> install.log
   fi
   
   if [ "$dbSrvNum6" != "" ]
   then
        db2 "update tbl_srv_inf set srv_num='$dbSrvNum6' where srv_id ='$dbSrvId6' and srv_name='$dbSrvName6'" >> install.log
   fi

#  update tbl_ins_key

   dbInsKeyIdx=`sed -n "/inskeyidx/"p $2|awk -F= '{print $2}'`

   if [ "$dbInsKeyIdx" != "" ]
   then
        db2 "update tbl_ins_key set ins_key_idx='$dbInsKeyIdx' where ins_id_cd ='1700' and ins_key_idx='0501'" >> install.log
   fi
   
    db2 connect reset >> install.log
    db2 terminate >> install.log
}
  

###################################################
##                  ȫ�ֱ���                     ##
###################################################
subSys=apsposp
cfgFile=install_$2.cfg

echo "cfgFile: $cfgFile"

while getopts :m:b OPTION
do
    case $OPTION in
    m) mainMachine=1
       ;; 
    b) backMachine=1
       ;; 
    :)
       print_log "��������!! \n\t\tѡ�� -$OPTARG ���븳ֵ\n"
       exit 
       ;;
    \?)
       print_log "��������!! \n\t\t��ʹ�� $0 -h ����鿴����\n"
       exit
       ;;
    esac
done

tput clear

subDir="ncup"
APPHOME=$HOME/$subDir

print_ver $subSys $cfgFile

print_log "\n"
print_log "============================== ׼����װ =============================="

##################
print_log ">> ��鰲װ��־ .\c"
if [ $# -lt 2 ]
then
  echo "Usage: $0 <��װ��־:��һ̨POSP����:1 �ڶ�̨����:2> <��װ����:����:dev  ����:ver  ����:prod> "
  exit 1
fi

FLAG=$1


###################
print_log ">> ����ļ� .\c"

if [ ! -s $cfgFile ]
then
    print_log "\n"
    print_log "ERROR: ��װ�����ļ�[$cfgFile]�����ڻ�Ϊ��!!\n"
    exit
fi
print_delay 1 ". ���"


###################
print_log ">> ���а�װ���� ... \c"
installDir=$HOME/$subDir/install
mkdir -p $installDir/.install_bak 2>>install.log
cp $HOME/.profile $installDir/.install_bak/ 2>>install.log
cp $APPHOME/etc/* $installDir/.install_bak/ 2>>install.log
print_delay 1 "���\n"

print_log "============================== ��ʼ��װ =============================="
sleep 1

###################
#print_log ">> װ�ز���黷������ ...\c"
# replace_env $APPHOME/etc/$envFile
#. $APPHOME/etc/$envFile         #���뻷������
#. $APPHOME/etc/`basename $tuxEnv`
#export LANG=C
# ....(����Ҫ����Ļ��������ļ�)
# ....

check_env $envList
if [ $? = 1 ]
then
    print_log "   ���޸����ϴ���"
    exit
fi
print_delay 1 " ���\n"


###################
print_log ">> ��Ŀ���ݿ� ... "  
uncatalog_db onl $cfgFile
uncatalog_db his $cfgFile

catalog_db onl $cfgFile
catalog_db his $cfgFile


######ɾ�����õ�db  ������ #####
#uncatalog_db onl $cfgFile
#uncatalog_db his $cfgFile
print_log "\n"

###################
print_log ">> �޸��ļ� [$HOME/.profile] ... \c"  
echo ". \$HOME/ncup/etc/ncup.db.sh" >> $HOME/.profile
echo ". \$HOME/ncup/etc/ncup.unix.sh" >> $HOME/.profile
echo ". \$HOME/ncup/etc/ncup.alias.sh" >> $HOME/.profile
echo ". \$HOME/hsm/etc/hsm.env" >> $HOME/.profile
echo "export LANG=C" >> $HOME/.profile

# .... (����Ҫ���ӵ� .profile �е��ļ�)
print_delay 1 " ���\n"


###################
print_log ">> ����Ŀ¼... \c"
mkdir -p $HOME/log
if [ $? -ne "0" ]
then
    print_log "\r"
    print_log "!! ����Ŀ¼ʧ��\n"
    exit
fi
print_delay 1 " ���\n"


###################
print_log ">> �����ļ�ͬ��Ŀ¼... \c"
mkdir -p $HOME/synfile
if [ $? -ne "0" ]
then
    print_log "\r"
    print_log "!! ����Ŀ¼ʧ��\n"
    exit
fi
print_delay 1 " ���\n"


###################
print_log ">> ����������־Ŀ¼... \c"
mkdir -p $HOME/backup/log
if [ $? -ne "0" ]
then
    print_log "\r"
    print_log "!! ����Ŀ¼ʧ��\n"
    exit
fi
print_delay 1 " ���\n"


###################
print_log ">> ������������Ŀ¼... \c"
mkdir -p $HOME/backup/db
if [ $? -ne "0" ]
then
    print_log "\r"
    print_log "!! ����Ŀ¼ʧ��\n"
    exit
fi
print_delay 1 " ���\n"


###################
print_log ">> �޸����������ļ� [$APPHOME/etc/*.sh] ... "
ls $APPHOME/install/ncupetc/* > cfg.list
while read fCfg
do
  fileNm=`basename $fCfg`

  print_log "    �޸� $fileNm ...\c"

  cp $fCfg $fileNm

  replace_cfg $fileNm $cfgFile

  mv $fileNm $APPHOME/etc

done < cfg.list
rm -f cfg.list
print_delay 0 "\n"


###################
print_log ">> �޸����������ļ� [$APPHOME/sbin/*] ... "
ls $APPHOME/install/ncupsbin/* > cfg.list
while read fCfg
do
  fileNm=`basename $fCfg`

  print_log "    �޸� $fileNm ...\c"

  cp $fCfg $fileNm

  replace_cfg $fileNm $cfgFile

  mv $fileNm $APPHOME/sbin

done < cfg.list
rm -f cfg.list
print_delay 0 "\n"


###################
print_log ">> �޸����������ļ� [$HOME/hsm/etc/*] ... "
ls $APPHOME/install/hsmetc/* > cfg.list
while read fCfg
do
  fileNm=`basename $fCfg`

  print_log "    �޸� $fileNm ...\c"

  cp $fCfg $fileNm

  replace_cfg $fileNm $cfgFile

  mv $fileNm $HOME/hsm/etc

done < cfg.list
rm -f cfg.list
print_delay 0 "\n"


###################
print_log ">> �޸��ļ����� ... \c"
# ... (������װ����)
chmod u+x $APPHOME/bin/* 2>> install.log
chmod u+x $APPHOME/sbin/* 2>> install.log

print_delay 1 "���\n"


if [ "$FLAG" = "1" ]
then
###################
     print_log ">> ���°��������ݿ��ļ� ... "
     bind_dbfile onl $cfgFile
     print_log ">> ���������ݿ��ļ����\n"

     print_log ">> ���°���ʷ���ݿ��ļ� ... "
     bind_dbfile his $cfgFile
     print_log ">> ����ʷ���ݿ��ļ����\n"

###################
     print_log ">> �������ݿ����� ... "
     replace_db onl $cfgFile
     print_log ">> �������ݿ��������\n"

 
###################���ò���ͬ�����Զ�����
(crontab -r ) | crontab
(echo "#APS ÿ��һСʱ�·�һ�β���ͬ���ļ�, �� 05�ֿ�ʼ" ; crontab -l ) | crontab
(echo "#POSP ��������15��45�����ز���ͬ���ļ�" ; crontab -l ) | crontab
(echo "15,45 * * * * /usr/bin/sh $HOME/tools/sbin/SynTable.sh" ; crontab -l ) | crontab
(echo "#ÿ��01:00��ʼ����clearlog.sh�ű�����־��������" ; crontab -l ) | crontab
(echo "00 1  * * * $HOME/ncup/sbin/clearlog.sh 1" ; crontab -l ) | crontab
(echo "#ÿ��02:10��ʼ����clearmon.sh�ű�����������" ; crontab -l ) | crontab
(echo "10 2  * * * $HOME/ncup/sbin/clearmon.sh" ; crontab -l ) | crontab 
fi

if [ "$FLAG" = "2" ] 
then
(echo "#ÿ��01:00��ʼ����clearlog.sh�ű�����־��������" ; crontab -l ) | crontab
(echo "00 1  * * * $HOME/ncup/sbin/clearlog.sh 2" ; crontab -l ) | crontab
fi
print_log "============================== ��װ���� ==============================\n"

