cd $FEHOME/src/BPCust
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/TomBp
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SwtBonus
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommBP
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/XML/mxml/
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/XML/xmlComm/
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommSOAP/
sh makeclean
sh makeall
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommSOAP/CommMall
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommGzsb
make clean all
if [ $? -ne 0 ];then
  exit 1
fi
