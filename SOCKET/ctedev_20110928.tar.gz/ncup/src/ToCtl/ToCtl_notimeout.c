/*****************************************************************************/
/*                    Shanghai Huateng Software System Inc.                  */
/*****************************************************************************/
/* PROGRAM NAME: ToCtl.c                                                     */
/* DESCRIPTIONS: The time out controller.                                    */
/*****************************************************************************/
/*                               MODIFICATION    LOG                         */
/* DATE           PROGRAMMER      DESCRIPTION                                */
/*                                                                           */
/*****************************************************************************/
static char *Id = "$Id: ToCtl_notimeout.c,v 1.1.1.1 2011/08/19 10:55:50 ctedev Exp $";
#include "ToCtl.h"

char      gsSrvId[SRV_ID_LEN+1];
char      gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char      gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq  gatSrvMsq[SRV_MSQ_NUM_MAX];

/* VARIABLES USED FOR TIMEOUT QUEUE */
short gnQueueHeader = NULL0;
short gnQueueTailer = NULL0;
short gnUnusedHeader = 1;

long glHeadTime = 0;
long glTailTime = 0;

ToQueueDef gpToQueue[MAX_TO_QUEUE+1];

Tbl_ssn_Def  gtTblSsn;

int main(short argc, char **argv)
{
    int              nReturnCode;
    int              nMsgSize;
    int              nAlarmTime=0;
    T_SwtToReqDef    tSwtToReq;

    long             lBeginTime, lEndTime ;
    struct tms       tTMS;

    nReturnCode = ToCtlInit(argc, argv);
    if (nReturnCode) {
        printf("ToCtl: ToCtlInit error %d\n", nReturnCode);
        return -1;
    }
    
    /* set alarm signal */
    if (sigset(SIGALRM, HandleTickOut) == SIG_ERR)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "sigset SIGALARM error, %d.", errno);
        return;
    }

    if (sigset(SIGTERM, HandleExit) == SIG_ERR)
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "sigset SIGTERM error, %d.", errno);

    sighold(SIGTERM);

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ToCtl started.");
    
    lBeginTime = 0;
    lEndTime = 0;
    /* HANDLE TRANSACTION */
    while (1)
    {
        /* get alarm time and set alarm */
        nAlarmTime = TO_MAX_ALARM_TIME;
        if (gnQueueHeader != NULL0)
        {
            nAlarmTime = gpToQueue[gnQueueHeader].lTimeLeft;
        }

        if (nAlarmTime != TO_MAX_ALARM_TIME)
        {
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
                   "ToQueue has alarmed in %d second.", nAlarmTime);
            alarm(nAlarmTime);
        }
        else
        {
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "no alarm signal.");
            alarm(0);
        }

        /* read msg from queue */
        sigrelse(SIGTERM);

        nMsgSize = sizeof(tSwtToReq);
        nReturnCode = MsqRcv(gsSrvId,
                             gatSrvMsq,
                             atoi(SRV_ID_TOCTL) * 100 + atoi(gsSrvSeqId),
                             MSQ_RCV_MODE_BLOCK,
                             &nMsgSize,
                             (char *)&tSwtToReq);
        sighold (SIGTERM);

        lBeginTime = times(&tTMS);

        if (nReturnCode)
        {
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
            {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                       "MsqRcv error, %d.", nReturnCode);
                return;
            }
        }
        else
        {
            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
                   "received request %d from %4.4s.", tSwtToReq.nTransCode, tSwtToReq.sSrvId);
            HandleRequest(&tSwtToReq);
        }

        lEndTime = times(&tTMS);
    }  /* for(;;) */

}

int ToCtlInit(short argc, char **argv)
{
    int                i,j;
    int                nReturnCode;
    long               lUsageKey;
    Tbl_srv_inf_Def    tTblSrvInf;
    char               saTlrType[10], *sToken;

    /* get server id, arg 1; server seq, arg 2 */
    strcpy(gsSrvId, argv[1]);
    strcpy(gsSrvSeqId, argv[2]);
    
    if (getenv(SRV_USAGE_KEY))
        lUsageKey = atoi(getenv(SRV_USAGE_KEY));
    else
        return -1;

    /* connect to database */
    nReturnCode = DbsConnect();
    if (nReturnCode)
        return (nReturnCode);
    
    /* get log file name from tbl_srv_inf */
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
    if (nReturnCode)
        return nReturnCode;
    CommonRTrim(tTblSrvInf.srv_name);
    sprintf(gsLogFile, "%s.%s.log", tTblSrvInf.srv_name, gsSrvSeqId);

    /* set gtTblSsn */
    memset(&gtTblSsn, 0, sizeof(gtTblSsn));
    nReturnCode = DbsSsn(DBS_SELECT, &gtTblSsn);
    if (nReturnCode) 
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "DbsSsn select error, %d.", nReturnCode);
        DbsDisconnect();
        return nReturnCode;
    }

    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
           "ssn_value = [%s]", gtTblSsn.ssn_value);
    
    /* init msg queue */
    memset((char *)gatSrvMsq, 0, sizeof(gatSrvMsq));
    nReturnCode = MsqInit(gsSrvId, gatSrvMsq);
    if (nReturnCode)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "MsqInit error, %d.", nReturnCode);
        DbsDisconnect();
        return nReturnCode;
    }

    /* initialize to queue */
    for (i=1; i<MAX_TO_QUEUE; i++) 
        gpToQueue[i].nAhead = i + 1;
    gpToQueue[i].nAhead = NULL0;

    return 0;
}

int GetSSN(char *pSSN)
{
    char          sFuncName[] = "GetSSN";
    static int    nBufCount = 0;
    int           nReturnCode, i;
    long          lNewSsn;
	char          sTmpCode[9+1];
    
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);

    /* calc next ssn value */
    lNewSsn = atol(gtTblSsn.ssn_value);
    if (lNewSsn == atol(gtTblSsn.ssn_max))
        lNewSsn = atol(gtTblSsn.ssn_min);
    else
        lNewSsn++;
    
    sprintf(gtTblSsn.ssn_value, "%06ld", lNewSsn);
    memcpy(pSSN, gtTblSsn.ssn_value, F011_LEN);

    /* check whether reached buf count */
    nBufCount++;
    if (nBufCount >= atoi(gtTblSsn.buf_count))
    {
        /* save current ssn value in table tbl_ssn */
        nReturnCode = DbsSsn(DBS_UPDATE, &gtTblSsn);
        if (nReturnCode)
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                   "DbsSsn select error, %d.", nReturnCode);
            return nReturnCode;
        }
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
               "DbsSsn select success.");

        nBufCount = 0;
    }

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}

void HandleTickOut(int iSig)
{
    char sFuncName[] = "HandleTickOut";

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);
    CalcTimeElapsed();
    DebugQueue();
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
}

void HandleRequest(T_SwtToReqDef *pSwtToReq)
{
    char             sFuncName[] = "HandleRequest";
    int              nReturnCode;
    T_SwtToReqDef    tSwtToReply;
	int pid = getpid();

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);
    HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
                   (char *)pSwtToReq, sizeof(*pSwtToReq));
    
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TransCode [%d] begin.", pSwtToReq->nTransCode);
    switch(pSwtToReq->nTransCode)
    {
        case TOCTL_NORMAL_FIRST:
        case TOCTL_REVERSAL_FIRST:
            /* set reply msg */
            memcpy((char *)&tSwtToReply, (char *)pSwtToReq, sizeof (*pSwtToReq));
            tSwtToReply.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;
            nReturnCode = GetSSN(tSwtToReply.sSysSeqNum);
            if (nReturnCode)
            {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                       "GetSSN error, %d.", nReturnCode);
                tSwtToReply.nReplyCode = TOCTL_REPLY_CODE_NOT_OK;
            }

            /* send reply */
            nReturnCode = MsqSnd(tSwtToReply.sSrvId,
                                 gatSrvMsq,
                                 pSwtToReq->lRtnMsgType,
                                 sizeof(tSwtToReply),
                                (char *)&tSwtToReply);

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__,
                   "send reply to %4.4s.", tSwtToReply.sSrvId);

            HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
                           (char *)&tSwtToReply, sizeof (tSwtToReply));
            if (nReturnCode)
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                       "msgsnd error, %d.", nReturnCode);

            break;
    
        case TOCTL_NORMAL_SECOND:
            /* set reply msg */
            memcpy((char *)&tSwtToReply, (char *)pSwtToReq, sizeof(*pSwtToReq));

            tSwtToReply.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;

            /* send reply */
            nReturnCode = MsqSnd(tSwtToReply.sSrvId,
                                 gatSrvMsq,
                                 pSwtToReq->lRtnMsgType,
                                 sizeof(tSwtToReply),
                                 (char *)&tSwtToReply);

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__,
                   "send reply to %4.4s.", tSwtToReply.sSrvId);
            HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
                           (char *)&tSwtToReply, sizeof (tSwtToReply));
            if (nReturnCode)
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                       "msgsnd error, %d.", nReturnCode);

            break;

        default:
            break;
    }

    CalcTimeElapsed();
/*    DebugQueue();     */

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
}

short DeleteQueue(T_SwtToReqDef *pSwtToReply)
{
    char   sFuncName[] = "DeleteQueue";
    short  nItem, nItemPrev;
    char   *pSSN= pSwtToReply->sSysSeqNum;

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);

    nItem = gnQueueHeader;
    nItemPrev = NULL0;

    /* locate item in queue */
    while (nItem!=NULL0)
    {
        if (memcmp( gpToQueue[nItem].pSSN, pSSN, F011_LEN) ||
            memcmp(gpToQueue[nItem].sTxnDate, pSwtToReply->sTxnDate, F007_LEN))
        {
            nItemPrev = nItem;
            nItem = gpToQueue[nItem].nAhead;
        }
        else
            break;
    }

    /* item not found */
    if ( nItem == NULL0)
        return TOCTL_REPLY_CODE_HAD_TO;
    else
    {
        /* found, set sToReserved */
        memcpy(pSwtToReply->sToReserved, gpToQueue[nItem].sToReserved, TO_RESERVED_LEN);
    }

    /* item is queue head, set head to next item */
    if ( nItem == gnQueueHeader)
    {
        gnQueueHeader = gpToQueue[nItem].nAhead;
    }

    /* move item to unused queue */
    if ( nItem == gnQueueTailer)
    {
        glTailTime -= gpToQueue[nItem].lTimeLeft;
        gnQueueTailer = nItemPrev;
        gpToQueue[nItemPrev].nAhead=NULL0;
    }
    else
    {
        gpToQueue[gpToQueue[nItem].nAhead].lTimeLeft
            += gpToQueue[nItem].lTimeLeft;
        if ( nItemPrev != NULL0)
            gpToQueue[nItemPrev].nAhead
                = gpToQueue[nItem].nAhead;
    }

    gpToQueue[nItem].nAhead = gnUnusedHeader;
    gnUnusedHeader = nItem;       

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
    return TOCTL_REPLY_CODE_NOT_TO;
}

void InsertQueue(T_SwtToReqDef *pSwtToReply)
{ 
    char    sFuncName[] = "InsertQueue";
    short   nItem;
    short   nItemCur, nItemPrev;
    long    lTempTime;
    long    lTimeSum;
    long    lTimeSumPrev;

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);

    /* get a free item */
    if(gnUnusedHeader == NULL0)
    {
        pSwtToReply->nReplyCode = TOCTL_REPLY_CODE_NOT_OK;
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
        return;
    }

    nItem = gnUnusedHeader;
    gnUnusedHeader = gpToQueue[gnUnusedHeader].nAhead;

    gpToQueue[nItem].nAhead = NULL0;

    /* set values in item */
    memcpy(gpToQueue[nItem].sSrvId, pSwtToReply->sSrcSrvId, SRV_ID_LEN);
    gpToQueue[nItem].lRtnMsgType = pSwtToReply->lRtnMsgType;
    memcpy(gpToQueue[nItem].pSSN, pSwtToReply->sSysSeqNum, F011_LEN);
    memcpy(gpToQueue[nItem].sTxnDate, pSwtToReply->sTxnDate, F007_LEN);
    memcpy(gpToQueue[nItem].sToReserved, pSwtToReply->sToReserved, TO_RESERVED_LEN);

    if(gnQueueHeader == NULL0)
    {    
        /* the first item */
        time(&glHeadTime);
        gpToQueue[nItem].lTimeLeft = pSwtToReply->nToCtlTime;

        gnQueueHeader = nItem;
        gnQueueTailer = nItem;
    }
    else
    {    
        /* insert the new item into queue */
        /* find a place for this item, the queue is ordered by time when it times out */
        nItemCur = gnQueueHeader;
        nItemPrev = NULL0;

        time(&lTempTime);
        lTimeSum = glHeadTime;
        lTimeSumPrev = 0;

        while (nItemCur != NULL0)
        {
            lTimeSum += gpToQueue[nItemCur].lTimeLeft;
            if (lTimeSum <= lTempTime + pSwtToReply->nToCtlTime)
            {
                nItemPrev = nItemCur;
                lTimeSumPrev = lTimeSum;
                nItemCur = gpToQueue[nItemCur].nAhead;
            }
            else
                break;
        }

        if (nItemCur == NULL0)
        {
            /* add new item after tail */
            time (&glTailTime);
            gpToQueue[nItem].lTimeLeft = lTempTime + pSwtToReply->nToCtlTime - lTimeSum;
            gpToQueue[gnQueueTailer].nAhead = nItem;
            gnQueueTailer = nItem;

        }
        else
        {
            if (nItemCur == gnQueueHeader)
            {
                /* add new item before head */
                time (&glHeadTime);
                gpToQueue[nItem].lTimeLeft = pSwtToReply->nToCtlTime;
                gpToQueue[nItemCur].lTimeLeft = lTimeSum - lTempTime - pSwtToReply->nToCtlTime;
                gpToQueue[nItem].nAhead = nItemCur;
                gnQueueHeader = nItem;

            }
            else
            {
                /* insert new item before nItemCur */
                gpToQueue[nItem].lTimeLeft = lTempTime + pSwtToReply->nToCtlTime - lTimeSumPrev;
                gpToQueue[nItemCur].lTimeLeft = lTimeSum - lTempTime - pSwtToReply->nToCtlTime;
                gpToQueue[nItem].nAhead = nItemCur;
                gpToQueue[nItemPrev].nAhead = nItem;

            }
        }
    }

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);

}

void DebugQueue()
{
    char sFuncName[] = "DebugQueue";
    int  i;
    char szTemp[TO_RESERVED_LEN+1];
    char sBuffer[100];

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Queue Summary\n");
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
           "+First unused item = %d\n", gnUnusedHeader);

    if (gnQueueHeader != NULL0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
               "+Header = %d time = %d\n", gnQueueHeader, glHeadTime);

        i = gnQueueHeader;
        for (;;)    
        { 
            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
                    "--%03d->%-3d lRtnMsgType=%8d TimeLeft=[%2d] ", 
                        i, gpToQueue[i].nAhead, 
                        gpToQueue[i].lRtnMsgType, 
                        gpToQueue[i].lTimeLeft);
            
            memcpy(szTemp, gpToQueue[i].pSSN, F011_LEN);
            szTemp[F011_LEN]=0;

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
                    "SSN = %s", szTemp);
            
            memcpy(szTemp, gpToQueue[i].sSrvId, SRV_ID_LEN);
            szTemp[SRV_ID_LEN]=0;

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
                   "sSrvId=%s ", szTemp);
            
            memcpy(szTemp, gpToQueue[i].sTxnDate, F007_LEN);
            szTemp[F007_LEN]=0;

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
                   "sTxnDate = %s ", szTemp);
            
            memcpy(szTemp, gpToQueue[i].sToReserved, TO_RESERVED_LEN);
            szTemp[TO_RESERVED_LEN]=0;
            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
                   "sToReserved = %s\n", szTemp);
            
            if (i == gnQueueTailer) 
                break;
            i = gpToQueue[i].nAhead;
        }

        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
               "+Tailer = %d    time = %d\n", gnQueueTailer, glTailTime);
    }
    else
    {
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "+Queue is Empty\n");
    }

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
}

void CalcTimeElapsed()
{
    char  sFuncName[] = "CalcTimeElapsed";
    long  lTempTime;
    long  diff;

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);

    time(&lTempTime);
    diff = lTempTime - glHeadTime;
    if (gnQueueHeader!=NULL0)
    {
        if (gpToQueue[gnQueueHeader].lTimeLeft > diff)
        {
            gpToQueue[gnQueueHeader].lTimeLeft -= diff;
            /* why not alarm (0) here ??? */
        }
        else
        {
            gpToQueue[gnQueueHeader].lTimeLeft = 0;
            alarm(0);
            ToRelease();
        }
    }
    glHeadTime=lTempTime;
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
}

void ToRelease()
{
    char    sFuncName[] = "ToRelease";
    short   nFirst, nLast;
    
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);

    if (gnQueueHeader == NULL0) 
    {
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
        return;
    }

    nFirst = gnQueueHeader;
    while (gnQueueHeader != NULL0 && gpToQueue[gnQueueHeader].lTimeLeft == 0)
    {
        nLast = gnQueueHeader;
        gnQueueHeader = gpToQueue[gnQueueHeader].nAhead;
    }

    if (gnQueueHeader == NULL0) gnQueueTailer = NULL0;

    gpToQueue[nLast].nAhead = NULL0;
    HandleToTrans(nFirst);

    gpToQueue[nLast].nAhead = gnUnusedHeader;
    gnUnusedHeader = nFirst;
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
}

void HandleToTrans(short nFirst)
{
    char            sFuncName[] = "HandleToTrans";
    char            sSysSeqNum[F011_LEN+1];
    char            sTempSrvId[SRV_ID_LEN+1];
    short           nItem;
    int             nReturnCode;
    T_SwtToReqDef   tSwtToReply;

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);

    if (nFirst == NULL0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
        return;
    }
    
    nItem = nFirst;

    /* for each time out item, send time out msg to request server */
    for(;;)
    {
        memset(sSysSeqNum, 0x00, sizeof (sSysSeqNum));
        memcpy(sSysSeqNum, gpToQueue[nItem].pSSN, F011_LEN);
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
                "%d is TO trans, SSN is %s.", nItem, sSysSeqNum);

        /* get item info */
        memset((char *)&tSwtToReply, 0, sizeof (tSwtToReply));
        memcpy(tSwtToReply.sSrcSrvId, SRV_ID_TOCTL, SRV_ID_LEN);
        memcpy(tSwtToReply.sSrvId, gpToQueue[nItem].sSrvId, SRV_ID_LEN);
        memset(sTempSrvId, 0, sizeof (sTempSrvId));
        memcpy(sTempSrvId, gpToQueue[nItem].sSrvId, SRV_ID_LEN);
        tSwtToReply.lRtnMsgType = gpToQueue[nItem].lRtnMsgType;
        tSwtToReply.nReplyCode = TOCTL_REPLY_CODE_HAD_TO;
        memcpy(tSwtToReply.sTxnDate, gpToQueue[nItem].sTxnDate, F007_LEN);
        memcpy(tSwtToReply.sSysSeqNum, gpToQueue[nItem].pSSN, F011_LEN);
        memcpy(tSwtToReply.sToReserved, gpToQueue[nItem].sToReserved, TO_RESERVED_LEN);

        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__,
               "send time out to %s.", sTempSrvId);
        HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
                       (char *)&tSwtToReply, sizeof (tSwtToReply));
    
        /* send reply */
        nReturnCode = MsqSnd(tSwtToReply.sSrvId, gatSrvMsq, 0, sizeof (tSwtToReply), (char *)&tSwtToReply);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "msgsnd error, %d.", nReturnCode);

        if(gpToQueue[nItem].nAhead != NULL0)
        {
            nItem = gpToQueue[nItem].nAhead;
        }
        else
            break;
    }

    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
}

void HandleExit(int n)
{
    DbsDisconnect();
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ToCtl exits.");
    exit(1);
}
