/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: ToCtl.c                                                     */
/* DESCRIPTIONS: The time out controller.                                    */
/*****************************************************************************/
/*                               MODIFICATION    LOG                         */
/* DATE           PROGRAMMER      DESCRIPTION                                */
/*****************************************************************************/
#include "ToCtl.h"

char gsSrvId[SRV_ID_LEN+1];
char gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq gatSrvMsq[SRV_MSQ_NUM_MAX];
Tbl_ssn_Def gtTblSsn;

int main(int argc, char **argv)
{
    int              nReturnCode;
    int              nMsgSize;
    T_SwtToReqDef    tSwtToReq;

    nReturnCode = ToCtlInit(argc, argv);
    if (nReturnCode) {
        printf("ToCtl: ToCtlInit error %d\n", nReturnCode);
        return -1;
    }
    
    /* set alarm signal */
    sigset(SIGTERM, HandleExit);

    sighold(SIGTERM);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "ToCtl started.");
    
    /* HANDLE TRANSACTION */
    while (1) {
        /* read msg from queue */
        sigrelse(SIGTERM);
        nMsgSize = sizeof(tSwtToReq);
        nReturnCode = MsqRcv(gsSrvId, gatSrvMsq,  atoi(SRV_ID_TOCTL) * 100 + atoi(gsSrvSeqId), MSQ_RCV_MODE_BLOCK, 
                             &nMsgSize, (char *)&tSwtToReq);
        sighold (SIGTERM);

        if (nReturnCode) {
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR) {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
                      "MsqRcv error, %d.", nReturnCode);
                return;
            }
        } else {
            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, 
                  "received request %d from %s.", tSwtToReq.nTransCode, tSwtToReq.sSrvId);
            HandleRequest(&tSwtToReq);
        }
    }  /* for(;;) */
}

int ToCtlInit(int argc, char **argv)
{
    int             i;
    int             nReturnCode;
    long            lUsageKey;
    Tbl_srv_inf_Def tTblSrvInf;

    /* get server id, arg 1; server seq, arg 2 */
    strcpy(gsSrvId, argv[1]);
    strcpy(gsSrvSeqId, argv[2]);
    
    if (getenv(SRV_USAGE_KEY))
        lUsageKey=atoi (getenv(SRV_USAGE_KEY));
    else
        return -1;

    /* connect to database */
    nReturnCode = DbsConnect();
    if (nReturnCode)
        return (nReturnCode);
    
    /* get log file name from tbl_srv_inf */
    memset((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy(tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
    if (nReturnCode)
        return nReturnCode;
    CommonRTrim(tTblSrvInf.srv_name);
    sprintf(gsLogFile, "%s.%s.log", tTblSrvInf.srv_name, gsSrvSeqId);

    /* set gtTblSsn */
    nReturnCode = DbsSsn(DBS_SELECT, &gtTblSsn);
    if (nReturnCode) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
              "DbsSsn select error, %d.",    nReturnCode);
        DbsDisconnect();
        return nReturnCode;
    }
    
    /* init msg queue */
    memset((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
    nReturnCode = MsqInit(gsSrvId, gatSrvMsq);
    if (nReturnCode) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
              "MsqInit error, %d.", nReturnCode);
        DbsDisconnect();
        return nReturnCode;
    }
        
    return 0;
}

int GetSSN(char* pSSN)
{
    long        lNewSsn;
    static int  nBufCount = 0;
    int         nReturnCode;

    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
          "%s begin.", __FUNCTION__);

    /* calc next ssn value */
    lNewSsn = atol(gtTblSsn.ssn_value);
    if (lNewSsn == atol(gtTblSsn.ssn_max))
        lNewSsn = atol(gtTblSsn.ssn_min);
    else
        lNewSsn++;            
    
    sprintf(gtTblSsn.ssn_value, "%06d", lNewSsn);
    memcpy(pSSN, gtTblSsn.ssn_value, F011_LEN);

    /* check whether reached buf count */
    nBufCount++;
    if (nBufCount >= atoi (gtTblSsn.buf_count)) {
        /* save current ssn value in table tbl_ssn */
        nReturnCode = DbsSsn(DBS_SELECT, &gtTblSsn);
        if (nReturnCode)
            {
            	 nReturnCode = DbsConnect();
               if (nReturnCode)
                  return (nReturnCode);
               nReturnCode = DbsSsn(DBS_SELECT, &gtTblSsn);
            }
        if (nReturnCode) { 
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
                  "DbsSsn DBS_SELECT error, %d.", nReturnCode);
            return nReturnCode;
        }
        HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
              "DbsSsn select success.");
        nBufCount = 0;
    }
    
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
          "%s end.", __FUNCTION__);
    return 0;
}

void HandleRequest(T_SwtToReqDef *pSwtToReq)
{
    int              nReturnCode;
    T_SwtToReqDef    tSwtToReply;     

    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
          "%s begin.", __FUNCTION__);
    HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
                  (char *)pSwtToReq, sizeof (*pSwtToReq));
    
    switch(pSwtToReq->nTransCode) {
        case TOCTL_NORMAL_FIRST:
        case TOCTL_REVERSAL_FIRST:
            /* set reply msg */
            memcpy((char *)&tSwtToReply, (char *)pSwtToReq, sizeof(*pSwtToReq));
            tSwtToReply.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;
            
            nReturnCode = GetSSN(tSwtToReply.sSysSeqNum);
            if (nReturnCode) {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
                      "GetSSN error, %d.", nReturnCode);
                tSwtToReply.nReplyCode = TOCTL_REPLY_CODE_NOT_OK;
            }
            /* send reply */
            nReturnCode = MsqSnd(tSwtToReply.sSrvId, gatSrvMsq, pSwtToReq->lRtnMsgType, 
                                 sizeof (tSwtToReply), (char *)&tSwtToReply);
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
                  "send reply to %4.4s.", tSwtToReply.sSrvId);
            HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
                          (char *)&tSwtToReply, sizeof(tSwtToReply));
            if (nReturnCode)
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "msgsnd error, %d.", nReturnCode);
            break;
        default:
            break;
    }     
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "%s end.", __FUNCTION__);
}

void HandleExit(int n)
{
    DbsDisconnect();
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ToCtl exits.");
    exit(1);
}
