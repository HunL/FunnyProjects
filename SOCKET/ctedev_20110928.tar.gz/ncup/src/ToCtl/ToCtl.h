#ifndef  __TO_CTL_H
#define  __TO_CTL_H

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <memory.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include "SrvDef.h"
#include "SrvParam.h"
#include "MsqOpr.h"
#include "ToOpr.h"
#include "HtLog.h"
#include "IpcInt.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "ErrCode.h"
#include "CstDbsTbl.h"
#include "TxnNum.h"
#include "IpcInt.h"

#define    TO_MAX_ALARM_TIME    999
#define    CST_BANK_TLR_NUM     10000
/* CONST USED IN DATA STRUCTURE */
#define    MAX_TO_QUEUE         700

#define    NULL0                0

/* THE STRUCTURE OF TO QUEUE */
typedef struct tagToQueue
{
    short    nAhead;
    long     lTimeLeft;
    char     sSrvId[SRV_ID_LEN];
    long     lRtnMsgType;
    char     pSSN[F011_LEN];
    char     sTxnDate[F007_LEN];
    char     sToReserved[TO_RESERVED_LEN];
} ToQueueDef;

int     ToCtlInit(int, char **);
void    HandleTickOut(int);
void    HandleRequest(T_SwtToReqDef *);
void    InsertQueue(T_SwtToReqDef *);
void    DebugQueue(void);
void    CalcTimeElapsed(void);
void    ToRelease();
void    HandleToTrans(short);
short   DeleteQueue(T_SwtToReqDef *);
void    HandleExit(int);

#endif
