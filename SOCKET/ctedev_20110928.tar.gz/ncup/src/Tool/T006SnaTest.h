#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/times.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <unistd.h>
#include <stropts.h>
#include <poll.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <math.h>
#include <setjmp.h>

#include <values_c.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "ErrCode.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "IpcInt.h"
#include "TxnNum.h"

#define MAX_BUFSIZE 	8192
#define BUF_SIZE 1800
#define TRUE            1
#define FALSE           0

typedef struct struct_combuf {
    char Text[MAX_BUFSIZE];
    long iTotal;
} struct_comblk;

struct_comblk ComBlock;
