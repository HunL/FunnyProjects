/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: T006SnaTest.c		     									 */
/* DESCRIPTIONS: SNA                                                         */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include "T006SnaTest.h"

char 				CICSCode[5];
int					nReturnCode;

void DebugString( char *psBuf, int iLength, int iLine)
{
   int i,j=0;
   char s[100], temp[5];

   printf( "Debug Information from Line: %04d\n", iLine);

   for (i=0; i<iLength; i++)
   {
      if (j==0)
      {
         memset( s, ' ', 84);
         sprintf(temp,   " %03d:",i );
         memcpy( s, temp, 5);
         sprintf(temp,   ":%03d",i+15 );
         memcpy( &s[72], temp, 4);
      }
      sprintf( temp, "%02X ", (unsigned char)psBuf[i]);
      memcpy( &s[j*3+5+(j>7)], temp, 3);
      if ( isprint( psBuf[i]))
      {
         s[j+55+(j>7)]=psBuf[i];
      }
      else
      {
         s[j+55+(j>7)]='.';
      }
      j++;
      if ( j==16)
      {
         s[76]=0;
         printf( "%s\n", s);
         j=0;
      }
   }
   if ( j)
   {
      s[76]=0;
      printf( "%s\n", s);
   }
}

void main(short	argc, char **argv)
{
	int		iPos;

	memset(CICSCode,0,sizeof(CICSCode));
	memcpy(CICSCode,"PEEC", 4);

	iPos = 0;
	memset(&ComBlock, 0, sizeof(ComBlock));
	memcpy(&ComBlock.Text[iPos], "PEEC921800921800       EV99906301542049884 EEV0BB1T00", 53);
	iPos += 53;
	memset(&ComBlock.Text[iPos], ' ', 123); 
	iPos += 123;
	memcpy(&ComBlock.Text[iPos], "36222600110002408610CNY0A78BCEEA718E12821600", 44); 
	iPos += 44;
	memset(&ComBlock.Text[iPos], ' ', 141); 
	iPos += 141;
	memcpy(&ComBlock.Text[iPos], "NET12345", 8); 
	iPos += 8;
	memcpy(&ComBlock.Text[iPos], "9902014305099020010000", 22); 
	iPos += 22;
	memset(&ComBlock.Text[iPos], ' ', 24); 
	iPos += 24;
	ComBlock.Text[iPos] = '\x02';
	iPos += 1;

	ComBlock.iTotal = iPos;

	DebugString((char *)ComBlock.Text, ComBlock.iTotal, __LINE__);

	nReturnCode = rl_SendToHostByAppc(ComBlock.Text, ComBlock.iTotal,
							CICSCode, ComBlock.Text, &ComBlock.iTotal);

	printf("nReturnCode = %d\n", nReturnCode);
	if(!nReturnCode)
	{
		DebugString((char *)ComBlock.Text, ComBlock.iTotal, __LINE__);
	}
}
