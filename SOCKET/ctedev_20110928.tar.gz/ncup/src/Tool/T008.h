#ifndef __BRIDGE_H
#define __BRIDGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <memory.h>
#include <signal.h>
#include <ctype.h>
#include <errno.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "TxnNum.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "CvtOpr.h"
#include "Convert.h"

typedef struct {
	char	sa_usage_key[9];
    char	sa_term_id[24];
    char	sa_uniq_term_id[9];
    char	sa_jcb_mcht_id[16];
    char	sa_sav1[51];
	char	sa_snd[51];
	char	sa_comm[6];
	char	sa_term_lock[5];
	char	sa_term_stat[5];
	char	sa_slmt_disc[5];
	char	sa_fwd_ins1[5];
	char	sa_fwd_ins2[5];
	char	sa_batch_num[7];
    char	sa_passwd_1[9];
    char	sa_passwd_2[9];
	char	sa_rsvd1[256];
	char	sa_rsvd2[256];
	char	sa_rsvd3[256];
	char	sa_rsvd4[256];
    char	sa_term_type[3];
	char	state[2];
	char	statetime[9];
	char	mcc[5];
	char	tcc[5];
	char	crtperson[11];
	char	modperson[11];
	char	l_rec_updt_usr_id[9];
    char	tm_rec_updt_time[30];
    char	tm_rec_crt_time[30];
} AtmLsDef;

#endif
