#ifndef __BRIDGE_H
#define __BRIDGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <memory.h>
#include <signal.h>
#include <ctype.h>
#include <errno.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "TxnNum.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "CvtOpr.h"
#include "Convert.h"

typedef	struct {
	char	sd_bankid[12];
	char	fk_bankid[12];
	char	source_bankid[12];
	char	target_bankid[12];
	char	equip_date[11];
	char	equip_time[9];
	char	terminal_id[9];
	char	merchant_id[16];
	char	card_no[20];
	char	expire[5];
	char	card_type[3];
	char	trace[7];
	char	invoice[7];
	char	authno[7];
	char	amount[14];
} PosLsDef;

#endif
