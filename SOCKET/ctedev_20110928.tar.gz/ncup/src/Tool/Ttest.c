#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include "HtLog.h"

int main()
{
	int rc = 0;
	struct timeval tv;

	while (1)
	{
		tv.tv_sec = 1;
		tv.tv_usec = 1;
		rc = select(0, NULL, NULL, NULL, &tv);
		HtLog("lfg.log", 3, __FILE__, __LINE__, "test");
	}
	return 0;
} 
