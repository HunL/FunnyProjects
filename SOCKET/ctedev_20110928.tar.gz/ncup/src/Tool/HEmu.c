/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: HEmu.c   			     									 */
/* DESCRIPTIONS: Host Emu                                                    */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include "HEmu.h"

char				gsSrvId[SRV_ID_LEN+1];
char				gsToSrvId[SRV_ID_LEN+1];
char				gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char				gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];

char				gsIpAddr[20];
int					gnPort;
int					gnSocketID;
int					gnTimeOut;
int					gnSysError = 0;

char 				CICSCode[5];

int CommInit (short argc, char **argv);
void HandleExit (int n);

void main(short	argc, char **argv)
{
	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	char	sIntMsgBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	char	sSrcSrvId[SRV_ID_LEN+1];
	char	sTxnNum[FLD_TXN_NUM_LEN+1],sTxnNumErr[FLD_TXN_NUM_LEN+1];
	char	sRespCode[F039_LEN+1];
	char	sKeyRsp[KEY_RSP_LEN+1];
	int		nReturnCode;
	int 	nMsgInLen;
	int		nIntMsgLen;
	int		nMsgOutLen;

	if(argc < 4)
	{
		printf("Usage:%s srvid seq tosrvid\n", argv[0]);
		exit(-1);
	}

	nReturnCode = CommInit (argc, argv);
	if (nReturnCode)
	{
		printf("CommInit error[%d] LINE[%d] FILE[%s]\n",nReturnCode,__LINE__,__FILE__);
		exit(-2);
	}

	if (sigset(SIGTERM, HandleExit) == SIG_ERR)
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s started", argv[0]);

	while (1)
	{
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "while in");
		memset(sMsgInBuf,0,sizeof(sMsgInBuf));
		nMsgInLen = MSQ_MSG_SIZE_MAX;
		sigrelse (SIGTERM);
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "MsqRcv  started");
		nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, 
								&nMsgInLen, sMsgInBuf);
	        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "MsqRcv  ended");
		sighold (SIGTERM);
		if (nReturnCode)
		{
			if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"MsqRcv error, %d", nReturnCode);
				exit(-3);
			}
			else
				continue;
		}

		memset (sSrcSrvId, 0, sizeof (sSrcSrvId));
		memcpy (sSrcSrvId, sMsgInBuf, SRV_ID_LEN);

		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"received %d byte msg from %s", nMsgInLen, sSrcSrvId);

		HtWriteLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sMsgInBuf, nMsgInLen);

		memset(sKeyRsp,0,sizeof(sKeyRsp));
		memcpy(sKeyRsp,sMsgInBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN,KEY_RSP_LEN);

		memset(sTxnNum,0,sizeof(sTxnNum));
		memcpy(sTxnNum,sMsgInBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+KEY_RSP_LEN,FLD_TXN_NUM_LEN);
		memset(sTxnNumErr,0,sizeof(sTxnNumErr));
		memcpy(sTxnNumErr,sTxnNum,FLD_TXN_NUM_LEN);

		memset(&ComBlock, 0, sizeof(ComBlock));

		if(memcmp(sTxnNum, "1023", 4) == 0)
		{
			ComBlock.iTotal = 373; 
			memset(ComBlock.Text, '0', 373);
		}
		else if(memcmp(sTxnNum, "1073", 4) == 0)
		{
			ComBlock.iTotal = 224; 
			memset(ComBlock.Text, '0', 224);
		}
		else if(memcmp(sTxnNum, "1013", 4) == 0)
		{
			ComBlock.iTotal = 222; 
			memset(ComBlock.Text, '0', 222);
		}
		else if(memcmp(sTxnNum, "1103", 4) == 0)
		{
			ComBlock.iTotal = 206; 
			memset(ComBlock.Text, '0', 206);
		}
		else if(memcmp(sTxnNum, "1101", 4) == 0)
		{
			ComBlock.iTotal = 286; 
			memset(ComBlock.Text, '0', 286);
		}
		else if(memcmp(sTxnNum, "2101", 4) == 0)
		{
			ComBlock.iTotal = 221; 
			memset(ComBlock.Text, '0', 221);
		}
		else if(memcmp(sTxnNum, "3101", 4) == 0)
		{
			ComBlock.iTotal = 286; 
			memset(ComBlock.Text, '0', 286);
		}
		else if(memcmp(sTxnNum, "4101", 4) == 0)
		{
			ComBlock.iTotal = 221; 
			memset(ComBlock.Text, '0', 221);
		}
		else if(memcmp(sTxnNum, "1011", 4) == 0)
		{
			ComBlock.iTotal = 304; 
			memset(ComBlock.Text, '0', 304);
		}
		else if(memcmp(sTxnNum, "3011", 4) == 0)
		{
			ComBlock.iTotal = 286; 
			memset(ComBlock.Text, '0', 286);
		}
		else if(memcmp(sTxnNum, "1091", 4) == 0)
		{
			ComBlock.iTotal = 286; 
			memset(ComBlock.Text, '0', 286);
		}
		else if(memcmp(sTxnNum, "3091", 4) == 0)
		{
			ComBlock.iTotal = 275; 
			memset(ComBlock.Text, '0', 275);
		}
		else if(memcmp(sTxnNum, "4091", 4) == 0)
		{
			ComBlock.iTotal = 221; 
			memset(ComBlock.Text, '0', 221);
		}
		else if(memcmp(sTxnNum, "2011", 4) == 0)
		{
			ComBlock.iTotal = 200; 
			memset(ComBlock.Text, '0', 200);
		}
		else if(memcmp(sTxnNum, "4011", 4) == 0)
		{
			ComBlock.iTotal = 196; 
			memset(ComBlock.Text, '0', 196);
		}
		else if(memcmp(sTxnNum, "2091", 4) == 0)
		{
			ComBlock.iTotal = 221; 
			memset(ComBlock.Text, '0', 221);
		}
		else
		{
			ComBlock.iTotal = 0; 
		}
   
		if(ComBlock.iTotal == 0)
		{
			memcpy(sRespCode,"06",F039_LEN);
			sTxnNum[3]++;
			memcpy(sTxnNumErr, "ERR1", FLD_TXN_NUM_LEN);
		}
		
		else
		{
			memcpy(sRespCode,"00",F039_LEN);
			sTxnNum[3]++;
			sTxnNumErr[3]++;
		}

		/********************************************************** 
		��Ҫ�������ױ��ĸ�ֵ��Ӧ���ױ��ĵĽ�β,����ֵӦ����F039
		***********************************************************/
		memset(	sMsgOutBuf, 0, sizeof(sMsgOutBuf));
		memcpy(	sMsgOutBuf, gsSrvId, SRV_ID_LEN);
		memcpy(	sMsgOutBuf+SRV_ID_LEN, gsToSrvId, SRV_ID_LEN);
		memset(	sMsgOutBuf+SRV_ID_LEN*2, ' ', FLD_MSQ_TYPE_LEN);
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN, sTxnNumErr, FLD_TXN_NUM_LEN); 
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TXN_NUM_LEN, sTxnNum, FLD_TXN_NUM_LEN); 
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TXN_NUM_LEN*2, sKeyRsp, KEY_RSP_LEN); 
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TXN_NUM_LEN*2+KEY_RSP_LEN, sRespCode, F039_LEN); 
		if(ComBlock.iTotal)
		{
			memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TXN_NUM_LEN*2+KEY_RSP_LEN+F039_LEN, ComBlock.Text, ComBlock.iTotal);
		}
		nMsgOutLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TXN_NUM_LEN*2+KEY_RSP_LEN+F039_LEN+ComBlock.iTotal;

		nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, nMsgOutLen, sMsgOutBuf);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"MsqSnd to %s error, %d", gsToSrvId, nReturnCode);
			continue;
		}
		
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"send msg to %s", gsToSrvId);
	}
}

/*****************************************************************************/
/* FUNC:   int CommInit (short argc, char **argv)                            */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �������ݿ�, ����ȫ�ֱ���, ��ȡ���в���,                           */
/*         ��ʼ����Ϣ����                                                    */
/*****************************************************************************/
int CommInit (short argc, char **argv)
{
	int				i;
	int				nReturnCode;
	Tbl_srv_inf_Def	tTblSrvInf;
    char			*lspTmp;
	int				lUsageKey;

	/* get server id arg 1; server seq arg 2; to server id arg 3 */
	strcpy(gsSrvId, argv[1]);
	strcpy(gsSrvSeqId, argv[2]);
	strcpy(gsToSrvId, argv[3]);

	/* connect to database */
    nReturnCode = DbsConnect ();
	if (nReturnCode) return (nReturnCode);
	
	if (getenv("DESTNAME") == NULL)
		return -1;

	/* get log file name from tbl_srv_inf */
	if (getenv(SRV_USAGE_KEY))
		lUsageKey=atoi (getenv(SRV_USAGE_KEY));
	else
		return -2;

	memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
	tTblSrvInf.usage_key = lUsageKey;
	memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
	nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
	if (nReturnCode)
		return (nReturnCode);

	sprintf (gsLogFile, "%s.%s", tTblSrvInf.srv_id, gsSrvSeqId);
	sprintf (gsLogFile, "%s.log", gsLogFile);

	/* init msg queue */
	memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
	nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d", nReturnCode);	  
		return (nReturnCode);
	}

	if (getenv("TL_COMM_TIME_OUT"))
		gnTimeOut = atoi (getenv("TL_COMM_TIME_OUT"));
	else
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"getenv(TL_COMM_TIME_OUT) error");
		return -1;
	}

	/* disconnect db */
	nReturnCode = DbsDisconnect ();
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"DbsDisconnect error, %d", nReturnCode);	  
	}
	return (0);
}

void HandleExit (int n)
{
	HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "exits");
	exit( 1 );
}
