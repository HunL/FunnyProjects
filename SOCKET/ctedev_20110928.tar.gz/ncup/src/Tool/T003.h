
/*==========================================================================*

	FILE		  		msq.h

	TARGET			UNIX message queue programming support

	HISTORY			DATE			DESCRIPTION
	~~~~~~~			~~~~			~~~~~~~~~~~
	Ray Hawkins		06/20/96		Initial version

*==========================================================================*/

#ifndef	_MSQ_H
#define	_MSQ_H

/* HEADER FILE(S) */

#include	<stdio.h>
#include	<stdlib.h>
#include	<sys/types.h>
#include	<sys/ipc.h>
#include	<sys/msg.h>
#include	<pwd.h>
#include	<grp.h>
#include	<memory.h>
#include	<string.h>
#include	<errno.h>

/* GLOBAL DEFINE(S) */

#define	C_MsqR			0400 /* msg queue read */
#define	C_MsqW			0200 /* msg queue write */
#define	C_MsqRW			0600 /* msg queue read & write */
#define	C_MsqAny			0000 /* msg queue no read or write */

#define	C_MsqPerm		((mode_t) 0777) /* queue permission */

#define	C_MsqAnyT		0 /* of any message type: for MsqRecv() */
#define	C_MsqNone		-1 /* param not used: for MsqChown() */
#define	C_MsqAll			-1 /* dump all message: for MsqDump() */

#define	C_MsgbufS		1024 /* mtext size small */
#define	C_MsgbufM		2048 /* mtext size medium */
#define	C_MsgbufL		8192 /* mtext size large */

#define	C_MsgErr			-1 /* msg error */
#define	C_MsgEnd			-2 /* msg data end */
#define	C_MsgEOF			-3 /* msg data file EOF */
#define	C_MsgOVF			-4 /* msgbuf overflow */

#define	C_MsgCheck		1 /* check msg data */
#define	C_MsgNoCheck	0 /* do not check msg data */

/* TYPE DEFINITION(S) */

typedef struct TAG_Msgbuf {
	long mtype; /* message type */
	char mtext[1]; /* message text */
	} T_Msgbuf; /* message buffer template */

typedef struct TAG_MsgbufS {
	long mtype; /* message type */
	char mtext[C_MsgbufS]; /* message text small */
	} T_MsgbufS; /* small message */

typedef struct TAG_MsgbufM {
	long mtype; /* message type */
	char mtext[C_MsgbufM]; /* message text medium */
	} T_MsgbufM; /* medium message */

typedef struct TAG_MsgbufL {
	long mtype; /* message type */
	char mtext[C_MsgbufL]; /* message text large */
	} T_MsgbufL; /* large message */

/* FUNCTION PROTOTYPE(S) */

void DumpC (FILE *fp, const char *buf, size_t nbytes);
void MsgbufDump (FILE *fp, T_Msgbuf *pmsg, size_t nbytes);
int MsgbufInput (FILE *fp, T_Msgbuf *pmsg, size_t msgsz, int flag);

int MsqCreate (key_t key, mode_t mode);
int MsqCreateExcl (key_t key, mode_t mode);
int MsqGet (key_t key, mode_t mode);

int MsqClose (int msqid);
int MsqCount (int msqid);
int MsqClear (int msqid);
int MsqChown (int msqid, uid_t uid, gid_t gid);
int MsqChmod (int msqid, mode_t mode);
int MsqInfo (int msqid, struct msqid_ds *pqds);

int MsqSend (int msqid, T_Msgbuf *pmsg, size_t nbytes);
int MsqSendType (int msqid, T_Msgbuf *pmsg, size_t nbytes, long mtype);
int MsqRecv (int msqid, T_Msgbuf *pmsg, size_t nbytes);
int MsqRecvType (int msqid, T_Msgbuf *pmsg, size_t nbytes, long mtype);

int MsqDump (FILE *fp, int msqid, int count);
int MsqWrite (FILE *fp, int msqid, int flag);

#endif /* _MSQ_H */
