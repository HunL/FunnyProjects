/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: T001.c         					     */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include "T001.h"
#include "HtLog.h"

TransRuleInfDef 	tTransRule;
long			lUsageKey;

static unsigned char SAEbcdicAscii[256] =
{0x00, 0x01, 0x02, 0x03, 0x9C, 0x09, 0x86, 0x7F,
	0x97, 0x8D, 0x8E, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
	0x10, 0x11, 0x12, 0x13, 0x9D, 0x85, 0x08, 0x87,
	0x18, 0x19, 0x92, 0x8F, 0x1C, 0x1D, 0x1E, 0x1F,
	0x80, 0x81, 0x82, 0x83, 0x84, 0x0A, 0x17, 0x1B,
	0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x05, 0x06, 0x07,
	0x90, 0x91, 0x16, 0x93, 0x94, 0x95, 0x96, 0x04,
	0x98, 0x99, 0x9A, 0x9B, 0x14, 0x15, 0x9E, 0x1A,
	0x20, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
	0xA7, 0xA8, 0x5B, 0x2E, 0x3C, 0x28, 0x2B, 0x21,
	0x26, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
	0xB0, 0xB1, 0x5D, 0x24, 0x2A, 0x29, 0x3B, 0x5E,
	0x2D, 0x2F, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
	0xB8, 0xB9, 0x7C, 0x2C, 0x25, 0x5F, 0x3E, 0x3F,
	0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF, 0xC0, 0xC1,
	0xC2, 0x60, 0x3A, 0x23, 0x40, 0x27, 0x3D, 0x22,
	0xC3, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
	0x68, 0x69, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9,
	0xCA, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70,
	0x71, 0x72, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xD0,
	0xD1, 0x7E, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
	0x79, 0x7A, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7,
	0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
	0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
	0x7B, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
	0x48, 0x49, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED,
	0x7D, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50,
	0x51, 0x52, 0xEE, 0xEF, 0xF0, 0xF1, 0xF2, 0xF3,
	0x5C, 0x9F, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
	0x59, 0x5A, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9,
	0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
	0x38, 0x39, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF};

static unsigned char SAAsciiEbcdic[256] =
{    0x00, 0x01, 0x02, 0x03, 0x37, 0x2D, 0x2E, 0x2F,
	0x16, 0x05, 0x25, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
	0x10, 0x11, 0x12, 0x13, 0x3C, 0x3D, 0x32, 0x26,
	0x18, 0x19, 0x3F, 0x27, 0x1C, 0x1D, 0x1E, 0x1F,
	0x40, 0x4F, 0x7F, 0x7B, 0x5B, 0x6C, 0x50, 0x7D,
	0x4D, 0x5D, 0x5C, 0x4E, 0x6B, 0x60, 0x4B, 0x61,
	0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
	0xF8, 0xF9, 0x7A, 0x5E, 0x4C, 0x7E, 0x6E, 0x6F,
	0x7C, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7,
	0xC8, 0xC9, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6,
	0xD7, 0xD8, 0xD9, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6,
	0xE7, 0xE8, 0xE9, 0x4A, 0xE0, 0x5A, 0x5F, 0x6D,
	0x79, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
	0x88, 0x89, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96,
	0x97, 0x98, 0x99, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
	0xA7, 0xA8, 0xA9, 0xC0, 0x6A, 0xD0, 0xA1, 0x07,
	0x20, 0x21, 0x22, 0x23, 0x24, 0x15, 0x06, 0x17,
	0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x09, 0x0A, 0x1B,
	0x30, 0x31, 0x1A, 0x33, 0x34, 0x35, 0x36, 0x08,
	0x38, 0x39, 0x3A, 0x3B, 0x04, 0x14, 0x3E, 0xE1,
	0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
	0x49, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
	0x58, 0x59, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
	0x68, 0x69, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75,
	0x76, 0x77, 0x78, 0x80, 0x8A, 0x8B, 0x8C, 0x8D,
	0x8E, 0x8F, 0x90, 0x9A, 0x9B, 0x9C, 0x9D, 0x9E,
	0x9F, 0xA0, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
	0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
	0xB8, 0xB9, 0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF,
	0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xDA, 0xDB,
	0xDC, 0xDD, 0xDE, 0xDF, 0xEA, 0xEB, 0xEC, 0xED,
	0xEE, 0xEF, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF};

short ConvInit( long, long, long, long, long, TransRuleInfDef* );
short ConvOutToIn( void*, short, short, short, TransRuleInfDef*, void*, short*);
void DebugString(char *, int);
int T001Init (short argc, char **argv);
short nMFormatChk(
		unsigned char* vspMsg,
		short          vnMsgL,
		short          vnMsgType);

int main(short	argc, char **argv)
{
	FILE	*fp;
	char	*sFileName = NULL;
	int	opt;
	char	*sValue = NULL;
	int	iRuleFlag = 0;
	int	iMatchFlag = 0;
	char    sTemp[100];

	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgInBuf1[MSQ_MSG_SIZE_MAX];
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	int 	nMsgInLen;
	short	nMsgOutLen;
	long	lCnt=0;

	char	sLogTime[24];
	char	sReadLen[5];

	int	lDebugFlag = 0, lErrorFlag;

	char	sLine[80];

	int	nReturnCode;

	char	sMatchDataIn[100],sMatchDataOut[100];
	int	lMatchLen = 0;
	int	liPos,liPosIn=0,liPosOut=0;
	int	iFlag = 0;
	FILE   *fptmp;
	int	i;

	setbuf(stdout,NULL);

	memset(sLine, '-', sizeof(sLine));

	if(argc < 2)
	{
		printf("Usage:%s :\n", argv[0]);
		printf("\t-f �ļ���\n");
		printf("\t-r ת������-1601:���� 1801:����STEPS 1899:���� 0:POS\n");
		printf("\t            1602:VSA 1603:VSP 1604:MTA 1605:MTP 1606:JCB 1610:AMX POS\n");
		printf("\t-d :���Ĵ�ӡ��־\n");
		printf("\t-m ��������\n");
		exit(-1);
	}

	while((opt = getopt(argc,argv,":f:r:dm:")) != -1)
	{
		switch(opt)
		{
			case 'f':
				sFileName = optarg;
				break;
			case 'r':
				sValue = optarg;
				iRuleFlag = 1;
				break;
			case 'd':
				lDebugFlag = 1;
				break;
			case 'm':
				strcpy(sMatchDataIn,optarg);
				lMatchLen = strlen(sMatchDataIn);
				iMatchFlag = 1;
				break;
			case ':':
				printf("'-%c' missing option argument.\n",optopt);
				exit(-1);
			case '?':
				printf("Unknown option '-%c'.\n",optopt);
				exit(-1);
		}
	}

	for(i = optind; i < argc; i++)
	{
		printf("Non-option argument: %s \n",argv[i]);
		exit(-1);
	}

	if( iRuleFlag == 1)
	{
		memset(sTemp, 0, sizeof(sTemp));
		strcpy(sTemp,sValue);
		lUsageKey = atoi (sTemp);
	}
	else
	{
		if(memcmp(sFileName,"1801",4) == 0 ||
		    memcmp(sFileName,"1802",4) == 0 ||
		    memcmp(sFileName,"1811",4) == 0)
		{
			lUsageKey = 2;
		}
		if(memcmp(sFileName,"1899",4) == 0)
		{
			lUsageKey = 1899;
		}
		else if (memcmp(sFileName,"1601",4) == 0)
		{
			lUsageKey = 0;
		}
		else if (memcmp(sFileName,"1602",4) == 0)
		{
			lUsageKey = 0;
		}
		else if (memcmp(sFileName,"1611",4) == 0)
		{
			lUsageKey = 4;
		}
		else if (memcmp(sFileName,"1612",4) == 0)
		{
			lUsageKey = 4;
		}
		else if (memcmp(sFileName,"1604",4) == 0)
		{
			lUsageKey = 1604;
		}
		else if (memcmp(sFileName,"1605",4) == 0)
		{
			lUsageKey = 1605;
		}
		else if (memcmp(sFileName,"1610",4) == 0)
		{
			lUsageKey = 1610;
		}
		else if (memcmp(sFileName,"2901",4) == 0)
		{
			lUsageKey = 2900;
		}
		else if (memcmp(sFileName,"2902",4) == 0)
		{
			lUsageKey = 2900;
		}
		else
		{
		}
	}


	if((fp = fopen(sFileName,"r")) == NULL)
	{
		printf("fail to open file %s\n", sFileName);
		exit(-2);
	}

	nReturnCode = T001Init (argc, argv);
	if (nReturnCode)
	{
		printf("T001: T001Init error[%d]",nReturnCode);
		exit(-2);
	}

	while(!feof(fp))
	{
		/*������־��23λʱ�䣬����ȡ��4λ����*/
		memset(sLogTime, 0, sizeof(sLogTime));
		memset(sReadLen, 0, sizeof(sReadLen));
		fread(sLogTime,23,1,fp);
		fread(sReadLen,4,1,fp);
		nMsgInLen = atoi(sReadLen);
		if(nMsgInLen <=0 ) continue;

		/*��ȡ��������*/
		memset(sMsgInBuf,0,sizeof(sMsgInBuf));
		memset(sMsgInBuf1,0,sizeof(sMsgInBuf1));

		fread(sMsgInBuf, nMsgInLen, 1, fp);
		memcpy(sMsgInBuf1, sMsgInBuf, nMsgInLen);
		EncodeNull (sMsgInBuf1, nMsgInLen);
		/*��ʼ���ļ�ָ��tmp*/
		if((fptmp = fopen(sFileName,"r+")) == NULL)
	  {
		printf("fail to open file %s\n", sFileName);
		exit(-2);
	  }


		if(iMatchFlag == 1 )
		{
			/*ascii*/
			memset(sMatchDataOut, 0, sizeof(sMatchDataOut));
			strcpy(sMatchDataOut, sMatchDataIn);
			liPosOut = lMatchLen;
			if(strstr(sMsgInBuf1, sMatchDataOut) == 0)
				iFlag = 0;
			else
				iFlag = 1;

			/*��BCD*/
			if(iFlag == 0)
			{
				liPosIn=0;
				liPosOut=0;
				memset(sMatchDataOut, 0, sizeof(sMatchDataOut));
				for(liPos = 0; liPos < lMatchLen; liPos++)
				{
					if(liPos % 2)
						sMatchDataOut[liPosOut++] += (sMatchDataIn[liPosIn++] - '0');
					else
						sMatchDataOut[liPosOut] = (sMatchDataIn[liPosIn++] - '0') * 0x10;
				}
				if(strstr(sMsgInBuf1, sMatchDataOut) == 0)
					iFlag = 0;
				else
					iFlag = 1;
			}

			/*�ҿ�BCD*/
			if(iFlag == 0)
			{
				liPosIn=0;
				liPosOut=0;
				memset(sMatchDataOut, 0, sizeof(sMatchDataOut));
				for(liPos = 0; liPos < lMatchLen; liPos++)
				{
					if(liPos % 2)
						sMatchDataOut[liPosOut++] += (sMatchDataIn[liPosIn++] - '0');
					else
						sMatchDataOut[liPosOut] = (sMatchDataIn[liPosIn++] - '0') * 0x10;
				}
				if(strstr(sMsgInBuf1, sMatchDataOut) == 0)
					iFlag = 0;
				else
					iFlag = 1;
			}

			/*EBCD*/
			if(iFlag == 0)
			{
				memset(sMatchDataOut, 0, sizeof(sMatchDataOut));
				for(liPos = 0; liPos < lMatchLen; liPos++)
					sMatchDataOut[liPos] = SAAsciiEbcdic[(unsigned char)sMatchDataIn[liPos]];

				if(strstr(sMsgInBuf1, sMatchDataOut) == 0)
					iFlag = 0;
				else
					iFlag = 1;
			}
		}

		if( iMatchFlag == 1 && iFlag == 0)
		{
			fread(sReadLen,1,1,fp);
			continue;
		}

		memset (sMsgOutBuf, 0, MSQ_MSG_SIZE_MAX);
		nMsgOutLen = MSQ_MSG_SIZE_MAX;

		printf("%37.37s%06d%37.37s\n", sLine, lCnt, sLine);
		printf("DATE [%23.23s]\n", sLogTime);
		printf("%80.80s\n", sLine);

		lErrorFlag = 0;
		nReturnCode = ConvOutToIn(sMsgInBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,
				nMsgInLen-SRV_ID_LEN*2-FLD_MSQ_TYPE_LEN-FLD_TIME_STAMP_LEN-FLD_GF_HEADER,
				0,
				0,
				&tTransRule,
				(unsigned char *)sMsgOutBuf,
				&nMsgOutLen);
		if(nReturnCode)
		{
			lErrorFlag = 1;
			printf("ConvOutToIn error [%d]\n", nReturnCode);
			DebugString( sMsgInBuf, nMsgInLen );
		}
		if(lDebugFlag && !lErrorFlag)
		{
			printf("%80.80s\n", sLine);
			DebugString( sMsgInBuf, nMsgInLen );
		}
		printf("%37.37s%06d%37.37s\n\n", sLine, lCnt++, sLine);

		fread(sReadLen,1,1,fp);
	}
	return 0;
}

/*****************************************************************************/
/* FUNC:   int T001Init (short argc, char **argv)                            */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �������ݿ�, ����ȫ�ֱ���, ��ȡ���в���,                           */
/*         ��ʼ����Ϣ����, �����ݿ��ȡת������������п�������·�ɱ�        */
/*****************************************************************************/
int T001Init (short argc, char **argv)
{
	int				i;
	int				nReturnCode;
	Tbl_srv_inf_Def	tTblSrvInf;
	char			*lspTmp;

	/* connect to database */
	nReturnCode = DbsConnect ();
	if (nReturnCode)
		return (nReturnCode);

	/* init ISO8583 convert rule */
	nReturnCode = ConvInit (lUsageKey, lUsageKey,lUsageKey, lUsageKey, lUsageKey, &tTransRule);
	if (nReturnCode)
	{
		DbsDisconnect ();
		return (nReturnCode);
	}

	/* disconnect db */
	nReturnCode = DbsDisconnect ();
	if (nReturnCode)
	{
		return (nReturnCode);
	}

	return (0);
}

void DebugString( char *psBuf, int iLength )
{
	int i,j=0;
	char s[100], temp[5];

	for (i=0; i<iLength; i++)
	{
		if (j==0)
		{
			memset( s, ' ', 84);
			sprintf(temp,   "%03d:",i );
			memcpy( s, temp, 4);
			sprintf(temp,   ":%03d",i+15 );
			memcpy( &s[72], temp, 4);
		}
		sprintf( temp, "%02X ", (unsigned char)psBuf[i]);
		memcpy( &s[j*3+5+(j>7)], temp, 3);
		if ( isprint( psBuf[i]))
		{
			s[j+55+(j>7)]=psBuf[i];
		}
		else
		{
			s[j+55+(j>7)]='.';
		}
		j++;
		if ( j==16)
		{
			s[76]=0;
			printf( "%s\n", s);
			j=0;
		}
	}
	if (j)
	{
		s[76]=0;
		printf( "%s\n", s);
	}
}


short ConvCutBlankTailLen(unsigned char *vspInputStr, short nMaxLen)
{
	short i;
	short j;

	j = nMaxLen;

	for (i=0; i<= nMaxLen; i++)
	{
		if (vspInputStr[i] == ' ' || vspInputStr[i] == '\0')
		{
			j = i;
			break;
		}
	}

	return j;
}

short nMAsciiHexToBinary(
		unsigned char* vspSourceStr,
		short          vnSourceStrL,
		unsigned char* vspDestStr) {

	if(vnSourceStrL % 2)
		return -1;

	for(; vnSourceStrL > 0; vnSourceStrL -= 2) {
		if(*vspSourceStr >= '0' &&
				*vspSourceStr <= '9')
			*vspDestStr = ((*vspSourceStr++) - '0') * 16;
		else if(*vspSourceStr >= 'a' &&
				*vspSourceStr <= 'f')
			*vspDestStr = ((*vspSourceStr++) - 'a' + 10) * 16;
		else if(*vspSourceStr >= 'A' &&
				*vspSourceStr <= 'F')
			*vspDestStr = ((*vspSourceStr++) - 'A' + 10) * 16;
		else
			return LFail;
		if(*vspSourceStr >= '0' &&
				*vspSourceStr <= '9')
			(*vspDestStr++) += ((*vspSourceStr++) - '0');
		else if(*vspSourceStr >= 'a' &&
				*vspSourceStr <= 'f')
			(*vspDestStr++) += ((*vspSourceStr++) - 'a' + 10);
		else if(*vspSourceStr >= 'A' &&
				*vspSourceStr <= 'F')
			(*vspDestStr++) += ((*vspSourceStr++) - 'A' + 10);
		else
			return -1;
	} /* end of for */

	return 0;
} /* end of nMAsciiHexToBinary */

short nMLoadFldInf(
		long               vlFldInfKey,
		Tbl_fld_inf_Def*   vtpTblFldInf,
		FldRuleInfDef*  vfripFldInf) {

	short   liFldX;

	for(liFldX = 0; liFldX < MAX_FLD_NUM; liFldX++)
		vfripFldInf[liFldX].iBeginPtr = -2;
	vtpTblFldInf->usage_key = vlFldInfKey;
	DbsFLDINF(
			DBS_CURSOR,
			vtpTblFldInf);

	if(DbsFLDINF(
				DBS_OPEN,
				vtpTblFldInf))
		return -1;

	while(DbsFLDINF(
				DBS_FETCH,
				vtpTblFldInf) == 0) {
		if((liFldX = vtpTblFldInf->fld_index) >= MAX_FLD_NUM)
			return -2;
		vfripFldInf[liFldX].iBeginPtr = -1;
		vfripFldInf[liFldX].nFldLenL = vtpTblFldInf->len_len;
		vfripFldInf[liFldX].nDataMaxL = vtpTblFldInf->data_max_len;
		vfripFldInf[liFldX].nLenExpVal = vtpTblFldInf->len_exp_val;
		vfripFldInf[liFldX].nIndSym = vtpTblFldInf->ind_sym;
		vfripFldInf[liFldX].nDataFormat = vtpTblFldInf->data_format;
		vfripFldInf[liFldX].nLenCharSet = vtpTblFldInf->len_char_set;
		vfripFldInf[liFldX].nDataCharSet = vtpTblFldInf->data_char_set;
	} /* end of while */

	if(DbsFLDINF(
				DBS_CLOSE,
				vtpTblFldInf))
		return -3;

	return 0;
} /* end of nMLoadFldInf */

short nMLoadMsgInf(
		long               vlMsgInfKey,
		Tbl_msg_inf_Def*   vtpTblMsgInf,
		short*             vnpMsgNum,
		MsgRuleInfDef*  vmripMsgInf) {

	short   liMsgX;

	*vnpMsgNum = 0;
	vtpTblMsgInf->usage_key = vlMsgInfKey;
	DbsMSGINF(
			DBS_CURSOR,
			vtpTblMsgInf);

	if(DbsMSGINF(
				DBS_OPEN,
				vtpTblMsgInf))
		return -1;

	while((DbsMSGINF(
					DBS_FETCH,
					vtpTblMsgInf) == 0) &&
			((liMsgX = (*vnpMsgNum)++) < MAX_MSG_NUM)) {
		vmripMsgInf[liMsgX].nTxnNumber = vtpTblMsgInf->txn_num;
		vmripMsgInf[liMsgX].iIpcIndex = vtpTblMsgInf->ipc_index;
		vmripMsgInf[liMsgX].iBmpIndex = vtpTblMsgInf->bmp_index;
		vmripMsgInf[liMsgX].iMandBmpIndex = vtpTblMsgInf->mand_bmp_index;
		memcpy(
				vmripMsgInf[liMsgX].saMsgType,
				&vtpTblMsgInf->msg_type[0],
				F000_MSG_TYPE_LEN);
		memcpy(
				vmripMsgInf[liMsgX].saTxnCode,
				&vtpTblMsgInf->txn_code[0],
				F129_TXN_CODE_LEN);
	} /* end of while */

	if(DbsMSGINF(
				DBS_CLOSE,
				vtpTblMsgInf))
		return -2;

	return 0;
} /* end of nMLoadMsgInf */

short nMLoadConInf(
		long               vlConInfKey,
		Tbl_con_inf_Def*   vtpTblConInf,
		short*             vnpConNum,
		ConRuleInfDef*  vcripConInf) {

	short   liConX;

	*vnpConNum = 0;
	vtpTblConInf->usage_key = vlConInfKey;
	DbsCONINF(
			DBS_CURSOR,
			vtpTblConInf);

	if(DbsCONINF(
				DBS_OPEN,
				vtpTblConInf))
		return -1;

	while((DbsCONINF(
					DBS_FETCH,
					vtpTblConInf) == 0) &&
			((liConX = (*vnpConNum)++) < MAX_CON_NUM)) {
		vcripConInf[liConX].iFldIndex = vtpTblConInf->fld_index;
		vcripConInf[liConX].iBeginPtr = vtpTblConInf->begin_byte_pos;
		if(vtpTblConInf->format_chg_need) {
			vcripConInf[liConX].nValL =
				ConvCutBlankTailLen((unsigned char *)&vtpTblConInf->val, 35) / 2;
			/*  vcripConInf[liConX].nValL = vtpTblConInf->val.len / 2; */
			if(nMAsciiHexToBinary(
						(unsigned char *)&vtpTblConInf->val[0],
						strlen(vtpTblConInf->val),
						/*   &vtpTblConInf->val.arr[0],
						     vtpTblConInf->val.len,  */
						&vcripConInf[liConX].saVal[0]))
				return -1;
		}
		else {
			vcripConInf[liConX].nValL =
				ConvCutBlankTailLen((unsigned char *)&vtpTblConInf->val, 35);
			/* vcripConInf[liConX].nValL = vtpTblConInf->val.len; */
			memcpy(
					vcripConInf[liConX].saVal,
					vtpTblConInf->val,
					strlen(vtpTblConInf->val));
			/*  vtpTblConInf->val.arr,
			    vtpTblConInf->val.len);  */
		} /* end of if */
		vcripConInf[liConX].nTxnNumber = vtpTblConInf->txn_num;
	} /* end of while */

	if(DbsCONINF(
				DBS_CLOSE,
				vtpTblConInf) != LSqlSuccess)
		return -1;

	liConX = *vnpConNum - 1;
	vcripConInf[liConX--].iNextGrp = *vnpConNum;
	for(; liConX >= 0; liConX--) {
		if(vcripConInf[liConX].nTxnNumber == vcripConInf[liConX + 1].nTxnNumber)
			vcripConInf[liConX].iNextGrp = vcripConInf[liConX + 1].iNextGrp;
		else
			vcripConInf[liConX].iNextGrp = liConX + 1;
	} /* end of for */

	return 0;
} /* end of nMLoadConInf */

short nMLoadBmpInf(
		long                vlBmpInfKey,
		Tbl_bmp_inf_Def*    vtpTblBmpInf,
		BmpRuleInfDef*   vbripBmpInf) {

	short   liBmpX;
	int ret;

	vtpTblBmpInf->usage_key = vlBmpInfKey;
	DbsBMPINF(
			DBS_CURSOR,
			vtpTblBmpInf);

	if(DbsBMPINF(
				DBS_OPEN,
				vtpTblBmpInf) != LSqlSuccess)
		return -1;

	while((DbsBMPINF(
					DBS_FETCH,
					vtpTblBmpInf) == 0)) {
		if((liBmpX = vtpTblBmpInf->bmp_index) >= MAX_BMP_NUM)
			return -1;
		if(nMAsciiHexToBinary(
					(unsigned char *)&vtpTblBmpInf->bmp_val,
					ConvCutBlankTailLen((unsigned char *)&vtpTblBmpInf->bmp_val, 32),
					&vbripBmpInf[liBmpX].saVal[0]))
			return -1;
		if(((vbripBmpInf[liBmpX].saVal[0] & 0x80) &&
					(ConvCutBlankTailLen((unsigned char *)&vtpTblBmpInf->bmp_val, 32) != 32)) ||
				(((vbripBmpInf[liBmpX].saVal[0] & 0x80) == 0) &&
				 (ConvCutBlankTailLen((unsigned char *)&vtpTblBmpInf->bmp_val, 32) != 16)))
		{
			printf("index[%d] TailLen error\n", vtpTblBmpInf->bmp_index);
			return -1;
		}
	} /* end of while */

	if(DbsBMPINF(
				DBS_CLOSE,
				vtpTblBmpInf) != LSqlSuccess)
		return -1;

	return 0;
} /* end of nMLoadBmpInf */

short nMCalcIpc(
		FldRuleInfDef*  vfripFldInf,
		unsigned char*     vspIpcStr,
		short              vnIpcStrL,
		IpcRuleInfDef*  viripIpcInf) {

	short   liFldX;

	for(liFldX = 0; liFldX < MAX_FLD_NUM; liFldX++)
		viripIpcInf->naFld[liFldX] = -1;
	viripIpcInf->nMsgL = 0;
	liFldX = -1;
	for(; vnIpcStrL > 0; vnIpcStrL--, vspIpcStr++) {
		if(ISNUMBER(*vspIpcStr)) {
			if(liFldX == -1)
				liFldX = *vspIpcStr - '0';
			else
				liFldX = liFldX * 10 + *vspIpcStr - '0';
		}
		else if(liFldX != -1) {
			if(liFldX >= MAX_FLD_NUM ||
					vfripFldInf[liFldX].iBeginPtr == -2 ||
					viripIpcInf->naFld[liFldX] != -1)
				return -1;
			viripIpcInf->naFld[liFldX] = viripIpcInf->nMsgL;
			viripIpcInf->nMsgL += (
					vfripFldInf[liFldX].nFldLenL +
					vfripFldInf[liFldX].nDataMaxL +
					vfripFldInf[liFldX].nIndSym);
			liFldX = -1;
		} /* end of if */
	} /* end of for */

	return 0;
} /* end of nMCalcIpc */

short nMLoadIpcInf(
		long               vlIpcInfKey,
		Tbl_ipc_inf_Def*   vtpTblIpcInf,
		FldRuleInfDef*  vfripFldInf,
		IpcRuleInfDef*  viripIpcInf) {

	short   liIpcX;

	vtpTblIpcInf->usage_key = vlIpcInfKey;
	DbsIPCINF(
			DBS_CURSOR,
			vtpTblIpcInf);

	if(DbsIPCINF(
				DBS_OPEN,
				vtpTblIpcInf))
		return -1;

	while((DbsIPCINF(
					DBS_FETCH,
					vtpTblIpcInf) == 0)) {
		if((liIpcX = vtpTblIpcInf->ipc_index) >= MAX_IPC_NUM)
			return -2;

		if(nMCalcIpc(
					vfripFldInf,
					(unsigned char *)&vtpTblIpcInf->ipc_val[0],
					strlen(vtpTblIpcInf->ipc_val),
					&viripIpcInf[liIpcX]))
			return -3;
	} /* end of while */

	if(DbsIPCINF(
				DBS_CLOSE,
				vtpTblIpcInf))
		return -4;

	return 0;
} /* end of nMLoadIpcInf */

short ConvInit(
		long                   vlFldInfKey,
		long                   vlMsgInfKey,
		long                   vlConInfKey,
		long                   vlBmpInfKey,
		long                   vlIpcInfKey,
		TransRuleInfDef*    vtripTransRule) {

	Tbl_fld_inf_Def ltTblFldInf;
	Tbl_msg_inf_Def ltTblMsgInf;
	Tbl_con_inf_Def ltTblConInf;
	Tbl_bmp_inf_Def ltTblBmpInf;
	Tbl_ipc_inf_Def ltTblIpcInf;

	short	nReturnCode;

	if(nReturnCode = nMLoadFldInf(
				vlFldInfKey,
				&ltTblFldInf,
				&vtripTransRule->taFldInf[0])) {
		DbsFLDINF(
				DBS_CLOSE,
				&ltTblFldInf);
		return NUsrErrFldInf;
	} /* end of if */

	if(nReturnCode = nMLoadMsgInf(
				vlMsgInfKey,
				&ltTblMsgInf,
				&vtripTransRule->nMsgNum,
				&vtripTransRule->taMsgInf[0])) {
		DbsMSGINF(
				DBS_CLOSE,
				&ltTblMsgInf);
		return NUsrErrMsgInf;
	} /* end of if */

	if(nReturnCode = nMLoadConInf(
				vlConInfKey,
				&ltTblConInf,
				&vtripTransRule->nConNum,
				&vtripTransRule->taConInf[0])) {
		DbsCONINF(
				DBS_CLOSE,
				&ltTblConInf);
		return NUsrErrConInf;
	} /* end of if */

	if(nReturnCode = nMLoadBmpInf(
				vlBmpInfKey,
				&ltTblBmpInf,
				&vtripTransRule->taBmpInf[0])) {
		DbsBMPINF(
				DBS_CLOSE,
				&ltTblBmpInf);
		return NUsrErrBmpInf;
	} /* end of if */

	if(nReturnCode = nMLoadIpcInf(
				vlIpcInfKey,
				&ltTblIpcInf,
				&vtripTransRule->taFldInf[0],
				&vtripTransRule->taIpcInf[0])) {
		DbsIPCINF(
				DBS_CLOSE,
				&ltTblIpcInf);
		return NUsrErrIpcInf;
	} /* end of if */

	return 0;
} /* end of ConvInit */

void vMNonasciiToAscii(
		unsigned char*  vspInStr,
		short*          vnpInStrL,
		unsigned char*  vspOutStr,
		short           vnOutStrL,
		short           vnCharSet) {

	short   liBufX;
	short	nTmp;
	char	sTmp[4];

	switch(vnCharSet) {
		case NCharSetEbcdic:
			*vnpInStrL = vnOutStrL;
			for(; vnOutStrL > 0; vnOutStrL--)
				*vspOutStr++ = SAEbcdicAscii[*vspInStr++];
			return;

		case NCharSetBcdl:
			for(liBufX = 0; liBufX < vnOutStrL; liBufX++) {
				if(liBufX % 2)
					*vspOutStr++ = (*vspInStr++ & 0x0f) + '0';
				else
					*vspOutStr++ = ((*vspInStr >> 4) & 0x0f) + '0';
			} /* end of for */
			*vnpInStrL = (vnOutStrL + 1) / 2;
			return;

		case NCharSetBcdr:
			*vnpInStrL = (vnOutStrL + 1) / 2;
			vspInStr += ((vnOutStrL + 1) / 2);
			vspOutStr += vnOutStrL;
			liBufX = *vnpInStrL * 2;
			for(; liBufX >= (*vnpInStrL*2-vnOutStrL); liBufX--) {
				if((liBufX+1) % 2)
					*vspOutStr-- =
						(((*vspInStr--) >> 4) & 0x0f) + '0';
				else
					*vspOutStr-- = (*vspInStr & 0x0f) + '0';
			} /* end of for */
			return;

		case NCharSetBinary:
			memcpy(
					vspOutStr,
					vspInStr,
					vnOutStrL);
			*vnpInStrL = vnOutStrL;
			return;

		case NCharSetBinary21:
			nTmp = *vspInStr;
			*vnpInStrL = 1;
			sprintf(sTmp, "%02d", nTmp);

			memcpy(vspOutStr, sTmp, vnOutStrL);
			return;

		case NCharSetBinary31:
			nTmp = *vspInStr;
			*vnpInStrL = 1;
			sprintf(sTmp, "%03d", nTmp);

			memcpy(vspOutStr, sTmp, vnOutStrL);
			return;

		case NCharSetBinary32:
			nTmp = *vspInStr;
			*vnpInStrL = 2;
			vspInStr++;
			nTmp = nTmp * 256 + (*vspInStr);
			sprintf(sTmp, "%03d", nTmp);
			memcpy(vspOutStr, sTmp, vnOutStrL);
			return;

		default:
			memcpy(
					vspOutStr,
					vspInStr,
					vnOutStrL);
			*vnpInStrL = vnOutStrL;
	} /* end of switch */
} /* end of vMNonasciiToAscii */

short nMBmpAnalysis(
		unsigned char*     vspBmpStr,
		short*             vnpBitNum,
		FldRuleInfDef*  vfripFldInf) {

	char    lsaBmpFilter[8] = {0x80, 0x40, 0x20, 0x10, 8, 4, 2, 1};
	short   liByteX;
	short   liBitX;
	short   liFldX;
	short   liByteXMax;

	if(*vspBmpStr & lsaBmpFilter[0])
	{
		*vnpBitNum = 128;
		liByteXMax = 16;
	}
	else
	{
		*vnpBitNum = 64;
		liByteXMax = 8;
	}

	for(liByteX = 0, liFldX = 1; liByteX < liByteXMax; liByteX++, vspBmpStr++) {
		for(liBitX = 0; liBitX < 8; liBitX++, liFldX++) {
			if(vfripFldInf[liFldX].iBeginPtr != -2)
				vfripFldInf[liFldX].iBeginPtr = -1;
			if(*vspBmpStr & lsaBmpFilter[liBitX]) {
				if(vfripFldInf[liFldX].iBeginPtr == -2)
					return(liFldX * 10 + NIllNullFld);
				if(liFldX <= *vnpBitNum)
					vfripFldInf[liFldX].iBeginPtr = 0;
			} /* end of if */
		} /* end of for */
	} /* end of for */

	if (liByteXMax == 8)
	{
		for (liFldX = 65; liFldX <= 128; liFldX++)
			if(vfripFldInf[liFldX].iBeginPtr != -2)
				vfripFldInf[liFldX].iBeginPtr = -1;
	}

	return 0;
} /* end of nMBmpAnalysis */


short nMFldTranslate(
		unsigned char**    vsppInBuf,
		short*             vnpInBufL,
		short              vnMaxInBufL,
		short              vnInBufCharSet,
		short              vnInBufCompress,
		unsigned char**    vsppOutBuf,
		short*             vnpOutBufL,
		FldRuleInfDef*  vfripFldInf) {

	short           lnInBufL;
	short           lnFldL;
	unsigned char   lsaFldL[4];

	vfripFldInf->iBeginPtr = *vnpOutBufL;
	if(vfripFldInf->nFldLenL == 0)
		lnFldL = vfripFldInf->nDataMaxL;
	else {
		if (vfripFldInf->nLenCharSet == NCharSetAscii)
			vMNonasciiToAscii(
					*vsppInBuf,
					&lnInBufL,
					*vsppOutBuf,
					vfripFldInf->nFldLenL,
					vnInBufCharSet);
		else
			vMNonasciiToAscii(
					*vsppInBuf,
					&lnInBufL,
					*vsppOutBuf,
					vfripFldInf->nFldLenL,
					vfripFldInf->nLenCharSet);

		if(nMFormatChk(
				*vsppOutBuf,
				vfripFldInf->nFldLenL,
				NFormatN))
			return NIllLenExp;

		memcpy(
				lsaFldL,
				*vsppOutBuf,
				vfripFldInf->nFldLenL);
		lsaFldL[vfripFldInf->nFldLenL] = 0;
		lnFldL = atoi(
				(char*)(&lsaFldL[0]));

		if((lnFldL > vfripFldInf->nDataMaxL) ||
				((vfripFldInf->nLenExpVal) &&
				 (lnFldL != vfripFldInf->nLenExpVal)))
			return NIllLenExp;

		*vsppInBuf += lnInBufL;
		*vnpInBufL += lnInBufL;
		*vsppOutBuf += vfripFldInf->nFldLenL;
		*vnpOutBufL += vfripFldInf->nFldLenL;

		if(*vnpInBufL > vnMaxInBufL)
			return NIllLenExp;
	} /* end of if */

	vfripFldInf->nFldL = vfripFldInf->nFldLenL + lnFldL;

	if(vfripFldInf->nDataCharSet == NCharSetAscii)
		vMNonasciiToAscii(
				*vsppInBuf,
				&lnInBufL,
				*vsppOutBuf,
				lnFldL,
				vnInBufCharSet);
	else
		vMNonasciiToAscii(
				*vsppInBuf,
				&lnInBufL,
				*vsppOutBuf,
				lnFldL,
				vfripFldInf->nDataCharSet);

	if(nMFormatChk(
				*vsppOutBuf,
				lnFldL,
				vfripFldInf->nDataFormat))
		return NIllDataExp;

	*vsppInBuf += lnInBufL;
	*vnpInBufL += lnInBufL;
	*vsppOutBuf += lnFldL;
	*vnpOutBufL += lnFldL;

	if(*vnpInBufL > vnMaxInBufL)
		return NIllDataExp;

	return 0;
} /* end of nMFldTranslate */

short ConvOutToIn(
		void*                  vvpInBuf,
		short                  vnInBufL,
		short                  vnInBufCharSet,
		short                  vnInBufCompres,
		TransRuleInfDef*    	vtripTransRule,
		void*                  vvpOutBuf,
		short*                 vnpOutBufL) {

	char            lsaBmpFilter[8] = {0x80, 0x40, 0x20, 0x10, 8, 4, 2, 1};
	short           liFldX;
	short           liBitX;
	short           liBufX;
	short           liBmpX;
	short           liIpcX;
	short           lnResult;
	short           lnBitNum;
	short           lnBitNum0;
	short           lnInBufL;
	short           lnOutBufL;
	short           liMandBmpX;
	short           lnTxnNumber;
	unsigned char	lsaTxnNumber[F130_TXN_NUMBER_LEN+1];
	short*          lnpTmpVal;
	unsigned char   lsErrBmp;
	unsigned char   lsaTxnCode[F129_TXN_CODE_LEN];
	unsigned char   lsaMsgType[F000_MSG_TYPE_LEN];
	unsigned char   lsaNewHead[F131_NEW_HEAD_LEN];
	unsigned char   lsaOutBuf[NMaxMsgBufL * 2];
	unsigned char*  lspInBuf;
	unsigned char*  lspTmpBuf;
	unsigned char*  lspOutBuf;
	int				lnHeaderBufL;
	int				i, nPrintPos=0;

	if(vnInBufL > NMaxMsgBufL || vnInBufL < 0)
		return NIllLenExp;

	lspInBuf = vvpInBuf;

	memset(lsaNewHead,0,sizeof(lsaNewHead));
	if(lspInBuf[0] == '\x2E' || memcmp(&lspInBuf[0], "ISO", 3) == 0 || lspInBuf[0] == '\x16' || lspInBuf[0] == '\x60')
	{
		if(memcmp(&lspInBuf[0], "ISO", 3) == 0)
		{
			lnHeaderBufL = 3;

			memcpy(lsaNewHead,(char *)lspInBuf,lnHeaderBufL);
			lspInBuf = lspInBuf + lnHeaderBufL;
			vnInBufL = vnInBufL - lnHeaderBufL;
		}
		else if(memcmp(&lspInBuf[0], "\x60", 1) == 0)
		{
			lnHeaderBufL = 11;

			memcpy(lsaNewHead,(char *)lspInBuf,lnHeaderBufL);
			lspInBuf = lspInBuf + lnHeaderBufL;
			vnInBufL = vnInBufL - lnHeaderBufL;
		}
		else
		{
			lnHeaderBufL = lspInBuf[0];

			memcpy(lsaNewHead,(char *)lspInBuf,lnHeaderBufL);
			lspInBuf = lspInBuf + lnHeaderBufL;
			vnInBufL = vnInBufL - lnHeaderBufL;
		}
		printf("HEAD [");
		for(i = 0; i < lnHeaderBufL; i++)
			printf("%02x ", lsaNewHead[i]);
		printf("]\n");
	}


	lspOutBuf = vvpOutBuf;
	lspTmpBuf = &lsaOutBuf[0];
	lnInBufL = 0;
	lnOutBufL = 0;
	vtripTransRule->taFldInf[0].iBeginPtr = 0;

	lnBitNum0 = 128;
	for(liFldX = 0; liFldX <= lnBitNum0; liFldX++) {
		switch(liFldX) {
			case 1:
				if(nMBmpAnalysis(
							lspInBuf,
							&lnBitNum,
							&vtripTransRule->taFldInf[0]))
					return (liFldX * 10 + NIllDataExp);
				vtripTransRule->taFldInf[1].iBeginPtr = lnOutBufL;
				memcpy(
						lspTmpBuf,
						lspInBuf,
						lnBitNum / 8);
				lspInBuf += lnBitNum / 8;
				lnInBufL += lnBitNum / 8;
				lspTmpBuf += lnBitNum / 8;
				lnOutBufL += lnBitNum / 8;
				if(lnInBufL > vnInBufL)
					return (liFldX * 10 + NIllDataExp);
				lnBitNum0 = lnBitNum;

				printf("F%03d [", liFldX);
				for(i = 0; i < lnBitNum / 8; i++)
					printf("%02x ", lsaOutBuf[nPrintPos+i]);
				printf("]\n");

				nPrintPos += i;
				break;

			default:
				if(vtripTransRule->taFldInf[liFldX].iBeginPtr < 0)
					break;
				lnResult = nMFldTranslate(
						&lspInBuf,
						&lnInBufL,
						vnInBufL,
						vnInBufCharSet,
						vnInBufCompres,
						&lspTmpBuf,
						&lnOutBufL,
						&vtripTransRule->taFldInf[liFldX]);

				if(lnResult)
					return (liFldX * 10 + lnResult);

				printf("F%03d [", liFldX);
				if(	liFldX != 52 && liFldX != 55 && liFldX != 60 && liFldX != 63 && liFldX != 62 &&
						liFldX != 9 && liFldX != 10 && liFldX != 125 && liFldX != 48 && liFldX != 128 &&
						liFldX != 96 )
				{
					for(i = 0; i < vtripTransRule->taFldInf[liFldX].nFldL; i++)
						printf("%c", lsaOutBuf[nPrintPos+i]);
				}
				else
				{
					for(i = 0; i < vtripTransRule->taFldInf[liFldX].nFldL; i++)
						printf("%02x ", lsaOutBuf[nPrintPos+i]);
				}
				printf("]\n");

				nPrintPos += i;

		} /* end of switch */
	} /* end of for */

	return 0;
} /* end of ConvOutToIn */


short nMFormatChk(
		unsigned char* vspMsg,
		short          vnMsgL,
		short          vnMsgType)
{

	short   liStrX;
	short   liBufX;
	short   lnSpaceBegin;

	switch(vnMsgType) {
		case NFormatANS:
			return 0;

		case NFormatAN:
			lnSpaceBegin = NFalse;
			for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
				if(ISNUMBER(*vspMsg) ||
						ISALPHA(*vspMsg)) {
					if(lnSpaceBegin)
						return -1;
				}
				else if(ISSPACE(*vspMsg))
					lnSpaceBegin = NTrue;
				else
					return -1;
			} /* end of for */
			return 0;

		case NFormatSN:
			if((*vspMsg != 'D') &&
					(*vspMsg != 'C'))
				return -1;
			vspMsg++;
			vnMsgL--;

		case NFormatN:
			for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
				if(!ISNUMBER(*vspMsg))
					return -1;
			} /* end of for */
			return 0;

		case NFormatZ:
			for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
				if(!ISNUMBER(*vspMsg) &&
						*vspMsg != '=' &&
						*vspMsg != 'D' &&
						*vspMsg != 'd' )
					return -1;
			} /* end of for */
			return 0;

		case NFormatMMDDhhmmss:
			if(vnMsgL != 10)
				return -1;
			if((memcmp(&vspMsg[0], "01", 2) < 0) ||
				(memcmp(&vspMsg[0], "12", 2) > 0))
				return -1;
			if((memcmp(&vspMsg[2], "01", 2) < 0) ||
				(memcmp(&vspMsg[2], "31", 2) > 0))
				return -1;
			if(memcmp(&vspMsg[4], "23", 2) > 0)
				return -1;
			if(memcmp(&vspMsg[6], "59", 2) > 0)
				return -1;
			if(memcmp(&vspMsg[8], "59", 2) > 0)
				return -1;
			for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
				if(!ISNUMBER(*vspMsg))
					return -1;
			} /* end of for */
			return 0;

		case NFormatMMDD:
			if(vnMsgL != 4)
				return -1;
			if((memcmp(&vspMsg[0], "01", 2) < 0) ||
				(memcmp(&vspMsg[0], "12", 2) > 0))
				return -1;
			if((memcmp(&vspMsg[2], "01", 2) < 0) ||
				(memcmp(&vspMsg[2], "31", 2) > 0))
				return -1;
			for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
				if(!ISNUMBER(*vspMsg))
					return -1;
			} /* end of for */
			return 0;

		case NFormathhmmss:
			if(vnMsgL != 6)
				return -1;
			if(memcmp(&vspMsg[0], "23", 2) > 0)
				return -1;
			if(memcmp(&vspMsg[2], "59", 2) > 0)
				return -1;
			if(memcmp(&vspMsg[4], "59", 2) > 0)
				return -1;
			for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
				if(!ISNUMBER(*vspMsg))
					return -1;
			} /* end of for */
			return 0;

		case NFormatYYMMDD:
			if(vnMsgL != 6)
				return -1;
			if(memcmp(&vspMsg[0], "99", 2) > 0)
				return -1;
			if((memcmp(&vspMsg[2], "01", 2) < 0) ||
				(memcmp(&vspMsg[2], "12", 2) > 0))
				return -1;
			if((memcmp(&vspMsg[4], "01", 2) < 0) ||
				(memcmp(&vspMsg[4], "31", 2) > 0))
				return -1;
			for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
				if(!ISNUMBER(*vspMsg))
					return -1;
			} /* end of for */
			return 0;

		case NFormatP1:
			if(vnMsgL != 2 &&
					vnMsgL != 51 &&
					vnMsgL != 100 &&
					vnMsgL != 149 &&
					vnMsgL != 198)
				return -1;
			for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
				if(!ISNUMBER(*vspMsg))
					return -1;
			} /* end of for */
			return 0;

		case NFormatP2:
			if(vnMsgL != 20 &&
					vnMsgL != 40 &&
					vnMsgL != 60)
				return -1;
			for(liStrX = vnMsgL / 20; liStrX > 0; liStrX--) {
				if(memcmp( vspMsg, "10", 2) &&
					memcmp( vspMsg, "30", 2) &&
					memcmp( vspMsg, "19", 2))
					return -1;
				vspMsg += 2;
				if(memcmp( vspMsg, "01", 2) &&
					memcmp( vspMsg, "02", 2) &&
					memcmp( vspMsg, "16", 2))
					return -1;
				vspMsg += 2;
				lnSpaceBegin = NFalse;
				for(liBufX = 0; liBufX < 3; vspMsg++, liBufX++) {
					if(ISNUMBER(*vspMsg) ||
						ISALPHA(*vspMsg)) {
						if(lnSpaceBegin)
							return -1;
					}
					else if(ISSPACE(*vspMsg))
						lnSpaceBegin = NTrue;
					else
						return -1;
				} /* end of for */
				if((*vspMsg != 'D') &&
					(*vspMsg != 'C'))
					return -1;
				for(++vspMsg, liBufX = 12; liBufX > 0; liBufX--, vspMsg++) {
					if(!ISNUMBER(*vspMsg))
						return -1;
				} /* end of for */
			} /* end of for */
			return 0;

		case NFormatP3:
			if(vnMsgL < 4)
				return -1;
			for(liBufX = 0; liBufX < 4; vspMsg++, liBufX++) {
				if(!ISNUMBER(*vspMsg))
					return -1;
			} /* end of for */
			return 0;

		default:
			return -1;
	} /* end of switch */

	return 0;
} /* end of nMFormatChk */
