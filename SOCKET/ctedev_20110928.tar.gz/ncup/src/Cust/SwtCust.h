#ifndef __SWT_CUST_H
#define __SWT_CUST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <errno.h>
#include <sys/msg.h>
#include <sys/times.h>
#include <time.h>
#include <math.h>
/*#include <syms.h>*/
#include "SrvDef.h"
#include "TxnNum.h"
#include "IpcInt.h"
#include "Common.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "CstDbsTbl.h"
#include "HtLog.h"
#include "SrvParam.h"
#include "ErrCode.h"
#include "EncOpr.h"
#include "MsqOpr.h"
#include "LineStat.h"
#include "db.h"
#include "unionAPI.h"

#define MSG_SRC_ID_ANY      "9999"
#define    CST_BANK_TLR_NUM     10000

typedef struct
{
	char  sTxnNum[4+1];
    char  sTermSsn[12+1];
	char  sMchntCd[15+1];
	char  sPan[19+1];
	char  sInstDate[8+1];
	char  sInstTime[6+1];
	char  sPayYear[2+1];
	char  sPayAmt[12+1];
	char  sReserve1[50+1];
	char  sReserve2[100+1];
} CST_mem_payment_info_Def;

typedef struct
{
	char acSubserial[21];  
	char acMchnt_cd[16];
	char acMem_nm[61];
    char acMem_nm_en[61];
	char acSex[2];
	char acBirth[21];
	char acPan[20];
	char acPanTp[3];
	char acCardTp[2];
	char acCardNo[51];
	char acCstNo[51];
	char acCardOrg[5];
	char acCardAddr[101];
	char acBrhNo[31];
	char acBankAddrno[21];
	char acOpr[11];
	char acContactPhone[21];
	char acContactTel[21];
	char acContactAddr[61];
	char acCompany[61];
	char acPostCode[21];
	char acCstManager[11];
	char acOprTp[2];
	char acAcctTp[2];
	char acSrvLevel[3];
	char acReserve[101];
} CST_mem_cardinfo_Def;

T_InstTxnParamVal InstTxnParamVal;


#endif
