/*****************************************************************************/

/*                NCUP -- Shanghai Huateng Software System Inc.              */

/*****************************************************************************/

/* PROGRAM NAME: CvtCust.c                                                   */

/* DESCRIPTIONS: message format convert between internal ipc and host msg    */

/*****************************************************************************/

/*                             MODIFICATION LOG                              */

/* DATE        PROGRAMMER     DESCRIPTION                                    */

/* 2005-04-19  YU TONG        Initialize                                     */

/*****************************************************************************/

static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Cust/Attic/CvtCust.c,v 1.2.2.3 2011/09/23 02:54:34 ctedev Exp $";

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <math.h>
#include "IpcInt.h"
#include "TxnNum.h"
#include "SrvDef.h"
#include "BufChg.h"
#include "DbsDef.h"
#include "BPIpcInt.h"

extern char gsLogFile[LOG_NAME_LEN_MAX];
extern GFHEADER_CFG GFHeaderCfg_CC;
extern GFHEADER_CFG GFHeaderCfg_ZK;	

int CvtCustOutToIn (stIpcDftRuleDef *ptIpcDftRule, bciMBufChgInfDef *ptBufChgRule, int nSrcMsgLen, char *sSrcMsgBuf, int *pnDestMsgLen, char *sDestMsgBuf, char *sTxnNum)
{
	T_IpcIntMngDef	*tIpcIntMng;
	T_IpcIntTxnDef	*tIpcIntTxn;
	T_IpcIntBonusDef *pIpcBonusTxn;
	Tbl_frn_ctl_Def vtFrnCtl;

	char saCompKey[11], saTmp[200], saDataLen[4];
	char sTemp[16];
	char sSbNo[5];
	char sDate[6];
	char sTranAmt[16];
	char sTranAmtFee[13];
	char sAuthInfo[23];
	int nBufChgIndex;
	int nReturnCode;
	int i;	

	/*============== ���Կ���̨����,�����޸� ======================*/
	if(memcmp(sSrcMsgBuf,SRV_ID_COMM_CON,SRV_ID_LEN) == 0)
	{
		memset(saCompKey,0,sizeof(saCompKey));
		memcpy(saCompKey,sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,4);

      	HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%4.4s]",saCompKey);
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
								sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode) return nReturnCode;

      	HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "pnDestMsgLen[%d]",*pnDestMsgLen);

		nReturnCode = BufChgOpr(nBufChgIndex,

								sSrcMsgBuf,

								sDestMsgBuf,

								ptBufChgRule);

		if(nReturnCode) return nReturnCode;

		if (sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_MANAGE)
		{
			tIpcIntMng = (T_IpcIntMngDef *)sDestMsgBuf;
			if (sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_REQ)
			{
			    /* ���������� */
				tIpcIntMng->sHeaderBuf[0] = '\x2E';
				tIpcIntMng->sHeaderBuf[1] = '\x01';
				memcpy(tIpcIntMng->sTxnNum,sTxnNum,FLD_TXN_NUM_LEN);
			}
			memcpy(tIpcIntMng->sTxnNum,sTxnNum,FLD_TXN_NUM_LEN);
		}
		return 0;
	}

	/*==========================================================*/
    /*==================     ��ֵ�������� -> 8583   ======================*/
    /****************** Add by: Metals Young    Time:2011-04-01 *************/
	if((memcmp(sSrcMsgBuf, "1701", SRV_ID_LEN) == 0) ||
	    (memcmp(sSrcMsgBuf, "1710", SRV_ID_LEN) == 0))
	{
	    HtDebugString ("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sSrcMsgBuf, nSrcMsgLen);
		memset(saCompKey,0,sizeof(saCompKey));
		memset(sDestMsgBuf,0,sizeof(sDestMsgBuf));
		/**4λ�����峤�ȣ���1024����+ 12λ������**/
		memcpy(saCompKey, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER, 4);		
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%4.4s]",saCompKey);

		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
							sTxnNum, &nBufChgIndex, ptIpcDftRule);							

		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%4.4s]",sTxnNum);
		HtDebugString ("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sDestMsgBuf, *pnDestMsgLen);	

		if(nReturnCode)
		    return nReturnCode;		

		nReturnCode = BufChgOpr(nBufChgIndex,
								sSrcMsgBuf,
								sDestMsgBuf,
								ptBufChgRule);
        if(nReturnCode) 
		    return nReturnCode;	  

	    HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%s]nReturnCode[%d]",sTxnNum,nReturnCode);
 
		tIpcIntTxn = (T_IpcIntTxnDef *)sDestMsgBuf;		

		/* F014 
		tIpcIntTxn->cF014Ind = 'Y';
		memcpy(tIpcIntTxn->sDateExpr, "0000", F014_LEN);*/		

		/* F048 ������ */
		if(memcmp(tIpcIntTxn->sTxnNum, "1936", FLD_TXN_NUM_LEN) == 0 ||
		    memcmp(tIpcIntTxn->sTxnNum, "1926", FLD_TXN_NUM_LEN) == 0)
		{
		    memset(sTranAmtFee, 0, sizeof(sTranAmtFee));
		    memcpy(sTranAmtFee, tIpcIntTxn->sAddtnlDataPrivate+1, 12);
		    tIpcIntTxn->cF048Ind = 'Y';
		    memcpy(tIpcIntTxn->sAddtnlDataPrivateLen, "012", 3);
		    memcpy(tIpcIntTxn->sAddtnlDataPrivate, sTranAmtFee, 12);
		}		

		/* F054 */
		tIpcIntTxn->cF054Ind = 'Y';
		memcpy(tIpcIntTxn->sAddtnlAmtLen, "040", F054_LEN_LEN);
		if(tIpcIntTxn->sAddtnlAmt[0] != ' ' && 
		    tIpcIntTxn->sAddtnlAmt[0] != 0x00 &&
		    memcmp(tIpcIntTxn->sRespCode, "00", F039_LEN) == 0)
		{
		    memset( saTmp , 0 , sizeof(saTmp));
		    memset( sTemp , 0 , sizeof(sTemp));
		    memcpy(saTmp, tIpcIntTxn->sAddtnlAmt, 13);
		    memcpy(sTemp, tIpcIntTxn->sAddtnlAmt+13, 13);
		    memset( tIpcIntTxn->sAddtnlAmt, 0, 40);
			i = 0;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "00", 2);
		    i += 2;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "01", 2);
		    i += 2;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "156", 3);
		    i += 3;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "C", 1);
		    i += 1;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, saTmp+1, 12);
		    i += 12;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "00", 2);
		    i += 2;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "02", 2);
		    i += 2;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "156", 3);
		    i += 3;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "C", 1);
		    i += 1;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, sTemp+1, 12);
		    i += 12;
		}
		else
		    memset(tIpcIntTxn->sAddtnlAmt, '0', 40);		

		/* F055 */
		if(tIpcIntTxn->sICData[0] != 0x00 && tIpcIntTxn->sICData[0] != ' ')
		    tIpcIntTxn->cICDataInd = 'Y';				

		memcpy(tIpcIntTxn->sTxnNum,sTxnNum,FLD_TXN_NUM_LEN);	

		return 0;
	}

    /*==================   END  ��ֵ����8583 -> ����    ======================*/
	/*==================  ���ÿ�  ���� -> 8583 ==1720Ϊ�������==1902 ǩ��ǩ�˵Ķ���==*/
	if((memcmp(sSrcMsgBuf,"1702",SRV_ID_LEN) == 0) || 
	   (memcmp(sSrcMsgBuf,"1902",SRV_ID_LEN) == 0))
	{
		memset(saCompKey,0,sizeof(saCompKey));
		if(nSrcMsgLen-(SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN) < FLD_GF_HEADER+523 || /*523Ϊ���ÿ������ཻ�׶��������峤��*/
		   sSrcMsgBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER] == ' ')
		{
			/*�����ཻ��ʱ��ȡ����ͷ��11�� �������� */
			memcpy(saCompKey,sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22,6);
		}
		else
		{
			/*ȡӦ��󣬽�������+���������е�ǰ6λ*/
			memcpy(&saCompKey[0],sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,4);
			memcpy(&saCompKey[4],sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+27,2);

			/* ���ڽ��� */
			if(memcmp(sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+483, "64", 2) == 0)
			    saCompKey[0] = '1';

			/* POS���ֽ��� */
			if(memcmp(sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+6, "JF", 2) == 0 &&
			   memcmp(saCompKey, "0930", 4) &&
			   memcmp(saCompKey, "0910", 4))
			    saCompKey[0] = '2';
		    	/* �̳ǻ��ֽ��� */
			if(memcmp(sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+6, "SC", 2) == 0 &&
			   memcmp(saCompKey, "0930", 4) &&
			   memcmp(saCompKey, "0910", 4))
			    saCompKey[0] = '2';
			
		}		

		/* ��Կ����,�ļ��ϴ�֪ͨ�߳��� */
		if(memcmp(sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22,"000610",6) == 0 ||
		   memcmp(sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22,"FL0011",6) == 0 ||
		   memcmp(sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22,"FL0021",6) == 0 )
		{
		    memcpy(saCompKey,sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22,6);
		}		

		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]",saCompKey);
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
							sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode) 
			return nReturnCode;

		nReturnCode = BufChgOpr(nBufChgIndex,
								sSrcMsgBuf,
								sDestMsgBuf,
								ptBufChgRule);
		if(nReturnCode) 
			return nReturnCode;			

		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%s]nReturnCode[%d]",sTxnNum,nReturnCode);
		/*tIpcIntMng = (T_IpcIntMngDef *)sDestMsgBuf;*/
		memset(saCompKey,0,sizeof(saCompKey));
		memcpy(saCompKey,sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+190+32,4);
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "header reservd txnnum [%4.4s]", saCompKey);
		tIpcIntTxn = (T_IpcIntTxnDef *)sDestMsgBuf;
		memcpy(tIpcIntTxn->sTxnNum,sTxnNum,FLD_TXN_NUM_LEN);		

		if(memcmp(saCompKey, "1805", 4) == 0 ||
		    memcmp(saCompKey, "1815", 4) == 0 ||
		    memcmp(saCompKey, "2815", 4) == 0 ||
		    memcmp(saCompKey, "3815", 4) == 0 ||
		    memcmp(saCompKey, "4815", 4) == 0 ||
		    memcmp(saCompKey, "5815", 4) == 0 ||
		    memcmp(saCompKey, "1825", 4) == 0||
		    memcmp(saCompKey, "1845", 4) == 0)
		{
		    saCompKey[3]++;
			if(memcmp(sTxnNum, "1208", 4) == 0)
				memcpy(sTxnNum, "1998", 4);
		    memcpy(tIpcIntTxn->sTxnNum,saCompKey,FLD_TXN_NUM_LEN);
		    memcpy(tIpcIntTxn->sKeyRsp,sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+190,32);
		    memcpy(tIpcIntTxn->sMAC064,sTxnNum,FLD_TXN_NUM_LEN); /* ԭ������ */
			HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tIpcIntTxn->sKeyRsp[%32.32s]", tIpcIntTxn->sKeyRsp);
		}

		memcpy(tIpcIntTxn->sMAC064,sTxnNum,FLD_TXN_NUM_LEN); /* ԭ������ */

		if( memcmp(sTxnNum,"1208",4) == 0 && memcmp(tIpcIntTxn->sRespCode, "00", F039_LEN) == 0)
		{
		    /* F054 */
		    tIpcIntTxn->cF054Ind = 'Y';
		    memcpy(tIpcIntTxn->sAddtnlAmtLen, "040", F054_LEN_LEN);
		    HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sF054 (sTrack3Data): [%104.104s]",tIpcIntTxn->sTrack3Data);
 		    memset( tIpcIntTxn->sAddtnlAmt , 0 , 40);
		    i = 0;
		    /* 0~20 */
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "30", 2);
		    i += 2;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "01", 2);
		    i += 2;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "156", 3);
		    i += 3;
		    if(memcmp(tIpcIntTxn->sTrack3Data,"+",1) == 0)
		        memcpy(tIpcIntTxn->sAddtnlAmt+i, "C", 1);
		    else
		        memcpy(tIpcIntTxn->sAddtnlAmt+i, "D", 1);
		    i += 1;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i,"000000000000" , 12);
		    i += 12;		    

		    /* 21~40 */
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "30", 2);
		    i += 2;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "02", 2);
		    i += 2;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, "156", 3);
		    i += 3;
		    if(memcmp(tIpcIntTxn->sTrack3Data,"+",1) == 0)
		        memcpy(tIpcIntTxn->sAddtnlAmt+i, "C", 1);
		    else
		        memcpy(tIpcIntTxn->sAddtnlAmt+i, "D", 1);
		    i += 1;
		    memcpy(tIpcIntTxn->sAddtnlAmt+i, tIpcIntTxn->sTrack3Data+1+1, 12);
		    i += 12;		    

		    HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sF054 : [%40.40s]",tIpcIntTxn->sAddtnlAmt);
		}
		return 0;
	}

	/*==================  ����ͨ�����-�ܿ�  ���� ==================*/
	if(memcmp(sSrcMsgBuf, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0)
	{
	    /* �жϽ��� F003����λ�� */
		memset(saCompKey,0,sizeof(saCompKey));
		memcpy(saCompKey,sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+129+26,4);
		if(memcmp(saCompKey, "9999", 4) == 0)
		{
		    sSrcMsgBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22+4] = '1';
		}		

		memcpy(saCompKey,sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22,6);

		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]",saCompKey);
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
							sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode) 
			return nReturnCode;

		nReturnCode = BufChgOpr(nBufChgIndex,
								sSrcMsgBuf,
								sDestMsgBuf,
								ptBufChgRule);
		if(nReturnCode)
			return nReturnCode;			

		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%s] nReturnCode[%d]",sTxnNum,nReturnCode);

		if(memcmp(saCompKey, "DEP", 3) == 0)
		{
		    tIpcIntTxn = (T_IpcIntTxnDef *)sDestMsgBuf;
		    memcpy(tIpcIntTxn->sTxnNum, sTxnNum, FLD_TXN_NUM_LEN);
		    memcpy(tIpcIntTxn->sRespCode, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+173, 2);
		    if(memcmp(tIpcIntTxn->sRespCode, "00", 2) == 0 ||
		        memcmp(tIpcIntTxn->sRespCode, "  ", 2) == 0)
		    {
		        if(memcmp(tIpcIntTxn->sRespCode, "00", 2) == 0)
		            memcpy(tIpcIntTxn->sStlmInst, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+175, 7);
		        memcpy(tIpcIntTxn->sRespCode, "01", 2);
		    }
		    else if(memcmp(tIpcIntTxn->sRespCode, "01", 2) == 0)
		        memcpy(tIpcIntTxn->sRespCode, "00", 2);		        

		    memcpy(tIpcIntTxn->sMAC128, tIpcIntTxn->sGfHeader+193, F128_LEN);
		    HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Return Mac [%8.8s]", tIpcIntTxn->sMAC128);
		}
		else
		{
		    tIpcIntMng = (T_IpcIntMngDef *)sDestMsgBuf;
		    memcpy(tIpcIntMng->sTxnNum, sTxnNum, FLD_TXN_NUM_LEN);
		    memcpy(tIpcIntMng->sFwdInstIdCodeLen, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+173, 2);
		    if(memcmp(tIpcIntMng->sFwdInstIdCodeLen, "00", 2) == 0 ||
		        memcmp(tIpcIntMng->sFwdInstIdCodeLen, "  ", 2) == 0)
		        memcpy(tIpcIntMng->sRespCode, "91", 2);
		    if(memcmp(saCompKey, "ECH", 3) == 0)
		    {
		        memcpy(tIpcIntMng->sRespCode, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+173, 2);
		        if(memcmp(tIpcIntMng->sRespCode, "00", 2) == 0 ||
		            memcmp(tIpcIntMng->sRespCode, "  ", 2) == 0)
		            memcpy(tIpcIntMng->sRespCode, "01", 2);
		        else if(memcmp(tIpcIntMng->sRespCode, "01", 2) == 0)
		            memcpy(tIpcIntMng->sRespCode, "00", 2);
		        memcpy(tIpcIntMng->sProcessingCode, saCompKey, 6);
		    }
		    memcpy(tIpcIntMng->sTransmsnDateTime, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+129, F007_LEN);
		    memcpy(tIpcIntMng->sSysTraceAuditNum, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+139, F011_LEN);
		    HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 
		            "sTransmsnDateTime[%10.10s] sSysTraceAuditNum[%6.6s]",tIpcIntMng->sTransmsnDateTime,tIpcIntMng->sSysTraceAuditNum);
            
		    memcpy(tIpcIntMng->sMAC128, tIpcIntMng->sGfHeader+193, F128_LEN);
		    HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Return Mac [%8.8s]", tIpcIntMng->sMAC128);
		}

		return 0;
	}

	/*==================     ����ϵͳ������   ======================*/
	if((memcmp(sSrcMsgBuf, "1903", SRV_ID_LEN) == 0))
	{
	    HtDebugString ("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sSrcMsgBuf, nSrcMsgLen);
		memset(saCompKey,0,sizeof(saCompKey));
		memset(sDestMsgBuf,0,sizeof(sDestMsgBuf));
		memcpy(saCompKey, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+57, 6);		
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%6.6s]",saCompKey);

		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
							sTxnNum, &nBufChgIndex, ptIpcDftRule);							

		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%4.4s]",sTxnNum);
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nBufChgIndex[%d]--pnDestMsgLen[%d]",nBufChgIndex,*pnDestMsgLen);
		HtDebugString ("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sDestMsgBuf, *pnDestMsgLen);	
		if(nReturnCode) 
		    return nReturnCode;		

		nReturnCode = BufChgOpr(nBufChgIndex,
								sSrcMsgBuf,
								sDestMsgBuf,
								ptBufChgRule);
		if(nReturnCode) 
		    return nReturnCode;	  

	    HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%s]nReturnCode[%d]",sTxnNum,nReturnCode);
        HtDebugString ("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sDestMsgBuf, *pnDestMsgLen);	
		pIpcBonusTxn = (T_IpcIntBonusDef *)sDestMsgBuf;
		memcpy(pIpcBonusTxn->sTxnNum,sTxnNum,FLD_TXN_NUM_LEN);
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sConsumeType, sLoopRsp[%1.1s]", pIpcBonusTxn->sLoopRsp + 32);
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sConsumeType[%1.1s]", pIpcBonusTxn->sConsumeType);

        memcpy(pIpcBonusTxn->sMAC064,sTxnNum,FLD_TXN_NUM_LEN); /* ԭ������ */

        HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransChnl[%4.4s]", pIpcBonusTxn->sTransChnl);

        /* ���ּ��ֽ��ף����״���ת�� */
		if(!memcmp(pIpcBonusTxn->sLoopRsp + 32, "1", 1) &&
		   !memcmp(pIpcBonusTxn->sTransChnl, "POSP", 4))
		{
            if(!memcmp(sTxnNum, "1816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "1826", 4);
			else if(!memcmp(sTxnNum, "2816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "2826", 4);
			else if(!memcmp(sTxnNum, "3816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "3826", 4);
			else if(!memcmp(sTxnNum, "4816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "4826", 4);
		}
		else if(!memcmp(pIpcBonusTxn->sConsumeType, "1", 1) &&
			    !memcmp(pIpcBonusTxn->sTransChnl, "POSP", 4))
		{
		    if(!memcmp(sTxnNum, "1816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "1826", 4);
			else if(!memcmp(sTxnNum, "2816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "2826", 4);
			else if(!memcmp(sTxnNum, "3816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "3826", 4);
			else if(!memcmp(sTxnNum, "4816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "4826", 4);
		}
		if(!memcmp(pIpcBonusTxn->sTransChnl,"CCAG",4)||
                !memcmp(pIpcBonusTxn->sTransChnl,"MALL",4) )
		{
            if(!memcmp(sTxnNum, "1816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "1846", 4);
			else if(!memcmp(sTxnNum, "1898", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "1846", 4);
			else if(!memcmp(sTxnNum, "2816", 4))
				memcpy(pIpcBonusTxn->sTxnNum, "2846", 4);
		}		
				
		return 0;
	}
	/*==================     �̳ǻ��֣�����   ======================*/
	if((memcmp(sSrcMsgBuf, "1831", SRV_ID_LEN) == 0))
	{
	    HtDebugString ("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sSrcMsgBuf, nSrcMsgLen);
		memset(saCompKey,0,sizeof(saCompKey));
		memset(sDestMsgBuf,0,sizeof(sDestMsgBuf));
		memcpy(saCompKey, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+57, 6);		
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%6.6s]",saCompKey);

		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
							sTxnNum, &nBufChgIndex, ptIpcDftRule);							

		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%4.4s]",sTxnNum);
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nBufChgIndex[%d]--pnDestMsgLen[%d]",nBufChgIndex,*pnDestMsgLen);
		HtDebugString ("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sDestMsgBuf, *pnDestMsgLen);	
		if(nReturnCode) 
		    return nReturnCode;		

		nReturnCode = BufChgOpr(nBufChgIndex,
								sSrcMsgBuf,
								sDestMsgBuf,
								ptBufChgRule);
		if(nReturnCode) 
		    return nReturnCode;	  

	    HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%s]nReturnCode[%d]",sTxnNum,nReturnCode);
        HtDebugString ("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sDestMsgBuf, *pnDestMsgLen);	
		pIpcBonusTxn = (T_IpcIntBonusDef *)sDestMsgBuf;
		memcpy(pIpcBonusTxn->sTxnNum,sTxnNum,FLD_TXN_NUM_LEN);
		HtLog("CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sConsumeType[%1.1s]", pIpcBonusTxn->sLoopRsp + 32);
	
		return 0;
	}
	return 0;
}

int CvtCustInToOut(stIpcDftRuleDef *ptIpcDftRule, bciMBufChgInfDef *ptBufChgRule, int nSrcMsgLen, char *sSrcMsgBuf, int *pnDestMsgLen, char *sDestMsgBuf)
{
	T_IpcIntMngDef	*tIpcIntMng;
	T_IpcIntTxnDef	*tIpcIntTxn;
	T_IpcIntBonusDef *pIpcBonusTxn;    

    char*   spGfHeader;
	char    saCompKey[11], sTxnNum[5];
	int     nBufChgIndex; 
	int     nReturnCode,i;
	char    sTemp[16];
	char    sTermSSN[10+1];	

	/*============== Ӧ�����̨����,�����޸� ======================*/
	if(memcmp(sSrcMsgBuf+SRV_ID_LEN,SRV_ID_COMM_CON,SRV_ID_LEN) == 0)
	{	
		tIpcIntMng = (T_IpcIntMngDef *)sSrcMsgBuf;
		memset(saCompKey,0,sizeof(saCompKey));
		memcpy(saCompKey,tIpcIntMng->sTxnNum,FLD_TXN_NUM_LEN);
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����̨saCompKey[%s]", saCompKey);
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
								sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode) return nReturnCode;        

        if(memcmp(tIpcIntMng->sMiscFlag, "6073", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "6073", 4);
        else if(memcmp(tIpcIntMng->sMiscFlag, "6074", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "6074", 4);
        else if(memcmp(tIpcIntMng->sMiscFlag, "6432", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "CCB1", 4);
        else if(memcmp(tIpcIntMng->sMiscFlag, "6434", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "CCB3", 4);
        else if(memcmp(tIpcIntMng->sMiscFlag, "6436", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "CCF1", 4);
        else if(memcmp(tIpcIntMng->sMiscFlag, "6438", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "CCF3", 4);
        else if(memcmp(tIpcIntMng->sMiscFlag, "6206", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "6205", 4);
        else if(memcmp(tIpcIntMng->sMiscFlag, "6216", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "6215", 4);
        else if(memcmp(tIpcIntMng->sTxnNum, "6446", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "ZK10", 4);
        else if(memcmp(tIpcIntMng->sTxnNum, "6456", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "ZK20", 4);
        else if(memcmp(tIpcIntMng->sTxnNum, "6236", 4) == 0)
            memcpy(tIpcIntMng->sTxnNum, "CCP1", 4);        

		nReturnCode = BufChgOpr(nBufChgIndex,
								sSrcMsgBuf,
								sDestMsgBuf,
								ptBufChgRule);
		if(nReturnCode) return nReturnCode;
		return 0;
	}
	
	/*==========================================================*/	
    /*=======================��ֵ��========================*/
	if((memcmp(sSrcMsgBuf+SRV_ID_LEN,"1701",SRV_ID_LEN) == 0) ||
	    (memcmp(sSrcMsgBuf+SRV_ID_LEN,"1710",SRV_ID_LEN) == 0) )
	{
		tIpcIntTxn = (T_IpcIntTxnDef *)sSrcMsgBuf;

		memset(saCompKey,0,sizeof(saCompKey));
		memcpy(saCompKey,tIpcIntTxn->sTxnNum,FLD_TXN_NUM_LEN);		

        HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]", saCompKey);
 
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
								sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode)
		{
            HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nReturnCode[%d]", nReturnCode );
			return nReturnCode;
		}    

		nReturnCode = BufChgOpr(nBufChgIndex,
								sSrcMsgBuf,
								sDestMsgBuf,
								ptBufChgRule);
		if(nReturnCode)
		{
            HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nReturnCode[%d]", nReturnCode );
            return nReturnCode;
		}		

		/* Debug��־ */
		nReturnCode = printPCSLog(sDestMsgBuf);
		return 0;
	}	

	/*====================���ÿ�����1702-������1902������====================*/
	if((memcmp(sSrcMsgBuf+SRV_ID_LEN,"1702",SRV_ID_LEN) == 0) || memcmp(sSrcMsgBuf+SRV_ID_LEN,"1902",SRV_ID_LEN) == 0)
	{
		tIpcIntTxn = (T_IpcIntTxnDef *)sSrcMsgBuf;
        spGfHeader=tIpcIntTxn->sGfHeader; /*Ϊ�����޸Ĺ㷢ͷ*/

		memset(saCompKey,0,sizeof(saCompKey));
		memcpy(saCompKey,tIpcIntTxn->sTxnNum,FLD_TXN_NUM_LEN);
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]", saCompKey);
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf, sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode)
			return nReturnCode;

		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "CvtCustInToOut.pnDestMsgLen[%d]", *pnDestMsgLen);

		/* ���㷢����ͷ  begin*/
		i=0;
		memset(spGfHeader, ' ', 190);      /*(����λ�����sKeyRspֵ�����ɸ���)*/
		
		memcpy(spGfHeader+i, GFHeaderCfg_CC.sRunPri, 2);   /* 1 �������ȼ� 2*/
		i += 2;
		
		sprintf(spGfHeader+i, "%04d", *pnDestMsgLen-(SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN));    /* 2 ���ݱ��ĳ��� 4*/
		i +=4;
		
		memcpy(spGfHeader+i, GFHeaderCfg_CC.sFwNum, 1);   /* 3 ת������ 1*/
		i +=1;
		
		memcpy(spGfHeader+i, GFHeaderCfg_CC.sVerNo, 1);      /* 4 �汾�� 1*/
		i +=1;
		
		memcpy(spGfHeader+i, GFHeaderCfg_CC.sToEnc, 1);      /* 5 ��Ѻ��ʶ 1*/
		i +=1;
		
		memcpy(spGfHeader+i, "0", 1);      /* 6 �ļ���ʶ 1*/
		i +=1;	

		memcpy(spGfHeader+i, GFHeaderCfg_CC.sChnlId, 3);    /* 7 ������ʶ 3*/
		i +=3;	

		if(!memcmp(tIpcIntTxn->sTxnNum, "6435", 4) || !memcmp(tIpcIntTxn->sTxnNum, "6437", 4))
		    memcpy(spGfHeader+i, GFHeaderCfg_CC.sChnlSeg2, 1);      /* 8 ����ϸ�� 1*/
		else
			memcpy(spGfHeader+i, GFHeaderCfg_CC.sChnlSeg1, 1);
		i +=1;		

		memcpy(spGfHeader+i, GFHeaderCfg_CC.sNetgateNo, 4);   /* 9 ���ر�� 4*/
		i +=4;		

		memcpy(spGfHeader+i, GFHeaderCfg_CC.sBusSys, 4);   /* 10 ҵ��ϵͳ 4*/
		i +=4;		

		/* 11 �������� 6*/
		if(!memcmp(tIpcIntTxn->sTxnNum, "1017", 4) ||   /*Ԥ��Ȩ����*/
		   !memcmp(tIpcIntTxn->sTxnNum, "3017", 4))     /*Ԥ��Ȩ��������*/
			memcpy(spGfHeader+i, "000100", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "1107", 4) ||
		        !memcmp(tIpcIntTxn->sTxnNum, "1117", 4) ||
		        !memcmp(tIpcIntTxn->sTxnNum, "1825", 4))    /*����(����)�������󣬻��ּ��ֽ����� */
			memcpy(spGfHeader+i, "000200", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "3107", 4) ||
		        !memcmp(tIpcIntTxn->sTxnNum, "3117", 4) ||
		        !memcmp(tIpcIntTxn->sTxnNum, "3825", 4))    /*����(����)�������󣬻��ּ��ֽ����ѳ��� */
			memcpy(spGfHeader+i, "000220", 6);

		/*��ԭ����*/
		else if(!memcmp(tIpcIntTxn->sTxnNum, "2107", 4) || /*���ѳ�������*/
		        !memcmp(tIpcIntTxn->sTxnNum, "4107", 4) || /*������������*/
		        !memcmp(tIpcIntTxn->sTxnNum, "5157", 4) || /*�����˻�����*/
		        !memcmp(tIpcIntTxn->sTxnNum, "2017", 4) || /*Ԥ��Ȩ��������*/
		        !memcmp(tIpcIntTxn->sTxnNum, "4017", 4) || /*Ԥ��Ȩ������������*/		        
		        !memcmp(tIpcIntTxn->sTxnNum, "2117", 4) || /*�������ѳ�������*/		        
		        !memcmp(tIpcIntTxn->sTxnNum, "4117", 4) || /*�������ѳ�����������*/
		        !memcmp(tIpcIntTxn->sTxnNum, "2825", 4) || /*���ּ��ֽ����ѳ��� */
		        !memcmp(tIpcIntTxn->sTxnNum, "4825", 4))   /*���ּ��ֽ����ѳ������� */  
			memcpy(spGfHeader+i, "000400", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "1207", 4))/*��ѯ��������*/
			memcpy(spGfHeader+i, "000900", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "6235", 4))/*��Կ����*/
			memcpy(spGfHeader+i, "000600", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "6431", 4))/*ǩ��*/
			memcpy(spGfHeader+i, "SYS910", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "6433", 4))/*ǩ��*/
			memcpy(spGfHeader+i, "SYS920", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "6435", 4))/*�ļ��ϴ�֪ͨ*/
			memcpy(spGfHeader+i, "FL0010", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "6437", 4)) /*�ļ��ϴ�״̬��ѯ*/
			memcpy(spGfHeader+i, "FL0020", 6);
		else if(!memcmp(tIpcIntTxn->sTxnNum, "1997", 4)) /*��У��*/
			memcpy(spGfHeader+i, "000920", 6);
		else
			HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����������û�ҵ�[%4.4d]", tIpcIntTxn->sTxnNum);
		i +=6;
		
		memcpy(spGfHeader+i, "*", 1);   /* 12 ������ 1*/
		i +=1;
		
		memcpy(spGfHeader+i,"000001", 6);      /* 13  �ܰ��� 6*/
		i +=6;
		
		memcpy(spGfHeader+i, "000001", 6);   /* 14  ����� 6*/
		i +=6;
		
		memcpy(spGfHeader+i,"000", 3);    /* 15  ����¼�� 3*/
		i +=3;
		
		memcpy(spGfHeader+i, "0", 1);    /* 16  ���ı�ʶ 1*/
		i +=1;	

		/* �����ཻ�� */
		if(tIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_MANAGE)
		{
		    tIpcIntMng = (T_IpcIntMngDef *)sSrcMsgBuf;
		    
		    memcpy(spGfHeader+i, "0000000000",10);   /* 17  �����ն� 10*/
    		i +=10;
    		
    		memcpy(spGfHeader+i,GFHeaderCfg_CC.sLanId, 4);   /* 18  Դ���𷽱�ʶ 4*/
    		i += 4;

    		memset(spGfHeader+i,'0',22);
    		i+=16;
    		
    		memcpy(spGfHeader+i, tIpcIntMng->sSysTraceAuditNum, F011_LEN);   /* 19  Դ������ˮ��� 22*/		 						
    		i +=6; 		

    		memcpy(spGfHeader+i, tIpcIntMng->sMiscFlag,4);   /* 20  Դ�������� 8*/
    		i +=4;

    		memcpy(spGfHeader+i, tIpcIntMng->sTransmsnDateTime,4);
    		i +=4;
    		
    		memcpy(spGfHeader+i, tIpcIntMng->sTransmsnDateTime+4,6);   /* 21  Դ����ʱ�� 6*/
    		i +=6;
    		
    		memcpy(spGfHeader+i, "0000", 4);
    		i += 4;
    		memcpy(spGfHeader+i, tIpcIntMng->sSysTraceAuditNum,F011_LEN);    /* 22  ������ˮ 10*/
    		i += 6;
 
    		memcpy(spGfHeader+i, tIpcIntMng->sMiscFlag,8);   /* 23  �������� 8*/    		
    		i +=8;    		

    		memcpy(spGfHeader+i, tIpcIntMng->sMiscFlag+8,6);   /* 24  ����ʱ�� 6*/
    		i +=6;    		    		

    		memcpy(spGfHeader+i, GFHeaderCfg_CC.sUniTeller, 10);   /* 25  ͳһ��Ա�� 10*/
    		i +=10;
    		
		}
		else
		{
		    memcpy(spGfHeader+i, tIpcIntTxn->sCardAccptrTermnlId,sizeof(tIpcIntTxn->sCardAccptrTermnlId));   /* 17  �����ն� 10*/
    		i +=10;
    		
    		memcpy(spGfHeader+i,GFHeaderCfg_CC.sLanId, 4);   /* 18  Դ���𷽱�ʶ 4*/	
    		i += 4;

    		memset(spGfHeader+i,'0',22);
    		i+=16;
    		
    		memcpy(spGfHeader+i, tIpcIntTxn->sMisc+F007_LEN, F011_LEN);   /* 19  Դ������ˮ��� 22*/
    		i +=6;
    		
    		memcpy(spGfHeader+i, tIpcIntTxn->sMiscFlag,4);   /* 20  Դ�������� 8*/
    		i +=4;
    		
    		memcpy(spGfHeader+i, tIpcIntTxn->sMisc,4);
    		i +=4;
    		
    		memcpy(spGfHeader+i, tIpcIntTxn->sMisc+4,6);   /* 21  Դ����ʱ�� 6*/
    		i +=6;
    		
    		memcpy(spGfHeader+i, "0000", 4);
    		i += 4;
    		memcpy(spGfHeader+i, tIpcIntTxn->sSysTraceAuditNum,F011_LEN);    /* 22  ������ˮ 10*/
    		i += 6;
    		
    		memcpy(spGfHeader+i, tIpcIntTxn->sMiscFlag,8);   /* 23  �������� 8*/
    		i +=8;
    		
    		memcpy(spGfHeader+i, tIpcIntTxn->sMiscFlag+8,6);   /* 24  ����ʱ�� 6*/			
    		i +=6;
    		
    		memcpy(spGfHeader+i, tIpcIntTxn->sCardAccptrTermnlId,F041_LEN);   /* 25  ͳһ��Ա�� 10*/
    		i +=10;
		}	                                       

		i +=30;  /* 26  �����ʶλ 30*/
		
		i +=8;  /* 27  �������� 8*/
		
		i +=6;  /* 28  ����ʱ�� 6*/
		
		i +=2;  /* 29  ȷ���� 2*/
		
		i +=7;  /* 30  ��Ϣ���� 7*/
		
		memcpy(spGfHeader+i, GFHeaderCfg_CC.sSndId, 4);   /* 31  ���ͷ���ʶ 4*/
		i +=4;
		
		if(!memcmp(tIpcIntTxn->sTxnNum, "6435", 4) || !memcmp(tIpcIntTxn->sTxnNum, "6437", 4))
		    memcpy(spGfHeader+i, GFHeaderCfg_CC.sRcvId2, 4); /* 32  ���շ���ʶ 4*/
		else
		    memcpy(spGfHeader+i, GFHeaderCfg_CC.sRcvId1, 4); /* 32  ���շ���ʶ 4*/
		i +=4;
		
		i +=66;     /* 33  ����λ(�����sKeyRspֵ�����ɸ���) 66*/
		/* ���㷢����ͷ  end*/
		
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tIpcIntTxn->sGfHeader[%-256.256s]", tIpcIntTxn->sGfHeader);
		
        nReturnCode = BufChgOpr(nBufChgIndex, sSrcMsgBuf, sDestMsgBuf, ptBufChgRule);
        
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tIpcIntTxn->sGfHeader[%-256.256s]", tIpcIntTxn->sGfHeader);
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sDestMsgBuf:[%s]", sDestMsgBuf);
		if(nReturnCode)
			return nReturnCode;

		return 0;
	}

	/*====================����ͳһ���� - �ܿ�====================*/
	if(memcmp(sSrcMsgBuf+SRV_ID_LEN, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0)
	{
		tIpcIntTxn = (T_IpcIntTxnDef *)sSrcMsgBuf;
        spGfHeader=tIpcIntTxn->sGfHeader; /*Ϊ�����޸Ĺ㷢ͷ*/
        
		memset(saCompKey,0,sizeof(saCompKey));
		memcpy(saCompKey,tIpcIntTxn->sTxnNum,FLD_TXN_NUM_LEN);
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]", saCompKey);
		
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf, sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode)
			return nReturnCode;

		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "CvtCustInToOut.pnDestMsgLen[%d]", *pnDestMsgLen);

		/* ���㷢����ͷ  begin*/
		i=0;
		memset(spGfHeader, ' ', 256);      /*(����λ�����sKeyRspֵ�����ɸ���)*/
		
		memcpy(spGfHeader+i, GFHeaderCfg_ZK.sRunPri, 2);   /* 1 �������ȼ� 2*/
		i += 2;
		
		sprintf(spGfHeader+i, "%04d", *pnDestMsgLen-(SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN));    /* 2 ���ݱ��ĳ��� 4*/
		i +=4;
		
		
		memcpy(spGfHeader+i, GFHeaderCfg_ZK.sFwNum, 1);   /* 3 ת������ 1*/
		i +=1;
		
		memcpy(spGfHeader+i, GFHeaderCfg_ZK.sVerNo, 1);      /* 4 �汾�� 1*/
		i +=1;
		
		memcpy(spGfHeader+i, GFHeaderCfg_ZK.sToEnc, 1);      /* 5 ��Ѻ��ʶ 1*/
		i +=1;
		
		memcpy(spGfHeader+i, "0", 1);      /* 6 �ļ���ʶ 1*/
		i +=1;
		
		memcpy(spGfHeader+i, GFHeaderCfg_ZK.sChnlId, 3);    /* 7 ������ʶ 3*/
		i +=3;
		
		memcpy(spGfHeader+i, GFHeaderCfg_ZK.sChnlSeg1, 1);   /* 8 ����ϸ�� 1*/
		i +=1;
		
		memcpy(spGfHeader+i, GFHeaderCfg_ZK.sNetgateNo, 4);   /* 9 ���ر�� 4*/
		i +=4;
		
		memcpy(spGfHeader+i, GFHeaderCfg_ZK.sBusSys, 4);   /* 10 ҵ��ϵͳ 4*/
		i +=4;
		
		/* 11 �������� 6*/
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tIpcIntTxn->sTxnNum [%4.4s]", tIpcIntTxn->sTxnNum);
		if(memcmp(tIpcIntTxn->sTxnNum, "6405", 4) == 0)
	        memcpy(spGfHeader+i, "BAT601", 6);
	    else if(memcmp(tIpcIntTxn->sTxnNum, "6415", 4) == 0)
	        memcpy(spGfHeader+i, "BAT602", 6);
	    else if(memcmp(tIpcIntTxn->sTxnNum, "6425", 4) == 0)
	        memcpy(spGfHeader+i, "BAT603", 6);
	    else if(memcmp(tIpcIntTxn->sTxnNum, "6445", 4) == 0)
	        memcpy(spGfHeader+i, "ECH001", 6);
	    else if(memcmp(tIpcIntTxn->sTxnNum, "6455", 4) == 0)
	        memcpy(spGfHeader+i, "ECH002", 6);
	    else if(memcmp(tIpcIntTxn->sTxnNum, "1383", 4) == 0 ||
	            memcmp(tIpcIntTxn->sTxnNum, "1385", 4) == 0)
	        memcpy(spGfHeader+i, "DEP605", 6);
	    else if(memcmp(tIpcIntTxn->sTxnNum, "2383", 4) == 0 ||
	            memcmp(tIpcIntTxn->sTxnNum, "2385", 4) == 0)
	        memcpy(spGfHeader+i, "DEP606", 6);
		i +=6;

		memcpy(spGfHeader+i, "*", 1);   /* 12 ������ 1*/
		i +=1;

		memcpy(spGfHeader+i,"000001", 6);      /* 13  �ܰ��� 6*/
		i +=6;

		memcpy(spGfHeader+i, "000001", 6);   /* 14  ����� 6*/
		i +=6;

		memcpy(spGfHeader+i,"001", 3);    /* 15  ����¼�� 3*/
		i +=3;

		memcpy(spGfHeader+i, "0", 1);    /* 16  ���ı�ʶ 1*/
		i +=1;

		/* �����ཻ�� */
		if(tIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_MANAGE)
		{
		    tIpcIntMng = (T_IpcIntMngDef *)sSrcMsgBuf;

		    /*memcpy(spGfHeader+i, " ", 10);*/   /* 17  �����ն� 10*/
    		i +=10;

    		memcpy(spGfHeader+i,GFHeaderCfg_ZK.sLanId, 4);		/* 18 ���𷽱�ʶ 4*/
    		i += 4;

    		memset(spGfHeader+i,'0',22-F011_LEN-14);  /* 19  ������ˮ��� 22*/
    		i+=(22-F011_LEN-14);

    		memcpy(spGfHeader+i, tIpcIntMng->sMiscFlag, 14);   
    		i +=14;

    		memcpy(spGfHeader+i, tIpcIntMng->sSysTraceAuditNum, F011_LEN);   
    		i +=F011_LEN;

    		memcpy(spGfHeader+i, tIpcIntMng->sMiscFlag,8);   /* 20  �������� 8*/
    		i +=8;

    		memcpy(spGfHeader+i, tIpcIntMng->sMiscFlag+8,6);   /* 21  ����ʱ�� 6*/
    		i +=6;

    		/*memcpy(spGfHeader+i, " ",F011_LEN);     22  ������ˮ 10*/
    		i += 10;

    		/*memcpy(spGfHeader+i, " ",8);    23  �������� 8*/
    		i +=8;

    		/*memcpy(spGfHeader+i, " ",6);    24  ����ʱ�� 6*/			
    		i +=6;

    		if(tIpcIntMng->sInquryNum[0] != 0x00)
    		    memcpy(spGfHeader+i, tIpcIntMng->sInquryNum,10);   /* 25  ͳһ��Ա�� 10*/
    		i +=10;

    		memcpy(spGfHeader+i, tIpcIntMng->sTransmsnDateTime,F007_LEN);
            i +=F007_LEN;
            memcpy(spGfHeader+i, tIpcIntMng->sSysTraceAuditNum,F011_LEN);
            i +=F011_LEN;
		    i +=(30-F007_LEN-F011_LEN);  /* 26  �����ʶλ 30*/
		}
		else
		{
		    /*memcpy(spGfHeader+i, " ", 10);    17  �����ն� 10*/
    		i +=10;

    		memcpy(spGfHeader+i,GFHeaderCfg_ZK.sLanId, 4);		/* 18 ���𷽱�ʶ 4*/
    		i += 4;

    		memset(spGfHeader+i,'0',22-F011_LEN-14);  /* 19  ������ˮ��� 22*/
    		i+=(22-F011_LEN-14);

    		memcpy(spGfHeader+i, tIpcIntTxn->sMiscFlag, 14);
    		i +=14;

    		memcpy(spGfHeader+i, tIpcIntTxn->sSysTraceAuditNum, F011_LEN);   
    		i +=F011_LEN;

    		memcpy(spGfHeader+i, tIpcIntTxn->sMiscFlag,8);   /* 20  �������� 8*/
    		i +=8;

    		memcpy(spGfHeader+i, tIpcIntTxn->sMiscFlag+8,6);   /* 21  ����ʱ�� 6*/
    		i +=6;

    		/*memcpy(spGfHeader+i, " ",F011_LEN);     22  ������ˮ 10*/
    		i += 10;

    		/*memcpy(spGfHeader+i, " ",8);    23  �������� 8*/
    		i +=8;

    		/*memcpy(spGfHeader+i, " ",6);    24  ����ʱ�� 6*/			
    		i +=6;

    		/*memcpy(spGfHeader+i, " ",10);    25  ͳһ��Ա�� 10*/
    		i +=10;

    		memcpy(spGfHeader+i, tIpcIntTxn->sTransmsnDateTime,F007_LEN);
            i +=F007_LEN;
            memcpy(spGfHeader+i, tIpcIntTxn->sSysTraceAuditNum,F011_LEN);
            i +=F011_LEN;
            memcpy(spGfHeader+i, tIpcIntTxn->sAcqInstIdCode,8);
            i +=8;
            memcpy(spGfHeader+i, tIpcIntTxn->sProcessingCode,F003_LEN);
            i +=F003_LEN;
		    /*i +=(30-F007_LEN-F011_LEN);*/  /* 26  �����ʶλ 30*/
		}


		i +=8;  /* 27  �������� 8*/

		i +=6;  /* 28  ����ʱ�� 6*/

		i +=2;  /* 29  ȷ���� 2*/

		i +=7;  /* 30  ��Ϣ���� 7*/

		memcpy(spGfHeader+i,GFHeaderCfg_ZK.sSndId,4);   /* 31  ���ͷ���ʶ 4*/
		i +=4;

        memcpy(spGfHeader+i,GFHeaderCfg_ZK.sRcvId1,4);   /* 32  ���շ���ʶ 4*/
		i +=4;

		if(tIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_MANAGE)
		{
		    memcpy(spGfHeader+i, GFHeaderCfg_ZK.sTxnLanChnl,3); /* 33  ���׷������� 3*/
		    i +=3;
		}
		else
		{
		    HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tIpcIntTxn->sFldReserved[%14.14s]", tIpcIntTxn->sFldReserved);
		    if(memcmp(&tIpcIntTxn->sFldReserved[8], "03", 2) == 0 ||
		        memcmp(&tIpcIntTxn->sFldReserved[8], "10", 2) == 0)
		    {
		        memcpy(spGfHeader+i, "POS",3); /* 33  ���׷������� 3*/
		        i +=3;
		    }
		    else
		    {
		        memcpy(spGfHeader+i, "   ",3); /* 33  ���׷������� 3*/
		        i +=3;
		    }
	    }
		
		if(tIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_MANAGE)
		    memcpy(spGfHeader+i, tIpcIntMng->sMAC128 ,8); /* 34  MACУ��ֵ 8*/
		else
		    memcpy(spGfHeader+i, tIpcIntTxn->sMAC128 ,8); /* 34  MACУ��ֵ 8*/
		i +=8;

		i +=55;     /* 35  ����λ 55*/
		/* ���㷢����ͷ  end*/

		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tIpcIntTxn->sGfHeader[%-256.256s]", tIpcIntTxn->sGfHeader);

		nReturnCode = BufChgOpr(nBufChgIndex, sSrcMsgBuf, sDestMsgBuf, ptBufChgRule);

		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tIpcIntTxn->sGfHeader[%-256.256s]", tIpcIntTxn->sGfHeader);
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sDestMsgBuf:[%s]", sDestMsgBuf);
		if(nReturnCode)
			return nReturnCode;

		return 0;
	}

       /*=======================����ϵͳ========================*/

	if((memcmp(sSrcMsgBuf+SRV_ID_LEN,"1903",SRV_ID_LEN) == 0) )
	{
		pIpcBonusTxn = (T_IpcIntBonusDef *)sSrcMsgBuf;
		memset(saCompKey,0,sizeof(saCompKey));
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]", pIpcBonusTxn->sTxnNum);
		memcpy(saCompKey,pIpcBonusTxn->sTxnNum,FLD_TXN_NUM_LEN);

		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]", saCompKey);
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%4.4s]", sTxnNum);

		if(memcmp(saCompKey, "1825", 4) == 0)
			memcpy(saCompKey, "1815", 4);
		else if(memcmp(saCompKey, "2825", 4) == 0)
			memcpy(saCompKey, "2815", 4);
		else if(memcmp(saCompKey, "3825", 4) == 0)
			memcpy(saCompKey, "3815", 4);
		else if(memcmp(saCompKey, "4825", 4) == 0)
			memcpy(saCompKey, "4815", 4);
 
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
								sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode)
		{
            HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nReturnCode[%d]", nReturnCode );
			return nReturnCode;
		}    

		nReturnCode = BufChgOpr(nBufChgIndex,

								sSrcMsgBuf,

								sDestMsgBuf,

								ptBufChgRule);

		if(nReturnCode)

		{			

            HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nReturnCode[%d]", nReturnCode );

            return nReturnCode;

		}

		

		/* Debug��־ */

		nReturnCode = printPCSLog(sDestMsgBuf);



		return 0;

	}
	  /*=======================�̳ǻ���========================*/

	if((memcmp(sSrcMsgBuf+SRV_ID_LEN,"1831",SRV_ID_LEN) == 0) )
	{
		pIpcBonusTxn = (T_IpcIntBonusDef *)sSrcMsgBuf;
		memset(saCompKey,0,sizeof(saCompKey));
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]", pIpcBonusTxn->sTxnNum);
		memcpy(saCompKey,pIpcBonusTxn->sTxnNum,FLD_TXN_NUM_LEN);

		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "saCompKey[%s]", saCompKey);
		HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%4.4s]", sTxnNum);

		/*if(memcmp(saCompKey, "1825", 4) == 0)
			memcpy(saCompKey, "1815", 4);*/
 
		nReturnCode = IpcDftOpr(saCompKey, pnDestMsgLen, sDestMsgBuf,
								sTxnNum, &nBufChgIndex, ptIpcDftRule);
		if(nReturnCode)
		{
            HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nReturnCode[%d]", nReturnCode );
			return nReturnCode;
		}    

		nReturnCode = BufChgOpr(nBufChgIndex,

								sSrcMsgBuf,

								sDestMsgBuf,

								ptBufChgRule);

		if(nReturnCode)

		{			

            HtLog( "CvtCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nReturnCode[%d]", nReturnCode );

            return nReturnCode;

		}

		

		/* Debug��־ */

		nReturnCode = printPCSLog(sDestMsgBuf);



		return 0;

	}

	return -1;

}



int printPCSLog(char * sBuf)

{

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 

            "-------------------------------------------------------------------------------");

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ƣңϣ����� [%6.6s]", &sBuf[305]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ [%4.4s]", &sBuf[316]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ϵͳ��ˮ�� [%8.8s]", &sBuf[320]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��֧���� [%1.1s]", &sBuf[353]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����루������ϵͳ�� [%6.6s]", &sBuf[354]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������ڣ�������ϵͳ�� [%8.8s]", &sBuf[360]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ϵͳԭ�������� [%8.8s]", &sBuf[368]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���׽�� [%13.13s]", &sBuf[376]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������־->������ [%1.1s]", &sBuf[413]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���׿��� [%19.19s]", &sBuf[414]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���ʺ� [%19.19s]", &sBuf[433]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���������� [%4.4s]", &sBuf[556]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭRTV.REF.NO. [%12.12s]", &sBuf[604]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "RTV.REF.NO. [%12.12s]", &sBuf[621]);

    HtLog( "To.1701.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 

            "-------------------------------------------------------------------------------\n\n\n");

    

    return 0;

}

