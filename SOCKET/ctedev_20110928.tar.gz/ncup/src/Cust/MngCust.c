/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: MngCust.c                                                   */
/* DESCRIPTIONS: customrize transaction process                              */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include "MngCust.h"
#define PIN_KEY_TYPE                    1
#define KEY_INDEX                       "01"
#define DB_KEY_LEN                      16
#define MAC_KEY_TYPE                    2

int MngCustCopyMacElement (char *pcMacPos, char *sMacElement, int *pnMacElementLen)
{
	int		i;
	int		c;
	int		nLen;

	nLen = 0;
	for (i = 0; i < *pnMacElementLen; i++)
	{
		c = *(sMacElement+i);
		if (isdigit (c) || isupper (c))
			*(pcMacPos+nLen) = *(sMacElement+i);
		else
		{
			if (islower (c))
				*(pcMacPos+nLen) = (char)toupper (c);
			else
				break;
		}
		nLen++;
	}

	*pnMacElementLen = nLen;
	return 0;
}

int MngCustGenMacBlock (HSMOprDef *ptHsmOpr, T_IpcIntMngDef *ptIpcIntMng)
{
	char		sFuncName[] = "MngCustGenMacBlock";
	char		*pcMacPos;
	char		sTmpLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int		nLen;
	char    sLen[3+1];

	HtLog (gsMngCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin", sFuncName);

	/* MAC element including:
	   0, 7, 11, 39, 53, 70, 100 */
	memset (ptHsmOpr->saMacBlock, ' ', HSM_MAC_BLOCK_LEN_MAX);
	pcMacPos = ptHsmOpr->saMacBlock;

	/* field 0, msg type */
	nLen = F000_MSG_TYPE_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sMsgType, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 7, transmision date tiem */
	nLen = F007_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sTransmsnDateTime, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 11, ssn */
	nLen = F011_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sSysTraceAuditNum, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 39, response code */
	nLen = F039_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sRespCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 53, sSecurityRelatedInfo */
	nLen = F053_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sSecurityRelatedInfo, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 66, sSettlmtCode
	nLen = F066_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sSettlmtCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	/* field 70, sNetwkMgmtInfoCode */
	nLen = F070_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sNetwkMgmtInfoCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 82, sCreditsProcesFeeAmt
	nLen = F082_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sCreditsProcesFeeAmt, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	/* field 84, sDebitsProcesFeeAmt
	nLen = F084_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sDebitsProcesFeeAmt, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	/* field 86, sCreditsAmt
	nLen = F086_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sCreditsAmt, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	/* field 87, sCreditsRevsalAmt
	nLen = F087_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sCreditsRevsalAmt, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	/* field 88, sDebitsAmt
	nLen = F088_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sDebitsAmt, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	/* field 89, sDebitsRevsalAmt
	nLen = F089_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sDebitsRevsalAmt, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	/* field 97, sAmtNetSettlmt
	nLen = F097_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sAmtNetSettlmt, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	/* field 100, sRcvgInstIdCode */
	nLen = F100_LEN_LEN;
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sRcvgInstIdCodeLen, &nLen);
	pcMacPos = pcMacPos + nLen;
	/*nLen = F100_VAL_LEN;*/
	memset(sLen, 0, sizeof(sLen));
	memcpy(sLen, ptIpcIntMng->sRcvgInstIdCodeLen, F100_LEN_LEN);
	nLen = atoi(sLen);
	MngCustCopyMacElement (pcMacPos, ptIpcIntMng->sRcvgInstIdCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* get rid of the last space */
	pcMacPos--;

	/* set MAC block len */
	sprintf (sTmpLen, "%03d", pcMacPos - ptHsmOpr->saMacBlock);
	memcpy (ptHsmOpr->saMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);

	HtLog (gsMngCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end", sFuncName);
	return 0;
}

/*****************************************************************************************/
/* FUNC:   int MngCustGenerateMAC (T_IpcIntMngDef *ptIpcIntMng)                      */
/* INPUT:  ptIpcIntMng: �����Ӧ����                                                   */
/* OUTPUT: ptIpcIntMng: �����Ӧ����                                                   */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                           */
/* DESC:   ���øú�������MAC                                                             */
/*****************************************************************************************/
int MngCustGenerateMAC (T_IpcIntMngDef *ptIpcIntMng)
{
	char		sFuncName[] = "MngCustGenerateMAC";
	int		nReturnCode, i;
	HSMOprDef	tHsmOpr;

	HtLog(	gsMngCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);
	memset( (char*)&tHsmOpr , 0 , sizeof(tHsmOpr));
	nReturnCode = MngCustGenMacBlock (&tHsmOpr, ptIpcIntMng);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsMngCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SwtCustGenMacBlock error, %d", nReturnCode);
		return -1;
	}
	preprocess_mac_element( &tHsmOpr.saMacBlock[0], &tHsmOpr.saMacBlockLen[0]);
	tHsmOpr.saOprType = HSM_GENMACWITHKEY;
	tHsmOpr.saRout[0] = 'Y';
	memcpy(&tHsmOpr.saRout[1],"0001",4);
	memcpy(tHsmOpr.saEncWay,ptIpcIntMng->sSecurityRelatedInfo,F053_LEN);
	if(memcmp(ptIpcIntMng->sSecurityRelatedInfo,"16",2) == 0)
	{
		memcpy(tHsmOpr.saEnc,&ptIpcIntMng->sAddtnlDataPrivate[2], 16);
	}
	else
	{
		memcpy(tHsmOpr.saEnc,&ptIpcIntMng->sMsgSecurityCode[0], F096_LEN);
	}

	nReturnCode = nEncOpr (&tHsmOpr);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsMngCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
		return -1;
	}

	ptIpcIntMng->cF128Ind = FLAG_YES_C;
	memcpy (ptIpcIntMng->sMAC128, tHsmOpr.saEnc+16, F128_LEN);
	HtLog(	gsMngCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);

	return 0;
}

/*****************************************************************************************/
/* FUNC:   int MngCustChangeKey(T_IpcIntMngDef *ptIpcIntMng)                             */
/* INPUT:  ptIpcIntMng: �����Ӧ����                                                   */
/* OUTPUT: ptIpcIntMng: �����Ӧ����                                                   */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                           */
/* DESC:   ���øú�����������Կ��ZMKתΪLMK����                                          */
/*****************************************************************************************/
int MngCustChangeKey(T_IpcIntMngDef *ptIpcIntMng)
{
	char		sFuncName[] = "MngCustChangeKey";
	int		nReturnCode, i;
	HSMOprDef	tHsmOpr;

	HtLog(	gsMngCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);
	memset( (char*)&tHsmOpr , 0 , sizeof(tHsmOpr));
	nReturnCode = MngCustGenMacBlock (&tHsmOpr, ptIpcIntMng);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsMngCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SwtCustGenMacBlock error, %d", nReturnCode);
		return -1;
	}
	preprocess_mac_element( &tHsmOpr.saMacBlock[0], &tHsmOpr.saMacBlockLen[0]);
	tHsmOpr.saOprType = HSM_CHANGEKEY;
	tHsmOpr.saRout[0] = 'Y';
	memcpy(&tHsmOpr.saRout[1],"0001",4);
	memcpy(tHsmOpr.saEncWay,ptIpcIntMng->sSecurityRelatedInfo,F053_LEN);
	if(memcmp(ptIpcIntMng->sSecurityRelatedInfo,"16",2) == 0)
	{
		memcpy(tHsmOpr.saEnc,&ptIpcIntMng->sAddtnlDataPrivate[2], 16);
	}
	else
	{
		memcpy(tHsmOpr.saEnc,&ptIpcIntMng->sMsgSecurityCode[0], F096_LEN);
	}

	memcpy(&tHsmOpr.saEnc[16] ,ptIpcIntMng->sMAC128, 8);

	nReturnCode = nEncOpr (&tHsmOpr);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsMngCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
		return -1;
	}

	HtLog(	gsMngCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);

	return 0;
}
