#include "CtlCust.h"
/*#include <syms.h>*/

int nCtlCustReq(T_IpcIntTxnDef *, char *);
int nCtlCustRsp(T_IpcIntTxnDef *);
int nTxnStsDoReq(Tbl_clc_mon_Def*, char*, int, char, char*);
int nTxnStsDoRsp(Tbl_clc_mon_Def*, char*, int, char );
int n3DaysTxnSts(Tbl_clc_mon_Def*, Tbl_txn_sts_Def*, int);
void vSGet3DaysBefoDate(char *);
int	nMISCtlRspCode(char *, char *, char *);
int nCardCtlReq( T_IpcIntTxnDef*,Tbl_clc_mon_Def*,char*,char *);


Tbl_ctl_card_inf_Def	tCtlCardInf;
Tbl_ctl_mcht_inf_Def	tCtlMchtInf;
Tbl_risk_inf_Def		tRiskInf;
Tbl_auth_rsp_info_Def	tAuthRspInfo;
Cst_mcht_supp_Def		tMchtSupp;

int		nReturnCode;
#if 0
int nCtlCustReq(T_IpcIntTxnDef *ptIpcIntTxn, char *vpRspCode)
{
	int		llResult;
	double		lnSetSumAmt;
	double		lnSetSumNum, lnTxnSumNum;
	int		lnHaveFailTxn;

	Tbl_clc_mon_Def		ltTblClcMon, ltTblClcMon1;
	Tbl_txn_sts_Def		ltTblTxnSts;

	char	saTxnAmt[13];
	char    F100Vaule1[11];
	char     F100Len[2];
	char	caCtlCardInfAction[2], caCtlMchtInfAction[2];
  
	char	sCurrentTime[15];
  char  sa_limit_amount[12+1];
  char  sa_limit_num[9+1];
  char  sts_sa_txn_amt[12+1];
  char  sts_sa_txn_num[9+1];
  char  mon_sa_txn_amt[12+1];

	caCtlCardInfAction[0] = CClcFlagNormal;
	caCtlMchtInfAction[0] = CClcFlagNormal;
  memset(sa_limit_amount, 0, sizeof(sa_limit_amount));
  memset(sa_limit_num, 0, sizeof(sa_limit_num));
  memset(sts_sa_txn_amt, 0, sizeof(sts_sa_txn_amt));
  memset(sts_sa_txn_num, 0, sizeof(sts_sa_txn_num));
  memset(mon_sa_txn_amt, 0, sizeof(mon_sa_txn_amt));
	memset(sCurrentTime, 0, sizeof(sCurrentTime));
	CommonGetCurrentTime (sCurrentTime);

	/*��ʼ�����ս�����ˮ����¼�ṹltTblClcMon*/
	memset( &ltTblClcMon, 0x00, sizeof( ltTblClcMon ) );
	memcpy( ltTblClcMon.sa_step_key, ptIpcIntTxn->sKeyRevsal, KEY_REVSAL_LEN);
	memcpy( ltTblClcMon.sa_tpcs_key, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	memcpy( ltTblClcMon.sa_txn_card, ptIpcIntTxn->sPrimaryAcctNum, F002_VAL_LEN);
	memcpy( ltTblClcMon.sa_expr_date, ptIpcIntTxn->sDateExpr, F014_LEN);
	memcpy( ltTblClcMon.sa_mcht_no,  ptIpcIntTxn->sCardAccptrId, F042_LEN);
	memcpy( ltTblClcMon.sa_term_no,  ptIpcIntTxn->sCardAccptrTermnlId, F041_LEN);
	memcpy( ltTblClcMon.sa_txn_num,  ptIpcIntTxn->sTxnNum, FLD_TXN_NUM_LEN);
	memcpy( ltTblClcMon.sa_txn_date, sCurrentTime, F013_LEN);
	memcpy( ltTblClcMon.sa_txn_date+4, ptIpcIntTxn->sDateLocalTrans, F013_LEN);
	memcpy( ltTblClcMon.sa_txn_time, ptIpcIntTxn->sTimeLocalTrans, F012_LEN);
	memcpy( ltTblClcMon.sa_txn_amt,  ptIpcIntTxn->sAmtTrans, F004_LEN);
	memcpy( ltTblClcMon.sa_msg_src_id, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
	memcpy( ltTblClcMon.sa_msg_dest_id, ptIpcIntTxn->sMsgDestId, SRV_ID_LEN);
	memcpy( ltTblClcMon.sa_open_inst, ptIpcIntTxn->sOpenInst, 3);
	
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
	{
		int ilen = 0;
		memset(F100Vaule1,0,11);
		memset(F100Len,0,2);
		//����ԭ100����Ϣ
		memcpy(F100Len,ptIpcIntTxn->sRcvgInstIdCodeLen,2);
		memcpy(F100Vaule1,ptIpcIntTxn->sRcvgInstIdCode,11);
#if 0
		SwtCustTransferInstIdCode(ptIpcIntTxn,0);
#endif
		memcpy( ltTblClcMon.sa_stlm_inst, ptIpcIntTxn->sRcvgInstIdCode, 9);
		//�ָ�100����Ϣ
		memcpy(ptIpcIntTxn->sRcvgInstIdCodeLen,F100Len,2);
		memcpy(ptIpcIntTxn->sRcvgInstIdCode,F100Vaule1,11);
	}
	else
		memcpy( ltTblClcMon.sa_stlm_inst, ptIpcIntTxn->sAcqInstResvd+30, 9);
	
	memcpy( ltTblClcMon.sa_rsp_code, "  ", F039_LEN );
	ltTblClcMon.sa_clc_flag[0] = '0';

	/*if( ptIpcIntTxn->sTxnNum[0] != '2' )
	{	
		nReturnCode = nCardCtlReq(ptIpcIntTxn,&ltTblClcMon,vpRspCode);
		if(nReturnCode != 99)
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"pan: %19.19s in blacklist ,nCardCtlReq returncode value: %d",ptIpcIntTxn->sPrimaryAcctNum ,nReturnCode );
			return nReturnCode;
		}	
	}*/

	if( memcmp(&ptIpcIntTxn->sTxnNum[1], "02", 2) == 0 ||  memcmp(&ptIpcIntTxn->sTxnNum[1], "16", 2) == 0 ||
			memcmp(&ptIpcIntTxn->sTxnNum[1], "22", 2) == 0 || memcmp(&ptIpcIntTxn->sTxnNum[1], "42", 2) == 0 
			|| memcmp(&ptIpcIntTxn->sTxnNum[1], "47", 2) == 0 || memcmp(&ptIpcIntTxn->sTxnNum[1], "46", 2) == 0)
		return  0;


	/**************** �ܿؿ�����Ҫ��*/ 
	  memset(&tCtlCardInf, 0, sizeof(tCtlCardInf));
	  memcpy(tCtlCardInf.sa_card_no, ptIpcIntTxn->sPrimaryAcctNum, F002_VAL_LEN);
	  nReturnCode = DbsCTLCARDINF(DBS_SELECT1, &tCtlCardInf);
	  if(nReturnCode == 0)
	  {
		  memset(saTxnAmt, 0, sizeof(saTxnAmt));
		  memcpy(saTxnAmt, ptIpcIntTxn->sAmtTrans, F004_LEN);
		  ltTblClcMon.sa_clc_flag[0] = tCtlCardInf.sa_action[0];
		  sprintf(ltTblClcMon.sa_step_key,"%32.32s%s",ptIpcIntTxn->sKeyRevsal,"1");
		  sprintf(ltTblClcMon.sa_tpcs_key,"%32.32s%s",ptIpcIntTxn->sKeyRsp,"1");
		  HtLog("CtlCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"step_key:%s,tpcs_key:%s",
				ltTblClcMon.sa_step_key,ltTblClcMon.sa_tpcs_key);
	
		  if( ptIpcIntTxn->sTxnNum[0] != '2' )
			{	
				nReturnCode = nCardCtlReq(ptIpcIntTxn,&ltTblClcMon,vpRspCode,tCtlCardInf.sa_action);
				if(nReturnCode != 99)
				{
					HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"pan: %19.19s in blacklist ,nCardCtlReq returncode value: %d",
						ptIpcIntTxn->sPrimaryAcctNum ,nReturnCode );
				}	
			}

		  	llResult =  atoi((char *)saTxnAmt) - atoi((char *)tCtlCardInf.sa_limit_amt)*100;
		  	if( llResult > D_ZERO )
		  	{
				if (nReturnCode == 2)
				{
			  		nTxnStsDoReq( &ltTblClcMon, "BLK1", 4, CClcFlagReject, SARspCode042);
			  		memcpy( vpRspCode, SARspCode042, F039_LEN );
			  		return 2;
				}
				else if (nReturnCode == 0) /*Ԥ��*/
				{
					strcpy( ltTblClcMon.sa_clc_rsn1 ,"BLK1");
					strcpy( ltTblClcMon.sa_rsp_code, "00");
					nReturnCode = DbsClcMon(DBS_INSERT, &ltTblClcMon);

                	if(nReturnCode)
                	{
                    	HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							 "sqlca.sqlcode value %d", nReturnCode);
					}
				}
		  	}
			else if (nReturnCode == 2)
			{
				memcpy(vpRspCode, "  ",2);
			}
		  /*if(tCtlCardInf.sa_action[0] == CClcFlagReject)
		  {
			  nTxnStsDoReq( &ltTblClcMon,
			  SClcRsnCtlCardTxnRej,
			  strlen( SClcRsnCtlCardTxnRej ),
			  CClcFlagReject,
			  SARspCode043);
			  memcpy( vpRspCode, SARspCode043, F039_LEN );
			  return 2;
		  }*/
		  caCtlCardInfAction[0] = tCtlCardInf.sa_action[0];
	  }
	 /*************************/
	/*��ʼ���ܿ��̻���¼,�����ױ����е��̻���ȡ��*/
	memset(&tCtlMchtInf, 0, sizeof(tCtlMchtInf));
	memcpy(tCtlMchtInf.sa_mer_no, ptIpcIntTxn->sCardAccptrId, F042_LEN);
	/*��ѯ�ܿ��̻���Ϣ��,�����ܿ��̻�������Ӧ����*/

	nReturnCode = DbsCTLMCHTINF(DBS_SELECT1, &tCtlMchtInf);
	if(nReturnCode == 0)
	  {
		  memset(saTxnAmt, 0, sizeof(saTxnAmt));
		  memcpy(saTxnAmt, ptIpcIntTxn->sAmtTrans, F004_LEN);
		  ltTblClcMon.sa_clc_flag[0] = tCtlMchtInf.sa_action[0];
		  sprintf(ltTblClcMon.sa_step_key,"%32.32s%s",ptIpcIntTxn->sKeyRevsal,"2");
		  sprintf(ltTblClcMon.sa_tpcs_key,"%32.32s%s",ptIpcIntTxn->sKeyRsp,"2");
		  HtLog("CtlCust.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"step_key:%s,tpcs_key:%s",
				ltTblClcMon.sa_step_key,ltTblClcMon.sa_tpcs_key);

		  if( ptIpcIntTxn->sTxnNum[0] != '2' )
			{	
				nReturnCode = nCardCtlReq(ptIpcIntTxn,&ltTblClcMon,vpRspCode,tCtlMchtInf.sa_action);
				if(nReturnCode != 99)
				{
					HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"pan: %19.19s in blacklist ,nCardCtlReq returncode value: %d",
						ptIpcIntTxn->sPrimaryAcctNum ,nReturnCode );
				}	
			}
		  	llResult = atoi((char *)saTxnAmt) - atoi((char *)tCtlMchtInf.sa_limit_amt)*100 ;
		  	if( llResult > D_ZERO  )
		  	{
				if(nReturnCode == 2)
				{
			  		nTxnStsDoReq( &ltTblClcMon, "BLK2", 4, CClcFlagReject, SARspCode042);
			  		memcpy( vpRspCode, SARspCode042, F039_LEN );
			  		return 2;
				}
				else if (nReturnCode == 0) /*Ԥ��*/
				{
					strcpy( ltTblClcMon.sa_clc_rsn1 , "BLK2");
					strcpy( ltTblClcMon.sa_rsp_code, "00");
					nReturnCode = DbsClcMon(DBS_INSERT, &ltTblClcMon);

                	if(nReturnCode)
                	{
                    	HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							 "sqlca.sqlcode value %d", nReturnCode);
					}
				}
	      	}
			else if ( nReturnCode == 2) 
			{
				memcpy(vpRspCode, "  ",2);
			}
		  /*if(tCtlMchtInf.sa_action[0] == CClcFlagReject)
		  {
			  nTxnStsDoReq( &ltTblClcMon,
			  SClcRsnCtlCardTxnRej,
			  strlen( SClcRsnCtlCardTxnRej ),
			  CClcFlagReject,
			  SARspCode043);
			  memcpy( vpRspCode, SARspCode043, F039_LEN );
			  return 2;
		  }*/
		  caCtlMchtInfAction[0] = tCtlMchtInf.sa_action[0];
	  }
	

	
	
//	memset(&tMchtSupp, 0, sizeof(tMchtSupp));
//	memcpy(tMchtSupp.mcht_id, ptIpcIntTxn->sCardAccptrId, F042_LEN);

	/*��ѯ�̻���Ϣ��,�����ܿ��̻�������Ӧ����*/
//	nReturnCode = DbsMCHTSUPP(DBS_SELECT1, &tMchtSupp);
//	if (nReturnCode == 0 && nReturnCode != -1405 && tMchtSupp.mcht_status == 6 )	/* VIP �̻� */
//	{
//		return 0;
//	}
//	else if( nReturnCode == 0 && 
//			( tMchtSupp.mcht_status == 2 || tMchtSupp.mcht_status == 3 || 
//			  tMchtSupp.mcht_status == 4 || tMchtSupp.mcht_status == 5 ) )
//	{	/* �ܿ��̻� */
//		/* ȡ�ý��׽�� */
//		memset(saTxnAmt, 0, sizeof(saTxnAmt));
//		memcpy(saTxnAmt, ptIpcIntTxn->sAmtTrans, F004_LEN);
//
//		/* ��齻�׽���Ƿ���,����������ж����ж� */
//		llResult = atoi((char *)saTxnAmt) - atoi((char *)tMchtSupp.sa_limit_amt)*100;
//		if( llResult > 0 )
//		{
//			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
//					"%12.12s %12.12s", saTxnAmt, tMchtSupp.sa_limit_amt);
//
//			/* ����̻��Ƿ�Ϊ���ܾ��̻� */
//			if(tMchtSupp.sa_action[0] == CClcFlagReject)
//			{
//				nTxnStsDoReq( &ltTblClcMon,
//						SClcRsnCtlMchtAmtTooBig,
//						strlen( SClcRsnCtlMchtAmtTooBig ),
//						CClcFlagReject,
//						"93");
//				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
//						"SClcRsnCtlMchtAmtTooBig Txn Reject!");
//				memcpy( ptIpcIntTxn->sHostTransFee1, "ERR008", F038_LEN);
//				memcpy( vpRspCode, "93", F039_LEN );
//				return 2;
//			}
//		} 
//
//		/* ���̻�����ȡ���ܿ�״̬ */
//		caCtlMchtInfAction[0] = tMchtSupp.sa_action[0];
//	}
	/**************** �ܿؿ�����Ҫ��*/ 
	/*  if(caCtlCardInfAction[0] == CClcFlagClc)
	  {
		  if( (llResult = nTxnStsDoReq( &ltTblClcMon,
		  SClcRsnCtlCardNeedClc,
		  strlen( SClcRsnCtlCardNeedClc ),
		  CClcFlagClc,
		  SARspCode004 )) != 0 )
		  {
			  HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			  "Call nTxnStsDoReq error %d", llResult);
			  return 2;
		  }
		  return 1;
	  }*/
	 /*************************/

	/*if(caCtlMchtInfAction[0] == CClcFlagClc)
	{
		if( (llResult = nTxnStsDoReq( &ltTblClcMon,
						SClcRsnCtlMchtNeedClc,
						strlen( SClcRsnCtlMchtNeedClc ),
						CClcFlagClc,
						SARspCode004 )) != 0 )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Call nTxnStsDoReq error %d", llResult);
			return 2;
		}
		return 1;
	}*/
	HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"55555555[%9.9s]", ltTblClcMon.sa_stlm_inst);
	memset(ltTblClcMon.sa_clc_rsn1, 0x00, sizeof (ltTblClcMon.sa_clc_rsn1));
	memset(ltTblClcMon.sa_step_key, 0x00, sizeof (ltTblClcMon.sa_step_key));
	memset(ltTblClcMon.sa_tpcs_key, 0x00, sizeof (ltTblClcMon.sa_tpcs_key));
	memcpy( ltTblClcMon.sa_step_key, ptIpcIntTxn->sKeyRevsal, KEY_REVSAL_LEN);
	memcpy( ltTblClcMon.sa_tpcs_key, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	/*���н��׷���ģ��C1*/
	memset(&tRiskInf, 0, sizeof(tRiskInf));
	memcpy(tRiskInf.sa_branch_code, ltTblClcMon.sa_stlm_inst, 9);
	memcpy(tRiskInf.sa_model_kind, "C1", 2);
	nReturnCode = DbsRISKINF(DBS_SELECT1, &tRiskInf);
	if(nReturnCode == 0 && tRiskInf.sa_be_use[0] == CRiskUsed)
	{
		memset( &ltTblTxnSts, 0x00, sizeof( ltTblTxnSts ) );
		llResult = n3DaysTxnSts( &ltTblClcMon, &ltTblTxnSts, 1 );
		if( llResult )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Call nSSts3DaysTxn C1 error %d", llResult);
			return 2;
		}
		CommonRTrim(tRiskInf.sa_limit_amount);
    HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					   "risk limit_amount [%12s]", tRiskInf.sa_limit_amount);
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					   "ltTblTxnSts limit_amount [%12s]", ltTblTxnSts.sa_txn_amt);
		memcpy(sa_limit_amount,tRiskInf.sa_limit_amount,12);
		memcpy(sa_limit_num,tRiskInf.sa_limit_num,9);
		memcpy(sts_sa_txn_amt,ltTblTxnSts.sa_txn_amt,12);
		memcpy(mon_sa_txn_amt,ltTblClcMon.sa_txn_amt,12);
		memcpy(sts_sa_txn_num,ltTblTxnSts.sa_txn_num,9);
		lnSetSumAmt = atof(sa_limit_amount)*100;
		lnSetSumNum = atof(sa_limit_num);
HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Amt1 [%lf],Amd2[%lf],Amd3[%lf]", lnSetSumAmt,atof(sts_sa_txn_amt),atof(mon_sa_txn_amt));
		if( atof(sts_sa_txn_amt ) + 
				atof(mon_sa_txn_amt )>= lnSetSumAmt ||
				atof(sts_sa_txn_num ) + 1 >= lnSetSumNum )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"sa_txn_card = %19.19s sa_mcht_no = %15.15s sa_txn_amt = %12.12s", 
					ltTblClcMon.sa_txn_card, ltTblClcMon.sa_mcht_no, ltTblClcMon.sa_txn_amt);

			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"ltTblTxnSts.sa_txn_amt %12.12s ltTblTxnSts.sa_txn_num %8.8s", 
					ltTblTxnSts.sa_txn_amt, ltTblTxnSts.sa_txn_num);

			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"lnSetSumAmt = %ld lnSetSumNum = %ld", lnSetSumAmt, lnSetSumNum);

			if( (llResult = nTxnStsDoReq( &ltTblClcMon,
							"C1",
							2,
							tRiskInf.sa_action[0],
							SARspCode004 )) != 0 )
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"Call nTxnStsDoReq() C1 error %d", llResult);
				return 2;
			}
			if(tRiskInf.sa_action[0] == CClcFlagClc)
			{
				return 1;
			}
			else if(tRiskInf.sa_action[0] == CClcFlagReject)
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"C1 Txn Reject!");
				memcpy( ptIpcIntTxn->sHostTransFee1, "ERR0C1", F038_LEN);
				memcpy( vpRspCode, "05", F039_LEN );
				return 2;
			}
			else
			{
				return 0;
			}
		}
	}

	memset(&tRiskInf, 0, sizeof(tRiskInf));
	memcpy(tRiskInf.sa_branch_code, ltTblClcMon.sa_stlm_inst, 9);
	memcpy(tRiskInf.sa_model_kind, "C2", 2);
	nReturnCode = DbsRISKINF(DBS_SELECT1, &tRiskInf);
	if(nReturnCode == 0 && tRiskInf.sa_be_use[0] == CRiskUsed)
	{
		memset( &ltTblTxnSts, 0x00, sizeof( ltTblTxnSts ) );
		llResult = n3DaysTxnSts( &ltTblClcMon, &ltTblTxnSts, 2 );
		if( llResult )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Call n3DaysTxnSts C2 error %d", llResult);
			return 2;
		}

		lnSetSumAmt = atoi((char*)tRiskInf.sa_limit_amount)*100;
		lnSetSumNum = atoi((char*)tRiskInf.sa_limit_num);
		
HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Amt1 [%lf],Amd2[%lf],Amd3[%lf]", lnSetSumAmt,atoi((char *)ltTblTxnSts.sa_txn_amt ),atoi((char *)ltTblClcMon.sa_txn_amt ));
HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"TotalNum= %lf lnSetSumNum = %lf", atoi((char *)ltTblTxnSts.sa_txn_num ), lnSetSumNum);
		
		if( atoi((char *)ltTblTxnSts.sa_txn_amt ) + 
				atoi((char *)ltTblClcMon.sa_txn_amt ) >= lnSetSumAmt ||
				atoi((char *)ltTblTxnSts.sa_txn_num ) + 1 >= lnSetSumNum )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"sa_txn_card = %19.19s sa_mcht_no = %15.15s sa_txn_amt = %12.12s", 
					ltTblClcMon.sa_txn_card, ltTblClcMon.sa_mcht_no, ltTblClcMon.sa_txn_amt);

			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"ltTblTxnSts.sa_txn_amt %12.12s ltTblTxnSts.sa_txn_num %8.8s", 
					ltTblTxnSts.sa_txn_amt, ltTblTxnSts.sa_txn_num);

			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"lnSetSumAmt = %ld lnSetSumNum = %ld", lnSetSumAmt, lnSetSumNum);

			if( (llResult = nTxnStsDoReq( &ltTblClcMon,
							"C2",
							2,
							tRiskInf.sa_action[0],
							SARspCode004 )) != 0 )
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"Call nTxnStsDoReq() C2 error %d", llResult);
				return 2;
			}
			if(tRiskInf.sa_action[0] == CClcFlagClc)
			{
				return 1;
			}
			else if(tRiskInf.sa_action[0] == CClcFlagReject)
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"C2 Txn Reject!");
				memcpy( ptIpcIntTxn->sHostTransFee1, "ERR0C2", F038_LEN);
				memcpy( vpRspCode, "05", F039_LEN );
				return 2;
			}
			else
			{
				return 0;
			}
		}
	}

	memset(&tRiskInf, 0, sizeof(tRiskInf));
	memcpy(tRiskInf.sa_branch_code, ltTblClcMon.sa_stlm_inst, 9);
	memcpy(tRiskInf.sa_model_kind, "C3", 2);
	nReturnCode = DbsRISKINF(DBS_SELECT1, &tRiskInf);
	if(nReturnCode == 0 && tRiskInf.sa_be_use[0] == CRiskUsed)
	{
		memset( &ltTblTxnSts, 0x00, sizeof( ltTblTxnSts ) );
		llResult = n3DaysTxnSts( &ltTblClcMon, &ltTblTxnSts, 3 );
		if( llResult )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Call n3DaysTxnSts C3 error %d", llResult);
			return 2;
		}

		lnSetSumAmt = atoi((char*)tRiskInf.sa_limit_amount)*100;
		lnSetSumNum = atoi((char*)tRiskInf.sa_limit_num);

		if( atoi((char *)ltTblTxnSts.sa_txn_amt ) + 
				atoi((char *)ltTblClcMon.sa_txn_amt ) >= lnSetSumAmt ||
				atoi((char *)ltTblTxnSts.sa_txn_num ) + 1 >= lnSetSumNum )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"sa_txn_card = %19.19s sa_mcht_no = %15.15s sa_txn_amt = %12.12s", 
					ltTblClcMon.sa_txn_card, ltTblClcMon.sa_mcht_no, ltTblClcMon.sa_txn_amt);

			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"ltTblTxnSts.sa_txn_amt %12.12s ltTblTxnSts.sa_txn_num %8.8s", 
					ltTblTxnSts.sa_txn_amt, ltTblTxnSts.sa_txn_num);

			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"lnSetSumAmt = %ld lnSetSumNum = %ld", lnSetSumAmt, lnSetSumNum);

			if( (llResult = nTxnStsDoReq( &ltTblClcMon,
							"C3",
							2,
							tRiskInf.sa_action[0],
							SARspCode004 )) != 0 )
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"Call nTxnStsDoReq() C3 error %d", llResult);
				return 2;
			}
			if(tRiskInf.sa_action[0] == CClcFlagClc)
			{
				return 1;
			}
			else if(tRiskInf.sa_action[0] == CClcFlagReject)
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"C3 Txn Reject!");
				memcpy( ptIpcIntTxn->sHostTransFee1, "ERR0C3", F038_LEN);
				memcpy( vpRspCode, "05", F039_LEN );
				return 2;
			}
			else
			{
				return 0;
			}
		}
	}

	memset(&tRiskInf, 0, sizeof(tRiskInf));
	memcpy(tRiskInf.sa_branch_code, ltTblClcMon.sa_stlm_inst, 9);
	memcpy(tRiskInf.sa_model_kind, "M1", 2);
	nReturnCode = DbsRISKINF(DBS_SELECT1, &tRiskInf);
	if(nReturnCode == 0 && tRiskInf.sa_be_use[0] == CRiskUsed)
	{
		llResult = DbsClcMon( DBS_SELECT1, &ltTblClcMon );
		if( !llResult )
		{
			if( (llResult = nTxnStsDoReq( &ltTblClcMon,
							"M1",
							2,
							tRiskInf.sa_action[0],
							SARspCode004 )) != 0 )
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"Call nTxnStsDoReq() M1 error %d", llResult );
				return 2;
			}
			if(tRiskInf.sa_action[0] == CClcFlagClc)
			{
				return 1;
			}
			else if(tRiskInf.sa_action[0] == CClcFlagReject)
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"M1 Txn Reject!");
				memcpy( ptIpcIntTxn->sHostTransFee1, "ERR0M1", F038_LEN);
				memcpy( vpRspCode, "05", F039_LEN );
				return 2;
			}
			else
			{
				return 0;
			}
		}
		else if( llResult != DBS_NOTFOUND)
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Call DbsClcMon() M1 error %d", llResult);
			return 2;
		}
	}

	memset(&tRiskInf, 0, sizeof(tRiskInf));
	memcpy(tRiskInf.sa_branch_code, ltTblClcMon.sa_stlm_inst, 9);
	memcpy(tRiskInf.sa_model_kind, "M3", 2);
	nReturnCode = DbsRISKINF(DBS_SELECT1, &tRiskInf);
	if(nReturnCode == 0 && tRiskInf.sa_be_use[0] == CRiskUsed)
	{
		memset( &ltTblTxnSts, 0x00, sizeof( ltTblTxnSts ) );
		memcpy( ltTblTxnSts.sa_txn_card, ltTblClcMon.sa_txn_card, 19 );
		memcpy( ltTblTxnSts.sa_mcht_no,  ltTblClcMon.sa_mcht_no, 15 );
		memcpy( ltTblTxnSts.sa_txn_date, ltTblClcMon.sa_txn_date, 8 );
		ltTblTxnSts.sa_ins_flag[0] = '1';
		llResult = DbsTxnSts1( DBS_SELECT3, &ltTblTxnSts );
		if( !llResult )
		{
			lnSetSumAmt = atoi((char*)tRiskInf.sa_limit_amount)*100;
			lnSetSumNum = atoi((char*)tRiskInf.sa_limit_num);

			if( atoi((char *)ltTblTxnSts.sa_txn_amt ) + 
					atoi((char *)ltTblClcMon.sa_txn_amt ) >= lnSetSumAmt ||
					atoi((char *)ltTblTxnSts.sa_txn_num ) + 1 >= lnSetSumNum )
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"sa_txn_card = %19.19s sa_mcht_no = %15.15s", 
						"sa_txn_card = %19.19s sa_mcht_no = %15.15s sa_txn_amt = %12.12s", 
						ltTblClcMon.sa_txn_card, ltTblClcMon.sa_mcht_no, ltTblClcMon.sa_txn_amt);

				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"ltTblTxnSts.sa_txn_amt %12.12s ltTblTxnSts.sa_txn_num %8.8s", 
						ltTblTxnSts.sa_txn_amt, ltTblTxnSts.sa_txn_num);

				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"lnSetSumAmt = %ld lnSetSumNum = %ld", lnSetSumAmt, lnSetSumNum);

				if( (llResult=nTxnStsDoReq( &ltTblClcMon,
								"M3",
								2,
								tRiskInf.sa_action[0],
								SARspCode004 ) ) != 0 )
				{
					HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"Call nTxnStsDoReq() M3 error %d", llResult);
					return 2;
				}
				if(tRiskInf.sa_action[0] == CClcFlagClc)
				{
					return 1;
				}
				else if(tRiskInf.sa_action[0] == CClcFlagReject)
				{
					HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"M3 Txn Reject!");
					memcpy( ptIpcIntTxn->sHostTransFee1, "ERR0M3", F038_LEN);
					memcpy( vpRspCode, "05", F039_LEN );
					return 2;
				}
				else
				{
					return 0;
				}
			}
		}
		else if( llResult )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Call DbsTxnSts1() M3 error %d", llResult);
			return 2;
		}
	}

	memset(&tRiskInf, 0, sizeof(tRiskInf));
	memcpy(tRiskInf.sa_branch_code, ltTblClcMon.sa_stlm_inst, 9);
	memcpy(tRiskInf.sa_model_kind, "M5", 2);
	nReturnCode = DbsRISKINF(DBS_SELECT1, &tRiskInf);
	if(nReturnCode == 0 && tRiskInf.sa_be_use[0] == CRiskUsed)
	{
		lnSetSumAmt = atoi((char*)tRiskInf.sa_limit_amount)*100;
		if( atoi((char *)ltTblClcMon.sa_txn_amt ) > lnSetSumAmt )
		{
			memset( &ltTblClcMon1, 0x00, sizeof( ltTblClcMon ) );
			memcpy( &ltTblClcMon1, &ltTblClcMon, sizeof( ltTblClcMon ) );
			DbsClcMon( DBS_CURSOR1, &ltTblClcMon1 );
			if(llResult = DbsClcMon( DBS_OPEN1, &ltTblClcMon1))
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"Call DbsClcMon(DBS_OPEN1) M5 error %d", llResult);
				return 2;
			}
			lnTxnSumNum = 0; 
			lnHaveFailTxn = 0;
			while((llResult = DbsClcMon( DBS_FETCH1, &ltTblClcMon1)) == 0) 
			{
				lnTxnSumNum++;
				if( memcmp( ltTblClcMon1.sa_rsp_code, "00", F039_LEN ) )
					lnHaveFailTxn = 1;

				if( lnTxnSumNum >= 2 && lnHaveFailTxn )
				{
					DbsClcMon( DBS_CLOSE1, &ltTblClcMon1 );
					if( (llResult = nTxnStsDoReq( &ltTblClcMon,
									"M5",
									2,
									tRiskInf.sa_action[0],
									SARspCode004 ) ) != 0 )
					{
						HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
								"Call nTxnStsDoReq() M5 error %d", llResult);
						return 2;
					}
					if(tRiskInf.sa_action[0] == CClcFlagClc)
					{
						return 1;
					}
					else if(tRiskInf.sa_action[0] == CClcFlagReject)
					{
						HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
								"M5 Txn Reject!");
						memcpy( ptIpcIntTxn->sHostTransFee1, "ERR0M5", F038_LEN);
						memcpy( vpRspCode, "05", F039_LEN );
						return 2;
					}
					else
					{
						return 0;
					}
				}
			}
			DbsClcMon( DBS_CLOSE1, &ltTblClcMon );
		}
	}

	if( (llResult=nTxnStsDoReq( &ltTblClcMon,
					SClcRsnTransNormal,
					strlen( SClcRsnTransNormal ),
					CClcFlagNormal,
					SARspCode004 ) ) != 0 )
	{
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"Call nTxnStsDoReq Normal error %d", llResult);
		return 2;
	}

	return 0;
}
#endif

int nTxnStsDoReq(
		Tbl_clc_mon_Def*		vpTblClcMon,
		char*					vpClcRsn1,
		int						vlClcRsn1Len,
		char					vcClcFlag,
		char*					vpRspCode2 )
{
	int					llResult;

	memcpy( vpTblClcMon->sa_clc_rsn1 ,vpClcRsn1, vlClcRsn1Len );
	vpTblClcMon->sa_clc_flag[0]=vcClcFlag;

	if(memcmp(vpClcRsn1,SClcRsnTransNormal,strlen(vpClcRsn1) ))
	{
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"ClcState[%s]", vpClcRsn1);
		llResult = DbsClcMon( DBS_INSERT, vpTblClcMon );
		if( llResult )
		{
			HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"Call DbsClcMon(DBS_INSERT) error %d", llResult);
			return 1;
		}
	}
	

	llResult = DbsTxnSts( DBS_UPDATE1, vpTblClcMon );
	if( llResult )
	{
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"Call DbsTxnSts(DBS_UPDATE1) error %d", llResult);
		return 1;
	}
	return 0;
}
int nTxnStsDoReqNew(
		Tbl_clc_mon_Def*		vpTblClcMon,
		char*					vpClcRsn1,
		int						vlClcRsn1Len,
		char					vcClcFlag,
		char*					vpRspCode2 )
{
	int					llResult;

	memcpy( vpTblClcMon->sa_clc_rsn1 ,vpClcRsn1, vlClcRsn1Len );
	vpTblClcMon->sa_clc_flag[0]=vcClcFlag;

	HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ClcState[%s]", vpClcRsn1);
	llResult = DbsClcMon( DBS_INSERT, vpTblClcMon );
	if( llResult )
	{
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"Call DbsClcMon(DBS_INSERT) error %d", llResult);
		return 1;
	}

	llResult = DbsTxnSts( DBS_UPDATE1, vpTblClcMon );
	if( llResult )
	{
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"Call DbsTxnSts(DBS_UPDATE1) error %d", llResult);
		return 1;
	}
	return 0;
}


int n3DaysTxnSts(
		Tbl_clc_mon_Def*	vpTblClcMon,
		Tbl_txn_sts_Def*	vpTblTxnSts,
		int					vnModlInstr )
{
	int		llResult;
	int		lnOprType;

	memcpy( vpTblTxnSts->sa_txn_card, vpTblClcMon->sa_txn_card, 19 );
	vSGet3DaysBefoDate( vpTblTxnSts->sa_txn_date );

	switch( vnModlInstr )
	{
		case 1: 
			lnOprType = DBS_SELECT1;
			memcpy( vpTblTxnSts->sa_mcht_no, vpTblClcMon->sa_mcht_no, 15 );
			vpTblTxnSts->sa_ins_flag[0] = '1';
			break;

		case 2: 
			lnOprType = DBS_SELECT1;
			memcpy( vpTblTxnSts->sa_mcht_no, vpTblClcMon->sa_stlm_inst, 9 );
			vpTblTxnSts->sa_ins_flag[0] = '2';
			break;

		case 3: 
			lnOprType = DBS_SELECT2;
			vpTblTxnSts->sa_ins_flag[0] = '0';
			break;

		default: 
			return 1;
	}

	llResult = DbsTxnSts1( lnOprType, vpTblTxnSts );
	if( llResult )
	{
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"Call DbsTxnSts1 error %d", llResult);
		return 1;
	}
	return 0;
}

void  vSGet3DaysBefoDate( char * vpDate )
{
	time_t current;
	struct tm * tmLimit;

	time(&current);
	current -= 3l * 24l * 3600l;
	tmLimit = localtime(&current);
	sprintf( vpDate, "%04d%02d%02d",
			(tmLimit->tm_year + 1900),
			tmLimit->tm_mon + 1,
			tmLimit->tm_mday );
}
#if 0
int nCtlCustRsp(T_IpcIntTxnDef *ptIpcIntTxn)
{
	int					llResult;
	int					lnISAllCtlRspCodes;

	Tbl_clc_mon_Def		ltTblClcMon, ltTblClcMon1;

	if( memcmp(&ptIpcIntTxn->sTxnNum[1], "02", 2) == 0 ||  memcmp(&ptIpcIntTxn->sTxnNum[1], "16", 2) == 0 ||
			memcmp(&ptIpcIntTxn->sTxnNum[1], "22", 2) == 0 || memcmp(&ptIpcIntTxn->sTxnNum[1], "42", 2) == 0 )
		return  0;

	memset( &ltTblClcMon, 0x00, sizeof( ltTblClcMon ) );
	memcpy( ltTblClcMon.sa_tpcs_key, ptIpcIntTxn->sKeyRsp, KEY_REVSAL_LEN );

	llResult=DbsClcMon( DBS_SELECT2, &ltTblClcMon );
	if( llResult )
		return 0;

	memcpy( ltTblClcMon.sa_rsp_code, ptIpcIntTxn->sRespCode, F039_LEN );

	if(ptIpcIntTxn->cF038Ind == 'Y')
		memcpy( ltTblClcMon.sa_clc_rsn2, ptIpcIntTxn->sAuthrIdResp, F038_LEN );
	else
		memcpy( ltTblClcMon.sa_clc_rsn2, "      ", F038_LEN );

	llResult = DbsClcMon( DBS_UPDATE1, &ltTblClcMon );
	if( llResult )
	{
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"Call DbsClcMon(DBS_UPDATE1) error %d", llResult);
		return 2;
	}

	if( ltTblClcMon.sa_clc_flag[0] == CClcFlagClc )
		return 0;

	memset(&tRiskInf, 0, sizeof(tRiskInf));
	memcpy(tRiskInf.sa_branch_code, ltTblClcMon.sa_stlm_inst, 9);
	memcpy(tRiskInf.sa_model_kind, "M2", 2);
	nReturnCode = DbsRISKINF(DBS_SELECT1, &tRiskInf);
	if(nReturnCode == 0 && tRiskInf.sa_be_use[0] == CRiskUsed)
	{
		if( memcmp( ltTblClcMon.sa_rsp_code, "00", F039_LEN ) == 0 )
		{
			memset( &ltTblClcMon1, 0x00, sizeof( ltTblClcMon ) );
			memcpy( &ltTblClcMon1, &ltTblClcMon, sizeof( ltTblClcMon ) );
			DbsClcMon( DBS_CURSOR2, &ltTblClcMon1 );
			if(llResult = DbsClcMon( DBS_OPEN2, &ltTblClcMon1))
				return llResult;
			lnISAllCtlRspCodes = 0;
			while((llResult = DbsClcMon( DBS_FETCH2, &ltTblClcMon1)) == 0) 
			{
				if(!nMISCtlRspCode("M2", ltTblClcMon1.sa_msg_src_id, ltTblClcMon1.sa_rsp_code))
				{ 
					lnISAllCtlRspCodes = -1;
					break;
				}
				lnISAllCtlRspCodes = 1;
			}
			DbsClcMon( DBS_CLOSE2, &ltTblClcMon1 );
			if( lnISAllCtlRspCodes == 1 )
			{
				llResult = nTxnStsDoRsp( &ltTblClcMon, "M2", 2, tRiskInf.sa_action[0]);
				if( llResult )
				{
					HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"Call nTxnStsDoRsp M2 error %d", llResult);
					return 2;
				}
				if(tRiskInf.sa_action[0] == CClcFlagClc)
				{
					return 1;
				}
				else if(tRiskInf.sa_action[0] == CClcFlagReject)
				{
					HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"M2 Txn Reject!");
					memcpy( ptIpcIntTxn->sHostTransFee1, "ERR0M2", F038_LEN);
					memcpy( ptIpcIntTxn->sRespCode, "05", F039_LEN );
					return 2;
				}
				else
				{
					return 0;
				}
			}
		}
	}

	memset(&tRiskInf, 0, sizeof(tRiskInf));
	memcpy(tRiskInf.sa_branch_code, ltTblClcMon.sa_stlm_inst, 9);
	memcpy(tRiskInf.sa_model_kind, "M4", 2);
	nReturnCode = DbsRISKINF(DBS_SELECT1, &tRiskInf);
	if(nReturnCode == 0 && tRiskInf.sa_be_use[0] == CRiskUsed)
	{
		if( atoi((char *)ltTblClcMon.sa_txn_amt) >= atoi((char*)tRiskInf.sa_limit_amount) &&
				nMISCtlRspCode( "M4", ltTblClcMon.sa_msg_src_id, ltTblClcMon.sa_rsp_code ) ) 
		{
			llResult = nTxnStsDoRsp( &ltTblClcMon, "M4", 2, tRiskInf.sa_action[0] );
			if( llResult )
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"Call nTxnStsDoRsp M4 error %d", llResult);
				return 2;
			}
			if(tRiskInf.sa_action[0] == CClcFlagClc)
			{
				return 1;
			}
			else if(tRiskInf.sa_action[0] == CClcFlagReject)
			{
				HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"M4 Txn Reject!");
				memcpy( ptIpcIntTxn->sHostTransFee1, "ERR0M4", F038_LEN);
				memcpy( ptIpcIntTxn->sRespCode, "05", F039_LEN );
				return 2;
			}
			else
			{
				return 0;
			}
		}
	}
	return 0;
}
#endif
int	nTxnStsDoRsp(
		Tbl_clc_mon_Def*		vpTblClcMon,
		char*					vpClcRsn1,
		int						vlClcRsn1Len,
		char					vcClcFlag )
{
	int					llResult;

	memcpy( vpTblClcMon->sa_clc_rsn1, vpClcRsn1, vlClcRsn1Len );
	vpTblClcMon->sa_clc_flag[0] = vcClcFlag;

	llResult = DbsClcMon( DBS_UPDATE2, vpTblClcMon );
	if( llResult )
	{
		HtLog("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"Call DbsClcMon(DBS_UPDATE2) error %d", llResult);
		return 1;
	}

	return 0;
}

int	nMISCtlRspCode( char *vpMdlName, char *vpCardOrg, char *vpRspCode)
{
	char	saCardOrg[5];

	memset(saCardOrg, 0, sizeof(saCardOrg));
	memcpy(saCardOrg, vpCardOrg, 4);

	memset(&tAuthRspInfo, 0, sizeof(tAuthRspInfo));
	tAuthRspInfo.l_usage_key = atoi(saCardOrg);
	memcpy(tAuthRspInfo.sa_fc_auth_rsp_code, vpRspCode, 2);

	nReturnCode = DbsAUTHRSPINFO(DBS_SELECT1, &tAuthRspInfo);
	if(nReturnCode == 0)
	{
		if(memcmp(vpMdlName, "M2", 2) == 0 && tAuthRspInfo.sa_app_m2[0] == CRiskUsed)
		{
			return 1;
		}
		if(memcmp(vpMdlName, "M4", 2) == 0 && tAuthRspInfo.sa_app_m4[0] == CRiskUsed)
		{
			return 1;
		}
		return 0;
	}
	return 0;
}


int nCardCtlReq(
		            T_IpcIntTxnDef *ptIpcIntTxn,
		            Tbl_clc_mon_Def *vpTblClcMon,
		            char *vpRspCode,
					char *acAction
	              )
{
	char   	nSaAction[2];
	int   	nRet = 0;
	int 	iFlag = 0;
 	
	memset(nSaAction,0x00,sizeof(nSaAction));
	strncpy(nSaAction,acAction,1);
	iFlag = atoi(nSaAction);


	/*nRet = DbsBlackList(ptIpcIntTxn->sPrimaryAcctNum, &nSaAction);

	if (nRet)
	{
		HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"sqlca.sqlcode value %d", nRet);
		return -1;
	}*/

	HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "saAction: %d", iFlag);
	if(iFlag)
	{
		switch (iFlag)
		{
			/*��û��*/
			case 1:
				memcpy (vpRspCode, "04", F039_LEN);
				memcpy( vpTblClcMon->sa_rsp_code, "04", F039_LEN);

				HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"pan: %19.19s Pick-up", ptIpcIntTxn->sPrimaryAcctNum);
						
				/*nRet = DbsClcMon(DBS_INSERT, vpTblClcMon);
				
				if(nRet)
				{
					HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							"sqlca.sqlcode value %d", nRet);
					return -1;
				}*/	
				return 2;
			/*��ѯ������*/	
			case 2:	
				memcpy (vpRspCode, "01", F039_LEN);
				memcpy(vpTblClcMon->sa_rsp_code, "01", F039_LEN);

				HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"pan: %19.19s Refer to card issuer", ptIpcIntTxn->sPrimaryAcctNum);
						
				/*nRet = DbsClcMon(DBS_INSERT, vpTblClcMon);

				if(nRet)
				{
					HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							"sqlca.sqlcode value %d", nRet);
					return -1;
				}*/	
				return 2;
			/*����ͨ����Ԥ��*/	
			case 3:
				if( memcmp(&ptIpcIntTxn->sTxnNum[1], "02", 2) == 0 ||
						memcmp(&ptIpcIntTxn->sTxnNum[1], "07", 2) == 0 )
				{				
					HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							"this transaction is from atm");
							
					memcpy( vpTblClcMon->sa_rsp_code, "00", F039_LEN);
				}

				HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"pan: %19.19s transaction approved , but record this transaction into the BLACKLIST", ptIpcIntTxn->sPrimaryAcctNum);
				
				/*nRet = DbsClcMon(DBS_INSERT, vpTblClcMon);

				if(nRet)
				{
					HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							"sqlca.sqlcode value %d", nRet);
				}*/
				return 0;
			/*�ü�¼�Ѵӷ��ռ�ر���ɾ��������ͨ��*/	
			case 4:
				HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"pan: %19.19s has been deleted from the BLACKLIST", ptIpcIntTxn->sPrimaryAcctNum);
				return 99;
			default:
				HtLog ("CtlCust.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"SaAction error value : %d ", nSaAction);
				return -1;	
		}
	}
	return 99;
}                   
