/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: SwtCommon.c                                                 */
/* DESCRIPTIONS: handle normal req from CUP and its rsp from host            */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-14  YU TONG        Initialize                                     */
/*****************************************************************************/
static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Cust/SwtCommon.c,v 1.1.1.1.4.2 2011/09/23 02:54:34 ctedev Exp $";

#include "SwtCommon.h"

void SetToTime(int nRouteIndex);

/*****************************************************************************/
/* FUNC:   double DecRound(double value,int dot)                             */
/* INPUT:  value: Ҫ����ת����˫���ȸ�������                                 */
/*         dot	: ��������Ҫ������λ��                                       */
/* OUTPUT: NULL                                                              */
/* RETURN: �ɹ���ת���������                                                */
/* DESC	 : ��������ת������                                                  */
/*****************************************************************************/

double DecRound(double value,int dot)
{
	char ss[40],ss1[40];
	double aa;

	sprintf(ss1,"%s%dlf","%.",dot);	
	if(value>=0) /* ���C���Ե������������� */
	    aa=value+0.00000001;
	else
	    aa=value-0.00000001;
	sprintf(ss,ss1,aa);	
	aa=atof(ss);	
	return aa;
} 
int InitTblTxn (Tbl_txn_Def *ptTxn)
{
	char sCurrentTime[15];

	/* init ptTxn to all 0x00,
	   set revsal_flag, cancel_flag to '-', batch_flag to FLAG_NO_C
	   set revsal_ssn, cancel_ssn, batch_date, misc_2 to all 0x00 */
	memset ((char *)ptTxn, 0, sizeof (*ptTxn));

	memcpy (ptTxn->trans_state,    TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN);
	memset (ptTxn->revsal_flag      , REV_CAN_FLAG_NULL, 1);
	memset (ptTxn->cancel_flag      , REV_CAN_FLAG_NULL, 1);
	memcpy (ptTxn->batch_flag       , FLAG_NO, 1);
	memset (ptTxn->amt_return       , '0', sizeof (ptTxn->amt_return)-1 );

	/* set inst_date, inst_time to current db date time */
	/*CommonGetCurrentTime (sCurrentTime);*/
	memcpy (ptTxn->inst_date        , gsTimeCurTs, 8);
	memcpy (ptTxn->inst_time        , gsTimeCurTs+8, 6);

	return 0;
}

/*****************************************************************************/
/* FUNC:   int SetTransType (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn)*/
/* INPUT:  ptIpcIntTxn: ������, ��ʽ���ڲ���IPC�ṹ                        */
/* OUTPUT: ptTxn: ��Ӧ��tbl_txn�ļ�¼                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ptIpcIntTxn��60��������дptTxn��trans_type                      */
/*****************************************************************************/
int SetTransType (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn )
{
	char        sFuncName[] = "SetTransType";
	char        sF060Len[F060_LEN_LEN+1];
	T_F060Def    tF060Val;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	if (!memcmp(ptIpcIntTxn->sFldReservedLen, "000", F060_LEN_LEN))
	{
		memcpy(ptIpcIntTxn->sFldReservedLen, "014", F060_LEN_LEN);
		memcpy(ptIpcIntTxn->sFldReserved, "00000000010000", 14);
	}
	memcpy(sF060Len, ptIpcIntTxn->sFldReservedLen, F060_LEN_LEN);
	sF060Len[F060_LEN_LEN] = 0;
	memset(&tF060Val, 0, sizeof(tF060Val));
	memcpy(&tF060Val, ptIpcIntTxn->sFldReserved, atoi(sF060Len));

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "LEN[%3.3s].",
			ptIpcIntTxn->sFldReservedLen);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "LEN[%14.14s].",
			ptIpcIntTxn->sFldReserved);

	if(!memcmp(tF060Val.sF060ChannelType, CHANNEL_TYPE_CNT, 2))
	{
		memcpy (ptIpcIntTxn->sTransType, TRANS_TYPE_GM, FLD_TRANS_TYPE_LEN);
	}
	else if(!memcmp(tF060Val.sF060ChannelType, CHANNEL_TYPE_CDM, 2) || 
	        !memcmp(tF060Val.sF060ChannelType, CHANNEL_TYPE_ATM, 2))
	{
	    memcpy (ptIpcIntTxn->sTransType, TRANS_TYPE_ATM, FLD_TRANS_TYPE_LEN);
	}
	else if(!memcmp(tF060Val.sF060ChannelType, CHANNEL_TYPE_UNK, 2)|| 
	        !memcmp(tF060Val.sF060ChannelType, CHANNEL_TYPE_POS, 2)|| 
	        !memcmp(tF060Val.sF060ChannelType, "09", 2)|| 
	        !memcmp(tF060Val.sF060ChannelType, "17", 2)|| 
	        !memcmp(tF060Val.sF060ChannelType, "39", 2)|| 
	        !memcmp(tF060Val.sF060ChannelType, "47", 2))
	{
	    memcpy (ptIpcIntTxn->sTransType, TRANS_TYPE_POS, FLD_TRANS_TYPE_LEN);
	}
	else if(!memcmp(tF060Val.sF060ChannelType, CHANNEL_TYPE_INTNT, 2))
	{
	    memcpy (ptIpcIntTxn->sTransType, TRANS_TYPE_NET, FLD_TRANS_TYPE_LEN);
	}
	else
	{
	    memcpy (ptIpcIntTxn->sTransType, TRANS_TYPE_OTHER, FLD_TRANS_TYPE_LEN);
	    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "unknown channel type, %2.2s.", tF060Val.sF060ChannelType);
	}

	memcpy (ptTxn->trans_type, ptIpcIntTxn->sTransType, FLD_TRANS_TYPE_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

	return 0;
}

/*****************************************************************************/
/* FUNC:   int MoveIpc2Txn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn )*/
/* INPUT:  ptIpcIntTxn: ������, ��ʽ���ڲ���IPC�ṹ                        */
/* OUTPUT: ptTxn: ��Ӧ��tbl_txn�ļ�¼                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ptIpcIntTxn������дptTxn                                        */
/*****************************************************************************/
int MoveIpc2Txn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn )
{
	char    sFuncName[] = "MoveIpc2Txn";
	char    sCurrentTime[15];
	char    *Track2P;
	int        nReturnCode;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDT_REQ:
		case TXN_NUM_TDB_REQ:
		case TXN_NUM_BDB_REQ:
		case TXN_NUM_CBDB_REQ:
			InitTblTxn (ptTxn);

    /***********************************************************
    * set misc_2 time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
        if (gnTimeOutFlag)
            sprintf(ptTxn->batch_date, "%1.1d%1.1d", 1 , atoi(getenv(SRV_USAGE_KEY)));
        else
           sprintf(ptTxn->batch_date, "%1.1d%1.1d", 0 ,atoi(getenv(SRV_USAGE_KEY)));
        memcpy (ptTxn->misc_2        , gsTimeOutTs    , 26);
    
    
			/* ����revsal_flag, cancel_flag��ʼֵ */
			switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
			{
				case TXN_NUM_NORMAL:
				case TXN_NUM_CANCEL:
					memset (ptTxn->revsal_flag      , REV_CAN_FLAG_NORMAL, 1);
					memset (ptTxn->cancel_flag      , REV_CAN_FLAG_NORMAL, 1);
					break;
				case TXN_NUM_REVSAL:
				case TXN_NUM_CANCEL_REVSAL:
				case TXN_NUM_NOTICE:
					break;
			}

			if (ptIpcIntTxn->sTransType[0] == ' ')
			{
				nReturnCode = SetTransType (ptIpcIntTxn, ptTxn);
				if (nReturnCode)
				{
					HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SetTransType error, %d.", nReturnCode);
					return -1;
				}
			}
			else
				memcpy (ptTxn->trans_type, ptIpcIntTxn->sTransType, FLD_TRANS_TYPE_LEN);

			memcpy (ptTxn->sys_seq_num      , ptIpcIntTxn->sSysSeqNum            , F011_LEN);
			memcpy (ptTxn->msg_src_id       , ptIpcIntTxn->sMsgSrcId            , SRV_ID_LEN);
			memcpy (ptTxn->txn_num          , ptIpcIntTxn->sTxnNum                , FLD_TXN_NUM_LEN);
			memcpy (ptTxn->trans_code       , ptIpcIntTxn->sTransCode            , FLD_TXN_CODE_LEN);

			memcpy (ptTxn->key_rsp            , ptIpcIntTxn->sKeyRsp                , KEY_RSP_LEN);
			memcpy (ptTxn->key_revsal        , ptIpcIntTxn->sKeyRevsal            , KEY_REVSAL_LEN);
			memcpy (ptTxn->key_cancel        , ptIpcIntTxn->sKeyCancel            , KEY_CANCEL_LEN);

			memcpy (ptTxn->host_date        , ptIpcIntTxn->sHostDate            , FLD_HOST_DATE_LEN);
			memcpy (ptTxn->host_ssn         , ptIpcIntTxn->sHostSSN                , FLD_HOST_SSN_LEN);
			memcpy (ptTxn->term_ssn         , ptIpcIntTxn->sTermSSN                , FLD_HOST_SSN_LEN);
			memcpy (ptTxn->header_buf       , ptIpcIntTxn->sHeaderBuf            , HEADER_BUF_LEN);
			memcpy (ptTxn->gf_header        , ptIpcIntTxn->sGfHeader            , FLD_GF_HEADER);
			memcpy (ptTxn->msg_type         , ptIpcIntTxn->sMsgType                , F000_MSG_TYPE_LEN);
			if (ptIpcIntTxn->cF002Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->pan_len          , ptIpcIntTxn->sPrimaryAcctNumLen    , F002_LEN_LEN);
				memcpy (ptTxn->pan              , ptIpcIntTxn->sPrimaryAcctNum        , F002_VAL_LEN);
			}
			else
			{
				memset (ptTxn->pan_len          , ' ', F002_LEN_LEN);
				memset (ptTxn->pan              , ' ', F002_VAL_LEN);
			}
			memcpy (ptTxn->processing_code  , ptIpcIntTxn->sProcessingCode        , F003_LEN);
			memcpy (ptTxn->amt_trans        , ptIpcIntTxn->sAmtTrans            , F004_LEN);
			memcpy (ptTxn->amt_settlmt      , ptIpcIntTxn->sAmtSettlmt            , F005_LEN);
			memcpy (ptTxn->amt_cdhldr_bil   , ptIpcIntTxn->sAmtCdhldrBil        , F006_LEN);
			memcpy (ptTxn->trans_date_time  , ptIpcIntTxn->sTransmsnDateTime    , F007_LEN);
			memcpy (ptTxn->conv_rate_stlm   , ptIpcIntTxn->sConvRateSettlmt        , F009_LEN);
			memcpy (ptTxn->conv_rate_cdhldr , ptIpcIntTxn->sConvRateCdhldrBil    , F010_LEN);
			memcpy (ptTxn->cup_ssn          , ptIpcIntTxn->sSysTraceAuditNum    , F011_LEN);
			memcpy (ptTxn->time_local_trans , ptIpcIntTxn->sTimeLocalTrans        , F012_LEN);
			memcpy (ptTxn->date_local_trans , ptIpcIntTxn->sDateLocalTrans        , F013_LEN);
			
		 	memcpy (ptTxn->date_settlmt     , ptIpcIntTxn->sDateSettlmt            , F015_LEN);		 		
			memcpy (ptTxn->date_conv        , ptIpcIntTxn->sDateConv            , F016_LEN);
			memcpy (ptTxn->mchnt_type       , ptIpcIntTxn->sMchntType            , F018_LEN);
			memcpy (ptTxn->acq_cntry_code   , ptIpcIntTxn->sAcqInstCntryCode    , F019_LEN);
			memcpy (ptTxn->pos_entry_mode   , ptIpcIntTxn->sPosEntryModeCode    , F022_LEN);
			memcpy (ptTxn->pos_cond_code    , ptIpcIntTxn->sPosCondCode            , F025_LEN);
			if (ptIpcIntTxn->cF026Ind == FLAG_YES_C)
				memcpy (ptTxn->pos_pin_cap_code , ptIpcIntTxn->sPosPinCaptrCode        , F026_LEN);
			else
				memset (ptTxn->pos_pin_cap_code , ' ', F026_LEN);
			if (ptIpcIntTxn->cF028Ind == FLAG_YES_C)
				memcpy (ptTxn->amt_trans_fee    , ptIpcIntTxn->sAmtTransFee            , F028_LEN);
			else
				memset (ptTxn->amt_trans_fee    , ' ', F028_LEN);
			memcpy (ptTxn->acq_inst_id_code , ptIpcIntTxn->sAcqInstIdCode        , F032_VAL_LEN);
			memcpy (ptTxn->fwd_inst_id_code , ptIpcIntTxn->sFwdInstIdCode        , F033_VAL_LEN);
			memcpy (ptTxn->retrivl_ref      , ptIpcIntTxn->sRetrivlRefNum        , F037_LEN);
			if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
				memcpy (ptTxn->authr_id_resp    , ptIpcIntTxn->sAuthrIdResp            , F038_LEN);
			else
				memset (ptTxn->authr_id_resp    , ' ', F038_LEN);
			memcpy (ptTxn->resp_code        , ptIpcIntTxn->sRespCode            , F039_LEN);
			memcpy (ptTxn->card_accp_term_id, ptIpcIntTxn->sCardAccptrTermnlId    , F041_LEN);
			memcpy (ptTxn->card_accp_id     , ptIpcIntTxn->sCardAccptrId        , F042_LEN);
			memcpy (ptTxn->card_accp_name   , ptIpcIntTxn->sCardAccptrNameLoc    , F043_LEN);
			if (ptIpcIntTxn->cF044Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->addrsp_data_len  , ptIpcIntTxn->sAddtnlRespCodeLen    , F044_LEN_LEN);
				memcpy (ptTxn->addrsp_data      , ptIpcIntTxn->sAddtnlRespCode        , F044_VAL_LEN);
			}
			else
			{
				HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "48len %.3s", ptIpcIntTxn->sAddtnlDataPrivateLen);
				memset(ptTxn->addrsp_data_len , ' ', F044_LEN_LEN);
				memset (ptTxn->addrsp_data      , ' ' , F044_VAL_LEN);
			}
			if (ptIpcIntTxn->cF048Ind == FLAG_YES_C)
			{
			  memcpy (ptTxn->addtnl_data_len  , ptIpcIntTxn->sAddtnlDataPrivateLen    , F048_LEN_LEN);
		      memcpy (ptTxn->addtnl_data      , ptIpcIntTxn->sAddtnlDataPrivate        , F048_VAL_LEN);
			}
			else
			{
				HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "48len %.3s", ptIpcIntTxn->sAddtnlDataPrivateLen);
				memset(ptTxn->addtnl_data_len  , ' ', F048_LEN_LEN);
				memset (ptTxn->addtnl_data      , ' ' , F048_VAL_LEN);
			}
			memcpy(ptTxn->addint_data,ptIpcIntTxn->sF046Value,F046_VAL_LEN);
			memcpy (ptTxn->currcy_code_trans, ptIpcIntTxn->sCurrcyCodeTrans        , F049_LEN);
			memcpy (ptTxn->currcy_code_stlm , ptIpcIntTxn->sCurrcyCodeSettlmt    , F050_LEN);
			memcpy (ptTxn->currcy_code_chldr, ptIpcIntTxn->sCurrcyCodeCdhldrBil    , F051_LEN);
			if (ptIpcIntTxn->cF054Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->addtnl_amt_len   , ptIpcIntTxn->sAddtnlAmtLen        , F054_LEN_LEN);
				memcpy (ptTxn->addtnl_amt       , ptIpcIntTxn->sAddtnlAmt            , F054_VAL_DB_LEN);
			}
			else
			{
				memset (ptTxn->addtnl_amt_len   , ' ', F054_LEN_LEN);
				memset (ptTxn->addtnl_amt       , ' ', F054_VAL_DB_LEN);
			}
			memcpy (ptTxn->fld_reserved_len , ptIpcIntTxn->sFldReservedLen        , F060_LEN_LEN);
			memcpy (ptTxn->fld_reserved     , ptIpcIntTxn->sFldReserved            , F060_VAL_LEN);
			memcpy (ptTxn->ch_auth_info_len , ptIpcIntTxn->sChAuthInfoLen        , F061_LEN_LEN);
			memcpy (ptTxn->ch_auth_info     , ptIpcIntTxn->sChAuthInfo            , F061_VAL_LEN);
			if (ptIpcIntTxn->cF062Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->switch_data_len  , ptIpcIntTxn->sSwitchingDataLen    , F062_LEN_LEN);
				memcpy (ptTxn->switch_data      , ptIpcIntTxn->sSwitchingData        , F062_VAL_LEN);
			}
			else
			{
				memset (ptTxn->switch_data_len  , ' ', F062_LEN_LEN);
				memset (ptTxn->switch_data      , ' ', F062_VAL_LEN);
			}
			memcpy (ptTxn->orig_data_elemts , ptIpcIntTxn->sOrigDataElemts        , F090_LEN);
			memcpy (ptTxn->replacement_amts , ptIpcIntTxn->sReplacementAmts        , F095_LEN);
			
			memcpy (ptTxn->rcvg_code_len    , ptIpcIntTxn->sRcvgInstIdCodeLen    , F100_LEN_LEN);
			memcpy (ptTxn->rcvg_code        , ptIpcIntTxn->sRcvgInstIdCode        , F100_VAL_LEN);
			
			
			if (ptIpcIntTxn->cF102Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->acct_id1_len     , ptIpcIntTxn->sAcctId1Len            , F102_LEN_LEN);
				memcpy (ptTxn->acct_id1         , ptIpcIntTxn->sAcctId1                , F102_VAL_LEN);
			}
			else
			{
				memset (ptTxn->acct_id1_len     , ' ', F102_LEN_LEN);
				memset (ptTxn->acct_id1         , ' ', F102_VAL_LEN);
			}
			if (ptIpcIntTxn->cF103Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->acct_id2_len     , ptIpcIntTxn->sAcctId2Len            , F103_LEN_LEN);
				memcpy (ptTxn->acct_id2         , ptIpcIntTxn->sAcctId2                , F103_VAL_LEN);
			}
			else
			{
				memset (ptTxn->acct_id2_len     , ' ', F103_LEN_LEN);
				memset (ptTxn->acct_id2         , ' ', F103_VAL_LEN);
			}
			if (ptIpcIntTxn->cF104Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->trans_descrpt_len, ptIpcIntTxn->sTransDescrptLen        , F104_LEN_LEN);
				memcpy (ptTxn->trans_descrpt    , ptIpcIntTxn->sTransDescrpt        , F104_VAL_LEN);
			}
			else
			{
				memset (ptTxn->trans_descrpt_len, ' ', F104_LEN_LEN);
				memset (ptTxn->trans_descrpt    , ' ', F104_VAL_LEN);
			}
			if (ptIpcIntTxn->cF121Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->cup_swresved_len , ptIpcIntTxn->sNationalSwResvedLen    , F121_LEN_LEN);
				memcpy (ptTxn->cup_swresved     , ptIpcIntTxn->sNationalSwResved    , F121_VAL_LEN);
			}
			else
			{
				memset (ptTxn->cup_swresved_len , ' ', F121_LEN_LEN);
				memset (ptTxn->cup_swresved     , ' ', F121_VAL_LEN);
			}
			if (ptIpcIntTxn->cF122Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->acq_swresved_len , ptIpcIntTxn->sAcqInstResvdLen    , F122_LEN_LEN);
				memcpy (ptTxn->acq_swresved     , ptIpcIntTxn->sAcqInstResvd   , F122_VAL_LEN);
			}
			else
			{
				memset (ptTxn->acq_swresved_len , ' ', F122_LEN_LEN);
				memset (ptTxn->iss_swresved     , ' ', F122_VAL_LEN);
				memcpy (ptTxn->acq_swresved     , ptIpcIntTxn->sAcqInstResvd   , F122_VAL_LEN);
			}
			if (ptIpcIntTxn->cF123Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->iss_swresved_len , ptIpcIntTxn->sIssrInstResvdLen    , F123_LEN_LEN);
				memcpy (ptTxn->iss_swresved     , ptIpcIntTxn->sIssrInstResvd   , F123_VAL_LEN);
			}
			else
			{
				memset (ptTxn->iss_swresved_len , ' ', F123_LEN_LEN);
				memset (ptTxn->iss_swresved     , ' ', F123_VAL_LEN);
				/*memcpy (ptTxn->iss_swresved     , ptIpcIntTxn->sIssrInstResvd   , F123_VAL_LEN);*/
			}
			memcpy (ptTxn->host_trans_fee1  , ptIpcIntTxn->sHostTransFee1        , FLD_HOST_TRANS_FEE_LEN);
			memcpy (ptTxn->host_trans_fee2  , ptIpcIntTxn->sHostTransFee2        , FLD_HOST_TRANS_FEE_LEN);
			memcpy (ptTxn->tlr_num          , ptIpcIntTxn->sTlrNum                , FLD_TLR_NUM_LEN);
			memcpy (ptTxn->open_inst        , ptIpcIntTxn->sOpenInst            , FLD_INST_LEN);
			memcpy (ptTxn->stlm_inst        , ptIpcIntTxn->sStlmInst            , FLD_INST_LEN);
			memcpy (ptTxn->msq_type         , ptIpcIntTxn->sMsqType                , 16);
			memcpy (ptTxn->misc_flag        , ptIpcIntTxn->sMiscFlag            , FLD_MISC_FLAG_LEN);
			memcpy (ptTxn->misc_1           , ptIpcIntTxn->sMisc                , FLD_MISC_LEN);
			if (getenv ( "THIS_IP_ADDR"))
				strcpy(ptTxn->req_node, getenv ("THIS_IP_ADDR")); 
			
			break;

		case TXN_NUM_BDT_RSP:
			if (!memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
			{
				memcpy (ptTxn->header_buf       , ptIpcIntTxn->sHeaderBuf            , HEADER_BUF_LEN);
				memcpy (ptTxn->gf_header        , ptIpcIntTxn->sGfHeader            , FLD_GF_HEADER);
				memcpy (ptTxn->pan_len      , ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
				memcpy (ptTxn->pan      , ptIpcIntTxn->sPrimaryAcctNum, F002_VAL_LEN);
				memcpy (ptTxn->amt_settlmt      , ptIpcIntTxn->sAmtSettlmt, F005_LEN);
				memcpy (ptTxn->amt_cdhldr_bil   , ptIpcIntTxn->sAmtCdhldrBil, F006_LEN);
				memcpy (ptTxn->conv_rate_stlm   , ptIpcIntTxn->sConvRateSettlmt, F009_LEN);
				memcpy (ptTxn->conv_rate_cdhldr , ptIpcIntTxn->sConvRateCdhldrBil, F010_LEN);
				memcpy (ptTxn->date_settlmt     , ptIpcIntTxn->sDateSettlmt, F015_LEN);
				memcpy (ptTxn->date_conv        , ptIpcIntTxn->sDateConv, F016_LEN);
				if (ptIpcIntTxn->cF028Ind == FLAG_YES_C)
					memcpy (ptTxn->amt_trans_fee    , ptIpcIntTxn->sAmtTransFee, F028_LEN);
				if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
					memcpy (ptTxn->authr_id_r    , ptIpcIntTxn->sAuthrIdResp, F038_LEN);
				memcpy (ptTxn->resp_code        , ptIpcIntTxn->sRespCode, F039_LEN);
				if (ptIpcIntTxn->cF044Ind == FLAG_YES_C)
				{
					memcpy (ptTxn->addtnl_data_len  , ptIpcIntTxn->sAddtnlRespCodeLen, F044_LEN_LEN);
					memcpy (ptTxn->addtnl_data      , ptIpcIntTxn->sAddtnlRespCode, F044_VAL_LEN);
					HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sAddtnlRespCode %25.25s", ptTxn->addtnl_data);
				}
				if (ptIpcIntTxn->cF054Ind == FLAG_YES_C)
				{
					memcpy (ptTxn->addtnl_amt_len   , ptIpcIntTxn->sAddtnlAmtLen, F054_LEN_LEN);
					memcpy (ptTxn->addtnl_amt       , ptIpcIntTxn->sAddtnlAmt, F054_VAL_DB_LEN);
				}
				memcpy (ptTxn->rcvg_code_len    , ptIpcIntTxn->sRcvgInstIdCodeLen, F100_LEN_LEN);
				memcpy (ptTxn->rcvg_code        , ptIpcIntTxn->sRcvgInstIdCode, F100_VAL_LEN);
				if (ptIpcIntTxn->cF062Ind == FLAG_YES_C)
				{
					memcpy (ptTxn->switch_data_len  , ptIpcIntTxn->sSwitchingDataLen, F062_LEN_LEN);
					memcpy (ptTxn->switch_data      , ptIpcIntTxn->sSwitchingData, F062_VAL_LEN);
				}
				if (ptIpcIntTxn->cF104Ind == FLAG_YES_C)
				{
					memcpy (ptTxn->trans_descrpt_len, ptIpcIntTxn->sTransDescrptLen, F104_LEN_LEN);
					memcpy (ptTxn->trans_descrpt    , ptIpcIntTxn->sTransDescrpt, F104_VAL_LEN);
				}
				if (ptIpcIntTxn->cF121Ind == FLAG_YES_C)
				{
					memcpy (ptTxn->cup_swresved_len , ptIpcIntTxn->sNationalSwResvedLen, F121_LEN_LEN);
					memcpy (ptTxn->cup_swresved     , ptIpcIntTxn->sNationalSwResved, F121_VAL_LEN);
				}
				if (ptIpcIntTxn->cF122Ind == FLAG_YES_C)
				{
					memcpy (ptTxn->acq_swresved_len , ptIpcIntTxn->sAcqInstResvdLen, F122_LEN_LEN);
					memcpy (ptTxn->acq_swresved     , ptIpcIntTxn->sAcqInstResvd, F122_VAL_LEN);
				}
				memcpy (ptTxn->host_trans_fee1  , ptIpcIntTxn->sHostTransFee1, FLD_HOST_TRANS_FEE_LEN);
				memcpy (ptTxn->host_trans_fee2  , ptIpcIntTxn->sHostTransFee2, FLD_HOST_TRANS_FEE_LEN);
			}
			else
			{
				memcpy (ptTxn->host_date        , ptIpcIntTxn->sHostDate, FLD_HOST_DATE_LEN);
				memcpy (ptTxn->host_ssn         , ptIpcIntTxn->sHostSSN, FLD_HOST_SSN_LEN);
				memcpy (ptTxn->resp_code        , ptIpcIntTxn->sRespCode, F039_LEN);
				memcpy (ptTxn->iss_swresved_len , ptIpcIntTxn->sIssrInstResvdLen, F123_LEN_LEN);
				memcpy (ptTxn->iss_swresved     , ptIpcIntTxn->sIssrInstResvd, F123_VAL_LEN);
				memcpy (ptTxn->host_trans_fee1  , ptIpcIntTxn->sHostTransFee1, FLD_HOST_TRANS_FEE_LEN);
				memcpy (ptTxn->host_trans_fee2  , ptIpcIntTxn->sHostTransFee2, FLD_HOST_TRANS_FEE_LEN);
			}

			if (getenv ( "THIS_IP_ADDR"))
				strcpy(ptTxn->rsp_node, getenv ("THIS_IP_ADDR")); 
			
			break;

		case TXN_NUM_TDB_RSP:
		case TXN_NUM_BDB_RSP:
			memcpy (ptTxn->host_date        , ptIpcIntTxn->sHostDate, FLD_HOST_DATE_LEN);
			memcpy (ptTxn->host_ssn         , ptIpcIntTxn->sHostSSN, FLD_HOST_SSN_LEN);
			if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
				memcpy (ptTxn->authr_id_r    , ptIpcIntTxn->sAuthrIdResp, F038_LEN);
			memcpy (ptTxn->resp_code        , ptIpcIntTxn->sRespCode, F039_LEN);
			if (ptIpcIntTxn->cF044Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->addrsp_data_len  , ptIpcIntTxn->sAddtnlRespCodeLen, F044_LEN_LEN);
				memcpy (ptTxn->addrsp_data      , ptIpcIntTxn->sAddtnlRespCode, F044_VAL_LEN);
			}
			if (ptIpcIntTxn->cF054Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->addtnl_amt_len   , ptIpcIntTxn->sAddtnlAmtLen, F054_LEN_LEN);
				memcpy (ptTxn->addtnl_amt       , ptIpcIntTxn->sAddtnlAmt, F054_VAL_DB_LEN);
			}
			memcpy (ptTxn->host_trans_fee1  , ptIpcIntTxn->sHostTransFee1, FLD_HOST_TRANS_FEE_LEN);
			memcpy (ptTxn->host_trans_fee2  , ptIpcIntTxn->sHostTransFee2, FLD_HOST_TRANS_FEE_LEN);
			memcpy (ptTxn->iss_swresved     , ptIpcIntTxn->sIssrInstResvd   , F123_VAL_LEN);
			
			if (getenv ( "THIS_IP_ADDR"))
				strcpy(ptTxn->rsp_node, getenv ("THIS_IP_ADDR")); 
			
			break;
			
		case TXN_NUM_CBDB_RSP:

			memcpy (ptTxn->host_date        , ptIpcIntTxn->sHostDate, FLD_HOST_DATE_LEN);
			memcpy (ptTxn->host_ssn         , ptIpcIntTxn->sHostSSN, FLD_HOST_SSN_LEN);
			if (ptIpcIntTxn->sAuthrIdResp[0] != ' ' )
				memcpy (ptTxn->authr_id_r    , ptIpcIntTxn->sAuthrIdResp, F038_LEN);
			memcpy (ptTxn->resp_code        , ptIpcIntTxn->sRespCode, F039_LEN);
			if (ptIpcIntTxn->sAddtnlRespCode[0] != ' ')
			{
				memcpy (ptTxn->addrsp_data_len  , ptIpcIntTxn->sAddtnlRespCodeLen, F044_LEN_LEN);
				memcpy (ptTxn->addrsp_data      , ptIpcIntTxn->sAddtnlRespCode, F044_VAL_LEN);
			}
			memcpy (ptTxn->host_trans_fee1  , ptIpcIntTxn->sHostTransFee1, FLD_HOST_TRANS_FEE_LEN);
			memcpy (ptTxn->host_trans_fee2  , ptIpcIntTxn->sHostTransFee2, FLD_HOST_TRANS_FEE_LEN);
			
			if (getenv ( "THIS_IP_ADDR"))
				strcpy(ptTxn->rsp_node, getenv ("THIS_IP_ADDR")); 
			
			break;

		default: 
			break;
	}
	
	if(ptIpcIntTxn->cF035Ind == FLAG_YES_C)
	{
		Track2P = strchr(ptIpcIntTxn->sTrack2Data, '=');
		if(Track2P != NULL)
			memcpy (ptTxn->card_material , Track2P+5       , 1); /* ���ŵ��Ⱥź�ĵ���λ */
	}
	/*CommonGetCurrentTime (sCurrentTime);*/
	memcpy (ptTxn->update_time      , gsTimeCurTs, 14);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:   int MoveTxn2Ipc (Tbl_txn_Def *ptTxn, T_IpcIntTxnDef *ptIpcIntTxn )*/
/* INPUT:  ptIpcIntTxn: ������, ��ʽ���ڲ���IPC�ṹ                        */
/* OUTPUT: ptTxn: ��Ӧ��tbl_txn�ļ�¼                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ptIpcIntTxn������дptTxn                                        */
/*****************************************************************************/
int MoveTxn2Ipc (Tbl_txn_Def *ptTxn, T_IpcIntTxnDef *ptIpcIntTxn )
{
	char    sFuncName[] = "MoveTxn2Ipc";
	char    sAcqInstIdCode[F032_VAL_LEN + 1];
	char    sFwdInstIdCode[F033_VAL_LEN + 1];
	char    sF104Len[2+1] = {0};

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memset ((char *)ptIpcIntTxn, ' ', sizeof (*ptIpcIntTxn));

	memcpy (ptIpcIntTxn->sSysSeqNum                , ptTxn->sys_seq_num      , F011_LEN);
	memcpy (ptIpcIntTxn->sMsgSrcId                , ptTxn->msg_src_id       , SRV_ID_LEN);
	memcpy (ptIpcIntTxn->sTxnNum                , ptTxn->txn_num          , FLD_TXN_NUM_LEN);
	memcpy (ptIpcIntTxn->sTransCode                , ptTxn->trans_code       , FLD_TXN_CODE_LEN);
	memcpy (ptIpcIntTxn->sTransType                , ptTxn->trans_type       , FLD_TRANS_TYPE_LEN);
	memcpy (ptIpcIntTxn->sTransState            , ptTxn->trans_state      , FLD_TRANS_STATE_LEN);
	memcpy (ptIpcIntTxn->sHostDate                , ptTxn->host_date        , FLD_HOST_DATE_LEN);
	memcpy (ptIpcIntTxn->sHostSSN                , ptTxn->host_ssn         , FLD_HOST_SSN_LEN);
	memcpy (ptIpcIntTxn->sTermSSN                , ptTxn->term_ssn         , FLD_HOST_SSN_LEN);
	memcpy (ptIpcIntTxn->sHeaderBuf                , ptTxn->header_buf       , HEADER_BUF_LEN);
	memcpy (ptIpcIntTxn->sGfHeader                 ,ptTxn->gf_header        , FLD_GF_HEADER);
	memcpy (ptIpcIntTxn->sMsgType                , ptTxn->msg_type         , F000_MSG_TYPE_LEN);
	ptIpcIntTxn->cF002Ind = (ptTxn->pan_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sPrimaryAcctNumLen        , ptTxn->pan_len          , F002_LEN_LEN);
	memcpy (ptIpcIntTxn->sPrimaryAcctNum        , ptTxn->pan              , F002_VAL_LEN);
	memcpy (ptIpcIntTxn->sProcessingCode        , ptTxn->processing_code  , F003_LEN);
	memcpy (ptIpcIntTxn->sAmtTrans                , ptTxn->amt_trans        , F004_LEN);
	memcpy (ptIpcIntTxn->sAmtSettlmt            , ptTxn->amt_settlmt      , F005_LEN);
	memcpy (ptIpcIntTxn->sAmtCdhldrBil            , ptTxn->amt_cdhldr_bil   , F006_LEN);
	memcpy (ptIpcIntTxn->sTransmsnDateTime        , ptTxn->trans_date_time  , F007_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransmsnDateTime[%10.10s].", ptIpcIntTxn->sTransmsnDateTime);
	memcpy (ptIpcIntTxn->sConvRateSettlmt        , ptTxn->conv_rate_stlm   , F009_LEN);
	memcpy (ptIpcIntTxn->sConvRateCdhldrBil        , ptTxn->conv_rate_cdhldr , F010_LEN);
	memcpy (ptIpcIntTxn->sSysTraceAuditNum        , ptTxn->cup_ssn          , F011_LEN);
	memcpy (ptIpcIntTxn->sTimeLocalTrans        , ptTxn->time_local_trans , F012_LEN);
	memcpy (ptIpcIntTxn->sDateLocalTrans        , ptTxn->date_local_trans , F013_LEN);
	ptIpcIntTxn->cF015Ind = (ptTxn->date_settlmt[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sDateSettlmt            , ptTxn->date_settlmt     , F015_LEN);
	memcpy (ptIpcIntTxn->sDateConv                , ptTxn->date_conv        , F016_LEN);
	memcpy (ptIpcIntTxn->sMchntType                , ptTxn->mchnt_type       , F018_LEN);
	ptIpcIntTxn->cF019Ind = (ptTxn->acq_cntry_code[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAcqInstCntryCode        , ptTxn->acq_cntry_code   , F019_LEN);
	memcpy (ptIpcIntTxn->sPosEntryModeCode        , ptTxn->pos_entry_mode   , F022_LEN);
	memcpy (ptIpcIntTxn->sPosCondCode            , ptTxn->pos_cond_code    , F025_LEN);
	ptIpcIntTxn->cF026Ind = (ptTxn->pos_pin_cap_code[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sPosPinCaptrCode        , ptTxn->pos_pin_cap_code , F026_LEN);
	ptIpcIntTxn->cF028Ind = (ptTxn->amt_trans_fee[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAmtTransFee            , ptTxn->amt_trans_fee    , F028_LEN);
	memcpy (sAcqInstIdCode, ptTxn->acq_inst_id_code , F032_VAL_LEN);
	sAcqInstIdCode[F032_VAL_LEN] = 0;
	CommonRTrim(sAcqInstIdCode);
	sprintf(ptIpcIntTxn->sAcqInstIdCodeLen, "%02d", (int)strlen(sAcqInstIdCode));
	memcpy (ptIpcIntTxn->sAcqInstIdCode            , ptTxn->acq_inst_id_code , F032_VAL_LEN);
	memcpy (sFwdInstIdCode, ptTxn->fwd_inst_id_code , F033_VAL_LEN);
	sFwdInstIdCode[F033_VAL_LEN] = 0;
	CommonRTrim(sFwdInstIdCode);
	sprintf(ptIpcIntTxn->sFwdInstIdCodeLen, "%02d", (int)strlen(sFwdInstIdCode));
	memcpy (ptIpcIntTxn->sFwdInstIdCode            , ptTxn->fwd_inst_id_code , F033_VAL_LEN);
	memcpy (ptIpcIntTxn->sRetrivlRefNum            , ptTxn->retrivl_ref      , F037_LEN);

	ptIpcIntTxn->cF038Ind = (ptTxn->authr_id_resp[0] != ' '&&ptTxn->authr_id_resp[0] != 0) ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAuthrIdResp            , ptTxn->authr_id_resp    , F038_LEN);

	memcpy (ptIpcIntTxn->sRespCode                , ptTxn->resp_code        , F039_LEN);
	memcpy (ptIpcIntTxn->sCardAccptrTermnlId    , ptTxn->card_accp_term_id, F041_LEN);
	memcpy (ptIpcIntTxn->sCardAccptrId            , ptTxn->card_accp_id     , F042_LEN);
	memcpy (ptIpcIntTxn->sCardAccptrNameLoc        , ptTxn->card_accp_name   , F043_LEN);
	ptIpcIntTxn->cF044Ind = (ptTxn->addrsp_data_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAddtnlRespCodeLen        , ptTxn->addrsp_data_len  , F044_LEN_LEN);
	memcpy (ptIpcIntTxn->sAddtnlRespCode        , ptTxn->addrsp_data      , F044_VAL_LEN);
	memcpy(ptIpcIntTxn->sF046Value,ptTxn->addint_data,F046_VAL_LEN);
	ptIpcIntTxn->cF048Ind = (ptTxn->addtnl_data_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAddtnlDataPrivateLen  , ptTxn->addtnl_data_len , F048_LEN_LEN);
	memcpy (ptIpcIntTxn->sAddtnlDataPrivate     , ptTxn->addtnl_data     , F048_VAL_LEN);
	memcpy (ptIpcIntTxn->sCurrcyCodeTrans        , ptTxn->currcy_code_trans, F049_LEN);
	memcpy (ptIpcIntTxn->sCurrcyCodeSettlmt        , ptTxn->currcy_code_stlm , F050_LEN);
	memcpy (ptIpcIntTxn->sCurrcyCodeCdhldrBil    , ptTxn->currcy_code_chldr, F051_LEN);
	ptIpcIntTxn->cF052Ind = FLAG_NO_C;
	ptIpcIntTxn->cF053Ind = FLAG_NO_C;
	ptIpcIntTxn->cF054Ind = (ptTxn->addtnl_amt_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAddtnlAmtLen            , ptTxn->addtnl_amt_len   , F054_LEN_LEN);
	memcpy (ptIpcIntTxn->sAddtnlAmt                , ptTxn->addtnl_amt       , F054_VAL_DB_LEN);
	memcpy (ptIpcIntTxn->sFldReservedLen        , ptTxn->fld_reserved_len , F060_LEN_LEN);
	memcpy (ptIpcIntTxn->sFldReserved            , ptTxn->fld_reserved     , F060_VAL_LEN);
	ptIpcIntTxn->cF061Ind = (ptTxn->ch_auth_info_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sChAuthInfoLen            , ptTxn->ch_auth_info_len , F061_LEN_LEN);
	memcpy (ptIpcIntTxn->sChAuthInfo            , ptTxn->ch_auth_info     , F061_VAL_LEN);
	ptIpcIntTxn->cF062Ind = (ptTxn->switch_data_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sSwitchingDataLen        , ptTxn->switch_data_len  , F062_LEN_LEN);
	memcpy (ptIpcIntTxn->sSwitchingData            , ptTxn->switch_data      , F062_VAL_LEN);
	memcpy (ptIpcIntTxn->sOrigDataElemts        , ptTxn->orig_data_elemts , F090_LEN);
	memcpy (ptIpcIntTxn->sReplacementAmts        , ptTxn->replacement_amts , F095_LEN);
	ptIpcIntTxn->cF100Ind = (ptTxn->rcvg_code_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sRcvgInstIdCodeLen        , ptTxn->rcvg_code_len    , F100_LEN_LEN);
	memcpy (ptIpcIntTxn->sRcvgInstIdCode        , ptTxn->rcvg_code        , F100_VAL_LEN);
	ptIpcIntTxn->cF102Ind = (ptTxn->acct_id1_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAcctId1Len            , ptTxn->acct_id1_len     , F102_LEN_LEN);
	memcpy (ptIpcIntTxn->sAcctId1                , ptTxn->acct_id1         , F102_VAL_LEN);
	ptIpcIntTxn->cF103Ind = (ptTxn->acct_id2_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAcctId2Len            , ptTxn->acct_id2_len     , F103_LEN_LEN);
	memcpy (ptIpcIntTxn->sAcctId2                , ptTxn->acct_id2         , F103_VAL_LEN);
	ptIpcIntTxn->cF104Ind = (ptTxn->trans_descrpt_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sTransDescrptLen        , ptTxn->trans_descrpt_len, F104_LEN_LEN);
	memcpy (ptIpcIntTxn->sTransDescrpt            , ptTxn->trans_descrpt    , F104_VAL_LEN);
	ptIpcIntTxn->cF121Ind = (ptTxn->cup_swresved_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sNationalSwResvedLen    , ptTxn->cup_swresved_len , F121_LEN_LEN);
	memcpy (ptIpcIntTxn->sNationalSwResved        , ptTxn->cup_swresved     , F121_VAL_LEN);
	ptIpcIntTxn->cF122Ind = (ptTxn->acq_swresved_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAcqInstResvdLen    , ptTxn->acq_swresved_len , F123_LEN_LEN);
	memcpy (ptIpcIntTxn->sAcqInstResvd        , ptTxn->acq_swresved     , F123_VAL_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sAcqInstResvd[%50.50s].", ptIpcIntTxn->sAcqInstResvd);
	ptIpcIntTxn->cF123Ind = (ptTxn->iss_swresved_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sIssrInstResvdLen    , ptTxn->iss_swresved_len , F123_LEN_LEN);
	memcpy (ptIpcIntTxn->sIssrInstResvd        , ptTxn->iss_swresved     , F123_VAL_LEN);
	memcpy (ptIpcIntTxn->sHostTransFee1            , ptTxn->host_trans_fee1  , FLD_HOST_TRANS_FEE_LEN);
	memcpy (ptIpcIntTxn->sHostTransFee2            , ptTxn->host_trans_fee2  , FLD_HOST_TRANS_FEE_LEN);
	memcpy (ptIpcIntTxn->sTlrNum                , ptTxn->tlr_num          , FLD_TLR_NUM_LEN);
	memcpy (ptIpcIntTxn->sOpenInst                , ptTxn->open_inst        , FLD_INST_LEN);
	memcpy (ptIpcIntTxn->sStlmInst                , ptTxn->stlm_inst        , FLD_INST_LEN);
	memcpy (ptIpcIntTxn->sMsqType                , ptTxn->msq_type         , FLD_MSQ_TYPE_LEN);
	memcpy (ptIpcIntTxn->sMiscFlag                , ptTxn->misc_flag        , FLD_MISC_FLAG_LEN);
	memcpy (ptIpcIntTxn->sMisc                    , ptTxn->misc_1           , FLD_MISC_LEN);

	if ( memcmp(ptTxn->misc_1+61 , "5203" , 4 ) == 0 )            /**ר������ ***/
	{
		ptIpcIntTxn->cF038Ind = FLAG_YES_C;
		memcpy (ptIpcIntTxn->sAuthrIdResp, "888888" , F038_LEN);
	}
	    
	/* ȡPAN���к�, ATC, ARPC */
	memcpy (sF104Len, ptTxn->trans_descrpt, 2);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ic data len [%s]", sF104Len);
	if(atoi(sF104Len) > 0)
	{
	    memcpy (ptIpcIntTxn->sTransDescrpt, ptTxn->trans_descrpt, atoi(sF104Len)+2);
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int InsertSafMsg (T_IpcIntTxnDef *ptSendIpcIntTxn, Tbl_txn_Def *ptTxn, char *sCount)
{
	char            sFuncName[] = "InsertSafMsg";
	int                nCount;
	int                nReturnCode;
	int                nMsgLen;
	Tbl_saf_msg_Def    tSafMsg;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nCount = %d .", atoi(sCount) );

	nCount = atoi (sCount);
	if (nCount > 0)
	{
		DbsBegin ();
		memset ((char *)&tSafMsg, 0, sizeof (tSafMsg));
		memcpy (tSafMsg.inst_date, ptTxn->inst_date, 8);
		memcpy (tSafMsg.inst_time, ptTxn->inst_time, 6);
		memcpy (tSafMsg.msg_src_id, ptTxn->msg_src_id, SRV_ID_LEN);
		memcpy (tSafMsg.txn_num, ptTxn->txn_num, FLD_TXN_NUM_LEN);
		memcpy (tSafMsg.sys_seq_num, ptTxn->sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
		memcpy (tSafMsg.msg_dest_srv_id, ptSendIpcIntTxn->sMsgDestId, SRV_ID_LEN);
		memcpy (tSafMsg.send_count, sCount, 2);
		memset (tSafMsg.center_stlm_date, ' ', 8);
		memcpy (tSafMsg.center_stlm_date, ptTxn->date_settlmt, 4);
		memcpy (tSafMsg.host_stlm_date, ptTxn->host_date, 8);
		nMsgLen = sizeof (*ptSendIpcIntTxn);
		sprintf (tSafMsg.msg_len, "%04d", nMsgLen);
		EncodeNull ((char *)ptSendIpcIntTxn, nMsgLen);
		if (nMsgLen > 3072)
		{
			memcpy (tSafMsg.msg_ipc1, (char *)ptSendIpcIntTxn, 3072);
			memcpy (tSafMsg.msg_ipc2, ((char *)ptSendIpcIntTxn)+3072, nMsgLen-3072);
		}
		else
		{
			memcpy (tSafMsg.msg_ipc1, (char *)ptSendIpcIntTxn, nMsgLen);
		}

		nReturnCode = DbsSafMsg (DBS_INSERT, &tSafMsg);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsSafMsg insert error, %d.", nReturnCode);
			DbsRollback ();
			return -1;
		}
		DbsCommit ();
	}
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CopyOrigTxnInfo (Tbl_txn_Def *ptTxn, T_IpcIntTxnDef *ptIpcIntTxn)
{
	char   sTemp[20];
	memcpy (ptIpcIntTxn->sProcessingCode        , ptTxn->processing_code  , F003_LEN);
	memcpy (ptIpcIntTxn->sTimeLocalTrans        , ptTxn->time_local_trans , F012_LEN);
	memcpy (ptIpcIntTxn->sDateLocalTrans        , ptTxn->date_local_trans , F013_LEN);
	memcpy (ptIpcIntTxn->sMchntType                , ptTxn->mchnt_type       , F018_LEN);
	memcpy (ptIpcIntTxn->sPosCondCode            , ptTxn->pos_cond_code    , F025_LEN);
	/* ���ÿ�Ҫ��F037���ֵ������ԭ������ͬ -- mod by wuzw */
	/* memcpy (ptIpcIntTxn->sRetrivlRefNum            , ptTxn->retrivl_ref      , F037_LEN); */
	
	/*add by xu zhen*/
	if(!memcmp(ptIpcIntTxn->sTxnNum,"3091",4)||!memcmp(ptIpcIntTxn->sTxnNum,"2091",4)||!memcmp(ptIpcIntTxn->sTxnNum,"4011",4)){

		/*memcpy (ptIpcIntTxn->sAuthrIdResp            , ptTxn->authr_id_r      , 6);
		  if(!memcmp(ptIpcIntTxn->sAuthrIdResp,"   ",3)||!memcmp(ptIpcIntTxn->sAuthrIdResp,"\x00\x00\x00",3)){
		  memcpy (ptIpcIntTxn->sAuthrIdResp            , ptTxn->authr_id_resp      , 6);

		  }*/
		memcpy (ptIpcIntTxn->sAuthrIdResp            , ptTxn->authr_id_resp      , 6);
	}
	if(!memcmp(ptIpcIntTxn->sTxnNum,"4091",4))
		memcpy (ptIpcIntTxn->sAuthrIdResp            , ptTxn->authr_id_resp      , 6);
	if(!memcmp(ptIpcIntTxn->sAuthrIdResp,"   ",3)||!memcmp(ptIpcIntTxn->sAuthrIdResp,"\x00\x00\x00",3)){
		ptIpcIntTxn->cF038Ind='N';

	}
	memcpy (ptIpcIntTxn->sHostSSN            , ptTxn->term_ssn      , 12);
	memcpy (ptIpcIntTxn->sHostDate            , ptTxn->host_date      , 8);
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ&&memcmp(ptIpcIntTxn->sTxnNum,"2083",4)&&memcmp(ptIpcIntTxn->sTxnNum,"2143",4)){
		/*CommonGetCurrentTime(sTemp);*/
		SetToTime(-1);
		memcpy (ptIpcIntTxn->sTimeLocalTrans            , gsTimeCurTs+8      , 6);
		memcpy (ptIpcIntTxn->sHostDate            , ptTxn->inst_date      , 4);
		memcpy (&ptIpcIntTxn->sHostDate[4]            , ptTxn->date_settlmt      , 4);
	}if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_REQ)
		memcpy(ptIpcIntTxn->sPosEntryModeCode,ptTxn->pos_entry_mode,F022_LEN);
	/*end*/

	return 0;
}

/*****************************************************************************/
/* FUNC:   int SendRevsalOnError (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex)   */
/* INPUT:  ptIpcIntTxn: �ڲ�IPC, ��Ӧ�����׵����ݿ��¼                    */
/*         nIndex: gatTxnInf�иý��׵��±�                                   */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �ڴ����ٵ��ĳɹ�Ӧ���Ӧ��ʱʱ, �ɵ��ô˺������ͳ�������        */
/*****************************************************************************/
int SendRevsalOnError (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex, char *sReasonCode)
{
	char            sFuncName[] = "SendRevsalOnError";
	char            sMsgSrcId[SRV_ID_LEN+1];
	char            sTxnNum[FLD_TXN_NUM_LEN+1];
	char            sFldReservedLen[F060_LEN_LEN+1];
	char            sCurrentTime[15];
	int                nFldReservedLen;
	int                nReturnCode;
	int                nRevsalIndex;
	int                i;
	T_IpcIntTxnDef    tIpcIntRevsal;
    memset(sCurrentTime,0x00,sizeof(sCurrentTime));
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy ((char *)&tIpcIntRevsal, ptIpcIntTxn, sizeof (*ptIpcIntTxn));
	if (strlen(gatTxnInf[nIndex].to_txn_num) &&
			gatTxnInf[nIndex].to_txn_num[0] != ' ')
	{
		/* need to send reversal */

		/* change ipc to reversal ipc */
	/*	if (!memcmp(tIpcIntRevsal.sMsgSrcId, SRV_ID_COMM_P, 4))
			memcpy (tIpcIntRevsal.sHeaderBuf + 6, "00010000    03050000    ", 22);
  */
		memcpy (tIpcIntRevsal.sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN);
		memcpy (tIpcIntRevsal.sTransState, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN);
		memcpy (tIpcIntRevsal.sTxnNum, gatTxnInf[nIndex].to_txn_num, FLD_TXN_NUM_LEN);
		tIpcIntRevsal.sTransCode[FLD_TXN_CODE_LEN-1] = TRANS_CODE_REVSAL;
		/* clear F039 */
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntTxn sRespCode[%2.2s] .", ptIpcIntTxn->sRespCode);
	 	memset (tIpcIntRevsal.sRespCode, ' ', F039_LEN); 
		/* F060 */
		memcpy (tIpcIntRevsal.sMsgType, MSG_TYPE_REVSAL, F000_MSG_TYPE_LEN);
		memset (sFldReservedLen, 0, sizeof (sFldReservedLen));
		memcpy (sFldReservedLen, ptIpcIntTxn->sFldReservedLen, F060_LEN_LEN);
		nFldReservedLen = atoi (sFldReservedLen);
		if (nFldReservedLen == 0)
		{
			sprintf (sFldReservedLen, "%04d", (int)strlen (sReasonCode));
			memcpy (tIpcIntRevsal.sFldReservedLen, sFldReservedLen, F060_LEN_LEN);
		}
		memcpy (tIpcIntRevsal.sFldReserved, sReasonCode, strlen (sReasonCode));
		/* F090 */
		memset (tIpcIntRevsal.sOrigDataElemts, '0', F090_LEN);
		i = 0;
		memcpy (tIpcIntRevsal.sOrigDataElemts+i, ptIpcIntTxn->sMsgType, F000_MSG_TYPE_LEN);
		i += F000_MSG_TYPE_LEN;
		if (!memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
		{
			/*memcpy (tIpcIntRevsal.sOrigDataElemts+i, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);*/
			memcpy (tIpcIntRevsal.sOrigDataElemts+i, ptIpcIntTxn->sMisc+F007_LEN,F011_LEN);
	    }
		else
		{
			/*memcpy (tIpcIntRevsal.sOrigDataElemts+i, ptIpcIntTxn->sTermSSN, F011_LEN);*/
			/*memcpy (tIpcIntRevsal.sOrigDataElemts+i, ptIpcIntTxn->sSysSeqNum,F011_LEN);*/
			memcpy (tIpcIntRevsal.sOrigDataElemts+i, ptIpcIntTxn->sMisc+F007_LEN,F011_LEN);
		}
		i += F011_LEN;
		/*memcpy (tIpcIntRevsal.sOrigDataElemts+i, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);*/
		memcpy (tIpcIntRevsal.sOrigDataElemts+i, ptIpcIntTxn->sMisc, F007_LEN);
		i += F007_LEN;
		memcpy (tIpcIntRevsal.sOrigDataElemts+i+F032_VAL_LEN-INST_ID_LEN, ptIpcIntTxn->sAcqInstIdCode, INST_ID_LEN);
		i += F032_VAL_LEN;
		memcpy (tIpcIntRevsal.sOrigDataElemts+i+F033_VAL_LEN-INST_ID_LEN, ptIpcIntTxn->sFwdInstIdCode, INST_ID_LEN);
      /*F007*/
       /*CommonGetCurrentTime(sCurrentTime);*/
       SetToTime(-1);
       memcpy(tIpcIntRevsal.sTransmsnDateTime,gsTimeCurTs+4,10);
       
		memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
		memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
		memset (sTxnNum, 0, sizeof (sTxnNum));
		memcpy (sTxnNum, gatTxnInf[nIndex].to_txn_num, FLD_TXN_NUM_LEN);
		nReturnCode = GetTxnInfoIndex( sMsgSrcId, sTxnNum, &nRevsalIndex );
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetTxnInfoIndex error, %d.", nReturnCode);
			return -1;
		}

		/* process reversal txn */
		for( i = 0; i < MAXTXNS; i++ )
		{
			if( memcmp( tIpcIntRevsal.sTxnNum, gaTxns[i].caTxnNum, FLD_TXN_NUM_LEN ) == 0 )
			{
				if (memcmp( gaTxns[i].caMsgSrcId, MSG_SRC_ID_ANY, SRV_ID_LEN ) == 0 )
				{
					break;
				}
				else
				{
					if (memcmp( ptIpcIntTxn->sMsgSrcId, gaTxns[i].caMsgSrcId, SRV_ID_LEN ) == 0 )
					{
						break;
					}
				}
			}
		}

		if( i == MAXTXNS )
		{
			nReturnCode = SwtCustHandleTransaction(&tIpcIntRevsal, nRevsalIndex);
		}
		else
		{
			nReturnCode = gaTxns[i].pfTxnFun(&tIpcIntRevsal, nRevsalIndex);
		}

		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HandleRvslReqTDB error, %d.", nReturnCode);
			return -1;
		}
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:   int SendMsg (tIpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn,      */
/*                      Tbl_txn_Def *ptOrigTxn)                              */
/* INPUT:  ptIpcIntTxn: ������, ��ʽ���ڲ���IPC�ṹ                        */
/*         ptTxn: tbl_txn��¼, ָ�����Ϊ��                                  */
/*         ptOrigTxn: ԭʼ����, tbl_txn��¼, ָ�����Ϊ��                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��gatTxnInf��������PackSend���;ܾ�Ӧ����                       */
/*****************************************************************************/
int SendMsg (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn, Tbl_txn_Def *ptOrigTxn)
{
	char    sFuncName[] = "SendMsg";
	char    sMsgBuf[MSQ_MSG_SIZE_MAX];
	int     nMsgLen;
	int        nReturnCode;
	int        nLineStat;
	char    summary[201]="";
        char    sTmp1[4+1];
	int i;
	char    sLineIndex[2] = {0};

	long lEndTime , lBeginTime;
	/*
	T_IpcIntTxnDef    tIpcIntTxn;
	*/
	struct tms        tTMS;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
	/* clear msq type if this is a request msg */
	if (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_REQ ||
			ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ ||
			ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ )
	{
		/*
		memset( ptIpcIntTxn->sMsqType, '0', FLD_MSQ_TYPE_LEN);

		*/
	}
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "ptIpcIntTxn->cF014Ind [%c] ptIpcIntTxn->sDateExpr [%-04.04s]", ptIpcIntTxn->cF014Ind, ptIpcIntTxn->sDateExpr);

	nReturnCode = SwtCustAfterTblTxnOpr (ptIpcIntTxn, ptTxn, ptOrigTxn);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"SwtCustAfterTblTxnOpr error, %d.", nReturnCode);
		return -1;
	}
    
  
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "sMsgSrcId--%4.4s  sMsgDestId--%4.4s",ptIpcIntTxn->sMsgSrcId, ptIpcIntTxn->sMsgDestId);
	

	/* ��F014��ȱʡֵ ������������������ */
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_TDB_REQ &&
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_BDT_REQ &&
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_BDB_REQ)
	{
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "ptIpcIntTxn->cF014Ind [%c] ptIpcIntTxn->sDateExpr [%-04.04s]", ptIpcIntTxn->cF014Ind, ptIpcIntTxn->sDateExpr);
	    if(ptIpcIntTxn->sDateExpr[0] == ' ' || ptIpcIntTxn->sDateExpr[0] == 0x00)
	    {HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "test");
	        ptIpcIntTxn->cF014Ind = FLD_IND_VAL_Y;
	        memcpy( ptIpcIntTxn->sDateExpr, F014_DEFAULT, F014_LEN);
        }
    }

	/***************
	 * ����MAC
	 ****************/
	 if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0 ||
	    memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0 ||
	    memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0 ||
	    memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_MZ, SRV_ID_LEN) == 0)
	{
	    nReturnCode = GenerateMAC (ptIpcIntTxn);
	    if (nReturnCode)
	    {
	    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	    			"GenerateMAC error, %d.", nReturnCode);
	    	return -1;
	    }
	}
	else
	{
	    ptIpcIntTxn->cF128Ind = 'Y';
		memcpy(ptIpcIntTxn->sMAC128, "FFFFFFFF", F128_LEN);
	}

	/***********************
	 * ��ⷢ��Ŀ����·״̬
	 ************************/
    strcpy (sLineIndex, getenv(SRV_USAGE_KEY));
	nReturnCode = LineStateCheck (ptIpcIntTxn->sMsgDestId, sLineIndex, &nLineStat);
	if (nReturnCode || (nReturnCode == 0 && nLineStat != LINE_STATE_CONNECT))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"LineStateCheck return %d, line state %d.", nReturnCode, nLineStat);
		return -1;
	}
	
	
	/* ������Ӧ��ʹ�ñ�����������Ӧ�� */
	if((ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_RSP) ||
	    (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_CBDB_RSP))
	{
	    /* �����ֽ��� */
	    if(memcmp(ptIpcIntTxn->sTxnNum, "1256", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "1202", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "1366", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "1102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "2366", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "2102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "3366", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "3102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "4366", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "4102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "5366", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "5152", 4);
	    /* �����ֽ𷢿��ཻ�� */
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "1906", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "1916", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "1926", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "1936", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "2906", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "2916", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "2926", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "2936", 4) == 0)
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����������ֽ𿨷����ཻ��");
        /* �����ֽ�������ֽ��ֵ���� */
        else if(memcmp(ptIpcIntTxn->sTxnNum, "1376", 4) == 0 &&
                memcmp(ptIpcIntTxn->sProcessingCode, "70", 2) == 0)
            memcpy(ptIpcIntTxn->sTxnNum, "1946", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "2376", 4) == 0 &&
	            memcmp(ptIpcIntTxn->sProcessingCode, "70", 2) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "2946", 4);
	    /* ÷���籣������ */
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "1306", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "1202", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "1316", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "1102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "2316", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "2102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "3316", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "3102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "4316", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "4102", 4);
	    /* POS���ڽ��� */
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "1118", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "1102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "2118", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "2102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "3118", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "3102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "4118", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "4102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "5118", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "5152", 4);
	    /* ���ֽ��� */
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "1806", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "1202", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "1816", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "1826", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "1102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "2816", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "2826", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "2102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "3816", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "3826", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "3102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "4816", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "4826", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "4102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "5836", 4) == 0 ||
	            memcmp(ptIpcIntTxn->sTxnNum, "5846", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "5152", 4);
	    /* �������� */
	    else
            ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_BDT_RSP;
    }

    /* ������Ӧ������Ǵ�ֵ�������룬ʹ��ԭ����������������Ӧ�� */
    if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_RSP)
    {
        if(memcmp(ptIpcIntTxn->sTxnNum, "1254", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "1204", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "1364", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "1104", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "2364", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "2104", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "3364", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "3104", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "4364", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "4104", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "5364", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "5154", 4);
	    }
    }
    
    /* ������Ӧ�������÷���籣�����룬ʹ��ԭ����������������Ӧ�� */
    if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_RSP)
    {
        if(memcmp(ptIpcIntTxn->sTxnNum, "1304", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "1204", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "1314", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "1104", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "2314", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "2104", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "3314", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "3104", 4);
	    }
	    if(memcmp(ptIpcIntTxn->sTxnNum, "4314", 4) == 0)
	    {
	        memcpy(ptIpcIntTxn->sTxnNum, "4104", 4);
	    }
    }

	/* ѹ����Ϣ�� */
	if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
	{
		/* compress msg */
		Compressbuf ((char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn), sMsgBuf, &nMsgLen);
	}
	else
	{
		nMsgLen = sizeof (*ptIpcIntTxn);
		memcpy (sMsgBuf, (char *)ptIpcIntTxn, nMsgLen);
	}

	nReturnCode = MsqSnd (SRV_ID_PACKSEND, gatSrvMsq, 0, nMsgLen, sMsgBuf);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqSnd error, %d.", nReturnCode);
		return -1;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int SendNewMsg (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn, Tbl_txn_Def *ptOrigTxn)
{
	char    sFuncName[] = "SendNewMsg";
	char    sMsgBuf[MSQ_MSG_SIZE_MAX];
	int     nMsgLen;
	int        nReturnCode;
	/*
	int        nLineStat;
	*/
	char    summary[201]="";

	/*
	T_IpcIntTxnDef    tIpcIntTxn;
	struct tms        tTMS;
	*/

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	/* clear msq type if this is a request msg */
	if (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_REQ ||
			ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ ||
			ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ )
	{
		/*
		memset( ptIpcIntTxn->sMsqType, '0', FLD_MSQ_TYPE_LEN);

		*/
	}

	nReturnCode = SwtCustAfterTblTxnOpr (ptIpcIntTxn, ptTxn, ptOrigTxn);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"SwtCustAfterTblTxnOpr error, %d.", nReturnCode);
		return -1;
	}

	/* ��F014��ȱʡֵ */
	ptIpcIntTxn->cF014Ind = FLD_IND_VAL_Y;
	memcpy( ptIpcIntTxn->sDateExpr, F014_DEFAULT, F014_LEN);

	/***************
	 * ����MAC
	 ***************
	 nReturnCode = GenerateMAC (ptIpcIntTxn);
	 if (nReturnCode)
	 {
	 HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	 "GenerateMAC error, %d.", nReturnCode);
	 return -1;
	 }
	 */

	/***********************
	 * ��ⷢ��Ŀ����·״̬
	 ************************/
	/***
	  nReturnCode = LineStateCheck (ptIpcIntTxn->sMsgDestId, &nLineStat);
	  if (nReturnCode || nReturnCode == 0 && nLineStat != LINE_STATE_CONNECT)
	  {
	  HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	  "LineStateCheck return %d, line state %d.", nReturnCode, nLineStat);
	  return -1;
	  }
	 ***/

	/* ѹ����Ϣ�� */
	if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
	{
		/* compress msg */
		Compressbuf ((char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn), sMsgBuf, &nMsgLen);
	}
	else
	{
		nMsgLen = sizeof (*ptIpcIntTxn);
		memcpy (sMsgBuf, (char *)ptIpcIntTxn, nMsgLen);
	}

	nReturnCode = MsqSnd (SRV_ID_HBSVR, gatSrvMsq, 0, nMsgLen, sMsgBuf);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqSnd error, %d.", nReturnCode);
		return -1;
	}

	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, (char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn));

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CheckRevsalTxn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckRevsalTxn";
	char    sPanLen[F002_LEN_LEN+1];
	int     nPanLen;
	int     nReturnCode;
	char    sCurrentTime[15];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	/* DBS_SELECT22: txn_num, key_revsal */
	
	ptOrigTxn->txn_num[INDEX_TXN_NUM_TYPE] --;
       
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"DbsTxn select22  txn_num=%4.4s,key_revsal=%32.32s.",
			ptOrigTxn->txn_num, ptOrigTxn->key_revsal);

	nReturnCode = DbsTxn (DBS_SELECT22, ptOrigTxn );

	if( nReturnCode != 0 )
	{
		ptOrigTxn->key_revsal[KEY_RSP_LEN] = 0;
		ptOrigTxn->txn_num[FLD_TXN_NUM_LEN] = 0;
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsTxn select22 error, %d. txn_num=%4.4s,key_revsal=%32.32s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		
		return 0;
	}

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sMsgSrcId[%4.4s]", ptIpcIntTxn->sMsgSrcId );
    
    /* ���ÿ��Զ�������F037 = F007����λ + F011 */
    if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_CBDB_REQ)
    {
        if(memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) == 0)
        {
            memcpy (ptIpcIntTxn->sRetrivlRefNum, ptIpcIntTxn->sTransmsnDateTime+4, 6);
            memcpy (ptIpcIntTxn->sRetrivlRefNum+6, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
        }
    }
    
	if (memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) )
	{
		/* check originl txn status */
		/* check F002, F004, txn state, revsal_flag, cancel_flag */
		if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
		{
			memset (sPanLen, 0, sizeof (sPanLen));
			memcpy (sPanLen, ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
			nPanLen = atoi (sPanLen);
			if (memcmp (ptOrigTxn->pan, ptIpcIntTxn->sPrimaryAcctNum, nPanLen))
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"check txn pan fail. txn_num=%4.4s,key_revsal=%32.32s.",
						ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
				memcpy (sRespCode, F039_INVALID_PAN, F039_LEN);
				return 0;
			}
		}
		else
		{
			memset (sPanLen, 0, sizeof (sPanLen));
			memcpy (sPanLen, ptOrigTxn->pan_len, F002_LEN_LEN);
			nPanLen = atoi (sPanLen);
			memcpy (ptIpcIntTxn->sPrimaryAcctNumLen, ptOrigTxn->pan_len, F002_LEN_LEN);
			memset (ptIpcIntTxn->sPrimaryAcctNum, ' ', F002_VAL_LEN);
			memcpy (ptIpcIntTxn->sPrimaryAcctNum, ptOrigTxn->pan, nPanLen);
		}

		/*
		   if (memcmp (ptOrigTxn->amt_trans, ptIpcIntTxn->sAmtTrans, F004_LEN))
		   {
		   HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		   "check txn amount fail. txn_num=%4.4s,key_revsal=%32.32s.",
		   ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
		   memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
		   return 0;
		   }
		 */
		/*
		   if (ptIpcIntTxn->sAuthrIdResp[0] != ' ' &&
		   ptIpcIntTxn->sAuthrIdResp[0] != 0x00 )
		   {
		   if (memcmp (ptOrigTxn->authr_id_r, ptIpcIntTxn->sAuthrIdResp, F038_LEN))
		   {
		   HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		   "check txn auth id fail. txn_num=%4.4s,key_revsal=%32.32s.",
		   ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
		   memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		   return 0;
		   }
		   }
		 */
		if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN) &&
				memcmp (ptOrigTxn->trans_state, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN))
		{
		    if(memcmp(ptIpcIntTxn->sTxnNum, "2383", 4) == 0 ||
		        memcmp(ptIpcIntTxn->sTxnNum, "2385", 4) == 0)
		    {
		        if(memcmp(ptOrigTxn->misc_flag+14+4, "00", 2) != 0)
		        {
		            memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		            /*add by xu zhen*/
			        memcpy(ptIpcIntTxn->sAuthrIdResp,ptOrigTxn->authr_id_resp,F038_LEN);
			        memcpy(ptIpcIntTxn->sPosEntryModeCode,ptOrigTxn->pos_entry_mode,F022_LEN);
			        /*end*/
		            return 0;
		        }
		    }
		    else
		    {
			    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			    		"check txn state fail. txn_num=%4.4s,key_revsal=%32.32s.",
			    		ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			    memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
			    /*add by xu zhen*/
			    memcpy(ptIpcIntTxn->sAuthrIdResp,ptOrigTxn->authr_id_resp,F038_LEN);
			    memcpy(ptIpcIntTxn->sPosEntryModeCode,ptOrigTxn->pos_entry_mode,F022_LEN);
			    /*end*/
			    return 0;
			}
		}
		if (ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"check txn cancel flag fail. txn_num=%4.4s,key_revsal=%32.32s.",
					ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
			return 0;
		}
		if (ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL )
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"check txn revsal flag fail. txn_num=%4.4s,key_revsal=%32.32s.",
					ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			memcpy (sRespCode, F039_DUPL_TXN, F039_LEN);
			return 0;
		}
		
		/* ����Ƿ��ճ���(��������������) */
		if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ ||
		    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
		{
		    memset(sCurrentTime, 0, sizeof(sCurrentTime));
	        /*CommonGetCurrentTime(sCurrentTime);*/
	        memcpy(sCurrentTime, gsTimeCurTs, 14);
	        
	        if(memcmp(ptOrigTxn->inst_date, sCurrentTime, 8) != 0)
	        {
	            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    		"check revsal txn date error. txn_num=%4.4s, key_revsal=%32.32s. orig_date[%8.8s] revsal_date[%8.8s]",
		    		ptOrigTxn->txn_num,ptOrigTxn->key_revsal, ptOrigTxn->inst_date, sCurrentTime);
		        memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		        return 0;
	        }
	    }
	}
	/*add by xu zhen*/
	if (memcmp (ptOrigTxn->amt_trans, ptIpcIntTxn->sAmtTrans, F004_LEN)&&(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_BDT_REQ))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn amount fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s,OrigAmt=%12.12s,Amt=%12.12s",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id,ptOrigTxn->amt_trans,ptIpcIntTxn->sAmtTrans);
		memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
		return 0;
	}
	/*end*/
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CheckConfirmTxn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckConfirmTxn";
	char    sPanLen[F002_LEN_LEN+1];
	int        nPanLen;
	int        nReturnCode;
	Tbl_txn_Def    stTxn;
	memset(&stTxn,0,sizeof(Tbl_txn_Def));

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	/* DBS_SELECT22: txn_num, key_revsal */
	ptOrigTxn->txn_num[INDEX_TXN_NUM_TYPE] --;

	nReturnCode = DbsTxn (DBS_SELECT22, ptOrigTxn );

	if( nReturnCode != 0)
	{
		ptOrigTxn->key_revsal[KEY_RSP_LEN] = 0;
		ptOrigTxn->txn_num[FLD_TXN_NUM_LEN] = 0;
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsTxn select22 error, %d. txn_num=%4.4s,key_revsal=%32.32s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		/*����ת��ȷ�ϣ�����ԭ���ף���ת�������Ĺ�Ա�ţ��������copy*/
		if( (!memcmp(ptIpcIntTxn->sTxnNum,"2443",4) || !memcmp(ptIpcIntTxn->sTxnNum,"2453",4)) &&
			( memcmp(ptIpcIntTxn->sFwdInstIdCode,"0316",4) == 0))
	{
		HtLog(  gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sCardAccptrTermnlId[%.8s]",ptIpcIntTxn->sCardAccptrTermnlId);
		HtLog(  gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sCardAccptrId[%.15s]",ptIpcIntTxn->sCardAccptrId);

		memcpy(stTxn.trans_date_time  , ptIpcIntTxn->sOrigDataElemts+10, F007_LEN);
		memcpy(stTxn.cup_ssn  , ptIpcIntTxn->sOrigDataElemts+4  , F011_LEN);
		memcpy(stTxn.acq_inst_id_code  , ptIpcIntTxn->sOrigDataElemts+23, 8);
		memcpy(stTxn.fwd_inst_id_code  , ptIpcIntTxn->sOrigDataElemts+34, 8);
		nReturnCode = DbsTxn (DBS_SELECT2, &stTxn);
		if(nReturnCode && nReturnCode != DBS_NOTFOUND)
		{			
			HtLog(  gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "DbsTxn(DBS_SELECT2) err.%d",nReturnCode);
			/* return -1; */
		}
		else if(nReturnCode == DBS_NOTFOUND)
		{			
			HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "DbsTxn(DBS_SELECT2) not found!");
			HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "DbsTxn(DBS_SELECT2)%s",stTxn.trans_date_time);
			HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "DbsTxn(DBS_SELECT2)%s",stTxn.cup_ssn);
			HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "DbsTxn(DBS_SELECT2)%s",stTxn.acq_inst_id_code );
			HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "DbsTxn(DBS_SELECT2)%s",stTxn.fwd_inst_id_code);
		}
		else 
		{	
		   strncpy( ptIpcIntTxn->sTermSSN,&stTxn.addint_data[83],5);
		   /*�������Ԥ�ȱ��棬packsend��ǿ�Ƹ�ֵ*/
		   ptIpcIntTxn->cF122Ind = FLAG_YES_C;
		   memcpy( ptIpcIntTxn->sAcqInstResvdLen,"024",3);
		   memcpy( ptIpcIntTxn->sAcqInstResvd,&stTxn.addint_data[8],15);
		   memcpy( ptIpcIntTxn->sAcqInstResvd+15,&stTxn.addint_data[48],9);
		}
	}
		return 0;
	}
	
	/*����ת��ȷ�ϣ�����ԭ���ף���ת�������Ĺ�Ա�ţ��������copy*/
	if( (!memcmp(ptIpcIntTxn->sTxnNum,"2443",4) || !memcmp(ptIpcIntTxn->sTxnNum,"2453",4)) &&
		( memcmp(ptIpcIntTxn->sFwdInstIdCode,"0316",4) == 0))
	{
		memcpy(ptIpcIntTxn->sTermSSN,ptOrigTxn->acq_swresved,5);
  	memcpy(ptIpcIntTxn->sAcqInstResvd,ptOrigTxn->acq_swresved,24);
  }
  
	if (memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) )
	{
		/* check originl txn status */
		/* check F002, F004 */
		memset (sPanLen, 0, sizeof (sPanLen));
		memcpy (sPanLen, ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
		nPanLen = atoi (sPanLen);
		if (memcmp (ptOrigTxn->pan, ptIpcIntTxn->sPrimaryAcctNum, nPanLen)&&(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_BDT_REQ) )
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"check txn pan fail. txn_num=%4.4s,key_revsal=%32.32s.",
					ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			memcpy (sRespCode, F039_INVALID_PAN, F039_LEN);
			return 0;
		}
		if (memcmp (ptOrigTxn->amt_trans, ptIpcIntTxn->sAmtTrans, F004_LEN)&&(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_BDT_REQ))
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"check txn amount fail. txn_num=%4.4s,key_revsal=%32.32s.",
					ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
			return 0;
		}

		/* check txn state */
		switch (ptOrigTxn->trans_state[0])
		{
			case TRANS_STATE_SUCC_C:
				/* check cancel_flag */
				if (ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL)
				{
					memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
					HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							"check txn cancel flag fail. txn_num=%4.4s,key_revsal=%32.32s.",
							ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
				}
				else
				{
					if (ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL )
					{
						memcpy (sRespCode, F039_DUPL_TXN, F039_LEN);
						HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
								"check txn revsal flag fail. txn_num=%4.4s,key_revsal=%32.32s.",
								ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
					}
				}
				break;
			case TRANS_STATE_NO_RSP_C:
			case TRANS_STATE_TIME_OUT_C:
			case TRANS_STATE_NO_ACCT_RSP_C:
			case TRANS_STATE_ACCT_TO_C:
				memcpy (sRespCode, F039_SUCC_FAULT_6, F039_LEN);
				break;
			case TRANS_STATE_REJ_BY_CUPS_C:
			case TRANS_STATE_REJ_BY_HOST_C:
			case TRANS_STATE_REJ_PIN_MAC_C:
			case TRANS_STATE_REJ_BY_FE_C:
				memcpy (sRespCode, F039_SUCC_FAULT_5, F039_LEN);
				break;
			default:
				memcpy (sRespCode, F039_MAL_FUNCTION, F039_LEN);
				break;
		}
	}
	else
		memcpy (sRespCode, F039_SUCC_FAULT_6, F039_LEN);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CheckCancelTxn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckCancelTxn";
	char    sTxnNum[FLD_TXN_NUM_LEN+1];
	char    sPanLen[F002_LEN_LEN+1];
	int        nPanLen;
	int        nReturnCode;
	char    sCurrentTime[15];
    char    sCurrentDate[8+1];
    
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	ptOrigTxn->txn_num[INDEX_TXN_NUM_TYPE] = ptOrigTxn->txn_num[INDEX_TXN_NUM_TYPE] - 2;

	memset (sTxnNum, 0, sizeof (sTxnNum));
	memcpy (sTxnNum, ptIpcIntTxn->sTxnNum+INDEX_TXN_NUM, 2);
	switch (atoi(sTxnNum))
	{
		case TXN_PRE_AUTH:
			HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%s] TXN_PRE_AUTH.", sTxnNum);
			/* DBS_SELECT23: txn_num, F038, F041, F002 */
			nReturnCode = DbsAuth (DBS_SELECT23, ptOrigTxn );
			
			if( nReturnCode != 0 )
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"DbsAuth select23 error, %d. txn_num=%4.4s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
						nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
				memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
				return 0;
			}
			break;
		default:
			/* DBS_SELECT23: txn_num, key_cancel*/
			nReturnCode = DbsTxn (DBS_SELECT23, ptOrigTxn );

			if( nReturnCode != 0 )
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"DbsTxn select23 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
						nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
				memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
				return 0;
			}
			break;
	}

    /* ���ÿ�Ԥ��Ȩ��������鳷��ʱ���Ƿ��� */
    if(memcmp(ptIpcIntTxn->sTxnNum, "3017", 4) == 0)
    {
        memset(sCurrentTime, 0, sizeof(sCurrentTime));
	    /*CommonGetCurrentTime(sCurrentTime);*/
	    memcpy(sCurrentTime, gsTimeCurTs, 14);
	    
	    if(memcmp(ptOrigTxn->inst_date, sCurrentTime, 8) != 0)
	    {
	        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"credit card afterday cancel. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s. orig_date[%8.8s] today[%8.8s]",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,
				ptOrigTxn->card_accp_id, ptOrigTxn->inst_date, sCurrentTime);
		    memcpy (ptIpcIntTxn->sTransState, "G", FLD_TRANS_STATE_LEN);
		    return 0;
	    }
	    
	    memset(sCurrentDate,0,sizeof(sCurrentDate));
	    memcpy(sCurrentDate,sCurrentTime,8);	    	    	    
    }
    
	/* check originl txn status */
	/* check F002, F004, txn state, revsal_flag, cancel_flag */

	/***��鿨��***/
	memset (sPanLen, 0, sizeof (sPanLen));
	memcpy (sPanLen, ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
	nPanLen = atoi (sPanLen);
	if (memcmp (ptOrigTxn->pan, ptIpcIntTxn->sPrimaryAcctNum, nPanLen))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn pan fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INVALID_PAN, F039_LEN);
		return 0;
	}
		
if ( (memcmp(ptIpcIntTxn->sTxnNum,"3015",4 )==0) || (memcmp(ptIpcIntTxn->sTxnNum,"3013",4 )==0)|| (memcmp(ptIpcIntTxn->sTxnNum,"3011",4 )==0) || (memcmp(ptIpcIntTxn->sTxnNum,"5015",4 )==0))
{
	if (memcmp (ptOrigTxn->amt_return, ptIpcIntTxn->sAmtTrans, F004_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn amount fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
		return 0;
	}
}
else
{
	if (memcmp (ptOrigTxn->amt_trans, ptIpcIntTxn->sAmtTrans, F004_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn amount fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
		return 0;
	}
}
	/*
	   if (ptIpcIntTxn->sAuthrIdResp[0] != ' ' &&
	   ptIpcIntTxn->sAuthrIdResp[0] != 0x00 )
	   {
	   if (memcmp (ptOrigTxn->authr_id_r, ptIpcIntTxn->sAuthrIdResp, F038_LEN))
	   {
	   HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	   "check txn auth id fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
	   ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
	   memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
	   return 0;
	   }
	   }
	 */
	 
	if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn state fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		return 0;
	}
		
	
	if (ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL ||
		ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL ||
		memcmp(ptOrigTxn->trans_state, TRANS_STATE_HAD_RETURN, 1) == 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn cancel flag fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s,cancel_flag[%1.1s] revsal_flag[%1.1s] ",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id,ptOrigTxn->cancel_flag,ptOrigTxn->revsal_flag);
		memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
		return 0;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CheckAddAuthTxn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckAddAuthTxn";
	int        nReturnCode;

	/* this func is the same as CheckAuthCompTxn */

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	/* DBS_SELECT23: F038, F041, F002 */
	nReturnCode = DbsAuth (DBS_SELECT23, ptOrigTxn );
	if( nReturnCode != 0 )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsAuth select23 error, %d. txn_num=%4.4s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		return 0;
	}

	/* check originl txn status */
	/* check txn state, revsal_flag, cancel_flag */
	if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn state fail.  txn_num=%4.4s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
		return 0;
	}
	if (ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL ||
			ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn (revsal flag, cancel flag) fail.  txn_num=%4.4s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
		return 0;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CheckAuthCompTxn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckAuthCompTxn";
	int        nReturnCode;
	double        amt_return;
	double        amt_trans;
    char     sAmt[13];
    memset(sAmt,0,sizeof(sAmt));
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	/* DBS_SELECT23: F038, F041, F002 */
	nReturnCode = DbsAuth (DBS_SELECT23, ptOrigTxn );
	if( nReturnCode != 0 )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsAuth select23 error, %d. txn_num=%4.4s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		return 0;
	}

	/* check originl txn status */
	/* check txn state, revsal_flag, cancel_flag */
	if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn state fail.  txn_num=%4.4s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
		return 0;
	}
	if (ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL ||
			ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn (revsal flag, cancel flag) fail.  txn_num=%4.4s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
		return 0;
	}
	
	
	/* ���Ԥ��Ȩ��ɽ�� */
	memcpy(sAmt,ptOrigTxn->amt_return,12);
    amt_return=atof(sAmt);

    amt_return=amt_return*0.0115;

    amt_return=DecRound(amt_return,2);

    memcpy(sAmt,ptIpcIntTxn->sAmtTrans,12);
    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"ptIpcIntTxn->sAmtTrans[%12.12s]",
				ptIpcIntTxn->sAmtTrans);
    amt_trans=atof(sAmt);

    amt_trans=amt_trans*0.01;

    amt_trans=DecRound(amt_trans,2);

    if ((amt_trans-amt_return)>D_ZERO)
    	{
    		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"Ԥ��Ȩ��ɽ���amt_trans=%f, amt_return=%f",
				amt_trans,amt_return);
		memcpy (sRespCode, F039_LIMIT_AMT, F039_LEN);
		return 0;
    	}
    
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CheckReturnTxn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode, int *pnInHsTxnFlag, char *sAmtReturn)
{
	char    sFuncName[] = "CheckReturnTxn";
	char    sPanLen[F002_LEN_LEN+1];
	int        nPanLen;
	int        nReturnCode;
	Tbl_sys_stat_Def tSysStat;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);
	*pnInHsTxnFlag = 0;

	/* DBS_SELECT23: key_cancel, txn_num */
	if ( !memcmp(ptIpcIntTxn->sTxnNum,"5171",4) )
      memcpy (ptOrigTxn->txn_num, "1711", FLD_TXN_NUM_LEN);
	else
	  memcpy (ptOrigTxn->txn_num, TXN_NUM_PCT_BDT_REQ, FLD_TXN_NUM_LEN);
	nReturnCode = DbsTxn (DBS_SELECT23, ptOrigTxn );
	if( nReturnCode != 0 && nReturnCode != DBS_NOTFOUND)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsTxn select23 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		return 0;
	}
	if (nReturnCode == DBS_NOTFOUND)
	{
	  if( !memcmp(ptIpcIntTxn->sTxnNum,"5171",FLD_TXN_NUM_LEN))
	  {
		 memcpy (ptOrigTxn->txn_num, "17A1", FLD_TXN_NUM_LEN);
		 nReturnCode = DbsTxn (DBS_SELECT23, ptOrigTxn );
		 if( nReturnCode != 0 && nReturnCode != DBS_NOTFOUND)
		 {
			 HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		          "DbsTxn select23 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
				 nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
			 memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
			 return 0;
		 }
		 if( nReturnCode == DBS_NOTFOUND )
		 {
		    nReturnCode = DbsTxn (DBS_SELECT25, ptOrigTxn );
		    if( nReturnCode != 0)
		    {
			   HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn DBS_SELECT25 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
					nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
			   memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
			   return 0;
		    }
		    *pnInHsTxnFlag = 1;
          }
       }
       else {
		    nReturnCode = DbsTxn (DBS_SELECT25, ptOrigTxn );
		    if( nReturnCode != 0)
		    {
			   HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn DBS_SELECT25 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
					nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
			   memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
			   return 0;
		    }
		    *pnInHsTxnFlag = 1;
       }
	}
#if 0
	/* get current CUP settlement date */
	memset (&tSysStat, 0, sizeof (tSysStat));
	if (!getenv(CS_SC_CODE))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"env CS_SC_CODE not found.");
		memcpy (sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}

	memcpy (tSysStat.record_id, (char *)getenv(CS_SC_CODE), INST_ID_LEN);
	nReturnCode = DbsSYSSTAT (DBS_SELECT, &tSysStat );
	if( nReturnCode != 0 )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsSYSSTAT select error, %d.", nReturnCode);
		memcpy (sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}

	/* check originl txn status */
	/* check settlement date, it should not be the same as that in orig txn */
	if (memcmp (ptOrigTxn->date_settlmt, tSysStat.cups_stlm_date, F015_LEN) == 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn stlm date fail. txn_num=%4.4s,key_cancel=%32.32s,date_settlmt=%4.4s",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->date_settlmt);
		memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		return 0;
	}

	/* check F002, F004, txn state, revsal_flag, cancel_flag */
	memset (sPanLen, 0, sizeof (sPanLen));
	memcpy (sPanLen, ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
	nPanLen = atoi (sPanLen);
	if (memcmp (ptOrigTxn->pan, ptIpcIntTxn->sPrimaryAcctNum, nPanLen))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn pan fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INVALID_PAN, F039_LEN);
		return 0;
	}
	memset (sAmtReturn, 0, sizeof (sAmtReturn));
	memcpy (sAmtReturn, ptOrigTxn->amt_return, F004_LEN);
	/* AddString (sAmtReturn, F004_LEN, ptIpcIntTxn->sAmtTrans, F004_LEN);
	if (memcmp (ptOrigTxn->amt_trans, sAmtReturn, F004_LEN)<0) */
    if ( atof(sAmtReturn) + atof(ptIpcIntTxn->sAmtTrans) - atof(ptOrigTxn->amt_trans) > D_ZERO )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"orig amt=%2f, total amt=%f.amt:%f",
				atof(ptOrigTxn->amt_trans), atof(sAmtReturn),atof(ptIpcIntTxn->sAmtTrans));
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn amount fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_LIMIT_AMT, F039_LEN);
		return 0;
	}
	AddString (sAmtReturn, F004_LEN, ptIpcIntTxn->sAmtTrans, F004_LEN);
	/*
	   if (ptIpcIntTxn->sAuthrIdResp[0] != ' ' &&
	   ptIpcIntTxn->sAuthrIdResp[0] != 0x00 )
	   {
	   if (memcmp (ptOrigTxn->authr_id_r, ptIpcIntTxn->sAuthrIdResp, F038_LEN))
	   {
	   HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	   "check txn auth id fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
	   ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
	   memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
	   return 0;
	   }
	   }
	 */
	if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN)&&memcmp (ptOrigTxn->trans_state, TRANS_STATE_HAD_RETURN, FLD_TRANS_STATE_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn state fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		return 0;
	}
	if (ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL ||
			ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn cancel flag fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
		return 0;
	}
#endif
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ʱ�����˻�У��");
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/* ����ԭ��ΪCheckReturnTxnTDB,������BDB����ֵ��֮���ΪCheckReturnTxnAll */
int CheckReturnTxnAll (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckReturnTxnAll";
	char    geriflag = 'N';
	/*
	char    sPanLen[F002_LEN_LEN+1];
	int        nPanLen;
	*/
	int        nReturnCode;
	char    transamt[13];
	double    allamt = 0 ;
	/*
	Tbl_sys_stat_Def tSysStat;
	*/

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	/* DBS_SELECT23: key_cancel, txn_num */
	if( !memcmp(ptOrigTxn->txn_num, TXN_NUM_PCT_TDB_RET ,FLD_TXN_NUM_LEN) )
	{
		/* ������pos */
		memcpy (ptOrigTxn->txn_num, TXN_NUM_PCT_TDB_REQ, FLD_TXN_NUM_LEN);
	}
	else if( !memcmp(ptOrigTxn->txn_num, TXN_NUM_PCT_BDB_RET, FLD_TXN_NUM_LEN) )
	{
		/* ������pos����ͳһ���� */
		memcpy (ptOrigTxn->txn_num, TXN_NUM_PCT_BDB_REQ ,FLD_TXN_NUM_LEN);
	}
	else if( !memcmp(ptOrigTxn->txn_num, TXN_NUM_PCT_CBDB_RET, FLD_TXN_NUM_LEN) )
	{
		/* ������pos���ÿ� */
		memcpy (ptOrigTxn->txn_num, TXN_NUM_PCT_CBDB_REQ ,FLD_TXN_NUM_LEN);
	}
	else if( !memcmp(ptOrigTxn->txn_num, TXN_NUM_FQ_PCT_CBDB_RET, FLD_TXN_NUM_LEN) )
	{
		/* ������pos���ÿ�-���� */
		memcpy (ptOrigTxn->txn_num, TXN_NUM_FQ_PCT_CBDB_REQ ,FLD_TXN_NUM_LEN);
	}
	else if( !memcmp(ptOrigTxn->txn_num, TXN_NUM_CZK_BDB_RET, FLD_TXN_NUM_LEN) )
	{
		/* ��ֵ�� */
		memcpy (ptOrigTxn->txn_num, TXN_NUM_CZK_BDB_REQ, FLD_TXN_NUM_LEN );
	}
	else if( !memcmp(ptOrigTxn->txn_num, TXN_NUM_CZK_TDB_RET, FLD_TXN_NUM_LEN) )
	{
		/* ��ֵ�� */
		memcpy (ptOrigTxn->txn_num, TXN_NUM_CZK_TDB_REQ, FLD_TXN_NUM_LEN );
	}
	if ( !memcmp(ptIpcIntTxn->sTxnNum,"5175",4) )
      memcpy (ptOrigTxn->txn_num, "1715", FLD_TXN_NUM_LEN);
	if ( !memcmp(ptIpcIntTxn->sTxnNum,"5171",4) )
      memcpy (ptOrigTxn->txn_num, "1711", FLD_TXN_NUM_LEN);
	nReturnCode = DbsTxn (DBS_SELECT23, ptOrigTxn );
	if( nReturnCode != 0 && nReturnCode != DBS_NOTFOUND)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsTxn select23 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		return 0;
	}
	if (nReturnCode == DBS_NOTFOUND)
	{
		nReturnCode = DbsTxn (DBS_SELECT25, ptOrigTxn );
		if( nReturnCode != 0)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn DBS_SELECT25 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
					nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
			memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
			return 0;
		}
		geriflag = 'Y';
	}

	if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN) 
	    && memcmp (ptOrigTxn->trans_state, TRANS_STATE_HAD_RETURN, FLD_TRANS_STATE_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn state fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		return 0;
	}
	
	/***�ж��ʺ� **/
	if ( memcmp(ptIpcIntTxn->sPrimaryAcctNum , ptOrigTxn->pan , F002_VAL_LEN ) != 0 )
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR,__FILE__,__LINE__,"�ʺ�error[%19.19s][%s]",ptIpcIntTxn->sPrimaryAcctNum,ptOrigTxn->pan);
		memcpy (sRespCode, "25", F039_LEN);
		return 0;
	}
	
	memset(transamt , 0 , sizeof(transamt));
	memcpy(transamt , ptIpcIntTxn->sAmtTrans , 12 );
	/***�ж��˻���***/
	if ((atof(ptOrigTxn->amt_trans) - atof(transamt)) < M_ZERO )  /**�˻����̫�� **/
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"���  error, %d. txn_num=%4.4s,key_cancel=%32.32s,amtold[%f],TH[%f].",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel,atof(ptOrigTxn->amt_trans) , atof(transamt));
		memcpy (sRespCode, "61", F039_LEN);
		return 0;
	}
	else
	{
		/**�Ƚ��˻������ۼƽ�� */
	/*	if ( atof(ptOrigTxn->addtnl_amt) + atof(transamt) - atof(ptOrigTxn->amt_trans) > D_ZERO )
		{
			HtLog(gsLogFile, HT_LOG_MODE_ERROR,__FILE__,__LINE__,"���error[%12.12s][%12.12s][%12.12s]",ptOrigTxn->addtnl_amt,transamt, ptOrigTxn->amt_trans );
			memcpy (sRespCode, "61", F039_LEN);
			return 0;
		}
		else
		{*/	
		if ( atof(ptOrigTxn->amt_return) + atof(transamt) - atof(ptOrigTxn->amt_trans) > D_ZERO )
		{
			HtLog(gsLogFile, HT_LOG_MODE_ERROR,__FILE__,__LINE__,"���error[%12.12s][%12.12s][%12.12s]",ptOrigTxn->amt_return,transamt, ptOrigTxn->amt_trans );
			memcpy (sRespCode, "61", F039_LEN);
			return 0;
		}
		else
		{
			/**�ۼƸ����˻���� **/
			/*allamt = atof(transamt) + atof(ptOrigTxn->addtnl_amt);
			sprintf(ptOrigTxn->addtnl_amt , "%012.0f" , allamt );*/
			allamt = atof(transamt) + atof(ptOrigTxn->amt_return);
			sprintf(ptOrigTxn->amt_return , "%012.0f" , allamt );
			
			DbsBegin ();
			/***************
			 * ��¼���ݿ�
			 ****************/
			if(geriflag == 'N')
				nReturnCode = DbsTxn (DBS_UPDATE4, ptOrigTxn);
			else
				nReturnCode = DbsTxn (DBS_UPDATE5, ptOrigTxn);

			if (nReturnCode )
			{
				DbsRollback ();
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn update error, %d. Discard this message.", nReturnCode);

				return -1;
			}
			DbsCommit ();
			
		}

	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int SetKeyRsp (T_IpcIntTxnDef *ptIpcIntTxn)
{
	char    sFuncName[] = "SetKeyRsp";
	int        nReturnCode;
	int        i;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDT_REQ:
			i = 0;
			if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0)
			    memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sSysTraceAuditNum, FLD_SYS_SEQ_NUM_LEN);
			else
			    memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sSysSeqNum, FLD_SYS_SEQ_NUM_LEN);
			i += FLD_SYS_SEQ_NUM_LEN;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
			i += F007_LEN;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sAcqInstIdCode, INST_ID_LEN);
			i += INST_ID_LEN;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sFwdInstIdCode, INST_ID_LEN);
			break;
		case TXN_NUM_BDT_RSP:
			i = 0;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
			i += FLD_SYS_SEQ_NUM_LEN;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
			i += F007_LEN;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sAcqInstIdCode, INST_ID_LEN);
			i += INST_ID_LEN;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sFwdInstIdCode, INST_ID_LEN);
			/*if (!memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
            {
                nReturnCode = nSetSlmtDate((char *)getenv(CS_SC_CODE),ptIpcIntTxn->sDateSettlmt);
			    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nSetStlmDate nReturnCode %d", nReturnCode);
			}*/
			break;
		case TXN_NUM_TDB_REQ:
			/*nReturnCode = nSetSlmtDate((char *)getenv(CS_SC_CODE),ptIpcIntTxn->sDateSettlmt);
			HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nSetStlmDate nReturnCode %d", nReturnCode);*/
			nReturnCode = SwtCustSetKeyRsp (ptIpcIntTxn);
			break;
		case TXN_NUM_TDB_RSP:
		case TXN_NUM_BDB_REQ:
		case TXN_NUM_BDB_RSP:
		case TXN_NUM_CBDB_REQ:
		case TXN_NUM_CBDB_RSP:
			nReturnCode = SwtCustSetKeyRsp (ptIpcIntTxn);
			break;
		default:
			break;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sKeyRsp:");
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int SetKeyRevsal (T_IpcIntTxnDef *ptIpcIntTxn)
{
	char    sFuncName[] = "SetKeyRevsal";
	int     nReturnCode;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	nReturnCode = SwtCustSetKeyRevsal (ptIpcIntTxn);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sKeyRevsal:");
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, ptIpcIntTxn->sKeyRevsal, KEY_REVSAL_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int SetKeyCancel (T_IpcIntTxnDef *ptIpcIntTxn)
{
	char    sFuncName[] = "SetKeyCancel";
	int     nReturnCode;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	nReturnCode = SwtCustSetKeyCancel (ptIpcIntTxn);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sKeyCancel:");
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, ptIpcIntTxn->sKeyCancel, KEY_CANCEL_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/* get total amount sAmtTrans from sAddtnlData */
/* sAddtnlData: input, F057 */
/* sAmtTrans: output */
/* return: 0: succ, -1: fail */
int GetTAFromF057 (char *sAddtnlData, char *sAmtTrans)
{
	char    sFuncName[] = "GetTAFromF057";

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	/* check format string */
	if (memcmp (sAddtnlData, F057_DATA_FM_TA, F057_DATA_FM_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check F057 error, invalid data format value");
		return -1;
	}

	/* save total amount */
	memcpy (sAmtTrans, sAddtnlData+F057_DATA_FM_LEN , F004_LEN);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}
/*****************************************
*��ȡ׷��Ԥ��Ȩ�����Ȩ�ܶ�
*int SetTAFromF057 (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *tAuth,char *sTotlAmt)
*input :tAuth  Ԥ��Ȩ
*  			sTotlAmt �˴���ǰԤ��Ȩ�ܶ�
*output sAddtnlData��tAuth
*
******************************************/
int SetTAFromF057 (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *pAuth,char *sTotlAmt)
{
	char    sFuncName[] = "SetTAFromF057";
	double  dAmt;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	
	/*cal total amount*/
	dAmt =  atof(sTotlAmt);
	dAmt += atof(pAuth->amt_trans);	
	sprintf(pAuth->amt_return,"%012.0f",dAmt);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, " YSQ total Amt = [%12.12s].", pAuth->amt_return);

	/*******make F057 value**********/
	sprintf(ptIpcIntTxn->sAddtnlDataLen,"%03d",F057_DATA_FM_LEN+F004_LEN);
	
	memset(ptIpcIntTxn->sAddtnlData,' ',F057_VAL_LEN);
	memcpy(ptIpcIntTxn->sAddtnlData, F057_DATA_FM_TA, F057_DATA_FM_LEN);
	memcpy (ptIpcIntTxn->sAddtnlData+F057_DATA_FM_LEN,pAuth->amt_return, F004_LEN);
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, " F057Date = [%14.14s].", ptIpcIntTxn->sAddtnlData);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}
int CheckConfirmExist(T_IpcIntTxnDef *ptIpcIntTxn)
{
	char    sFuncName[] = "CheckConfirmExist";
	/*
	char    sPanLen[F002_LEN_LEN+1];
	int        nPanLen;
	*/
	int        nReturnCode;
	Tbl_txn_Def        ptOrigTxn;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	if(memcmp(ptIpcIntTxn->sTxnNum,"1083",4)&&memcmp(ptIpcIntTxn->sTxnNum,"1143",4))
		return 0;

	/* DBS_SELECT22: txn_num, key_revsal */
	memset((char *)&ptOrigTxn,0,sizeof(Tbl_txn_Def));
	memcpy(ptOrigTxn.txn_num,ptIpcIntTxn->sTxnNum,4);
	ptOrigTxn.txn_num[INDEX_TXN_NUM_TYPE]++;
	memcpy( ptOrigTxn.key_revsal,ptIpcIntTxn->sKeyRevsal,KEY_REVSAL_LEN);
	nReturnCode = DbsTxn (DBS_SELECT22, (Tbl_txn_Def *)&ptOrigTxn );
	if( nReturnCode )
		return 0;
	if(!memcmp(ptOrigTxn.resp_code,F039_SUCCESS,2))
		return 1;
	else
		return 2;
}

int SetBDBMisc(T_IpcIntTxnDef *ptIpcIntTxn)
{
	char             sCurrentTime[15];
	char             sTransAmt[12+1];
	char             sAmt[15+1];
	int              nReturnCode;
	Tbl_sys_stat_Def tSysStat;

	memset (&tSysStat, 0, sizeof (tSysStat));
	if (!getenv(CS_SC_CODE))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"env CS_SC_CODE not found.");
		memcpy (ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}

	memcpy (tSysStat.record_id, (char *)getenv(CS_SC_CODE), INST_ID_LEN);
	nReturnCode = DbsSYSSTAT (DBS_SELECT, &tSysStat );
	if( nReturnCode != 0 )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsSYSSTAT select error, %d.", nReturnCode);
		memcpy (ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}

	/*CommonGetCurrentTime(sCurrentTime);*/
	memcpy(sCurrentTime, gsTimeCurTs, 14);
	if (!memcmp(tSysStat.cups_stlm_date, "0101", 4) &&
			!memcmp(sCurrentTime + 4, "1231", 4))
	{
		memset(sCurrentTime + 4, 0, sizeof(sCurrentTime) - 4);
		sprintf(sCurrentTime, "%04d", atoi(sCurrentTime) + 1);
		memcpy(ptIpcIntTxn->sMisc+20, sCurrentTime, 4);
	}
	else
		memcpy(ptIpcIntTxn->sMisc+20, sCurrentTime, 4);

	memset(sTransAmt, 0, sizeof(sTransAmt));
	memcpy(sTransAmt, ptIpcIntTxn->sAmtTrans, 12);
	sprintf(sAmt, "%015.2lf", atof(sTransAmt) / 100.0);
	memcpy(ptIpcIntTxn->sMisc+24, sAmt, 15);
	/*  ������־ add by wjing 20090807*/
			/* ������ ֱ���� */
       memcpy(&ptIpcIntTxn->sMisc[82],"12",2); 

			/* ����� */
			if ( memcmp(&ptIpcIntTxn->sAcqInstIdCode[4],&ptIpcIntTxn->sPrimaryAcctNum[6],4) == 0 )
				 ptIpcIntTxn->sMisc[84] = '1';
      else
				 ptIpcIntTxn->sMisc[84] = '2';

			/* ���� */
			memcpy(&ptIpcIntTxn->sMisc[85],&ptIpcIntTxn->sFldReserved[8],2);

			/* ���� ���� */
			memcpy(&ptIpcIntTxn->sMisc[87],"01",2);

			/* 22 �� */
            memcpy(&ptIpcIntTxn->sMisc[89],&ptIpcIntTxn->sPosEntryModeCode[0],F022_LEN); 

			/* memcpy(&ptTxn->misc_1[82],&ptIpcIntTxn->sMisc[82],20);*/
			/* end */
	return 0;
}

int TransReturnOrginTxn(T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *tOrigTxn, char *sRespCode,Tbl_txn_Def *tTxn)
{
	    /*����ʱ���ɹ�������⣬����ʱ���ӵ��ۼ��˻�������*/
    /*�ɹ����߳�ʱ״̬�£�ԭ���ѽ���trans_state��ΪHAD_RETURN����ֹ�˻���ĳ�������*/
  int nReturnCode;
  double      allamt = 0;
  int i=0;
  memcpy (tOrigTxn->key_cancel+i, tOrigTxn->orig_data_elemts, F000_MSG_TYPE_LEN); /* msg type */
	i += F000_MSG_TYPE_LEN;
	memcpy (tOrigTxn->key_cancel+i, &tOrigTxn->orig_data_elemts[4] , F011_LEN); /* P����ˮ�� */
	i += F011_LEN;
	memcpy (tOrigTxn->key_cancel+i, &tOrigTxn->orig_data_elemts[10] , F007_LEN); /* P���������� */
	i += F007_LEN;
	memcpy (tOrigTxn->key_cancel+i, &tOrigTxn->orig_data_elemts[23], 8);
	
	nReturnCode = DbsTxn (DBS_SELECT23, &tOrigTxn );
	if( nReturnCode != 0 && nReturnCode != DBS_NOTFOUND)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsTxn select23 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
				nReturnCode,tOrigTxn->txn_num,tOrigTxn->key_cancel);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		return 0;
	}    	
	if(nReturnCode == DBS_NOTFOUND)	
	{
		nReturnCode = DbsTxn (DBS_SELECT25, tOrigTxn );
		if( nReturnCode != 0)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn DBS_SELECT25 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
					nReturnCode,tOrigTxn->txn_num,tOrigTxn->key_cancel);
			memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
			return 0;
    }
  }
	if(memcmp(ptIpcIntTxn->sRespCode,"00",2)&&memcmp(ptIpcIntTxn->sRespCode,"98",2))
		{
				allamt = atof(tOrigTxn->addtnl_amt)-atof(tTxn->amt_trans);
				sprintf(tOrigTxn->addtnl_amt , "%012.0f" , allamt );
	   }
	  else
		{
				memcpy(tOrigTxn->trans_state,TRANS_STATE_HAD_RETURN,1);
		 } 
  nReturnCode = DbsTxn (DBS_UPDATE1, &tOrigTxn);
  if (nReturnCode != 0 && nReturnCode != DBS_NOTFOUND )
			{
				DbsRollback ();
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn update error, %d. Discard this message.", nReturnCode);
					memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
					return 0;
			}
	if(nReturnCode == DBS_NOTFOUND)	
	{
		nReturnCode = DbsTxn (DBS_UPDATE9, tOrigTxn );
		if( nReturnCode != 0)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn DBS_SELECT25 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
					nReturnCode,tOrigTxn->txn_num,tOrigTxn->key_cancel);
			memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
			return 0;
    }
  }
	DbsCommit ();
}

/*****************************************************************************/
/* FUNC:   int MoveTxn2IcTxn (Tbl_txn_Def *ptTxn, Tbl_ic_txn_Def *ptIcTxn )  */
/* INPUT:  ptTxn: ��Ӧ��tbl_txn�ļ�¼                                        */
/*         ptIpcIntTxn: ������, ��ʽ���ڲ���IPC�ṹ                        */
/* OUTPUT: ptIcTxn: ��Ӧ��tbl_ic_txn�ļ�¼                                   */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ptTxn������дptIcTxn                                            */
/*****************************************************************************/
int MoveTxn2IcTxn (Tbl_txn_Def *ptTxn, T_IpcIntTxnDef *ptIpcIntTxn, Tbl_ic_txn_Def *ptIcTxn )
{
	char    sFuncName[] = "MoveTxn2IcTxn";
	char    sF055Len[F055_LEN_LEN+1] = {0};
	char    sCurrentTime[15];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memset ((char *)ptIcTxn, 0, sizeof (*ptIcTxn));

	memcpy (ptIcTxn->key_rsp                        , ptTxn->key_rsp        , KEY_RSP_LEN);
	memcpy (ptIcTxn->key_revsal                     , ptTxn->key_revsal      , KEY_REVSAL_LEN);
	memcpy (ptIcTxn->key_cancel                     , ptTxn->key_cancel      , KEY_CANCEL_LEN);
	memcpy (ptIcTxn->txn_num                        , ptTxn->txn_num        , FLD_TXN_NUM_LEN);
	memcpy (ptIcTxn->pan                            , ptTxn->pan            , F002_VAL_LEN);
	memcpy (ptIcTxn->amt_trans                      , ptTxn->amt_trans      , F004_LEN);
	memcpy (ptIcTxn->trans_date_time                , ptTxn->trans_date_time      , F007_LEN);
	
	memcpy (ptIcTxn->req_iclen                      , ptIpcIntTxn->sICDataLen      , F055_LEN_LEN);
	memcpy (sF055Len                                , ptIpcIntTxn->sICDataLen      , F055_LEN_LEN);
	sprintf(ptIcTxn->req_iclen, "%03d", atoi(sF055Len)*2);
	Hex2Str(ptIpcIntTxn->sICData                    , ptIcTxn->req_icdata          , atoi(sF055Len));
	
	/*CommonGetCurrentTime (sCurrentTime);*/
	memcpy (ptIcTxn->insert_time                    , gsTimeCurTs      , 14);
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}


void SetToTime(int nRouteIndex)
{
	 long retun=0;
	 char timecurt[27];
	 char timeout[27];
	 memset(timecurt,0x00,sizeof(timecurt));
	 memset(timeout,0x00,sizeof(timeout));
	 memset(gsTimeOutTs,0x00,sizeof(gsTimeOutTs));
	 memset(gsTimeCurTs,0x00,sizeof(gsTimeCurTs));
	 /*��ȡ���ݿ�ʱ��+��ʱʱ��*/
    if(nRouteIndex == -1)
        retun = GetDBoutTime( 0,timecurt ,timeout);
    else
        retun = GetDBoutTime( atol(gatTxnInf[nRouteIndex].msg_to),timecurt ,timeout);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,"insert cur time return: [%d]",retun);
    
   /* long lCurrTime = time(NULL);
    long lToTime;
    char  timecurt[100]={0};

  
    strftime(timecurt, sizeof(timecurt), "%Y-%m-%d %H:%M:%S",
             localtime((time_t*)(&lCurrTime)));
    
   HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
              "insert cur time: %s",timecurt);

   lToTime = lCurrTime + gatTxnRouteInf[nRouteIndex].nToTime;
    strftime(gsTimeOutTs, sizeof(gsTimeOutTs), "%Y-%m-%d %H:%M:%S",
             localtime((time_t*)(&lToTime)));*/
             
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "insert cur time: %s",timecurt);
    if(retun == 0)
    {
        memcpy(gsTimeCurTs,timecurt,4);       /*year*/
        memcpy(gsTimeCurTs+4,timecurt+5,2);   /*month*/
        memcpy(gsTimeCurTs+6,timecurt+8,2);   /*day*/
        memcpy(gsTimeCurTs+8,timecurt+11,2);  /*hour*/
        memcpy(gsTimeCurTs+10,timecurt+14,2); /*minute*/
        memcpy(gsTimeCurTs+12,timecurt+17,2); /*second*/
    }
    else
        CommonGetCurrentTime(gsTimeCurTs);
        
   HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "insert txn+ti timeout: %s",timeout);
    memcpy(gsTimeOutTs,timeout,strlen(timeout));
   HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "insert txn+ti time: %s",gsTimeOutTs);
 
    if (atoi(gatTxnInf[nRouteIndex].msg_to) > 0)
        gnTimeOutFlag = 1;
    else
        gnTimeOutFlag = 0;

   HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "TXN toTime value : %d gnTimeOutFlag:%d ",atoi(gatTxnInf[nRouteIndex].msg_to),gnTimeOutFlag);
}
