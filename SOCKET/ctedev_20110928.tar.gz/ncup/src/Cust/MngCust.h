#ifndef __MNG_CUST_H
#define __MNG_CUST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <errno.h>

#include "SrvDef.h"
#include "TxnNum.h"
#include "IpcInt.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "Common.h"
#include "HtLog.h"
#include "SrvParam.h"
#include "ErrCode.h"
#include "EncOpr.h"

char	gsMngCustLogFile[LOG_NAME_LEN_MAX] = "MngCust.log";

#endif
