#ifndef __SWT_CUST_H
#define __SWT_CUST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <errno.h>
#include <sys/msg.h>
#include <sys/times.h>
#include <time.h>
#include <math.h>

#include "SrvDef.h"
#include "TxnNum.h"
#include "IpcInt.h"
#include "Common.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "CstDbsTbl.h"
#include "HtLog.h"
#include "SrvParam.h"
#include "ErrCode.h"
#include "EncOpr.h"
#include "MsqOpr.h"
#include "LineStat.h"

#define MSG_SRC_ID_ANY      "9999"


extern    Tbl_txn_inf_Def     gatTxnInf[TXN_INF_NUM_MAX];
typedef struct
{
    char    caTxnNum[FLD_TXN_NUM_LEN+1];
    char    caMsgSrcId[SRV_ID_LEN+1];
    int     (*pfTxnFun)(T_IpcIntTxnDef *, int );
    char    caTxnDsp[50];
} TXNFUN;
extern    TXNFUN              gaTxns[MAXTXNS];
extern    char                gsParamMsgCompressFlag[2];
extern    T_SrvMsq            gatSrvMsq[SRV_MSQ_NUM_MAX];
extern    char                gsLogFile[LOG_NAME_LEN_MAX];
T_InstTxnParamVal InstTxnParamVal;


#endif
