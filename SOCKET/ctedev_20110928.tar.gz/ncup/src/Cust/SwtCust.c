
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: SwtCust.c                                                    */
/* DESCRIPTIONS: customrize transaction process                              */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-19  YU TONG        Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Cust/SwtCust.c,v 1.1.1.1.4.2 2011/09/23 02:54:34 ctedev Exp $" ;

#include "SwtCust.h"
#include "Quota.h"
#include "XFT.h"

typedef struct
{
	char		sBranchNo[9+1];
	char		sBankNo[9+1];
	char		sSsnType[1+1];
	char		sSsnSeqno[2+1];
	char		sTlrNo[5+1];
	char		sTlrDsp[80+1];
}T_IpcTlrDef;
static int	 gnTlr_Num;
static T_IpcTlrDef gnBank_Tlr_Inf[CST_BANK_TLR_NUM];

char gsSwtCustLogFile[LOG_NAME_LEN_MAX]="SwtCust.log";

int PCSPacketWrapper(T_IpcIntTxnDef *ptIpcIntTxn);
#if 0
/*****************************************************************************/
/* FUNC:    double DecRound(double value,int dot)                             */
/* INPUT:  value: Ҫ����ת����˫���ȸ�������                                 */
/*         dot    : ��������Ҫ������λ��                                        */
/* OUTPUT: NULL                                                              */
/* RETURN: �ɹ���ת���������                                                */
/* DESC     : ��������ת������                                                  */
/*****************************************************************************/

double DecRound(double value,int dot)
{
	char ss[40],ss1[40];
	double aa;

	sprintf(ss1,"%s%dlf","%.",dot);	
	if(value>=0)aa=value+0.00000001;//���C���Ե�������������	
	else aa=value-0.00000001;
	sprintf(ss,ss1,aa);	
	aa=atof(ss);	
	return aa;
} 
#endif
/*****************************************************************************/
/* FUNC:    int SwtCustHandleTransaction (T_IpcIntTxnDef *ptIpcIntTxn,        */
/*                                        int nIndex)                         */
/* INPUT:  ptIpcIntTxn: ��������ϵͳ����Ϣ                                    */
/*         nIndex: �ý�����gatTxnInf�е��±�                                 */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: ��Switch���յ��Ǳ�׼�Ľ���, �����øú���������Ϣ                    */
/*****************************************************************************/
int SwtCustHandleTransaction (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex)
{
	char  sFuncName[] = "SwtCustHandleTransaction";

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	return 0;
}


/*****************************************************************************/
/* FUNC:    int SwtCustCheckTxn (T_IpcIntTxnDef *ptIpcIntTxn,                 */
/*                              char *sRespCode)                             */
/* INPUT:  ptIpcIntTxn: ������Ϣ                                             */
/* OUTPUT: sRespCode: ����鲻ͨ��ʱ,  ���;ܾ�Ӧ�����е�Ӧ����            */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch��������, ���������øú���������ɿͻ����ļ��          */
/*****************************************************************************/
int SwtCustCheckTxn (T_IpcIntTxnDef *ptIpcIntTxn, char *sRespCode)
{
	char	sFuncName[] = "SwtCustCheckTxn";
	int	 i, nReturnCode;
	int	 nIsSpecialTxn=0;
	int	 nLen;
	char	sTxnNum[4+1];
	char	sDate[4];
	char	OldNew[2];
	char	sTmp [28+1];
	char	sTmpLen [2+1];	
	double  sAmt;
	Tbl_society_insure_info_Def tSocietyInsureInfo;

	HtLog(  gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	HtLog(  gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Txn is %4.4s.", ptIpcIntTxn->sTxnNum);
	HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, ptIpcIntTxn->sMisc, 128);
		memset(sTmp, 0, sizeof(sTmp));
		memset(sTmpLen, 0, sizeof(sTmpLen));

	memset(sTxnNum , 0 , sizeof(sTxnNum));
	memcpy(sTxnNum, ptIpcIntTxn->sTxnNum, 4 );

	if (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
	{
		HtLog(  gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMsgDestId [%4.4s]", ptIpcIntTxn->sMsgDestId);
		/* ÷���籣�̻����� */
		if(memcmp(ptIpcIntTxn->sMsgDestId, "1811", 4) == 0)
		{
		    memset( &tSocietyInsureInfo, 0, sizeof(tSocietyInsureInfo) );
		    memcpy(tSocietyInsureInfo.sii_mcht_no, ptIpcIntTxn->sCardAccptrId, F042_LEN);
		    nReturnCode = DbsSocietyInsureInfo(DBS_SELECT, &tSocietyInsureInfo);
		    if(!nReturnCode)
		    {
		        if(tSocietyInsureInfo.sii_use_flag[0] != '1')
		        {
		            HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"mcht_no err,[%15.15s]. use_flag[%1.1s], not support txn[%4.4s], reject it.",
                                ptIpcIntTxn->sCardAccptrId, tSocietyInsureInfo.sii_use_flag, ptIpcIntTxn->sTxnNum);
                    memcpy(sRespCode, F039_NOT_SUPPORT, F039_LEN);
                    return 0;
		        }
		    }
		    else
		    {
		        HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"find mcht_no err,[%15.15s] not support txn[%4.4s], reject it.",
                            ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sTxnNum);
                memcpy(sRespCode, F039_NOT_SUPPORT, F039_LEN);
                return 0;
		    }
		}
	}

	memcpy(sRespCode, F039_SUCCESS, F039_LEN);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustBeforeTblTxnOpr (T_IpcIntTxnDef *ptIpcIntTxn,          */
/*                                     Tbl_txn_Def *ptTxn,                    */
/*                                     Tbl_txn_Def *ptOrigTxn)                */
/* INPUT:  ptIpcIntTxn: ��Ϣ                                                 */
/*         ptTxn: ��tbl_txn��¼��Ӧ                                          */
/* OUTPUT: ptTxn                                                             */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Խ��յ�����Ϣ, �ڲ����������ݿ�ǰ���øú���,                */
/*        �ɸ���ptTxn��ĳЩ��������ݱ��浽���ݿ���                            */
/*        ע: ptIpcIntTxn�����ݲ��ɸ���                                        */
/*****************************************************************************/
int SwtCustBeforeTblTxnOpr (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn, Tbl_txn_Def *ptOrigTxn)
{
	char  sFuncName[] = "SwtCustBeforeTblTxnOpr";
	char	sCurrentTime[15];
	int	  nReturnCode, i;
	char  sTransAmt[12 + 1],sTxnFee[9];
	char  sAmt[15+1];
	char  sAmtLen[3+1];  
	char  sTemp[100];
	char  sTmpFee[8+1];
	char  sTmpFee1[10+1];
	char  sTmpFee2[10+1];
	char  sNowTime[14+1];
	char  sSysTraceAuditNum[12+1];

	char	sTmpAmt[15+1];
	char	sTmpAmt1[12+1];
	char	sTmpAmt2[12+1];
	char	sTmpMcht[15+1];

	char	sTmpLen[2+1];
	int	num;

	Tbl_sys_stat_Def tSysStat;
	char sTmp[2];
	
	char sF055Val[1000];
	char sF055Len[F055_LEN_LEN+1];
	char sF104Len[2+1] = {0};
	
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "%s begin.", sFuncName);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "sTxnNum[%4.4s].", ptIpcIntTxn->sTxnNum);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "sMsgDestId[%4.4s].", ptIpcIntTxn->sMsgDestId);
			
	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_TDB_REQ:
		    memset(sCurrentTime, 0, sizeof(sCurrentTime));
            /*CommonGetCurrentTime(sCurrentTime);*/
            memcpy(sCurrentTime, gsTimeCurTs, 14);
            
	         if(!memcmp(ptIpcIntTxn->sDateSettlmt, "0101", 4) &&
		    !memcmp(sCurrentTime + 4, "1231", 4))
		    {
		    	memset(sCurrentTime + 4, 0, sizeof(sCurrentTime) - 4);
		    	sprintf(sCurrentTime, "%04d", atoi(sCurrentTime) + 1);
		    	memcpy(ptIpcIntTxn->sMiscFlag+14+4+4, sCurrentTime, 4);
		    }
		    else if(!memcmp(ptIpcIntTxn->sDateSettlmt, "1231", 4) &&
		    		 !memcmp(sCurrentTime + 4, "0101", 4))
		    {
		    	 memset(sCurrentTime + 4, 0, sizeof(sCurrentTime) - 4);
		    	 sprintf(sCurrentTime, "%04d", atoi(sCurrentTime) - 1);
		    	 memcpy(ptIpcIntTxn->sMiscFlag+14+4+4, sCurrentTime, 4);
		    }
		    else
		    	memcpy(ptIpcIntTxn->sMiscFlag+14+4+4, sCurrentTime, 4);
		    memcpy(ptIpcIntTxn->sMiscFlag+14+4+4+4, ptIpcIntTxn->sDateSettlmt, 4);
		    memcpy (ptTxn->misc_flag+14+4+4, ptIpcIntTxn->sMiscFlag+14+4+4, 8);
		    memcpy (ptTxn->host_date, ptIpcIntTxn->sMiscFlag+14+4+4, 8);
            
			break;
		case TXN_NUM_TDB_RSP:
			break;
		case TXN_NUM_BDB_REQ:
		    /* IC�����ף����PAN���к�, ATC, ARPC */
		    memcpy (sF104Len, ptIpcIntTxn->sTransDescrpt, 2);
		    HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ic data len [%s]", sF104Len);
		    if(atoi(sF104Len) > 0)
		    {
		        memcpy (ptTxn->trans_descrpt, ptIpcIntTxn->sTransDescrpt, atoi(sF104Len)+2);
		    }
		    
		    /* F015 ʹ��ϵͳ���� (����ͳһ���롢��ֵ��) */
			ptIpcIntTxn->cF015Ind = FLAG_YES_C;
			
			/*memset (&tSysStat, 0, sizeof (tSysStat));
			if (!getenv(CS_SC_CODE))
			{
				HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"env CS_SC_CODE not found.");
				memcpy (ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
				return -1;
			}
			memcpy (tSysStat.record_id, (char *)getenv(CS_SC_CODE), INST_ID_LEN);
			nReturnCode = DbsSYSSTAT (DBS_SELECT, &tSysStat );
	        if( nReturnCode != 0 )
	        {
	        	HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	        			"DbsSYSSTAT select error, %d.", nReturnCode);
	        	memcpy (ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
	        	return -1;
	        }
			
			memcpy (ptIpcIntTxn->sDateSettlmt, tSysStat.cups_stlm_date, F015_LEN);*/
			
			/* �����������Կ�������������Ϊ׼��������ȡ����������ʱ�䣩 
			memcpy (ptTxn->date_settlmt, tSysStat.cups_stlm_date, F015_LEN);*/
			
			memset(sCurrentTime, 0, sizeof(sCurrentTime));
	        /*CommonGetCurrentTime(sCurrentTime);*/
	        memcpy(sCurrentTime, gsTimeCurTs, 14);
	        
			memcpy (ptIpcIntTxn->sDateSettlmt, sCurrentTime+4, F015_LEN);
			memcpy (ptTxn->date_settlmt, sCurrentTime+4, F015_LEN);
			
			memcpy(ptIpcIntTxn->sMiscFlag+14+4+4, sCurrentTime, 8);
			memcpy (ptTxn->misc_flag+14+4+4, sCurrentTime, 8);
			
			break;
		case TXN_NUM_BDB_RSP:
		    /* F015 
		    if(ptIpcIntTxn->sDateSettlmt[0] != ' ' && ptIpcIntTxn->sDateSettlmt[0] != 0x00)
		        memcpy(ptTxn->date_settlmt, ptIpcIntTxn->sDateSettlmt, F015_LEN);*/
		    
			break;
		case TXN_NUM_CBDB_REQ:
		    /* use in revsal/cancel/cancelrevsal */
		    if(!memcmp(ptIpcIntTxn->sTxnNum,"1017",4))/*Ԥ��Ȩ����*/
	        	memcpy(&ptTxn->req_buf[0],"0100030000",10);
	        else if(!memcmp(ptIpcIntTxn->sTxnNum,"2017",4))/*Ԥ��Ȩ��ԭ*/
	        	memcpy(&ptTxn->req_buf[0],"0400030000",10);
	        else if(!memcmp(ptIpcIntTxn->sTxnNum,"3017",4))/*Ԥ��Ȩ����*/
	        	memcpy(&ptTxn->req_buf[0],"0100230000",10);
	        else if(!memcmp(ptIpcIntTxn->sTxnNum,"4017",4))/*Ԥ��Ȩ������ԭ*/
	        	memcpy(&ptTxn->req_buf[0],"0400230000",10);
	        else if(!memcmp(ptIpcIntTxn->sTxnNum,"1107",4) ||
	                !memcmp(ptIpcIntTxn->sTxnNum,"1117",4))/*����(����)��������*/
	        	memcpy(&ptTxn->req_buf[0],"0200000000",10);
	        else if(!memcmp(ptIpcIntTxn->sTxnNum,"2107",4) ||
	                !memcmp(ptIpcIntTxn->sTxnNum,"2117",4))/*����(����)��ԭ*/
	        	memcpy(&ptTxn->req_buf[0],"0400000000",10);
	        else if(!memcmp(ptIpcIntTxn->sTxnNum,"3107",4) ||
	                !memcmp(ptIpcIntTxn->sTxnNum,"3117",4))/*����(����)����*/
	        	memcpy(&ptTxn->req_buf[0],"0220000000",10);
	        else if(!memcmp(ptIpcIntTxn->sTxnNum,"4107",4) ||
	                !memcmp(ptIpcIntTxn->sTxnNum,"4117",4))/*����(����)������ԭ*/
	        	memcpy(&ptTxn->req_buf[0],"0400020000",10);
	        else if(!memcmp(ptIpcIntTxn->sTxnNum,"1207",4))/*��ѯ��������*/
	        	memcpy(&ptTxn->req_buf[0],"0900310000",10);
	
		    /* F015 ʹ��ϵͳ��ǰ���� (���ÿ�) */
			ptIpcIntTxn->cF015Ind = FLAG_YES_C;
			
			memset(sCurrentTime, 0, sizeof(sCurrentTime));
	        /*CommonGetCurrentTime(sCurrentTime);*/
	        memcpy(sCurrentTime, gsTimeCurTs, 14);
			
			memcpy (ptIpcIntTxn->sDateSettlmt, sCurrentTime+4, F015_LEN);
			memcpy (ptTxn->date_settlmt, sCurrentTime+4, F015_LEN);
			
			memcpy(ptIpcIntTxn->sMiscFlag+14+4+4, sCurrentTime, 8);
			memcpy (ptTxn->misc_flag+14+4+4, sCurrentTime, 8);
			
			/* F037 �Զ�������ʹ���µ�ֵ */
			if(memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) == 0)
			{
			    memcpy (ptTxn->retrivl_ref, ptIpcIntTxn->sRetrivlRefNum, F037_LEN);
			}
			break;
		case TXN_NUM_CBDB_RSP:
			memset(&ptTxn->rsp_buf[0],' ',F121_VAL_LEN+F123_VAL_LEN);
			memcpy(&ptTxn->rsp_buf[0],ptIpcIntTxn->sNationalSwResved,strlen(ptIpcIntTxn->sNationalSwResved));
			memcpy(&ptTxn->rsp_buf[F121_VAL_LEN],ptIpcIntTxn->sIssrInstResvd,F123_VAL_LEN);
			/*if (!memcmp(ptIpcIntTxn->sTxnNum,"1208",4))
			{
				if(ptIpcIntTxn->sTrack3Data[0] != ' ')
				{
					memcpy( &ptTxn->addtnl_amt[0],  "30", 2 );
					if(ptIpcIntTxn->sTrack3Data[0] == '+')
						memcpy( &ptTxn->addtnl_amt[2],  "D", 1 );
					else
						memcpy( &ptTxn->addtnl_amt[2],  "C", 1 );
					memcpy( &ptTxn->addtnl_amt[3],  &ptIpcIntTxn->sTrack3Data[2], 12 );
					memset(sAmtLen, 0x00, sizeof(sAmtLen));
					sprintf(sAmtLen, "%03d", strlen(ptTxn->addtnl_amt));
					memcpy( ptTxn->addtnl_amt_len, sAmtLen, F054_LEN_LEN );
					HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "ptTxn->addtnl_amt[%s].", ptTxn->addtnl_amt);
				}
			}*/
			memcpy(ptTxn->addtnl_amt_len, ptIpcIntTxn->sAddtnlAmtLen, 3 );
			memcpy(ptTxn->addtnl_amt, ptIpcIntTxn->sAddtnlAmt, 40 );
			HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "ptTxn->addtnl_amt[%s].", ptTxn->addtnl_amt);
			
			/* ����ҵ�� */
			/* F025 */
			if(memcmp(ptTxn->pos_cond_code, "64", F025_LEN) == 0 &&
			    memcmp(ptIpcIntTxn->sRespCode, "00", F039_LEN) == 0)
			{
			    ptIpcIntTxn->cF048Ind = 'Y';
			    memset(sTemp, 0, sizeof(sTemp));
			    memcpy(sTemp, ptIpcIntTxn->sAddtnlDataPrivate, 40);
			    memset(ptIpcIntTxn->sAddtnlDataPrivate, ' ', 40);
			    memcpy(ptIpcIntTxn->sAddtnlDataPrivateLen, "038", F048_LEN_LEN);
			    memcpy(ptIpcIntTxn->sAddtnlDataPrivate, sTemp+2, 38);
			    
			    /* save rsp data in database */
			    memcpy(ptTxn->addtnl_data_len, ptIpcIntTxn->sAddtnlDataPrivateLen, F048_LEN_LEN);
			    memcpy(ptTxn->addtnl_data, ptIpcIntTxn->sAddtnlDataPrivate, 38);
			}
			
			break;
		case TXN_NUM_BDT_REQ:
#if 0
			if (memcmp(ptIpcIntTxn->sTxnNum,"5151",4)==0||memcmp(ptIpcIntTxn->sTxnNum,"5171",4)==0)
			{
				memset (&tSysStat, 0, sizeof (tSysStat));
				if (!getenv(CS_SC_CODE))
				{
					HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							"env CS_SC_CODE not found.");
					memcpy (ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
					return -1;
				}
	
				memcpy (tSysStat.record_id, (char *)getenv(CS_SC_CODE), INST_ID_LEN);
				nReturnCode = DbsSYSSTAT (DBS_SELECT, &tSysStat );
				if( nReturnCode != 0 )
				{
					HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							"DbsSYSSTAT select error, %d.", nReturnCode);
					memcpy (ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
					return -1;
				}
				
				memcpy( ptIpcIntTxn->sDateSettlmt, tSysStat.cups_stlm_date, 4);
				memcpy( ptTxn->date_settlmt, ptIpcIntTxn->sDateSettlmt, 4);
				
				 /* year */
				/*CommonGetCurrentTime(sCurrentTime);*/
				memcpy(sCurrentTime, gsTimeCurTs, 14);
				if (!memcmp(tSysStat.cups_stlm_date, "0101", 4) &&
					!memcmp(sCurrentTime + 4, "1231", 4))
				{
					memset(sCurrentTime + 4, 0, sizeof(sCurrentTime) - 4);
					sprintf(sCurrentTime, "%04d", atoi(sCurrentTime) + 1);
					memcpy(ptIpcIntTxn->sMisc+20, sCurrentTime, 4);
				}
				else if (!memcmp(ptIpcIntTxn->sDateSettlmt, "1231", 4) &&
						 !memcmp(sCurrentTime + 4, "0101", 4))
				{
					 memset(sCurrentTime + 4, 0, sizeof(sCurrentTime) - 4);
					 sprintf(sCurrentTime, "%04d", atoi(sCurrentTime) - 1);
					 memcpy(ptIpcIntTxn->sMisc+20, sCurrentTime, 4);
				}
				else
					memcpy(ptIpcIntTxn->sMisc+20, sCurrentTime, 4);
			}

			HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "year [%4.4s]", ptIpcIntTxn->sMisc+20);
#endif

			
			/*���ı���ͷ*/		
		memcpy (ptIpcIntTxn->sHeaderBuf+6, CUP_INST_ID, 8);
		memcpy (ptIpcIntTxn->sHeaderBuf+6+F032_VAL_LEN,ptIpcIntTxn->sFwdInstIdCode, 8);
			
			break;
			
	  case TXN_NUM_BDT_RSP:
            /* From ���� */
            if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0)
            {
                /* F015 */
                if(ptIpcIntTxn->cF015Ind == FLAG_YES_C)
                    memcpy(ptTxn->date_settlmt, ptIpcIntTxn->sDateSettlmt, F015_LEN);
            }
            
			 /* ϵͳ�� */
			/*CommonGetCurrentTime(sCurrentTime);*/
			memcpy(sCurrentTime, gsTimeCurTs, 14);
			if (!memcmp(ptIpcIntTxn->sDateSettlmt, "0101", 4) &&
					!memcmp(sCurrentTime + 4, "1231", 4))
			{
				memset(sCurrentTime + 4, 0, sizeof(sCurrentTime) - 4);
				sprintf(sCurrentTime, "%04d", atoi(sCurrentTime) + 1);
				memcpy(&ptIpcIntTxn->sMisc[20], sCurrentTime, 4);
			}
			else if (!memcmp(ptIpcIntTxn->sDateSettlmt, "1231", 4) &&
					!memcmp(sCurrentTime + 4, "0101", 4))
			{
				memset(sCurrentTime + 4, 0, sizeof(sCurrentTime) - 4);
				sprintf(sCurrentTime, "%04d", atoi(sCurrentTime) - 1);
				memcpy(&ptIpcIntTxn->sMisc[20], sCurrentTime, 4);
			}
			else
				memcpy(&ptIpcIntTxn->sMisc[20], sCurrentTime, 4);
			
			if( memcmp(ptIpcIntTxn->sMsgSrcId,"16",2) == 0 )
			{
					if ( ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_NORMAL &&
						memcmp(&ptIpcIntTxn->sTxnNum[1],"09",2))
					{
						memcpy(&ptIpcIntTxn->sTlrNum[0],sCurrentTime, 4);
						memcpy(&ptIpcIntTxn->sTlrNum[4],ptIpcIntTxn->sDateSettlmt,4);
						memcpy(ptTxn->tlr_num,ptIpcIntTxn->sTlrNum,8);
					}	
            }

			memcpy(	&ptTxn->misc_1[20],&ptIpcIntTxn->sMisc[20],4);
		
			break;
	}
	
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustAfterTblTxnOpr (T_IpcIntTxnDef *ptSendIpcIntTxn,      */
/*                                     Tbl_txn_Def *ptTxn,                   */
/*                                     Tbl_txn_Def *ptOrigTxn)               */
/* INPUT:  ptSendIpcIntTxn: ��Ҫ���͵���Ϣ                                   */
/*         ptTxn: ��tbl_txn��¼��Ӧ                                          */
/* OUTPUT: ptSendIpcIntTxn                                                   */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Խ��յ�����Ϣ, �ڲ����������ݿ����øú���,               */
/*        �ɸ���ptSendIpcIntTxn�����ݿ��¼��ĳЩ��������ݷŵ�������Ϣ��,   */
/*        ptSendIpcIntTxn��ͨ��PackSend����ʽת�������ⷢ��                  */
/*        ע: ptTxn�����ݲ��ɸ���                                            */
/*****************************************************************************/
int SwtCustAfterTblTxnOpr (T_IpcIntTxnDef *ptSendIpcIntTxn, Tbl_txn_Def *ptTxn, Tbl_txn_Def *ptOrigTxn)
{
	char  sFuncName[] = "SwtCustAfterTblTxnOpr";
	char  sAmt[13];
	char  sTemp[100];

	int	nReturnCode, nMaxRspCodeMapN = 0, i;
	
	
    char  sTmpFee[10+1];
	char  sTmpMcht[15+1];
	double  dAmt = 0.00;
	int num;
    TBL_brh_info_Def tbl_brh_inf;
	char	sTxnNum[4+1];
	
	char	sTmpLen[3+1];
	
	char    sF055Len[F055_LEN_LEN+1];
	char    sF055Val[F055_LEN+1];
	Tbl_sys_stat_Def tSysStat;
	
  memset(&tbl_brh_inf, 0, sizeof(TBL_brh_info_Def) );


	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TxnNum: %4.4s", ptSendIpcIntTxn->sTxnNum );

	memset(sTxnNum , 0 , sizeof(sTxnNum));
	memcpy(sTxnNum, ptSendIpcIntTxn->sTxnNum, 4 );
	

	if( memcmp(ptSendIpcIntTxn->sTxnNum,"6325",4) == 0)
	{
		memcpy(ptSendIpcIntTxn->sMsqType,"0000000000000000",16);
		return 0;
	}

	switch (ptSendIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDB_REQ:
			HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMsgDestId: %4.4s", ptSendIpcIntTxn->sMsgDestId );
			
			/* To ����ͳһ���� */
			if ( !memcmp (ptSendIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN) )
			{
		        /*HeaderBuf*/
	            memset(&ptSendIpcIntTxn->sHeaderBuf[0], 0x2E,1);//ͷ1��ͷ����
	            memset(&ptSendIpcIntTxn->sHeaderBuf[1], 0x01,1);//ͷ2���汾��ʶ
	            memset(&ptSendIpcIntTxn->sHeaderBuf[2],'0',4);//ͷ3���������ĳ���
	            memcpy(&ptSendIpcIntTxn->sHeaderBuf[6],BANK_INST_ID,8); //ͷ4��Ŀ��ID
	            memcpy(&ptSendIpcIntTxn->sHeaderBuf[14],"   ",3);
	            memcpy(&ptSendIpcIntTxn->sHeaderBuf[17],CUP_INST_ID,8); //ͷ5��ԴID
	            memcpy(&ptSendIpcIntTxn->sHeaderBuf[25],"   ",3);
	            memset(&ptSendIpcIntTxn->sHeaderBuf[28],0x00,4);//ͷ6������ʹ�ã�24bit����ͷ7��1bit��
	            memset(&ptSendIpcIntTxn->sHeaderBuf[32],'0',8);//ͷ8��������Ϣ
	            memset(&ptSendIpcIntTxn->sHeaderBuf[40],0x00,1);//ͷ9���û���Ϣ
	            memset(&ptSendIpcIntTxn->sHeaderBuf[41],'0',5);//ͷ10���ܾ���
	            /*HeaderBuf over*/
	
				/* F033 ʹ��POSP���͵��ڲ������� */
				memcpy(ptSendIpcIntTxn->sFwdInstIdCodeLen,"08",2);
				memcpy(&ptSendIpcIntTxn->sFwdInstIdCode[0], "CG", 2);
				memcpy(&ptSendIpcIntTxn->sFwdInstIdCode[2], &ptSendIpcIntTxn->sAcqInstResvd[30], 6);
				HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "sFwdInstIdCodeLen [%2.2s].", ptSendIpcIntTxn->sFwdInstIdCodeLen);
				HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "sFwdInstIdCode [%11.11s].", ptSendIpcIntTxn->sFwdInstIdCode);
	            
	            /* F100 */
				if (ptSendIpcIntTxn->cF100Ind != FLAG_YES_C)
				{
					ptSendIpcIntTxn->cF100Ind = FLAG_YES_C;
					memcpy (ptSendIpcIntTxn->sRcvgInstIdCodeLen, "08", F100_LEN_LEN);
					memcpy (ptSendIpcIntTxn->sRcvgInstIdCode, "00000000", F100_VAL_LEN);
				}
				
				switch (ptSendIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
				{
					case TXN_NUM_REVSAL:
					case TXN_NUM_CANCEL:
					case TXN_NUM_CANCEL_REVSAL:
					    /* F037 from orig txn F037  */
					    memcpy (ptSendIpcIntTxn->sRetrivlRefNum, ptOrigTxn->retrivl_ref, F037_LEN);
					    
						/* save original txn info in F090 */
						memset (ptSendIpcIntTxn->sOrigDataElemts, '0', F090_LEN);
						i = 0;
						memcpy (ptSendIpcIntTxn->sOrigDataElemts+i, ptOrigTxn->msg_type, F000_MSG_TYPE_LEN);
						i += F000_MSG_TYPE_LEN;
						memcpy (ptSendIpcIntTxn->sOrigDataElemts+i, ptOrigTxn->sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
						i += F011_LEN;
						memcpy (ptSendIpcIntTxn->sOrigDataElemts+i, ptOrigTxn->trans_date_time, F007_LEN);
						i += F007_LEN;
						memcpy (ptSendIpcIntTxn->sOrigDataElemts+i+F032_VAL_LEN-INST_ID_LEN, ptOrigTxn->acq_inst_id_code, INST_ID_LEN);
						i += F032_VAL_LEN;
						memcpy (ptSendIpcIntTxn->sOrigDataElemts+i+F033_VAL_LEN-INST_ID_LEN, ptSendIpcIntTxn->sFwdInstIdCode, INST_ID_LEN);
						HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "sOrigDataElemts [%42.42s].", ptSendIpcIntTxn->sOrigDataElemts);
						break;
				}
			}
			
			/* To ��ֵ�� */
			if (!memcmp (ptSendIpcIntTxn->sMsgDestId, "1701", SRV_ID_LEN) || !memcmp (ptSendIpcIntTxn->sMsgDestId, "1710", SRV_ID_LEN) )
			{
			    /*  �ͻ��� */
				nReturnCode = SetBDBSavingCard (ptSendIpcIntTxn,ptTxn,ptOrigTxn);
				if(nReturnCode)
				{
					HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "SetBDBSavingCard %d err.", nReturnCode);
					return -1;
				}
				
				/* F055 */
				if(ptSendIpcIntTxn->cICDataInd == 'Y')
		        {
		            memset( sF055Len, 0, sizeof(sF055Len) );
		            memset( sF055Val, 0, sizeof(sF055Val) );
		            memcpy(sF055Len, ptSendIpcIntTxn->sICDataLen, F055_LEN_LEN);
		            memcpy(sF055Val, ptSendIpcIntTxn->sICData, atoi(sF055Len));
		            
		            memset(ptSendIpcIntTxn->sICData, ' ', F055_LEN);
		            memcpy(ptSendIpcIntTxn->sICData, sF055Len, F055_LEN_LEN);
		            memcpy(ptSendIpcIntTxn->sICData+F055_LEN_LEN, sF055Val, atoi(sF055Len));
		        }
			}
			
			/* To �ܿ� */
			if( !memcmp(ptSendIpcIntTxn->sMsgDestId, SRV_ID_COMM_ZK, 4) )
		    {
		       nReturnCode = SetCups (ptSendIpcIntTxn,ptTxn,ptOrigTxn);
			    if(nReturnCode)
			    {
				    HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "SetCups %d err.", nReturnCode);
				    return -1;
			    }
		    }
		    
		    /* To ÷���籣 */
			if( !memcmp(ptSendIpcIntTxn->sMsgDestId, SRV_ID_COMM_MZ, 4) )
			{
			    /* F100 */
				if (ptSendIpcIntTxn->cF100Ind != FLAG_YES_C)
				{
					ptSendIpcIntTxn->cF100Ind = FLAG_YES_C;
					memcpy (ptSendIpcIntTxn->sRcvgInstIdCodeLen, "08", F100_LEN_LEN);
					memcpy (ptSendIpcIntTxn->sRcvgInstIdCode, "00000000", F100_VAL_LEN);
				}
			}
			
			break;
		case TXN_NUM_CBDB_REQ:
			nReturnCode = SetCreditCard (ptSendIpcIntTxn,ptTxn,ptOrigTxn);
			if(nReturnCode)
			{
				HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "SetCreditCard %d err.", nReturnCode);
				return -1;
			}
			
			/* ����ҵ�� */
			/* F025 */
			if(memcmp(ptSendIpcIntTxn->sPosCondCode, "64", F025_LEN) == 0)
			{
				if(ptSendIpcIntTxn->sTxnNum[0]=='2' ||
				   ptSendIpcIntTxn->sTxnNum[0]=='3' ||
				   ptSendIpcIntTxn->sTxnNum[0]=='4')
				{
			      memset(sTemp, ' ', sizeof(sTemp));
			      memcpy(sTemp, ptSendIpcIntTxn->sAddtnlDataPrivate, 38);
			      memcpy(ptSendIpcIntTxn->sAddtnlDataPrivate+2, sTemp, 38);
			      memcpy(ptSendIpcIntTxn->sAddtnlDataPrivate, ptSendIpcIntTxn->sPosCondCode, F025_LEN);
			    }
			    else
			    {
			      memset(sTemp, ' ', sizeof(sTemp));
			      memcpy(sTemp, ptSendIpcIntTxn->sAddtnlDataPrivate, 18);
			      memcpy(ptSendIpcIntTxn->sAddtnlDataPrivate+2, sTemp, 18);
			      memcpy(ptSendIpcIntTxn->sAddtnlDataPrivate, ptSendIpcIntTxn->sPosCondCode, F025_LEN);
			    }
			}
			
			break;
		case TXN_NUM_TDB_REQ:
		    if( !memcmp(ptSendIpcIntTxn->sMsgDestId,"1701",4) )
		    {
		        if(ptSendIpcIntTxn->cICDataInd == 'Y')
		        {
		            memset( sF055Len, 0, sizeof(sF055Len) );
		            memset( sF055Val, 0, sizeof(sF055Val) );
		            memcpy(sF055Len, ptSendIpcIntTxn->sICDataLen, F055_LEN_LEN);
		            memcpy(sF055Val, ptSendIpcIntTxn->sICData, atoi(sF055Len));
		            
		            memset( ptSendIpcIntTxn->sICData, ' ', sizeof(F055_LEN) );
		            memcpy(ptSendIpcIntTxn->sICData, sF055Len, F055_LEN_LEN);
		            memcpy(ptSendIpcIntTxn->sICData+F055_LEN_LEN, sF055Val, atoi(sF055Len));
		        }
		    }
		    else if( !memcmp(ptSendIpcIntTxn->sMsgDestId, SRV_ID_COMM_ZK, 4) )
		    {
		       nReturnCode = SetCups (ptSendIpcIntTxn,ptTxn,ptOrigTxn);
			    if(nReturnCode)
			    {
				    HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "SetCups %d err.", nReturnCode);
				    return -1;
			    }
		    }
		    else if( !memcmp(ptSendIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUPS, 4) )
		    {
			    if(memcmp(ptSendIpcIntTxn->sCardAccptrNameLoc, "                                        ", F043_LEN) == 0)
			    {
				    memcpy(ptSendIpcIntTxn->sCardAccptrNameLoc, "NULL", 4);
			    }
		    }
			break;
		case TXN_NUM_BDT_REQ:
			
			/* F070 �ű��������֪ͨ */
            if(memcmp(ptSendIpcIntTxn->sTxnNum,"5181",4) == 0)
            {
                memcpy(ptSendIpcIntTxn->sNetwkMgmtInfoCode,"951",3);
            }
			
			memcpy(ptSendIpcIntTxn->sKeyRsp,ptTxn->key_rsp, sizeof(ptSendIpcIntTxn->sKeyRsp));
			break;
	case TXN_NUM_BDT_RSP:
			/* ����������Ӧ��ȡԭ������ˮ�źͽ���ʱ�� */
			if(memcmp(ptSendIpcIntTxn->sMsgDestId, SRV_ID_COMM_P, 2) == 0) /* POSP */
			{
			  memcpy(ptSendIpcIntTxn->sSysTraceAuditNum,&ptSendIpcIntTxn->sMisc[F007_LEN],F011_LEN);
			  memcpy(ptSendIpcIntTxn->sTransmsnDateTime,&ptSendIpcIntTxn->sMisc[0],F007_LEN);
			}
			
			/* ���˾ܾ�������ǰ��F100=00000000 */
            if ( ptSendIpcIntTxn->sRcvgInstIdCode[0] == ' ' ||
				ptSendIpcIntTxn->sRcvgInstIdCode[0] == 0x00 )
		    {
		        ptSendIpcIntTxn->cF100Ind = 'Y';
		        memcpy(ptSendIpcIntTxn->sRcvgInstIdCodeLen, "08", F100_LEN_LEN);
		        memcpy(ptSendIpcIntTxn->sRcvgInstIdCode, "00000000", 8);
		    }
			
			break;
		case TXN_NUM_CBDB_RSP:		    		               		                
		case TXN_NUM_BDB_RSP:
			if(memcmp(ptSendIpcIntTxn->sMsgDestId, SRV_ID_COMM_P, 2) == 0) /*POSP*/
			{
			    
			    /* F003 */
			    if(memcmp(ptSendIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0)
			    {
			        memcpy(ptSendIpcIntTxn->sProcessingCode,&ptSendIpcIntTxn->sMisc[F007_LEN+F011_LEN], F003_LEN);
			    }
			    if(memcmp(ptSendIpcIntTxn->sMsgSrcId, SRV_ID_COMM_P, 2) == 0)
			    {
			        if(ptSendIpcIntTxn->sMisc[F007_LEN+F011_LEN] != 0x00 &&
			            ptSendIpcIntTxn->sMisc[F007_LEN+F011_LEN] != ' ')
			            memcpy(ptSendIpcIntTxn->sProcessingCode,&ptSendIpcIntTxn->sMisc[F007_LEN+F011_LEN], F003_LEN);
			    }
			
		/*	if (ptSendIpcIntTxn->cF015Ind != FLAG_YES_C)
				{
					ptSendIpcIntTxn->cF015Ind = FLAG_YES_C;
					memcpy (ptSendIpcIntTxn->sDateSettlmt, ptSendIpcIntTxn->sHostDate+4, F015_LEN);
				}*/
				if ( ptSendIpcIntTxn->cF100Ind != FLAG_YES_C )
				{
					ptSendIpcIntTxn->cF100Ind = FLAG_YES_C;
					memcpy( ptSendIpcIntTxn->sRcvgInstIdCodeLen,  "08", F100_LEN_LEN );
					memcpy( ptSendIpcIntTxn->sRcvgInstIdCode,  "00000000", F100_VAL_LEN );
				}
				memcpy(ptSendIpcIntTxn->sTransmsnDateTime,&ptSendIpcIntTxn->sMisc[0],F007_LEN);
				memcpy(ptSendIpcIntTxn->sSysTraceAuditNum,&ptSendIpcIntTxn->sMisc[F007_LEN],F011_LEN);
			}
			break;
		case TXN_NUM_TDB_RSP:
			{
				/*memcpy( ptSendIpcIntTxn->sMsgDestId, ptTxn->msg_src_id, SRV_ID_LEN );*/
				memcpy(ptSendIpcIntTxn->sTransmsnDateTime, ptSendIpcIntTxn->sMisc, F007_LEN);
                memcpy(ptSendIpcIntTxn->sSysTraceAuditNum, ptSendIpcIntTxn->sMisc+F007_LEN, F011_LEN);

				break;
			}
	}

	HtLog( gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}
/*****************************************************************************/
/* FUNC:    int SwtCustSetKeyRsp (T_IpcIntTxnDef *ptIpcIntTxn)                */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                        */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Ա�����,������������Ӧ����Ϣ,                              */
/*        �ڸ��Ƶ�Tbl_txn_Defǰ���øú���                                     */
/*        ������, �ú����������еĹؼ����¼��sKeyRsp��, ������Ӧ��ʱƥ������ */
/*        ��Ӧ��, �ú�����Ӧ���еĹؼ����¼��sKeyRsp��, ��ƥ������            */
/*****************************************************************************/
int SwtCustSetKeyRsp (T_IpcIntTxnDef *ptIpcIntTxn)
{
	char  sFuncName[] = "SwtCustSetKeyRsp";
	int	  i;
 
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_TDB_REQ:
		case TXN_NUM_TDB_RSP:
		case TXN_NUM_BDB_REQ:
		case TXN_NUM_BDB_RSP:
		case TXN_NUM_CBDB_REQ:
		case TXN_NUM_CBDB_RSP:
			i = 0;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
			i += F007_LEN;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
			i += F011_LEN;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sAcqInstIdCode, 8);
			i += 8;
			memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sProcessingCode, 6);
			break;
		default:
			break;
	}

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustSetKeyRevsal (T_IpcIntTxnDef *ptIpcIntTxn)             */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                        */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Ա�����,��������������Ϣ,                                    */
/*        �ڸ��Ƶ�Tbl_txn_Defǰ���øú���                                     */
/*        ����ͨ����, �ú����������еĹؼ����¼��sKeyRevsal��,                */
/*                ����������ʱƥ��ԭʼ����                                    */
/*        �Գ�������, �ú�����ԭʼ�������ݼ�¼��sKeyRevsal��, ��ƥ��ԭ����    */
/*****************************************************************************/
int SwtCustSetKeyRevsal (T_IpcIntTxnDef *ptIpcIntTxn)
{
	char  sFuncName[] = "SwtCustSetKeyRevsal";
	int	  i,j;
	char  sTemp[20];
	char saTDate[9];
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_TDB_REQ:
			switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
			{
				case TXN_NUM_NORMAL:
				case TXN_NUM_CANCEL:
					i = 0;
					if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0)
					{
						memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
						i += F011_LEN;
						memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
						i += F007_LEN;
						memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sAcqInstIdCode, INST_ID_LEN);
						i += INST_ID_LEN;
						memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sFwdInstIdCode, INST_ID_LEN);
					}
					else
					{
						memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sMisc+F007_LEN, F011_LEN);
						i += F011_LEN;
						memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sMisc, F007_LEN);
						i += F007_LEN;
						memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sAcqInstIdCode, INST_ID_LEN);
						i += INST_ID_LEN;
						memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sFwdInstIdCode, INST_ID_LEN);
					}
					break;
				case TXN_NUM_REVSAL:
				case TXN_NUM_CANCEL_REVSAL:
					i = 0;
					j = 4;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sOrigDataElemts+j, F011_LEN);
					i += F011_LEN;
					j += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sOrigDataElemts+j, F007_LEN);
					i += F007_LEN;
					j = j + F007_LEN + F032_VAL_LEN - INST_ID_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sOrigDataElemts+j, INST_ID_LEN);
					i += INST_ID_LEN;
					j = j + F032_VAL_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sOrigDataElemts+j, INST_ID_LEN);
					break;
				default:
					break;
			}
			break;
		case TXN_NUM_BDB_REQ:
		case TXN_NUM_CBDB_REQ:
		case TXN_NUM_BDT_REQ:
			switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
			{
				case TXN_NUM_NORMAL:
				case TXN_NUM_CANCEL:
					i = 0;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sMsgType, F000_MSG_TYPE_LEN); /* msg type */
					i += F000_MSG_TYPE_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sMisc+F007_LEN , F011_LEN);
					i += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sMisc , F007_LEN);
					i += F007_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sCardAccptrTermnlId, F041_LEN);
					break;

				case TXN_NUM_REVSAL:
				case TXN_NUM_CANCEL_REVSAL:
                case TXN_NUM_NOTICE:
					i = 0;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sOrigDataElemts, F000_MSG_TYPE_LEN); /* msg type */
					i += F000_MSG_TYPE_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, &ptIpcIntTxn->sOrigDataElemts[F000_MSG_TYPE_LEN] , F011_LEN);
					i += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, &ptIpcIntTxn->sOrigDataElemts[F000_MSG_TYPE_LEN+F011_LEN] , F007_LEN);
					i += F007_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sCardAccptrTermnlId, F041_LEN);
					break;
			}
	}
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustSetKeyCancel (T_IpcIntTxnDef *ptIpcIntTxn)            */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                       */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Ա�����,��������������Ϣ,                                    */
/* �ڸ��Ƶ�Tbl_txn_Defǰ���øú���                                           */
/* ����ͨ����, �ú����������еĹؼ����¼��sKeyCancel��,                     */
/* ����������ʱƥ��ԭʼ����                                                  */
/* �Գ�������, �ú�����ԭʼ�������ݼ�¼��sKeyCancel��, ��ƥ��ԭ����          */
/*****************************************************************************/
int SwtCustSetKeyCancel (T_IpcIntTxnDef *ptIpcIntTxn)
{
	char  sFuncName[] = "SwtCustSetKeyCancel";
	int   i,j;

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_TDB_REQ:
			switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
			{
				case TXN_NUM_NORMAL:
					i = 0;
					if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0)
					{
						memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
						i += F011_LEN;
						memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
						i += F007_LEN;
						memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sAcqInstIdCode, INST_ID_LEN);
						i += INST_ID_LEN;
						memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sFwdInstIdCode, INST_ID_LEN);
					}
					else
					{
						memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sMisc+F007_LEN, F011_LEN);
						i += F011_LEN;
						memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sMisc, F007_LEN);
						i += F007_LEN;
						memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sAcqInstIdCode, INST_ID_LEN);
						i += INST_ID_LEN;
						memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sFwdInstIdCode, INST_ID_LEN);
					}
					break;
				case TXN_NUM_CANCEL:
				case TXN_NUM_NOTICE:
					i = 0;
					j = 4;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sOrigDataElemts+j, F011_LEN);
					i += F011_LEN;
					j += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sOrigDataElemts+j, F007_LEN);
					i += F007_LEN;
					j = j + F007_LEN + F032_VAL_LEN - INST_ID_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sOrigDataElemts+j, INST_ID_LEN);
					i += INST_ID_LEN;
					j = j + F033_VAL_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sOrigDataElemts+j, INST_ID_LEN);
					break;
				default:
					break;
			}
			break;	
		case TXN_NUM_BDB_REQ:
		case TXN_NUM_CBDB_REQ:
		case TXN_NUM_BDT_REQ:
			switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
			{
				case TXN_NUM_NORMAL:
					i = 0;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sMisc, F007_LEN);
					i += F007_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sMisc+F007_LEN, F011_LEN);
					i += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sCardAccptrTermnlId, F041_LEN);
					i += F041_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sCardAccptrId+7, F042_LEN-7);
					break;
	
				case TXN_NUM_NOTICE:
				case TXN_NUM_CANCEL:
					i = 0;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sOrigDataElemts+4+F011_LEN, F007_LEN);
					i += F007_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sOrigDataElemts+4, F011_LEN);
					i += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sCardAccptrTermnlId, F041_LEN);
					i += F041_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sCardAccptrId+7, F042_LEN-7);
					break;
			}
			break;
	}
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustVerifyMAC (T_IpcIntTxnDef *ptIpcIntTxn)                */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                        */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Խ��յ������������������Ϣ, ���øú�����֤MAC                */
/*****************************************************************************/
int SwtCustVerifyMAC (T_IpcIntTxnDef *ptIpcIntTxn )
{
	char  sFuncName[] = "SwtCustVerifyMAC";

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CustCopyMacElement (char *pcMacPos, char *sMacElement, int *pnMacElementLen)
{
	/*
		int	  i;
		int	  c;
		int	  nLen;

		nLen = 0;
		for (i = 0; i < *pnMacElementLen; i++)
		{
		c = *(sMacElement+i);
		if (isdigit (c) || isupper (c))
	 *(pcMacPos+nLen) = *(sMacElement+i);
	 else
	 {
	 if (islower (c))
	 *(pcMacPos+nLen) = (char)toupper (c);
	 else
	 break;
	 }
	 nLen++;
	 }

	 *pnMacElementLen = nLen;
	 */
	/* 050830 just copy data into mac block, do not make any change */
	memcpy (pcMacPos, sMacElement, *pnMacElementLen);
	return 0;
}

int CustGenMacBlock (char *sMacBlockLen, char *sMacBlock, T_IpcIntTxnDef *ptIpcIntTxn)
{
#define MAC_F090_LEN 20
	char	 sFuncName[] = "CustGenMacBlock";
	char	 *pcMacPos;
	char	 sTmpLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int		 nLen;

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	/* MAC element including:
		0, 2, 3, 4, 7, 11, 18, 25, 28, 32, 33, 38, 39, 41, 42, 90, 102, 103 */
	memset (sMacBlock, ' ', HSM_MAC_BLOCK_LEN_MAX);
	pcMacPos = sMacBlock;

	/* field 0, msg type */
	nLen = F000_MSG_TYPE_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sMsgType, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 2, panlen, pan */
	if (ptIpcIntTxn->cF002Ind == FLAG_YES_C)
	{
		nLen = F002_LEN_LEN;
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sPrimaryAcctNumLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = F002_VAL_LEN;
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sPrimaryAcctNum, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* field 3, processing code */
	nLen = F003_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sProcessingCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 4, transaction amount */
	nLen = F004_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAmtTrans, &nLen);
	if (nLen > 0)
		pcMacPos = pcMacPos + nLen + 1;

	/* field 7, transmision date tiem */
	nLen = F007_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sTransmsnDateTime, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 11, ssn */
	nLen = F011_LEN;
	if (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_RSP)
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sTermSSN, &nLen);
	else
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sSysTraceAuditNum, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 18, merchant type */
	nLen = F018_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sMchntType, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 25, pos condition code */
	nLen = F025_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sPosCondCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 28, transaction fee */
	if (ptIpcIntTxn->cF028Ind == FLAG_YES_C)
	{
		nLen = F028_LEN;
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAmtTransFee, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* field 32, acquiring inst id */
	nLen = F032_LEN_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAcqInstIdCodeLen, &nLen);
	pcMacPos = pcMacPos + nLen;
	nLen = F032_VAL_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAcqInstIdCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 33, forwarding inst id */
	nLen = F033_LEN_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sFwdInstIdCodeLen, &nLen);
	pcMacPos = pcMacPos + nLen;
	nLen = F033_VAL_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sFwdInstIdCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 38, auth id */
	if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
	{
		nLen = F038_LEN;
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAuthrIdResp, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* field 39, response code */
	nLen = F039_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sRespCode, &nLen);
	if (nLen > 0)
		pcMacPos = pcMacPos + nLen + 1;

	/* field 41, terminal id */
	nLen = F041_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sCardAccptrTermnlId, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 42, merchant id */
	nLen = F042_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sCardAccptrId, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 90, original data elements */
	nLen = MAC_F090_LEN;
	CustCopyMacElement (pcMacPos, ptIpcIntTxn->sOrigDataElemts, &nLen);
	if (nLen > 0)
		pcMacPos = pcMacPos + nLen + 1;

	/* field 102, account id 1 */
	if (ptIpcIntTxn->cF102Ind == FLAG_YES_C )
	{
		nLen = F102_LEN_LEN;
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAcctId1Len, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = F102_VAL_LEN;
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAcctId1, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* field 103, account id 2 */
	if (ptIpcIntTxn->cF103Ind == FLAG_YES_C )
	{
		nLen = F103_LEN_LEN;
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAcctId2Len, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = F103_VAL_LEN;
		CustCopyMacElement (pcMacPos, ptIpcIntTxn->sAcctId2, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* get rid of the last space */
	pcMacPos--;

	/* set MAC block len */
	sprintf (sTmpLen, "%03d", (int)(pcMacPos - sMacBlock));
	memcpy (sMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:   int SwtCustTransferPin (T_IpcIntTxnDef *ptIpcIntTxn)              */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                       */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Խ��յ������������������Ϣ,                                 */
/*       �ڵ��ú�����֤MAC����øú�����PINת��                              */
/*****************************************************************************/
int SwtCustTransferPin (T_IpcIntTxnDef  *ptIpcIntTxn)
{
	int			nReturnCode;
	HSMOprDef	tHsmOpr;
	char		sMsgSrcId[4+1],sMsgDestId[4+1];
	char		sSrcKeyIndex[5+1],sDestKeyIndex[5+1];
	
	memset(sMsgSrcId, 0 ,sizeof(sMsgSrcId));
	memcpy(sMsgSrcId, ptIpcIntTxn->sMsgSrcId, 4);
	memset(sMsgDestId, 0 ,sizeof(sMsgDestId));
	memcpy(sMsgDestId, ptIpcIntTxn->sMsgDestId, 4);
HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sMsgSrcId[%s] sMsgDestId[%s]", sMsgSrcId, sMsgDestId);
	memset(sSrcKeyIndex, 0x00, sizeof(sSrcKeyIndex));
	switch ( atoi(sMsgSrcId) )
	{
		case 1601:/*����*/
			sprintf(sSrcKeyIndex,"Y%04s","0001");
			break;
		case 1611:/*����ͳһ����*/
			sprintf(sSrcKeyIndex,"Y%04s","0002");
			break;
		case 1702:/*���ÿ�*/
			sprintf(sSrcKeyIndex,"Y%04s","0004");
			break;
		case 1801:/*POSP*/
		case 1802:/*POSP*/
			sprintf(sSrcKeyIndex,"Y%04s","0005");
			break;
		default:
			break;
	}
	
	memset(sDestKeyIndex, 0x00, sizeof(sDestKeyIndex));
	switch ( atoi(sMsgDestId) )
	{
		case 1601:/*����*/
			sprintf(sDestKeyIndex,"Y%04s","0001");
			break;
		case 1611:/*����ͳһ����*/
			sprintf(sDestKeyIndex,"Y%04s","0002");
			break;
		case 1702:/*���ÿ�*/
			sprintf(sDestKeyIndex,"Y%04s","0004");
			break;
		case 1801:/*POSP*/
		case 1802:/*POSP*/
			sprintf(sDestKeyIndex,"Y%04s","0005");
	    case 1811:/*÷���籣*/
			sprintf(sDestKeyIndex,"Y%04s","0008");
			break;
		case 1613:/*�ܿ�*/
			sprintf(sDestKeyIndex,"Y%04s","0007");
			break;
		default:
			break;
	}
	/*
	if (memcmp(ptIpcIntTxn->sMsgSrcId, "1601", SRV_ID_LEN) == 0)
		sprintf(sSrcKeyIndex,"Y%04s","0001");
	
	if (memcmp(ptIpcIntTxn->sMsgDestId, "1601", SRV_ID_LEN) == 0)
		sprintf(sDestKeyIndex,"Y%04s","0001");
*/
	if(ptIpcIntTxn->cF052Ind == FLAG_YES_C)
	{

		memset((char *)&tHsmOpr,0,sizeof(HSMOprDef));

		tHsmOpr.saOprType = HSM_TRANSPIN;
		memcpy(&tHsmOpr.saRout[0],sSrcKeyIndex,5);
		memcpy(&tHsmOpr.saRout[5],sDestKeyIndex,5);

		memcpy(tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
		memcpy(tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
		memcpy(tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
		memcpy(tHsmOpr.saEnc, ptIpcIntTxn->sPinData, 8);

		nReturnCode = nEncOpr (&tHsmOpr);
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
			return -1;
		}
		ptIpcIntTxn->cF052Ind = FLAG_YES_C;
		memcpy (ptIpcIntTxn->sPinData, tHsmOpr.saEnc, F052_LEN);
	}
	else
	{
		ptIpcIntTxn->sPosEntryModeCode[2] = F022_WITH_OUT_PIN;
		ptIpcIntTxn->cF026Ind = FLAG_NO_C;
		ptIpcIntTxn->cF052Ind = FLAG_NO_C;
		memcpy(ptIpcIntTxn->sPinData, "NPINNPIN", F052_LEN);
		ptIpcIntTxn->cF053Ind = FLAG_NO_C;
	}
	return 0;
}

/*****************************************************************************/
/* FUNC:   int SwtCustTransferPin4ZK (T_IpcIntTxnDef *ptIpcIntTxn)           */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                       */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Խ��յ������������������Ϣ,                                 */
/*       �ڵ��ú�����֤MAC����øú�����PINת��                              */
/*****************************************************************************/
int SwtCustTransferPin4ZK (T_IpcIntTxnDef  *ptIpcIntTxn)
{
	int			nReturnCode;
	HSMOprDef	tHsmOpr;
	char		sMsgSrcId[4+1],sMsgDestId[4+1];
	char		sSrcKeyIndex[5+1],sDestKeyIndex[5+1];
	
	memset(sMsgSrcId, 0 ,sizeof(sMsgSrcId));
	memcpy(sMsgSrcId, ptIpcIntTxn->sMsgSrcId, 4);
	memset(sMsgDestId, 0 ,sizeof(sMsgDestId));
	memcpy(sMsgDestId, ptIpcIntTxn->sMsgDestId, 4);
HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sMsgSrcId[%s] sMsgDestId[%s]", sMsgSrcId, sMsgDestId);
	memset(sSrcKeyIndex, 0x00, sizeof(sSrcKeyIndex));
	switch ( atoi(sMsgSrcId) )
	{
		case 1601:/*����*/
			sprintf(sSrcKeyIndex,"Y%04s","0001");
			break;
		case 1801:/*POSP*/
		case 1802:/*POSP*/
			sprintf(sSrcKeyIndex,"Y%04s","0005");
			break;
		default:
			break;
	}
	
	memset(sDestKeyIndex, 0x00, sizeof(sDestKeyIndex));
	switch ( atoi(sMsgDestId) )
	{
		case 1613:/*�ܿ�*/
			sprintf(sDestKeyIndex,"Y%04s","0007");
			break;
		default:
			break;
	}
	
	if(ptIpcIntTxn->cF052Ind == FLAG_YES_C)
	{

		memset((char *)&tHsmOpr,0,sizeof(HSMOprDef));

		tHsmOpr.saOprType = HSM_TRANSPIN4ZK;
		memcpy(&tHsmOpr.saRout[0],sSrcKeyIndex,5);
		memcpy(&tHsmOpr.saRout[5],sDestKeyIndex,5);

		memcpy(tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
		/* ������ǿ� */
		memcpy(tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
		memcpy(tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
		/* �����ֽ� */
		memcpy(tHsmOpr.saTRK, ptIpcIntTxn->sAcctId2Len,F002_LEN_LEN);
		memcpy(tHsmOpr.saTRK+2, ptIpcIntTxn->sAcctId2,F002_VAL_LEN);
		
		memcpy(tHsmOpr.saEnc, ptIpcIntTxn->sPinData, 8);

		nReturnCode = nEncOpr (&tHsmOpr);
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
			return -1;
		}
		ptIpcIntTxn->cF052Ind = FLAG_YES_C;
		memcpy (ptIpcIntTxn->sPinData, tHsmOpr.saEnc, F052_LEN);
	}
	else
	{
		ptIpcIntTxn->sPosEntryModeCode[2] = F022_WITH_OUT_PIN;
		ptIpcIntTxn->cF026Ind = FLAG_NO_C;
		ptIpcIntTxn->cF052Ind = FLAG_NO_C;
		memcpy(ptIpcIntTxn->sPinData, "NPINNPIN", F052_LEN);
		ptIpcIntTxn->cF053Ind = FLAG_NO_C;
	}
	return 0;
}

#if 0
/*****************************************************************************/
/* FUNC:    int SwtCustTransferPin (T_IpcIntTxnDef *ptIpcIntTxn)              */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                        */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Խ��յ������������������Ϣ,                                 */
/*        �ڵ��ú�����֤MAC����øú�����PINת��                              */
/*****************************************************************************/
int SwtCustTransferPin (T_IpcIntTxnDef *ptIpcIntTxn )
{
	char	 sFuncName[] = "SwtCustTransferPin";
	int	  nReturnCode;
	HSMOprDef	tHsmOpr;
	char		OldNew[2];
	char sTmpPin1[16+1];
	char sTmpPin2[16+1];
	char sTmpPin3[16+1];
	char sTmpPin4[16+1];
	char sTmpPin[16+1];
	char sTmpCard[19+1];
	char sTmpStr[2+1];
  char			 sPoszpkName[34+1];
  char			 sAtmbmkName[34+1];
  char			 sPubzpkName[34+1];
  char			 sCupZpkName[20];
  memset(sPubzpkName,0,sizeof(sPubzpkName));
  memset(sCupZpkName,0,sizeof(sCupZpkName));
  
 HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, " ����[%2.2s] .", ptIpcIntTxn->sFldReserved+8);
  memcpy(sCupZpkName,"czb.cup00000000.zpk",19);
  switch( ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] )
  {
	  case TXN_NUM_TDB_REQ:
			memcpy(&sCupZpkName[7],ptIpcIntTxn->sRcvgInstIdCode,8);
			break;
	  case TXN_NUM_BDT_REQ:
	  case TXN_NUM_BDB_REQ:
			memcpy(&sCupZpkName[7],ptIpcIntTxn->sFwdInstIdCode,8);
			break;
	  default:
			break;
  }
  if((memcmp(ptIpcIntTxn->sFldReserved+8,"03",2)==0 ||memcmp(ptIpcIntTxn->sFldReserved+8,"39",2)==0 ||memcmp(ptIpcIntTxn->sFldReserved+8,"47",2)==0 ||memcmp(ptIpcIntTxn->sFldReserved+8,"17",2)==0 ||memcmp(ptIpcIntTxn->sFldReserved+8,"09",2)==0)&&memcmp(ptIpcIntTxn->sAcqInstResvd+12,"05",2)!=0 &&memcmp(ptIpcIntTxn->sAcqInstResvd+12,"07",2)!=0) 
  {  
	  memset(sPoszpkName,0,sizeof(sPoszpkName));
	  memcpy(sPoszpkName,"czb.pos",7);
	  memcpy(sPoszpkName+7,ptIpcIntTxn->sCardAccptrId,sizeof(ptIpcIntTxn->sCardAccptrId));
	  memcpy(sPoszpkName+22,ptIpcIntTxn->sCardAccptrTermnlId,sizeof(ptIpcIntTxn->sCardAccptrTermnlId));
	  memcpy(sPoszpkName+30,".zpk",4);
	  strcpy(sPubzpkName,sPoszpkName);

	  if ((memcmp(ptIpcIntTxn->sAcqInstResvd+12,"14",2) == 0) ||
	  		(memcmp(ptIpcIntTxn->sAcqInstResvd+12,"39",2)==0)  ||
	  		(memcmp(ptIpcIntTxn->sAcqInstResvd+12,"47",2)==0) ||
	  		(memcmp(ptIpcIntTxn->sAcqInstResvd+12,"09",2)==0)  ||
	  		(memcmp(ptIpcIntTxn->sAcqInstResvd+12,"17",2)==0) ||
				(memcmp(ptIpcIntTxn->sAcqInstResvd+12,"19",2) == 0))
	  {
		  HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Epos or Oldpos");
		  memset(sPubzpkName,0,sizeof(sPubzpkName));
		  memcpy(sPubzpkName,"czb.posp2tpl.zpk",16);
	  }

	  HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	 HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sPoszpkName %s .", sPubzpkName);
	  memset(OldNew , 0 , sizeof(OldNew));
	  memcpy(OldNew , ptIpcIntTxn->sMisc+127 , 1 );
	
	  memset(sTmpPin1,0,sizeof(sTmpPin1));
	  memset(sTmpPin2,0,sizeof(sTmpPin2));
	  memset(sTmpCard,0,sizeof(sTmpCard));
	  memset(sTmpStr,0,sizeof(sTmpStr));
  }
	
	if(memcmp(ptIpcIntTxn->sFldReserved+8,"01",2)==0&&memcmp(ptIpcIntTxn->sAcqInstResvd+12,"05",2)!=0&&memcmp(ptIpcIntTxn->sAcqInstResvd+12,"07",2)!=0)  
  {
  	memset(sAtmbmkName,0,sizeof(sAtmbmkName));
	  memcpy(sAtmbmkName,"czb.atm",7);
	  memcpy(sAtmbmkName+7,ptIpcIntTxn->sAcqInstResvd+30,9);
	  memcpy(sAtmbmkName+16,ptIpcIntTxn->sCardAccptrTermnlId,sizeof(ptIpcIntTxn->sCardAccptrTermnlId));
	  memcpy(sAtmbmkName+24,".zpk",4);
	  strcpy(sPubzpkName,sAtmbmkName);
	  HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	  HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sAtmbmkName %s .", sPubzpkName);
		
	  memset(sTmpPin1,0,sizeof(sTmpPin1));
	  memset(sTmpPin2,0,sizeof(sTmpPin2));
	  memset(sTmpCard,0,sizeof(sTmpCard));
	  memset(sTmpStr,0,sizeof(sTmpStr));
  }
  if( memcmp(ptIpcIntTxn->sTxnNum,"1935",4)==0 )
	{ /* �������޸����� */	
	
	memset(sTmpPin3,0,sizeof(sTmpPin3));
	  memset(sTmpPin4,0,sizeof(sTmpPin4));
	  memset(sTmpPin,0,sizeof(sTmpPin));
HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ptIpcIntTxn->sAddtnlDataPrivate[%18.18s]",ptIpcIntTxn->sAddtnlDataPrivate);
	  memcpy(sTmpPin3,ptIpcIntTxn->sAddtnlDataPrivate+2,F053_LEN);
HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "wjing TransferPin begin");
	Hex2Str(ptIpcIntTxn->sPinData,sTmpPin1,8);
HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNum,sizeof(ptIpcIntTxn->sPrimaryAcctNum));
HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNumLen,sizeof(ptIpcIntTxn->sPrimaryAcctNumLen));
		memcpy(sTmpStr,ptIpcIntTxn->sPrimaryAcctNumLen,2);
		memcpy(sTmpCard,&ptIpcIntTxn->sPrimaryAcctNum[0],atoi(sTmpStr));
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin1[%s]Card[%s]",sTmpPin1,sTmpCard);
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin3[%s]Card[%s]",sTmpPin3,sTmpCard);
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sPubzpkName[%s]",sPubzpkName);

		nReturnCode = UnionTranslateX98PinToZSHPin(sPubzpkName,
										"czb.host.zpk",
										sTmpPin1,
										sTmpCard,
										sTmpPin2);

	 if ( nReturnCode < 0 )
	 {
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Faild!ret=[%d]",nReturnCode);
				 return -1;
		 }
		 
		 nReturnCode = UnionTranslateX98PinToZSHPin(sPubzpkName,
										"czb.host.zpk",
										sTmpPin3,
										sTmpCard,
										sTmpPin4);

	 if ( nReturnCode < 0 )
	 {
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Faild!ret=[%d]",nReturnCode);
				 return -1;
		 }
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin2[%s]",sTmpPin2);
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin4[%s]",sTmpPin4);
		ptIpcIntTxn->cF053Ind = FLAG_YES_C;
		memcpy(ptIpcIntTxn->sSecRelatdCtrlInfo, sTmpPin2, F053_LEN); 
		memcpy(ptIpcIntTxn->sMisc, sTmpPin4, F053_LEN);
	}
	
		/*EFTP����PIN����*/
	nReturnCode= SwtCustEncryptPin(ptIpcIntTxn);
		if (nReturnCode)
			{
				HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "EncryptPin err %d",nReturnCode);
		  	return -1 ;
		 }
		 
	if( ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ )
	{ /* ���������� */
		#if 0
		memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

		tHsmOpr.saOprType = HSM_TRANSPIN;
		tHsmOpr.saRout[0] = 'Y';
		/*memcpy (tHsmOpr.saRout+1, "0002", 4);*/
		/*get MinShen  SBNO  front 2 byte  as  BMK index */
		/* Modify by LIUSHJ , For POSP used the spec hsm idx Defined by env*/
		/*
			memcpy (tHsmOpr.saRout+1, "00", 2);
			memcpy (tHsmOpr.saRout+1+2, ptIpcIntTxn->sMisc + 16 , 2);
			*/
		tHsmOpr.OldNewFlag = OldNew[0];
		if(memcmp(ptIpcIntTxn->sTransType , TRANS_TYPE_POS ,FLD_TRANS_TYPE_LEN) == 0)
		{
			if(OldNew[0] == '1')
			{
				memcpy (tHsmOpr.saRout+1, getenv("HSM_INDEX_POSP"), HSM_INDEX_LEN);
				memcpy (tHsmOpr.TerminaNum , ptIpcIntTxn->sCardAccptrId , F042_LEN);
				memcpy (&tHsmOpr.TerminaNum[15] , ptIpcIntTxn->sCardAccptrTermnlId , F041_LEN);
				tHsmOpr.saRout[5] = 'Y';
				if (getenv("HSM_INDEX_CUP"))
				memcpy (tHsmOpr.saRout+6, getenv("HSM_INDEX_CUP"), HSM_INDEX_LEN);

				tHsmOpr.saWithKey[0] = 'N';
				tHsmOpr.saWithKey[33] = 'N';	
				
				memcpy (tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
					memcpy (tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
				memcpy (tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
				memcpy (tHsmOpr.saEnc, ptIpcIntTxn->sPinData,F052_LEN);
				memcpy(tHsmOpr.SerialIn , ptIpcIntTxn->sSysSeqNum,6);
				tHsmOpr.OldNewFlag = '1';

				/* nReturnCode = nEncOpr (&tHsmOpr); */
				nReturnCode = 0;
				if (nReturnCode != HSM_SUCCESS) 
				{
					HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
					return -1;
				}
				memcpy (tHsmOpr.saRout+1, getenv("HSM_INDEX_CUP"), HSM_INDEX_LEN);
				memcpy (tHsmOpr.saRout+6, getenv("HSM_INDEX_HOST"), HSM_INDEX_LEN);
				tHsmOpr.OldNewFlag = '0';

				/* nReturnCode = nEncOpr (&tHsmOpr); */
				nReturnCode = 0;
				if (nReturnCode != HSM_SUCCESS)
				{
					HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nEncOpr2 %c error.", tHsmOpr.saOprType);
					return -1;
				}
				
				ptIpcIntTxn->cF052Ind = FLAG_YES_C;
				memcpy (ptIpcIntTxn->sPinData, tHsmOpr.saEnc, F052_LEN);				
				
				HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
				return 0;
			}
			else{
				memcpy(tHsmOpr.saRout+1 , getenv("HSM_INDEX_POSP") , HSM_INDEX_LEN );
				memcpy (tHsmOpr.TerminaNum , ptIpcIntTxn->sCardAccptrId , F042_LEN);
				memcpy (&tHsmOpr.TerminaNum[15] , ptIpcIntTxn->sCardAccptrTermnlId , F041_LEN);
				tHsmOpr.saRout[5] = 'Y';
				if (getenv("HSM_INDEX_CUP"))
				memcpy (tHsmOpr.saRout+6, getenv("HSM_INDEX_CUP"), HSM_INDEX_LEN);

				tHsmOpr.saWithKey[0] = 'N';
				tHsmOpr.saWithKey[33] = 'N';

				memcpy (tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
				memcpy (tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
				memcpy (tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
				memcpy (tHsmOpr.saEnc, ptIpcIntTxn->sPinData,F052_LEN);
				memcpy(tHsmOpr.SerialIn , ptIpcIntTxn->sSysSeqNum,6);
				tHsmOpr.OldNewFlag = '1';

				/* nReturnCode = nEncOpr (&tHsmOpr); */
				nReturnCode = 0;
				if (nReturnCode != HSM_SUCCESS)
				{
					HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
					return -1;
				}
				memcpy (tHsmOpr.saRout+1, getenv("HSM_INDEX_CUP"), HSM_INDEX_LEN);
				memcpy (tHsmOpr.saRout+6, getenv("HSM_INDEX_HOST"), HSM_INDEX_LEN);
				tHsmOpr.OldNewFlag = '0';

				/* nReturnCode = nEncOpr (&tHsmOpr); */
				nReturnCode = 0;
				if (nReturnCode != HSM_SUCCESS)
				{
					HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nEncOpr2 %c error.", tHsmOpr.saOprType);
					return -1;
				}

				ptIpcIntTxn->cF052Ind = FLAG_YES_C;
				memcpy (ptIpcIntTxn->sPinData, tHsmOpr.saEnc, F052_LEN);

				HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
				return 0;
			}	
		}
		else if(memcmp(ptIpcIntTxn->sTransType , TRANS_TYPE_ATM ,FLD_TRANS_TYPE_LEN) == 0)
		{
			if(OldNew[0] == '1')
			{
				memcpy (tHsmOpr.saRout+1, getenv("HSM_INDEX_ATMP"), HSM_INDEX_LEN);
			}
			else
			{
				memcpy(tHsmOpr.saRout+1 , getenv("HSM_INDEX_HOST") , HSM_INDEX_LEN );
			}
		}
		tHsmOpr.saRout[5] = 'Y';
		if (getenv("HSM_INDEX_HOST"))
			memcpy (tHsmOpr.saRout+6, getenv("HSM_INDEX_HOST"), HSM_INDEX_LEN);

		tHsmOpr.saWithKey[0] = 'Y';
		memcpy (tHsmOpr.saWithKey+1, ptIpcIntTxn->sMisc, 16);
		tHsmOpr.saWithKey[33] = 'N';

		memcpy (tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
		memcpy (tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
		memcpy (tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
		memcpy (tHsmOpr.saEnc, ptIpcIntTxn->sPinData,F052_LEN);
		memcpy(tHsmOpr.SerialIn , ptIpcIntTxn->sSysSeqNum,6);

		/* nReturnCode = nEncOpr (&tHsmOpr); */
		nReturnCode = 0;
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
			return -1;
		}

		ptIpcIntTxn->cF052Ind = FLAG_YES_C;
		memcpy (ptIpcIntTxn->sPinData, tHsmOpr.saEnc, F052_LEN);
#endif

HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "wjing TransferPin begin");
Hex2Str(ptIpcIntTxn->sPinData,sTmpPin1,8);
HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNum,sizeof(ptIpcIntTxn->sPrimaryAcctNum));
HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNumLen,sizeof(ptIpcIntTxn->sPrimaryAcctNumLen));
		memcpy(sTmpStr,ptIpcIntTxn->sPrimaryAcctNumLen,2);
		memcpy(sTmpCard,&ptIpcIntTxn->sPrimaryAcctNum[0],atoi(sTmpStr));
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin[%s]Card[%s]",sTmpPin1,sTmpCard);
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sPubzpkName[%s]",sPubzpkName);
		/* if (memcmp(ptIpcIntTxn->sFldReserved+8,"19",2)==0)
			{
				nReturnCode = UnionTranslateX98PinToZSHPin("czb.cups.zpk",
										"czb.host.zpk",
										sTmpPin1,
										sTmpCard,
										sTmpPin2);
			}
		else
			{ */
			nReturnCode = UnionTranslateX98PinToZSHPin(sPubzpkName,
										"czb.host.zpk",
										sTmpPin1,
										sTmpCard,
										sTmpPin2);
		/*	}  */
		 if ( nReturnCode < 0 ){
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Faild!ret=[%d]",nReturnCode);
				 return -1;
		 }
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin2[%s]",sTmpPin2);
		ptIpcIntTxn->cF053Ind = FLAG_YES_C;
		memcpy(ptIpcIntTxn->sSecRelatdCtrlInfo, sTmpPin2, F053_LEN); 
	}
	else if( ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_REQ )
	{ /* ���������� */
		#if 0
		memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

		tHsmOpr.saOprType = HSM_TRANSPIN;
		tHsmOpr.saRout[0] = 'Y';
		/*memcpy (tHsmOpr.saRout+1, "0002", 4);*/
		/*get MinShen  SBNO  front 2 byte  as  BMK index */
		/* Modify by LIUSHJ , For POSP used the spec hsm idx Defined by env*/
		/*
			memcpy (tHsmOpr.saRout+1, "00", 2);
			memcpy (tHsmOpr.saRout+1+2, ptIpcIntTxn->sMisc + 16 , 2);
			*/
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ptIpcIntTxn->sTransType[%.1s].", ptIpcIntTxn->sTransType);
		if(memcmp(ptIpcIntTxn->sTransType , TRANS_TYPE_POS ,FLD_TRANS_TYPE_LEN) == 0){
			memcpy (tHsmOpr.saRout+1, getenv("HSM_INDEX_POSP"), HSM_INDEX_LEN);
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "tHsmOpr.saRout+1[%s].", tHsmOpr.saRout+1);
		}
		else if(memcmp(ptIpcIntTxn->sTransType , TRANS_TYPE_ATM ,FLD_TRANS_TYPE_LEN) == 0)
			memcpy (tHsmOpr.saRout+1, getenv("HSM_INDEX_ATMP"), HSM_INDEX_LEN);
		else if(memcmp(ptIpcIntTxn->sTransType , TRANS_TYPE_GM , FLD_TRANS_TYPE_LEN) == 0)
		{
			//  memcpy (tHsmOpr.saRout+1, getenv("HSM_INDEX_GMPATMP"), HSM_INDEX_LEN);
			memcpy (tHsmOpr.saRout+1, "0199", 4);
			/*��ֵ���к� */
			//	memcpy (tHsmOpr.saRout+3, ptIpcIntTxn->sMisc+16, 2);
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "tHsmOpr.saRout+1[%s].", tHsmOpr.saRout+1);
		}
		tHsmOpr.saRout[5] = 'Y';
		if (getenv(HSM_INDEX_CUP))
			memcpy (tHsmOpr.saRout+6, getenv(HSM_INDEX_CUP), HSM_INDEX_LEN);

		tHsmOpr.saWithKey[0] = 'Y';
		memcpy (tHsmOpr.saWithKey+1, ptIpcIntTxn->sMisc, 16);
		tHsmOpr.saWithKey[33] = 'N';

		memcpy (tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
		memcpy (tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
		memcpy (tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
		memcpy (tHsmOpr.saEnc, ptIpcIntTxn->sPinData,F052_LEN);

		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ptIpcIntTxn->sMisc[%16.16s].", ptIpcIntTxn->sMisc);
		tHsmOpr.OldNewFlag = OldNew[0];
		memcpy(tHsmOpr.SerialIn , ptIpcIntTxn->sSysSeqNum,6);
		/* nReturnCode = nEncOpr (&tHsmOpr); */
		nReturnCode = 0;
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
			return -1;
		}

		ptIpcIntTxn->cF052Ind = FLAG_YES_C;
		memcpy (ptIpcIntTxn->sPinData, tHsmOpr.saEnc, F052_LEN);
		#endif
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "wjing TransferPin begin");
		Hex2Str(ptIpcIntTxn->sPinData,sTmpPin1,8);
		HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNum,sizeof(ptIpcIntTxn->sPrimaryAcctNum));
		HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNumLen,sizeof(ptIpcIntTxn->sPrimaryAcctNumLen));
		memcpy(sTmpStr,ptIpcIntTxn->sPrimaryAcctNumLen,2);
		memcpy(sTmpCard,&ptIpcIntTxn->sPrimaryAcctNum[0],atoi(sTmpStr));
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin[%s]Card[%s]",sTmpPin1,sTmpCard);
		if (memcmp(ptIpcIntTxn->sFldReserved+8,"19",2)==0)
			{
					nReturnCode = UnionTranslatePin("czb.posp2tpl.zpk",
										sCupZpkName,
										sTmpPin1,
										sTmpCard,
										sTmpPin2);
			
			}
			else if (memcmp(ptIpcIntTxn->sFldReserved+8,"06",2)==0)
				{
						nReturnCode = UnionTranslatePin("czb.abs2tpl.zpk",
										sCupZpkName,
										sTmpPin1,
										sTmpCard,
										sTmpPin2);
														HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "3333");
				}
			else if (memcmp(ptIpcIntTxn->sAcqInstResvd+12,"05",2)==0 || memcmp(ptIpcIntTxn->sAcqInstResvd+12,"07",2)==0)
				{
						nReturnCode = UnionTranslatePin("czb.eftp2tpl.zpk",
										sCupZpkName,
										sTmpPin1,
										sTmpCard,
										sTmpPin2);
										HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "11111");
				}
				else
				{
		nReturnCode = UnionTranslatePin(sPubzpkName,
										sCupZpkName,
										sTmpPin1,
										sTmpCard,
										sTmpPin2);
														HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "22222");
				}
		 if ( nReturnCode < 0 ){
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Faild!ret=[%d]",nReturnCode);
				 return -1;
		 }
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin2[%s]",sTmpPin2);
		Str2Hex(sTmpPin2,ptIpcIntTxn->sPinData,16);
	}
	else if( ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ )
	{
		/*	
		memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

		tHsmOpr.saOprType = HSM_TRANSPIN;
		tHsmOpr.saRout[0] = 'Y';
		if (getenv("HSM_INDEX_CUP") == NULL)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "getenv HSM_INDEX_CUP error.");
			return -1;
		}
		memcpy (tHsmOpr.saRout+1, getenv("HSM_INDEX_CUP"), HSM_INDEX_LEN);
		tHsmOpr.saRout[5] = 'Y';
		if (getenv("HSM_INDEX_HOST") == NULL)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "getenv HSM_INDEX_HOST error.");
			return -1;
		}
		memcpy (tHsmOpr.saRout+6, getenv("HSM_INDEX_HOST"), HSM_INDEX_LEN);

		memcpy (tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
		memcpy (tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
		memcpy (tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
		memcpy (tHsmOpr.saEnc, ptIpcIntTxn->sPinData, F052_LEN);

		tHsmOpr.OldNewFlag = OldNew[0];
		memcpy(tHsmOpr.SerialIn , ptIpcIntTxn->sSysSeqNum,6);
		nReturnCode = nEncOpr (&tHsmOpr); 
		nReturnCode = 0;
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nEncOpr %cerror.", tHsmOpr.saOprType);
			return -1;
		}  */

		
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "wjing TransferPin begin");
		Hex2Str(ptIpcIntTxn->sPinData,sTmpPin1,8);
HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNum,sizeof(ptIpcIntTxn->sPrimaryAcctNum));
HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNumLen,sizeof(ptIpcIntTxn->sPrimaryAcctNumLen));
		memcpy(sTmpStr,ptIpcIntTxn->sPrimaryAcctNumLen,2);
		memcpy(sTmpCard,&ptIpcIntTxn->sPrimaryAcctNum[0],atoi(sTmpStr));
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin[%s]Card[%s]",sTmpPin1,sTmpCard);
		nReturnCode = UnionTranslateX98PinToZSHPin(sCupZpkName,
										"czb.host.zpk",
										sTmpPin1,
										sTmpCard,
										sTmpPin2);
		 if ( nReturnCode < 0 ){
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Faild!ret=[%d]",nReturnCode);
				 return -1;
		 }
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Pin2[%s]",sTmpPin2);
		ptIpcIntTxn->cF053Ind = FLAG_YES_C;
		memcpy(ptIpcIntTxn->sSecRelatdCtrlInfo, sTmpPin2, F053_LEN); 
	}
 
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}
#endif
/*****************************************************************************/
/* FUNC:    int SwtCustTransferRspCode                                       */
/* INPUT:  HOSTRSPCODE                                                       */
/* OUTPUT:                                                                   */
/*         nMaxRspCodeMapN Ӧ����ת����������                                */
/*         tBrhCodeMap Ӧ����ת������                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:      ����Ӧ����ת������                                             */
/*****************************************************************************/
int SwtCustTransferRspCode(T_IpcIntTxnDef *ptIpcIntTxn)
{
	static	int  sInitflag=1;
	/*static  int nMaxRspCodeMapN = 0;*/
	int nReturnCode;
	int i ;

	/* static Tbl_rsp_code_map_Def tRspCodeMap[5000]; */

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"SwtCustTransferRspCode begin");
	/*if (sInitflag)
	{
		nReturnCode = LoadRspCodeMap(&nMaxRspCodeMapN, &tRspCodeMap);
	 	if(nReturnCode)
		{
			 HtLog(	gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LoadRspCodeMap %d.", nReturnCode);
			 return nReturnCode;
		}
		sInitflag = 0 ;
	}*/
	
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"ptIpcIntTxn->sMsgSrcId:[%4.4s]",ptIpcIntTxn->sMsgSrcId);
	
	if ( ( ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_CBDB_RSP ) &&  
	     ( memcmp(ptIpcIntTxn->sMsgSrcId,"1702",4) == 0 ) )    /* ���ÿ� */
	{
		if(memcmp(&ptIpcIntTxn->sRespCode,"00",2) != 0) 
		{
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"Original sRespCode[%2.2s]",ptIpcIntTxn->sRespCode);
			 for( i=0;i<gnMaxRspCodeMapLen;i++)
			 {			   
				if((memcmp(tRspCodeMap[i].src_id, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN) == 0) && 
				   (memcmp(tRspCodeMap[i].src_rsp_code, &ptIpcIntTxn->sRespCode, 2) == 0))  
				break;
			 }
			 if(i == gnMaxRspCodeMapLen)
			 {
				return -1;
			 }
			 else
			 {
				memcpy(ptIpcIntTxn->sRespCode,tRspCodeMap[i].dest_rsp_code,F039_LEN);
			 }
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"Dest sRespCode[%2.2s]",ptIpcIntTxn->sRespCode);
		}
	}
	
	if ( ( ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_RSP ||
	        ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_RSP) &&  
	     ( memcmp(ptIpcIntTxn->sMsgSrcId,SRV_ID_COMM_ZK,4) == 0 ) )    /* �ܿ� */
	{
		if(memcmp(ptIpcIntTxn->sRespCode,"00",2) != 0) 
		{
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"Original sRespCode[%7.7s]",ptIpcIntTxn->sStlmInst);
			 for( i=0;i<gnMaxRspCodeMapLen;i++)
			 {
				if(memcmp(tRspCodeMap[i].src_id, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN) == 0)
				{
				    if(memcmp(tRspCodeMap[i].src_rsp_code, ptIpcIntTxn->sStlmInst+3, 4) == 0 ||
				        memcmp(tRspCodeMap[i].src_rsp_code, ptIpcIntTxn->sStlmInst, 7) == 0)
				        break;
				}
			 }
			 if(i == gnMaxRspCodeMapLen)
			 {
			    if(memcmp(ptIpcIntTxn->sStlmInst, "HSM", 3) == 0)
			        memcpy(ptIpcIntTxn->sRespCode, F039_MAC_FAIL, F039_LEN);
			    else if(memcmp(ptIpcIntTxn->sStlmInst, "HOS", 3) == 0)
			        memcpy(ptIpcIntTxn->sRespCode, "91", F039_LEN);
			    else
			    {
			        /* �Ҳ�����¼��Ĭ�ϸ�ֵ01 */
				    memcpy(ptIpcIntTxn->sRespCode, "01", F039_LEN);
				}
			 }
			 else
			 {
				memcpy(ptIpcIntTxn->sRespCode,tRspCodeMap[i].dest_rsp_code,F039_LEN);
			 }
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"Dest sRespCode[%2.2s]",ptIpcIntTxn->sRespCode);
		}
	}

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"SwtCustTransferRspCode end");
	return 0;
	
}

/*****************************************************************************/
/* FUNC:    int SwtCustTransferCupAreaId                                     */
/* INPUT:  HOSTRSPCODE                                                       */
/* OUTPUT:                                                                   */
/*         nMaxRspCodeMapN Ӧ����ת����������                                */
/*         tBrhCodeMap Ӧ����ת������                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:      ����Ӧ����ת������                                             */
/*****************************************************************************/
int SwtCustTransferCupAreaId(T_IpcIntTxnDef *ptIpcIntTxn)
{
	static	int  sInitflag=1;
	int nReturnCode;
	int i ;

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"SwtCustTransferCupAreaId begin");
	
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"sAcqInstIdCode [%11.11s]",ptIpcIntTxn->sAcqInstIdCode);

	for( i=0;i<gnMaxCupAreaLen;i++)
	{
	if(memcmp(gatCupArea[i].area_id, ptIpcIntTxn->sAcqInstIdCode+4, SRV_ID_LEN) == 0)
	    break;
	}
	if(i == gnMaxCupAreaLen)
	{
	    /* �Ҳ�����¼��ʹ��Ĭ��ֵ */
        HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"not found brh_id, use default val.");
        memcpy(ptIpcIntTxn->sHostSSN, DFT_BANK_ID, 6);
	}
	else
	{
	    memcpy(ptIpcIntTxn->sHostSSN, gatCupArea[i].zone_brh_id, 6);
	}
	
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"sHostSSN [%6.6s]",ptIpcIntTxn->sHostSSN);

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"SwtCustTransferCupAreaId end");
	return 0;
}


#if 0
/*****************************************************************************/
/* FUNC:    int SwtCustEncryptPin (T_IpcIntTxnDef *ptIpcIntTxn)              */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                        */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Խ��յ�������EFTP,�������Ϣ,                                 */
/*        �ڵ��øú�����PIN����                              */
/*****************************************************************************/
int SwtCustEncryptPin (T_IpcIntTxnDef *ptIpcIntTxn )
{
	char	 sFuncName[] = "SwtCustEncryptPin";
	int	  nReturnCode;
	char sTmpPin1[16+1];
	char sTmpPin[8+1];
	char sTmpPan[19+1];
	char sTmpLen[2+1];
  memset(sTmpPin1,0,sizeof(sTmpPin1));
	memset(sTmpPin,0,sizeof(sTmpPin));
	memset(sTmpPan,0,sizeof(sTmpPan));
	memset(sTmpLen,0,sizeof(sTmpLen));

	if ( ((memcmp(ptIpcIntTxn->sMsgSrcId,"1803",4)==0) || 
		  (memcmp(ptIpcIntTxn->sMsgSrcId,"1804",4)==0)) &&
		  (ptIpcIntTxn->sPosEntryModeCode[2] == '1'))
		{	
			HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "wjing[%8.8s]",ptIpcIntTxn->sPinData);
HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "wjing[%19.19s]",ptIpcIntTxn->sPrimaryAcctNum);
		  memcpy(sTmpPin,ptIpcIntTxn->sPinData,8);
		  if ( ptIpcIntTxn->sPrimaryAcctNumLen[0] != ' ' &&
				ptIpcIntTxn->sPrimaryAcctNumLen[0] != 0x00 )
		  {
			 memcpy(sTmpLen,ptIpcIntTxn->sPrimaryAcctNumLen,2);
			 memcpy(sTmpPan,ptIpcIntTxn->sPrimaryAcctNum,atoi(sTmpLen));
		  }
		  else {
			 HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Pan Error");
			 return -1;
		  }
	  CommonRTrim(sTmpPin);
HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "wjing[%s]",sTmpPin);
HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "wjing[%s]",sTmpPan);
	  if (!memcmp(ptIpcIntTxn->sFldReserved+8,"06",2))
			nReturnCode = UnionEncryptPin ("czb.abs2tpl.zpk",sTmpPin,sTmpPan,sTmpPin1); 
			else if (!memcmp(ptIpcIntTxn->sAcqInstResvd+12,"05",2) || !memcmp(ptIpcIntTxn->sAcqInstResvd+12,"07",2))
			nReturnCode = UnionEncryptPin ("czb.eftp2tpl.zpk",sTmpPin,sTmpPan,sTmpPin1); 
				if (nReturnCode)
				{
HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "SwtCust return EncryptPin Failed ,nReturnCode=[%d]",nReturnCode);
					  return nReturnCode;
				}
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "wjing[%s]",sTmpPin1);
		Str2Hex(sTmpPin1,ptIpcIntTxn->sPinData,16);
	 HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sPrimaryAcctNum,sizeof(ptIpcIntTxn->sPrimaryAcctNum));
	
			HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
			return 0 ;
		}
	return 0 ;
}
#endif

/*****************************************************************************/
/* FUNC:    int CardCompareTrack (char *sTrack, char *sCardId)                */
/* INPUT:  sTrack: ת�ʽ��׿������ݱȽ�                                              */
/*         sCardId: ��ʶ����                                                 */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �뿨ʶ����һ��, -1: �뿨ʶ���벻һ��                            */
/* DESC:    �ȽϿ���ǰ��λ�뿨ʶ�����Ƿ���ͬ                                    */
/*****************************************************************************/
int CardCompCarno (char *carno, char *sCardId)
{
		int i=0;
		CommonRTrim(sCardId);
		CommonLTrim(sCardId);
		i = strlen(sCardId);
	if( memcmp(carno,sCardId,i)==0)
		return 0;
	else
		return -1;
}

#if 0
/*********************************************************************************/
/* FUNC:    int PCSPacketWrapper (T_IpcIntTxnDef *ptIpcIntTxn) */
/* INPUT:  ptIpcIntTxn: �ڲ�IPC��ṹ                                            */
/*         ptTxn:                                                                */
/* OUTPUT: ��                                                                    */
/* RETURN: 0: �ɹ�, -1: ����                                                     */
/* DESC:    ��䷢����ֵ���Ķ�������                                              */
/*********************************************************************************/
int PCSPacketWrapper(T_IpcIntTxnDef *ptIpcIntTxn)
{
	
	char sSrvName[12+1];
	char sToBrhno[6+1];
	char sFromBrhno[6+1];
	char sFaDongDuan[4+1];
	char sCurrentDate[8+1];
	char sCurrentTime[6+1];
	char sAmtTrans[13+1];
	float fAmtTrans=0;
	
	memset(sSrvName,0,sizeof(sSrvName));
	memset(sToBrhno,0,sizeof(sToBrhno));
	memset(sFromBrhno,0,sizeof(sFromBrhno));
	memset(sFaDongDuan,0,sizeof(sFaDongDuan));
	memset(sCurrentDate,0,sizeof(sCurrentDate));
	memset(sCurrentTime,0,sizeof(sCurrentTime));
	memset(sAmtTrans,0,sizeof(sAmtTrans));
	
	memcpy(sSrvName,"PCS_XXX",7);
	memcpy(sToBrhno,"101000",6);
	memset(sFromBrhno,'9',6);
	memcpy(sFromBrhno+2,ptIpcIntTxn->sAcqInstIdCode+4,4);
	
	
	/*memset(ptIpcIntTxn->sNationalSwResved,0,sizeof(ptIpcIntTxn->sNationalSwResved));
	memset(ptIpcIntTxn->sAcqInstResvd,0,sizeof(ptIpcIntTxn->sAcqInstResvd));*/
	memset(ptIpcIntTxn->sNationalSwResved,' ',F121_VAL_LEN);
	memset(ptIpcIntTxn->sAcqInstResvd,' ',F123_VAL_LEN);
	memcpy(ptIpcIntTxn->sNationalSwResved,"1024",4);	/*4λ���ĳ��ȣ�1024��*/	
	memcpy(ptIpcIntTxn->sNationalSwResved+4,sSrvName,7);		/*12λ������*/
	memcpy(ptIpcIntTxn->sNationalSwResved+16,"1",1);	/*���ͱ�ʶ*/
	memcpy(ptIpcIntTxn->sNationalSwResved+17,sToBrhno,6);	 /*TO������*/
	memcpy(ptIpcIntTxn->sNationalSwResved+23,sFromBrhno,6);	 /*FROM������*/	
	memset(ptIpcIntTxn->sNationalSwResved+29,' ',5);	 /*ATM������*/
	memcpy(sFaDongDuan,ptIpcIntTxn->sAcqInstIdCode+4,4);
	memcpy(ptIpcIntTxn->sNationalSwResved+34,sFaDongDuan,4);	 /*������*/	
	memcpy(ptIpcIntTxn->sNationalSwResved+38,ptIpcIntTxn->sSysSeqNum,6);	 /*������ϵͳ��ˮ��*/
	memset(ptIpcIntTxn->sNationalSwResved+46,' ',8);	 /*��Ȩ��*/
	memset(ptIpcIntTxn->sNationalSwResved+54,0,4);	 /*ATM���*/	
	memset(sCurrentDate,0,sizeof(sCurrentDate));
	CommonGetCurrentDate(sCurrentDate);
	memcpy(ptIpcIntTxn->sNationalSwResved+58,sCurrentDate,8);	 /*��������*/	
	memcpy(ptIpcIntTxn->sNationalSwResved+66,"0",1);	 /*�����ʱ�*/
	memcpy(ptIpcIntTxn->sNationalSwResved+67,"1",1);	 /*ԭ�����*/
	memset(ptIpcIntTxn->sNationalSwResved+68,0,3);	 /*�ͻ�������*/
	memcpy(ptIpcIntTxn->sNationalSwResved+71,"1",1);	 /*��֧����*/
	memcpy(ptIpcIntTxn->sNationalSwResved+72,ptIpcIntTxn->sTxnNum,4);	 /*6λ���״���*/
	memcpy(ptIpcIntTxn->sNationalSwResved+78,sCurrentDate,8);	 /*������������*/
	memcpy(ptIpcIntTxn->sNationalSwResved+86,ptIpcIntTxn->sPrimaryAcctNum+12,7);	 /*�����˺�*/  
	
	fAmtTrans=atoi(ptIpcIntTxn->sAmtTrans)/100.00;
	sprintf(sAmtTrans,"%11.2f",fAmtTrans);
	memcpy(ptIpcIntTxn->sAcqInstResvd,sAmtTrans,13); /*���׽��*/
	memset(ptIpcIntTxn->sAcqInstResvd+13,0,1); /*Filter*/
	memset(ptIpcIntTxn->sAcqInstResvd+14,0,1); /*������ʶ*/
	memset(ptIpcIntTxn->sAcqInstResvd+15,' ',8); /*PIN BLOCK*/ 
	
	memset(sCurrentTime,0,sizeof(sCurrentTime));
	CommonGetCurrentTime(sCurrentTime);
	memcpy(ptIpcIntTxn->sAcqInstResvd+23,sCurrentTime,6); /*������ϵͳ����ʱ��*/
	
	memset(ptIpcIntTxn->sAcqInstResvd+29,0,1); /*������*/
	memset(ptIpcIntTxn->sAcqInstResvd+30,' ',19); /*���˺�*/
	memset(ptIpcIntTxn->sAcqInstResvd+49,0,4); /*�ص��ۿ���*/
	memset(ptIpcIntTxn->sAcqInstResvd+53,0,5); /*BATCH NUMBER*/
	memset(ptIpcIntTxn->sAcqInstResvd+58,0,3); /*���ױ���*/
	memset(ptIpcIntTxn->sAcqInstResvd+61,' ',5); /*TPDU*/
	memcpy(ptIpcIntTxn->sAcqInstResvd+66,ptIpcIntTxn->sAcqInstIdCode+4,7); /*���׵���*/
	memset(ptIpcIntTxn->sAcqInstResvd+73,0,8); /*������*/
	memset(ptIpcIntTxn->sAcqInstResvd+81,0,1); /*������֤��־*/
	memset(ptIpcIntTxn->sAcqInstResvd+82,0,3); /*����ժҪ����*/
	memset(ptIpcIntTxn->sAcqInstResvd+85,0,1); /*У�������־*/
	
	
	HtDebugString ("PCSWraper.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sNationalSwResved, sizeof(ptIpcIntTxn->sNationalSwResved));
	HtDebugString ("PCSWraper.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__,ptIpcIntTxn->sAcqInstResvd, sizeof(ptIpcIntTxn->sAcqInstResvd));
}
#endif

/*********************************************************************************/
/* FUNC:   int SetCreditCard (T_IpcIntTxnDef *ptIpcIntTxn,Tbl_txn_Def *ptOrigTxn)*/
/* INPUT:  ptIpcIntTxn: �ڲ�IPC��ṹ                                            */
/*         ptOrigTxn                                                             */
/* OUTPUT: ��                                                                    */
/* RETURN: 0: �ɹ�, -1: ����                                                     */
/* DESC:   ��䷢�����ÿ��Ķ�������                                              */
/*********************************************************************************/
int SetCreditCard(T_IpcIntTxnDef *ptIpcIntTxn,Tbl_txn_Def *ptTxn, Tbl_txn_Def *ptOrigTxn)
{
	char sFuncName[] = "SetCreditCard";
	char sTransAmt[15];
	char sAmt[15];
	char sCurrentTime[15];
	char sAmtTrans[13+1];

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    /*F037ʹ�ã�F007����λ+F011
    memcpy(ptIpcIntTxn->sRetrivlRefNum, ptIpcIntTxn->sMisc+4, F037_LEN);*/
    
	/* ����sKeyRsp��sGfHeader�ı���λ��,������tbl_txn�еĽ��׼�¼ʹ��  */
	memcpy(ptIpcIntTxn->sGfHeader+190, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
		
	memset(ptIpcIntTxn->sNationalSwResved, '0', F121_VAL_LEN);
	/* ��������  */
	if(!memcmp(ptIpcIntTxn->sTxnNum,"1017",4))/*Ԥ��Ȩ����*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0100030000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"2017",4))/*Ԥ��Ȩ��ԭ*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0400030000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"3017",4))/*Ԥ��Ȩ����*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0100230000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"4017",4))/*Ԥ��Ȩ������ԭ*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0400230000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"1107",4) ||
	        !memcmp(ptIpcIntTxn->sTxnNum,"1117",4))/*���ѽ�������*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0200000000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"2107",4) ||
	        !memcmp(ptIpcIntTxn->sTxnNum,"2117",4))/*���ѻ�ԭ*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0400000000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"3107",4) ||
	        !memcmp(ptIpcIntTxn->sTxnNum,"3117",4))/*���ѳ���*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0220000000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"4107",4) ||
	        !memcmp(ptIpcIntTxn->sTxnNum,"4117",4))/*���ѳ�����ԭ*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0400020000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"1207",4))/*��ѯ��������*/
		memcpy(&ptIpcIntTxn->sNationalSwResved[0],"0900310000",10);
	else
	{
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sTxnNum[%4.4s] %s err.", ptIpcIntTxn->sTxnNum,sFuncName);
		return -1;
	}
	
	/* ��������   */
	memcpy(&ptIpcIntTxn->sNationalSwResved[10],"AS",2);
	
	/* ������Դ   */
	memcpy(&ptIpcIntTxn->sNationalSwResved[12],"AS",2);
	
	/* ����ԭʼ��������ʱ��   */
	/*CommonGetCurrentTime (sCurrentTime);*/
	memcpy(sCurrentTime, gsTimeCurTs, 14);
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_REVSAL || 
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_CANCEL_REVSAL ||
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_CANCEL)
	{
	    /* ���ڻ�ԭ���� */
		if(ptOrigTxn->misc_flag[0] != ' ' && ptOrigTxn->trans_date_time[0] != ' ')
		{
			memcpy(&ptIpcIntTxn->sNationalSwResved[14], &ptOrigTxn->misc_flag[0], 4);
			memcpy(&ptIpcIntTxn->sNationalSwResved[18], ptOrigTxn->trans_date_time, F007_LEN);
		}
		else
		{
		    HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "cc txn get orig date error.");
		    return -1;
		}
	}
	else
	{
	    memcpy(&ptIpcIntTxn->sNationalSwResved[14],sCurrentTime,4);
	    memcpy(&ptIpcIntTxn->sNationalSwResved[18],ptIpcIntTxn->sTransmsnDateTime,F007_LEN);
    }
	
	/* �м�ƽ̨��������ʱ��   */
	memcpy(&ptIpcIntTxn->sNationalSwResved[28],sCurrentTime,4);
	memcpy(&ptIpcIntTxn->sNationalSwResved[32],ptIpcIntTxn->sTransmsnDateTime,F007_LEN);
	
	/*�յ���������n-11*/
	/*��ת��������n-11*/
	
	/* ��Ȩ����	*/
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_REVSAL || 
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_CANCEL_REVSAL ||
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_CANCEL)
		if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
			memcpy(&ptIpcIntTxn->sNationalSwResved[64], ptIpcIntTxn->sAuthrIdResp, F038_LEN);
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sAuthrIdRespF038_LEN[%6.6s].", ptIpcIntTxn->sAuthrIdResp);
	
	/*��Ӧ����An-2*/
	/*���׷���n-4*/
	/*��������n-6*/
	
	/* �̻�����	*/
	/*memcpy(&ptIpcIntTxn->sNationalSwResved[82], "000100000100453", 15);*/
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sNationalSwResved[%100.100s].", ptIpcIntTxn->sNationalSwResved);
	
	memset(ptIpcIntTxn->sIssrInstResvd, '0', F123_VAL_LEN);
	/* PIN-BLOCK	*/
	if(ptIpcIntTxn->sPosEntryModeCode[2] == '0' || ptIpcIntTxn->sPosEntryModeCode[2] == '1')
		if (ptIpcIntTxn->cF052Ind == FLAG_YES_C)
		{
			/*memcpy(&ptIpcIntTxn->sIssrInstResvd[0], ptIpcIntTxn->sPinData, F052_LEN);*/
			Hex2Str(ptIpcIntTxn->sPinData, &ptIpcIntTxn->sIssrInstResvd[0], F052_LEN);
			/*memset(&ptIpcIntTxn->sIssrInstResvd[F052_LEN], ' ', 16-F052_LEN);*/
			memcpy(&ptIpcIntTxn->sIssrInstResvd[16], "01", 2);		/*PIN BLOCK FORMAT*/
		}
	
	/* �ŵ���ʶ   */
	memcpy(&ptIpcIntTxn->sIssrInstResvd[18],"0",1);
	if (ptIpcIntTxn->sTrack1Data[0]!= ' ')
		memcpy(&ptIpcIntTxn->sIssrInstResvd[18],"1",1);
	if (ptIpcIntTxn->cF035Ind == FLAG_YES_C)
		memcpy(&ptIpcIntTxn->sIssrInstResvd[18],"2",1);
/*	if (ptIpcIntTxn->cF036Ind == FLAG_YES_C)
		memcpy(&ptIpcIntTxn->sIssrInstResvd[18],"3",1);*/
		
	/*������n-12*/
	
	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
	{
		case TXN_NUM_REVSAL:
		case TXN_NUM_CANCEL:
		case TXN_NUM_CANCEL_REVSAL:
			/*ԭ���ױ������ͣ����ڻ�ԭ����*/
		    memcpy(&ptIpcIntTxn->sIssrInstResvd[31], ptOrigTxn->req_buf, F000_MSG_TYPE_LEN);
			
			/*ԭ���״������룻���ڻ�ԭ����*/
			memcpy(&ptIpcIntTxn->sIssrInstResvd[35], ptOrigTxn->req_buf+4, F003_LEN);
			
			/*ԭ���׷�������ʱ�䣻���ڻ�ԭ����*/
			if(ptOrigTxn->misc_flag[0] != ' ' && ptOrigTxn->trans_date_time[0] != ' ')
			{
				memcpy(&ptIpcIntTxn->sIssrInstResvd[41],&ptOrigTxn->misc_flag[0],4);
				memcpy(&ptIpcIntTxn->sIssrInstResvd[41+4], ptOrigTxn->trans_date_time, F007_LEN);
			}
			else
			{
			    HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "cc txn get orig date error.");
		        return -1;
			}
	
			/*ԭ������ˮ�ţ����ڻ�ԭ����*/
            memcpy(&ptIpcIntTxn->sIssrInstResvd[55], ptOrigTxn->retrivl_ref, F037_LEN);
			break;
		default:
			break;
	}
	/*ǰ����ˮ��An-8*/
	
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sIssrInstResvd[%100.100s].", ptIpcIntTxn->sIssrInstResvd);
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}


/*********************************************************************************/
/* FUNC: int SetBDBSavingCard(T_IpcIntTxnDef *ptIpcIntTxn,Tbl_txn_Def *ptTxn,Tbl_txn_Def *ptOrigTxn)*/
/* INPUT:  ptIpcIntTxn: �ڲ�IPC��ṹ                                            */
/*         ptTxn:                                                                */
/* OUTPUT: ��                                                                    */
/* RETURN: 0: �ɹ�, -1: ����                                                     */
/* DESC:    ��䷢����ֵ���ı�������������                                       */
/*********************************************************************************/
int SetBDBSavingCard(T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn, Tbl_txn_Def *ptOrigTxn)
{
	char sFuncName[] = "SetBDBSavingCard";
	int		i;
	float	fAmtTrans=0.00;
	char	sAmtTrans[13+1];
	char    sss[1];
	char    sTemp[10];
	
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	
	/* ����sKeyRsp��sGfHeader�ı���λ��,������tbl_txn�еĽ��׼�¼ʹ��  */
	memcpy(ptIpcIntTxn->sGfHeader+190, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	
	memset(ptIpcIntTxn->sNationalSwResved,' ',F121_VAL_LEN);
	i = 0;
	/*���ͱ�ʶ1*/i += 1;
	/*TO������6*/i += 6;
	
#if 0
	memcpy(ptIpcIntTxn->sNationalSwResved+i,"99",2);	 /*FROM������6*/
	i += 2;
	if(ptIpcIntTxn->sAcqInstIdCode[0] != ' ')
		memcpy(ptIpcIntTxn->sNationalSwResved+i,ptIpcIntTxn->sAcqInstIdCode+4, 4);
	i += 4;
#endif
    
    if(ptIpcIntTxn->sAcqInstResvd[30] != ' ' && ptIpcIntTxn->sAcqInstResvd[30] != 0x00)
		memcpy(ptIpcIntTxn->sNationalSwResved+i,ptIpcIntTxn->sAcqInstResvd+30, 6);
    i += 6;
    
	/*ATM������5*/	i += 5;
	if(ptIpcIntTxn->sAcqInstIdCode[0] != ' ')
		memcpy(ptIpcIntTxn->sNationalSwResved+i,ptIpcIntTxn->sAcqInstIdCode+4, 4);/*������4*/
	i += 4;
	/*��Ȩ��8*/			i += 8;
	/*ATM���4*/		i += 4;
	/*��������8*/		i += 8;
	/*�����ʱ�1*/		i += 1;
	/*ԭ�����1*/		i += 1;
	/*�ͻ�������3*/	i += 3;
	/*��֧����1*/
	if(memcmp(ptIpcIntTxn->sTxnNum, "1255", 4) == 0)
		memcpy(ptIpcIntTxn->sNationalSwResved+i,"0", 1);
	else if(memcmp(ptIpcIntTxn->sTxnNum, "1365", 4) == 0)
		memcpy(ptIpcIntTxn->sNationalSwResved+i,"2", 1);
	else if(memcmp(ptIpcIntTxn->sTxnNum, "2365", 4) == 0)
		memcpy(ptIpcIntTxn->sNationalSwResved+i,"1", 1);
	else if(memcmp(ptIpcIntTxn->sTxnNum, "3365", 4) == 0)
		memcpy(ptIpcIntTxn->sNationalSwResved+i,"1", 1);
	else if(memcmp(ptIpcIntTxn->sTxnNum, "4365", 4) == 0)
		memcpy(ptIpcIntTxn->sNationalSwResved+i,"2", 1);
	else if(memcmp(ptIpcIntTxn->sTxnNum, "5365", 4) == 0)
		memcpy(ptIpcIntTxn->sNationalSwResved+i,"1", 1);
	i += 1;
	memcpy(ptIpcIntTxn->sNationalSwResved+i,ptIpcIntTxn->sMiscFlag,8);	 /*�������ڣ�������ϵͳ��8*/
	i += 8;
	/* ������ϵͳԭ�������� 8*/
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] != TXN_NUM_NORMAL)
		memcpy(ptIpcIntTxn->sNationalSwResved+i,ptOrigTxn->misc_flag, 8);
/*	else
		memcpy(ptIpcIntTxn->sNationalSwResved+i,ptIpcIntTxn->sMiscFlag,8);*/
	i += 8;

	if(ptIpcIntTxn->sAmtTrans[0] != ' ' && ptIpcIntTxn->sAmtTrans[0] !=  0)
	{
		/*memset(sAmtTrans,0x00,sizeof(sAmtTrans));
		fAmtTrans=atoi(ptIpcIntTxn->sAmtTrans)/100.00;
		sprintf(sAmtTrans,"%013.2f",fAmtTrans);
		memcpy(ptIpcIntTxn->sNationalSwResved+i,sAmtTrans,13);*/  /*���׽��13*/
		memcpy(ptIpcIntTxn->sNationalSwResved+i, "0", 1);
		i += 1;
		memcpy(ptIpcIntTxn->sNationalSwResved+i, ptIpcIntTxn->sAmtTrans, F004_LEN);  /*���׽��*/
		i += F004_LEN;
	}else
		i += 13;

	/*Filter1*/			i += 1;
	/*������ʶ1*/		i += 1;
	/*MAC VALUE 8*/	i += 8;
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sNationalSwResved[%-100.100s].", ptIpcIntTxn->sNationalSwResved);
	
	memset(ptIpcIntTxn->sIssrInstResvd,' ',F123_VAL_LEN);
	i = 0;
	memcpy(ptIpcIntTxn->sIssrInstResvd+i,ptIpcIntTxn->sTransmsnDateTime+4,6); /*������ϵͳ����ʱ��6*/
	i += 6;
	
	/* ������־->������1 */ /* ����1���ף���������俨�ţ���Ҫ��60.3�жϿ����� */ /* ����Ҫ�޸� */
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_NORMAL)
	{
	    if(memcmp(ptIpcIntTxn->sPosEntryModeCode, "05", 2) == 0 ||
	        memcmp(ptIpcIntTxn->sPosEntryModeCode, "07", 2) == 0 ||
	        memcmp(ptIpcIntTxn->sPosEntryModeCode, "95", 2) == 0 ||
	        memcmp(ptIpcIntTxn->sPosEntryModeCode, "96", 2) == 0 ||
	        memcmp(ptIpcIntTxn->sPosEntryModeCode, "97", 2) == 0 ||
	        memcmp(ptIpcIntTxn->sPosEntryModeCode, "98", 2) == 0)
	        memcpy(ptIpcIntTxn->sIssrInstResvd+i, "I", 1);
	    else
	        memcpy(ptIpcIntTxn->sIssrInstResvd+i, "C", 1);
	    
	    /* ����1��ʹ��F048�жϿ����� */
	    if(memcmp(ptIpcIntTxn->sTxnNum, "1915", 4) == 0)
	    {
	        if(memcmp(ptIpcIntTxn->sPosEntryModeCode, "01", 2) == 0)
	        {
	            if(ptIpcIntTxn->sAddtnlDataPrivate[0] == 0x00 ||
	                ptIpcIntTxn->sAddtnlDataPrivate[0] == ' ')
	            {
	                HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "����1����ǰ��û���Ϳ����� err.");
	                return -1;
	            }
	            if(ptIpcIntTxn->sAddtnlDataPrivate[0] == '1')
	                memcpy(ptIpcIntTxn->sIssrInstResvd+i, "C", 1);
	            else if(ptIpcIntTxn->sAddtnlDataPrivate[0] == '2')
	                memcpy(ptIpcIntTxn->sIssrInstResvd+i, "I", 1);
	        }
	    }
	}
	else
	{
	    if(memcmp(ptOrigTxn->pos_entry_mode, "05", 2) == 0 ||
	        memcmp(ptOrigTxn->pos_entry_mode, "07", 2) == 0 ||
	        memcmp(ptOrigTxn->pos_entry_mode, "95", 2) == 0 ||
	        memcmp(ptOrigTxn->pos_entry_mode, "96", 2) == 0 ||
	        memcmp(ptOrigTxn->pos_entry_mode, "97", 2) == 0 ||
	        memcmp(ptOrigTxn->pos_entry_mode, "98", 2) == 0)
	        memcpy(ptIpcIntTxn->sIssrInstResvd+i, "I", 1);
	    else
	        memcpy(ptIpcIntTxn->sIssrInstResvd+i, "C", 1);
	}
	i += 1;
	
	/* ���˺� - ����������Ϊԭ������ˮ������Ϊ�ɿ��ţ� */
	if(memcmp(ptIpcIntTxn->sTxnNum, "1925", 4) == 0)
	{
	    if(ptIpcIntTxn->cF048Ind != 'Y')
	    {
	        HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "��������ǰ��û���Ͼɿ��� err.");
	        return -1;
	    }
	    memset(sTemp, 0, sizeof(sTemp));
	    memcpy(sTemp, ptIpcIntTxn->sAddtnlDataPrivateLen, F048_LEN_LEN);
	    memcpy(ptIpcIntTxn->sIssrInstResvd+i, ptIpcIntTxn->sAddtnlDataPrivate, atoi(sTemp));
	    i += atoi(sTemp);
	    memset(ptIpcIntTxn->sIssrInstResvd+i,' ', 19-atoi(sTemp));
	    i += 19-atoi(sTemp);
	}
	else if(memcmp(ptIpcIntTxn->sTxnNum, "1393", 4) == 0 ||
	        memcmp(ptIpcIntTxn->sTxnNum, "1395", 4) == 0)
	{
	    memcpy(ptIpcIntTxn->sIssrInstResvd+i,ptTxn->rsp_buf, 19);
        i += 19;
	}
	else
	{
	    switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
	    {
	    	case TXN_NUM_REVSAL:
	    	case TXN_NUM_CANCEL:
	    	case TXN_NUM_CANCEL_REVSAL:
	    	case TXN_NUM_NOTICE:
	    	    memcpy(ptIpcIntTxn->sIssrInstResvd+i,ptOrigTxn->sys_seq_num, 6);
	    		i += 6;
	    		memset(ptIpcIntTxn->sIssrInstResvd+i,' ', 13);
	    		i += 13;
	    		break;
	    	default:
	    		i += 19;
	    		break;
	    }
	}

	/*����������4*/		i += 4;
	/*�ص��ۿ���4*/		i += 4;
	/*BATCH NUMBER5*/	i += 5;
	/*���ױ���3*/			i += 3;
	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
	{
		case TXN_NUM_REVSAL:
		case TXN_NUM_CANCEL:
		case TXN_NUM_CANCEL_REVSAL:
		case TXN_NUM_NOTICE:
			memcpy(ptIpcIntTxn->sIssrInstResvd+i,ptOrigTxn->retrivl_ref,F037_LEN);	/*ԭRTV.REF.NO.12*/
			break;
		default:
			break;
	}
	i += 12;
	/*TPDU5*/					i += 5;
	/*������8*/				i += 8;
	memcpy(ptIpcIntTxn->sIssrInstResvd+i,ptIpcIntTxn->sFldReserved+8, 2);/*��������2*/
	i += 2;

	if(ptIpcIntTxn->sAcqInstIdCode[0] != ' ')
		memcpy(ptIpcIntTxn->sIssrInstResvd+i,ptIpcIntTxn->sAcqInstIdCode+1, 7);/*���׵�����7*/
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sIssrInstResvd[%-100.100s].", ptIpcIntTxn->sIssrInstResvd);
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	
	return 0;
}

/*********************************************************************************/
/* FUNC:   int ReturnGet9F36 (T_IpcIntTxnDef *ptIpcIntTxn)                       */
/* INPUT:  ptIpcIntTxn: �ڲ�IPC��ṹ                                            */
/*                                                                               */
/* OUTPUT: ��                                                                    */
/* RETURN: 0: �ɹ�, -1: ����                                                     */
/* DESC:   ���󱨴�������Tag 9F36                                                */
/*********************************************************************************/
int ReturnGet9F36(T_IpcIntTxnDef *ptIpcIntTxn)
{
    char        sF055Len[F055_LEN_LEN+1], sF055Val[F055_LEN+1], sTagName[2+1];
    int         nReturnCode;
    int         iF055Len;
    
    memset(sF055Len, 0, sizeof(sF055Len));
    memcpy(sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
    iF055Len = atoi(sF055Len);
    
    /*9F36 ATC*/
    sTagName[0] = 0x9F;
    sTagName[1] = 0x36;
    sTagName[2] = 0x00;
    memset(sF055Val, 0, sizeof(sF055Val));
    nReturnCode = parse_tlv_data(sF055Val, sTagName, ptIpcIntTxn->sICData, iF055Len);
    if(nReturnCode > 0)
    {
        /*Hex2Str(sF055Val, tHsmOpr.saPIKChkV, 2);*/
        memset(ptIpcIntTxn->sICData, ' ', sizeof(F055_LEN));
        ptIpcIntTxn->sICData[0] = 0x9F;
        ptIpcIntTxn->sICData[1] = 0x36;
        ptIpcIntTxn->sICData[2] = 0x02;
        memcpy(&ptIpcIntTxn->sICData[3], sF055Val, 2);
        memcpy(ptIpcIntTxn->sICDataLen, "005", F055_LEN_LEN);
    }
    else
    {
        HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"Return get 9F36 ATC error, contine.");	
    }
    
    return 0;
}

/*********************************************************************************/
/* FUNC:   int SetCups (T_IpcIntTxnDef *ptIpcIntTxn,Tbl_txn_Def *ptOrigTxn)      */
/* INPUT:  ptIpcIntTxn: �ڲ�IPC��ṹ                                            */
/*         ptOrigTxn                                                             */
/* OUTPUT: ��                                                                    */
/* RETURN: 0: �ɹ�, -1: ����                                                     */
/* DESC:   ��䷢������ͳһ����Ķ�������                                        */
/*********************************************************************************/
int SetCups(T_IpcIntTxnDef *ptIpcIntTxn,Tbl_txn_Def *ptTxn, Tbl_txn_Def *ptOrigTxn)
{
	char sFuncName[] = "SetCups";
	char sTransAmt[15];
	char sAmt[15];
	char sCurrentTime[15];
	char sAmtTrans[13+1];
	int  i, nReturnCode;
	Tbl_sys_stat_Def tSysStat;

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    /* Ȧ�� */
    if(memcmp(ptIpcIntTxn->sTxnNum, "1385", 4) == 0 ||
        memcmp(ptIpcIntTxn->sTxnNum, "1383", 4) == 0 ||
        memcmp(ptIpcIntTxn->sTxnNum, "1395", 4) == 0 ||
        memcmp(ptIpcIntTxn->sTxnNum, "1393", 4) == 0)
    {
        /* F059 */
        i = 0;
        memset(ptIpcIntTxn->sF059Val, ' ', F059_VAL_LEN);
        
        /* ���� */
        if(ptIpcIntTxn->sPinData[0] != ' ' && ptIpcIntTxn->sPinData[0] != 0x00)
            Hex2Str(ptIpcIntTxn->sPinData, ptIpcIntTxn->sF059Val+i, 8);
        i += 16;
        
        /* ����2 */
        i += 16;
        
        /* LMK ����ֵ */
        i += 16;
        
        /* ZMK ����ֵ */
        i += 16;
        
        /* PINУ��ֵ */
        i += 8;
        
        /* MACУ��ֵ */
        i += 8;
        
        /* ���������� */
        i += 29;
        
        /* ����ϸ�� */
        memcpy(ptIpcIntTxn->sF059Val+i, "001", 3);
        i += 3;
        
        /* ������ */
        if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ)
            memcpy(ptIpcIntTxn->sF059Val+i, ptIpcIntTxn->sAcqInstResvd+30, 6);
        else
            memcpy(ptIpcIntTxn->sF059Val+i, ptIpcIntTxn->sHostSSN, 6);
        i += 6;
        
        /*������ */
        memcpy(ptIpcIntTxn->sF059Val+i, ptIpcIntTxn->sFwdInstIdCode, 6);
        i += 6;
        
        /* ת���������� */
        i += 4;
        
        /* ת���ʺ����� */
        memcpy(ptIpcIntTxn->sF059Val+i, "C", 1);
        i += 1;
        
        /* �ұ� [�����] */
        memcpy(ptIpcIntTxn->sF059Val+i, "01", 2);
        i += 3;
        
        /* ��ŵ���־ */
        memcpy(ptIpcIntTxn->sF059Val+i, "N", 1);
        if((ptIpcIntTxn->sTrack2Data[0] != ' ' && ptIpcIntTxn->sTrack2Data[0] != 0x00) || 
            (ptIpcIntTxn->sTrack3Data[0] != ' ' && ptIpcIntTxn->sTrack3Data[0] != 0x00))
        {
            memcpy(ptIpcIntTxn->sF059Val+i, "Y", 1);
        }
        i += 1;
        
        /* ���ܱ�׼ [2 - ��Χ��������] */
        memcpy(ptIpcIntTxn->sF059Val+i, "2", 1);
        i += 1;
        
        /* ���ܱ�־ */
        memcpy(ptIpcIntTxn->sF059Val+i, "N", 1);
        if(ptIpcIntTxn->sPinData[0] != ' ' && ptIpcIntTxn->sPinData[0] != 0x00)
            memcpy(ptIpcIntTxn->sF059Val+i, "Y", 1);
        i += 1;
        
        /* �������� [2 - У�鿨����] */
        memcpy(ptIpcIntTxn->sF059Val+i, "2", 1);
        i += 1;
        
        /* ��������ȡ��־ [0����] */
        memcpy(ptIpcIntTxn->sF059Val+i, "0", 1);
        i += 1;
        
        /* ��ȡ�����ѷ�ʽ [N - ����] */
        memcpy(ptIpcIntTxn->sF059Val+i, "N", 1);
        i += 1;
        
        /* �����ѽ�� */
        memset(ptIpcIntTxn->sF059Val+i, '0', 19);
        i += 19;
        
        /* ���׹�Ա�� */
        i += 4;
        
        /* ��Ȩ���� */
        i += 4;
        
        /* ��������(������ȡϵͳ���ڣ�������ȡF015) */
        memcpy(ptIpcIntTxn->sF059Val+i, ptIpcIntTxn->sMiscFlag+14+4+4, 8);
        i += 8;
        
		/* ժҪ���� */
        i += 3;
        
        /* ������ �����־ [1 - -�ֳ���] */
        memcpy(ptIpcIntTxn->sF059Val+i, "1", 1);
        i += 1;
        
        /* ���� */
        i += 100;
        
    }
    /* Ȧ����� */
    else if(memcmp(ptIpcIntTxn->sTxnNum, "2385", 4) == 0 ||
                memcmp(ptIpcIntTxn->sTxnNum, "2383", 4) == 0 ||
                memcmp(ptIpcIntTxn->sTxnNum, "2395", 4) == 0 ||
                memcmp(ptIpcIntTxn->sTxnNum, "2393", 4) == 0)
    {
        /* F059 */
        i = 0;
        memset(ptIpcIntTxn->sF059Val, ' ', F059_VAL_LEN);
        
        /* ԭ��Χ������ˮ�� */
        memcpy(ptIpcIntTxn->sF059Val+i,"00", 2);
        i += 2;
        memcpy(ptIpcIntTxn->sF059Val+i,ptOrigTxn->misc_flag, 14);
        i += 14;
        memcpy(ptIpcIntTxn->sF059Val+i,ptOrigTxn->sys_seq_num, 6);
        i += 6;
        
        /* ԭ��Χ�������� */
        memcpy(ptIpcIntTxn->sF059Val+i,ptOrigTxn->misc_flag, 8);
        i += 8;
        
        /* ԭ��Χ����ʱ�� */
        memcpy(ptIpcIntTxn->sF059Val+i,ptOrigTxn->misc_flag+8, 6);
        i += 6;
        
        /* ԭ���������� */
        memcpy(ptIpcIntTxn->sF059Val+i,"DEP605", 6);
        i += 6;
        
        /* ԭ����ϸ�� */
        memcpy(ptIpcIntTxn->sF059Val+i,"001", 3);
        i += 3;
        
        /* ������ */
        memcpy(ptIpcIntTxn->sF059Val+i, ptOrigTxn->rsp_buf+19+6, 6);
        i += 6;
        
        /* ������ */
        memcpy(ptIpcIntTxn->sF059Val+i, ptOrigTxn->rsp_buf+19, 6);
        i += 6;
        
        /* ת������ */
        memcpy(ptIpcIntTxn->sF059Val+i,ptOrigTxn->rsp_buf, 19);
        i += 19;
        
        /* ���׽�� */
        memset(ptIpcIntTxn->sF059Val+i,'0', 7);
        i += 7;
        memcpy(ptIpcIntTxn->sF059Val+i,ptOrigTxn->amt_trans, 12);
        i += 12;
        
        /* �ұ� */
        memcpy(ptIpcIntTxn->sF059Val+i, "01", 2);
        i += 3;
        
        /* ժҪ���� */
        i += 3;
        
        /* ��������(ԭȦ�潻���������ص���������) */
        memcpy(ptIpcIntTxn->sF059Val+i, ptOrigTxn->misc_flag+14+4+4, 8);
        i += 8;
        
        /* ���� */
        i += 256;
    }

    
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}
