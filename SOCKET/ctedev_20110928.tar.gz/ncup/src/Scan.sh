#!/usr/bin/ksh

################## argc config ###############################
SOURCE_DIR=$HOME/ncup/src
PDF_DIR=$SOURCE_DIR/CTEPDF

SPLINE=================================================================================================

DIR_LIST="\
hsmSrc
Common
ToCtl
SavFwd
SwtTDB
SwtBDT
Daemon
SwtBDB
PackSend
Bridge
Manage
HsmSrv
Cust
Comm/ComCups1
Comm/ComCup
Comm/ComCup2
Comm/ComCups2
Comm/ComPosp
Comm/CommCCT
Comm/CommCC
Comm/CommPCS
Comm/CommCon
Comm/CommCB
"

mkdir -p $PDF_DIR

cd $SOURCE_DIR

for DIR_NAME in $DIR_LIST; do
	if [ "a$DIR_NAME" = "a" ]; then
		continue
	fi
		
	echo "################################## starting scan $DIR_NAME ...#################################"
	cd $SOURCE_DIR/$DIR_NAME	
	FILE_NAME=`echo $DIR_NAME|awk -F "/" '{print $2}'`
	
	#�ж��Ƿ������Ŀ¼
	if [ "a$FILE_NAME" = "a" ]; then	
	   FILE_NAME=`echo $DIR_NAME|awk -F "/" '{print $1}'`	   
	fi
	
	rm -f *.o
	sourceanalyzer -Xmx600M -b $FILE_NAME make
	sourceanalyzer -Xmx600M -b $FILE_NAME -scan -f $FILE_NAME.fpr
	ReportGenerator -format pdf -f $FILE_NAME.pdf -source $FILE_NAME.fpr
	
	mv -f $FILE_NAME.pdf $PDF_DIR
	
	echo "################################## end scan $DIR_NAME ...#################################"
done

cd $SOURCE_DIR
find . -name "*.fpr" -exec rm -f {} \;

echo "############################### scan all success ###############################"

exit 0;
