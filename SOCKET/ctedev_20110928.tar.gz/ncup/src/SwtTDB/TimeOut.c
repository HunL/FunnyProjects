/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: TimeOut.c                                                   */
/* DESCRIPTIONS: handle time out msg from ToCtl                              */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-29  YU TONG        Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtTDB/TimeOut.c,v 1.1.1.1 2011/08/19 10:55:53 ctedev Exp $";

#include "SwtTDB.h"

/*****************************************************************************/
/* FUNC:   int HandleTimeOut (char *sMsgBuf)                                 */
/* INPUT:  �ַ���ָ��                                                        */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��������ToCtl�Ľ���                                               */
/*****************************************************************************/
int HandleTimeOut (char *sMsgBuf )
{
    char            sFuncName[] = "HandleTimeOut";
    char            sTxnNum[FLD_TXN_NUM_LEN+1];
    int             nReturnCode;
    int             nIndex;
    T_SwtToReqDef   tSwtToReq;
    Tbl_txn_Def     tTxn;
    T_IpcIntTxnDef  tSendIpcIntTxn, tSendIpcIntTxn1;

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memcpy ((char *)&tSwtToReq, sMsgBuf, sizeof (tSwtToReq));

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "time out txn: date: %10.10s  FE SSN: %6.6s",
            tSwtToReq.sTxnDate, tSwtToReq.sSysSeqNum);

    /****************************
     * ����tbl_txn�еĽ��׼�¼
     ****************************/
    /* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
    memset ((char *)&tTxn, 0, sizeof (tTxn));
    /*memcpy (tTxn.date_local_trans, tSwtToReq.sTxnDate, FLD_DATE_LEN); */
    memcpy (tTxn.trans_date_time, tSwtToReq.sTxnDate, F007_LEN);
    memcpy (tTxn.sys_seq_num, tSwtToReq.sSysSeqNum, FLD_SYS_SEQ_NUM_LEN);

    /* �����ݿ��в���ԭ������ */
    /* DBS_SELECT1: F007, FE SSN */
    nReturnCode = DbsTxn (DBS_SELECT1, &tTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn select error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    

    nReturnCode = MoveTxn2Ipc (&tTxn, &tSendIpcIntTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    nReturnCode = GetTxnInfoIndex( tSendIpcIntTxn.sMsgSrcId, tSendIpcIntTxn.sTxnNum, &nIndex );
    if ( nReturnCode != 0 )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetTxnInfoIndex error. Discard this message.");
        return -1;
    }

    /* ����Ӧ���״��� */
    memcpy( tSendIpcIntTxn.sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
    /* ���Ĵ���Ӧ���� */
    memcpy( tSendIpcIntTxn.sRespCode, F039_TIME_OUT, F039_LEN );

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (&tSendIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* �ָ�ԭ���״��룬������Ľ��״��� */
    memcpy( tSendIpcIntTxn.sTxnNum, gatTxnInf[nIndex].txn_num, FLD_TXN_NUM_LEN );

    /***************
     * ��¼���ݿ�
     ****************/
    if (!memcmp (tTxn.trans_state, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN))
        memcpy (tTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN);
    else
    {
        if (!memcmp (tTxn.trans_state, TRANS_STATE_NO_ACCT_RSP, FLD_TRANS_STATE_LEN))
            memcpy (tTxn.trans_state, TRANS_STATE_ACCT_TO, FLD_TRANS_STATE_LEN);
    }

    DbsBegin ();

    nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn update error, %d. Discard this message.", nReturnCode);

        return -1;
    }

    DbsCommit ();
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tSendIpcIntTxn.sMisc+42=[%12.12s].", tSendIpcIntTxn.sMisc+42);
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "tSendIpcIntTxn.sTermSSN=[%12.12s].", tSendIpcIntTxn.sTermSSN);


    /***************
     * ���ͳ�ʱʧ��Ӧ��
     ****************/
    memcpy ((char *)&tSendIpcIntTxn1, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn1));
    /* ����Ӧ���״��� */
    memcpy( tSendIpcIntTxn1.sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
    /*������Ϣ����*/
    tSendIpcIntTxn1.sMsgType[2] ++;
    /* ����Ӧ��SrvId */
    memcpy( tSendIpcIntTxn1.sMsgDestId, tSendIpcIntTxn.sMsgSrcId, SRV_ID_LEN );
    /* clear F090 */
    memset (tSendIpcIntTxn1.sOrigDataElemts, ' ', F090_LEN);
    
    nReturnCode = SendMsg (&tSendIpcIntTxn1, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
    }
    
    /* ����ѯ�ཻ�ס��ֽ��ֵ�������� */
    if(memcmp(tTxn.txn_num, "1253", 4) == 0 ||
        memcmp(tTxn.txn_num, "1203", 4) == 0 ||
        memcmp(tTxn.txn_num, "1373", 4) == 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "txn_num [%-4.4s], no need to send revsal. Discard this message.", tTxn.txn_num);
        return -1;
    }
    
    /* ָ���˻�Ȧ���ѯ�������� */
    if(memcmp( tTxn.misc_flag+14, "1283", 4 ) == 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "txn_num [%-4.4s], no need to send revsal. Discard this message.", tTxn.misc_flag+14);
        return -1;
    }

    /***************
     * ���ͳ�ʱ����
     ****************/
    nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nIndex, REASON_CODE_TIME_OUT);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
    }

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    return 0;
}
