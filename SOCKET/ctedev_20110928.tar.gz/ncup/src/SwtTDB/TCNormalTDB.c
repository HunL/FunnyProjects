/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Normal.c                                                    */
/* DESCRIPTIONS: handle normal req from CUP and its rsp from host            */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtTDB/TCNormalTDB.c,v 1.2.2.10 2011/09/23 02:54:35 ctedev Exp $";

#include "SwtTDB.h"

int TCHandleTDBNormalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
	char			sFuncName[] = "TCHandleTDBNormalReq";
	char			sRespCode[F039_LEN+1];
	char			sMsgBuf[MSQ_MSG_SIZE_MAX];
	int				nReturnCode;
	int				nLineStat;
	int				nMsgLen;
	int				nTxnSelOpr;
	T_SwtToReqDef	tSwtToReq;
	Tbl_txn_Def		tTxn;
	T_IpcIntTxnDef	tSendIpcIntTxn;

	T_IpcIntTxnDef	tIpcIntTxn;
	long            lBeginTime, lEndTime;
	struct tms		tTMS;
	char            sCurrentDate[14+1];
	char            sTickLog[128] = {0};
       
    sprintf (sTickLog, "SwtTDB.Ticks.%s.log", gsSrvSeqId);
	
    
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	
	if (nIndex < 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sMsgSrcId);
		return -1;
	}
	
	/***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    SetToTime(nIndex);
    memcpy(sCurrentDate, gsTimeCurTs, 14);
    memcpy(ptIpcIntTxn->sMiscFlag, sCurrentDate, 14);
	
	/* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
		"TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %6.6s\n", 
		gatTxnInf[nIndex].txn_num, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans, 
		ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, ptIpcIntTxn->sSysTraceAuditNum);
	
	/* sMisc�м�¼ǰ��ʱ��,ǰ����ˮ */
    memcpy(ptIpcIntTxn->sMisc, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
    memcpy(ptIpcIntTxn->sMisc+F007_LEN, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
    
	/*******************
	* �жϸý����Ƿ�֧��
	********************/		
	if (memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) ||
	    !memcmp(ptIpcIntTxn->sMAC064, "-99", 3))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
		/* ����Ӧ���״��� */
		memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
		/* ����Ӧ��SrvId */
		memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
		/* ���Ĵ���Ӧ���� */
		memcpy( ptIpcIntTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );	
		/* ����Ӧ�� msg type */
		ptIpcIntTxn->sMsgType[2]++;
		ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		ptIpcIntTxn->cICDataInd = 'N';
        
		nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);
		
		HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
		    
		return -1;
	}

#if 0
	/***************
	* ������ˮ��
	****************/
	memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
	tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
	if (tSwtToReq.nToCtlTime > 0)
		tSwtToReq.nTransCode = TOCTL_NORMAL_FIRST;
	else
		tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
	memcpy (tSwtToReq.sTxnDate, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
	
	nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq,ptIpcIntTxn );
	if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"ToCtrlReq error, %d. Discard this transaction.", nReturnCode);
		return -1;
	}

	/* save ssn in ipc */
	memcpy (ptIpcIntTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
#endif

    memcpy (ptIpcIntTxn->sSysSeqNum, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);

	/* ��key_rsp, key_revsal, key_cancel��ֵ */
	nReturnCode = SetKeyRsp (ptIpcIntTxn);
	nReturnCode = SetKeyRevsal (ptIpcIntTxn);
	nReturnCode = SetKeyCancel (ptIpcIntTxn);

	/***********************
	* ��֯��¼���ݿ��¼�ṹ
	************************/
	nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
	if( nReturnCode )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"MoveIpc2Txn error, %d. Discard this transaction.", nReturnCode);
			
		return -1;
	}
	

 	/***************
	* У��MAC
	****************/
	lBeginTime = times( &tTMS);
	if(gsMacFlag[0] == FLAG_YES_C)
	{
	    nReturnCode = VerifyMAC1 (ptIpcIntTxn );
	    if (nReturnCode != 0 )
	    {
	    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	    		"VerifyMAC error, %d. Reject this transaction with %s.", nReturnCode, F039_MAC_FAIL);
        
	    	/* ����Ӧ���״��� */
	    	memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
	    	/* ����Ӧ��SrvId */
	    	memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
	    	/* ���Ĵ���Ӧ���� */
	    	memcpy( ptIpcIntTxn->sRespCode, F039_MAC_FAIL, F039_LEN );	
	    	/* ����Ӧ�� msg type */
	    	ptIpcIntTxn->sMsgType[2]++;
	    	/*memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);*/
                    
	    	nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
	    	
	    	HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
	    
	    	/* save this txn in Db */
	    	DbsBegin ();
	    	memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
	    	memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
	    	nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
	    	if (nReturnCode)
	    		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
	    	DbsCommit ();
	    
	    	return -1;
	    }
	}
	lEndTime = times( &tTMS);
    HtLog (sTickLog, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "VerifyMAC1, used %ld ticks",lEndTime - lBeginTime);

	/***************
	* ת��PIN
	****************/
	lBeginTime = times( &tTMS);
	if (gatTxnInf[nIndex].pin_flag[0] == FLAG_YES_C)
	{
		nReturnCode = TransferPin (ptIpcIntTxn );
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"TransferPin error, %d. Reject this transaction with %s.", nReturnCode, F039_PIN_ERROR);
	
			/* ����Ӧ���״��� */
			memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
			/* ����Ӧ��SrvId */
			memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
			/* ���Ĵ���Ӧ���� */
			memcpy( ptIpcIntTxn->sRespCode, F039_PIN_ERROR, F039_LEN );	
			/* ����Ӧ�� msg type */
			ptIpcIntTxn->sMsgType[2]++;
			/*memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);*/
                        
			nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
			
			HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
		
			/* save this txn in Db */
			DbsBegin ();
			memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
			memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
			nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
			if (nReturnCode)
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
			DbsCommit ();
		
			return -1;
		}				
		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, ptIpcIntTxn->sSecRelatdCtrlInfo,16) ; 

	}
	lEndTime = times( &tTMS);
    HtLog (sTickLog, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "TransferPin, used %ld ticks",lEndTime - lBeginTime);

	/*********************
	* �ͻ������ݿ��¼�ṹ
	**********************/
	nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SwtCustBeforeTblTxnOpr error, %d. Continue this transaction.", nReturnCode);
	}
	
	DbsBegin ();
	
	/***************
	* ��¼���ݿ�
	****************/
	lBeginTime = times( &tTMS);
	nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
	if (nReturnCode )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn insert error, %d. Discard this transaction.", nReturnCode);
		return -1;
	}

	DbsCommit ();
	lEndTime = times( &tTMS);
    HtLog (sTickLog, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "DbsTxn DBS_INSERT, used %ld ticks",lEndTime - lBeginTime);
	
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");	

	/***********************
	*  �ͻ���Ŀ��IPC��������
	************************/
	lBeginTime = times( &tTMS);
	memcpy ((char *)&tSendIpcIntTxn, (char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn));
	memcpy( tSendIpcIntTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );
	nReturnCode = SendMsg (&tSendIpcIntTxn, &tTxn, NULL);
	if (nReturnCode)
	{
	    /* ����MAC����·�쳣�ı��� */
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SendMsg error, %d. Discard this transaction.", nReturnCode);

		return -1;
	}
	lEndTime = times( &tTMS);
    HtLog (sTickLog, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "SendMsg, used %ld ticks",lEndTime - lBeginTime);
	
	HtLog(	gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	
	return 0;
}

int TCHandleTDBNormalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
	char			sFuncName[] = "TCHandleTDBNormalRsp";
	char			sMsgSrcId[SRV_ID_LEN+1];
	char			sMsgBuf[MSQ_MSG_SIZE_MAX];
	int				nReturnCode;
	int				nLineStat;
	int				nTxnSelOpr;
	int				nMsgLen;
	int				nSendRevsalFlag;
	int				nSendRspFlag;
	int				nReqIndex;
	char                        sTxnNum[4+1];
	T_SwtToReqDef	tSwtToReq;
	Tbl_txn_Def		tTxn;
	T_IpcIntTxnDef	tSendIpcIntTxn, tSendIpcInt2;

	T_IpcIntTxnDef	tIpcIntTxn;
	long            lBeginTime, lEndTime;
	struct tms		tTMS;
	char	sTemp[20];
	int     iMacResult;
	char            sTickLog[128] = {0};
	
	sprintf (sTickLog, "SwtTDB.Ticks.%s.log", gsSrvSeqId);
	
	memset( sTxnNum , 0 , sizeof(sTxnNum));
    memcpy( sTxnNum, ptIpcIntTxn->sTxnNum, 4 );
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    SetToTime(-1);
    
    /* ת��Ӧ���� */
	SwtCustTransferRspCode(ptIpcIntTxn);

	/* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
	memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
	memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
	
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
		"TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  host SSN: %12.12s\n  response code: %2.2s", 
		ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans, 
		ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, 
		ptIpcIntTxn->sSysTraceAuditNum, ptIpcIntTxn->sHostSSN, ptIpcIntTxn->sRespCode);
	
	/***************
	* У��MAC
	****************/
	lBeginTime = times( &tTMS);
	iMacResult = 0;
	if(gsMacFlag[0] == FLAG_YES_C)
	{
	    if(memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) != 0)
	    {
	        nReturnCode = VerifyMAC (ptIpcIntTxn );
	        if (nReturnCode != 0 )
	        {
	            iMacResult = 1;
	        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	        		"VerifyMAC error, %d. Discard this message.", nReturnCode);
	        }
	    }
	}
	lEndTime = times( &tTMS);
    HtLog (sTickLog, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "RSP VerifyMAC, used %ld ticks",lEndTime - lBeginTime);

	/****************************
	* ����tbl_txn�еĽ��׼�¼
	****************************/
	/* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
	nReturnCode = SetKeyRsp (ptIpcIntTxn);

	memset ((char *)&tTxn, 0, sizeof (tTxn));
	memcpy (tTxn.key_rsp, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	memcpy (tTxn.txn_num, ptIpcIntTxn->sTxnNum, FLD_TXN_NUM_LEN);
	tTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
	/* �����ݿ��в���ԭ������ */
	/* DBS_SELECT21: txn_num, key_rsp */
	lBeginTime = times( &tTMS);
	nReturnCode = DbsTxn (DBS_SELECT21, &tTxn);	
	if (nReturnCode)
	{
		tTxn.key_rsp[KEY_RSP_LEN] = 0;
		tTxn.txn_num[FLD_TXN_NUM_LEN] = 0;
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn select error, %d. txn_num=%s,key_rsp=%s. Discard this message.", nReturnCode,tTxn.txn_num,tTxn.key_rsp);
		return -1;
	}
	lEndTime = times( &tTMS);
    HtLog (sTickLog, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "RSP DbsTxn DBS_SELECT21, used %ld ticks",lEndTime - lBeginTime);

	/***********************
	* ���ҽ���������gatTxnInf�е�����
	************************/
	nReturnCode = GetTxnInfoIndex (tTxn.msg_src_id, tTxn.txn_num, &nReqIndex );
	if (nReturnCode || nReqIndex < 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
		return -1;
	}
	
	/***********************
	* ���ô����쳣ʱ�Ƿ�Ҫ���ͳ���
	************************/
	if (IsRspSuccess (ptIpcIntTxn->sRespCode) )
		nSendRevsalFlag = 1;
	else
		nSendRevsalFlag = 0;
	
	/***********************
	* ��֯��¼���ݿ��¼�ṹ
	************************/	
	nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
	if( nReturnCode )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
		return -1;
	}
	
	/*********************
	* �ͻ������ݿ��¼�ṹ
	**********************/
	nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SwtCustBeforeTblTxnOpr error, %d. Continue this message.", nReturnCode);
	}
	
 	/* ��tTxn���浽tSendIpcIntTxn, ������Ӧ����ʹ�� */	
	nReturnCode = MoveTxn2Ipc (&tTxn, &tSendIpcIntTxn);
	if( nReturnCode )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
		return -1;
	}

    /* ת����Ӧ�������14��ʹ�÷�����Ӧ���е�14�� */
	if (ptIpcIntTxn->cF014Ind == FLAG_YES_C)
	{
		tSendIpcIntTxn.cF014Ind = FLAG_YES_C;
		memcpy (tSendIpcIntTxn.sDateExpr, ptIpcIntTxn->sDateExpr, F014_LEN);		
	}
	else
		tSendIpcIntTxn.cF014Ind = FLAG_NO_C;
		
	/* ת����Ӧ�������38��ʹ�÷�����Ӧ���е�38�� */
	if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
	{
		tSendIpcIntTxn.cF038Ind = FLAG_YES_C;
		memcpy (tSendIpcIntTxn.sAuthrIdResp, ptIpcIntTxn->sAuthrIdResp, F038_LEN);
	}
	else
		tSendIpcIntTxn.cF038Ind = FLAG_NO_C;
	
	/*ת��Ӧ�������57��ʹ�÷�����Ӧ���е�57��*/
	if(ptIpcIntTxn->sAddtnlData[0] != ' ' && ptIpcIntTxn->sAddtnlData[0] != 0x00)
	{
		strncpy(tSendIpcIntTxn.sAddtnlDataLen ,  ptIpcIntTxn->sAddtnlDataLen,3);
		strncpy(tSendIpcIntTxn.sAddtnlData ,  ptIpcIntTxn->sAddtnlData,atoi(ptIpcIntTxn->sAddtnlDataLen) );
	}
	
	/*ת��Ӧ�������61��ʹ�÷�����Ӧ���е�61�� ������ʹ�������61��*/
	if(ptIpcIntTxn->cF061Ind == 'Y')
	{
	    tSendIpcIntTxn.cF061Ind = 'Y';
	    memcpy(tSendIpcIntTxn.sChAuthInfoLen, ptIpcIntTxn->sChAuthInfoLen, F061_LEN_LEN);
	    memset(sTemp, 0, sizeof(sTemp));
	    memcpy(sTemp, ptIpcIntTxn->sChAuthInfoLen, F061_LEN_LEN);
	    memcpy(tSendIpcIntTxn.sChAuthInfo, ptIpcIntTxn->sChAuthInfo, atoi(sTemp));
	}
	
	/*ת��Ӧ�������123��ʹ�÷�����Ӧ���е�123��*/
	if(ptIpcIntTxn->cF123Ind == 'Y')
	{
	    tSendIpcIntTxn.cF123Ind = 'Y';
	    memcpy(tSendIpcIntTxn.sIssrInstResvdLen, ptIpcIntTxn->sIssrInstResvdLen, F123_LEN_LEN);
	    memset(sTemp, 0, sizeof(sTemp));
	    memcpy(sTemp, ptIpcIntTxn->sIssrInstResvdLen, F123_LEN_LEN);
	    memcpy(tSendIpcIntTxn.sIssrInstResvd, ptIpcIntTxn->sIssrInstResvd, atoi(sTemp));
	}

#if 0
	/***************
	* ��齻���Ƿ�ʱ
	****************/
	memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
	tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
	tSwtToReq.nToCtlTime = atoi (gatTxnInf[nReqIndex].msg_to );
	memcpy (tSwtToReq.sTxnDate, tTxn.trans_date_time, F007_LEN);
	memcpy (tSwtToReq.sSysSeqNum, tTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN );
	tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;
	nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq ,ptIpcIntTxn);
	if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"ToCtrlReq error, %d. Discard this message.", nReturnCode);
		return -1;
	}
#endif
	/* ���ײ���ʱ */
	tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;
	
        /* set trans state if reply is not time out */
	if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_TO)
	{
		if (IsRspSuccess (ptIpcIntTxn->sRespCode))
			memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
		else
			memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
	}
	
	if(iMacResult)
	{
	    memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
	    memcpy (tTxn.resp_code, F039_MAC_FAIL, 2);
	}
	
	DbsBegin ();
	
	/***************
	* ��¼���ݿ�
	****************/
	lBeginTime = times( &tTMS);
	nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
	if (nReturnCode )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn update error, %d. Continue this message.", nReturnCode);
	}
	else
	    DbsCommit ();
	    
	if(iMacResult)
	    return -1;
	    
	lEndTime = times( &tTMS);
    HtLog (sTickLog, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "RSP DbsTxn DBS_UPDATE1, used %ld ticks",lEndTime - lBeginTime);   
    
    if(gsMacFlag[0] == FLAG_YES_C)
    {
        /* ����ͳһ����A0����������96 */
        if(memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) == 0)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                     "CUP return [%2.2s], respone 96", ptIpcIntTxn->sRespCode);
            memcpy(tSendIpcIntTxn.sRespCode, "96", F039_LEN);
        }
    }
	
	if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_HAD_TO)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"lgm nSendRevsalFlag [%d]",nSendRevsalFlag);
		/* ��ʱӦ�� */
		/* send reversal on late success reply */
		if (nSendRevsalFlag)
		{		
			nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_LATE_RSP);
			if (nReturnCode)
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
			}
		}
	}
	else
	{
		/***********************
		* Ӧ��δ��ʱ, ת��Ӧ��
		************************/
		/* �ͻ���Ŀ��IPC�������� */
		memcpy ((char *)&tSendIpcInt2, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
		
		/* ����Ӧ���״��� */
		memcpy( tSendIpcInt2.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
	
		/* ����Ӧ��SrvId */
		
		/*memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );*/
		memcpy( tSendIpcInt2.sMsgDestId, tTxn.msg_src_id, SRV_ID_LEN );
		
		/* ����Ӧ�� msg type */
		tSendIpcInt2.sMsgType[2]++;

		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,  __LINE__, (char*)&tSendIpcInt2, sizeof(tSendIpcInt2));
	    
	    lBeginTime = times( &tTMS);
		nReturnCode = SendMsg (&tSendIpcInt2, &tTxn, NULL);
		if (nReturnCode)
		{
		    /* ����MAC����·�쳣�ı��� */
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"SendMsg error, %d. Discard this message.", nReturnCode);

			return -1;
		}
		
		HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "R %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
		    
		HtLog(	gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");	
		lEndTime = times( &tTMS);
        HtLog (sTickLog, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "RSP SendMsg, used %ld ticks",lEndTime - lBeginTime);   	
	}
	
	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	
	return 0;
}
