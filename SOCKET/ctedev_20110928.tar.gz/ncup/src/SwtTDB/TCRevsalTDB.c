/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Revsal.c                                                    */
/* DESCRIPTIONS: handle reversal req its rsp                                 */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-29  YU TONG        Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtTDB/TCRevsalTDB.c,v 1.2.2.6 2011/09/23 02:54:35 ctedev Exp $";

#include "SwtTDB.h"

int TCHandleTDBRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
	char			sFuncName[] = "TCHandleTDBRevsalReq";
	char			sRespCode[F039_LEN+1];
	char			sTxnNum[FLD_TXN_NUM_LEN+1];
	int				nReturnCode;
	int				i;
	int				nRevsalIndex;
	int				nSendRspFlag;
	T_SwtToReqDef	tSwtToReq;
	Tbl_txn_Def		tTxn, tOrigTxn;
	T_IpcIntTxnDef	tSendIpcIntTxn, tSendIpcIntTxn1;
	char            sCurrentDate[14+1];
	
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	if (nIndex < 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sMsgSrcId);
		return -1;
	}
	
	/***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    SetToTime(nIndex);
    memcpy(sCurrentDate, gsTimeCurTs, 14);
    memcpy(ptIpcIntTxn->sMiscFlag, sCurrentDate, 14);
	
	/* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
		"TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %6.6s\n  orig data elem: %42.42s\n", 
		gatTxnInf[nIndex].txn_num, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans, 
		ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, ptIpcIntTxn->sSysTraceAuditNum,
		ptIpcIntTxn->sOrigDataElemts);
	
	/* sMisc�м�¼ǰ��ʱ��,ǰ����ˮ */
    memcpy(ptIpcIntTxn->sMisc, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
    memcpy(ptIpcIntTxn->sMisc+F007_LEN, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
    
	nSendRspFlag = 1;
	if (!memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) )
	{
		/* no need to send reversal response for time out reversal or late response reversal */
		nSendRspFlag = 0;
	}
		
	/*******************
	* �жϸý����Ƿ�֧��
	********************/
	if ((nSendRspFlag && memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1)) ||
	    !memcmp(ptIpcIntTxn->sMAC064, "-99", 3))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
		/* ����Ӧ���״��� */
		memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
		/* ����Ӧ��SrvId */
		memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
		/* ���Ĵ���Ӧ���� */
		memcpy( ptIpcIntTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );	
		/* ����Ӧ�� msg type */
		ptIpcIntTxn->sMsgType[2]++;
		ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		ptIpcIntTxn->cICDataInd = 'N';
        
		nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);
		
		HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
		    
		return -1;
	}

#if 0
	/***************
	* ������ˮ��
	****************/
	memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
	tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
	tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
	memcpy (tSwtToReq.sTxnDate, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
	nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq,ptIpcIntTxn );
	if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"ToCtrlReq error, %d.", nReturnCode);
		/* do not send response for this failure, wait for resend of this reversal */
		return -1;
	}
	/* save ssn in ipc */
	memcpy (ptIpcIntTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
	if (!nSendRspFlag)
		memcpy(ptIpcIntTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);
#endif
    
    memcpy (ptIpcIntTxn->sSysSeqNum, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
    
	/* ��key_rsp, key_revsal��ֵ */
	nReturnCode = SetKeyRevsal (ptIpcIntTxn);
	nReturnCode = SetKeyRsp (ptIpcIntTxn);
	
	/***********************
	* ��֯��¼���ݿ��¼�ṹ
	************************/
	nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
	if( nReturnCode )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"MoveIpc2Txn error, %d, Discard this transaction.", nReturnCode);
		/* do not send response for this failure, wait for resend of this reversal */
	
		return -1;
	}

	/***************
	* У��MAC
	****************/
	if(gsMacFlag[0] == FLAG_YES_C)
	{
	    if (nSendRspFlag)
	    {
	    	nReturnCode = VerifyMAC1 (ptIpcIntTxn );
	    	if (nReturnCode != 0 )
	    	{
	    		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	    			"VerifyMAC error, %d. Reject this transaction with %s.", nReturnCode, F039_MAC_FAIL);
        	
	    		/* ����Ӧ���״��� */
	    		memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
	    		/* ����Ӧ��SrvId */
	    		memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
	    		/* ���Ĵ���Ӧ���� */
	    		memcpy( ptIpcIntTxn->sRespCode, F039_MAC_FAIL, F039_LEN );	
	    		/* ����Ӧ�� msg type */
	    		ptIpcIntTxn->sMsgType[2]++;
	    		/* clear F038 */
	    		ptIpcIntTxn->cF038Ind = FLAG_NO_C;
	    		/* clear F090 */
	    		memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
	    		nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
	    		
	    		HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		        "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		        ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		        ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		        ptIpcIntTxn->sAcqInstIdCode,
		        ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
	    	
	    		/* save this txn in Db */
	    		DbsBegin ();
	    		memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
	    		memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
	    		nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
	    		if (nReturnCode)
	    			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
	    		DbsCommit ();
	    	
	    		return -1;
	    	}
	    }
	}

	/***************
	* �������׵������жϴ���
	****************/
	memset ((char *)&tOrigTxn, 0, sizeof (tOrigTxn));
	memcpy ((char *)&tOrigTxn, (char *)&tTxn, sizeof (tTxn));
    
    tOrigTxn.txn_num[INDEX_TXN_NUM_TYPE] --;
    
    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"DbsTxn select22  txn_num=%4.4s,key_revsal=%32.32s.",
			tOrigTxn.txn_num, tOrigTxn.key_revsal);
			
    nReturnCode = DbsTxn (DBS_SELECT22, &tOrigTxn );
    if(!nReturnCode)
    {
        /* save original fe ssn in revsal_ssn */
		memcpy (tTxn.revsal_ssn, tOrigTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
	}


	/*********************
	* �ͻ������ݿ��¼�ṹ
	**********************/
	nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, &tOrigTxn);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SwtCustBeforeTblTxnOpr error, %d. Continue this transaction.", nReturnCode);
		/* do not send response for this failure, wait for resend of this reversal */
	}
	
	/* �Գ�ʱ�����Ľ�����Դ�������ΪSwitch, ʹ��ԭʼ���׵Ľ�����Դ�� */
	/*memcpy (tTxn.msg_src_id, tOrigTxn.msg_src_id, SRV_ID_LEN);*/
	
	DbsBegin ();
	
	/***************
	* ��¼���ݿ�
	****************/
	nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
	if (nReturnCode )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn insert error, %d. Discard this transaction.", nReturnCode);
		/* do not send response for this failure, wait for resend of this reversal */

		return -1;
	}
	
	DbsCommit ();
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");

    DbsBegin ();
	/***************
	* �������ݿ�ԭʼ���׼�¼
	****************/
	memset (tOrigTxn.revsal_flag, REV_CAN_FLAG_HAD, 1);
	memcpy (tOrigTxn.revsal_ssn, tTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
	nReturnCode = DbsTxn (DBS_UPDATE2, &tOrigTxn );
	if( nReturnCode != 0 )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn update error, %d. txn_num[%-04.04s] key_revsal[%-32.32s], Continue this transaction.", nReturnCode, tOrigTxn.txn_num ,tOrigTxn.key_revsal);
		/* do not send response for this failure, wait for resend of this reversal */
	}
	else
	    DbsCommit ();
	
	/***********************
	*  ת��������
	************************/	
	memcpy ((char *)&tSendIpcIntTxn, (char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn));	
	
	/***********************
	*  ת��������
	************************/

	/* send reversal to dest 1 */
	memcpy ((char *)&tSendIpcIntTxn1, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
	memcpy( tSendIpcIntTxn1.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );

	nReturnCode = SendMsg (&tSendIpcIntTxn1, &tTxn, &tOrigTxn);
	if (nReturnCode)
	{
	    /* ����MAC����·�쳣�ı��� */
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d. Discard this transaction.", nReturnCode);
		return -1;
	}
	
	HtLog(	gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	
	return 0;
}

int TCHandleTDBRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
	char			sFuncName[] = "TCHandleTDBRevsalRsp";
	char			sMsgSrcId[SRV_ID_LEN+1];
	int				nReturnCode;
	int				nTxnSelOpr;
	int				nReqIndex;
	Tbl_txn_Def		tTxn, tOrigTxn;
	T_IpcIntTxnDef	tSendIpcIntTxn, tSendIpcInt2;
	char	sTemp[20];
	int     iMacResult;
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	
	SetToTime(-1);
	
	/* ת��Ӧ���� */
	SwtCustTransferRspCode(ptIpcIntTxn);
		
	/* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
	memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
	memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
	
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
		"TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  host SSN: %12.12s\n  response code: %2.2s", 
		ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans, 
		ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, 
		ptIpcIntTxn->sSysTraceAuditNum, ptIpcIntTxn->sHostSSN, ptIpcIntTxn->sRespCode);

	/***************
	* У��MAC
	****************/
	iMacResult = 0;
	if(gsMacFlag[0] == FLAG_YES_C)
	{
	    if(memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) != 0)
	    {
	        nReturnCode = VerifyMAC (ptIpcIntTxn );
	        if (nReturnCode != 0 )
	        {
	            iMacResult = 1;
	        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	        		"VerifyMAC error, %d. Discard this message.", nReturnCode);
	        }
	    }
	}
	
	/****************************
	* ����tbl_txn�еĽ��׼�¼
	****************************/
	nReturnCode = SetKeyRsp (ptIpcIntTxn);
		
	/* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
	memset ((char *)&tTxn, 0, sizeof (tTxn));
	memcpy (tTxn.key_rsp, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	memcpy (tTxn.txn_num, ptIpcIntTxn->sTxnNum, FLD_TXN_NUM_LEN);
	tTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
	/* �����ݿ��в���ԭ������ */
	nReturnCode = DbsTxn (DBS_SELECT21, &tTxn);
	if (nReturnCode)
	{
	    tTxn.key_rsp[KEY_RSP_LEN] = 0;
		tTxn.txn_num[FLD_TXN_NUM_LEN] = 0;
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn select error, %d. txn_num=%s,key_rsp=%s. Discard this message.", nReturnCode,tTxn.txn_num,tTxn.key_rsp);
		return -1;
	}
	
	/***********************
	* ���ҽ���������gatTxnInf�е�����
	************************/
	nReturnCode = GetTxnInfoIndex (tTxn.msg_src_id, tTxn.txn_num, &nReqIndex );
	if (nReturnCode || nReqIndex < 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
		return -1;
	}

	/***********************
	* ��֯��¼���ݿ��¼�ṹ
	************************/
	nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
	if( nReturnCode )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
		return -1;
	}
	
	/*********************
	* �ͻ������ݿ��¼�ṹ
	**********************/
	nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SwtCustBeforeTblTxnOpr error, %d. Continue this message.", nReturnCode);
	}
	
	/* ��tTxn���浽tSendIpcIntTxn, ������Ӧ����ʹ�� */
	nReturnCode = MoveTxn2Ipc (&tTxn, &tSendIpcIntTxn);
	if( nReturnCode )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
		return -1;
	}
	
	/* ת����Ӧ�������28��ʹ�÷�����Ӧ���е�28�� */
	if (ptIpcIntTxn->cF028Ind == FLAG_YES_C)
	{
		tSendIpcIntTxn.cF028Ind = FLAG_YES_C;
		memcpy (tSendIpcIntTxn.sAmtTransFee, ptIpcIntTxn->sAmtTransFee, F028_LEN);
	}
	else
		tSendIpcIntTxn.cF028Ind = FLAG_NO_C;
		
	/* ת����Ӧ�������38��ʹ�÷�����Ӧ���е�38�� */
	if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
	{
		tSendIpcIntTxn.cF038Ind = FLAG_YES_C;
		memcpy (tSendIpcIntTxn.sAuthrIdResp, ptIpcIntTxn->sAuthrIdResp, F038_LEN);
	}
	else
		tSendIpcIntTxn.cF038Ind = FLAG_NO_C;
	
	
	/*ת��Ӧ�������57��ʹ�÷�����Ӧ���е�57��*/
	if(memcmp(tSendIpcIntTxn.sFldReserved+8,"06",2))
		memset(ptIpcIntTxn->sAddtnlData,' ',F060_VAL_LEN);
	if(ptIpcIntTxn->sAddtnlData[0] != ' ' && ptIpcIntTxn->sAddtnlData[0] != 0x00)
	{
		strncpy(tSendIpcIntTxn.sAddtnlDataLen ,  ptIpcIntTxn->sAddtnlDataLen,3);
		strncpy(tSendIpcIntTxn.sAddtnlData ,  ptIpcIntTxn->sAddtnlData,atoi(ptIpcIntTxn->sAddtnlDataLen) );
	}
	
	/*ת��Ӧ�������123��ʹ�÷�����Ӧ���е�123��*/
	if(ptIpcIntTxn->cF123Ind == 'Y')
	{
	    tSendIpcIntTxn.cF123Ind = 'Y';
	    memcpy(tSendIpcIntTxn.sIssrInstResvdLen, ptIpcIntTxn->sIssrInstResvdLen, F123_LEN_LEN);
	    memset(sTemp, 0, sizeof(sTemp));
	    memcpy(sTemp, ptIpcIntTxn->sIssrInstResvdLen, F123_LEN_LEN);
	    memcpy(tSendIpcIntTxn.sIssrInstResvd, ptIpcIntTxn->sIssrInstResvd, atoi(sTemp));
	}
	
	/* set trans state */
	if (IsRspSuccess (ptIpcIntTxn->sRespCode))
		memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
	else
		memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
	
	if(iMacResult)
	{
	    memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
	    memcpy (tTxn.resp_code, F039_MAC_FAIL, 2);
	}
		
	DbsBegin ();
	
	/***************
	* ��¼���ݿ�
	****************/
	nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
	if (nReturnCode )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn update error, %d. Continue this message.", nReturnCode);
	}
	else
	    DbsCommit ();
	    
	if(iMacResult)
	    return -1;
	
	if(gsMacFlag[0] == FLAG_YES_C)
	{
	    /* ����ͳһ����A0����������96 */
        if(memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) == 0)
        {
          HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "CUP return [%2.2s], respone 96", ptIpcIntTxn->sRespCode);
          memcpy(tSendIpcIntTxn.sRespCode, "96", F039_LEN);
        }
    }
	
	/***********************
	* ת��Ӧ��
	************************/
	/* �ͻ���Ŀ��IPC�������� */
	memcpy ((char *)&tSendIpcInt2, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
	
	/* ����Ӧ���״��� */
	memcpy( tSendIpcInt2.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
	
	/* ����Ӧ��SrvId */
	
	/*memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );*/
	memcpy( tSendIpcInt2.sMsgDestId, tTxn.msg_src_id, SRV_ID_LEN );
	
	/* ����Ӧ�� msg type */
	tSendIpcInt2.sMsgType[2]++;
	
	/* ��� F090 */
	if(tSendIpcInt2.sOrigDataElemts[0] != 0x00 && tSendIpcInt2.sOrigDataElemts[0] != ' ')
	    memset(tSendIpcInt2.sOrigDataElemts, ' ', F090_LEN);

	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,  __LINE__, (char*)&tSendIpcInt2, sizeof(tSendIpcInt2));
	
	nReturnCode = SendMsg (&tSendIpcInt2, &tTxn, NULL);
	if (nReturnCode)
	{
	    /* ����MAC����·�쳣�ı��� */
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SendMsg error, %d. Discard this message.", nReturnCode);
		return -1;
	}
	
	HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "R %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
		    
	HtLog(	gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
		
	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	
	return 0;
}
