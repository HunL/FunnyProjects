/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Switch.c                                                    */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtTDB/SwtTDB.c,v 1.1.1.1.4.5 2011/09/23 02:54:35 ctedev Exp $";

#include "SwtTDB.h"
#include "SwtTDBTxn.h"

int main( int argc, char **argv )
{
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    char            sIntMsgBuf[MSQ_MSG_SIZE_MAX];
    char            sTxnType[FLD_TXN_NUM_LEN+1];    
    int             i;
    int             nTxnType;
    int             nReturnCode;
    int             nMsgLen;
    int             nIntMsgLen;
    int             nIndex;
    long            lBeginTime, lEndTime;
    T_IpcIntTxnDef    tIpcIntTxn;
    struct tms        tTMS;
    char            sTickLog[128] = {0};
       
    sprintf (sTickLog, "SwtTDB.Ticks.%s.log", gsSrvSeqId);

    nReturnCode = SwitchInit( argc, argv);
    if ( nReturnCode != 0 )
    {
        printf("Switch: SwitchInit error %d\n", nReturnCode);
        return;
    }

    if (sigset(SIGTERM, HandleExit) == SIG_ERR)
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d.", errno);

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Switch started.");

    lBeginTime = 0;
    lEndTime = 0;

    while(1)
    {
        /* ����Ϣ�����л�ȡ��Ϣ */
        memset (sMsgBuf, 0, sizeof(sMsgBuf) );
        sigrelse (SIGTERM);
        nMsgLen = MSQ_MSG_SIZE_MAX;
        nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, &nMsgLen, sMsgBuf);
        sighold (SIGTERM);
        if (nReturnCode)
        {
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
            {
                HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqRcv error, %d.", nReturnCode);
                return;
            }
            else
                continue;
        }

        lBeginTime = times( &tTMS);
        /* uncompress msg */
        if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
        {
            /* uncompress msg */
            /* sMsgBuf, nMsgLen -> sIntMsgBuf, nIntMsgLen */
            UnCompressbuf(sMsgBuf, nMsgLen, sIntMsgBuf, &nIntMsgLen);

            nMsgLen = nIntMsgLen;
            memcpy (sMsgBuf, sIntMsgBuf, nIntMsgLen);
        }

        /*HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s", LINE_SEPARATOR);*/
        HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, sMsgBuf, nMsgLen);

        /* process msg according to msg source */
        memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
        memcpy (sMsgSrcId, sMsgBuf, SRV_ID_LEN);

        if (!memcmp (sMsgSrcId, SRV_ID_TOCTL, SRV_ID_LEN))
            nReturnCode = HandleTimeOut (sMsgBuf);
        else
        {
            memcpy ((char *)&tIpcIntTxn, sMsgBuf, sizeof (tIpcIntTxn));
            
            /* Save front SSN in sTermSSN */
            memcpy (tIpcIntTxn.sTermSSN, tIpcIntTxn.sSysTraceAuditNum, F011_LEN);
            memcpy (tIpcIntTxn.sOpenInst, gsSrvId, 4);
            
            if(tIpcIntTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
            {
            		nReturnCode = GetTxnInfoIndex( tIpcIntTxn.sMsgSrcId, tIpcIntTxn.sTxnNum, &nIndex );
            }
            else
            {
            		nReturnCode = 0;
            }	
            
            if ( nReturnCode != 0 )
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetTxnInfoIndex error.");
                return -1;
            }
            memcpy( tIpcIntTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );/*add by fucl*/
            
            /******************
			*Bridge CheckCard ����ʧ��
			*����ǰ��
			******************/
			/* һ�ڶԲ�֧�ֵĽ��ף������������ */
			/*HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CheckCard Flag [%c]",tIpcIntTxn.sMisc[69]);
			if(memcmp(tIpcIntTxn.sMisc+69,"Y",1) == 0)
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Bridge CheckCard error,src:[%4.4s],dest:[%4.4s]",
						tIpcIntTxn.sMsgSrcId,tIpcIntTxn.sMsgDestId);
				tIpcIntTxn.sTxnNum[3]++;
				memcpy( tIpcIntTxn.sMsgDestId, tIpcIntTxn.sMsgSrcId, SRV_ID_LEN );
				memcpy( tIpcIntTxn.sTransState, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
				tIpcIntTxn.sMsgType[2]++;
				nReturnCode = SendMsg (&tIpcIntTxn, NULL, NULL);
				continue;
			}*/

            for( i = 0; i < MAXTXNS; i++ )
            {
                if( memcmp( tIpcIntTxn.sTxnNum, gaTxns[i].caTxnNum, FLD_TXN_NUM_LEN ) == 0 )
                {
                    if (memcmp( gaTxns[i].caMsgSrcId, MSG_SRC_ID_ANY, SRV_ID_LEN ) == 0 )
                    {
                        break;
                    }
                    else
                    {
                        if (memcmp( tIpcIntTxn.sMsgSrcId, gaTxns[i].caMsgSrcId, SRV_ID_LEN ) == 0 )
                        {
                            break;
                        }
                    }
                }
            }
            
            nReturnCode = -1;
            nReturnCode = DbReconnectTest();
            if(nReturnCode != 0)
            {
			 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 	"\n  TXN: %4.4s\n  F002: %19.19s\n  F004: %12.12s\n  F007: %10.10s\n F011: %6.6s\n", 
			 	gatTxnInf[nIndex].txn_num, tIpcIntTxn.sPrimaryAcctNum, tIpcIntTxn.sAmtTrans, 	tIpcIntTxn.sTransmsnDateTime, tIpcIntTxn.sSysTraceAuditNum);    
			 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DataBase status is error ,Discard this message, nReturnCode=[%d]", nReturnCode);    	       
		    } /*  added end */
		    else
            {
                if( i == MAXTXNS )
                {
                    nReturnCode = SwtCustHandleTransaction(&tIpcIntTxn, nIndex);
                }
                else
                {
                    nReturnCode = gaTxns[i].pfTxnFun(&tIpcIntTxn, nIndex);
                }
            }

            lEndTime = times( &tTMS);
            HtLog (sTickLog, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Txn %s processed, used %ld ticks",
                    gaTxns[i].caTxnNum, lEndTime - lBeginTime);
        }

    }

}

/*****************************************************************************/
/* FUNC:   int SwitchInit ( );                                               */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ʼ��ϵͳ��̬����,����,������Ϣ��                                */
/*****************************************************************************/
int SwitchInit (short argc, char **argv)
{
    int                i;
    int                nReturnCode;
    long            lUsageKey;
    Tbl_srv_inf_Def    tTblSrvInf;
    int nMaxRspCodeMapN=0 ;
    static Tbl_rsp_code_map_Def tRspCodeMap[1500];
    /* get server id, arg 1 */
    strcpy (gsSrvId, argv[1]);
    strcpy (gsSrvSeqId, argv[2]);
    /* get parameter, compress flag */
    if (getenv(MSG_COMPRESS_FLAG))
    {
        strcpy (gsParamMsgCompressFlag, getenv(MSG_COMPRESS_FLAG));
    }
    else
        strcpy (gsParamMsgCompressFlag, FLAG_NO);

    if (getenv(SRV_USAGE_KEY))
        lUsageKey=atoi (getenv(SRV_USAGE_KEY));
    else
        return -1;

    if (getenv(MAC_FLAG))
        strcpy(gsMacFlag, getenv(MAC_FLAG));
    else
        return -1;
    
    /* connect to database */
    nReturnCode = DbsConnect ();
    if (nReturnCode)
        return (nReturnCode);

    /* get log file name from tbl_srv_inf */
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nReturnCode)
    {
        DbsDisconnect ();
        return (nReturnCode);
    }
    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (gsLogFile, "%s.%s.log", gsSrvId, gsSrvSeqId);
    

    /* init msg queue */
    memset ((char *)gatSrvMsq, 0, SRV_MSQ_NUM_MAX * sizeof (T_SrvMsq));
    nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d.", nReturnCode);
        DbsDisconnect ();
        return (nReturnCode);
    }
    /* ��ʼ��������Ϣ�� */
    memset( (char *)gatTxnInf, 0, sizeof(gatTxnInf) );
    gnTxnInfNum = TXN_INF_NUM_MAX;
    nReturnCode = DbsTxnInfLoad (&gnTxnInfNum, gatTxnInf);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxnInfLoad error, %d.", nReturnCode);
        DbsDisconnect ();
        return (nReturnCode);
    }
    
    /* ��ʼ��������������ձ� */
    memset( (char *)gatCupArea, 0, sizeof(gatCupArea) );
    nReturnCode = LoadCupArea (&gnMaxCupAreaLen, &gatCupArea);
    HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "gnMaxCupAreaLen:[%d]",gnMaxCupAreaLen);
    if(nReturnCode)
	{
		 HtLog(	gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LoadCupArea error %d.", nReturnCode);
		 DbsDisconnect ();
		 return nReturnCode;
	}
	

    /* ���ؽ���Ӧ����ת���� */
    nReturnCode = LoadRspCodeMap(&gnMaxRspCodeMapLen, &tRspCodeMap);
    HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "gnMaxRspCodeMapLen:[%d]",gnMaxRspCodeMapLen);
 	if(nReturnCode)
	{
		 HtLog(	gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LoadRspCodeMap error %d.", nReturnCode);
		 DbsDisconnect ();
		 return nReturnCode;
	}

    return 0;
}

/*****************************************************************************/
/* FUNC:   int GetTxnInfoIndex                                               */
/* INPUT:  ���״���                                                          */
/* OUTPUT: ��Ӧ��gatTblTxnInf�ṹ������, δ�ҵ�ʱֵΪ-1                      */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���״�����db_txn_inf�ṹ������                                  */
/*****************************************************************************/
int GetTxnInfoIndex( char *sMsgSrcId, char *sTxnNum, int *nIndex )
{
    char	sFuncName[] = "GetTxnInfoIndex";
	int		i;

	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin", sFuncName);

	*nIndex = -1;

	for( i = 0; i < gnTxnInfNum; i++ )
	{
		if ( memcmp(gatTxnInf[i].msg_src_id, sMsgSrcId, SRV_ID_LEN) == 0 &&
				memcmp(gatTxnInf[i].txn_num, sTxnNum, FLD_TXN_NUM_LEN) == 0 
				)
		{
			*nIndex = i;
			break;
		}
	}

	if( i == gnTxnInfNum )
	{
		for( i = 0; i < gnTxnInfNum; i++ )
		{
			if (!memcmp(gatTxnInf[i].msg_src_id, sMsgSrcId, SRV_ID_LEN-2) && 
					!memcmp(gatTxnInf[i].msg_src_id+2, "##", SRV_ID_LEN-2) &&
					!memcmp(gatTxnInf[i].txn_num, sTxnNum, FLD_TXN_NUM_LEN))
			{
				*nIndex = i;
				break;
			}
		}
	}

	if( i == gnTxnInfNum )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s   not configed in tbl_txn_inf",
				sTxnNum, sMsgSrcId);
		return -1;
	}

	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end", sFuncName);
	return 0;
}

void HandleExit (int n)
{
    DbsDisconnect ();
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Switch exits.");
    exit( 1 );
}


