/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Txn5153.c                                                   */
/* DESCRIPTIONS: handle notice msg from CUPS                                 */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-05-08  YU TONG        Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtTDB/Txn5183.c,v 1.2 2011/08/23 12:52:09 ctedev Exp $";

#include "SwtTDB.h"

int Txn5183 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
	char			sFuncName[] = "Txn5183";
	char			sMsgSrcId[SRV_ID_LEN+1];
	char			sSysTraceAuditNum[FLD_TERM_SSN_LEN+1];
	char			sRespCode[F039_LEN+1];
	char			sTxnNum[FLD_TXN_NUM_LEN+1];
	int				nReturnCode;
	int				i;
	int				nRevsalIndex;
	int				nSendFlag;
	T_SwtToReqDef	tSwtToReq;
	Tbl_txn_Def		tTxn, tOrigTxn, *ptOrigTxn;
	T_IpcIntTxnDef	tSendIpcIntTxn;
	Tbl_ic_txn_Def  tIcTxn;
	char            sCurrentTime[15];
	
    
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	
	if (nIndex < 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sMsgSrcId);
		return -1;
	}
	
	memset(sCurrentTime, 0, sizeof(sCurrentTime));
	/***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex);
    memcpy(sCurrentTime, gsTimeCurTs, 14);
    
	/* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
	memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
	memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
	memset (sSysTraceAuditNum, 0, sizeof (sSysTraceAuditNum));
	memcpy (sSysTraceAuditNum, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
		"TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %12.12s\n", 
		gatTxnInf[nIndex].txn_num, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans, 
		ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, sSysTraceAuditNum);
	
	/* ��ʱ�Ǽ�ʹ�ñ���ʱ�� */
    /*CommonGetCurrentTime(sCurrentTime);*/
    
    /* sMisc�м�¼ǰ��ʱ��,ǰ����ˮ */
    memcpy(ptIpcIntTxn->sMisc, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
    memcpy(ptIpcIntTxn->sMisc+F007_LEN, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
    memcpy(ptIpcIntTxn->sMiscFlag, sCurrentTime, 14);
    memcpy(ptIpcIntTxn->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
    
	/*******************
	* �жϸý����Ƿ�֧��
	********************/
	if (memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) ||
	    !memcmp(ptIpcIntTxn->sMAC064, "-99", 3))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
		/* ����Ӧ���״��� */
		memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
		/* ����Ӧ��SrvId */
		memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
		/* ���Ĵ���Ӧ���� */
		memcpy( ptIpcIntTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );	
		/* ����Ӧ�� msg type */
		ptIpcIntTxn->sMsgType[2]++;
		/* clear F038 */
		ptIpcIntTxn->cF038Ind = FLAG_NO_C;
		/* clear F090 */
		memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
		/* F055 Return 9F36 */
		nReturnCode = ReturnGet9F36(ptIpcIntTxn);
		
		nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);
		return -1;
	}
	
	/*******************
	* �жϸý����Ƿ�ת��
	********************/
	nSendFlag = 0;
	CommonRTrim (gatTxnInf[nIndex].msg_dest1);
	if (strlen (gatTxnInf[nIndex].msg_dest1) == SRV_ID_LEN)
		nSendFlag = 1;
	
	/***************
	* ������ˮ��
	****************/
	memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
	tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
	tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
	memcpy (tSwtToReq.sTxnDate, ptIpcIntTxn->sTransmsnDateTime, F007_LEN );
	
	nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq,ptIpcIntTxn );
	if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"ToCtrlReq error, %d.", nReturnCode);
		/* do not send response for this failure, wait for resend of this msg */
		return -1;
	}
	/* save ssn in ipc */
	memcpy (ptIpcIntTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
	
	/* ��key_rsp, key_cancel��ֵ */
	nReturnCode = SetKeyRsp (ptIpcIntTxn);
	nReturnCode = SetKeyCancel (ptIpcIntTxn);

	/***********************
	* ��֯��¼���ݿ��¼�ṹ
	************************/
	nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
	if( nReturnCode )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"MoveIpc2Txn error, %d.", nReturnCode);
		/* do not send response for this failure, wait for resend of this msg */
	
		return -1;
	}

	/***************
	* ����ԭ��������
	****************/
	memset ((char *)&tOrigTxn, 0, sizeof (tOrigTxn));
	memcpy ((char *)&tOrigTxn, (char *)&tTxn, sizeof (tTxn));
    memcpy (tOrigTxn.term_ssn, ptIpcIntTxn->sOrigDataElemts+4, F011_LEN);
	/* DBS_SELECT29: txn_num, key_cancel, term_ssn*/
	nReturnCode = DbsTxn (DBS_SELECT29, &tOrigTxn );
	if(nReturnCode)
	    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn DBS_SELECT29 doesn't find orig txn [%d], txn_num [%4.4s], key_cancel [%32.32s], term_ssn [%6.6s].", 
			nReturnCode, tOrigTxn.txn_num, tOrigTxn.key_cancel, tOrigTxn.term_ssn);
	
	/*******************
	* �����ͻ����ļ��
	********************/
	nReturnCode = SwtCustCheckTxn (ptIpcIntTxn, sRespCode);
	if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SwtCustCheckTxn error, %d. Reject this transaction with %s.", nReturnCode, sRespCode);

		/* ����Ӧ���״��� */
		memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
		/* ����Ӧ��SrvId */
		memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
		/* ���Ĵ���Ӧ���� */
		memcpy( ptIpcIntTxn->sRespCode, sRespCode, F039_LEN );	
		/* ����Ӧ�� msg type */
		ptIpcIntTxn->sMsgType[2]++;
		/* clear F038 */
		ptIpcIntTxn->cF038Ind = FLAG_NO_C;
		/* clear F090 */
		memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
		/* F055 Return 9F36 */
		nReturnCode = ReturnGet9F36(ptIpcIntTxn);
		
		nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);

		/* save this txn in Db */
		DbsBegin ();
		memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
		memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
		nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
		if (nReturnCode)
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
		DbsCommit ();

		return -1;
	}
	
	/*********************
	* �ͻ������ݿ��¼�ṹ
	**********************/
	nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SwtCustBeforeTblTxnOpr error, %d.", nReturnCode);
		/* do not send response for this failure, wait for resend of this msg */

		/* save this txn in Db */
		DbsBegin ();
		memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
		memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
		nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
		if (nReturnCode)
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
		DbsCommit ();
	
		return -1;
	}
	
	/*********************
	*��ֵ��������ֵ F122
	**********************/	
    PCSPacketWrapper(ptIpcIntTxn, &tOrigTxn);
	
	DbsBegin ();
	
	if (!nSendFlag)
	{
		memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
		memcpy (tTxn.resp_code, F039_SUCCESS, F039_LEN);
	}

	/***************
	* ��¼���ݿ�
	****************/
	nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
	if (nReturnCode )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn insert error, %d.", nReturnCode);
		/* do not send response for this failure, wait for resend of this msg */

		return -1;
	}
	
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");
    
    /***************
	* ��¼IC���������ݿ�
	****************/
	if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    nReturnCode = MoveTxn2IcTxn(&tTxn, ptIpcIntTxn, &tIcTxn);
	    nReturnCode = DbsIcTxn (DBS_INSERT, &tIcTxn);
	    if (nReturnCode )
	    {
	    	DbsRollback ();
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
		    	"DbsIcTxn insert error, %d.", nReturnCode);
		    /* do not send response for this failure, wait for resend of this msg */
            
		    return -1;
	    }
	}
	
	DbsCommit ();
	
	/***********************
	*  ת��������
	************************/
	if (nSendFlag)
		memcpy ((char *)&tSendIpcIntTxn, (char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn));	
	
	/****************
	* ���ͳɹ�Ӧ�������
	****************/
	/* ����Ӧ���״��� */
	memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
	/* ����Ӧ��SrvId */
	memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
	/* ����Ӧ�� msg type */
	ptIpcIntTxn->sMsgType[2]++;
	/* ���Ĵ���Ӧ���� */
	memcpy( ptIpcIntTxn->sRespCode, F039_SUCCESS, F039_LEN );	
	/* clear F038 */
	ptIpcIntTxn->cF038Ind = FLAG_NO_C;
	/* clear F090 */
	memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
	/* F055 Return 9F36 */
    nReturnCode = ReturnGet9F36(ptIpcIntTxn);

	nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
	if( nReturnCode != 0 )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "SendMsg to %4.4s.", ptIpcIntTxn->sMsgSrcId);
	
	/***********************
	*  ת��������
	************************/
	if (nSendFlag)
	{
		memcpy( tSendIpcIntTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );
	
		nReturnCode = SendMsg (&tSendIpcIntTxn, &tTxn, NULL);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
		}
		
		HtLog(	gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);
		
		nReturnCode = InsertSafMsg (&tSendIpcIntTxn, &tTxn, gatTxnInf[nIndex].saf_count1);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
		}
	}
	
	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	
	return 0;
}

int Txn5184 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
	char			sFuncName[] = "Txn5184";
	char			sMsgSrcId[SRV_ID_LEN+1];
	int				nReturnCode;
	int				nTxnSelOpr;
	int				nReqIndex;
	Tbl_txn_Def		tTxn, tOrigTxn;
	Tbl_ic_txn_Def  tIcTxn;
	Tbl_saf_msg_Def	tSafMsg;
	char            sF055Len[F055_LEN_LEN+1];
	char            sCurrentTime[15];
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	
	memset(sCurrentTime, 0, sizeof(sCurrentTime));
	SetToTime(-1);
	memcpy(sCurrentTime, gsTimeCurTs, 14);
	
	/* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
	memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
	memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
		"TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  host SSN: %12.12s\n  response code: %2.2s", 
		ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans, 
		ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, 
		ptIpcIntTxn->sSysTraceAuditNum, ptIpcIntTxn->sHostSSN, ptIpcIntTxn->sRespCode);
	
	/****************************
	* ����tbl_txn�еĽ��׼�¼
	****************************/
	nReturnCode = SetKeyRsp (ptIpcIntTxn);
		
	/* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
	memset ((char *)&tTxn, 0, sizeof (tTxn));
	memcpy (tTxn.key_rsp, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	memcpy (tTxn.txn_num, ptIpcIntTxn->sTxnNum, FLD_TXN_NUM_LEN);
	tTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
	/* �����ݿ��в���ԭ������ */
	nReturnCode = DbsTxn (DBS_SELECT21, &tTxn);
	if (nReturnCode)
	{
		tTxn.key_rsp[KEY_RSP_LEN] = 0;
		tTxn.txn_num[FLD_TXN_NUM_LEN] = 0;
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn select error, %d. txn_num=%s,key_rsp=%s. Discard this message.", nReturnCode,tTxn.txn_num,tTxn.key_rsp);
		return -1;
	}
	
	/***********************
	* ���ҽ���������gatTxnInf�е�����
	************************/
	nReturnCode = GetTxnInfoIndex (tTxn.msg_src_id, tTxn.txn_num, &nReqIndex );
	if (nReturnCode || nReqIndex < 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
		return -1;
	}

	/***********************
	* ��֯��¼���ݿ��¼�ṹ
	************************/
	nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
	if( nReturnCode )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
		return -1;
	}
	
	/*********************
	* �ͻ������ݿ��¼�ṹ
	**********************/
	nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
		return -1;
	}
	
	/* set trans state */
	if (IsRspSuccess (ptIpcIntTxn->sRespCode))
		memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
	else
		memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
	
	DbsBegin ();
	
	/***************
	* ��¼���ݿ�
	****************/
	nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
	if (nReturnCode )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn update error, %d. Discard this message.", nReturnCode);

		return -1;
	}
	
	/* ���tbl_saf_msg�еķ��ʹ��� */
	memset ((char *)&tSafMsg, 0, sizeof (tSafMsg));
	memcpy (tSafMsg.inst_date, tTxn.inst_date, 8);
	memcpy (tSafMsg.inst_time, tTxn.inst_time, 6);
	memcpy (tSafMsg.sys_seq_num, tTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
	memcpy (tSafMsg.msg_dest_srv_id, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
	memset (tSafMsg.send_count, '0', 2);
	nReturnCode = DbsSafMsg (DBS_UPDATE, &tSafMsg);
	if (nReturnCode && nReturnCode != DBS_NOTFOUND )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsSafMsg update error, %d. Discard this message.", nReturnCode);

		return -1;
	}
	
	/***************
	* ����IC���ű�
	****************/
	if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    /*CommonGetCurrentTime(sCurrentTime);*/
	    memcpy (sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
	    sprintf(sF055Len, "%03d", atoi(sF055Len)*2);
	    memcpy(tIcTxn.rsp_iclen, sF055Len, F055_LEN_LEN);
	    Hex2Str(ptIpcIntTxn->sICData, tIcTxn.rsp_icdata, atoi(sF055Len)/2);
	    memcpy(tIcTxn.update_time, sCurrentTime, 14);
	    memcpy(tIcTxn.key_rsp, tTxn.key_rsp, KEY_RSP_LEN);
	    
	    nReturnCode = DbsIcTxn (DBS_UPDATE, &tIcTxn);
	    if (nReturnCode )
	    {
	    	DbsRollback ();
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
		    	"DbsIcTxn update error, %d. Discard this message.", nReturnCode);
            
		    return -1;
	    }
	}
	DbsCommit ();
		
	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	
	return 0;
}
