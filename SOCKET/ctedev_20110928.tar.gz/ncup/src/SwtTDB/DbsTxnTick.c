/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Normal.c                                                    */
/* DESCRIPTIONS: handle normal req from CUP and its rsp from host            */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtTDB/DbsTxnTick.c,v 1.1.1.1 2011/08/19 10:55:53 ctedev Exp $";

#include "SwtTDB.h"
extern TXNFUN gaTxns[MAXTXNS];

/***********************
*��ֵ��TDB����ѯӦ��
************************/
int main( int argc, char **argv )
{
    int             i=0;
	char			sFuncName[] = "Txn1254";

	int				nReturnCode;
	int				nLineStat;
	int				nTxnSelOpr;
	int				nMsgLen;
	int				nSendRevsalFlag;
	int				nSendRspFlag;
	int				nReqIndex;
	char            sTxnNum[4+1];

	struct tms		tTMS;
	Tbl_txn_Def		tTxn;
	long            lBeginTime, lEndTime;
	char            gsLogFile[128] = "swtTest.log";

    memset ((char *)&tTxn, 0, sizeof (tTxn));
	
	lBeginTime = 0;
    lEndTime = 0;
	
	nReturnCode = DbsConnect();
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsConnect error [%d].", nReturnCode);	
		return -1;		
	}
	
	/* �����ݿ��в���ԭ������ */
	/* DBS_SELECT21: txn_num, key_rsp */
	lBeginTime = times( &tTMS);
	memcpy(tTxn.key_rsp, "062915152134329304103320300000  ", 32);
	nReturnCode = DbsTxn (DBS_SELECT21, &tTxn);
	if (nReturnCode)
	{
		tTxn.key_rsp[32] = 0;
		tTxn.txn_num[4] = 0;
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn select error, %d. txn_num=%s,key_rsp=%s. Discard this message.", nReturnCode,tTxn.txn_num,tTxn.key_rsp);
		return -1;
	}
	
	lEndTime = times( &tTMS);	
	printf("DbsTxn DBS_SELECT21, used %ld ticks, key_rsp[%s]\n",
                    lEndTime - lBeginTime, tTxn.key_rsp);
	
	/***************
	* ��¼���ݿ�
	****************/
	DbsBegin ();
	
	lBeginTime = times( &tTMS);
	nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
	if (nReturnCode )
	{
		DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"DbsTxn update error, %d. Discard this message.", nReturnCode);

		
		return -1;
	}
	
	lEndTime = times( &tTMS);	
	printf( "DbsTxn DBS_UPDATE1, used %ld ticks\n",
                    lEndTime - lBeginTime);	
	
	return 0;
}


int GetTxnInfoIndex( char *sMsgSrcId, char *sTxnNum, int *nIndex )
{
    return 0;
}


int nSetSlmtDate(char * sRecordID, char * sStlmDate)
{
	return 0;	
}

int DbsTxnSts1()
{
	return 0;
}

int DbsAUTHRSPINFO()
{
	return 0;
}
int DbsClcMon()
{
	return 0;
}
int DbsCupRsp()
{
	return 0;
}

int DbsSYSSTAT()
{
	return 0;
}

int DbsTxnSts()
{
	return 0;
}
