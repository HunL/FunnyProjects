/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Normal.c                                                    */
/* DESCRIPTIONS: handle normal req from CUP and its rsp from host            */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtTDB/Txn1383.c,v 1.2 2011/08/23 12:52:09 ctedev Exp $";

#include "SwtTDB.h"

int Txn1383 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
    char            sFuncName[] = "Txn1383";
    char            sRespCode[F039_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    
    int             nReturnCode;
    int             nLineStat;
    int             nMsgLen;
    int             nTxnSelOpr;
    T_SwtToReqDef   tSwtToReq;
    Tbl_txn_Def     tTxn;
    T_IpcIntTxnDef  tSendIpcIntTxn;
    Tbl_ic_txn_Def  tIcTxn;
    char            sAcqInstIdCode[8+1+2];
    char            sCurrentTime[15];
    
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    if (nIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sMsgSrcId);
        return -1;
    }
    
    memset(sCurrentTime, 0, sizeof(sCurrentTime));
    /***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex);
    memcpy(sCurrentTime, gsTimeCurTs, 14);

   /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
		"TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %6.6s\n", 
		gatTxnInf[nIndex].txn_num, 
		ptIpcIntTxn->sPrimaryAcctNum, 
		ptIpcIntTxn->sAmtTrans, 
		ptIpcIntTxn->sDateLocalTrans, 
		ptIpcIntTxn->sTimeLocalTrans, 
		ptIpcIntTxn->sSysTraceAuditNum);
	
	/* ��ʱ�Ǽ�ʹ�ñ���ʱ�� */
    /*CommonGetCurrentTime(sCurrentTime);*/
    
    /* sMisc�м�¼ǰ��ʱ��,ǰ����ˮ */
    memcpy(ptIpcIntTxn->sMisc, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
    memcpy(ptIpcIntTxn->sMisc+F007_LEN, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
    memcpy(ptIpcIntTxn->sMiscFlag, sCurrentTime, 14);
    memcpy(ptIpcIntTxn->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
    
    /* �Ǽǲ�ѯ�����뵽sMiscFlag������ʱģ���� */
    memcpy( ptIpcIntTxn->sMiscFlag+14, "1283", 4 );
      
    /*******************
     * �жϸý����Ƿ�֧��
     ********************/
    if (memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) ||
        !memcmp(ptIpcIntTxn->sMAC064, "-99", 3))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		/* clear F055 */
		ptIpcIntTxn->cICDataInd = FLAG_NO_C;
        
        nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);
        return -1;
    }
    
    /***************
     * ������ˮ��
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
    if (tSwtToReq.nToCtlTime > 0)
        tSwtToReq.nTransCode = TOCTL_NORMAL_FIRST;
    else
        tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
    memcpy (tSwtToReq.sTxnDate, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);

    nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
    if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "ToCtrlReq error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );    
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		/* clear F055 */
        ptIpcIntTxn->cICDataInd = FLAG_NO_C;
    
        nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);
        return -1;
    }
    
    /* save ssn in ipc */
    memcpy (ptIpcIntTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
    memcpy(ptIpcIntTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);

    /* ��key_rsp, key_revsal, key_cancel��ֵ */
    nReturnCode = SetKeyRsp (ptIpcIntTxn);
    nReturnCode = SetKeyRevsal (ptIpcIntTxn);
    nReturnCode = SetKeyCancel (ptIpcIntTxn);
    
    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);

        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		/* clear F055 */
        ptIpcIntTxn->cICDataInd = FLAG_NO_C;
        
        nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);    /* by gjch */

        return -1;
    }

    /***************
     * У��MAC
     ****************/
    nReturnCode = VerifyMAC1 (ptIpcIntTxn );
    if (nReturnCode != 0 )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "VerifyMAC error, %d. Reject this transaction with %s.", nReturnCode, F039_MAC_FAIL);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_MAC_FAIL, F039_LEN );
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		/* clear F055 */
        ptIpcIntTxn->cICDataInd = FLAG_NO_C;
        
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }
	
    /***************
     * ת��PIN
     ****************/
    if (gatTxnInf[nIndex].pin_flag[0] == FLAG_YES_C)
    {
        nReturnCode = TransferPin (ptIpcIntTxn );
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "TransferPin error, %d. Reject this transaction with %s.", nReturnCode, F039_PIN_ERROR);
            /* �����ʱ���� */
            tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, F039_PIN_ERROR, F039_LEN );
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            ptIpcIntTxn->cF014Ind = 'Y';
			memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
			/* clear F055 */
            ptIpcIntTxn->cICDataInd = FLAG_NO_C;
            
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);

            /* save this txn in Db */
            DbsBegin ();
            memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
            nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
            DbsCommit ();

            return -1;
        }
    }
	
    /*******************
     * �����ͻ����ļ��
     ********************/
    nReturnCode = SwtCustCheckTxn (ptIpcIntTxn, sRespCode);
    if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustCheckTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, sRespCode, F039_LEN );
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		/* clear F055 */
        ptIpcIntTxn->cICDataInd = FLAG_NO_C;
        
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }
    
    /*******************
	 * ARQC��֤
	 ********************/
#if 0 /* ��ʱ���� */
    if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
    {
        nReturnCode = VerifyARQC (ptIpcIntTxn);
        if (nReturnCode)
	    {
	        memcpy(sRespCode, "34\0", 3);
	    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	    			"VerifyARQC error, %d. Reject this transaction with %s.", nReturnCode, sRespCode);
	    	/* �����ʱ���� */
            tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
            
            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, sRespCode, F039_LEN );
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            ptIpcIntTxn->cF014Ind = 'Y';
		    memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		    /* clear F055 */
            ptIpcIntTxn->cICDataInd = FLAG_NO_C;
            
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
            
            /* save this txn in Db */
            DbsBegin ();
            memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
            nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
            DbsCommit ();
            
            return -1;
	    }
	}
#endif /* ��ʱ���� */
	
    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"SwtCustBeforeTblTxnOpr error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
        
        /* ���Ĵ���Ӧ���� */
        if(ptIpcIntTxn->sRespCode[0] == ' ' || ptIpcIntTxn->sRespCode[0] == 0)
		{
			memcpy(ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
        }
        
        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
        
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		/* clear F055 */
        ptIpcIntTxn->cICDataInd = FLAG_NO_C;
        
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }
    
    /*********************
	*��ֵ��������ֵ F122
	**********************/	
    PCSPacketWrapper(ptIpcIntTxn, &tTxn);

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn insert error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_DUPL_TXN, F039_LEN );
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		/* clear F055 */
        ptIpcIntTxn->cICDataInd = FLAG_NO_C;
		
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        return -1;
    }
    
    /***************
	* ��¼IC���������ݿ�
	****************/
	if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    nReturnCode = MoveTxn2IcTxn(&tTxn, ptIpcIntTxn, &tIcTxn);
	    nReturnCode = DbsIcTxn (DBS_INSERT, &tIcTxn);
	    if (nReturnCode )
	    {
	    	DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsIcTxn insert error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
            /* �����ʱ���� */
            tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
            
            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, F039_DUPL_TXN, F039_LEN );
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            ptIpcIntTxn->cF014Ind = 'Y';
		    memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		    /* clear F055 */
            ptIpcIntTxn->cICDataInd = FLAG_NO_C;
		    
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
            return -1;
	    }
	}
    DbsCommit ();

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");

    /***********************
	* ����IPC�������ݣ�����Packsend����������
	************************/
    memcpy ((char *)&tSendIpcIntTxn, (char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn));
    memcpy( tSendIpcIntTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );
    /*ת������ֵ��->Ȧ���ѯ����*/
    memcpy( tSendIpcIntTxn.sTxnNum, "1283", 4 );
    nReturnCode = SendMsg (&tSendIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SendMsg error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        ptIpcIntTxn->cF014Ind = 'Y';
		memcpy (ptIpcIntTxn->sDateExpr, "0000", 4);
		/* clear F055 */
        ptIpcIntTxn->cICDataInd = FLAG_NO_C;
        
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);

        /* �޸�tbl_txn��resp_code */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
        if (nReturnCode)
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn DBS_UPDATE1 error, %d.", nReturnCode);
        }
        DbsCommit ();

        return -1;
    }

    HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);
    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    
    return 0;
}

int Txn1384 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
    char            sFuncName[] = "Txn1384";
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    int                nReturnCode;
    int                nLineStat;
    int                nTxnSelOpr;
    int                nMsgLen;
    int                nSendRevsalFlag;
    int                nSendRspFlag;
    int                nSendAccountFlag;
    int                nReqIndex;
    T_SwtToReqDef    tSwtToReq;
    Tbl_txn_Def        tTxn;
    Tbl_ic_txn_Def     tIcTxn;
    T_IpcIntTxnDef    tSendIpcIntTxn, tSendIpcInt2;
    char            sAcctLen[F002_LEN_LEN+1], sAcctNo[F002_VAL_LEN+1];
    int             iAcctLen;
    char            sF055Len[F055_LEN_LEN+1];
    char            sCurrentTime[15];

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    memset(sCurrentTime, 0, sizeof(sCurrentTime));
	SetToTime(-1);
	memcpy(sCurrentTime, gsTimeCurTs, 14);
	
    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
	memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
	memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
	
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
		"TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  host SSN: %12.12s\n  response code: %2.2s", 
		ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans, 
		ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, 
		ptIpcIntTxn->sSysTraceAuditNum, ptIpcIntTxn->sHostSSN, ptIpcIntTxn->sRespCode);

    /* ת��Ӧ���� */    
	nReturnCode = SwtCustTransferRspCode(ptIpcIntTxn);
	if (nReturnCode != 0 )
	{
        memcpy(ptIpcIntTxn->sRespCode,"01",F039_LEN);	
	}
    
    /***************
	* У��MAC
	****************/
	if(memcmp (sMsgSrcId, SRV_ID_COMM_ZK, 4) == 0 &&
	    memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) != 0)
	{
	    nReturnCode = VerifyMAC (ptIpcIntTxn );
	    if (nReturnCode != 0 )
	    {
	    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	    		"VerifyMAC error, %d. Discard this message.", nReturnCode);
	    	return -1;
	    }
	}

    /****************************
     * ����tbl_txn�еĽ��׼�¼
     ****************************/
    nReturnCode = SetKeyRsp (ptIpcIntTxn);

    /* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
    memset ((char *)&tTxn, 0, sizeof (tTxn));
    memcpy (tTxn.key_rsp, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
    /*Ȧ���˻���ѯӦ������Ľ�����ת��ΪȦ�潻����*/
    if(memcmp(ptIpcIntTxn->sTxnNum, "1284", 4) == 0)
        memcpy (tTxn.txn_num, "1384", FLD_TXN_NUM_LEN);
    else
        memcpy (tTxn.txn_num, ptIpcIntTxn->sTxnNum, FLD_TXN_NUM_LEN);
    tTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
    /* �����ݿ��в���ԭ������ */
    /* DBS_SELECT21: txn_num, key_rsp */
    nReturnCode = DbsTxn (DBS_SELECT21, &tTxn);
    if (nReturnCode)
    {
        tTxn.key_rsp[KEY_RSP_LEN] = 0;
        tTxn.txn_num[FLD_TXN_NUM_LEN] = 0;
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn select error, %d. txn_num=%s,key_rsp=%s. Discard this message.", nReturnCode,tTxn.txn_num,tTxn.key_rsp);
        return -1;
    }

    /***********************
     * ���ҽ���������gatTxnInf�е�����
     ************************/
    nReturnCode = GetTxnInfoIndex (tTxn.msg_src_id, tTxn.txn_num, &nReqIndex );
    if (nReturnCode || nReqIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
        return -1;
    }

    /***********************
     * ���ô����쳣ʱ�Ƿ�Ҫ���ͳ��� ����ֵ����һ�η��أ����÷�������
     ************************/
    if(memcmp (ptIpcIntTxn->sMsgSrcId, "1701", 4) == 0 &&
        memcmp (ptIpcIntTxn->sTxnNum, "1284", 4) == 0)
    {
        nSendRevsalFlag = 0;
    }
    else
    {
        switch (gatTxnInf[nReqIndex].rsp_type[0])
        {
            case RSP_TYPE_NO_ACCOUNT:
                if (IsRspSuccess (ptIpcIntTxn->sRespCode) )
                    nSendRevsalFlag = 1;
                else
                    nSendRevsalFlag = 0;
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                if (IsRspSuccess (ptIpcIntTxn->sRespCode) && !memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
                    nSendRevsalFlag = 1;
                else
                    nSendRevsalFlag = 0;
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                /*�ɹ�Ӧ�𣬶��Ҳ��ǲ�ѯӦ��*/
                if (IsRspSuccess (ptIpcIntTxn->sRespCode) &&
                    memcmp (ptIpcIntTxn->sTxnNum, "1284", 4) != 0)
                    nSendRevsalFlag = 1;
                else
                    nSendRevsalFlag = 0;
                break;
            default:
                break;
        }
    }

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* ��tTxn���浽tSendIpcIntTxn, ������Ӧ����ʹ�� */
    nReturnCode = MoveTxn2Ipc (&tTxn, &tSendIpcIntTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    
    
    /* ת����Ӧ�������38��ʹ�÷�����Ӧ���е�38�� */
    if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
    {
        tSendIpcIntTxn.cF038Ind = FLAG_YES_C;
        memcpy (tSendIpcIntTxn.sAuthrIdResp, ptIpcIntTxn->sAuthrIdResp, F038_LEN);
    }
    else
        tSendIpcIntTxn.cF038Ind = FLAG_NO_C;
	
	/* Ȧ���ѯӦ��ɹ���ת��Ӧ�������102��(Ȧ���˻�) */
	if((memcmp(ptIpcIntTxn->sTxnNum, "1284", 4) == 0) &&
	    (memcmp(ptIpcIntTxn->sRespCode, "00", 2) == 0) &&
	    (ptIpcIntTxn->sAcctId1[0] == ' ' || ptIpcIntTxn->sAcctId1[0] == 0x00))
	{
	    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "Ȧ���˻�δ���� error, Discard this message.");
        return -1;
    }
    if(memcmp(ptIpcIntTxn->sTxnNum, "1284", 4) == 0 &&
        memcmp(ptIpcIntTxn->sRespCode, "00", 2) == 0)
    {
        /* F103 �����ֽ𿨺� */
        memset(sAcctLen, 0, sizeof(sAcctLen));
        memset(sAcctNo, 0, sizeof(sAcctNo));
        memcpy(sAcctNo, ptIpcIntTxn->sPrimaryAcctNum, F002_VAL_LEN);
        CommonRTrim(sAcctNo);
        iAcctLen = strlen(sAcctNo);
        sprintf(sAcctLen, "%02d", iAcctLen);
        memcpy(ptIpcIntTxn->sAcctId2Len, sAcctLen, F002_LEN_LEN);
        memcpy(ptIpcIntTxn->sAcctId2, ptIpcIntTxn->sPrimaryAcctNum, iAcctLen);
        memcpy(tSendIpcIntTxn.sAcctId2Len, sAcctLen, F002_LEN_LEN);
        memcpy(tSendIpcIntTxn.sAcctId2, ptIpcIntTxn->sPrimaryAcctNum, iAcctLen);
        
        /* F002 ��ǿ��� */
        ptIpcIntTxn->cF002Ind = 'Y';
        tSendIpcIntTxn.cF002Ind = 'Y';
        memset(sAcctLen, 0, sizeof(sAcctLen));
        memset(sAcctNo, 0, sizeof(sAcctNo));
        memset(ptIpcIntTxn->sPrimaryAcctNum, ' ', F002_VAL_LEN);
        memcpy(sAcctNo, ptIpcIntTxn->sAcctId1, F002_VAL_LEN);
        CommonRTrim(sAcctNo);
        iAcctLen = strlen(sAcctNo);
        sprintf(sAcctLen, "%02d", iAcctLen);
        memcpy(ptIpcIntTxn->sPrimaryAcctNumLen, sAcctLen, F002_LEN_LEN);
        memcpy(ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAcctId1, iAcctLen);
        memcpy(tSendIpcIntTxn.sPrimaryAcctNumLen, sAcctLen, F002_LEN_LEN);
        memcpy(tSendIpcIntTxn.sPrimaryAcctNum, ptIpcIntTxn->sAcctId1, iAcctLen);
        
        /* F052 */
        if(ptIpcIntTxn->sPinData[0] == ' ')
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "������û���� error, Discard this message.");
            return -1;
        }
        tSendIpcIntTxn.cF052Ind = 'Y';
        memcpy(tSendIpcIntTxn.sPinData, ptIpcIntTxn->sPinData, F052_LEN);
        
        /* ������ */
        if(ptIpcIntTxn->sF059Val[1+6] == ' ')
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "����������û���� error, Discard this message.");
            return -1;
        }
        memcpy(tSendIpcIntTxn.sFwdInstIdCode, ptIpcIntTxn->sF059Val+1+6, 6);
        
        /* ������ */
        nReturnCode = SwtCustTransferCupAreaId(ptIpcIntTxn);
        if(nReturnCode != 0)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "ת������������ error, Discard this message.");
            return -1;
        }
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntTxn->sHostSSN [%6.6s]", ptIpcIntTxn->sHostSSN);
        memcpy(tSendIpcIntTxn.sHostSSN, ptIpcIntTxn->sHostSSN, 6);
    }
    
    /* ת����Ӧ�������55��ʹ�÷�����Ӧ���е�55�� */
    if (ptIpcIntTxn->cICDataInd == FLAG_YES_C)
    {
        memset(sF055Len, 0, sizeof(sF055Len));
        tSendIpcIntTxn.cICDataInd = FLAG_YES_C;
        memcpy (tSendIpcIntTxn.sICDataLen, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
        memcpy (sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
        memcpy (tSendIpcIntTxn.sICData, ptIpcIntTxn->sICData, atoi(sF055Len));
    }
    
    /***************
	* �����нű� ARPC
	****************/
	if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    nReturnCode = GenScriptMac (&tSendIpcIntTxn );
	    if (nReturnCode != 0 )
	    {
	    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	    			"GenScriptMac error, %d. Discard this message.", nReturnCode);
	    	return -1;
	    }
	}
	
    /***************
     * ��齻���Ƿ�ʱ
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nReqIndex].msg_to );
    memcpy (tSwtToReq.sTxnDate, tTxn.trans_date_time, F007_LEN);
    memcpy (tSwtToReq.sSysSeqNum, tTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN );
    tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;

    /* ���ȼ����ٻ�ǰ��Ӧ������, ���յ������ɹ�Ӧ��ʱ���ⳬʱ, �յ���������Ӧ����ٽⳬʱ */
    switch (gatTxnInf[nReqIndex].rsp_type[0])
    {
        case RSP_TYPE_NO_ACCOUNT:
        case RSP_TYPE_RSP_BEFORE_ACCOUNT:
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
            if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "ToCtrlReq error, %d. Discard this message.", nReturnCode);
                return -1;
            }

            break;
        case RSP_TYPE_RSP_AFTER_ACCOUNT:
            /* ��ֵ��ʧ�ܷ��صĽ��ף����������صĽ��ף��ⳬʱ */
            if ((memcmp(sMsgSrcId, "1701", 4) == 0 && memcmp(ptIpcIntTxn->sTxnNum, "1394", 4) == 0) ||
                    !IsRspSuccess (ptIpcIntTxn->sRespCode))
            {
#if 0
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
                if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                            "ToCtrlReq error, %d. Discard this message.", nReturnCode);
                    return -1;
                }
#endif
                /* �����ʱ */
                if(memcmp(sMsgSrcId, "1701", 4) == 0 && memcmp(ptIpcIntTxn->sTxnNum, "1394", 4) == 0)
                {
                    if(IsRspSuccess (ptIpcIntTxn->sRespCode))
                        memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    else
                        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
                }
                else
                    memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
                DbsBegin ();
                nReturnCode = DbsTxn (DBS_UPDATE13, &tTxn);
                if (nReturnCode)
                {
                    DbsRollback ();
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn DBS_UPDATE13 error, %d.", nReturnCode);
                }
                DbsCommit ();
            }
            else
            {
                if (!memcmp (tTxn.trans_state, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN) ||
                    !memcmp (tTxn.trans_state, TRANS_STATE_NO_ACCT_RSP, FLD_TRANS_STATE_LEN))
                    tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;
                else
                    tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_HAD_TO;
            }

            break;
        default:
            break;
    }
    
    /***********************************************************
    *  ��齻���Ƿ�ʱ add by tangb for double Machine ToCtl->Tom
    *************************************************************/
	if (!memcmp(tTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN))
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_HAD_TO;
    else
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;

    /* set trans state if reply is not time out */
    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_TO)
    {
        if (IsRspSuccess (ptIpcIntTxn->sRespCode))
        {
            switch (gatTxnInf[nReqIndex].rsp_type[0])
            {
                case RSP_TYPE_NO_ACCOUNT:
                    memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    break;
                case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                    if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
                        memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    break;
                case RSP_TYPE_RSP_AFTER_ACCOUNT:
                    if ( !memcmp (sMsgSrcId, SRV_ID_COMM_ZK, 4) )
                        memcpy (tTxn.trans_state, TRANS_STATE_ACCT_TO, FLD_TRANS_STATE_LEN);
                    else if(!memcmp (sMsgSrcId, "1701", 4) && !memcmp(ptIpcIntTxn->sTxnNum, "1394", 4))
                        memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    else
                        memcpy (tTxn.trans_state, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN);
                    break;
                default:
                    break;
            }
        }
        else
        {
            if (!memcmp (sMsgSrcId, "1701", 4))
                memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_CUPS, FLD_TRANS_STATE_LEN);
            else
                memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
        }
    }


    /* תPIN */
    if(memcmp (sMsgSrcId, "1701", 4) == 0 &&
        memcmp(ptIpcIntTxn->sTxnNum, "1284", 4) == 0 &&
        memcmp(ptIpcIntTxn->sRespCode, "00", 2) == 0)
    {
        memcpy(tSendIpcIntTxn.sMsgDestId, gatTxnInf[nReqIndex].msg_dest2, 4);
        memcpy(tSendIpcIntTxn.sSecRelatdCtrlInfo, "2600000000000000", F053_LEN);
        
        nReturnCode = TransferPin4ZK (&tSendIpcIntTxn );
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "TransferPin4ZK error, %d. Discard this transaction.", nReturnCode);
                    
            /* �����ʱ   
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
            if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "ToCtrlReq error, %d. Discard this message.", nReturnCode);
                return -1;
            } */
            
            return -1;
        }
    }

                
    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    if(!memcmp (sMsgSrcId, "1701", 4))
    {
        /* save debit card no from 1701 rsp */
        if(memcmp(ptIpcIntTxn->sTxnNum, "1284", 4) == 0 &&
            memcmp(ptIpcIntTxn->sRespCode, "00", 2) == 0)
        {
            /* �����ǿ��˺� */
            memcpy(tTxn.rsp_buf, ptIpcIntTxn->sAcctId1, F002_VAL_LEN);
            /* ��������ֽ𿨷������� */
            memcpy(tTxn.rsp_buf+F002_VAL_LEN, tSendIpcIntTxn.sFwdInstIdCode, 6);
            /* ���潻�׻����� */
            memcpy(tTxn.rsp_buf+F002_VAL_LEN+6, tSendIpcIntTxn.sHostSSN, 6);
            memcpy( tTxn.misc_flag+14, "1383", 4 );
        }
        if(memcmp(ptIpcIntTxn->sTxnNum, "1394", 4) == 0)
        {
            memcpy(tTxn.misc_flag+14+4+2, ptIpcIntTxn->sRespCode, F039_LEN);
        }
        
        
        nReturnCode = DbsTxn (DBS_UPDATE11, &tTxn);
        if (nReturnCode )
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsTxn update error, %d. Discard this message.", nReturnCode);
      
            /* send reversal on success reply */
            if (nSendRevsalFlag && !memcmp (ptIpcIntTxn->sTxnNum, "1394", 4))
            {
                nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if (nReturnCode)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
            }
            return -1;
        }
    }
    else
    {
        
        memcpy(tTxn.misc_flag+14+4, ptIpcIntTxn->sRespCode, F039_LEN);
        /*memcpy(tTxn.misc_flag+14+4+4, tTxn.host_date, 8);*/
        nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
        if (nReturnCode )
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsTxn update error, %d. Discard this message.", nReturnCode);
        
            /* send reversal on success reply */
            if (nSendRevsalFlag)
            {
                nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if (nReturnCode)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
            }
            return -1;
        }
    }
    
    /***************
	* ����IC���ű�
	****************/
	if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    /*CommonGetCurrentTime(sCurrentTime);*/
	    memcpy (sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
	    sprintf(sF055Len, "%03d", atoi(sF055Len)*2);
	    memcpy(tIcTxn.rsp_iclen, sF055Len, F055_LEN_LEN);
	    Hex2Str(ptIpcIntTxn->sICData, tIcTxn.rsp_icdata, atoi(sF055Len)/2);
	    memcpy(tIcTxn.update_time, sCurrentTime, 14);
	    memcpy(tIcTxn.key_rsp, tTxn.key_rsp, KEY_RSP_LEN);
	    
	    nReturnCode = DbsIcTxn (DBS_UPDATE, &tIcTxn);
	    if (nReturnCode )
	    {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                  "DbsIcTxn update error, %d. Discard this message.", nReturnCode);
      
            /* send reversal on success reply */
            if (nSendRevsalFlag && !memcmp (ptIpcIntTxn->sTxnNum, "1394", 4))
            {
                nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if (nReturnCode)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
            }
            return -1;
	    }
	}
    DbsCommit ();

    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_HAD_TO)
    {
        /* ��ʱӦ�� */
        /* send reversal on late success reply */
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Received late response.");
        if (nSendRevsalFlag)
        {
            nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_LATE_RSP);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
            }
            HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Reversal for late successful response sent out.");
        }
    }
    else
    {
        /* Ӧ��δ��ʱ */
        /* �Ƿ�ת��Ӧ�� */
        nSendRspFlag = 0;
        switch (gatTxnInf[nReqIndex].rsp_type[0])
        {
            case RSP_TYPE_NO_ACCOUNT:
                nSendRspFlag = 1;
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
                    nSendRspFlag = 1;
                else
                    nSendRspFlag = 0;
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                if( !IsRspSuccess (ptIpcIntTxn->sRespCode) )
                    nSendRspFlag = 1;
                else if(!memcmp (sMsgSrcId, "1701", 4) && IsRspSuccess (ptIpcIntTxn->sRespCode) && !memcmp (ptIpcIntTxn->sTxnNum, "1394", 4) )
                    nSendRspFlag = 1;
                else
                    nSendRspFlag = 0;
                break;
            default:
                break;
        }

        if (nSendRspFlag)
        {
            /***********************
             *  �ͻ���Ŀ��IPC��������
             ************************/

            memcpy ((char *)&tSendIpcInt2, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));

            /* ����Ӧ���״��� */
            memcpy( tSendIpcInt2.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN );

            /* ����Ӧ��SrvId */
            memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendIpcInt2.sMsgType[2]++;

            HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,  __LINE__, (char*)&tSendIpcInt2, sizeof(tSendIpcInt2));
            nReturnCode = SendMsg (&tSendIpcInt2, &tTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);

                /* send reversal on success reply */
                if (nSendRevsalFlag)
                {
                    nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                    if (nReturnCode)
                    {
                        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                    }
                }

                return -1;
            }

            HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
        }

        /* �Ƿ񷢼��� */
        nSendAccountFlag = 0;
        switch (gatTxnInf[nReqIndex].rsp_type[0])
        {
            case RSP_TYPE_NO_ACCOUNT:
                nSendAccountFlag = 0;
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) &&
                        IsRspSuccess (ptIpcIntTxn->sRespCode))
                    nSendAccountFlag = 1;
                else
                    nSendAccountFlag = 0;
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                if ((!memcmp (sMsgSrcId, "1701", 4) &&
                    !memcmp (ptIpcIntTxn->sTxnNum, "1284", 4) &&
                        IsRspSuccess (ptIpcIntTxn->sRespCode)) ||
                        (!memcmp (sMsgSrcId, SRV_ID_COMM_ZK, 4) && IsRspSuccess (ptIpcIntTxn->sRespCode)))
                    nSendAccountFlag = 1;
                else
                    nSendAccountFlag = 0;
                break;
            default:
                break;
        }

        if (nSendAccountFlag)
        {
            /* ����Ӧ��SrvId */
            memcpy ((char *)&tSendIpcInt2, &tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
            if(!memcmp (sMsgSrcId, "1701", 4))
            {
                memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].msg_dest2, SRV_ID_LEN );
            }
            else
            {
                memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].msg_dest1, SRV_ID_LEN );
                memcpy( tSendIpcInt2.sTxnNum, "1393", 4 );
                
                memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
                memcpy(tIcTxn.key_rsp, tTxn.key_rsp, KEY_RSP_LEN);
                nReturnCode = DbsIcTxn (DBS_SELECT, &tIcTxn);
	            if( !nReturnCode )
	            {
	                tSendIpcInt2.cICDataInd = 'Y';
	                memcpy(sF055Len, tIcTxn.req_iclen, F055_LEN_LEN);
	                sprintf(sF055Len, "%03d", atoi(sF055Len)/2);
	                memcpy(tSendIpcInt2.sICDataLen, sF055Len, F055_LEN_LEN);
	                Str2Hex(tIcTxn.req_icdata, tSendIpcInt2.sICData, atoi(sF055Len)*2);
	            }
	            else
	            {
	                nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                    if (nReturnCode)
                    {
                        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                    }
                    return -1;
	            }
                
                /*********************
	            *��ֵ��������ֵ F122
	            **********************/
	            memcpy(tSendIpcInt2.sKeyRsp, tTxn.key_rsp, KEY_RSP_LEN);
                PCSPacketWrapper(&tSendIpcInt2, &tTxn);
                
            }
            /* clear F038 */
            tSendIpcInt2.cF038Ind = FLAG_NO_C;
            /* clear F039 */
            memset (tSendIpcInt2.sRespCode, ' ', F039_LEN);
            
            
            nReturnCode = SendMsg (&tSendIpcInt2, &tTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);

                /* send reversal on success reply */
                if (nSendRevsalFlag)
                {
                    nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                    if (nReturnCode)
                    {
                        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                    }
                }

                return -1;
            }

            HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction account request sent out.");

            nReturnCode = InsertSafMsg (&tSendIpcInt2, &tTxn, gatTxnInf[nReqIndex].saf_count2);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
            }
        }


        /* �Ƿ���Ҫ��ʧ�ܵļ���Ӧ�����������ͳ��� */
        nSendRevsalFlag = 0;
        switch (gatTxnInf[nReqIndex].rsp_type[0])
        {
            case RSP_TYPE_NO_ACCOUNT:
                nSendRevsalFlag = 0;
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                nSendRevsalFlag = 0;
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                if (IsRspSuccess (ptIpcIntTxn->sRespCode) == 0 &&
                    memcmp (ptIpcIntTxn->sTxnNum, "1394", 4) == 0) /* �����ֽ�Ӧ��ʧ�� */
                {
                    nSendRevsalFlag = 1;
                }
                else if (!memcmp (sMsgSrcId, "1701", 4) || 
                    IsRspSuccess (ptIpcIntTxn->sRespCode) ||
                    (!IsRspSuccess (ptIpcIntTxn->sRespCode) && !memcmp (sMsgSrcId, SRV_ID_COMM_ZK, 4)))
                    nSendRevsalFlag = 0;
                else
                    nSendRevsalFlag = 1;
                break;
            default:
                break;
        }

        if (nSendRevsalFlag)
        {
                nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendRevsalOnError error, %d. Discard this message.", nReturnCode);
                return -1;
            }
            HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reversal request sent out.");
        }

    }

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    /*showIpc( ptIpcIntTxn );*/
    return 0;
}
