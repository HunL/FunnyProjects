static char * id = "$Id: CfgProfile.c,v 1.1.1.1 2011/08/19 10:55:50 ctedev Exp $";

#include <stdarg.h>
#include <math.h>
#include <memory.h>
#include <string.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/sem.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <memory.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#include <assert.h>
#include <time.h>
#include <signal.h>

#define PF_FALSE     0

#ifndef	PSTR__TYPE
#define	PSTR__TYPE
	typedef char * PSTR;
#endif

extern int	errno;

/**********************
**��ȡ�ļ���****
**********************/
void GetBaseName(char *vsSrc, char *vsDest)
{
	int i, j;
	j = strlen(vsSrc);
	for(i=j-1; i>=0; i--)
	{
		if(vsSrc[i] == '/')
			break;
	}
	if(i == j-1)
		vsDest[0] = 0;
	else
		strcpy(vsDest, &vsSrc[i+1]);
	return;
}

/********************
* ����ո�          *
********************/
void ClearBlank(char * line)
{
	int i = 0, j, k;
	char buf[256];

	while (line[i] != 0)
	{
		if (line[i] == ';' || line[i] == '\n')
		{
			line[i] = 0;
			for (j = i - 1; (line[j] == ' ') || (line[j] == '\t'); line[j--] = 0);
			break;
		}
		i++;
	}

	i = 0;
	memset(buf, 0, 256);

	while ((line[i] != '=') && (i < strlen(line))) i++;
	if (i == strlen(line)) return;

	for (j = i - 1; (line[j] == ' ') || (line[j] == '\t'); j--);
	for (k = i + 1; (line[k] == ' ') || (line[k] == '\t'); k++);

	memcpy(buf, line, j + 1);
	buf[j + 1] = '=';
 	strcat(buf + j + 2, line + k);

	strcpy(line, buf);
}

/********************
* �ж��Ƿ��½ڱ�־  *
********************/
int IsSection(char * line)
{
	return line[0] == '[';
}

/*******************
* �ж��Ƿ������½� *
*******************/
int IsThisSection(char * line, char * pszSection)
{
	/*
	char buf[256];

	memset(buf, 0 ,sizeof(buf));

	buf[0] = '[';
	strcpy(buf + 1,pszSection);
	buf[strlen(pszSection)+ 1] = ']';

	return !strcmp(line,buf);
	*/

	return !memcmp(line + 1, pszSection, strlen(pszSection));

}

/*******************
* �ж��Ƿ�������Ŀ *
*******************/
int IsThisEntry(char * line, char * pszEntry)
{
	return (!memcmp(line, pszEntry, strlen(pszEntry)) &&
           line[strlen(pszEntry)] == '=') ;
}

/*******************
* ��ȡ��������     *
*******************/
int CutContent(char * line, char * pszDestination, int cbReturnBuf)
{
	int i = 0;

	while (line[i++] != '=');

	strncpy(pszDestination, line + i, cbReturnBuf);

	return 0;
}

/*************************
* ��ȡ���ò������ַ����� *
*************************/
int cfgGetProfileString(PSTR pszSection, PSTR pszEntry,
                     PSTR pszDestination, int cbReturnBuf, PSTR pszFileName)
{
	static FILE * fp;
	char line[256];
	int cbNum = -1;
	int InThisSection = PF_FALSE;

	fp = fopen(pszFileName, "r");
	if (fp == NULL)
	{
		printf("open file fail! filename = [%s]\n", pszFileName);
		return -1;
		/***
		exit(-1);
		***/
	}

	while (NULL !=	fgets(line, 256, fp))
	{
		ClearBlank(line);

		if (IsSection(line))
		{
			/* printf("section is %s\n", line); */
			InThisSection = IsThisSection(line, pszSection);
			continue;
		}

		if (InThisSection == PF_FALSE) continue;

		/* printf("line = %s\n", line ); */
		if (IsThisEntry(line, pszEntry))
		{
			cbNum = CutContent(line, pszDestination, cbReturnBuf);
			break;
		}
	}

	fclose(fp);

	if (cbNum == -1)
	{
		printf ("Read INI fail !\n file = [%s], section = [%s] , entry = [%s]\n",
		pszFileName, pszSection, pszEntry) ;
		printf(" error msg = [%s]\n", strerror(errno) );
		return -1;
		/***
		exit(-1);
		***/
	}

	return cbNum;

}

/*************************
* ��ȡ���ò�����������   *
*************************/
int cfgGetProfileInt(PSTR pszSection, PSTR pszEntry, PSTR pszFileName)
{
	char buf[256];
	int Number;

	if (cfgGetProfileString(pszSection, pszEntry, buf, 256, pszFileName) < 0)
		return -1;
	else
	{
		if (strncmp(buf, "0x", 2))
			Number = atoi(buf);
		else
			sscanf(buf, "%x", &Number);
		return Number;
	}
}

/*************************
* ��ȡ���ò������������� *
*************************/
long cfgGetProfileLong(PSTR pszSection, PSTR pszEntry, PSTR pszFileName)
{
	char buf[256];
	long Number;

	if (cfgGetProfileString(pszSection, pszEntry, buf, 256, pszFileName) < 0)
		return -1;
	else
		if (strncmp(buf, "0x", 2))
			Number = atol(buf);
		else
			sscanf(buf, "%x", &Number);
		return Number;
}
