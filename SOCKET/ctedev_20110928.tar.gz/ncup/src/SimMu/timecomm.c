static char * id = "$Id: timecomm.c,v 1.1.1.1 2011/08/19 10:55:50 ctedev Exp $";

#include <stdio.h>
#include <errno.h>
#include <time.h>
#include <math.h>
#include <sys/stat.h>
#include <string.h>

#define ___IsLeapYear(N) (((N % 4 == 0) && (N % 100 != 0)) || (N % 400 == 0)) /*�Ƿ�Ϊ����*/

#define YEARDAYS(a) ___IsLeapYear(a)?366:365      /*һ�������*/
#define MON2DAYS(a) ___IsLeapYear(a)?29:28        /*���µ�����*/

/*һ���µ�����*/
#define RMONTHDAYS(a, b) ((a) == 2?(MON2DAYS(b)):((a) < 8 && (a) % 2 == 0 || (a) >= 8 && (a) % 2 != 0)?30:31)

void GetGMTCurrentTime(char *sCurrentTime);
char * GetLastDay ( char * caNowDate , char *caLastDay );

time_t GetTimeInLong (char *sTime,int GmtFlag);

int buf_change(char * ChangeType,  char * SourStr, char * DestStr);

/*******************************************************************
*  Function: void *GetGMTCurrentTime(char *sCurrentDate)              *
*  Desc    : Get the current time with the format (YYYYMMDDHHMMSS) *
*      Input : None                                                *
*      Output: sCurrentTime                                        *
*  Return  : the string of the current time                        *
*  Calling :                                                       *
*******************************************************************/
void GetGMTCurrentTime(char *sCurrentTime)
{
   time_t current;
   struct tm *tmCurrentTime;

   time(&current);
   tmCurrentTime = gmtime(&current);
   sprintf(sCurrentTime, "%4d%02d%02d%02d%02d%02d",
				 tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1,
				 tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
           tmCurrentTime->tm_min, tmCurrentTime->tm_sec);

}

/*********************
* ��ȡGMTʱ��        *
*********************/
void GetGMTInTime(char *sCurrentTime)
{
   time_t current;
   struct tm *tmCurrentTime;

   current = GetTimeInLong(sCurrentTime,0);
   tmCurrentTime = gmtime(&current);
   sprintf(sCurrentTime, "%4d%02d%02d%02d%02d%02d",
				 tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1,
				 tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
           tmCurrentTime->tm_min, tmCurrentTime->tm_sec);

}

char *GetDate_FULL( char * buff ) /* �����ʽ ��YYYYMMDD */
{
    time_t time(), now;
    struct tm * tTime, * localtime();

    time( &now );
    tTime = localtime( &now );

    tTime->tm_year = tTime->tm_year + 1900;

    sprintf( buff, "%.4d%.2d%.2d", tTime->tm_year,
        tTime->tm_mon+1, tTime->tm_mday );
    return buff;
}


/********************************************************************

  Description : convert time from string (YYYYMMDDhhmmss)
		to time_t

  Input   : sTime -- time, YYYYMMDDhhmmss
  Return  : time in time_t

********************************************************************/
time_t GetTimeInLong (char *sTime ,int GmtFlag)
{
    char str[20];
    struct tm tmTmp;

	memset (&tmTmp, '\0', sizeof (tmTmp));

	/* get year, year start from 1900 in struct tm */
	memcpy (str, sTime, 4);
	str[4] = '\0';
	tmTmp.tm_year = atoi (str) - 1900;
	/* get month, month start from 0 in struct tm */
	memcpy (str, sTime + 4, 2);
	str[2] ='\0';
	tmTmp.tm_mon = atoi (str) - 1;
	/* get day */
	memcpy (str, sTime + 6, 2);
	str[2] = '\0';
	tmTmp.tm_mday = atoi (str);
	/* get hour */
	memcpy (str, sTime + 8, 2);
	str[2] = '\0';
	tmTmp.tm_hour = atoi (str);
	/* get minute */
	memcpy (str, sTime + 10, 2);
	str[2] = '\0';
	tmTmp.tm_min = atoi (str);
	/* get second */
	memcpy (str, sTime + 12, 2);
	str[2] = '\0';
	tmTmp.tm_sec = atoi (str);
	if (GmtFlag)
	   return mktime(&tmTmp) + 8*60*60;
    else
	   return mktime(&tmTmp);
}

/****************************
* ת�����ɸ��ָ�ʽ����ʱ��  *
****************************/
int buf_change(char * ChangeType,  char * SourStr, char * DestStr)
  {
  	time_t  current_time;
  	char	str_time[20];
  	struct tm *tmp_struct_time;


  	if (memcmp(ChangeType, "YYYYMMDD", 8) == 0 )
  	{
  		if (strcmp(SourStr, "CT") == 0)
	  	{
	  		time(&current_time);
	  		tmp_struct_time = localtime(&current_time);
	  	}
	  	else
	  	{
	  		current_time = GetTimeInLong (SourStr , 0);
	  		tmp_struct_time = localtime(&current_time);
	  	}
  		sprintf(DestStr, "%04d%02d%02d", tmp_struct_time->tm_year + 1900, tmp_struct_time->tm_mon + 1,
  								tmp_struct_time->tm_mday);
  		return 0;
  	}

  	if (memcmp(ChangeType, "YYMMDD", 6) == 0 )
  	{
  		if (strcmp(SourStr, "CT") == 0)
	  	{
	  		time(&current_time);
	  		tmp_struct_time = localtime(&current_time);
	  	}
	  	else
	  	{
	  		current_time = GetTimeInLong (SourStr , 0);
	  		tmp_struct_time = localtime(&current_time);
	  	}
  		sprintf(DestStr, "%02d%02d%02d", (tmp_struct_time->tm_year + 1900)  % 100, tmp_struct_time->tm_mon + 1,
  								tmp_struct_time->tm_mday);
  		return 0;
  	}

  	if (memcmp(ChangeType, "MMDDYYYY", 8) == 0 )
  	{
  		if (strcmp(SourStr, "CT") == 0)
	  	{
	  		time(&current_time);
	  		tmp_struct_time = localtime(&current_time);
	  	}
	  	else
	  	{
	  		current_time = GetTimeInLong (SourStr , 0);
	  		tmp_struct_time = localtime(&current_time);
	  	}
  		sprintf(DestStr, "%02d%02d%04d",  tmp_struct_time->tm_mon + 1,
  								tmp_struct_time->tm_mday, tmp_struct_time->tm_year + 1900);
  		return 0;
  	}

  	if (memcmp(ChangeType, "YYDDD", 5) == 0)
  	{
  		if (strcmp(SourStr, "CT") == 0)
	  	{
	  		time(&current_time);
	  		tmp_struct_time = localtime(&current_time);
	  	}
	  	else
	  	{
	  		current_time = GetTimeInLong (SourStr , 0);
	  		tmp_struct_time = localtime(&current_time);
	  	}
  		sprintf(DestStr, "%02d%03d", (tmp_struct_time->tm_year + 1900) % 100, tmp_struct_time->tm_yday + 1);
  		return 0;
  	}

    if (memcmp(ChangeType, "YDDD", 4) == 0)
  	{
  		if (strcmp(SourStr, "CT") == 0)
	  	{
	  		time(&current_time);
	  		tmp_struct_time = localtime(&current_time);
	  	}
	  	else
	  	{
	  		current_time = GetTimeInLong (SourStr , 0);
	  		tmp_struct_time = localtime(&current_time);
	  	}
  		sprintf(DestStr, "%01d%03d", (tmp_struct_time->tm_year + 1900) % 10, tmp_struct_time->tm_yday + 1);
  		return 0;
  	}

  	if (memcmp(ChangeType, "MMDD", 4) == 0)
  	{
  		if (strcmp(SourStr, "CT") == 0)
	  	{
	  		time(&current_time);
	  		tmp_struct_time = localtime(&current_time);
	  	}
	  	else
	  	{
	  		current_time = GetTimeInLong (SourStr , 0);
	  		tmp_struct_time = localtime(&current_time);
	  	}
  		sprintf(DestStr, "%02d%02d", tmp_struct_time->tm_mon + 1,  tmp_struct_time->tm_mday);
  		return 0;
  	}

  	if (memcmp(ChangeType, "CMMDD", 5) == 0)
  	{

	  	time(&current_time);
	  	tmp_struct_time = localtime(&current_time);

  		sprintf(DestStr, "%02d%02d", tmp_struct_time->tm_mon + 1,  tmp_struct_time->tm_mday);
  		return 0;
  	}

  	if (memcmp(ChangeType, "HHMMSS", 6) == 0)
  	{
  		if (strcmp(SourStr, "CT") == 0)
	  	{
	  		time(&current_time);
	  		tmp_struct_time = localtime(&current_time);
	  	}
	  	else
	  	{
	  		current_time = GetTimeInLong (SourStr , 0);
	  		tmp_struct_time = localtime(&current_time);
	  	}
  		sprintf(DestStr, "%02d%02d%02d", tmp_struct_time->tm_hour, tmp_struct_time->tm_min, tmp_struct_time->tm_sec);
  		return 0;
  	}

  	if (memcmp(ChangeType, "PYYYY", 5) == 0)
  	{
  		time(&current_time);
	  	tmp_struct_time = localtime(&current_time);

	  	if (atoi(SourStr) > tmp_struct_time->tm_mon + 1)
	  	{
	  		sprintf(DestStr, "%04d", tmp_struct_time->tm_year + 1900 - 1);
	  	}
	  	else
	  	{
	  		sprintf(DestStr, "%04d", tmp_struct_time->tm_year + 1900);
	  	}
	  	return 0;
  	}

  	if (memcmp(ChangeType, "MM/DD/YY", 8) == 0 )
    {
        if (strcmp(SourStr, "CT") == 0)
        {
            time(&current_time);
            tmp_struct_time = localtime(&current_time);
        }
        else
        {
            current_time = GetTimeInLong (SourStr , 0);
            tmp_struct_time = localtime(&current_time);
        }
        sprintf(DestStr, "%02d/%02d/%02d",  tmp_struct_time->tm_mon + 1,tmp_struct_time->tm_mday, (tmp_struct_time->tm_year + 1900)  % 100);
        return 0;
    }

	if (memcmp(ChangeType, "HH:MM:SS", 8) == 0)
    {
        if (strcmp(SourStr, "CT") == 0)
        {
            time(&current_time);
            tmp_struct_time = localtime(&current_time);
        }
        else
        {
            current_time = GetTimeInLong (SourStr , 0);
            tmp_struct_time = localtime(&current_time);
        }
        sprintf(DestStr, "%02d:%02d:%02d", tmp_struct_time->tm_hour, tmp_struct_time->tm_min, tmp_struct_time->tm_sec);
        return 0;
    }

	/** New Add By GaoCheng **/
  	if (memcmp(ChangeType, "PMMYY", 5) == 0)
  	{
  		sprintf(DestStr, "%2.2s%2.2s", SourStr+2, SourStr );
  		return 0;
  	}
	/** End New Add By GaoCheng **/

  	printf("cannot find changetype, %s\n", ChangeType);
  	return -1;

}
/*
int gen_check_digit(char * check_buf, int buf_len)
{
	int  str_sum, str_num;
	int	 check_digit;
	int  i;
	char tmp_str[2];
	str_num = 0;
	str_sum = 0;
	for(i = buf_len -1;i>=0;i--)
	{
		memset(tmp_str, 0, 2);
		memcpy(tmp_str, &check_buf[i], 1);
		str_num = atoi(tmp_str) * ((buf_len - i) % 2 + 1);
		str_sum += str_num /10 + str_num % 10;
	}
	check_digit = (10 - str_sum % 10 ) % 10;
	return check_digit;
}
*/
/* add Year info to a Date without it
   date form is MMDDhhmmss
   return form is YYYYMMDDhhmmss*/
int AddYearToDate(
                char *spInDate,
                char *spOutDate){

        int    liError;
    	long   nowtime;
        struct tm *tmCurrentTime;
        char   TmpDateMon[3];
        int    InDateMonth;
        int    DiffMon;

	time(&nowtime);
	tmCurrentTime = localtime(&nowtime);
	memcpy(
	     &TmpDateMon[0],
	     &spInDate[0],
	     2);
        TmpDateMon[2] = 0;
	InDateMonth = atoi(TmpDateMon);

	DiffMon = InDateMonth - tmCurrentTime->tm_mon;
        if(abs(DiffMon)<= 6){
            sprintf(
                spOutDate,
                "%04d",
                tmCurrentTime->tm_year + 1900);
        }
        else if (DiffMon > 6) {
            sprintf(
                spOutDate,
                "%04d",
                tmCurrentTime->tm_year - 1 + 1900);
        }
        else{
            sprintf(
                spOutDate,
                "%04d",
                tmCurrentTime->tm_year + 1 + 1900);
        }
        memcpy(
             spOutDate + 4,
             spInDate,
             10);
}/*end of AddYearToDate*/

/****************************
* ��F007�ӱ���ʱ��ת��ΪGMT *
****************************/
int  ChgField7ToGmt(char *field7)
{
   char curtime[15];

   memset(curtime, 0,15);
   memcpy(curtime, field7, 10);
   AddYearToDate(field7, curtime);
   GetGMTInTime(curtime);
   memcpy(field7, &curtime[4], 10);
}

/****************************
* ��F007��GMTת��Ϊ����ʱ�� *
****************************/
int  ChgGmtToField7(char *field7)
{
   time_t tfield7;
   struct tm *tmptm;
   char curtime[15];

   memset(curtime, 0, 15);
   AddYearToDate(field7, curtime);
   tfield7 = GetTimeInLong(curtime,1);
   tmptm = localtime(&tfield7);
   sprintf(curtime, "%02d%02d%02d%02d%02d",
				 tmptm->tm_mon + 1,
				 tmptm->tm_mday, tmptm->tm_hour,
                 tmptm->tm_min, tmptm->tm_sec);
   memcpy(field7, curtime, 10);
}

/****************************
* ̫���� -> ��������        *
****************************/
int Suncal_To_Juliancal( char * source_time , char * dest_time)
{
	struct tm tmtmp;
	struct tm * tmpResult;
	time_t lTime;
	char   caYear[5];
	char   caDays[4];
	char   tmpDate[9];

	memset(&tmtmp, 0, sizeof(tmtmp));

	tmtmp.tm_sec = 0;
	tmtmp.tm_min = 0;
	tmtmp.tm_hour = 0;
	tmtmp.tm_mday = 1;
	tmtmp.tm_mon = 0;

	memset(caYear , 0 , sizeof(caYear));
	memcpy(&caYear[0] , &source_time[0] , 4 );
	tmtmp.tm_year = atoi(caYear) - 1900;

	lTime = mktime(&tmtmp);

	memset(caDays , 0 , sizeof(caDays));
	memcpy(&caDays[0] , &source_time[4] , 3);

	lTime = lTime + (atoi(caDays)-1) * 24 * 60 * 60;

	tmpResult = localtime(&lTime);
	memset(tmpDate , 0 , sizeof(tmpDate));

	sprintf(&tmpDate[0] , "%04d" , tmpResult->tm_year + 1900 );
	sprintf(&tmpDate[4] , "%02d" , tmpResult->tm_mon + 1 );
	sprintf(&tmpDate[6] , "%02d" , tmpResult->tm_mday );

	memcpy(dest_time , &tmpDate[0] , sizeof(tmpDate) -1 );

}

Juliancal_To_Suncal_Local( char *insert_time, char *buf )
{
	struct tm  *tmCurrent;
	time_t  lTime;
	char szDayOfYear[5];
	char szHourTmp[3];
 	char szAuRRN[13];

	memset( szDayOfYear, 0, 5);
	memset(szHourTmp, 0, 3);
	memset(szAuRRN, 0, 13);
	lTime = GetTimeInLong (insert_time,0);
	tmCurrent = localtime(&lTime);
	sprintf( szDayOfYear, "%03d", tmCurrent->tm_yday + 1 );
	sprintf(szHourTmp, "%02d", tmCurrent->tm_hour);
	memcpy( szAuRRN, &insert_time[3], 1);
	memcpy( &szAuRRN[1], szDayOfYear, 3);
	memcpy( &szAuRRN[4], &szHourTmp[0], 2);
	memcpy( &szAuRRN[6], &insert_time[8], 6);
	memcpy( &szAuRRN[10], "00", 2);
	szAuRRN[12] = 0;
        memcpy( buf, szAuRRN, 6 ); buf[6]=0;
	return ;
}

void GetCurrentTime(char *sCurrentTime)
{
   time_t current;
   struct tm *tmCurrentTime;

   tzset();
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentTime, "%4d%02d%02d%02d%02d%02d",
   tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1,
   tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
   tmCurrentTime->tm_min, tmCurrentTime->tm_sec);

}

/************************************************************
**   INPUT:
**   iType: 0-����Ϊ��̫���յ��ļ���
**          1-����Ϊ̫����DDD
************************************************************/
int ChangeDDD2YYYYMMDD( int iType, char* vspInStr, char* vspOutStr)
{

    int                               liDayGap;
    int                               lnNameLen;
    int                               llResult;
    char                              lsaFileDay[4];
    char                              lspTimestamp[14];
    char                              lspCmd[100];
    char*                             lspTmp;
    struct                            stat pp;
    struct                            tm*  ltmpCurrent;
    time_t                            ltimeTimeVal;

	memset(lsaFileDay, 0x00, sizeof(lsaFileDay));
	memset(lspTimestamp, 0x00, sizeof(lspTimestamp));
	memset(lspCmd, 0x00, sizeof(lspCmd));
    memset( &lsaFileDay[0], 0, 4);

	if(iType == 0)
	{
	   lspTmp=strchr(vspInStr, '.');
	   if(lspTmp == NULL || 12 <= strlen(vspInStr) )
		   memcpy( &lsaFileDay[0], &vspInStr[9], 3);
	   else
	   {
		   if( strlen(lspTmp)-1 >= 3 )
				memcpy( &lsaFileDay[0], lspTmp+1, 3);
		   else if( strlen(lspTmp)-1 >= 0 )
				memcpy( &lsaFileDay[0], lspTmp+1, strlen(lspTmp) - 1);
		   else
		   {
				WRITE_LOG(1, "FILE FORMAT ERROR");
				return -1;
		   }
	   }

	   if(atoi(lsaFileDay) <= 0  || atoi(lsaFileDay) > 366)
	   {
           WRITE_LOG(2, "InPut Parameter FileName Format Error() [%s]", vspInStr);
		   return (-1);
	   }
    }
	else if(iType == 1)
	{
        memcpy( &lsaFileDay[0], &vspInStr[0], 3);
	    if(atoi(lsaFileDay) <= 0  || atoi(lsaFileDay) > 366)
		{
            WRITE_LOG(2, "InPut Parameter Sun day Error() [%s]", vspInStr);
			return (-1);
        }
	}
	else
	{
        WRITE_LOG(2, "InPut Parameter Sun Day Or File Name Error() ");
		return (-1);
	}

    if ((ltimeTimeVal = time(NULL)) == -1)
	{
            WRITE_LOG(1, "Call time() [%d]", errno);
            return(-10);
    }

    if ((ltmpCurrent = localtime(&ltimeTimeVal)) == NULL)
	{
            WRITE_LOG(1, "Call time() [%d]", errno);
            return(-10);
    }

    liDayGap = ltmpCurrent->tm_yday + 1 - atoi(lsaFileDay);
    ltimeTimeVal -= liDayGap * 60 * 60 * 24;
	if (atoi(lsaFileDay) == 366)
	{
        if (liDayGap > 200)
            ltimeTimeVal += 366 * 60 * 60 * 24;
        if (liDayGap < -200)
            ltimeTimeVal -= 366 * 60 * 60 * 24;
	}
	else
	{
        if (liDayGap > 200)
            ltimeTimeVal += 365 * 60 * 60 * 24;
        if (liDayGap < -200)
            ltimeTimeVal -= 365 * 60 * 60 * 24;
	}

    if ((ltmpCurrent = localtime(&ltimeTimeVal)) == NULL)
	{
        WRITE_LOG(1, "Call time() [%d]", errno);
        return(-10);
    }

    sprintf( vspOutStr, "%04d", ltmpCurrent->tm_year + 1900);
    sprintf( vspOutStr+4, "%02d", ltmpCurrent->tm_mon + 1);
    sprintf( vspOutStr+6,  "%02d", ltmpCurrent->tm_mday);

    return 0;
}

void cu_x_day(int m_num, char * m_strTime)
{
    time_t current;
    struct tm *tmCurrentTime;

    current = GetTimeInLong(m_strTime , 0);

    current = current - ( 24 * 60 * 60 * m_num);

    tmCurrentTime = localtime(&current);
    sprintf(m_strTime, "%4d%02d%02d", tmCurrentTime->tm_year + 1900,
        tmCurrentTime->tm_mon + 1, tmCurrentTime->tm_mday);
}

/*
	��������ʱ��֮������������
	����ʱ���ʽ��YYYYMMDD
*/
int nDiffDate( char *date1, char *date2 )
{
   time_t       st1,st2;
   struct tm    s_tm1,s_tm2;
   char         year1[5],year2[5];
   char         mon1[3],mon2[3];
   char         day1[3],day2[3];

   memset(year1,0,5);
   memset(mon1,0,3);
   memset(day1,0,3);
   memset(year2,0,5);
   memset(mon2,0,3);
   memset(day2,0,3);

   memcpy(year1,date1,4);
   memcpy(mon1,date1+4,2);
   memcpy(day1,date1+6,2);
   memcpy(year2,date2,4);
   memcpy(mon2,date2+4,2);
   memcpy(day2,date2+6,2);

   s_tm1.tm_sec=10;
   s_tm1.tm_min=10;
   s_tm1.tm_hour=10;
   s_tm1.tm_mday=atoi(day1);
   s_tm1.tm_mon=atoi(mon1)-1;
   s_tm1.tm_year=atoi(year1)-1900;
   s_tm1.tm_isdst=0;

   s_tm2.tm_sec=10;
   s_tm2.tm_min=10;
   s_tm2.tm_hour=10;
   s_tm2.tm_mday=atoi(day2);
   s_tm2.tm_mon=atoi(mon2)-1;
   s_tm2.tm_year=atoi(year2)-1900;
   s_tm2.tm_isdst=0;

   st1=mktime(&s_tm1);
   st2=mktime(&s_tm2);

   return ((int)difftime(st2,st1)/(3600*24));
}


/***************************************************
*��������: CheckDate
*��������: У�����ڵĺϷ���
*�������: sDate -- ���� yyyymmdd
*�������: ��
*����: 0 --- �Ϸ�
      -1 -- ���Ϸ�
 ***************************************************/
int CheckDate(char *sDate)
{
    int iRet;

    char sYear[5];
    char sMonth[3];
    char sDay[3];

    memset(sYear,  0, sizeof(sYear));
    memset(sMonth, 0, sizeof(sMonth));
    memset(sDay,   0, sizeof(sDay));

    if (strlen(sDate) != 8)
    {
        return -1;
    }

    memcpy(sYear,  sDate, 4);
    memcpy(sMonth, sDate+4, 2);
    memcpy(sDay,   sDate+6, 2);

    iRet = checkdate(atoi(sYear), atoi(sMonth), atoi(sDay));
    if (iRet != 0)
    {
        return -1;
    }

    return 0;
}


/***************************************************
*��������: checkdate
*��������: У�����ڵĺϷ���
*�������: iYear -- �� iMonth -- �� iDay -- ��
*�������: ��
*����: 0 --- �Ϸ�
      -1 -- ���
      -2 -- �´�
      -3 -- �մ�
 ***************************************************/
int checkdate(int iYear, int iMonth, int iDay)
{
    if (iYear < 0 || iYear > 9999)
        return -1;
    switch (iMonth)
    {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
        if (iDay <= 0 || iDay > 31)
        {
            return -3;
        }
        break;
    case 4:
    case 6:
    case 9:
    case 11:
        if (iDay <= 0 || iDay > 30)
        {
            return -3;
        }
        break;
    case 2:
        if ((iYear % 4 == 0 && iYear % 100 != 0) || iYear % 400 == 0)
        {
            if (iDay <= 0 || iDay > 29)
            {
                return -3;
            }
        }
        else
        {
            if (iDay <= 0 || iDay > 28)
            {
                return -3;
            }
        }
        break;
    default:
        return -2;
    }
    return 0;
}

/*****************************************************
*��������: CountDate
*��������: ����һ�����ڼ��ϻ��߼�ȥһ�����������õ�����
*�������: lStartDate -- ��ʼ����(YYYYMMDD)
           iOffset    -- ƫ����(������ʾ��ȥ)
*�������: sResultDate -- ������������
*����ֵ:   0  -- �ɹ�
           -1 -- ʧ��
*****************************************************/
long CountDate(char *sStartDate, int iOffset, char *sResultDate)
{
    int  step;
    long lStartDate;
    int  iYear, iMonth, iDays;
    long i;

    lStartDate  =  atol(sStartDate);

    iYear  = lStartDate / 10000;
    iMonth = lStartDate % 10000 / 100;
    iDays  = lStartDate % 100;

    if (checkdate(iYear, iMonth, iDays) != 0)
        return -1;

    step = (iOffset >= 0?1:-1);

    for(i = 1; i <= abs(iOffset); i ++)
    {
        iDays += step;
        if (iDays <= 0 || iDays > RMONTHDAYS(iMonth, iYear))
        {
            iMonth += step;
            if (iMonth <= 0)
            {
                iYear += step;
                iMonth = 12;
            }
            else if (iMonth > 12)
            {
                iYear += step;
                iMonth = 1;
            }

            if (iDays <= 0)
                iDays = RMONTHDAYS(iMonth, iYear);
            else
                iDays = 1;
        }
    }

    lStartDate = iYear * 10000 + iMonth * 100 + iDays;

    sprintf(sResultDate, "%8ld", lStartDate);

    return 0;
}


/*****************************************************************************
*�������ơ� GetNextDate
*�������ܡ� ȡ��һ������
*��������� sCurrDate -- ��ǰ����
*��������� sNextDate -- ��һ������
*�� �� ֵ�� 0  -- �ɹ�
           -1 -- ʧ��
*****************************************************************************/
int GetNextDate(char * sCurrDate, char *sNextDate)
{
    int  iRet;
    int  year  = 0;
    int  month = 0;
    int  day   = 0;
    int  lastday = 0;
    long lCurrDate = 0;
    long lNextDate = 0;
    char sLastDate[9];

    /* У�����ڵĺϷ��� */
    iRet = CheckDate(sCurrDate);
    if (iRet != 0)
    {
        return -1;
    }

    lCurrDate = atol(sCurrDate);

    year  = (lCurrDate / 10000);
    month = (lCurrDate / 100) % 100;
    day   = lCurrDate % 100;

    memset(sLastDate, 0, sizeof(sLastDate));

    GetLastDay(sCurrDate, sLastDate);

    lastday = (atol(sLastDate)) % 100;

    if (day < lastday)
    {
        lNextDate = lCurrDate + 1;
    }
    else
    {
        day = 1;
        month++;
        if (month > 12)
        {
            month = 1;
            year++;
        }

        lNextDate = (year*10000) + (month*100) + day;
    }

    sprintf(sNextDate, "%8ld", lNextDate);

    return 0;
}


/* ȡ�������һ�� */
char * GetLastDay ( char * caNowDate , char *caLastDay )
{
    char caMonth[3];
    char caYear[5];
    char caDay[3];

    memcpy(    caYear , caNowDate  , 4 );
    memcpy(    caMonth , caNowDate + 4 , 2 );
    caYear[4] = '\0';
    caMonth[2] = '\0';

    switch( atoi(caMonth)) {
        case 1 :
            strcpy( caDay , "31" );
            break;
        case 2 :
            if(    ___IsLeapYear(atoi( caYear )))
                strcpy( caDay , "29" );
            else
                strcpy( caDay , "28" );
            break;
        case 3 :
            strcpy( caDay , "31" );
            break;
        case 4 :
            strcpy( caDay , "30" );
            break;
        case 5 :
            strcpy( caDay , "31" );
            break;
        case 6 :
            strcpy( caDay , "30" );
            break;
        case 7 :
            strcpy( caDay , "31" );
            break;
        case 8 :
            strcpy( caDay , "31" );
            break;
        case 9 :
            strcpy( caDay , "30" );
            break;
        case 10 :
            strcpy( caDay , "31" );
            break;
        case 11 :
            strcpy( caDay , "30" );
            break;
        case 12 :
            strcpy( caDay , "31" );
            break;
        default:
            return (NULL);
    }
    sprintf( caLastDay , "%4.4s%2.2s%2.2s" , caYear , caMonth , caDay );
    return(caLastDay);
}

/* ȡ��ǰ�·�ָ��n�º�����һ�� */
char * GetMonLastDay ( char * caNowDate ,int iMonNum, char *caLastDay )
{
    char caMonth[3];
    char caYear[5];
    char caDay[3];

    memcpy(    caYear , caNowDate  , 4 );
    memcpy(    caMonth , caNowDate + 4 , 2 );
    sprintf(caYear, "%04d", atoi(caYear)+(((atoi(caMonth)+iMonNum) == 12 ? 0:(atoi(caMonth)+iMonNum))/12));
    sprintf(caMonth, "%02d", (atoi(caMonth)+iMonNum)%12);
    if (memcmp(caMonth, "00", 2) == 0)
    {
    	memcpy(caMonth, "12", 2);
    }
    caYear[4] = '\0';
    caMonth[2] = '\0';

    switch( atoi(caMonth)) {
        case 1 :
            strcpy( caDay , "31" );
            break;
        case 2 :
            if(    ___IsLeapYear(atoi( caYear )))
                strcpy( caDay , "29" );
            else
                strcpy( caDay , "28" );
            break;
        case 3 :
            strcpy( caDay , "31" );
            break;
        case 4 :
            strcpy( caDay , "30" );
            break;
        case 5 :
            strcpy( caDay , "31" );
            break;
        case 6 :
            strcpy( caDay , "30" );
            break;
        case 7 :
            strcpy( caDay , "31" );
            break;
        case 8 :
            strcpy( caDay , "31" );
            break;
        case 9 :
            strcpy( caDay , "30" );
            break;
        case 10 :
            strcpy( caDay , "31" );
            break;
        case 11 :
            strcpy( caDay , "30" );
            break;
        case 12 :
            strcpy( caDay , "31" );
            break;
        default:
            return (NULL);
    }
    sprintf( caLastDay , "%4.4s%2.2s%2.2s" , caYear , caMonth , caDay );
    return(caLastDay);
}

/***************************************************
*��������: CheckStrDate
*��������: У�����ڵĺϷ���
*�������: sDate -- ���� yyyymmdd
*�������: ��
*����: 0 --- �Ϸ�
      -1 -- ���Ϸ�
 ***************************************************/
int CheckStrDate(char *sDate)
{
    int iRet;

    char sYear[5];
    char sMonth[3];
    char sDay[3];

    memset(sYear,  0, sizeof(sYear));
    memset(sMonth, 0, sizeof(sMonth));
    memset(sDay,   0, sizeof(sDay));

    if (strlen(sDate) != 8)
    {
        return -1;
    }

    memcpy(sYear,  sDate, 4);
    memcpy(sMonth, sDate+4, 2);
    memcpy(sDay,   sDate+6, 2);

    iRet = checkdate(atoi(sYear), atoi(sMonth), atoi(sDay));
    if (iRet != 0)
    {
        return -1;
    }

    return 0;
}

/*********************************************
*��������: CheckMonEnd
*��������: У���Ƿ�����ĩ
*�������: sDate -- ��������yyyymmdd
*�������: ��
*����ֵ:   0  -- ��ĩ
           1  -- ����ĩ
           -1 -- ������
*************************************************/
int CheckMonEnd(char *sDate)
{
    int iRet;
    char sDay[3];
    char sLastDate[9];
    char sLastDay[3];

    memset(sDay,      0, sizeof(sDay));
    memset(sLastDate, 0, sizeof(sLastDate));
    memset(sLastDay,  0, sizeof(sLastDay));

    iRet = CheckStrDate(sDate);
    if (iRet != 0)
    {
        return -1;
    }

    /* ȡ����������� */
    GetLastDay(sDate, sLastDate);

    memcpy(sDay,     sDate+6,     2);
    memcpy(sLastDay, sLastDate+6, 2);

    iRet = memcmp(sDay, sLastDay, 2);
    if (iRet != 0)
    {
        return 1;
    }

    return 0;
}

/*****************************************************
*��������: GetDateDiff
*��������: ������������֮����������
*�������: sStartDate -- ��ʼ����(YYYYMMDD)
            sEndDate   -- ��ֹ����(YYYYMMDD)
*�������: plDiffDays -- �������������
*��������: 0  -- �ɹ�
            -1 -- ʧ��
*****************************************************/
int GetDateDiff(char *sStartDate, char *sEndDate, int *piDiffDays)
{
    int   iRet;
    long  lStartDate;
    long  lEndDate;

    lStartDate = atol(sStartDate);
    lEndDate   = atol(sEndDate);

    iRet = DiffDate(lStartDate, lEndDate, piDiffDays);
    if (iRet != 0)
    {
        return -1;
    }

    return 0;
}

/*****************************************************
*��������: DiffDate
*��������: ������������֮����������
*�������: lStartDate -- ��ʼ����(YYYYMMDD)
            lEndDate   -- ��ֹ����(YYYYMMDD)
*�������: piDiffDays -- �������������
*��������: 0  -- �ɹ�
            -1 -- ʧ��
*****************************************************/
int DiffDate(long lStartDate, long lEndDate, long *piDiffDays)
{
    int  i, flag = 1;
    int  sYear, sMonth, sDays;
    int  eYear, eMonth, eDays;
    long tmp_date;
    long Days = 0;

    if (lStartDate > lEndDate)
    {
        tmp_date = lEndDate;
        lEndDate = lStartDate;
        lStartDate = tmp_date;
        flag = -1;
    }

    sYear = lStartDate / 10000;
    eYear = lEndDate / 10000;

    sMonth = lStartDate % 10000 / 100;
    eMonth = lEndDate % 10000 / 100;

    sDays = lStartDate % 100;
    eDays = lEndDate % 100;

    if (checkdate(sYear, sMonth, sDays) != 0 ||
        checkdate(eYear, eMonth, eDays) != 0)
        return -1;

    for(i = sYear; i < eYear; i ++)
        Days += YEARDAYS(i);

    for(i = 1; i < eMonth; i ++)
        Days += RMONTHDAYS(i, eYear);

    Days += eDays;

    for(i = 1; i < sMonth; i ++)
        Days -= RMONTHDAYS(i, sYear);

    Days -= sDays;
    *piDiffDays = flag * Days;

    return 0;
}

/*****************************************************
*��������: ChgDDD2YYYYMMDD
*��������: ̫����ת��Ϊ��������
*�������: vspInStr  -- ̫����(DDD)
*�������: vspOutStr  -- (YYYYMMDD)
*��������: 0  -- �ɹ�
           -1 -- ʧ��
*****************************************************/
int ChgDDD2YYYYMMDD(char* vspInStr, char* vspOutStr)
{
    int  iRet;
    int  iCurrMonDay;            /* �������� */
    int  iCurrDayCnt=0;          /* �ۼ����� */
    int  iCurrMon;               /* ��ǰ�� */
    int  iDay;                   /* ����̫�����ڸ����еĵڼ��� */
    char sDDD[3+1]={0};          /* ����̫���� */
    char sCurrDDD[4+1]={0};      /* ��ǰ����̫���� */
    char sCurrYear[4+1]={0};     /* ��ǰ�� */
    char sLastYear[4+1]={0};     /* ȥ���� */
    char sNextYear[4+1]={0};     /* ������ */
    char sTmpYear[4+1]={0};

    time_t  current_time;
    struct tm *tmp_struct_time;

    memcpy(sDDD, vspInStr, 3);
    if (atoi(sDDD) < 0 || atoi(sDDD) > 366 )
    {
        printf("InPut Parameter FileName Format Error [%s]", vspInStr);
        return -1;
    }



    time(&current_time);
    tmp_struct_time = localtime(&current_time);
    tmp_struct_time->tm_year = tmp_struct_time->tm_year + 1900;
    sprintf(sCurrDDD, "%03d", tmp_struct_time->tm_yday + 1);
    sprintf(sCurrYear, "%.4d", tmp_struct_time->tm_year);
    sprintf(sLastYear, "%d", atoi(sCurrYear)-1);
    sprintf(sNextYear, "%d", atoi(sCurrYear)+1);


    iCurrMonDay = 0;
    iCurrMon = 1;

    if (atoi(sCurrDDD) < atoi(sDDD))
    {
        /* ��ǰʱ��С������ʱ�䣬������̫���յ�����ȥ���ʱ�� */
        memcpy(sTmpYear, sLastYear, 4);
    }
    else
    {
    	if ((atoi(sDDD) + 366) - atoi(sCurrDDD) < 10)
    	{
    		/* �������ʱ���Ǹ������룬ȴ�����10�����ң��򵱳��������ʱ�� */
    		memcpy(sTmpYear, sNextYear, 4);
    	}
    	else
    	{
    		/* ��ǰʱ���������ʱ�䣬������̫���յ����ǵ����ʱ�� */
            memcpy(sTmpYear, sCurrYear, 4);
    	}
    }

    while (iCurrDayCnt < atoi(sDDD))
    {
        switch (iCurrMon)
        {
            case 2:
                if (___IsLeapYear(atoi(sTmpYear)))
                {
                	iCurrMonDay=29;
                	iCurrDayCnt+=iCurrMonDay;

                }
                else
                {
                	iCurrMonDay=28;
                	iCurrDayCnt+=iCurrMonDay;
                }

                break;
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                iCurrMonDay=31;
                iCurrDayCnt+=iCurrMonDay;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                iCurrMonDay=30;
                iCurrDayCnt+=iCurrMonDay;
                break;
        }

        iCurrMon += 1;
    }

    iDay = iCurrMonDay - (iCurrDayCnt - atoi(sDDD));
    sprintf(vspOutStr, "%4.4s%02d%02d", sTmpYear, iCurrMon-1, iDay);

    return 0;
}

char *juliancal_to_suncal( char *insert_time )
{
    struct tm  *tmCurrent;
    time_t  lTime;
    char szDayOfYear[5];
    char szHourTmp[3];
    static char szAuRRN[13];

	memset(szAuRRN, 0, sizeof(szAuRRN));
    memset( szDayOfYear, 0, 5);
    memset(szHourTmp, 0, 3);
    lTime = GetTimeInLong (insert_time,0);
    tmCurrent = gmtime(&lTime);
    sprintf( szDayOfYear, "%03d", tmCurrent->tm_yday + 1 );
    sprintf(szHourTmp, "%02d", tmCurrent->tm_hour);
    memcpy( szAuRRN, &insert_time[3], 1);
    memcpy( &szAuRRN[1], szDayOfYear, 3);
    memcpy( &szAuRRN[4], &szHourTmp[0], 2);
    memcpy( &szAuRRN[6], &insert_time[8], 6);
    memcpy( &szAuRRN[10], "00", 2);
    return szAuRRN;
}

void GetField37SunCal(char *field7, char *timebuf)
{
   char curtime[15];

   memset(curtime, 0, 15);
   AddYearToDate(field7, curtime);
  /* GetGMTInTime(curtime);*/
   strcpy(timebuf, juliancal_to_suncal(curtime));
   /*
   return juliancal_to_suncal(curtime);
   */
}

/* ȡ�����·� */
char * GetLastMonth ( char * caNowDate , char *caLastMonth )
{
    int    year, month ;
    char caTmp[10];

    memset(caTmp , 0, sizeof(caTmp));

    memcpy(caTmp , caNowDate, 4);
    year = atoi(caTmp);
    memcpy(caTmp , caNowDate+4, 2);
    caTmp[2] = 0;
    month = atoi(caTmp);
    month --;
    if( month == 0) {
        year -- ;
        month = 12;
    }
    sprintf(caLastMonth, "%4d%02d" , year ,month);
    return(caLastMonth);
}

/* ȡ�����·� */
char * GetNextMonth ( char * caNowDate , char *caNextMonth )
{
    int  year, month;
    char caTmp[10];

    memset(caTmp , 0, sizeof(caTmp));

    memcpy(caTmp , caNowDate, 4);
    year = atoi(caTmp);
    memcpy(caTmp , caNowDate + 4, 2);
    caTmp[2] = 0;
    month = atoi(caTmp);
    month ++;
    if( month == 13) {
        year ++ ;
        month = 1;
    }
    sprintf(caNextMonth, "%4d%02d" , year ,month);
    return(caNextMonth);
}

int GetWeekStr( char *pDate, char *pWeekStr )
{
    char sYear[5]={0};
    char sMon[3]={0};
    char sDay[3]={0};
    int  y,m,d;
    int  x;
    int  z;
    int  first_data[] = { 0x00,0x06,0x02,0x02,0x05,0x00,0x03,0x05,0x01,0x04,0x06,0x02,0x04 };

    sprintf(sYear,"%4.4s", pDate );
    sprintf(sMon,"%2.2s", pDate+4 );
    sprintf(sDay,"%2.2s", pDate+6 );

    y=atoi(sYear);
    m=atoi(sMon);
    d=atoi(sDay);

    x = first_data[m] + d -1 ;
    x += (y -2000 + 3 )/4 ;
    x += y - 2000 ;
    if(!( y % 4 )  && (m > 2 ))
        x++;

    z=x%7;

    if( z == 0 )
        z = 7;

    switch( z )
    {
        case 1:
            sprintf(pWeekStr, "MON");
            break;
        case 2:
            sprintf(pWeekStr, "TUE");
            break;
        case 3:
            sprintf(pWeekStr, "WED");
            break;
        case 4:
            sprintf(pWeekStr, "THU");
            break;
        case 5:
            sprintf(pWeekStr, "FRI");
            break;
        case 6:
            sprintf(pWeekStr, "SAT");
            break;
        case 7:
            sprintf(pWeekStr, "SUN");
            break;
        defaule:
            break;
    }

    return z;
}

int GetWeekDay( char *pDate, int *piWeekDay )
{
    char sYear[5]={0};
    char sMon[3]={0};
    char sDay[3]={0};
    int  y,m,d;
    int  x;
    int  z;
    int  first_data[] = { 0x00,0x06,0x02,0x02,0x05,0x00,0x03,0x05,0x01,0x04,0x06,0x02,0x04 };

    sprintf(sYear,"%4.4s", pDate );
    sprintf(sMon,"%2.2s", pDate+4 );
    sprintf(sDay,"%2.2s", pDate+6 );

    y=atoi(sYear);
    m=atoi(sMon);
    d=atoi(sDay);

    x = first_data[m] + d -1 ;
    x += (y -2000 + 3 )/4 ;
    x += y - 2000 ;
    if(!( y % 4 )  && (m > 2 ))
        x++;

    z=x%7;

    if( z == 0 )
        z = 7;

    *piWeekDay = z;

    return z;
}


/****************************************************** �ļ����� ****************************************/

