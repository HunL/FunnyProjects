#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <string.h>
       
#include "SrvDef.h"
#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "TxnNum.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "CvtOpr.h"
#include "xmlstruct.h"
#include "simu.h"

#define CLIENT_LOG_FILE "client.log"
#define CLIENT_CFG_FILE_NAME "sim_client.ini"
#define SPLIT ":"
#define HEAD_LEN_LEN 4
#define MAX_FILE_PATH 255
#define MAX_BUF_LEN 127
#define IP_LEN 15
#define ACQ_SSN_LEN 12

int ReadlenSocket(int nSocket, int *sBuf, int nLen);
typedef struct {
	char szIp[IP_LEN+1];
	int iPort;
	char szCfgPath[MAX_FILE_PATH+1];
} ClientConfig;

typedef struct {
	char sVersion[1];
	char sPressFlag[1];
	char sCommCode[6];
	char sCommType[1];
	char sRcvFlag[4];
	char sSndFlag[4];
	char sFwSsn[22];
	char sFwDate[8];
	char sFwTime[6];
	char sTrsCode[6];
	char sNetErrCode[2];
	char sNetErrMsg[7];
	char sMisc[8];
}BonusHead;

BonusHead  gsBonusHead;

char gsTmpOut[2048];
char gsTxnType[20];
char gsBufType[2];
char gsTradePath[128];

char gszAcqSsn[6+1] = {0};

int main(int argc, char **argv)
{    
	char  sTxnNum[4+1] = {0};
	int ilen=0;
	char sContentLen[HEAD_LEN_LEN+1] = {0};
    char  sReqBuf[REQBUF_LENTH_MAX+1] = {0};
    
    if(argc < 2)
	{
		printf("Usage:%s TxnNum \n", argv[0]);
		exit(-1);
	}
        
    ClientConfig stClientConfig = {0};        
    memset(gsTradePath, 0, sizeof(gsTradePath));   
    
	int iRet = getClientConfig(&stClientConfig);
	if (iRet != 0)
	{
		HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
			"InitClient error");
    	return -1;
	}
    
    memcpy(gsTradePath, stClientConfig.szCfgPath, strlen(stClientConfig.szCfgPath));
    
	/* ���ӷ����� */
	char szIp[IP_LEN+1] = {0};
	int iPort = 0;
	int iSocketID = 0;
	strncpy(szIp, stClientConfig.szIp, IP_LEN);
	iPort = stClientConfig.iPort;
	
	char* pReqBuf = malloc(REQBUF_LENTH_MAX);
	if (pReqBuf == NULL)
	{
		HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
			"Malloc new space error");
		return -1;
	}
	memset(pReqBuf, 0x00, REQBUF_LENTH_MAX);    
	memset(sReqBuf, 0x00, REQBUF_LENTH_MAX);
	
    /* ���ݲ�ͬ������������XML������ argv[1] - �������� */
    int iContentLen = 0;
    
    memcpy(sTxnNum, argv[1], 4);
	int iGenMsgRet = GenReqMessage(sTxnNum, sReqBuf, &iContentLen);
    if (iContentLen < 0)
    {
		HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"GenReqMessage Error");
		return -1;
    }
    
				
	if (iRet = nMCalcOut(iContentLen, sContentLen, HEAD_LEN_LEN))
    {
        HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,  "nGetHexStr error %d", iRet);
        return -1;
    }
    
    memcpy(pReqBuf, sContentLen, HEAD_LEN_LEN);
		
	memcpy(pReqBuf+4, sReqBuf, iContentLen);
	
	HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
			"���͵�������");
	HtDebugString(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__,__LINE__, pReqBuf, HEAD_LEN_LEN+iContentLen);			
		
	int iOpenSockRet = OpenSocket(szIp, iPort, 3 , 30 , &iSocketID);
	if (iOpenSockRet < 0)
    {
		HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
			"socket Error IP [%s] Port [%d] - [%s]\n" ,
			szIp, iPort, strerror(errno));
		return -1;
	}
	
	HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
		"Connect OK! IP [%s]Port [%d]" , szIp, iPort);

	int iSndRet = send(iSocketID, pReqBuf, iContentLen + HEAD_LEN_LEN, 0);
    if (iSndRet == -1)
    {
		HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
			"Write_socket error [%s]" , strerror(errno));
		close(iSocketID);
		return -1;
	}
	free(pReqBuf);
    /* ��buf���� */
    memset(sContentLen, 0x00, sizeof sContentLen);
	iRet = ReadSocket(iSocketID, sContentLen, HEAD_LEN_LEN);
	if (iRet < 0)
    {
		HtLog (CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"Read_socket error [%s]" , strerror(errno));
		close(iSocketID);
		return -1;
    }    
    
    if (iRet = nMCalcIn(&iContentLen, sContentLen, HEAD_LEN_LEN))
    {
        HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,  "nGetHexStr error %d", iRet);
        return -1;
    }
        
    int iRecvLen = iContentLen;
    
	char* szRcvBuf = malloc(iRecvLen+1);
	memset(szRcvBuf, 0x00, iRecvLen+1);
	
	int iRecvRet = ReadSocket(iSocketID, szRcvBuf, iRecvLen);
	
    if (iRet < 0)
    {
		HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"Read_socket error [%s]\n" , strerror(errno));
    	close(iSocketID);
        return -1;
    }
	
    HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"receive msg Ok \n");
    
    HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
			"�յ���Ӧ����");
			
	HtDebugString(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__,__LINE__, szRcvBuf, iRecvLen);	
		
	sleep(1);
	close(iSocketID);

	HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		"nrMsgBuf=[%s]", szRcvBuf);

    return 0;
}

int getRequestTimeStamp(char* szRequestTimeStamp)
{
	char sCurrTime[14+1] = {0};
	CommonGetCurrentTime(sCurrTime);

	sprintf(szRequestTimeStamp, "%4.4s-%2.2s-%2.2s %2.2s:%2.2s:%2.2s.000000",
		sCurrTime, sCurrTime+4, sCurrTime+6, sCurrTime+8,
		sCurrTime+10, sCurrTime+12);
	
	return 0;
}



/*************************************************************
*��������: GenReqMessage
*��������: ����������
*�������: pBuf -- �������ַ���ָ��
		   iBufLen -- �������ַ�������
		   pBranch -- ���к�ָ��
*�������: pBuf  --  ���ɺ���������ַ���ָ��
*�� �� ֵ: 0  -- �ɹ�
  		   -1 -- ʧ��
***************************************************************/
int GenReqMessage(char* sTxnNum, char *sReqBuf, int* iContentLen)
{
	int  iTxnNum = 0;	
	char sCurrTime[14+1] = {0};
	
	iTxnNum = atoi(sTxnNum);
	CommonGetCurrentTime(sCurrTime);
	
	/* ��ʼ������ͷ */	
	memcpy(gsBonusHead.sVersion, "1", 1);
	memcpy(gsBonusHead.sPressFlag, "0", 1);
	memcpy(gsBonusHead.sCommCode, "500001", 6);
	memcpy(gsBonusHead.sCommType, "0", 1);
	memcpy(gsBonusHead.sRcvFlag, "BPMS", 4);
	memcpy(gsBonusHead.sSndFlag, "POSP", 4);
	
	getAcqSsn(gszAcqSsn);
	
	memset(gsBonusHead.sFwSsn, ' ', 22);
	memcpy(gsBonusHead.sFwSsn, gszAcqSsn, 6);
	memcpy(gsBonusHead.sFwDate, sCurrTime, 8);
	memcpy(gsBonusHead.sFwTime, sCurrTime+8, 6);
	memcpy(gsBonusHead.sTrsCode, "000005", 6);
	memcpy(gsBonusHead.sNetErrCode, "  ", 2);
	memcpy(gsBonusHead.sNetErrMsg, "       ", 7);
	memcpy(gsBonusHead.sMisc, "        ", 8);
	
	memcpy(sReqBuf, &gsBonusHead, sizeof(gsBonusHead));
	
	switch(iTxnNum)
	{
		/* ��������ѯ */
		case  1041:
		{
			*iContentLen = BalanceQry(sReqBuf+sizeof(gsBonusHead));
			break;
		}	
			
	}	
	*iContentLen = *iContentLen + sizeof(gsBonusHead);
	
    return 0;
}

int getParamValue(const char* szSection, const char* szKey, const char* szProfileName,
	char* szValue)
{
	char sParaValue[MAX_FILE_PATH+1] = {0};
	int iRet = cfgGetProfileString(szSection, szKey, sParaValue, MAX_FILE_PATH, szProfileName);
	if (iRet != 0)
	{
		HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"Get Section[%s] Key[%s] ERROR", szSection, szKey);
		return -1;
	}
	AllTrim(sParaValue);
	strcpy(szValue, sParaValue);
	
	return 0;
}

int getClientConfig(ClientConfig *pClientConfig)
{
	char szProfileName[MAX_FILE_PATH+1] = {0};
	char szPort[16] = {0};
	
	sprintf(szProfileName, "%s/etc/%s", getenv("FEHOME"),
		CLIENT_CFG_FILE_NAME);
	
	getParamValue("CLIENT", "IP", szProfileName, pClientConfig->szIp);
	getParamValue("CLIENT", "PORT", szProfileName, szPort);
	getParamValue("CLIENT", "TRADE_PATH", szProfileName, pClientConfig->szCfgPath);
	
	pClientConfig->iPort = atoi(szPort);
	
    return 0;
}

int getAcqSsn(char* gszAcqSsn)
{
	char szProfileName[MAX_FILE_PATH+1] = {0};
	char szLine[32] = {0};
	int iSq = 0;
	sprintf(szProfileName, "%s/etc/sim_acqssn.ini", getenv("FEHOME"));
	
	char szCurrTime[14+1] = {0};
	CommonGetCurrentTime(szCurrTime);
	
	FILE* pAcqFile = fopen(szProfileName, "r+");
	fgets(szLine, sizeof szLine, pAcqFile);
	HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
		"szLine[%s]", szLine);
	iSq = atoi(szLine);
	iSq++;
	
	sprintf(gszAcqSsn, "%06d", iSq);
	HtLog(CLIENT_LOG_FILE, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
		"Acq Ssn[%s]", gszAcqSsn);
	
	rewind(pAcqFile);
	fprintf(pAcqFile, "%06d", iSq);
	fclose(pAcqFile);
	
	return 0;
}


int BalanceQry(char* sBuf)
{
	char szProfileName[MAX_FILE_PATH+1] = {0};
	char sCurrTime[14+1] = {0};    
	char sTemp[128] = {0};
	char sMidTime = {0};
	char currentPage[4+1];
	char sSsn[12+1] = {0};
	int  iSsn;      
	char *pBuf;
	
	pBuf = sBuf;

	CommonGetCurrentTime(sCurrTime); 
			
	sprintf(szProfileName, "%s/%s", gsTradePath, "BalanceQry.cfg");
	
	/* ���� */	
	getParamValue("BODY", "ChanlId", szProfileName, sTemp);    
    memcpy(sBuf, sTemp, 4);
    sBuf = sBuf + 4;
    
    /* ת��ϵͳ��ʶ */
    memset(sTemp, 0, sizeof(sTemp));
    getParamValue("BODY", "midID", szProfileName, sTemp);    
    memcpy(sBuf, sTemp, 4);
    sBuf = sBuf + 4;

    /* ת��ϵͳʱ�� */
    memcpy(sBuf, sCurrTime+2, 10);
    sBuf = sBuf + 10;
    
    /* ת��ϵͳ��ˮ�� */
    memset(sTemp, 0, sizeof(sTemp));     
    iSsn = atoi(gszAcqSsn) + 11;
    sprintf(sSsn, "%06d       ", iSsn);        
    memcpy(sBuf, sSsn, 12);
    sBuf = sBuf + 12;
    
    /* �ڵ��������ʶ */
    memset(sTemp, 0, sizeof(sTemp));
    getParamValue("BODY", "midTag", szProfileName, sTemp);   
    memcpy(sTemp+4, "    ", 4); 
    memcpy(sBuf, sTemp, 8);
    sBuf = sBuf + 8;
    
    /* ��ǰҳ�� */
    memset(sTemp, 0, sizeof(sTemp));
    getParamValue("BODY", "currentPage", szProfileName, sTemp);  
    sprintf(currentPage, "%04d", atoi(sTemp));  
    memcpy(sBuf, currentPage, 4);   
    sBuf = sBuf + 4;
    
    /* card_no */
    memset(sTemp, 0, sizeof(sTemp));
    getParamValue("BODY", "card_no", szProfileName, sTemp);    
    if (strlen(sTemp) < 19+1)
    {
    	memset(sTemp+strlen(sTemp)-1, ' ', 19-(strlen(sTemp)-1));
    }
    memcpy(sBuf, sTemp, 19);
    sBuf = sBuf + 19;
    
    /* ת��ϵͳ������ */        
    memset(sBuf, ' ', 80);
    sBuf = sBuf + 80;
    
    /* �������� */
    memset(sTemp, 0, sizeof(sTemp));
    getParamValue("BODY", "jgId", szProfileName, sTemp);    
    memcpy(sBuf, sTemp, 3);
    sBuf = sBuf + 3;
    
    /* �̻��� */
    memset(sTemp, 0, sizeof(sTemp));
    getParamValue("BODY", "mcc", szProfileName, sTemp);    
    memcpy(sBuf, sTemp, 15);
    sBuf = sBuf + 15;
    
    /* �ն˺� */
    memset(sTemp, 0, sizeof(sTemp));
    getParamValue("BODY", "terminal_code", szProfileName, sTemp);    
    memcpy(sBuf, sTemp, 8);
    sBuf = sBuf + 8;
    
    /* ����Ա�� */ 
    memcpy(sBuf, "          ", 10);
    sBuf = sBuf + 10;
    
    /* �Ƿ�ֻ��ѯ�������� */
    memset(sTemp, 0, sizeof(sTemp));
    getParamValue("BODY", "is_only_query_type", szProfileName, sTemp);    
    memcpy(sBuf, sTemp, 1);
    sBuf = sBuf + 1;
    
    return strlen(pBuf); ;	
}