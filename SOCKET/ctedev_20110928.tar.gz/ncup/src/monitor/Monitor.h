#ifndef __MONITOR_H
#define __MONITOR_H

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <termio.h>
#include <fcntl.h>
#include <time.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/timeb.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "MsqOpr.h"
#include "ToOpr.h"
#include "HtLog.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "ErrCode.h"
#include "OnMon.h"


#define RETRYNUM         5

#endif
