/*****************************************************************************/
/*                    Shanghai Huateng Software System Inc.                  */
/*****************************************************************************/
/* PROGRAM NAME: Monitor.c                                                   */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*                                                                           */
/*****************************************************************************/
#include "Monitor.h"

int       gnMsqId;
int       gnRemotePort;
int       gnSocketId;
char      gnRemoteAddr[15 + 1];
char      gsLogFile[LOG_NAME_LEN_MAX];
char      gsSrvId[SRV_ID_LEN+1];
char      gsSrvSeq[SRV_SEQ_ID_LEN+1];

struct sockaddr     *gtSocketAddr;
struct sockaddr_in  gnRemoteSin; 
socklen_t           gtRemoteLen;

void HandleExit(int sig);
void ConnectSocket();
int lCPickParam();

int MonitorInit(int argc, char **argv);

typedef struct{

	    char    sTransmsnDateTime[15];
	    char    sSysSeqNum[FLD_SYS_SEQ_NUM_LEN+1];
	    char    bran_code[12];
	    char    bran_codefa[12];
	    char    sAcqInstIdCode[F032_VAL_LEN+1];
	    char    sFwdInstIdCode[F033_VAL_LEN+1];
	    char    mer_code[16];
	    char    sCardAccptrTermnlId[F041_LEN+1];
	    char    sPrimaryAcctNum[F002_VAL_LEN+1];
	    char    sAmtTrans[F004_LEN+1];
	    char    sTxnNum[5];
	    char    sRespCode[F039_LEN+1];
		char    read_flag[2];
}MsgStruct;
int FormStruct(char *s, MsgStruct * m);
int main(int argc, char *argv[])
{
    int             code;
    /*int             nMsqId;*/
    int             nMsgLen;
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    int flag;
	

	MsgStruct msdest;
    memset(&msdest, 0, sizeof(msdest));
    if(argc < 3) 
    {
        printf("Usage: %s srvid seq \n", argv[0]);
        exit(-1);
    }

    code = MonitorInit(argc, argv);
    if (code != 0) 
    {
    	printf("Monitor111111: MonitorInit \n");
    	HtLog("Monitor.1.log", 1, __FILE__,__LINE__, "gMonitor: MonitorInit error %d\n", code);
        printf("Monitor: MonitorInit error %d\n", code);
        exit(-1);
    }
HtLog("Monitor.1.log", 1, __FILE__,__LINE__, "gMonitor: MonitorInit strat:\n");
/*
	printf("Monitor22222222222: MonitorInit \n");
    if (sigset(SIGTERM, HandleExit) == SIG_ERR) 
    {
    	printf("Monitor3333: MonitorInit \n");
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "sigset SIGTERM error: %d.", errno);
        exit(-2);
    }
*/
    HtLog(gsLogFile, 1, __FILE__,__LINE__, "Monitor started.");
    
/*    code = nConnectSocket();
    if (code)
    {
    	printf("Monitor4444: MonitorInit \n");
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Create Socket error");
        exit(-3);
    }
*/
    while (1)
    {
        memset(sMsgBuf, 0, sizeof(sMsgBuf));
		HtLog("Monitor.1.log", 1, __FILE__,__LINE__, "gnMsqId[%d]", gnMsqId);
		printf("Monitor55555: gnMsqId[%d] \n", gnMsqId);
        code = msgrcv(gnMsqId, sMsgBuf, &nMsgLen, 0, 0);
        if (code == -1)
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                   "msgrcv error [%d]", errno);
            continue;
        }

        nMsgLen = code;

        HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sMsgBuf, nMsgLen);

   /*     code = sendto(gnSocketId, sMsgBuf, nMsgLen, 0, gtSocketAddr, gtRemoteLen);  
        if (code <= 0)
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                   "sendto error [%d]", errno);
            HandleExit(0);
        }
*/	
		flag=FormStruct(sMsgBuf, &msdest);
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "FLAG2 :%d", flag);
		if(flag)
		{	
			flag = DbsMonitorInfo(DBS_INSERT, &msdest);
		} 

    }
}

/*****************************************************************************/
/* FUNC:   int MonitorInit();                                                */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ʼ��ϵͳ��̬����,����,������Ϣ��                                */
/*****************************************************************************/
int MonitorInit(int argc, char **argv)
{
    /*int                i;*/
    int                code;
    long               lUsageKey;
    Tbl_srv_inf_Def    tTblSrvInf;
    Tbl_msq_inf_Def    tTblMsqInf;

    strcpy(gsSrvId, argv[1]);
    strcpy(gsSrvSeq, argv[2]);

    if (getenv(SRV_USAGE_KEY))
        lUsageKey = atoi(getenv(SRV_USAGE_KEY));
    else
        return -1;

    /* connect to database */
    code = DbsConnect();
    if (code)
        return (code);
    
    /* get log file name from tbl_srv_inf */
    memset((char *)&tTblSrvInf, 0x00, sizeof(tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy(tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    printf("Monitor6666: usage_key %d, srvid %s \n",  tTblSrvInf.usage_key, tTblSrvInf.srv_id);
   // HtLog ("var111.log", 1, __FILE__,__LINE__, "usage_key %d, srvid %s", tTblSrvInf.usage_key, tTblSrvInf.srv_id);
    code = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
    if (code)
    {
        DbsDisconnect();
        return (code);
    }
    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_name, gsSrvSeq);

    memset((char *)&tTblMsqInf, 0x00, sizeof(tTblMsqInf));
    memcpy(tTblMsqInf.msq_int_id, tTblSrvInf.msq_int_id, sizeof(tTblMsqInf.msq_int_id));
    printf("Monitor7 %s\n",tTblMsqInf.msq_int_id);
    code = DbsMSQINF(DBS_SELECT, &tTblMsqInf);
    if (code)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "MonitorInit DbsMSQINF error, [%d]", code);
        DbsDisconnect();
        return (code);
    }
printf("Monitor8\n");
    /* open msq */
    code = msgget(atol(tTblMsqInf.msq_key), 0660|IPC_CREAT);
    if (code == -1)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "MonitorInit msgget error, [%d]", errno);
        DbsDisconnect();
        return (code);
    }
    printf("Monitor9\n");
    gnMsqId = code;
    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Monitor MsqId [%ld]", code);
    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "atol [%ld]", atol(tTblMsqInf.msq_key));

    code = lCPickParam();
    if (code)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "MonitorInit lCPickParam error, [%d]", errno);
        DbsDisconnect();
        return (code);
    }
 printf("Monitor10\n");
 	return 0;    
}

/*****************************************************************************/
/* FUNC  : int lCPickParam ()                                                */
/* INPUT : NULL                                                              */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC  : ȡMonitor��ص���·��Ϣ�����浽ȫ�ֱ������������               */
/*****************************************************************************/
int lCPickParam()
{
    int                 code;
    /*short               lnLoop;*/
    char                *lspTmp;
    Tbl_line_cfg_Def    tTblLineCfg;

    memset(&tTblLineCfg, 0, sizeof(tTblLineCfg));
    if((lspTmp = getenv("TL_COMM_LINE_CFG_KEY")) == NULL) 
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "Call getenv(TL_COMM_LINE_CFG_KEY), error %d", errno);
        return -1;
    }
    if((tTblLineCfg.usage_key = atoi(lspTmp)) < 0) 
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "Call atoi(tTblLineCfg.usage_key), error %d", errno);
        return -2;
    }

    memcpy(&tTblLineCfg.srv_id[0], &gsSrvId[0], SRV_ID_LEN);
    tTblLineCfg.line_index = 1;
    code = DbsLINECFG(DBS_SELECT, &tTblLineCfg);
    if (code)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "lCPickParam DbsLINECFG DBS_SELECT errno [%d]", code);
        return code;
    }

    gnRemotePort = tTblLineCfg.out_sock_num;
    memset(gnRemoteAddr, 0, sizeof(gnRemoteAddr));
    memcpy(gnRemoteAddr, tTblLineCfg.remote_addr, strlen(tTblLineCfg.remote_addr));  

    return 0;
} /* end of lCPickParam */

/*****************************************************************************/
/* FUNC  : int nConnectSocket()                                              */
/* INPUT : NULL                                                              */
/* OUTPUT:                                                                   */
/* RETURN: 0: �ɹ�  ����: ʧ��                                               */
/* DESC  : ȡMonitor��ص���·��Ϣ�����浽ȫ�ֱ������������               */
/*****************************************************************************/
int nConnectSocket()
{
    /*int                 code;*/
    int                 sockfd;
    /*int                 Flag;*/
    /*int                 Error;*/
    int                 RetryTimeSap = 2;
    int                 nRetryFlag = 0;

    memset(&gnRemoteSin, 0, sizeof(gnRemoteSin));
    gnRemoteSin.sin_family = AF_INET;
    gnRemoteSin.sin_port = htons(gnRemotePort);
    
    printf("Monitor: gnRemotePort[%d] \n", gnRemotePort);
    printf("Monitor: gnRemoteAddr[%s] \n", gnRemoteAddr);

    if(inet_pton(AF_INET, gnRemoteAddr, &gnRemoteSin.sin_addr) <= 0) 
    {
    	printf("Monitor66: gnMsqId[%d] \n");
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               "[%s] is not a valid IP address\n", gnRemoteAddr);
        return -1;
    }

    while(1)
    {
        while ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket errno, %d", errno);
			printf("Monitor77: gnMsqId[%d] \n");
            if (nRetryFlag++ == RETRYNUM) 
            {
                if ( RetryTimeSap<100) RetryTimeSap += 2;
                nRetryFlag = 0;
            }

            sleep(RetryTimeSap);
        }

        break;
    }

    gnSocketId = sockfd;
    gtSocketAddr = (struct sockaddr *)&gnRemoteSin;
    gtRemoteLen = sizeof(gnRemoteSin);

    return 0;
}

void HandleExit(int sig)
{
	DbsDisconnect();
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Monitor exit.");
    close(gnSocketId);
    exit(1);
}


int FormStruct(char *s, MsgStruct * m)
{
	int rcode=1;
	memcpy(m->sTransmsnDateTime, s+7, 14);
	memcpy(m->sSysSeqNum, s+21, 6);
	memcpy(m->bran_code, s+27, 11);
	memcpy(m->bran_codefa, s+38, 11);
	memcpy(m->sAcqInstIdCode, s+49, 11);
	memcpy(m->sFwdInstIdCode, s+60, 11);
	memcpy(m->mer_code, s+71, 15);
	memcpy(m->sCardAccptrTermnlId, s+86, 8);
	memcpy(m->sPrimaryAcctNum, s+94, 19);
	memcpy(m->sAmtTrans, s+113, 12);
	memcpy(m->sTxnNum, s+125, 4);
	memcpy(m->sRespCode, s+129, 2);
	if(!memcmp(m->sRespCode, "00", 2))
	    rcode=0;
    memcpy(m->read_flag, "0", 1);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTransmsnDateTime[%s]",m->sTransmsnDateTime);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sSysSeqNum[%s]",m->sSysSeqNum);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "bran_code[%s]",m->bran_code);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "bran_codefa[%s]",m->bran_codefa);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sAcqInstIdCode[%s]",m->sAcqInstIdCode);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sFwdInstIdCode[%s]",m->sFwdInstIdCode);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "mer_code[%s]",m->mer_code);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sCardAccptrTermnlId[%s]",m->sCardAccptrTermnlId);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sPrimaryAcctNum[%s]",m->sPrimaryAcctNum);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sAmtTrans[%s]",m->sAmtTrans);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sRespCode[%s]",m->sRespCode);
 /*   struct timeb tp;
    ftime(&tp);
    m->registime = tp.time*1000 + tp.millitm;
    */
	return rcode;
}


