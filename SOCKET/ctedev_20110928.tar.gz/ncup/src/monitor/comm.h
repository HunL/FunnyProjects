#define  QUEUE_BASE_KEY ( atol(getenv( "QUEUE_BASE_KEY" )) )
#define  MSGQUE12_KEY	( QUEUE_BASE_KEY + 12 )
