#ifndef	__DUMPMSG_H
#define	__DUMPMSG_H

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <memory.h>
#include <sys/types.h>
#include <time.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>
#include <sys/times.h>
#include <sys/time.h>
#include <unistd.h>
#include "SrvDef.h"
#include "SrvParam.h"
#include "HtLog.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "ErrCode.h"

/* env var */
#define DM_DEFAULT_CHECK_HOUR	1
#define DM_DEFAULT_SLEEP_MIN	10

#define DM_BUF_MAX				10*1024

#define MSQ_GET_FLAG   0660

int DumpmsgInit (short argc, char **argv);
void Dumpmsg ();
void FUNC_NONE();
void HandleExit (int n);

#endif
