#ifndef	__SAV_FWD_H
#define	__SAV_FWD_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <memory.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include "SrvDef.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "IpcInt.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "ErrCode.h"
#include "LineStat.h"
#include "SrvParam.h"

#define SF_DEFAULT_CYCLE_INTV_MIN	10
#define SF_DEFAULT_GRP_MSG_NUM		5
#define SF_DEFAULT_GRP_INTV_SECOND	1

#define SF_SEND_COUNT_MAX			"99"

int		SafFwdInit (short, char **);
int     SavFwdInit (short, char **);
int		SaveForward ();
void	HandleExit (int n);

#endif
