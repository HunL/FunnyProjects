/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Normal.c                                                    */
/* DESCRIPTIONS: handle normal req from CUP and its rsp from host            */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBonus/Txn1825.c,v 1.1.2.1 2011/09/23 02:54:35 ctedev Exp $";

#include "SwtBonus.h"

int Txn1825 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex )
{
    char            sFuncName[] = "Txn1825";
    char            sRespCode[F039_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    int             nReturnCode;
    int             nLineStat;
    int             nMsgLen;
    int             nTxnSelOpr;    
    T_SwtToReqDef   tSwtToReq;
    Tbl_bonus_txn_Def tBonusTxn;
    
    T_IpcIntBonusDef tSendIpcBonusTxn;    
    char   sCurrentDate[14+1];

    memset(sCurrentDate, 0, sizeof(sCurrentDate));    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
  
    if (nIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", pIpcBonusTxn->sTxnNum, pIpcBonusTxn->sMsgSrcId);
        return -1;
    }   
    
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    /***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex);
    memcpy(sCurrentDate, gsTimeCurTs, 14);    
    
     /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
     HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %12.12s\n",
            gatTxnInf[nIndex].txn_num, pIpcBonusTxn->sPrimaryAcctNum, pIpcBonusTxn->sAmtTrans,
            pIpcBonusTxn->sDateLocalTrans, pIpcBonusTxn->sTimeLocalTrans, pIpcBonusTxn->sSysTraceAuditNum);
     /* ����ǰ��F007,F011��sMisc */
     memcpy(pIpcBonusTxn->sMisc1,pIpcBonusTxn->sTransmsnDateTime,F007_LEN);
     memcpy(pIpcBonusTxn->sMisc1+F007_LEN,pIpcBonusTxn->sSysTraceAuditNum,F011_LEN);
     /* F007ʹ��ϵͳ��ǰʱ�� */
     memcpy(pIpcBonusTxn->sMiscFlag, sCurrentDate, 14);
     memcpy(pIpcBonusTxn->sTransmsnDateTime, sCurrentDate+4, F007_LEN);
     pIpcBonusTxn->sConsumeType[0] = '1';
      
    /*******************
     * �жϸý����Ƿ�֧��
     ********************/
    if (memcmp(gatTxnInf[nIndex].support_flag, FLAG_YES, 1) )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */
        return -1;
    }
   
    /***************
     * ������ˮ��
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
    if (tSwtToReq.nToCtlTime > 0)
        tSwtToReq.nTransCode = TOCTL_NORMAL_FIRST;
    else
        tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
    memcpy (tSwtToReq.sTxnDate, pIpcBonusTxn->sTransmsnDateTime, F007_LEN);

    nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
    if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "ToCtrlReq error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */
        return -1;
    }
    /* save ssn in ipc */
    memcpy (pIpcBonusTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
    memcpy (pIpcBonusTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);

    /* ��key_rsp, key_revsal, key_cancel��ֵ */
    nReturnCode = SetKeyRsp (pIpcBonusTxn);
    nReturnCode = SetKeyRevsal (pIpcBonusTxn);
    nReturnCode = SetKeyCancel (pIpcBonusTxn);

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/      
    nReturnCode = MoveIpc2Txn (pIpcBonusTxn, &tBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);

        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */
        return -1;
    }
  
    /***************
     * ת��PIN
     ****************/
    if (gatTxnInf[nIndex].pin_flag[0] == FLAG_YES_C)
    {
        nReturnCode = TransferPin (pIpcBonusTxn );
        if (nReturnCode)
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "TransferPin error, %d. Reject this transaction with %s.", nReturnCode, F039_PIN_ERROR);
            /* �����ʱ���� */
            tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

            /* ����Ӧ���״��� */
            memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( pIpcBonusTxn->sRespCode, F039_PIN_ERROR, F039_LEN );
            /*����15��*/
            pIpcBonusTxn->cF015Ind = 'Y';
            memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            pIpcBonusTxn->sMsgType[2]++;
            
            nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);

            /* save this txn in Db */
            DbsBegin ();
            memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
            nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
            DbsCommit ();

            return -1;
        }
    }

    /*******************
     * �����ͻ����ļ��
     ********************/
    nReturnCode = SwtCustCheckTxn (pIpcBonusTxn, sRespCode);
    if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustCheckTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, sRespCode, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }
    
    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    memcpy(pIpcBonusTxn->sMiscFlag + 14, "0", 1);
    nReturnCode = SwtCustBeforeTblTxnOpr (pIpcBonusTxn, &tBonusTxn, NULL);
    if (nReturnCode)
    {
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        if(pIpcBonusTxn->sRespCode[0] == ' ' || pIpcBonusTxn->sRespCode[0] == 0)
        {
            memcpy(pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
        }
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }
    
    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    showBPTxn(&tBonusTxn);
    nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"DbsBonusTxn tBonusTxn.key_rsp [%s].", tBonusTxn.key_rsp);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn insert error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_DUPL_TXN, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);
        return -1;
    }
    
    DbsCommit ();

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");
    
    memcpy ((char *)&tSendIpcBonusTxn, (char *)pIpcBonusTxn, sizeof (*pIpcBonusTxn));

    /* ��ת���������ÿ� -> ��У�� */
    memcpy( tSendIpcBonusTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest2, SRV_ID_LEN );
    
    /* ����sTxnNum, sKeyRsp��sMisc2,������tbl_txn�еĽ��׼�¼ʹ��  */
    memcpy(tSendIpcBonusTxn.sMisc2, tSendIpcBonusTxn.sKeyRsp, KEY_RSP_LEN);
    memcpy(tSendIpcBonusTxn.sMisc2+KEY_RSP_LEN, tSendIpcBonusTxn.sTxnNum, 4);

    memcpy( tSendIpcBonusTxn.sTxnNum, "1997", 4);
    
    /* use FE ssn in F011 */
    memcpy (tSendIpcBonusTxn.sSysTraceAuditNum, pIpcBonusTxn->sSysSeqNum, F011_LEN);

    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sLoopReq [%-512.512s]", pIpcBonusTxn->sLoopReq);
    nReturnCode = SendMsg (&tSendIpcBonusTxn, &tBonusTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SendMsg error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);

        /* �޸�tbl_txn��resp_code */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_UPDATE1, &tBonusTxn);
        if (nReturnCode)
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert1 error, %d.", nReturnCode);
        }
        DbsCommit ();

        return -1;
    }

    HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    showBPIpc( pIpcBonusTxn );
    return 0;
}

int Txn1826 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex)
{
    char               sFuncName[] = "Txn1826";
    char               sMsgSrcId[SRV_ID_LEN+1];
    char               sMsgBuf[MSQ_MSG_SIZE_MAX];
    int                nReturnCode;
    int                nLineStat;
    int                nTxnSelOpr;
    int                nMsgLen;
    int                nSendRspFlag;
    int                nSendAccountFlag;
    int                nReqIndex;
    T_SwtToReqDef      tSwtToReq;
    Tbl_bonus_txn_Def  tBonusTxn, tOrigTxn;
    char               sRespCode[F039_LEN+1];
    char               sSrcTxnNum[5];
    char               sTrackData[80];
    char               sPinData[20];
    int                i = 0;
    
    T_IpcIntBonusDef   tSendIpcBonusTxn ,tSendIpcBonusTxn2;
    T_IpcIntBonusDef   tSendToBonusCosume,tSendToBonusRevsal;
    T_IpcIntBonusDef   tSendToCredit;
    T_IpcIntBonusDef   tSendRspToPosp;    
    
    char               sF054Len[F054_LEN_LEN+1] = {0};
    char               sCurrentTime[15];
	char               sOrigElement[50];

    HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, pIpcBonusTxn, sizeof(T_IpcIntBonusDef));

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    memset(sCurrentTime, 0, sizeof(sCurrentTime));
    memset(sSrcTxnNum, 0, sizeof(sSrcTxnNum));
    SetToTime(-1);
    memcpy(sCurrentTime, gsTimeCurTs, 14);

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
    memcpy (sMsgSrcId, pIpcBonusTxn->sMsgSrcId, SRV_ID_LEN);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  host SSN: %12.12s\n  response code: %2.2s",
            pIpcBonusTxn->sTxnNum, pIpcBonusTxn->sPrimaryAcctNum, pIpcBonusTxn->sAmtTrans,
            pIpcBonusTxn->sDateLocalTrans, pIpcBonusTxn->sTimeLocalTrans,
            pIpcBonusTxn->sSysTraceAuditNum, pIpcBonusTxn->sMidSsn, pIpcBonusTxn->sRespCode);

    /* ת��Ӧ���� */    
    nReturnCode = SwtCustTransferRspCode(pIpcBonusTxn);
    if (nReturnCode != 0 )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "transfer RSPCODE error");
        memcpy(pIpcBonusTxn->sRespCode, "01", F039_LEN);    
    }

    memcpy(sRespCode, pIpcBonusTxn->sRespCode, 2);
    memcpy(sSrcTxnNum, pIpcBonusTxn->sMAC064, 4);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sReturnCode:[%2.2s]", sRespCode);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sSrcId:[%4.4s], sDesId[%4.4s]", sMsgSrcId, pIpcBonusTxn->sMsgDestId);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sPosCondCode:[%2.2s],SrcTxn[%4.4s]", pIpcBonusTxn->sPosCondCode, sSrcTxnNum);

    /****************************
    * ����tbl_txn�еĽ��׼�¼
    ****************************/
    nReturnCode = SetKeyRsp (pIpcBonusTxn);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMidTime [%10.10s]", pIpcBonusTxn->sMidTime);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMidSsn [%12.12s]", pIpcBonusTxn->sMidSsn);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMidTag [%8.8s]", pIpcBonusTxn->sMidTag);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransChnl [%4.4s]", pIpcBonusTxn->sTransChnl);

    /* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
    memset ((char *)&tBonusTxn, 0, sizeof (tBonusTxn));
    memcpy(tBonusTxn.key_rsp, pIpcBonusTxn->sKeyRsp, KEY_RSP_LEN);    
    memcpy (tBonusTxn.txn_num, pIpcBonusTxn->sTxnNum, FLD_TXN_NUM_LEN);
    tBonusTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;

    /* �����ݿ��в���ԭ������ */
    /* DBS_SELECT21: txn_num, key_rsp */
    nReturnCode = DbsBonusTxn(DBS_SELECT21, &tBonusTxn);
    if (nReturnCode)
    {
        tBonusTxn.key_rsp[KEY_RSP_LEN] = 0;
        tBonusTxn.txn_num[FLD_TXN_NUM_LEN] = 0;
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn select error, %d. txn_num=%s,key_rsp=%s. Discard this message.", nReturnCode,tBonusTxn.txn_num,tBonusTxn.key_rsp);
        return -1;
    }

    memcpy(pIpcBonusTxn->sMisc2, tBonusTxn.key_rsp, KEY_RSP_LEN);
    memcpy(tBonusTxn.misc_2, tBonusTxn.key_rsp, KEY_RSP_LEN);
        pIpcBonusTxn->sConsumeType[0] = '1';
    tBonusTxn.consume_type[0] = '1';

	memset(sOrigElement, 0, sizeof(sOrigElement));
	memcpy(sOrigElement, tBonusTxn.msg_type, F000_MSG_TYPE_LEN);
	memcpy(&sOrigElement[F000_MSG_TYPE_LEN], tBonusTxn.key_revsal, KEY_REVSAL_LEN);

    /***********************
     * ���ҽ���������gatTxnInf�е�����
     ************************/
    nReturnCode = GetTxnInfoIndex (tBonusTxn.msg_src_id, tBonusTxn.txn_num, &nReqIndex );
    if (nReturnCode || nReqIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
        return -1;
    }

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn(pIpcBonusTxn, &tBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
        return -1;
    }

     /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    memcpy(pIpcBonusTxn->sMiscFlag + 14, "0", 1);
    nReturnCode = SwtCustBeforeTblTxnOpr (pIpcBonusTxn, &tBonusTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* ��tTxn���浽tSendIpcIntTxn, ������Ӧ����ʹ�� */
    nReturnCode = MoveTxn2Ipc (&tBonusTxn, &tSendIpcBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
        return -1;
    }  

    /* ת����Ӧ�������38��ʹ�÷�����Ӧ���е�38�� */
    if (pIpcBonusTxn->cF038Ind == FLAG_YES_C)
    {
        tSendIpcBonusTxn.cF038Ind = FLAG_YES_C;
        memcpy (tSendIpcBonusTxn.sAuthrIdResp, pIpcBonusTxn->sAuthrIdResp, F038_LEN);
    }
    else
        tSendIpcBonusTxn.cF038Ind = FLAG_NO_C;
        
    /* ת����Ӧ�������54��ʹ�÷�����Ӧ���е�54�� */
    if (pIpcBonusTxn->cF054Ind == FLAG_YES_C)
    {
        tSendIpcBonusTxn.cF054Ind = FLAG_YES_C;
        memset(sF054Len, 0, sizeof(sF054Len));
        memcpy (sF054Len, pIpcBonusTxn->sAddtnlAmtLen, F054_LEN_LEN);
        memcpy (tSendIpcBonusTxn.sAddtnlAmtLen, pIpcBonusTxn->sAddtnlAmtLen, F054_LEN_LEN);
        memcpy (tSendIpcBonusTxn.sAddtnlAmt, pIpcBonusTxn->sAddtnlAmt, atoi(sF054Len));
    }
    
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nReqIndex].msg_to );
    memcpy (tSwtToReq.sTxnDate, tBonusTxn.trans_date_time, F007_LEN);
    memcpy (tSwtToReq.sSysSeqNum, tBonusTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN );
    tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;

    /***********************************************************
    *  ��齻���Ƿ�ʱ add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    if (!memcmp(tBonusTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN))
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_HAD_TO;
    else
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO; 

    /* set trans state if reply is not time out */
    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_TO)
    {
        if (IsRspSuccess (pIpcBonusTxn->sRespCode))
        {
            switch (gatTxnInf[nReqIndex].rsp_type[0])
            {
                case RSP_TYPE_NO_ACCOUNT:
                    memcpy (tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    break;
                case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                    if (!memcmp (sMsgSrcId, "1903", 4))
                        memcpy (tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    break;
                case RSP_TYPE_RSP_AFTER_ACCOUNT:
                    if (!memcmp (sMsgSrcId, "1903", 4))
                        memcpy (tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    break;
                default:
                    break;
            }
        }
        else
        {
            if (!memcmp (sMsgSrcId, "1903", 4))
                memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_BP, FLD_TRANS_STATE_LEN);
        }
    }

    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_HAD_TO) /* ��ʱӦ�� */
    {        
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Received late response.");
        memcpy(tSendIpcBonusTxn.sOrigDataElemts, sOrigElement, KEY_REVSAL_LEN+F000_MSG_TYPE_LEN);
		nReturnCode = SendRevsalOnError (&tSendIpcBonusTxn, nReqIndex, REASON_CODE_LATE_RSP);
        if (nReturnCode)
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
        }
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Reversal for late successful response sent out.");
    }
    else /* Ӧ��δ��ʱ */
    {
        /****************** 
          �������ÿ�:�鿨�ɹ�
          ȥ����֧��
        *******************/
        if(!memcmp(sMsgSrcId, "1702", 4) &&
           !memcmp(sSrcTxnNum, "1998", 4) &&
           !memcmp(sRespCode, "00", 2))
        {
            /* ����Ӧ��SrvId */
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                            "check card succ. begin send to bonus");
            memcpy((char *)&tSendIpcBonusTxn2, &tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));
            memcpy(tSendIpcBonusTxn2.sMsgDestId, gatTxnInf[nReqIndex].msg_dest1, SRV_ID_LEN );
            memcpy(tSendIpcBonusTxn2.sMiscFlag+14, "1", 1);
            
            nReturnCode = SwtCustBeforeTblTxnOpr (&tSendIpcBonusTxn2, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
                memcpy( tSendIpcBonusTxn2.sRespCode, "96", F039_LEN );
                /* ����Ӧ���״��� */
                memcpy( tSendIpcBonusTxn2.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
                /* ����Ӧ��SrvId */
                memcpy( tSendIpcBonusTxn2.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );
                /* ����Ӧ�� msg type */
                tSendIpcBonusTxn2.sMsgType[2]++;
                
                nReturnCode = SendMsg (&tSendIpcBonusTxn2, &tBonusTxn, NULL);
                if (nReturnCode)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                            "SendMsg error, %d. Discard this message.", nReturnCode);
                
                    return -1;
                }
                HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
            }
    
            /* clear F038 */
            tSendIpcBonusTxn2.cF038Ind = FLAG_NO_C;
            /* clear F039 */
            memset (tSendIpcBonusTxn2.sRespCode, ' ', F039_LEN);
            nReturnCode = SendMsg(&tSendIpcBonusTxn2, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);
                /* send reversal on success reply */
				memcpy(tSendIpcBonusTxn.sOrigDataElemts, sOrigElement, KEY_REVSAL_LEN+F000_MSG_TYPE_LEN);
                nReturnCode = SendRevsalOnError (&tSendIpcBonusTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if (nReturnCode)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
                return -1;
            }

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction account request sent out.");
        }
        /****************** 
          �������ÿ�:�鿨ʧ��
          ��POSPϵͳ����ʧ��
        *******************/
        else if(!memcmp(sMsgSrcId, "1702", 4) &&
                !memcmp(sSrcTxnNum, "1998", 4) &&
                 memcmp(sRespCode, "00", 2))
        {
            /* ���½���״̬Ϊ�鿨ʧ�ܣ�trans_state='5' */
            tBonusTxn.trans_state[0] = '5';
            nReturnCode = DbsBonusTxn(DBS_UPDATE13, &tBonusTxn);
                        if(nReturnCode)
            {
                DbsRollback();
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "DbsBonusTxn update trans_state error[%d]", nReturnCode);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
                return -1;
            }
            DbsCommit();

            /***********************
             *  �ͻ���Ŀ��IPC��������
             ************************/
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "check card fail. begin send to POSP");
            memcpy ((char *)&tSendRspToPosp, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));

            /* ����Ӧ���״��� */
            memcpy(tSendRspToPosp.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN);

            /* ����Ӧ��SrvId */
            memcpy(tSendRspToPosp.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendRspToPosp.sMsgType[2]++;

            nReturnCode = SendMsg (&tSendRspToPosp, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
                return -1;
            }

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
        }

        /**************************************** 
         ���Ի���ϵͳ:���˳ɹ�
         ȥ���ÿ�����
         ***************************************/
        else if(!memcmp(sMsgSrcId, "1903", 4) && 
                !memcmp(sSrcTxnNum, "1816", 4) &&
                !memcmp(sRespCode, "00", 2))
        {
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "bonus acct succ. begin send to credit");

            /* ����sTxnNum, sKeyRsp��sMisc2,������tbl_txn�еĽ��׼�¼ʹ��  */
            memcpy(tSendIpcBonusTxn.sKeyRsp, pIpcBonusTxn->sKeyRsp, KEY_RSP_LEN);
            memcpy(tSendIpcBonusTxn.sMisc2, pIpcBonusTxn->sKeyRsp, KEY_RSP_LEN);
            memcpy(tSendIpcBonusTxn.sMisc2+KEY_RSP_LEN, tSendIpcBonusTxn.sTxnNum, 4);

            memcpy(tSendIpcBonusTxn.sMsgDestId, "1702", 4);

            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                          "misc_2track[%37.37s]", tBonusTxn.misc_2+50);
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                          "misc_2pin[%8.8s]", tBonusTxn.misc_2+50+37);
            memset(sTrackData, 0, sizeof(sTrackData));
            memset(sPinData, 0, sizeof(sPinData));
            memcpy(sTrackData, tBonusTxn.misc_2+50, 37);
            memcpy(sPinData, tBonusTxn.misc_2+50+37, 8);

            /* ���½��׽����54�� */
            SwtCustBeforeTblTxnOpr(&tSendIpcBonusTxn, &tBonusTxn, &tBonusTxn);
            tBonusTxn.trans_state[0] = '0';
            nReturnCode = DbsBonusTxn(DBS_UPDATE1, &tBonusTxn);
            if (nReturnCode)
            {
                DbsRollback();
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert1 error, %d.", nReturnCode);
            }
            DbsCommit();
            
            memcpy(tSendIpcBonusTxn.sTxnNum, "1825", 4);
            memcpy(tSendIpcBonusTxn.sTrack2Data, sTrackData, F035_VAL_LEN);
            if(memcmp(sPinData, "NPINNPIN", 8) != 0)
            {
                tSendIpcBonusTxn.cF052Ind = FLAG_YES_C;
                memcpy(tSendIpcBonusTxn.sPinData, sPinData, 8);
            }

            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
                          "sTrack2Data[%37.37s]", tSendIpcBonusTxn.sTrack2Data);            

            HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
                          tSendIpcBonusTxn.sPinData, sizeof(tSendIpcBonusTxn.sPinData));            

            nReturnCode = SendMsg(&tSendIpcBonusTxn, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                          "SendMsg error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

                /* ����Ӧ���״��� */
                memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
                /* ����Ӧ��SrvId */
                memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
                /* ���Ĵ���Ӧ���� */
                memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
                /* ����Ӧ�� msg type */
                pIpcBonusTxn->sMsgType[2]++;
        
                nReturnCode = SendMsg(pIpcBonusTxn, &tBonusTxn, NULL);

                /* �޸�tbl_txn��resp_code */
                DbsBegin ();
                memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
                memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
                nReturnCode = DbsBonusTxn (DBS_UPDATE1, &tBonusTxn);
                if (nReturnCode)
                {
                    DbsRollback ();
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert1 error, %d.", nReturnCode);
                }
                DbsCommit ();
                return -1;
            }            
        }
        /**************************************** 
         ���Ի���ϵͳ:����ʧ��
         ֱ�ӷ���POSPʧ��         
         ***************************************/
        else if(!memcmp(sMsgSrcId, "1903", 4) && 
                !memcmp(sSrcTxnNum, "1816", 4) &&
                 memcmp(sRespCode, "00", 2))
        {
            /* ���½���״̬Ϊ�鿨ʧ�ܣ�trans_state='2' */
            tBonusTxn.trans_state[0] = '2';
            nReturnCode = DbsBonusTxn(DBS_UPDATE13, &tBonusTxn);
                        if(nReturnCode)
            {
                DbsRollback();
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "DbsBonusTxn update trans_state error[%d]", nReturnCode);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
                return -1;
            }
            DbsCommit();
            
            /***********************
             *  �ͻ���Ŀ��IPC��������
            ************************/
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "bonus acct fail. begin send to POSP");
            memcpy ((char *)&tSendRspToPosp, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));

            /* ����Ӧ���״��� */
            memcpy(tSendRspToPosp.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN);

            /* ����Ӧ��SrvId */
            memcpy(tSendRspToPosp.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendRspToPosp.sMsgType[2]++;

            nReturnCode = SendMsg (&tSendRspToPosp, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
                return -1;
            }

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
        }
        /**************************************** 
         �������ÿ�:���˳ɹ�
         ��POSP���سɹ�
         ***************************************/
        else if(
                !memcmp(sMsgSrcId, "1702", 4) &&
                !memcmp(sSrcTxnNum, "1826", 4) &&
                !memcmp(sRespCode, "00", 2)
               )
        {
            /* �������ݿ� */
            tBonusTxn.trans_state[0] = '1';
            pIpcBonusTxn->cF038Ind = FLD_IND_VAL_Y;
            memcpy(tBonusTxn.authr_id_r, pIpcBonusTxn->sAuthrIdResp, F038_LEN);
            memcpy(tBonusTxn.authr_id_resp, pIpcBonusTxn->sAuthrIdResp, F038_LEN);
			tSendIpcBonusTxn.cF038Ind = FLD_IND_VAL_Y;
			memcpy(tSendIpcBonusTxn.sAuthrIdResp, pIpcBonusTxn->sAuthrIdResp, F038_LEN);

            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
                  "authr_id_resp[%6.6s]", pIpcBonusTxn->sAuthrIdResp);
            
            nReturnCode = DbsBonusTxn (DBS_UPDATE11, &tBonusTxn);
            if(nReturnCode)
            {
                DbsRollback ();
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                  "DbsBonusTxn update error, %d. Discard this message.", nReturnCode);
      
                /* send reversal on success reply */
				memcpy(tSendIpcBonusTxn.sOrigDataElemts, sOrigElement, KEY_REVSAL_LEN+F000_MSG_TYPE_LEN);
                nReturnCode = SendRevsalOnError (&tSendIpcBonusTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if(nReturnCode)
                {
                    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
                return -1;
            }
            DbsCommit();

            /***********************
             *  �ͻ���Ŀ��IPC��������
             ************************/
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "credit acct succ, resp to POSP");
            memcpy((char *)&tSendRspToPosp, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));

            /* ����Ӧ���״��� */
            memcpy(tSendRspToPosp.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN);

            /* ����Ӧ��SrvId */
            memcpy(tSendRspToPosp.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendRspToPosp.sMsgType[2]++;

            nReturnCode = SendMsg (&tSendRspToPosp, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);
                return -1;
            }

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
            
        }
        
        /**************************************** 
         �������ÿ�:����ʧ��
         ����POSP����ʧ�ܵ�Ӧ��Ȼ�������ϵͳ�������
         ***************************************/
        else if(
                !memcmp(sMsgSrcId, "1702", 4) &&
                !memcmp(sSrcTxnNum, "1826", 4) &&
                 memcmp(sRespCode, "00", 2)
               )
        {            
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"credit acct fail, begin send Revsal to bonus");
            /* ���½���״̬Ϊ���ÿ�����ʧ�ܣ�trans_state='4' */
            tBonusTxn.trans_state[0] = '4';
            nReturnCode = DbsBonusTxn(DBS_UPDATE13, &tBonusTxn);
                        if(nReturnCode)
            {
                DbsRollback();
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "DbsBonusTxn update trans_state error[%d]", nReturnCode);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
                return -1;
            }
            DbsCommit();

            /*-------- ��ǰ��POSP����ʧ�ܵ�Ӧ�� --------------- */

            /***********************
             *  �ͻ���Ŀ��IPC��������
            ************************/
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "bonus Revsal succ, begin send to POSP");
            memcpy ((char *)&tSendRspToPosp, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));

            /* ����Ӧ���״��� */
            memcpy(tSendRspToPosp.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN);

            /* ����Ӧ��SrvId */
            memcpy(tSendRspToPosp.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendRspToPosp.sMsgType[2]++;

            nReturnCode = SendMsg (&tSendRspToPosp, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);
                return -1;
            }

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");

            
            /*--------------- �����ϵͳ�������� --------------------------*/
            memcpy((char *)&tSendToBonusRevsal, &tSendIpcBonusTxn, sizeof(tSendIpcBonusTxn));

            memcpy(tSendToBonusRevsal.sMsgDestId, "1903", 4);
            memcpy(tSendToBonusRevsal.sTxnNum, "2815", 4);

            /* save original txn info in F090 */
            memset (tSendToBonusRevsal.sOrigDataElemts, '0', F090_LEN);
            i = 0;
            memcpy (tSendToBonusRevsal.sOrigDataElemts+i, tBonusTxn.fw_trans_id, FLD_FW_TRANS_ID_LEN);
            i += FLD_FW_TRANS_ID_LEN;
            memcpy (tSendToBonusRevsal.sOrigDataElemts+i, tBonusTxn.fw_trans_ssn, FLD_FW_TRANS_SSN_LEN);
            i += FLD_FW_TRANS_SSN_LEN;
            memcpy (tSendToBonusRevsal.sOrigDataElemts+i, tBonusTxn.fw_trans_date, FLD_FW_TRANS_DATE_LEN);
            i += FLD_FW_TRANS_DATE_LEN;
            memcpy (tSendToBonusRevsal.sOrigDataElemts+i, tBonusTxn.fw_trans_time, FLD_FW_TRANS_TIME_LEN);

            memcpy(tSendToBonusRevsal.sMiscFlag+14, "1", 1);

            SwtCustBeforeTblTxnOpr(&tSendToBonusRevsal, &tBonusTxn, &tBonusTxn);

            nReturnCode = SendMsg (&tSendToBonusRevsal, &tBonusTxn, &tBonusTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

            nReturnCode = InsertSafMsg(&tSendToBonusRevsal, &tBonusTxn, gatTxnInf[nIndex].saf_count1);
            if(nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
        }
        else
        {
            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "error, no find process.\nMsgSrcId[%4.4s]\nSrcTxnNum[%4.4s]\nRespCode[%2.2s]", sMsgSrcId,sSrcTxnNum,sRespCode);
        }
    }

    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    showBPIpc( pIpcBonusTxn );
    return 0;
}


