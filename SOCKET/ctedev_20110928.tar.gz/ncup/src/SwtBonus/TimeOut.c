/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: TimeOut.c                                                   */
/* DESCRIPTIONS: handle time out msg from ToCtl                              */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-29  YU TONG        Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBonus/TimeOut.c,v 1.1.1.1.4.1 2011/09/23 02:54:35 ctedev Exp $";

#include "SwtBonus.h"

/*****************************************************************************/
/* FUNC:   int HandleTimeOut (char *sMsgBuf)                                 */
/* INPUT:  �ַ���ָ��                                                        */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��������ToCtl�Ľ���                                               */
/*****************************************************************************/
int HandleTimeOut (char *sMsgBuf )
{
    char              sFuncName[] = "HandleTimeOut";
    char              sTxnNum[FLD_TXN_NUM_LEN+1];
    int               nReturnCode;
    int               nIndex;
    T_SwtToReqDef     tSwtToReq;
    Tbl_bonus_txn_Def tTxn;
    T_IpcIntBonusDef  tSendIpcIntTxn, tSendIpcIntTxn1;
	char              sOrigElement[50];

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memcpy ((char *)&tSwtToReq, sMsgBuf, sizeof (tSwtToReq));

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "time out txn: date: %10.10s  FE SSN: %6.6s",
            tSwtToReq.sTxnDate, tSwtToReq.sSysSeqNum);

    /****************************
     * ����tbl_txn�еĽ��׼�¼
     ****************************/
    /* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
    memset ((char *)&tTxn, 0, sizeof (tTxn));
    /*memcpy (tTxn.date_local_trans, tSwtToReq.sTxnDate, FLD_DATE_LEN); */
    memcpy (tTxn.trans_date_time, tSwtToReq.sTxnDate, F007_LEN);
    memcpy (tTxn.sys_seq_num, tSwtToReq.sSysSeqNum, FLD_SYS_SEQ_NUM_LEN);

    /* �����ݿ��в���ԭ������ */
    /* DBS_SELECT1: F007, FE SSN */
    nReturnCode = DbsBonusTxn(DBS_SELECT1, &tTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn select error[%d] Discard this message.", nReturnCode);
        return -1;
    }

	memset(sOrigElement, 0, sizeof(sOrigElement));
	memcpy(sOrigElement, tTxn.msg_type, F000_MSG_TYPE_LEN);
	memcpy(&sOrigElement[F000_MSG_TYPE_LEN], tTxn.key_revsal, KEY_REVSAL_LEN);

    nReturnCode = MoveTxn2Ipc(&tTxn, &tSendIpcIntTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    nReturnCode = GetTxnInfoIndex(tSendIpcIntTxn.sMsgSrcId, tSendIpcIntTxn.sTxnNum, &nIndex);
    if(nReturnCode != 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetTxnInfoIndex error. Discard this message.");
        return -1;
    }

    /* ����Ӧ���״��� */
    memcpy( tSendIpcIntTxn.sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
    /* ���Ĵ���Ӧ���� */
    memcpy( tSendIpcIntTxn.sRespCode, F039_TIME_OUT, F039_LEN );

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr(&tSendIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* �ָ�ԭ���״��룬������Ľ��״��� */
    memcpy(tSendIpcIntTxn.sTxnNum, gatTxnInf[nIndex].txn_num, FLD_TXN_NUM_LEN );

    /***************
     * ��¼���ݿ�
     ****************/
    if (!memcmp(tTxn.trans_state, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN))
        memcpy(tTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN);
    else
    {
        if (!memcmp(tTxn.trans_state, TRANS_STATE_NO_ACCT_RSP, FLD_TRANS_STATE_LEN))
            memcpy(tTxn.trans_state, TRANS_STATE_ACCT_TO, FLD_TRANS_STATE_LEN);
    }

    DbsBegin ();

    nReturnCode = DbsBonusTxn(DBS_UPDATE1, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn update error, %d. Discard this message.", nReturnCode);

        return -1;
    }

    DbsCommit ();

    /***************
     * ���ͳ�ʱʧ��Ӧ��
     ****************/
    memcpy ((char *)&tSendIpcIntTxn1, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn1));
    /* ����Ӧ���״��� */
    memcpy( tSendIpcIntTxn1.sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
    /*������Ϣ����*/
    tSendIpcIntTxn1.sMsgType[2] ++;
    /* ����Ӧ��SrvId */
    memcpy( tSendIpcIntTxn1.sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
    /*����15��*/
    tSendIpcIntTxn1.cF015Ind = 'Y';
    memcpy(tSendIpcIntTxn1.sDateSettlmt,"0000",F015_LEN);
    /* clear F090 */
    memset (tSendIpcIntTxn1.sOrigDataElemts, ' ', F090_LEN);
    nReturnCode = SendMsg (&tSendIpcIntTxn1, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
    }

    /***************
     * ���ͳ�ʱ����
     ****************/
    memcpy(tSendIpcIntTxn.sOrigDataElemts, sOrigElement, KEY_REVSAL_LEN+F000_MSG_TYPE_LEN);
    nReturnCode = SendRevsalOnError(&tSendIpcIntTxn, nIndex, REASON_CODE_TIME_OUT);
    if (nReturnCode)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
    }

    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    return 0;
}
