/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Cancel.c                                                    */
/* DESCRIPTIONS: handle cancel req its rsp                                   */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBonus/Attic/Txn3825.c,v 1.1.4.2 2011/09/23 02:57:03 ctedev Exp $";

#include "SwtBonus.h"

int Txn3825(T_IpcIntBonusDef *pIpcBonusTxn, int nIndex )
{
    char            sFuncName[] = "Txn3825";
    char            sRespCode[F039_LEN+1];
    int             nReturnCode;
    int             nTxnSelOpr;
    int             i;
    T_SwtToReqDef   tSwtToReq;
    Tbl_bonus_txn_Def tBonusTxn, tOrigBonusTxn;
    char            sCurrentDate[14+1];
    T_IpcIntBonusDef tSendIpcBonusTxn, tSendIpcBonusTxn1;
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    if (nIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", pIpcBonusTxn->sTxnNum, pIpcBonusTxn->sMsgSrcId);
        return -1;
    }
    
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    /***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex);
    memcpy(sCurrentDate, gsTimeCurTs, 14);

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %12.12s\n",
            gatTxnInf[nIndex].txn_num, pIpcBonusTxn->sPrimaryAcctNum, pIpcBonusTxn->sAmtTrans,
            pIpcBonusTxn->sDateLocalTrans, pIpcBonusTxn->sTimeLocalTrans, pIpcBonusTxn->sSysTraceAuditNum);
            
    /* ����ǰ��F007,F011��sMisc */
     memcpy(pIpcBonusTxn->sMisc1,pIpcBonusTxn->sTransmsnDateTime,F007_LEN);
     memcpy(pIpcBonusTxn->sMisc1+F007_LEN,pIpcBonusTxn->sSysTraceAuditNum,F011_LEN);
     /* F007ʹ��ϵͳ��ǰʱ�� */
     memcpy(pIpcBonusTxn->sMiscFlag, sCurrentDate, 14);
     memcpy(pIpcBonusTxn->sTransmsnDateTime, sCurrentDate+4, F007_LEN);
      memcpy(pIpcBonusTxn->sTransChnl, "POSP", 4);    
     pIpcBonusTxn->sConsumeType[0] = '1'; 
     
    /*******************
     * �жϸý����Ƿ�֧��
     ********************/
    if (memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */
        return -1;
    }
    
    /***************
     * ������ˮ��
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
    if (tSwtToReq.nToCtlTime > 0)
        tSwtToReq.nTransCode = TOCTL_NORMAL_FIRST;
    else
        tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
    memcpy (tSwtToReq.sTxnDate, pIpcBonusTxn->sTransmsnDateTime, F007_LEN );

    nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
    if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "ToCtrlReq error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */
        return -1;
    }
    /* save ssn in ipc */
    memcpy(pIpcBonusTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
    memcpy(pIpcBonusTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);

    /* ��key_rsp, key_revsal, key_cancel��ֵ */
    nReturnCode = SetKeyRsp (pIpcBonusTxn);
    nReturnCode = SetKeyRevsal (pIpcBonusTxn);
    nReturnCode = SetKeyCancel (pIpcBonusTxn);

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (pIpcBonusTxn, &tBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);

        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */

        return -1;
    }


    /***************
     * �������׵������жϴ���
     ****************/
    memset ((char *)&tOrigBonusTxn, 0, sizeof (tOrigBonusTxn));
    memcpy ((char *)&tOrigBonusTxn, (char *)&tBonusTxn, sizeof (tBonusTxn));
    
    nReturnCode = CheckCancelTxn (pIpcBonusTxn, &tOrigBonusTxn, sRespCode);
    if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "CheckCancelTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, sRespCode, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }
    else
    {
        /* save original fe ssn in cancel_ssn */
        memcpy (tBonusTxn.cancel_ssn, tOrigBonusTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
        pIpcBonusTxn->cF054Ind = FLD_IND_VAL_Y;
        memcpy(pIpcBonusTxn->sAddtnlAmtLen, tOrigBonusTxn.addtnl_amt_len, 3);
        memcpy(pIpcBonusTxn->sAddtnlAmt, tOrigBonusTxn.addtnl_amt, 40);
        memcpy(tBonusTxn.addtnl_amt_len, tOrigBonusTxn.addtnl_amt_len, 3);
        memcpy(tBonusTxn.addtnl_amt, tOrigBonusTxn.addtnl_amt, 40);
        /* save original F037 */
        /*
        memcpy (tBonusTxn.retrivl_ref, tOrigBonusTxn.retrivl_ref, F037_LEN);
        memcpy (pIpcBonusTxn->sRetrivlRefNum, tOrigBonusTxn.retrivl_ref, F037_LEN); */
    }

    /***************
     * ת��PIN
     ****************/
    if (gatTxnInf[nIndex].pin_flag[0] == FLAG_YES_C)
    {
        nReturnCode = TransferPin (pIpcBonusTxn );
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "TransferPin error, %d. Reject this transaction with %s.", nReturnCode, F039_PIN_ERROR);
            /* �����ʱ���� */
            tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

            /* ����Ӧ���״��� */
            memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( pIpcBonusTxn->sRespCode, F039_PIN_ERROR, F039_LEN );
            /*����15��*/
            pIpcBonusTxn->cF015Ind = 'Y';
            memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            pIpcBonusTxn->sMsgType[2]++;
            /* clear F090 */
            memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
            
            nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);

            /* save this txn in Db */
            DbsBegin ();
            memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
            nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
            DbsCommit ();

            return -1;
        }
    }

    /*******************
     * �����ͻ����ļ��
     ********************/
    nReturnCode = SwtCustCheckTxn (pIpcBonusTxn, sRespCode);
    if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustCheckTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, sRespCode, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }


    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn insert error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_DUPL_TXN, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);
        return -1;
    }

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");

    /***************
     * �������ݿ�ԭʼ���׼�¼
     ****************/
    memset (tOrigBonusTxn.cancel_flag, REV_CAN_FLAG_HAD, 1);
    memcpy (tOrigBonusTxn.cancel_ssn, tBonusTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
    nReturnCode = DbsBonusTxn (DBS_UPDATE3, &tOrigBonusTxn );
    if( nReturnCode != 0 )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn update error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);
        return -1;
    }
    
    DbsCommit ();

    /***********************
     *  ת��������
     ************************/
    memcpy ((char *)&tSendIpcBonusTxn, (char *)pIpcBonusTxn, sizeof (*pIpcBonusTxn));
    memcpy( tSendIpcBonusTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );
    memcpy (tSendIpcBonusTxn.sSysTraceAuditNum, pIpcBonusTxn->sSysSeqNum, F011_LEN);
    
    nReturnCode = CopyOrigTxnInfo (&tOrigBonusTxn, &tSendIpcBonusTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CopyOrigTxnInfo error, %d.", nReturnCode);
    }
    
    /* use original F037 */
    memcpy (tSendIpcBonusTxn.sOrderId, tOrigBonusTxn.retrivl_ref, F037_LEN);
    
    /* save original txn info in F090 */
    memset (tSendIpcBonusTxn.sOrigDataElemts, '0', F090_LEN);
    i = 0;
    memcpy (tSendIpcBonusTxn.sOrigDataElemts+i, tOrigBonusTxn.fw_trans_id, FLD_FW_TRANS_ID_LEN);
    i += FLD_FW_TRANS_ID_LEN;
    memcpy (tSendIpcBonusTxn.sOrigDataElemts+i, tOrigBonusTxn.fw_trans_ssn, FLD_FW_TRANS_SSN_LEN);
    i += FLD_FW_TRANS_SSN_LEN;
    memcpy (tSendIpcBonusTxn.sOrigDataElemts+i, tOrigBonusTxn.fw_trans_date, FLD_FW_TRANS_DATE_LEN);
    i += FLD_FW_TRANS_DATE_LEN;
    memcpy (tSendIpcBonusTxn.sOrigDataElemts+i, tOrigBonusTxn.fw_trans_time, FLD_FW_TRANS_TIME_LEN);

    nReturnCode = SendMsg (&tSendIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SendMsg error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);

        /* �޸�tbl_txn��resp_code */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_UPDATE1, &tBonusTxn);
        if (nReturnCode)
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn DBS_UPDATE1 error, %d.", nReturnCode);
        }
        DbsCommit ();

        return -1;
    }

    HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}

int Txn3826(T_IpcIntBonusDef *pIpcBonusTxn, int nIndex )
{
    char               sFuncName[] = "Txn3826";
    char               sMsgSrcId[SRV_ID_LEN+1];
    char               sTxnNum[FLD_TXN_NUM_LEN+1];
    int                nReturnCode;
    int                nTxnSelOpr;
    int                nReqIndex;
    T_SwtToReqDef      tSwtToReq;
    Tbl_bonus_txn_Def  tBonusTxn, tOrigBonusTxn, tOrigTxn;
    T_IpcIntBonusDef   tSendIpcBonusTxn, tSendIpcBonusTxn2;
    T_IpcIntBonusDef   tSendToBonusRevsal;
    T_IpcIntBonusDef   tSendRspToPosp;
    char               sCurrentTime[15];
    char               sRespCode[F039_LEN+1];
    char               sSrcTxnNum[5];
    char               sTrackData[80];
    char               sPinData[20];
    char               sBonusRspCode[10];
	char               sOrigElement[50];
    int                i = 0;

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    memset(sCurrentTime, 0, sizeof(sCurrentTime));
    SetToTime(-1);
    memcpy(sCurrentTime, gsTimeCurTs, 14);
    
    /* ת��Ӧ���� */    
    nReturnCode = SwtCustTransferRspCode(pIpcBonusTxn);
    if (nReturnCode != 0 )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "transfer RSPCODE error");
        memcpy(pIpcBonusTxn->sRespCode, "01", F039_LEN);    
    }

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memset(sMsgSrcId, 0, sizeof(sMsgSrcId));
    memset(sBonusRspCode, 0, sizeof(sBonusRspCode));
    memcpy(sMsgSrcId, pIpcBonusTxn->sMsgSrcId, SRV_ID_LEN);
    memcpy(sBonusRspCode, pIpcBonusTxn->sRespDesp, FLD_RESP_DESP_LEN);
    memcpy(pIpcBonusTxn->sTransChnl, "POSP", 4);
    memcpy(pIpcBonusTxn->sPosCondCode, "66", 2);
    memcpy(pIpcBonusTxn->sConsumeType, "1", 1);
    memcpy(pIpcBonusTxn->sBpType, "001", 3);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  response code: %2.2s",
            pIpcBonusTxn->sTxnNum, pIpcBonusTxn->sPrimaryAcctNum, pIpcBonusTxn->sAmtTrans,
            pIpcBonusTxn->sDateLocalTrans, pIpcBonusTxn->sTimeLocalTrans,
            pIpcBonusTxn->sSysTraceAuditNum, pIpcBonusTxn->sRespCode);

    memcpy(sRespCode, pIpcBonusTxn->sRespCode, 2);
    memcpy(sSrcTxnNum, pIpcBonusTxn->sMAC064, 4);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sReturnCode:[%2.2s]", sRespCode);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sSrcId:[%4.4s], sDesId[%4.4s]", sMsgSrcId, pIpcBonusTxn->sMsgDestId);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sPosCondCode:[%2.2s],SrcTxn[%4.4s]", pIpcBonusTxn->sPosCondCode, sSrcTxnNum);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sBonusRspCode:[%7.7s]", sBonusRspCode);

    /****************************
     * ����tbl_txn�еĽ��׼�¼
     ****************************/
    nReturnCode = SetKeyRsp (pIpcBonusTxn);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMidTime [%10.10s]", pIpcBonusTxn->sMidTime);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMidSsn [%12.12s]", pIpcBonusTxn->sMidSsn);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMidTag [%8.8s]", pIpcBonusTxn->sMidTag);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransChnl [%4.4s]", pIpcBonusTxn->sTransChnl);    

    /* ����ѯ������ʹ�õ������Ƶ�tBonusTxn�� */
    memset((char *)&tBonusTxn, 0, sizeof (tBonusTxn));
    memcpy(tBonusTxn.key_rsp, pIpcBonusTxn->sKeyRsp, KEY_RSP_LEN);
    memcpy(tBonusTxn.txn_num, pIpcBonusTxn->sTxnNum, FLD_TXN_NUM_LEN);
    tBonusTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
    /* �����ݿ��в���ԭ������ */
    nReturnCode = DbsBonusTxn (DBS_SELECT21, &tBonusTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn select error[%d] Discard this message.key_rsp[%32.32s],txn_num[%4.4s]", nReturnCode, tBonusTxn.key_rsp, tBonusTxn.txn_num);                
        return -1;
    }

    tBonusTxn.consume_type[0] = '1';
	memset(sOrigElement, 0, sizeof(sOrigElement));
	memcpy(sOrigElement, tBonusTxn.msg_type, F000_MSG_TYPE_LEN);
	memcpy(&sOrigElement[F000_MSG_TYPE_LEN], tBonusTxn.key_revsal, KEY_REVSAL_LEN);

    /* ����ԭ���ף���ֵ��Ȩ��  */
    if(!memcmp(sMsgSrcId, "1903", 4) &&
       !memcmp(sSrcTxnNum, "3816", 4) &&
       !memcmp(sRespCode, "00", 2))
    {
        memset((char *)&tOrigTxn, 0, sizeof (tOrigTxn));
        memcpy(tOrigTxn.txn_num, "1825", 4);
        memcpy(tOrigTxn.key_cancel, tBonusTxn.key_cancel, KEY_CANCEL_LEN);
        nReturnCode = DbsBonusTxn(DBS_SELECT23, &tOrigTxn);
        if(nReturnCode == 0)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "tOrigTxn.authr_id_resp[%6.6s]", tOrigTxn.authr_id_r); 
            pIpcBonusTxn->cF038Ind = FLD_IND_VAL_Y;
            memcpy(pIpcBonusTxn->sAuthrIdResp, tOrigTxn.authr_id_r, F038_LEN);
            memcpy(tBonusTxn.authr_id_r, tOrigTxn.authr_id_r, F038_LEN);
            memcpy(tBonusTxn.authr_id_resp, tOrigTxn.authr_id_r, F038_LEN);
            pIpcBonusTxn->cF054Ind = FLD_IND_VAL_Y;
            memcpy(pIpcBonusTxn->sAddtnlAmtLen, "038", 3);
            memcpy(pIpcBonusTxn->sAddtnlAmt, tOrigTxn.addtnl_amt, 38);
            memcpy(tBonusTxn.addtnl_amt_len, "038", 3);
            memcpy(tBonusTxn.addtnl_amt, tOrigTxn.addtnl_amt, 38);            
        }
    }
    else
    {
        /* ��ֵmisc2 */
        memcpy(pIpcBonusTxn->sMisc2, tBonusTxn.key_rsp, KEY_RSP_LEN);
        /*memcpy(tBonusTxn.misc_2, pIpcBonusTxn->sMisc2, FLD_MISC_LEN);*/
    }
    
    /***********************
     * ���ҽ���������gatTxnInf�е�����
     ************************/
    nReturnCode = GetTxnInfoIndex (tBonusTxn.msg_src_id, tBonusTxn.txn_num, &nReqIndex );
    if (nReturnCode || nReqIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
        return -1;
    }

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (pIpcBonusTxn, &tBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (pIpcBonusTxn, &tBonusTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* ��tTxn���浽tSendIpcBonusTxn, ������Ӧ����ʹ�� */
    nReturnCode = MoveTxn2Ipc (&tBonusTxn, &tSendIpcBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* ת����Ӧ�������38��ʹ�÷�����Ӧ���е�38�� */
    if (pIpcBonusTxn->cF038Ind == FLAG_YES_C)
    {
        tSendIpcBonusTxn.cF038Ind = FLAG_YES_C;
        memcpy (tSendIpcBonusTxn.sAuthrIdResp, pIpcBonusTxn->sAuthrIdResp, F038_LEN);
    }
    else
        tSendIpcBonusTxn.cF038Ind = FLAG_NO_C;

    /***********************************************************
    *  ��齻���Ƿ�ʱ add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    if (!memcmp(tBonusTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN))
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_HAD_TO;
    else
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;

    /* set trans state if reply is not time out */
    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_TO)
    {
        if (IsRspSuccess(pIpcBonusTxn->sRespCode))
        {
            if (!memcmp(sMsgSrcId, "1702", 4))
                memcpy(tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
        }
        else
        {
            if(!memcmp(sMsgSrcId, "1903", 4))
                memcpy(tBonusTxn.trans_state, TRANS_STATE_REJ_BY_CUPS, FLD_TRANS_STATE_LEN);
            else
                memcpy(tBonusTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
        }
    }

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    /*nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);*/
    nReturnCode = DbsBonusTxn(DBS_UPDATE12, &tBonusTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn update error, %d. Discard this message.", nReturnCode);

        /* send reversal on success reply */
		memcpy(tSendIpcBonusTxn.sOrigDataElemts, sOrigElement, KEY_REVSAL_LEN+F000_MSG_TYPE_LEN);
        nReturnCode = SendRevsalOnError (&tSendIpcBonusTxn, nReqIndex, REASON_CODE_SEND_ERR);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
        }
        return -1;
    }    
   
    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_TO &&
            !IsRspSuccess (pIpcBonusTxn->sRespCode))
    {
        /* ��ʧ��Ӧ��, ����ԭʼ���׵ĳ���״̬ */
        /* select tBonusTxn to get key_cancel */
        nReturnCode = DbsBonusTxn (DBS_SELECT1, &tBonusTxn);
        if (nReturnCode )
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsBonusTxn select1 error, %d. Discard this message.", nReturnCode);

            /* send reversal on success reply */
			memcpy(tSendIpcBonusTxn.sOrigDataElemts, sOrigElement, KEY_REVSAL_LEN+F000_MSG_TYPE_LEN);
            nReturnCode = SendRevsalOnError (&tSendIpcBonusTxn, nReqIndex, REASON_CODE_SEND_ERR);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
            }
            return -1;
        }

        /* update cancel_flag according to key_cancel, txn_num */
        memcpy ((char *)&tOrigBonusTxn, (char *)&tBonusTxn, sizeof (tBonusTxn));
        tOrigBonusTxn.txn_num[INDEX_TXN_NUM_TYPE] = tOrigBonusTxn.txn_num[INDEX_TXN_NUM_TYPE] - 2;
        memset (tOrigBonusTxn.cancel_flag, REV_CAN_FLAG_NORMAL, 1);
        nReturnCode = DbsBonusTxn (DBS_UPDATE3, &tOrigBonusTxn);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn DBS_UPDATE3 error, %d.", nReturnCode);
        }

    }

    DbsCommit ();    

    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_HAD_TO)
    {
        /* ��ʱӦ�� */
        /* send reversal on late success reply */
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Received late response.");
        memcpy(tSendIpcBonusTxn.sOrigDataElemts, sOrigElement, KEY_REVSAL_LEN+F000_MSG_TYPE_LEN);
		nReturnCode = SendRevsalOnError (&tSendIpcBonusTxn, nReqIndex, REASON_CODE_LATE_RSP);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
        }
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Reversal for late successful response sent out.");
    }
    else
    {
        /* Ӧ��δ��ʱ */
        /****************** 
          ���Ի���ϵͳ:�����ɹ�
          ȥ���ÿ�����
        *******************/
        if(!memcmp(sMsgSrcId, "1903", 4) &&
           !memcmp(sSrcTxnNum, "3816", 4) &&
           !memcmp(sRespCode, "00", 2))
        {
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "bonus acct succ. begin send to credit");

            /* ����sTxnNum, sKeyRsp��sMisc2,������tbl_txn�еĽ��׼�¼ʹ��  */
            memcpy(tSendIpcBonusTxn.sKeyRsp, pIpcBonusTxn->sKeyRsp, KEY_RSP_LEN);
            memcpy(tSendIpcBonusTxn.sMisc2, pIpcBonusTxn->sKeyRsp, KEY_RSP_LEN);
            memcpy(tSendIpcBonusTxn.sMisc2+KEY_RSP_LEN, tSendIpcBonusTxn.sTxnNum, 4);

            memcpy(tSendIpcBonusTxn.sMsgDestId, "1702", 4);

            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                          "misc_2track[%37.37s]", tBonusTxn.misc_2+50);
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                          "misc_2pin[%8.8s]", tBonusTxn.misc_2+50+37);
            memset(sTrackData, 0, sizeof(sTrackData));
            memset(sPinData, 0, sizeof(sPinData));
            memcpy(sTrackData, tBonusTxn.misc_2+50, 37);
            memcpy(sPinData, tBonusTxn.misc_2+50+37, 8);

            /* ���½��׽����54�� */
            SwtCustBeforeTblTxnOpr(&tSendIpcBonusTxn, &tBonusTxn, &tBonusTxn);
            tBonusTxn.trans_state[0] = '0';
            nReturnCode = DbsBonusTxn(DBS_UPDATE1, &tBonusTxn);
            if (nReturnCode)
            {
                DbsRollback();
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert1 error, %d.", nReturnCode);
            }
            DbsCommit();
            
            memcpy(tSendIpcBonusTxn.sTxnNum, "3825", 4);
            memcpy(tSendIpcBonusTxn.sTrack2Data, sTrackData, F035_VAL_LEN);
            if(memcmp(sPinData, "NPINNPIN", 8) != 0)
            {
                tSendIpcBonusTxn.cF052Ind = FLAG_YES_C;
                memcpy(tSendIpcBonusTxn.sPinData, sPinData, 8);
            }

            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
                          "sTrack2Data[%37.37s]", tSendIpcBonusTxn.sTrack2Data);            

            HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
                          tSendIpcBonusTxn.sPinData, sizeof(tSendIpcBonusTxn.sPinData));            

            nReturnCode = SendMsg(&tSendIpcBonusTxn, &tBonusTxn, &tBonusTxn);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                          "SendMsg error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);

                /* ����Ӧ���״��� */
                memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
                /* ����Ӧ��SrvId */
                memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
                /* ���Ĵ���Ӧ���� */
                memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
                /* ����Ӧ�� msg type */
                pIpcBonusTxn->sMsgType[2]++;
        
                nReturnCode = SendMsg(pIpcBonusTxn, &tBonusTxn, NULL);

                /* �޸�tbl_txn��resp_code */
                DbsBegin ();
                memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
                memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
                nReturnCode = DbsBonusTxn (DBS_UPDATE1, &tBonusTxn);
                if (nReturnCode)
                {
                    DbsRollback ();
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert1 error, %d.", nReturnCode);
                }
                DbsCommit ();
                return -1;
            }
        }
        /****************** 
          ���Ի���ϵͳ:����ʧ��
          �����ն�ʧ��
        *******************/
        else if(!memcmp(sMsgSrcId, "1903", 4) &&
                !memcmp(sSrcTxnNum, "3816", 4) &&
                memcmp(sRespCode, "00", 2))
        {
            /* ���½���״̬Ϊ�鿨ʧ�ܣ�trans_state='2' */
            tBonusTxn.trans_state[0] = '2';
            nReturnCode = DbsBonusTxn(DBS_UPDATE13, &tBonusTxn);
            if(nReturnCode)
            {
                DbsRollback();
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "DbsBonusTxn update trans_state error[%d]", nReturnCode);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
                return -1;
            }
            DbsCommit();
            
            /***********************
             *  �ͻ���Ŀ��IPC��������
            ************************/
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "bonus acct fail. begin send to POSP");
            memcpy ((char *)&tSendRspToPosp, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));

            /* ����Ӧ���״��� */
            memcpy(tSendRspToPosp.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN);

            /* ����Ӧ��SrvId */
            memcpy(tSendRspToPosp.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendRspToPosp.sMsgType[2]++;

            nReturnCode = SendMsg(&tSendRspToPosp, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
                return -1;
            }

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");

        }
        /****************** 
          �������ÿ�:�����ɹ�
          �����ն˳ɹ�
        *******************/
        else if(!memcmp(sMsgSrcId, "1702", 4) &&
                !memcmp(sSrcTxnNum, "3826", 4) &&
                !memcmp(sRespCode, "00", 2))
        {
            /* �������ݿ� */
            tBonusTxn.trans_state[0] = '1';
            nReturnCode = DbsBonusTxn(DBS_UPDATE11, &tBonusTxn);
            if(nReturnCode)
            {
                DbsRollback ();
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                  "DbsBonusTxn update error, %d. Discard this message.", nReturnCode);
      
                /* send reversal on success reply */
				memcpy(tSendIpcBonusTxn.sOrigDataElemts, sOrigElement, KEY_REVSAL_LEN+F000_MSG_TYPE_LEN);
                nReturnCode = SendRevsalOnError (&tSendIpcBonusTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if(nReturnCode)
                {
                    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
                return -1;
            }
            DbsCommit();

            /***********************
             *  �ͻ���Ŀ��IPC��������
             ************************/
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "credit acct succ, resp to POSP");
            memcpy((char *)&tSendRspToPosp, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));

            /* ����Ӧ���״��� */
            memcpy(tSendRspToPosp.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN);

            /* ����Ӧ��SrvId */
            memcpy(tSendRspToPosp.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendRspToPosp.sMsgType[2]++;

            nReturnCode = SendMsg (&tSendRspToPosp, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);
                return -1;
            }

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
        }

        /****************** 
          �������ÿ�:����ʧ��
          ����POSP����ʧ�ܵ�Ӧ��Ȼ�������ϵͳ�������
        *******************/
        else if(!memcmp(sMsgSrcId, "1702", 4) &&
                !memcmp(sSrcTxnNum, "3826", 4) &&
                memcmp(sRespCode, "00", 2))
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"credit acct fail, begin send Revsal to bonus");
            /* ���½���״̬Ϊ���ÿ�����ʧ�ܣ�trans_state='4' */
            tBonusTxn.trans_state[0] = '4';
            nReturnCode = DbsBonusTxn(DBS_UPDATE13, &tBonusTxn);
            if(nReturnCode)
            {
                DbsRollback();
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "DbsBonusTxn update trans_state error[%d]", nReturnCode);
                /* �����ʱ���� */
                tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
                return -1;
            }
            DbsCommit();

            /*-------- ��ǰ��POSP����ʧ�ܵ�Ӧ�� --------------- */

            /***********************
             *  �ͻ���Ŀ��IPC��������
            ************************/
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "bonus Revsal succ, begin send to POSP");
            memcpy ((char *)&tSendRspToPosp, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));

            /* ����Ӧ���״��� */
            memcpy(tSendRspToPosp.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN);

            /* ����Ӧ��SrvId */
            memcpy(tSendRspToPosp.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendRspToPosp.sMsgType[2]++;

            nReturnCode = SendMsg (&tSendRspToPosp, &tBonusTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);
                return -1;
            }

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");

            
            /*--------------- �����ϵͳ�������� --------------------------*/
            memcpy((char *)&tSendToBonusRevsal, &tSendIpcBonusTxn, sizeof(tSendIpcBonusTxn));

            memcpy(tSendToBonusRevsal.sMsgDestId, "1903", 4);
            memcpy(tSendToBonusRevsal.sTxnNum, "4815", 4);

            /* save original txn info in F090 */
            memset (tSendToBonusRevsal.sOrigDataElemts, '0', F090_LEN);
            i = 0;
            memcpy (tSendToBonusRevsal.sOrigDataElemts+i, tBonusTxn.fw_trans_id, FLD_FW_TRANS_ID_LEN);
            i += FLD_FW_TRANS_ID_LEN;
            memcpy (tSendToBonusRevsal.sOrigDataElemts+i, tBonusTxn.fw_trans_ssn, FLD_FW_TRANS_SSN_LEN);
            i += FLD_FW_TRANS_SSN_LEN;
            memcpy (tSendToBonusRevsal.sOrigDataElemts+i, tBonusTxn.fw_trans_date, FLD_FW_TRANS_DATE_LEN);
            i += FLD_FW_TRANS_DATE_LEN;
            memcpy (tSendToBonusRevsal.sOrigDataElemts+i, tBonusTxn.fw_trans_time, FLD_FW_TRANS_TIME_LEN);

            memcpy(tSendToBonusRevsal.sMiscFlag+14, "1", 1);

            SwtCustBeforeTblTxnOpr(&tSendToBonusRevsal, &tBonusTxn, &tBonusTxn);

            nReturnCode = SendMsg (&tSendToBonusRevsal, &tBonusTxn, &tBonusTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

            nReturnCode = InsertSafMsg(&tSendToBonusRevsal, &tBonusTxn, gatTxnInf[nIndex].saf_count1);
            if(nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
            
        }
        else
        {
            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "error, no find process.\nMsgSrcId[%4.4s]\nSrcTxnNum[%4.4s]\nRespCode[%2.2s]", sMsgSrcId,sSrcTxnNum,sRespCode);
        }
    }

    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}

