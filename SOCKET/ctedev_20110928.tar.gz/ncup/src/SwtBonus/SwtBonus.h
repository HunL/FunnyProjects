#ifndef __SWITCH_BP_H
#define __SWITCH_BP_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <math.h>
#include <errno.h>
#include <string.h>
#include <memory.h>
#include <ctype.h> 
#include <signal.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "MsqOpr.h"
#include "ToOpr.h"
#include "HtLog.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "TxnNum.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "EncOpr.h"
#include "LineStat.h"
#include "CstDbsTbl.h"
#include "BPIpcInt.h"
#include "BufChg.h"
/*#include "XFT.h"*/
bciMBufChgInfDef	tBufChgRule;
#define MSG_SRC_ID_ANY      "9999"
/* tbl_card_inf��¼��, ֻ�������п� */
#define CARD_INF_NUM_MAX		100

#define LINE_SEPARATOR "============================================="

#define SWT_USE_RSP_38	"SWT_USE_RSP_38"

/* global variables */
char				gsSrvId[SRV_ID_LEN+1];
char				gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char				gsLogFile[LOG_NAME_LEN_MAX];
int					gnTxnInfNum;
Tbl_txn_inf_Def		gatTxnInf[TXN_INF_NUM_MAX];
T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];
int					gnCardInfNum;
Tbl_card_inf_Def	gatCardInf[CARD_INF_NUM_MAX];
char				gsParamMsgCompressFlag[2];

typedef struct
{
    char    caTxnNum[FLD_TXN_NUM_LEN+1];
    char    caMsgSrcId[SRV_ID_LEN+1];
    int     (*pfTxnFun)(T_IpcIntBonusDef *, int );
    char    caTxnDsp[50];
} TXNFUN;

extern TXNFUN gaTxns[MAXTXNS];

/* internal functions */
int SwitchInit (short argc, char **argv);
int GetTxnInfoIndex( char *sMsgSrcId, char *sTxnNum, int *nIndex );
void HandleExit (int n);
void showIpc(T_IpcIntTxnDef *InIpc);

int HandlePOSNormalReq (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int HandlePOSNormalRsp (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int HandlePOSRevsalReq (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int HandlePOSRevsalRsp (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int HandlePOSCancelReq (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int HandlePOSCancelRsp (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int HandlePOSCancelRevsalReq (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int HandlePOSCancelRevsalRsp (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );

int Txn1825 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int Txn1826 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );

int Txn2825 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int Txn2826 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );

int Txn3825 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int Txn3826 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );

int Txn4825 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int Txn4826 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );

int Txn5835 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int Txn5836 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );

int Txn5845 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int Txn5846 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );

int HandleSCCNormalReq (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );
int HandleSCCNormalRsp (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex );

/*int HandlePOSCancelReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandlePOSCancelRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandlePOSRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandlePOSRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandlePOSCancelRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandlePOSCancelRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );


int HandleSCCNormalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleSCCNormalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleSCCCancelRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleSCCCancelRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleSCCRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleSCCRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleSCCCancelRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleSCCCancelRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int TxnPOSNoticeReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TxnPOSNoticeRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTimeOut (char *sMsgBuf );*/

#endif
