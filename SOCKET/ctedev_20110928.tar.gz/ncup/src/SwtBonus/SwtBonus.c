/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Switch.c                                                    */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBonus/SwtBonus.c,v 1.2.2.1 2011/09/23 02:54:35 ctedev Exp $";

#include "SwtBonus.h"
#include "SwtBonusTxn.h"

void showBPIpc(T_IpcIntBonusDef *InIpc);

int main( int argc, char **argv )
{
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    char            sIntMsgBuf[MSQ_MSG_SIZE_MAX];
    char            sTxnType[FLD_TXN_NUM_LEN+1];
    int             i;
    int             nTxnType;
    int             nReturnCode;
    int             nMsgLen;
    int             nIntMsgLen;
    int             nIndex;
    long            lBeginTime, lEndTime;
    T_IpcIntTxnDef    tIpcIntTxn;
    T_IpcIntBonusDef tIpcBonusTxn;
    struct tms        tTMS;

    nReturnCode = SwitchInit( argc, argv);
    if ( nReturnCode != 0 )
    {
        printf("Switch: SwitchInit error %d\n", nReturnCode);
        return;
    }

    if (sigset(SIGTERM, HandleExit) == SIG_ERR)
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d.", errno);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Switch started.");

    lBeginTime = 0;
    lEndTime = 0;

    while(1)
    {
        /* ����Ϣ�����л�ȡ��Ϣ */
        memset (sMsgBuf, 0, sizeof(sMsgBuf) );
        sigrelse (SIGTERM);
        nMsgLen = MSQ_MSG_SIZE_MAX;
        nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, &nMsgLen, sMsgBuf);
        sighold (SIGTERM);
        if (nReturnCode)
        {
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
            {
                HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqRcv error, %d.", nReturnCode);
                return;
            }
            else
                continue;
        }

        lBeginTime = times( &tTMS);
        /* uncompress msg */
        if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
        {
            /* uncompress msg */
            /* sMsgBuf, nMsgLen -> sIntMsgBuf, nIntMsgLen */
            UnCompressbuf(sMsgBuf, nMsgLen, sIntMsgBuf, &nIntMsgLen);

            nMsgLen = nIntMsgLen;
            memcpy (sMsgBuf, sIntMsgBuf, nIntMsgLen);
        }

        HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s", LINE_SEPARATOR);
        HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, sMsgBuf, nMsgLen);

        /* process msg according to msg source */
        memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
        memcpy (sMsgSrcId, sMsgBuf, SRV_ID_LEN);

        if (!memcmp (sMsgSrcId, SRV_ID_TOCTL, SRV_ID_LEN))
            nReturnCode = HandleTimeOut (sMsgBuf);
        else if(!memcmp (sMsgSrcId, "1903", SRV_ID_LEN)||
        	    !memcmp (sMsgSrcId, "1831", SRV_ID_LEN))
        {
            memcpy ((char *)&tIpcBonusTxn, sMsgBuf, sizeof (tIpcBonusTxn));
            
            /* Save front SSN in sTermSSN */
            /*memcpy (tIpcIntTxn.sTermSSN, tIpcIntTxn.sSysTraceAuditNum, F011_LEN);
            memcpy (tIpcIntTxn.sOpenInst, gsSrvId, 4);*/
            memset (sTxnType, 0, sizeof (sTxnType));
			memcpy (sTxnType, tIpcBonusTxn.sTxnNum, TXN_TYPE_LEN);
			nTxnType = atoi (sTxnType);
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TxnType[%d]--[%s]", nTxnType,sTxnType);
			
       	if((tIpcBonusTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ))
			{
					nReturnCode = GetTxnInfoIndex( tIpcBonusTxn.sMsgSrcId, tIpcBonusTxn.sTxnNum, &nIndex );
			}
			else
			{
					nReturnCode = 0;
			}                  
            
 /* END */           
            if ( nReturnCode != 0 )
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetTxnInfoIndex error.");
                return -1;
            }
            memcpy( tIpcBonusTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );/*add by fucl*/

            for( i = 0; i < MAXTXNS; i++ )
            {
                if( memcmp( tIpcBonusTxn.sTxnNum, gaTxns[i].caTxnNum, FLD_TXN_NUM_LEN ) == 0 )
                {
                    if (memcmp( gaTxns[i].caMsgSrcId, MSG_SRC_ID_ANY, SRV_ID_LEN ) == 0 )
                    {
                        break;
                    }
                    else
                    {
                        if (memcmp( tIpcBonusTxn.sMsgSrcId, gaTxns[i].caMsgSrcId, SRV_ID_LEN ) == 0 )
                        {
                            break;
                        }
                    }
                }
            }
            
            /*�������ݿ��Ƿ�״̬�ļ�� add 20110718*/		
            nReturnCode = -1;
            nReturnCode = DbReconnectTest();
            if(nReturnCode != 0)
            {
			 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 	"\n  TXN: %4.4s\n  F002: %19.19s\n  F004: %12.12s\n  F007: %10.10s\n F011: %12.12s\n", 
			 	gatTxnInf[nIndex].txn_num, tIpcBonusTxn.sPrimaryAcctNum, tIpcBonusTxn.sAmtTrans, 	tIpcBonusTxn.sMidTime, tIpcBonusTxn.sMidSsn);    
			 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DataBase status is error ,Discard this message, nReturnCode=[%d]", nReturnCode);    	       
		    } /*  added end */
		    else
            {
                if( i == MAXTXNS )
                {
                    nReturnCode = SwtCustHandleTransaction(&tIpcBonusTxn, nIndex);
                }
                else
                {
                    nReturnCode = gaTxns[i].pfTxnFun(&tIpcBonusTxn, nIndex);
                }
            }

            lEndTime = times( &tTMS);
            HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "Txn %s processed, used %ld ticks  i is %d",
                    gaTxns[i].caTxnNum, lEndTime - lBeginTime, i);
        }
        else if(!memcmp (sMsgSrcId, "1801", SRV_ID_LEN) ||
                !memcmp (sMsgSrcId, "1802", SRV_ID_LEN) ||
                !memcmp (sMsgSrcId, SRV_ID_COMM_CC, SRV_ID_LEN))
        {
            memcpy ((char *)&tIpcIntTxn, sMsgBuf, sizeof (tIpcIntTxn));
            
            /* Save front SSN in sTermSSN */
            memcpy (tIpcIntTxn.sTermSSN, tIpcIntTxn.sSysTraceAuditNum, F011_LEN);
            memcpy (tIpcIntTxn.sOpenInst, gsSrvId, 4);
            
            memset (sTxnType, 0, sizeof (sTxnType));
			memcpy (sTxnType, tIpcIntTxn.sTxnNum, TXN_TYPE_LEN);
			nTxnType = atoi (sTxnType);
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TxnType[%d]", nTxnType);
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TxnType[%d]--[%s]", nTxnType,sTxnType);
			
       	    if((tIpcIntTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ))
			{
					nReturnCode = GetTxnInfoIndex( tIpcIntTxn.sMsgSrcId, tIpcIntTxn.sTxnNum, &nIndex );
			}
			else
			{
					nReturnCode = 0;
			}
            
 /* END */           
            if ( nReturnCode != 0 )
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetTxnInfoIndex error.");
                return -1;
            }
            memcpy( tIpcIntTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );/*add by fucl*/
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sTxnNum[%4.4s]", tIpcIntTxn.sTxnNum);

            for( i = 0; i < MAXTXNS; i++ )
            {
                if( memcmp( tIpcIntTxn.sTxnNum, gaTxns[i].caTxnNum, FLD_TXN_NUM_LEN ) == 0 )
                {
                    if (memcmp( gaTxns[i].caMsgSrcId, MSG_SRC_ID_ANY, SRV_ID_LEN ) == 0 )
                    {
                        break;
                    }
                    else
                    {
                        if (memcmp( tIpcIntTxn.sMsgSrcId, gaTxns[i].caMsgSrcId, SRV_ID_LEN ) == 0 )
                        {
                            break;
                        }
                    }
                }
            }
            
            /* ת����IPC */
             HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sTxnNum[%4.4s]", tIpcIntTxn.sTxnNum);
            showIpc( &tIpcIntTxn );
            memset(&tIpcBonusTxn, ' ', sizeof(T_IpcIntBonusDef));
            nReturnCode = BufChgOpr(40,&tIpcIntTxn,&tIpcBonusTxn,&tBufChgRule);
            if(nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "BufChgOpr err, index 40.");
                continue;
            }
            showBPIpc( &tIpcBonusTxn );
            
            if(!memcmp (sMsgSrcId, "1801", SRV_ID_LEN) || !memcmp (sMsgSrcId, "1802", SRV_ID_LEN) )
               memcpy(tIpcBonusTxn.sTransChnl, "POSP", 4);
			else
			   memcpy(tIpcBonusTxn.sTransChnl, tIpcBonusTxn.sKeyRsp+16, 4);			
            
            /*�������ݿ��Ƿ�״̬�ļ�� add 20110718*/		
            nReturnCode = -1;
            nReturnCode = DbReconnectTest();
            if(nReturnCode != 0)
            {
			 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 	"\n  TXN: %4.4s\n  F002: %19.19s\n  F004: %12.12s\n  F007: %10.10s\n F011: %6.6s\n", 
			 	gatTxnInf[nIndex].txn_num, tIpcBonusTxn.sPrimaryAcctNum, tIpcBonusTxn.sAmtTrans, 	tIpcBonusTxn.sTransmsnDateTime, tIpcBonusTxn.sSysTraceAuditNum);    
			 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DataBase status is error ,Discard this message, nReturnCode=[%d]", nReturnCode);    	       
		    } /*  added end */
		    else
            {
                if( i == MAXTXNS )
                {
                    nReturnCode = SwtCustHandleTransaction(&tIpcBonusTxn, nIndex);
                }
                else
                {
                    nReturnCode = gaTxns[i].pfTxnFun(&tIpcBonusTxn, nIndex);
                }
            }

            lEndTime = times( &tTMS);
            HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "Txn %s processed, used %ld ticks  i is %d",
                    gaTxns[i].caTxnNum, lEndTime - lBeginTime, i);
        }
        else
        {
            HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "error, unknown src id [%4.4s].", sMsgSrcId);
            continue;
        }

    }

}
/*****************************************************************************/
/* FUNC:   int SwitchInit ( );                                               */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ʼ��ϵͳ��̬����,����,������Ϣ��                                */
/*****************************************************************************/
int SwitchInit (short argc, char **argv)
{
    int                i;
    int                nReturnCode;
    long            lUsageKey;
    Tbl_srv_inf_Def    tTblSrvInf;

    /* get server id, arg 1 */
    strcpy (gsSrvId, argv[1]);
    strcpy (gsSrvSeqId, argv[2]);
    /* get parameter, compress flag */
    if (getenv(MSG_COMPRESS_FLAG))
    {
        strcpy (gsParamMsgCompressFlag, getenv(MSG_COMPRESS_FLAG));
    }
    else
        strcpy (gsParamMsgCompressFlag, FLAG_NO);

    if (getenv(SRV_USAGE_KEY))
        lUsageKey=atoi (getenv(SRV_USAGE_KEY));
    else
        return -1;

    /* connect to database */
    nReturnCode = DbsConnect ();
    if (nReturnCode)
        return (nReturnCode);

    /* get log file name from tbl_srv_inf */
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nReturnCode)
    {
        DbsDisconnect ();
        return (nReturnCode);
    }
    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (gsLogFile, "%s.%s.log", gsSrvId, gsSrvSeqId);

    /* init msg queue */
    memset ((char *)gatSrvMsq, 0, SRV_MSQ_NUM_MAX * sizeof (T_SrvMsq));
    nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d.", nReturnCode);
        DbsDisconnect ();
        return (nReturnCode);
    }
    /* ��ʼ��������Ϣ�� */
    memset( (char *)gatTxnInf, 0, sizeof(gatTxnInf) );
    gnTxnInfNum = TXN_INF_NUM_MAX;
    nReturnCode = DbsTxnInfLoad (&gnTxnInfNum, gatTxnInf);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxnInfLoad error, %d.", nReturnCode);
        DbsDisconnect ();
        return (nReturnCode);
    }
    /*����BUGCHGROULE*/
    memset(&tBufChgRule,0,sizeof(bciMBufChgInfDef));
	nReturnCode = BufChgLoad(1,&tBufChgRule);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "BufChgLoad error, %d.", nReturnCode);	  
		DbsDisconnect ();
		return (nReturnCode);
	}

	/* ���ؽ���Ӧ����ת���� */
    nReturnCode = LoadRspCodeMap(&gnMaxRspCodeMapLen, &tRspCodeMap);
    HtLog(	gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "gnMaxRspCodeMapLen:[%d]",gnMaxRspCodeMapLen);
 	if(nReturnCode)
	{
		 HtLog(	gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LoadRspCodeMap %d.", nReturnCode);
		 DbsDisconnect ();
		 return nReturnCode;
	}

    return 0;
}

/*****************************************************************************/
/* FUNC:   int GetTxnInfoIndex                                               */
/* INPUT:  ���״���                                                          */
/* OUTPUT: ��Ӧ��gatTblTxnInf�ṹ������, δ�ҵ�ʱֵΪ-1                      */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���״�����db_txn_inf�ṹ������                                  */
/*****************************************************************************/
int GetTxnInfoIndex( char *sMsgSrcId, char *sTxnNum, int *nIndex )
{
    char    sFuncName[] = "GetTxnInfoIndex";
    int        i;
    
          	

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    *nIndex = -1;
    for( i = 0; i < gnTxnInfNum; i++ )
    {
        if (!memcmp(gatTxnInf[i].msg_src_id, sMsgSrcId, SRV_ID_LEN) &&
                !memcmp(gatTxnInf[i].txn_num, sTxnNum, FLD_TXN_NUM_LEN) )
        {
            *nIndex = i;
            break;
        }
    }

    if( i == gnTxnInfNum )
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", sTxnNum, sMsgSrcId);
    }

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end  index is %d.", sFuncName, i);
    
   
    
    
    return 0;
}

void HandleExit (int n)
{
    DbsDisconnect ();
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Switch exits.");
    exit( 1 );
}
void showBPIpc(T_IpcIntBonusDef *InIpc)
{
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgSrcId:\t%.4s", InIpc->sMsgSrcId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgDestId:\t%.4s", InIpc->sMsgDestId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsqType:\t%.16s", InIpc->sMsqType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sBpHeader:\t%.80s",InIpc->sBpHeader); 
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSysSeqNum:\t%.6s", InIpc->sSysSeqNum);   
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransChnl:\t%.4s", InIpc->sTransChnl);                                            
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransState:\t%.1s", InIpc->sTransState);    
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwTransDate:\t%.8s", InIpc->sFwTransDate); 
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwTransTime:\t%.6s", InIpc->sFwTransTime);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwTransSsn:\t%.22s", InIpc->sFwTransSsn);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMidTime:\t%.10s", InIpc->sMidTime);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMidSsn:\t%.12s", InIpc->sMidSsn);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMidTag:\t%.8s", InIpc->sMidTag); 
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyRsp:\t%.32s", InIpc->sKeyRsp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyRevsal:\t%.32s", InIpc->sKeyRevsal);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyCancel:\t%.32s", InIpc->sKeyCancel);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTxnNum:\t%.4s", InIpc->sTxnNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransCode:\t%.3s", InIpc->sTransCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgType:\t%.4s", InIpc->sMsgType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF002Ind:\t%c", InIpc->cF002Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPrimaryAcctNumLen:\t%.2s", InIpc->sPrimaryAcctNumLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPrimaryAcctNum:\t%.19s", InIpc->sPrimaryAcctNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sProcessingCode:\t%.6s", InIpc->sProcessingCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtTrans:\t%.12s", InIpc->sAmtTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransmsnDateTime:\t%.10s", InIpc->sTransmsnDateTime);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSysTraceAuditNum:\t%.6s", InIpc->sSysTraceAuditNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTimeLocalTrans:\t%.6s", InIpc->sTimeLocalTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateLocalTrans:\t%.4s", InIpc->sDateLocalTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF014Ind:\t%c", InIpc->cF014Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateExpr:\t%.4s", InIpc->sDateExpr);    
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateSettlmt:\t%.4s", InIpc->sDateSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMchntType:\t%.4s", InIpc->sMchntType);   
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosEntryModeCode:\t%.3s", InIpc->sPosEntryModeCode);  
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosCondCode:\t%.2s", InIpc->sPosCondCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF026Ind:\t%c", InIpc->cF026Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosPinCaptrCode:\t%.2s", InIpc->sPosPinCaptrCode);   
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstIdCodeLen:\t%.2s", InIpc->sAcqInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstIdCode:\t%.11s", InIpc->sAcqInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwdInstIdCodeLen:\t%.2s", InIpc->sFwdInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwdInstIdCode:\t%.11s", InIpc->sFwdInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF035Ind:\t%c", InIpc->cF035Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack2DataLen:\t%.2s", InIpc->sTrack2DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack2Data:\t%.37s", InIpc->sTrack2Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF036Ind:\t%c", InIpc->cF036Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack3DataLen:\t%.3s", InIpc->sTrack3DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack3Data:\t%.104s", InIpc->sTrack3Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRetrivlRefNum:\t%.12s", InIpc->sRetrivlRefNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF038Ind:\t%c", InIpc->cF038Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAuthrIdResp:\t%.6s", InIpc->sAuthrIdResp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRespCode:\t%.2s", InIpc->sRespCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrTermnlId:\t%.8s", InIpc->sCardAccptrTermnlId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrId:\t%.15s", InIpc->sCardAccptrId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrNameLoc:\t%.40s", InIpc->sCardAccptrNameLoc);      
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeTrans:\t%.3s", InIpc->sCurrcyCodeTrans);   
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF052Ind:\t%c", InIpc->cF052Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPinData:\t%.8s", InIpc->sPinData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF053Ind:\t%c", InIpc->cF053Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSecRelatdCtrlInfo:\t%.16s", InIpc->sSecRelatdCtrlInfo);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF054Ind:\t%c", InIpc->cF054Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlAmtLen:\t%.3s", InIpc->sAddtnlAmtLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlAmt:\t%.120s", InIpc->sAddtnlAmt); 
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFldReservedLen:\t%.3s", InIpc->sFldReservedLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFldReserved:\t%.30s", InIpc->sFldReserved); 
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF062Ind:\t%c", InIpc->cF062Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSwitchingDataLen:\t%.3s", InIpc->sSwitchingDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSwitchingData:\t%.200s", InIpc->sSwitchingData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sOrigDataElemts:\t%.42s", InIpc->sOrigDataElemts);  
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF122Ind:\t%c", InIpc->cF122Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstResvdLen:\t%.3s", InIpc->sAcqInstResvdLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstResvd:\t%.100s", InIpc->sAcqInstResvd);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF064Ind:\t%c", InIpc->cF064Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMAC064:\t%.8s", InIpc->sMAC064);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF128Ind:\t%c", InIpc->cF128Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMAC128:\t%.8s", InIpc->sMAC128);    
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sOrderId:\t%.18s", InIpc->sOrderId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sBpType:\t%.3s", InIpc->sBpType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConsumeType:\t%.1s", InIpc->sConsumeType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRespDesp:\t%.7s", InIpc->sRespDesp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMiscFlag:\t%.32s", InIpc->sMiscFlag);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMisc1:\t%.128s", InIpc->sMisc1);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMisc2:\t%.128s", InIpc->sMisc2);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sLoopReq:\t%.512s", InIpc->sLoopReq);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sLoopRsp:\t%.512s", InIpc->sLoopRsp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "===========================================================\n" );
}

void showBPTxn(Tbl_bonus_txn_Def *ptTxn)
{
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " inst_date: \t%.8s",        ptTxn->inst_date);                                                            
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " sys_seq_num: \t%.6s",      ptTxn->sys_seq_num);                                              
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " inst_time: \t%.6s",        ptTxn->inst_time);                                                
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " msg_src_id: \t%.4s",       ptTxn->msg_src_id);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " txn_num: \t%.4s",          ptTxn->txn_num);                                                  
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " trans_code: \t%.3s",       ptTxn->trans_code);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " trans_chnl: \t%.4s",       ptTxn->trans_chnl);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " trans_state: \t%.1s",      ptTxn->trans_state);                                              
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " revsal_flag: \t%.1s",      ptTxn->revsal_flag);                                              
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " revsal_ssn: \t%.6s",       ptTxn->revsal_ssn);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " cancel_flag: \t%.1s",      ptTxn->cancel_flag);                                              
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " cancel_ssn: \t%.6s",       ptTxn->cancel_ssn);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " fw_trans_date: \t%.8s",    ptTxn->fw_trans_date);                                            
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " fw_trans_time: \t%.6s",    ptTxn->fw_trans_time);                                            
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " fw_trans_ssn: \t%.22s",    ptTxn->fw_trans_ssn);                                             
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " mid_time: \t%.10s",        ptTxn->mid_time);                                                 
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " mid_ssn: \t%.12s",         ptTxn->mid_ssn);                                                  
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " mid_tag: \t%.8s",          ptTxn->mid_tag);                                                  
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " key_rsp: \t%.32s",         ptTxn->key_rsp);                                                  
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " key_revsal: \t%.32s",      ptTxn->key_revsal);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " key_cancel: \t%.32s",      ptTxn->key_cancel);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " bp_header: \t%.80s",       ptTxn->bp_header);                                                
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " msg_type: \t%.4s",         ptTxn->msg_type);                                                 
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " pan_len: \t%.2s",          ptTxn->pan_len);                                                  
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " pan: \t%.19s",             ptTxn->pan);                                                      
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " processing_code: \t%.6s",  ptTxn->processing_code);                                          
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " amt_trans: \t%.12s",       ptTxn->amt_trans);                                                
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " point_trans: \t%.12s",     ptTxn->point_trans);                                              
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " trans_date_time: \t%.10s", ptTxn->trans_date_time);                                          
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " time_local_trans: \t%.6s", ptTxn->time_local_trans);                                         
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " date_local_trans: \t%.4s", ptTxn->date_local_trans);                                         
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " date_settlmt: \t%.8s",     ptTxn->date_settlmt);                                             
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " mchnt_type: \t%.4s",       ptTxn->mchnt_type);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " pos_entry_mode: \t%.3s",   ptTxn->pos_entry_mode);                                           
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " pos_cond_code: \t%.2s",    ptTxn->pos_cond_code);                                            
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " pos_pin_cap_code: \t%.2s", ptTxn->pos_pin_cap_code);                                         
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " acq_inst_id_code: \t%.11s",ptTxn->acq_inst_id_code);                                         
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " fwd_inst_id_code: \t%.11s",ptTxn->fwd_inst_id_code);                                         
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " retrivl_ref: \t%.12s",     ptTxn->retrivl_ref);                                              
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " authr_id_resp: \t%.6s",    ptTxn->authr_id_resp);                                            
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " resp_code: \t%.2s",        ptTxn->resp_code);                                                
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " resp_desp: \t%.7s",        ptTxn->resp_desp);                                                
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " card_accp_term_id: \t%.8s",ptTxn->card_accp_term_id);                                        
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " card_accp_id: \t%.15s",    ptTxn->card_accp_id);                                             
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " card_accp_name: \t%.40s",  ptTxn->card_accp_name);                                           
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " currcy_code_trans: \t%.3s",ptTxn->currcy_code_trans);                                        
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " addtnl_amt_len: \t%.3s",   ptTxn->addtnl_amt_len);                                           
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " addtnl_amt: \t%.40s",      ptTxn->addtnl_amt);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " fld_reserved_len: \t%.3s", ptTxn->fld_reserved_len);                                         
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " fld_reserved: \t%.30s",    ptTxn->fld_reserved);                                             
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " switch_data_len: \t%.3s",  ptTxn->switch_data_len);                                          
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " switch_data: \t%.200s",    ptTxn->switch_data);                                              
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " acq_swresved_len: \t%.3s", ptTxn->acq_swresved_len);                                         
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " acq_swresved: \t%.100s",   ptTxn->acq_swresved);                                             
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " tom_flag_1: \t%.2s",       ptTxn->tom_flag_1);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " tom_flag_2: \t%.26s",      ptTxn->tom_flag_2);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " msq_type: \t%.16s",        ptTxn->msq_type);                                                 
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " amt_return: \t%.12s",      ptTxn->amt_return);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " authr_id_r: \t%.6s",       ptTxn->authr_id_r);                                               
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " order_id: \t%.18s",        ptTxn->order_id);                                                 
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " bp_type: \t%.3s",          ptTxn->bp_type);                                                  
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " consume_type: \t%.1s",     ptTxn->consume_type);                                             
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " misc_flag: \t%.32s",       ptTxn->misc_flag);                                                
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " misc_1: \t%.128s",         ptTxn->misc_1);                                                   
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " misc_2: \t%.128s",         ptTxn->misc_2);                                                   
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " loop_req: \t%.512s",       ptTxn->loop_req);                                                 
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " loop_rsp: \t%.512s",       ptTxn->loop_rsp);                                                 
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " req_node: \t%.21s",        ptTxn->req_node);                                                 
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " rsp_node: \t%.21s",        ptTxn->rsp_node);                                                 
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " update_time: \t%.14s",     ptTxn->update_time);                                              
    HtLog ("BonusTxn.log", 1, __FILE__,__LINE__, " ===========================================================\n" );
}
void showIpc(T_IpcIntTxnDef *InIpc)
{
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgSrcId:\t%.4s", InIpc->sMsgSrcId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgDestId:\t%.4s", InIpc->sMsgDestId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsqType:\t%.16s", InIpc->sMsqType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvTxnNum:\t%.1s", InIpc->sConvTxnNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSysSeqNum:\t%.6s", InIpc->sSysSeqNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransType:\t%.1s", InIpc->sTransType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransState:\t%.1s", InIpc->sTransState);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostDate:\t%.8s", InIpc->sHostDate);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostSSN:\t%.12s", InIpc->sHostSSN);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTermSSN:\t%.12s", InIpc->sTermSSN);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyRsp:\t%.32s", InIpc->sKeyRsp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyRevsal:\t%.32s", InIpc->sKeyRevsal);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyCancel:\t%.32s", InIpc->sKeyCancel);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHeaderBuf:\t%.46s", InIpc->sHeaderBuf);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTxnNum:\t%.4s", InIpc->sTxnNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransCode:\t%.3s", InIpc->sTransCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgType:\t%.4s", InIpc->sMsgType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF002Ind:\t%c", InIpc->cF002Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPrimaryAcctNumLen:\t%.2s", InIpc->sPrimaryAcctNumLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPrimaryAcctNum:\t%.19s", InIpc->sPrimaryAcctNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sProcessingCode:\t%.6s", InIpc->sProcessingCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtTrans:\t%.12s", InIpc->sAmtTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtSettlmt:\t%.12s", InIpc->sAmtSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtCdhldrBil:\t%.12s", InIpc->sAmtCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransmsnDateTime:\t%.10s", InIpc->sTransmsnDateTime);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvRateSettlmt:\t%.8s", InIpc->sConvRateSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvRateCdhldrBil:\t%.8s", InIpc->sConvRateCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSysTraceAuditNum:\t%.6s", InIpc->sSysTraceAuditNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTimeLocalTrans:\t%.6s", InIpc->sTimeLocalTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateLocalTrans:\t%.4s", InIpc->sDateLocalTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF014Ind:\t%c", InIpc->cF014Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateExpr:\t%.4s", InIpc->sDateExpr);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateSettlmt:\t%.4s", InIpc->sDateSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateConv:\t%.4s", InIpc->sDateConv);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMchntType:\t%.4s", InIpc->sMchntType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstCntryCode:\t%.3s", InIpc->sAcqInstCntryCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosEntryModeCode:\t%.3s", InIpc->sPosEntryModeCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardSeqId:\t%.3s", InIpc->sCardSeqId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosCondCode:\t%.2s", InIpc->sPosCondCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF026Ind:\t%c", InIpc->cF026Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosPinCaptrCode:\t%.2s", InIpc->sPosPinCaptrCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF028Ind:\t%c", InIpc->cF028Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtTransFee:\t%.9s", InIpc->sAmtTransFee);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstIdCodeLen:\t%.2s", InIpc->sAcqInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstIdCode:\t%.11s", InIpc->sAcqInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwdInstIdCodeLen:\t%.2s", InIpc->sFwdInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwdInstIdCode:\t%.11s", InIpc->sFwdInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF035Ind:\t%c", InIpc->cF035Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack2DataLen:\t%.2s", InIpc->sTrack2DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack2Data:\t%.37s", InIpc->sTrack2Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF036Ind:\t%c", InIpc->cF036Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack3DataLen:\t%.3s", InIpc->sTrack3DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack3Data:\t%.104s", InIpc->sTrack3Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRetrivlRefNum:\t%.12s", InIpc->sRetrivlRefNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF038Ind:\t%c", InIpc->cF038Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAuthrIdResp:\t%.6s", InIpc->sAuthrIdResp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRespCode:\t%.2s", InIpc->sRespCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrTermnlId:\t%.8s", InIpc->sCardAccptrTermnlId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrId:\t%.15s", InIpc->sCardAccptrId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrNameLoc:\t%.40s", InIpc->sCardAccptrNameLoc);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF044Ind:\t%c", InIpc->cF044Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlRespCodeLen:\t%.2s", InIpc->sAddtnlRespCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlRespCode:\t%.25s", InIpc->sAddtnlRespCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack1DataLen:\t%.2s", InIpc->sTrack1DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack1Data:\t%.79s", InIpc->sTrack1Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataPrivateLen:\t%.3s", InIpc->sAddtnlDataPrivateLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataPrivate:\t%.512s", InIpc->sAddtnlDataPrivate);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeTrans:\t%.3s", InIpc->sCurrcyCodeTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeSettlmt:\t%.3s", InIpc->sCurrcyCodeSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeCdhldrBil:\t%.3s", InIpc->sCurrcyCodeCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF052Ind:\t%c", InIpc->cF052Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPinData:\t%.8s", InIpc->sPinData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF053Ind:\t%c", InIpc->cF053Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSecRelatdCtrlInfo:\t%.16s", InIpc->sSecRelatdCtrlInfo);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF054Ind:\t%c", InIpc->cF054Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlAmtLen:\t%.3s", InIpc->sAddtnlAmtLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlAmt:\t%.120s", InIpc->sAddtnlAmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataLen:\t%.3s", InIpc->sAddtnlDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlData:\t%.100s", InIpc->sAddtnlData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFldReservedLen:\t%.3s", InIpc->sFldReservedLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFldReserved:\t%.30s", InIpc->sFldReserved);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sChAuthInfoLen:\t%.3s", InIpc->sChAuthInfoLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sChAuthInfo:\t%.200s", InIpc->sChAuthInfo);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF062Ind:\t%c", InIpc->cF062Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSwitchingDataLen:\t%.3s", InIpc->sSwitchingDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSwitchingData:\t%.200s", InIpc->sSwitchingData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFinaclNetDataLen:\t%.3s", InIpc->sFinaclNetDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFinaclNetData:\t%.200s", InIpc->sFinaclNetData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sOrigDataElemts:\t%.42s", InIpc->sOrigDataElemts);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sReplacementAmts:\t%.42s", InIpc->sReplacementAmts);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgSecurityCode:\t%.8s", InIpc->sMsgSecurityCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRcvgInstIdCodeLen:\t%.2s", InIpc->sRcvgInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRcvgInstIdCode:\t%.11s", InIpc->sRcvgInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF102Ind:\t%c", InIpc->cF102Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId1Len:\t%.2s", InIpc->sAcctId1Len);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId1:\t%.28s", InIpc->sAcctId1);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF103Ind:\t%c", InIpc->cF103Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId2Len:\t%.2s", InIpc->sAcctId2Len);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId2:\t%.28s", InIpc->sAcctId2);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF104Ind:\t%c", InIpc->cF104Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransDescrptLen:\t%.3s", InIpc->sTransDescrptLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransDescrpt:\t%.100s", InIpc->sTransDescrpt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF121Ind:\t%c", InIpc->cF121Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sNationalSwResvedLen:\t%.3s", InIpc->sNationalSwResvedLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sNationalSwResved:\t%.100s", InIpc->sNationalSwResved);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF122Ind:\t%c", InIpc->cF122Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstResvdLen:\t%.3s", InIpc->sAcqInstResvdLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstResvd:\t%.100s", InIpc->sAcqInstResvd);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF123Ind:\t%c", InIpc->cF123Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sIssrInstResvdLen:\t%.3s", InIpc->sIssrInstResvdLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sIssrInstResvd:\t%.100s", InIpc->sIssrInstResvd);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF064Ind:\t%c", InIpc->cF064Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMAC064:\t%.8s", InIpc->sMAC064);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF128Ind:\t%c", InIpc->cF128Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMAC128:\t%.8s", InIpc->sMAC128);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostTransFee1:\t%.12s", InIpc->sHostTransFee1);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostTransFee2:\t%.12s", InIpc->sHostTransFee2);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTlrNum:\t%.8s", InIpc->sTlrNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sOpenInst:\t%.15s", InIpc->sOpenInst);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sStlmInst:\t%.15s", InIpc->sStlmInst);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMiscFlag:\t%.32s", InIpc->sMiscFlag);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMisc:\t%.128s", InIpc->sMisc);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "===========================================================\n" );
}
/*****************************************************************************/
/* FUNC:   int GMTInit(T_IpcIntTxnDef *pIpcIntTxn,int nMsgLen)         */
/* INPUT:  pIpcIntTxn: ����������Ϣ, ��ʽ���ڲ���IPC�ṹ                   */
/*         nMsgLen: ��Ϣ����                                                */
/* OUTPUT: pIpcIntTxn: ��ʼ�������ֵ                                       */
/*                          												 */
/* RETURN: 0: �ɹ�, ����: ʧ��                                              */
/* DESC:   ��ʼ���ɹ���ͨ���׸������ֵ               */
/*                                               							 */
/*****************************************************************************/
int GMTInit (T_IpcIntTxnDef *pIpcIntTxn, int nMsgLen)
{
	char   sTemp[50];
	char   sF11Code[20];
	char  sTransAmt[12 + 1];
	char  sTxnNum[4 + 1];
	int   nReturn;
	int i = 0;
	int nLen=0;

	memset(sTemp,0,sizeof(sTemp));
	memset(sTxnNum,0,sizeof(sTxnNum) );
	
	nReturn = 0;
	
	memcpy(sTxnNum,pIpcIntTxn->sTxnNum,4);
	
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"GMTInit Begin:");
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"sTxnNum[%s].",sTxnNum);
					
			
						
	switch(sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDT_REQ:
			/*HeaderBuf*/
			pIpcIntTxn->sConvTxnNum[0] = 'N';
			memset(&pIpcIntTxn->sHeaderBuf[0], 0x2e,1);//ͷ1��ͷ����
			memset(&pIpcIntTxn->sHeaderBuf[1], 0x01,1);//ͷ2���汾��ʶ
			memset(&pIpcIntTxn->sHeaderBuf[2],'0',4);//ͷ3���������ĳ���
			memcpy(&pIpcIntTxn->sHeaderBuf[6],CUP_INST_ID,8);//ͷ4��Ŀ��ID
			memcpy(&pIpcIntTxn->sHeaderBuf[14],"   ",3);
	
			memset(&pIpcIntTxn->sHeaderBuf[28],0x00,4);//ͷ6������ʹ�ã�24bit����ͷ7��8bit��
			memset(&pIpcIntTxn->sHeaderBuf[32],'0',8);//ͷ8��������Ϣ
			memset(&pIpcIntTxn->sHeaderBuf[40],0x00,1);//ͷ9���û���Ϣ
			memset(&pIpcIntTxn->sHeaderBuf[41],'0',5);//ͷ10���ܾ���
			/*HeaderBuf over*/
			
			//TransType
			if(memcmp(pIpcIntTxn->sMsgSrcId, SRV_ID_COMM_P, 2) == 0)
			    memcpy(pIpcIntTxn->sTransType, TRANS_TYPE_POS, FLD_TRANS_TYPE_LEN);
			else if(memcmp(pIpcIntTxn->sMsgSrcId, "1603", 4) == 0)
			    memcpy(pIpcIntTxn->sTransType, TRANS_TYPE_ATM, FLD_TRANS_TYPE_LEN);
						
			memcpy(&pIpcIntTxn->sHeaderBuf[17],pIpcIntTxn->sAcqInstIdCode,11);//ͷ5��ԴID
			break;
		default:
			break;
	}
	
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, 
				(char *)pIpcIntTxn, nMsgLen);
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GMTInit End."); 
	
	 
	
	
	return 0;	
}
