/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Txn5835.c                                                   */
/* DESCRIPTIONS: handle normal req from CUP and its rsp from host            */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-08-09  YU TONG        Initialize                                     */
/*****************************************************************************/
static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBonus/Attic/Txn5835.c,v 1.1.4.2 2011/09/23 02:57:04 ctedev Exp $";

#include "SwtBonus.h"

int Txn5835(T_IpcIntBonusDef *pIpcBonusTxn, int nIndex)
{
    char            sFuncName[] = "Txn5835";
    char            sRespCode[F039_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    int                i;
    int                nReturnCode;
    int                nLineStat;
    int                nMsgLen;
    int                nTxnSelOpr;
    T_SwtToReqDef    tSwtToReq;
    Tbl_bonus_txn_Def        tBonusTxn, tOrigTxn;
    Tbl_ic_txn_Def  tIcTxn;
    T_IpcIntTxnDef    tSendIpcIntTxn;
    char            sCurrentDate[14+1];    
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    if (nIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", pIpcBonusTxn->sTxnNum, pIpcBonusTxn->sMsgSrcId);
        return -1;
    }
    
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    /*CommonGetCurrentTime(sCurrentDate);*/
    /***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex);
    memcpy(sCurrentDate, gsTimeCurTs, 14);
    
    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
        "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n", 
        gatTxnInf[nIndex].txn_num, pIpcBonusTxn->sPrimaryAcctNum, pIpcBonusTxn->sAmtTrans, 
        pIpcBonusTxn->sDateLocalTrans, pIpcBonusTxn->sTimeLocalTrans);
        
     /* ����ǰ��F007,F011��sMisc */
     memcpy(pIpcBonusTxn->sMisc1,pIpcBonusTxn->sTransmsnDateTime,F007_LEN);
     memcpy(pIpcBonusTxn->sMisc1+F007_LEN,pIpcBonusTxn->sSysTraceAuditNum,F011_LEN);
     /* F007ʹ��ϵͳ��ǰʱ�� */
     memcpy(pIpcBonusTxn->sMiscFlag, sCurrentDate, 14);
     memcpy(pIpcBonusTxn->sTransmsnDateTime, sCurrentDate+4, F007_LEN);    
     pIpcBonusTxn->sConsumeType[0] = '0'; 
 
    /*******************
    * �жϸý����Ƿ�֧��
    ********************/
    if (memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);    
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */
        return -1;
    }
    
    /***************
    * ������ˮ��
    ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
    if (tSwtToReq.nToCtlTime > 0)
        tSwtToReq.nTransCode = TOCTL_NORMAL_FIRST;
    else
        tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
    memcpy (tSwtToReq.sTxnDate, pIpcBonusTxn->sTransmsnDateTime, F007_LEN);
    
    nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, pIpcBonusTxn);
    if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "ToCtrlReq error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );    
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg(pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */
        return -1;
    }
    /* save ssn in ipc */
    memcpy (pIpcBonusTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
    memcpy(pIpcBonusTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);
    
    /* ��key_rsp��ֵ */
    nReturnCode = SetKeyRsp (pIpcBonusTxn);
    /* ��key_cancel��ֵ, �˻�Ҳʹ��key_cancelƥ��ԭ���� */
    nReturnCode = SetKeyCancel (pIpcBonusTxn);

    /***********************
    * ��֯��¼���ݿ��¼�ṹ
    ************************/
    nReturnCode = MoveIpc2Txn (pIpcBonusTxn, &tBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "MoveIpc2Txn error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
    
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );    
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);    /* by gjch */
    
        return -1;
    }

    /***************
    * �������˻�����, ���ԭ����, ������ۼ��˻����
    ****************/
    memset ((char *)&tOrigTxn, 0, sizeof (tOrigTxn));
    memcpy ((char *)&tOrigTxn, (char *)&tBonusTxn, sizeof (tBonusTxn));

    nReturnCode = CheckReturnTxnAll(pIpcBonusTxn, &tOrigTxn, sRespCode);
    if(nReturnCode || memcmp(sRespCode, F039_SUCCESS, F039_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "CheckReturnTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, sRespCode, F039_LEN );    
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);
    
        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn(DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();
        
        return -1;
    }

    /***************
    * ת��PIN
    ****************/
    if (gatTxnInf[nIndex].pin_flag[0] == FLAG_YES_C)
    {
        nReturnCode = TransferPin(pIpcBonusTxn );
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
                "TransferPin error, %d. Reject this transaction with %s.", nReturnCode, F039_PIN_ERROR);
            /* ����Ӧ���״��� */
            memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( pIpcBonusTxn->sRespCode, F039_PIN_ERROR, F039_LEN );    
            /*����15��*/
            memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            pIpcBonusTxn->sMsgType[2]++;
            /* clear F090 */
            memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
            
            nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);
        
            /* save this txn in Db */
            DbsBegin ();
            memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
            nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
            DbsCommit ();
        
            return -1;
        }
    }
    
    /*******************
    * �����ͻ����ļ��
    ********************/
    nReturnCode = SwtCustCheckTxn (pIpcBonusTxn, sRespCode);
    if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "SwtCustCheckTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, sRespCode, F039_LEN );    
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg(pIpcBonusTxn, &tBonusTxn, NULL);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }

    /*********************
    * �ͻ������ݿ��¼�ṹ
    **********************/
    /*add by xu zhen*/
    memcpy (pIpcBonusTxn->sRetrivlRefNum, tOrigTxn.retrivl_ref, F037_LEN);
    memcpy (tBonusTxn.retrivl_ref,tOrigTxn.retrivl_ref, F037_LEN);
    /*end */
    nReturnCode = SwtCustBeforeTblTxnOpr(pIpcBonusTxn, &tBonusTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "SwtCustBeforeTblTxnOpr error, %d. Reject this transaction with %2.2s.", nReturnCode, F039_MAL_FUNCTION);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );    
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);
    
        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn(DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();
    
        return -1;
    }
    
    DbsBegin ();
    
    /***************
    * ��¼���ݿ�
    ****************/
    nReturnCode = DbsBonusTxn(DBS_INSERT, &tBonusTxn);
    if (nReturnCode )
    {
        DbsRollback();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "DbsTxn insert error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_DUPL_TXN, F039_LEN );
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);    
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);
        return -1;
    }    
    DbsCommit ();
    
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");

    /* ����POSP�ɹ�  */
    /* ����Ӧ���״��� */
    memcpy(pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN);
    /* ����Ӧ��SrvId */
    memcpy(pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN);
    /* ���Ĵ���Ӧ���� */
    memcpy( pIpcBonusTxn->sRespCode, F039_SUCCESS, F039_LEN);
    /*����15��*/
    memcpy(pIpcBonusTxn->sDateSettlmt, sCurrentDate+4, F015_LEN);    
    /* ����Ӧ�� msg type */
    pIpcBonusTxn->sMsgType[2]++;
    /* clear F090 */
    memset(pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
    
    nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);
    if(nReturnCode)
    {
        memcpy(tBonusTxn.trans_state, TRANS_STATE_ACCT_TO, 1);
        memcpy(tBonusTxn.resp_code, F039_MAL_FUNCTION, 2);
    }
    else
    {
        memcpy(tBonusTxn.trans_state, TRANS_STATE_SUCC, 1);
        memcpy(tBonusTxn.resp_code, F039_SUCCESS, 2);  
    }    
    nReturnCode = DbsBonusTxn(DBS_UPDATE1, &tBonusTxn);
    if(nReturnCode)
    {
        DbsRollback();
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "error, DbsBonusTxn DBS_UPDATE1[%d]", nReturnCode);
        return -1;
    }
    DbsCommit();
    
#if 0
    /***********************
    *  �ͻ���Ŀ��IPC��������
    ************************/
    memcpy((char *)&tSendIpcIntTxn, (char *)pIpcBonusTxn, sizeof (*pIpcBonusTxn));

    /* save original txn info in F090 */
    memset (tSendIpcIntTxn.sOrigDataElemts, '0', F090_LEN);
    i = 0;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i, tOrigTxn.msg_type, F000_MSG_TYPE_LEN);
    i += F000_MSG_TYPE_LEN;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i, tOrigTxn.sys_seq_num, F011_LEN);
    i += F011_LEN;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i, tOrigTxn.trans_date_time, F007_LEN);
    i += F007_LEN;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i+F032_VAL_LEN-INST_ID_LEN, tOrigTxn.acq_inst_id_code, INST_ID_LEN);
    i += F032_VAL_LEN;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i+F033_VAL_LEN-INST_ID_LEN, tOrigTxn.fwd_inst_id_code, INST_ID_LEN);
    
    /* send to dest 1 */
    memcpy( tSendIpcIntTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );

    nReturnCode = SendMsg (&tSendIpcIntTxn, &tBonusTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
    }
    
    HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

    nReturnCode = InsertSafMsg(&tSendIpcIntTxn, &tBonusTxn, gatTxnInf[nIndex].saf_count1);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
    }
#endif

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    
    return 0;
}

int Txn5836 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex )
{
    char            sFuncName[] = "Txn5836";
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    int                nReturnCode;
    int                nLineStat;
    int                nTxnSelOpr;
    int                nMsgLen;
    int                nSendRevsalFlag;
    int                nSendRspFlag;
    int                nSendAccountFlag;
    int                nReqIndex;
    double          allamt = 0;
    char            sCurrentDate[14+1];
    int i;
    T_SwtToReqDef    tSwtToReq;
    Tbl_txn_Def        tBonusTxn,tOrigTxn;
    Tbl_ic_txn_Def  tIcTxn;
    T_IpcIntTxnDef    tSendIpcIntTxn, tSendIpcInt2;
    Tbl_saf_msg_Def    tSafMsg;
    char            sF055Len[F055_LEN_LEN+1] = {0};
    
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    /*CommonGetCurrentTime(sCurrentDate);*/
    SetToTime(-1);
    memcpy(sCurrentDate, gsTimeCurTs, 14);
    
    #if 0
     /* ת��Ӧ���� */    
    nReturnCode = SwtCustTransferRspCode(ptIpcIntTxn);
    if (nReturnCode != 0 )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "transfer RSPCODE error, %d", nReturnCode);
        memcpy(ptIpcIntTxn->sRespCode,"01",F039_LEN);    
    }
    #endif
    
    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
    memcpy (sMsgSrcId, pIpcBonusTxn->sMsgSrcId, SRV_ID_LEN);
    
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
        "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  response code: %2.2s", 
        pIpcBonusTxn->sTxnNum, pIpcBonusTxn->sPrimaryAcctNum, pIpcBonusTxn->sAmtTrans, 
        pIpcBonusTxn->sDateLocalTrans, pIpcBonusTxn->sTimeLocalTrans, 
        pIpcBonusTxn->sSysTraceAuditNum, pIpcBonusTxn->sRespCode);
        
        
    /***************
    * У��MAC
    ****************/
     /* �����������A0��discard���ף���У��MAC */
    if(memcmp(pIpcBonusTxn->sRespCode, "A0", F039_LEN) != 0 &&
        memcmp(pIpcBonusTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0)
    {
        nReturnCode = VerifyMAC (pIpcBonusTxn );
        if (nReturnCode != 0 )
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "VerifyMAC error, %d. Discard this message.", nReturnCode);
            return -1;
        }
    }
    
    /****************************
    * ����tbl_txn�еĽ��׼�¼
    ****************************/
    nReturnCode = SetKeyRsp (pIpcBonusTxn);

    /* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
    memset ((char *)&tBonusTxn, 0, sizeof (tBonusTxn));
    memcpy (tBonusTxn.key_rsp, pIpcBonusTxn->sKeyRsp, KEY_RSP_LEN);
    memcpy (tBonusTxn.txn_num, pIpcBonusTxn->sTxnNum, FLD_TXN_NUM_LEN);
    
    tBonusTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
    /* �����ݿ��в���ԭ������ */
    /* DBS_SELECT21: txn_num, key_rsp */
    nReturnCode = DbsBonusTxn (DBS_SELECT21, &tBonusTxn);
    if (nReturnCode)
    {
        tBonusTxn.key_rsp[KEY_RSP_LEN] = 0;
        tBonusTxn.txn_num[FLD_TXN_NUM_LEN] = 0;
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "DbsTxn select error, %d. txn_num=%s,key_rsp=%s. Discard this message.", nReturnCode,tBonusTxn.txn_num,tBonusTxn.key_rsp);
        return -1;
    }

    
    /*����ʱ���ɹ�������⣬����ʱ���ӵ��ۼ��˻�������*/
    /*�ɹ����߳�ʱ״̬�£�ԭ���ѽ���trans_state��ΪHAD_RETURN����ֹ�˻���ĳ�������*/
    memset ((char *)&tOrigTxn, 0, sizeof (tOrigTxn));  
    memcpy ((char *)&tOrigTxn, (char *)&tBonusTxn, sizeof (tBonusTxn));
    
    /*���״��뻻Ϊ���ѽ��״��룬����ƥ��ԭ���ѽ���*/
    memcpy(tOrigTxn.txn_num,"1101",4);
#if 0
    i=0;
    memcpy (ptIpcIntTxn->sKeyRevsal+i, &ptIpcIntTxn->sRetrivlRefNum , F037_LEN);/* P����ˮ�� */
    i += F037_LEN;
    memcpy (ptIpcIntTxn->sKeyCancel+i, &ptIpcIntTxn->sAcqInstResvd[20] , F007_LEN); /* P���������� */
    i += F007_LEN;
    memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sAcqInstIdCode, 8);
#endif
    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "key_cancel:[%s],txn_num[%s]",tOrigTxn.key_cancel,tOrigTxn.txn_num);            
    
    nReturnCode = DbsBonusTxn (DBS_SELECT23, &tOrigTxn );
    if( nReturnCode != 0 && nReturnCode != DBS_NOTFOUND)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn select23 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
                nReturnCode,tOrigTxn.txn_num,tOrigTxn.key_cancel);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            " sMsgDestId [%4.4s].", pIpcBonusTxn->sMsgDestId);
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN );
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);    
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL); 
        return 0;
    }
    
    /* ���׷��سɹ����߳�ʱ���޸�ԭ����״̬Ϊ�����˻��� */
    if(memcmp(pIpcBonusTxn->sRespCode,F039_SUCCESS,F039_LEN) && 
        memcmp(pIpcBonusTxn->sRespCode,F039_TIME_OUT,F039_LEN))
    {
        allamt = atof(tOrigTxn.addtnl_amt)-atof(tBonusTxn.amt_trans);
        sprintf(tOrigTxn.addtnl_amt , "%012.0f" , allamt );
    }
    else
    {
        memcpy(tOrigTxn.trans_state,TRANS_STATE_HAD_RETURN,1);
    } 
 HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "key_rsp:[%s],trans_state[%s]",tOrigTxn.key_rsp,tOrigTxn.trans_state);
    nReturnCode = DbsBonusTxn (DBS_UPDATE1, &tOrigTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn update error, %d. Discard this message.", nReturnCode);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            " sMsgDestId [%4.4s].", pIpcBonusTxn->sMsgDestId);
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN );
        /*����15��*/
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);    
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL); 
        return 0;
    }
    DbsCommit ();


    /***********************
    * ���ҽ���������gatTxnInf�е�����
    ************************/
    nReturnCode = GetTxnInfoIndex (tBonusTxn.msg_src_id, tBonusTxn.txn_num, &nReqIndex );
    if (nReturnCode || nReqIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
        return -1;
    }

        
    /***********************
    * ��֯��¼���ݿ��¼�ṹ
    ************************/
    nReturnCode = MoveIpc2Txn (pIpcBonusTxn, &tBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    
    /*********************
    * �ͻ������ݿ��¼�ṹ
    **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (pIpcBonusTxn, &tBonusTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    
    /* ��tTxn���浽tSendIpcIntTxn, ������Ӧ����ʹ�� */
    
    
    nReturnCode = MoveTxn2Ipc (&tBonusTxn, &tSendIpcIntTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    
    /***********************************************************
    *  ��齻���Ƿ�ʱ add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    if (!memcmp(tBonusTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN))
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_HAD_TO;
    else
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO; 
    
    /* set trans state if reply is not time out */
    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_TO)
    {                                              
        if (IsRspSuccess (pIpcBonusTxn->sRespCode))
        {
            switch (gatTxnInf[nReqIndex].rsp_type[0])
            {
            case RSP_TYPE_NO_ACCOUNT:
                memcpy (tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_HOST, SRV_ID_LEN))
                    memcpy (tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_HOST, SRV_ID_LEN))
                    memcpy (tBonusTxn.trans_state, TRANS_STATE_NO_ACCT_RSP, FLD_TRANS_STATE_LEN);
                else
                    memcpy (tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                break;
            default:
                break;
            }
        }
        else
        {
            if (!memcmp (sMsgSrcId, SRV_ID_COMM_HOST, SRV_ID_LEN))
                memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_CUPS, FLD_TRANS_STATE_LEN);
            else
                memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
        }
    }
    
    DbsBegin ();
    
    /***************
    * ��¼���ݿ�
    ****************/
    nReturnCode = DbsBonusTxn(DBS_UPDATE1, &tBonusTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "DbsTxn update error, %d. Discard this message.", nReturnCode);

        /* send reversal on success reply */
        if (nSendRevsalFlag)
        {
            nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
            }
        }
        return -1;
    }
    
    DbsCommit ();
    
    if(!memcmp(pIpcBonusTxn->sRespCode, "A0", F039_LEN) && 
        !memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "CUP return [%2.2s], respone 96", pIpcBonusTxn->sRespCode);
        memcpy(tSendIpcIntTxn.sRespCode, "96", F039_LEN);
    }
    
HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "tSwtToReq[%d]",tSwtToReq.nReplyCode);

    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_HAD_TO && !memcmp(pIpcBonusTxn->sRespCode,F039_TIME_OUT,2))
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "h111111111111");
        if (memcmp (sMsgSrcId, SRV_ID_COMM_HOST, SRV_ID_LEN) == 0)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
                "�˻�������ʱ. Reject this transaction with %s.", F039_TIME_OUT);
            memcpy ((char *)&tSendIpcInt2, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
            
            /* ����Ӧ���״��� */
            memcpy( tSendIpcInt2.sTxnNum, "5152", FLD_TXN_NUM_LEN );
        
            /* ����Ӧ��SrvId */
            memcpy( tSendIpcInt2.sMsgDestId, "1802", SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( tSendIpcInt2.sRespCode, F039_TIME_OUT, F039_LEN );
            /*����15��*/
            memcpy(tSendIpcInt2.sDateSettlmt,sCurrentDate+4,F015_LEN);    
            /* ����Ӧ�� msg type */
            tSendIpcInt2.sMsgType[2]++;
            /* clear F090 */
            memset (tSendIpcInt2.sOrigDataElemts, ' ', F090_LEN);
            nReturnCode = SendMsg (&tSendIpcInt2, &tBonusTxn, NULL);    
            return nReturnCode;    
        }
        else if (memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) == 0)
         {
            HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 
                    "h2222222");
             nSendRspFlag = 1 ;
         }
    }
    else
    {
        nSendRspFlag = 0;
        switch (gatTxnInf[nReqIndex].rsp_type[0])
        {
            case RSP_TYPE_NO_ACCOUNT:
                nSendRspFlag = 1;
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_HOST, SRV_ID_LEN))
                    nSendRspFlag = 1;
                else
                    nSendRspFlag = 0;
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) )
                {
                    nSendRspFlag = 1;
                    memcpy(pIpcBonusTxn->sRespCode,"00",2);
                }
                else if (!memcmp (sMsgSrcId, SRV_ID_COMM_HOST, SRV_ID_LEN) && memcmp(pIpcBonusTxn->sRespCode,F039_SUCCESS,F039_LEN))
                {
                    nSendRspFlag = 1;
                }
                else
                    nSendRspFlag = 0;
                break;
            default:
                break;
        }
    }
HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nSendRspFlag %d",nSendRspFlag);

    if (nSendRspFlag)
    {
        /***********************
        *  �ͻ���Ŀ��IPC��������
        ************************/    
                    
        memcpy ((char *)&tSendIpcInt2, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
        
        /* ����Ӧ���״��� */
        memcpy( tSendIpcInt2.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
    
        /* ����Ӧ��SrvId */
        memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );
        
        /* ����Ӧ�� msg type */
        tSendIpcInt2.sMsgType[2]++;
        
         HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,  __LINE__, (char*)&tSendIpcInt2, sizeof(tSendIpcInt2));
    
        nReturnCode = SendMsg (&tSendIpcInt2, &tBonusTxn, NULL);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
                "SendMsg error, %d. Discard this message.", nReturnCode);
                

            return -1;
        }
    
        HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
    }
        
    /* �Ƿ񷢼��� */
    nSendAccountFlag = 0;
    switch (gatTxnInf[nReqIndex].rsp_type[0])
    {
        case RSP_TYPE_NO_ACCOUNT:
            nSendAccountFlag = 0;
            break;
        case RSP_TYPE_RSP_BEFORE_ACCOUNT:
            if (!memcmp (sMsgSrcId, SRV_ID_COMM_HOST, SRV_ID_LEN) &&
                    IsRspSuccess (pIpcBonusTxn->sRespCode))
                nSendAccountFlag = 1;
            else
                nSendAccountFlag = 0;
            break;
        case RSP_TYPE_RSP_AFTER_ACCOUNT:
            if (!memcmp (sMsgSrcId, SRV_ID_COMM_HOST, SRV_ID_LEN) &&
                    IsRspSuccess (pIpcBonusTxn->sRespCode))
                nSendAccountFlag = 1;
            else
                nSendAccountFlag = 0;
            break;
        default:
            break;
    }
        
    if (nSendAccountFlag)
    {
        /* ����Ӧ��SrvId */
        memcpy ((char *)&tSendIpcInt2, &tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
        memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].msg_dest2, SRV_ID_LEN );
        memcpy (tSendIpcInt2.sHeaderBuf+6, CUP_INST_ID, 8);
        memcpy (tSendIpcInt2.sHeaderBuf+6+F032_VAL_LEN,tSendIpcInt2.sFwdInstIdCode, 8);
        /* clear F039 */
        memset (tSendIpcInt2.sRespCode, ' ', F039_LEN);
        
        nReturnCode = SendMsg(&tSendIpcInt2, &tBonusTxn, NULL);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
                "SendMsg error, %d. Discard this message.", nReturnCode);
                
            /* send reversal on success reply */
            if (nSendRevsalFlag)
            {
                nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if (nReturnCode)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
            }
            
            return -1;
        }
    
        HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction account request sent out.");

        nReturnCode = InsertSafMsg (&tSendIpcInt2, &tBonusTxn, gatTxnInf[nReqIndex].saf_count2);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
        }

    }
    
    if (memcmp(pIpcBonusTxn->sMsgSrcId,SRV_ID_COMM_CUP,SRV_CUP_ID_LEN) == 0)
       {
        /* ���tbl_saf_msg�еķ��ʹ��� */
        memset ((char *)&tSafMsg, 0, sizeof (tSafMsg));
        memcpy (tSafMsg.inst_date, tBonusTxn.inst_date, 8);
        memcpy (tSafMsg.inst_time, tBonusTxn.inst_time, 6);
        memcpy (tSafMsg.sys_seq_num, tBonusTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
        memcpy (tSafMsg.msg_dest_srv_id, pIpcBonusTxn->sMsgSrcId, SRV_ID_LEN);
        memset (tSafMsg.send_count, '0', 2);
        nReturnCode = DbsSafMsg (DBS_UPDATE, &tSafMsg);
        if (nReturnCode && nReturnCode != DBS_NOTFOUND )
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsSafMsg update error, %d. Discard this message.", nReturnCode);
        
            return -1;
        }
        
        DbsCommit ();
    }
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    
    return 0;
}


