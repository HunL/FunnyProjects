/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Revsal.c                                                    */
/* DESCRIPTIONS: handle reversal req its rsp                                 */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-29  YU TONG        Initialize                                     */
/*****************************************************************************/
static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBonus/SCCRevsal.c,v 1.1.1.1 2011/08/19 10:55:53 ctedev Exp $";

#include "SwtBonus.h"

int HandleSCCRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
    char            sFuncName[] = "HandleBDTRevsalReq";
    char            sRespCode[F039_LEN+1];
    char            sTxnNum[FLD_TXN_NUM_LEN+1];
    char            cityno[5];
    char            branchCode[12];
    char            transCode[4+1];
    int             nReturnCode;
    int             i;
    int             nRevsalIndex;
    int             nSendRspFlag;
    T_SwtToReqDef   tSwtToReq;
    Tbl_txn_Def     tTxn, tOrigTxn;
    Tbl_ic_txn_Def  tIcTxn;
    T_IpcIntTxnDef  tSendIpcIntTxn, tSendIpcIntTxn1;
    char            sAcqInstIdCode[8+1+2];
    char						sCurrentDate[14+1];
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    char            sF055Len[F055_LEN_LEN+1] = {0};
    
    /*CommonGetCurrentTime(sCurrentDate);*/
    
    /***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex, sCurrentDate);
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    if (nIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sMsgSrcId);
        return -1;
    }

    memcpy(cityno, ptIpcIntTxn->sMisc+16, 4);

    memcpy(ptIpcIntTxn->sMisc+121, cityno, 4);

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %12.12s\n  orig data elem: %42.42s\n",
            gatTxnInf[nIndex].txn_num, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
            ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, ptIpcIntTxn->sTermSSN,
            ptIpcIntTxn->sOrigDataElemts);
            
       /*  2011��4��15��  Ԭ�� ����ǰ��F007,F011 ��sMisc  Start*/      

    /* ����ǰ��F007,F011��sMisc */
     memcpy(ptIpcIntTxn->sMisc,ptIpcIntTxn->sTransmsnDateTime,F007_LEN);
     memcpy(ptIpcIntTxn->sMisc+F007_LEN,ptIpcIntTxn->sSysTraceAuditNum,F011_LEN);
     /* F007ʹ��ϵͳ��ǰʱ�� */
     memcpy(ptIpcIntTxn->sTransmsnDateTime, sCurrentDate+4, F007_LEN);
     
     /*END*/
          
            
            

    nSendRspFlag = 1;
	if (!memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) ) 
    {
        /* no need to send reversal response for time out reversal or late response reversal */
        nSendRspFlag = 0;
    }

    /*******************
     * �жϸý����Ƿ�֧��
     ********************/
    if (nSendRspFlag && memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /*����15��*/
		ptIpcIntTxn->cF015Ind = 'Y';
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        /* clear F038 */
        ptIpcIntTxn->cF038Ind = FLAG_NO_C;
        /* clear F090 */
        memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
    	
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);    /* by gjch */
        return -1;
    }

    /***************
     * ������ˮ��
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
    tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
    memcpy (tSwtToReq.sTxnDate, ptIpcIntTxn->sTransmsnDateTime, F007_LEN );

    nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
    if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "ToCtrlReq error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */
        return -1;
    }
    /* save ssn in ipc */
    memcpy (ptIpcIntTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
    memcpy(ptIpcIntTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);

    /* ��key_rsp, key_revsal��ֵ */
    nReturnCode = SetKeyRevsal (ptIpcIntTxn);
    nReturnCode = SetKeyRsp (ptIpcIntTxn);

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        return -1;
    }

#if 0
    /***************
     * У��MAC
     ****************/
    if (nSendRspFlag)
    {
        nReturnCode = VerifyMAC (ptIpcIntTxn );
        if (nReturnCode != 0 )
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "VerifyMAC error, %d. Reject this transaction with %s.", nReturnCode, F039_MAC_FAIL);

            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, F039_MAC_FAIL, F039_LEN );
            /*����15��*/
			ptIpcIntTxn->cF015Ind = 'Y';
            memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            /* clear F038 */
            ptIpcIntTxn->cF038Ind = FLAG_NO_C;
            /* clear F090 */
            memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
    		
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);

            /* save this txn in Db */
            DbsBegin ();
            memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
            nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
            DbsCommit ();

            return -1;
        }
    }
#endif

    /***************
     * �������׵������жϴ���
     ****************/
    memset ((char *)&tOrigTxn, 0, sizeof (tOrigTxn));
    memcpy ((char *)&tOrigTxn, (char *)&tTxn, sizeof (tTxn));

    nReturnCode = CheckRevsalTxn (ptIpcIntTxn, &tOrigTxn, sRespCode);
    if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
    {
        if (!memcmp (sRespCode, F039_DUPL_TXN, F039_LEN))
            memcpy (sRespCode, F039_SUCCESS, F039_LEN);
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "CheckRevsalTxn error, %d. Reject this transaction with %2.2s. nSendRspFlag[%d]", nReturnCode, sRespCode, nSendRspFlag);

        if (nSendRspFlag)
        {
            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, sRespCode, F039_LEN );
            /*����15��*/
			ptIpcIntTxn->cF015Ind = 'Y';
            memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            /* clear F038 */
            ptIpcIntTxn->cF038Ind = FLAG_NO_C;
            /* clear F090 */
            memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
    		
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        }

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();


        return -1;
    }
    else
    {
        /* save original fe ssn in revsal_ssn */
        memcpy (tTxn.revsal_ssn, tOrigTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
        /* save original F037 */
        memcpy (tTxn.retrivl_ref, tOrigTxn.retrivl_ref, F037_LEN);
        memcpy (ptIpcIntTxn->sRetrivlRefNum, tOrigTxn.retrivl_ref, F037_LEN);
    }

    /*******************
     * �����ͻ����ļ��
     ********************/
    if (nSendRspFlag)
    {
        nReturnCode = SwtCustCheckTxn (ptIpcIntTxn, sRespCode);
        if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "SwtCustCheckTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);

            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, sRespCode, F039_LEN );
            /*����15��*/
			ptIpcIntTxn->cF015Ind = 'Y';
            memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            /* clear F038 */
            ptIpcIntTxn->cF038Ind = FLAG_NO_C;
            /* clear F090 */
            memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
    		
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, &tOrigTxn);

            /* save this txn in Db */
            DbsBegin ();
            memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
            nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
            DbsCommit ();

            return -1;
        }
    }

    /*********************
     *��������
     **********************/
    memset( branchCode, 0, sizeof(branchCode) );
    memset(sAcqInstIdCode, 0, sizeof(sAcqInstIdCode));

    memcpy( sAcqInstIdCode, ptIpcIntTxn->sAcqInstIdCode, 8 );
    /*DbsGetBran(DBS_SELECT,sAcqInstIdCode,branchCode);*/
    memcpy( transCode,ptIpcIntTxn->sTxnNum,4 );
    if( DbsCheckFlag(branchCode , transCode ) == 2 )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
            "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        memcpy( ptIpcIntTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /*����15��*/
		ptIpcIntTxn->cF015Ind = 'Y';
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        ptIpcIntTxn->sMsgType[2]++;
        
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);    /* by gjch */
        return -1;
    }

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, &tOrigTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        /*����15��*/
		ptIpcIntTxn->cF015Ind = 'Y';
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }

    /* �Գ�ʱ�����Ľ�����Դ�������ΪSwitch, ʹ��ԭʼ���׵Ľ�����Դ�� */
    memcpy (tTxn.msg_src_id, tOrigTxn.msg_src_id, SRV_ID_LEN);

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn insert error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        return -1;
    }

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");

    /***************
     * �������ݿ�ԭʼ���׼�¼
     ****************/
    memset (tOrigTxn.revsal_flag, REV_CAN_FLAG_HAD, 1);
    memcpy (tOrigTxn.revsal_ssn, tTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
    nReturnCode = DbsTxn (DBS_UPDATE2, &tOrigTxn );
    if( nReturnCode != 0 )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn update error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        return -1;
    }
    
    /* �Զ����������ԭ������F055��ת��F055 */
	if((ptIpcIntTxn->sICData[0] == ' ' || ptIpcIntTxn->sICData[0] == 0x00) && 
	    memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) == 0)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    memcpy(tIcTxn.key_rsp, tOrigTxn.key_rsp, KEY_RSP_LEN);
	    nReturnCode = DbsIcTxn (DBS_SELECT, &tIcTxn);
	    if( !nReturnCode )
	    {
	        ptIpcIntTxn->cICDataInd = 'Y';
	        memcpy(sF055Len, tIcTxn.req_iclen, F055_LEN_LEN);
	        sprintf(sF055Len, "%03d", atoi(sF055Len)/2);
	        memcpy(ptIpcIntTxn->sICDataLen, sF055Len, F055_LEN_LEN);
	        Str2Hex(tIcTxn.req_icdata, ptIpcIntTxn->sICData, atoi(sF055Len)*2);
	    }    
	}
	
    /***************
	* ��¼IC���������ݿ�
	****************/
    if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    nReturnCode = MoveTxn2IcTxn(&tTxn, ptIpcIntTxn, &tIcTxn);
	    nReturnCode = DbsIcTxn (DBS_INSERT, &tIcTxn);
	    if (nReturnCode )
	    {
	    	DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsIcTxn insert error, %d.", nReturnCode);
            /* do not send response for this failure, wait for resend of this reversal */
            
            return -1;
	    }
	}

    DbsCommit ();

    /***********************
     *  ת��������
     ************************/
    memcpy ((char *)&tSendIpcIntTxn, (char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn));

    /****************
     * ���ͳɹ�Ӧ�������
     ****************/
    if (nSendRspFlag)
    {
        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_SUCCESS, F039_LEN );
        /*����15��*/
		ptIpcIntTxn->cF015Ind = 'Y';
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        /* clear F038 */
        ptIpcIntTxn->cF038Ind = FLAG_NO_C;
        /* clear F090 */
        memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);

        memcpy(ptIpcIntTxn->sMisc+121, cityno, 4);

        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, &tOrigTxn);
        if( nReturnCode != 0 )
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
        }
        HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Response sent to %s.", gatTxnInf[nIndex].rsp_dest_srv_id);
    }

    /***********************
     *  ת��������
     ************************/

    memcpy (tSendIpcIntTxn.sSysTraceAuditNum, ptIpcIntTxn->sSysSeqNum, F011_LEN);
    nReturnCode = CopyOrigTxnInfo (&tOrigTxn, &tSendIpcIntTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CopyOrigTxnInfo error, %d.", nReturnCode);
    }

    /* save original txn info in F090 */
    memset (tSendIpcIntTxn.sOrigDataElemts, '0', F090_LEN);
    i = 0;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i, tOrigTxn.msg_type, F000_MSG_TYPE_LEN);
    i += F000_MSG_TYPE_LEN;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i, tOrigTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
    i += F011_LEN;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i, tOrigTxn.trans_date_time, F007_LEN);
    i += F007_LEN;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i+F032_VAL_LEN-INST_ID_LEN, tOrigTxn.acq_inst_id_code, INST_ID_LEN);
    i += F032_VAL_LEN;
    memcpy (tSendIpcIntTxn.sOrigDataElemts+i+F033_VAL_LEN-INST_ID_LEN, tOrigTxn.fwd_inst_id_code, INST_ID_LEN);

    /* send reversal to dest 1 */
HtLog ("lgm.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sTransmsnDateTime[%-10.10s].", tSendIpcIntTxn1.sTransmsnDateTime);
    memcpy ((char *)&tSendIpcIntTxn1, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
    memcpy( tSendIpcIntTxn1.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );

    nReturnCode = SendMsg (&tSendIpcIntTxn1, &tTxn, &tOrigTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
    }

    HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

    nReturnCode = InsertSafMsg (&tSendIpcIntTxn1, &tTxn, gatTxnInf[nIndex].saf_count1);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
    }

    if (gatTxnInf[nIndex].msg_dest2[0] != ' ' &&
            gatTxnInf[nIndex].msg_dest2[0] != 0x00 &&
            gatTxnInf[nIndex].rsp_type[0] != RSP_TYPE_NO_ACCOUNT &&
            memcmp (tOrigTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN) &&
            memcmp (tOrigTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN) )
    {
        /* send reversal to dest 2 */
        memcpy ((char *)&tSendIpcIntTxn1, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
        memcpy( tSendIpcIntTxn1.sMsgDestId, gatTxnInf[nIndex].msg_dest2, SRV_ID_LEN );

        nReturnCode = SendMsg (&tSendIpcIntTxn1, &tTxn, &tOrigTxn);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
        }

        HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

        nReturnCode = InsertSafMsg (&tSendIpcIntTxn1, &tTxn, gatTxnInf[nIndex].saf_count2);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
        }
    }

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    showIpc( ptIpcIntTxn );
    return 0;
}

int HandleSCCRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
    char            sFuncName[] = "HandleBDTRevsalRsp";
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sRspCode[F039_LEN+1];
    int                nReturnCode;
    int                nTxnSelOpr;
    int                nReqIndex;
    Tbl_txn_Def        tTxn, tOrigTxn;
    Tbl_ic_txn_Def  tIcTxn;
    T_IpcIntTxnDef    tSendIpcIntTxn, tSendIpcInt2;
    Tbl_saf_msg_Def    tSafMsg;
    char            sCurrentTime[15];
	char            sF055Len[F055_LEN_LEN+1] = {0};

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    #if 0
    /* ת��Ӧ���� */    
	nReturnCode = SwtCustTransferRspCode(ptIpcIntTxn);
	if (nReturnCode != 0 )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"transfer RSPCODE error, %d", nReturnCode);
    memcpy(ptIpcIntTxn->sRespCode,"01",F039_LEN);	
	}
   #endif

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
    memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  host SSN: %12.12s\n  response code: %2.2s",
            ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
            ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans,
            ptIpcIntTxn->sSysTraceAuditNum, ptIpcIntTxn->sHostSSN, ptIpcIntTxn->sRespCode);

    //memcpy(ptIpcIntTxn->sMisc+127, getenv("OLDNEWFLAG"), 1 );
    /***************
     * У��MAC
     ****************/
    
     /*  2011��5��6��  Ԭ�� ����  */
     
      /* �����������A0��discard���ף���У��MAC */
    if(memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) != 0 &&
        memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0)
    {
        nReturnCode = VerifyMAC (ptIpcIntTxn );
        if (nReturnCode != 0 )
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "VerifyMAC error, %d. Discard this message.", nReturnCode);
            return -1;
        }
    }
    /*  2011��5��6��  Ԭ�� ����  */
   
    /****************************
     * ����tbl_txn�еĽ��׼�¼
     ****************************/
    nReturnCode = SetKeyRsp (ptIpcIntTxn);

    /* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
    memset ((char *)&tTxn, 0, sizeof (tTxn));
    memcpy (tTxn.key_rsp, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
    memcpy (tTxn.txn_num, ptIpcIntTxn->sTxnNum, FLD_TXN_NUM_LEN);
    tTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
    /* �����ݿ��в���ԭ������ */
    nReturnCode = DbsTxn (DBS_SELECT21, &tTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn select error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    /* save F039 */
    memset (sRspCode, 0, sizeof(sRspCode));
    memcpy (sRspCode, tTxn.resp_code, F039_LEN);


    /***********************
     * ���ҽ���������gatTxnInf�е�����
     ************************/
    nReturnCode = GetTxnInfoIndex (tTxn.msg_src_id, tTxn.txn_num, &nReqIndex );
    if (nReturnCode || nReqIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
        return -1;
    }


    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* set trans state */
    switch (gatTxnInf[nReqIndex].rsp_type[0])
    {
        case RSP_TYPE_NO_ACCOUNT:
            if (IsRspSuccess (ptIpcIntTxn->sRespCode))
                memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
            else
                memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_CUPS, FLD_TRANS_STATE_LEN);
            break;
        case RSP_TYPE_RSP_BEFORE_ACCOUNT:
        case RSP_TYPE_RSP_AFTER_ACCOUNT:
            if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
            {
                /* trans_state save CUPS's response, won't be changed at host response */
                if (IsRspSuccess (ptIpcIntTxn->sRespCode))
                    memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                else
                    memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_CUPS, FLD_TRANS_STATE_LEN);
                /* resp_code save host F039, not CUP F039 */
                memcpy (tTxn.resp_code, sRspCode, F039_LEN);
            }
            break;
        default:
            break;
    }

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn update error, %d. Discard this message.", nReturnCode);

        return -1;
    }

    /* ���tbl_saf_msg�еķ��ʹ��� */
    memset ((char *)&tSafMsg, 0, sizeof (tSafMsg));
    memcpy (tSafMsg.inst_date, tTxn.inst_date, 8);
    memcpy (tSafMsg.inst_time, tTxn.inst_time, 6);
    memcpy (tSafMsg.sys_seq_num, tTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
    memcpy (tSafMsg.msg_dest_srv_id, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
    memset (tSafMsg.send_count, '0', 2);
    nReturnCode = DbsSafMsg (DBS_UPDATE, &tSafMsg);
    if (nReturnCode && nReturnCode != DBS_NOTFOUND )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsSafMsg update error, %d. Discard this message.", nReturnCode);

        return -1;
    }
    
    /***************
	* ����IC���ű�
	****************/
	if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    CommonGetCurrentTime(sCurrentTime);
	    memcpy (sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
	    sprintf(sF055Len, "%03d", atoi(sF055Len)*2);
	    memcpy(tIcTxn.rsp_iclen, sF055Len, F055_LEN_LEN);
	    Hex2Str(ptIpcIntTxn->sICData, tIcTxn.rsp_icdata, atoi(sF055Len)/2);
	    memcpy(tIcTxn.update_time, sCurrentTime, 14);
	    memcpy(tIcTxn.key_rsp, tTxn.key_rsp, KEY_RSP_LEN);
	    
	    nReturnCode = DbsIcTxn (DBS_UPDATE, &tIcTxn);
	    if (nReturnCode )
	    {
	    	DbsRollback ();
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
		    	"DbsIcTxn update error, %d. key_rsp[%32.32s], Discard this message.", nReturnCode, tIcTxn.key_rsp);
            
		    return -1;
	    }
	}

    DbsCommit ();
    
    if(!memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) && 
	    !memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "CUP return [%2.2s], respone 96", ptIpcIntTxn->sRespCode);
        memcpy(tSendIpcIntTxn.sRespCode, "96", F039_LEN);
    }
	

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}
