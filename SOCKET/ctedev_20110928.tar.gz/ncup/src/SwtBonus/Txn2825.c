/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Revsal.c                                                    */
/* DESCRIPTIONS: handle reversal req its rsp                                 */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-29  YU TONG        Initialize                                     */
/*****************************************************************************/
static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBonus/Attic/Txn2825.c,v 1.1.4.2 2011/09/23 02:57:03 ctedev Exp $";

#include "SwtBonus.h"

int Txn2825(T_IpcIntBonusDef *pIpcBonusTxn, int nIndex )
{
    char            sFuncName[] = "Txn2825";
    char            sRespCode[F039_LEN+1];
    char            sTxnNum[FLD_TXN_NUM_LEN+1];
    int             nReturnCode;
    int             i;
    int             nRevsalIndex;
    int             nSendRspFlag;
    T_SwtToReqDef   tSwtToReq;
    Tbl_bonus_txn_Def tBonusTxn, tOrigBonusTxn;
    char                        sCurrentDate[14+1];
    char            sF055Len[F055_LEN_LEN+1] = {0};
    char            sAmtTrans[13];
    char            sAmtCredit[13];
    char            sAmtBonus[13];
    
    T_IpcIntBonusDef tSendIpcBonusTxn, tSendIpcBonusTxn1;
    T_IpcIntBonusDef tIpcBonusTxn;
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    if (nIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", pIpcBonusTxn->sTxnNum, pIpcBonusTxn->sMsgSrcId);
        return -1;
    }
    
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    /***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex);
    memcpy(sCurrentDate, gsTimeCurTs, 14);
    

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %12.12s\n  orig data elem: %42.42s\n",
            gatTxnInf[nIndex].txn_num, pIpcBonusTxn->sPrimaryAcctNum, pIpcBonusTxn->sAmtTrans,
            pIpcBonusTxn->sDateLocalTrans, pIpcBonusTxn->sTimeLocalTrans, pIpcBonusTxn->sSysTraceAuditNum,
            pIpcBonusTxn->sOrigDataElemts);
            

    /* ����ǰ��F007,F011��sMisc */
     memcpy(pIpcBonusTxn->sMisc1, pIpcBonusTxn->sTransmsnDateTime, F007_LEN);
     memcpy(pIpcBonusTxn->sMisc1+F007_LEN, pIpcBonusTxn->sSysTraceAuditNum, F011_LEN);
     /* F007ʹ��ϵͳ��ǰʱ�� */
     memcpy(pIpcBonusTxn->sMiscFlag, sCurrentDate, 14);
     memcpy(pIpcBonusTxn->sTransmsnDateTime, sCurrentDate+4, F007_LEN);
     pIpcBonusTxn->sConsumeType[0] = '1';           
            
    nSendRspFlag = 1;
    if (!memcmp (pIpcBonusTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) ) 
    {
        /* no need to send reversal response for time out reversal or late response reversal */
        nSendRspFlag = 0;
    }

    /*******************
     * �жϸý����Ƿ�֧��
     ********************/
    if (nSendRspFlag && memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F038 */
        pIpcBonusTxn->cF038Ind = FLAG_NO_C;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);
        return -1;
    }

    /***************
     * ������ˮ��
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
    tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
    memcpy (tSwtToReq.sTxnDate, pIpcBonusTxn->sTransmsnDateTime, F007_LEN );

    nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, NULL);
    if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "ToCtrlReq error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */
        return -1;
    }
    /* save ssn in ipc */
    memcpy (pIpcBonusTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
    memcpy(pIpcBonusTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);

    /* ��key_rsp, key_revsal��ֵ */
    nReturnCode = SetKeyRevsal (pIpcBonusTxn);
    nReturnCode = SetKeyRsp (pIpcBonusTxn);

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (pIpcBonusTxn, &tBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        return -1;
    }

    /***************
     * �������׵������жϴ���
     ****************/
    memset ((char *)&tOrigBonusTxn, 0, sizeof (tOrigBonusTxn));
    memcpy ((char *)&tOrigBonusTxn, (char *)&tBonusTxn, sizeof (tBonusTxn));

    nReturnCode = CheckRevsalTxn (pIpcBonusTxn, &tOrigBonusTxn, sRespCode);
    if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
    {
        if (!memcmp (sRespCode, F039_DUPL_TXN, F039_LEN))
            memcpy (sRespCode, F039_SUCCESS, F039_LEN);
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "CheckRevsalTxn error, %d. Reject this transaction with %2.2s. nSendRspFlag[%d]", nReturnCode, sRespCode, nSendRspFlag);

        if (nSendRspFlag)
        {
            /* ����Ӧ���״��� */
            memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( pIpcBonusTxn->sRespCode, sRespCode, F039_LEN );
            /*����15��*/
            pIpcBonusTxn->cF015Ind = 'Y';
            memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            pIpcBonusTxn->sMsgType[2]++;
            /* clear F038 */
            pIpcBonusTxn->cF038Ind = FLAG_NO_C;
            /* clear F090 */
            memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
            
            nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, NULL);
        }

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
        DbsCommit ();


        return -1;
    }
    else
    {
        /* save original fe ssn in revsal_ssn */
        memcpy (tBonusTxn.revsal_ssn, tOrigBonusTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
        /* save original F037 */
        /***********************
        memcpy (tBonusTxn.retrivl_ref, tOrigBonusTxn.retrivl_ref, F037_LEN);
        memcpy (pIpcBonusTxn->sRetrivlRefNum, tOrigBonusTxn.retrivl_ref, F037_LEN);
        **********************/
        memset(sAmtTrans, 0, sizeof(sAmtTrans));
        memset(sAmtCredit, 0, sizeof(sAmtCredit));
        memset(sAmtBonus, 0, sizeof(sAmtBonus));
        memcpy(sAmtTrans, tOrigBonusTxn.amt_trans, F004_LEN);
        memcpy(sAmtBonus, tOrigBonusTxn.addtnl_amt+9, 9);
        sprintf(sAmtCredit, "%012d", atoi(sAmtTrans) - atoi(sAmtBonus)); 
    }

    /*******************
     * �����ͻ����ļ��
     ********************/
    if (nSendRspFlag)
    {
        nReturnCode = SwtCustCheckTxn (pIpcBonusTxn, sRespCode);
        if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "SwtCustCheckTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);

            /* ����Ӧ���״��� */
            memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( pIpcBonusTxn->sRespCode, sRespCode, F039_LEN );
            /*����15��*/
            pIpcBonusTxn->cF015Ind = 'Y';
            memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            pIpcBonusTxn->sMsgType[2]++;
            /* clear F038 */
            pIpcBonusTxn->cF038Ind = FLAG_NO_C;
            /* clear F090 */
            memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);
            
            nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);

            /* save this txn in Db */
            DbsBegin ();
            memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
            nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
            DbsCommit ();

            return -1;
        }
    }

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tBonusTxn.resp_code, pIpcBonusTxn->sRespCode, F039_LEN);
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBonusTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }

    /* �Գ�ʱ�����Ľ�����Դ�������ΪSwitch, ʹ��ԭʼ���׵Ľ�����Դ�� */
    memcpy (tBonusTxn.msg_src_id, tOrigBonusTxn.msg_src_id, SRV_ID_LEN);

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsBonusTxn (DBS_INSERT, &tBonusTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn insert error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        return -1;
    }

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");

    /***************
     * �������ݿ�ԭʼ���׼�¼
     ****************/
    memset (tOrigBonusTxn.revsal_flag, REV_CAN_FLAG_HAD, 1);
    memcpy (tOrigBonusTxn.revsal_ssn, tBonusTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
    nReturnCode = DbsBonusTxn (DBS_UPDATE2, &tOrigBonusTxn );
    if( nReturnCode != 0 )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn update error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        return -1;
    }

    DbsCommit ();

    /***********************
     *  ת��������
     ************************/
    memcpy ((char *)&tSendIpcBonusTxn, (char *)pIpcBonusTxn, sizeof (*pIpcBonusTxn));

    /****************
     * ���ͳɹ�Ӧ�������
     ****************/
    if (nSendRspFlag)
    {
        /* ����Ӧ���״��� */
        memcpy( pIpcBonusTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( pIpcBonusTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( pIpcBonusTxn->sRespCode, F039_SUCCESS, F039_LEN );
        /*����15��*/
        pIpcBonusTxn->cF015Ind = 'Y';
        memcpy(pIpcBonusTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        pIpcBonusTxn->sMsgType[2]++;
        /* clear F038 */
        pIpcBonusTxn->cF038Ind = FLAG_NO_C;
        /* clear F090 */
        memset (pIpcBonusTxn->sOrigDataElemts, ' ', F090_LEN);


        nReturnCode = SendMsg (pIpcBonusTxn, &tBonusTxn, &tOrigBonusTxn);
        if( nReturnCode != 0 )
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
        }
        HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Response sent to %s.", gatTxnInf[nIndex].rsp_dest_srv_id);
    }

    /***********************
     *  ת��������
     ************************/

    memcpy (tSendIpcBonusTxn.sSysTraceAuditNum, pIpcBonusTxn->sSysSeqNum, F011_LEN);
    nReturnCode = CopyOrigTxnInfo (&tOrigBonusTxn, &tSendIpcBonusTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CopyOrigTxnInfo error, %d.", nReturnCode);
    }
    
    /* save original txn info in F090 */
    memset (tSendIpcBonusTxn.sOrigDataElemts, '0', F090_LEN);
    i = 0;
    memcpy (tSendIpcBonusTxn.sOrigDataElemts+i, tOrigBonusTxn.fw_trans_id, FLD_FW_TRANS_ID_LEN);
    i += FLD_FW_TRANS_ID_LEN;
    memcpy (tSendIpcBonusTxn.sOrigDataElemts+i, tOrigBonusTxn.fw_trans_ssn, FLD_FW_TRANS_SSN_LEN);
    i += FLD_FW_TRANS_SSN_LEN;
    memcpy (tSendIpcBonusTxn.sOrigDataElemts+i, tOrigBonusTxn.fw_trans_date, FLD_FW_TRANS_DATE_LEN);
    i += FLD_FW_TRANS_DATE_LEN;
    memcpy (tSendIpcBonusTxn.sOrigDataElemts+i, tOrigBonusTxn.fw_trans_time, FLD_FW_TRANS_TIME_LEN);

    /* send reversal to dest 1 */
    memcpy ((char *)&tSendIpcBonusTxn1, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));
    memcpy( tSendIpcBonusTxn1.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );

    nReturnCode = SendMsg (&tSendIpcBonusTxn1, &tBonusTxn, &tOrigBonusTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
    }

    HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

    nReturnCode = InsertSafMsg (&tSendIpcBonusTxn1, &tBonusTxn, gatTxnInf[nIndex].saf_count1);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
    }

    if (gatTxnInf[nIndex].msg_dest2[0] != ' ' &&
        gatTxnInf[nIndex].msg_dest2[0] != 0x00 &&
        gatTxnInf[nIndex].rsp_type[0] != RSP_TYPE_NO_ACCOUNT &&
        memcmp (tOrigBonusTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN))
    {
        /* send reversal to dest 2 */
        memcpy ((char *)&tSendIpcBonusTxn1, (char *)&tSendIpcBonusTxn, sizeof (tSendIpcBonusTxn));
        memcpy( tSendIpcBonusTxn1.sMsgDestId, gatTxnInf[nIndex].msg_dest2, SRV_ID_LEN );
        memcpy(tSendIpcBonusTxn1.sAmtTrans, sAmtCredit, F004_LEN);
        nReturnCode = SendMsg (&tSendIpcBonusTxn1, &tBonusTxn, &tOrigBonusTxn);
        if (nReturnCode)
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
        }

        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

        nReturnCode = InsertSafMsg (&tSendIpcBonusTxn1, &tBonusTxn, gatTxnInf[nIndex].saf_count2);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
        }
    }

    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    
    return 0;
}
 
int Txn2826 (T_IpcIntBonusDef *pIpcBonusTxn, int nIndex )
{
    char            sFuncName[] = "Txn2826";
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sRspCode[F039_LEN+1];
    int                nReturnCode;
    int                nTxnSelOpr;
    int                nReqIndex;
    Tbl_bonus_txn_Def tBonusTxn, tOrigBonusTxn;
    Tbl_saf_msg_Def    tSafMsg;
    char            sCurrentTime[15];
    char            sF055Len[F055_LEN_LEN+1] = {0};

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    memset(sCurrentTime, 0, sizeof(sCurrentTime));
    SetToTime(-1);
    memcpy(sCurrentTime, gsTimeCurTs, 14);
    
    /* ת��Ӧ���� */    
    nReturnCode = SwtCustTransferRspCode(pIpcBonusTxn);
    if (nReturnCode != 0 )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "transfer RSPCODE error");
        memcpy(pIpcBonusTxn->sRespCode, "01", F039_LEN);    
    }

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
    memcpy (sMsgSrcId, pIpcBonusTxn->sMsgSrcId, SRV_ID_LEN);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  response code: %2.2s",
            pIpcBonusTxn->sTxnNum, pIpcBonusTxn->sPrimaryAcctNum, pIpcBonusTxn->sAmtTrans,
            pIpcBonusTxn->sDateLocalTrans, pIpcBonusTxn->sTimeLocalTrans,
            pIpcBonusTxn->sSysTraceAuditNum, pIpcBonusTxn->sRespCode);
   
    /****************************
     * ����tbl_txn�еĽ��׼�¼
     ****************************/
    nReturnCode = SetKeyRsp (pIpcBonusTxn);

    /* ����ѯ������ʹ�õ������Ƶ�tBonusTxn�� */
    memset ((char *)&tBonusTxn, 0, sizeof (tBonusTxn));
    memcpy (tBonusTxn.key_rsp, pIpcBonusTxn->sKeyRsp, KEY_RSP_LEN);
    memcpy (tBonusTxn.txn_num, pIpcBonusTxn->sTxnNum, FLD_TXN_NUM_LEN);
    tBonusTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
    /* �����ݿ��в���ԭ������ */
    nReturnCode = DbsBonusTxn (DBS_SELECT21, &tBonusTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn select error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    /* save F039 */
    memset (sRspCode, 0, sizeof(sRspCode));
    memcpy (sRspCode, tBonusTxn.resp_code, F039_LEN);
    pIpcBonusTxn->sConsumeType[0] = '1';
    tBonusTxn.consume_type[0] = '1';


    /***********************
     * ���ҽ���������gatTxnInf�е�����
     ************************/
    nReturnCode = GetTxnInfoIndex (tBonusTxn.msg_src_id, tBonusTxn.txn_num, &nReqIndex );
    if (nReturnCode || nReqIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
        return -1;
    }


    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (pIpcBonusTxn, &tBonusTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (pIpcBonusTxn, &tBonusTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* set trans state */
    switch (gatTxnInf[nReqIndex].rsp_type[0])
    {
        case RSP_TYPE_NO_ACCOUNT:
            if (IsRspSuccess (pIpcBonusTxn->sRespCode))
                memcpy (tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
            else
                memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_BP, FLD_TRANS_STATE_LEN);
            break;
        case RSP_TYPE_RSP_BEFORE_ACCOUNT:
        case RSP_TYPE_RSP_AFTER_ACCOUNT:
            if (!memcmp (sMsgSrcId, "1903", SRV_CUP_ID_LEN))
            {
                /* trans_state save CUPS's response, won't be changed at host response */
                if (IsRspSuccess (pIpcBonusTxn->sRespCode))
                    memcpy (tBonusTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                else
                    memcpy (tBonusTxn.trans_state, TRANS_STATE_REJ_BY_BP, FLD_TRANS_STATE_LEN);
                /* resp_code save host F039, not CUP F039 */
                memcpy (tBonusTxn.resp_code, sRspCode, F039_LEN);
            }
            break;
        default:
            break;
    }

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsBonusTxn (DBS_UPDATE1, &tBonusTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsBonusTxn update error, %d. Discard this message.", nReturnCode);

        return -1;
    }

    /* ���tbl_saf_msg�еķ��ʹ��� */
    memset ((char *)&tSafMsg, 0, sizeof (tSafMsg));
    memcpy (tSafMsg.inst_date, tBonusTxn.inst_date, 8);
    memcpy (tSafMsg.inst_time, tBonusTxn.inst_time, 6);
    memcpy (tSafMsg.sys_seq_num, tBonusTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
    memcpy (tSafMsg.msg_dest_srv_id, pIpcBonusTxn->sMsgSrcId, SRV_ID_LEN);
    memset (tSafMsg.send_count, '0', 2);
    nReturnCode = DbsSafMsg (DBS_UPDATE, &tSafMsg);
    if (nReturnCode && nReturnCode != DBS_NOTFOUND )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsSafMsg update error, %d. Discard this message.", nReturnCode);

        return -1;
    }

    DbsCommit ();

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}
