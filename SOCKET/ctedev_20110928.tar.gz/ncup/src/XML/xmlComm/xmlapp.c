
#include <stdio.h>
#include "xmlstruct.h"
#include "xml/mxml.h"
#include "xml/xml.h"

char gsLogFile[LOG_NAME_LEN_MAX]="xmlapp.log";

int createxml(int nSavKey,char *IPCrcvmsgbuf,int iXMLinlen,char *sXmlOutBuf,int *iXMLoutlen,AllXmlnodeBuf sCRTallxmlnodebuf)
{
	int ilRc; 
  int bufindex;
	int liX;
  int 	alllen =0;
	int nxmlOffset =0;
	char attrtest1[60+1];
	char attrtest2[60+1];
	char attrtest3[60+1];
	char attrname1[40+1];
	char attrname2[40+1];
	char attrname3[40+1];
    char path_tmp[100];
    char father_node_name[41];
    char sp_node_name[41];
    
	int  iRet, i, j, iLoopBegin,iLoopFlag = 0;
	int  iLoopPos = 0;
	int  iMatchFlag = 0;
	int  iTotListNum = 0;
	int  iCurListNum = 1;
	char sListNum[4+1] = {0};
	char sLastRecName[30+1] = {0};
	char sTempRecName[256] = {0};
	char sTempTagName[256] = {0};
	char sTempValue[256] = {0};
	char sLoopName[64] = {0};
	
	mxml_node_t  *ptLocRoot, *pNode, *pTemp, *pList;
		
	int path_len=0;
	char keycodeTMP[11];
  int igMsgbodylen;
  char alTmp[200];
	char alBuf[2048],alXpath[100];
	xml_trans_dsp ltXmlTransDsp;
	
	memset(&ltXmlTransDsp,0x00,sizeof(ltXmlTransDsp));
	memset(&alTmp,0x00,sizeof(alTmp));
  memset(&alBuf,0x00,sizeof(alBuf));
  memset(path_tmp,0,sizeof(path_tmp));
  memset(&alXpath,0x00,sizeof(alXpath));
  memset(keycodeTMP,0x00,sizeof(keycodeTMP));
	
 /* _xmInitRuleTable();

  if(nSavKey==1)
  xmlpackInit("1.0","UTF-8"); 
  else if(nSavKey==2)  
  xmlpackInit("1.0","ISO-8859-1");  
  else
  xmlpackInit("1.0","UTF-8"); */
  
  
  
  ptLocRoot = (mxml_node_t *)XmlInit();
    if (ptLocRoot == NULL)
    {
    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlInit Error !");
    	return -1;
    }
    
  memcpy(keycodeTMP,&IPCrcvmsgbuf[95],6);
  memset(ltXmlTransDsp.txn_number,0x20,6);
	memcpy(ltXmlTransDsp.txn_number ,keycodeTMP,strlen(keycodeTMP));
	HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"xmlInit  txn_number[%s]--[%d]\n",ltXmlTransDsp.txn_number,nSavKey);	     
  /* _xmTrim(&ltXmlTransDsp.txn_number);
   i = strlen(ltXmlTransDsp.txn_number);*/
  for(liX = 0; liX < sCRTallxmlnodebuf.nBufN; liX++)
  {
  	/*_xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[liX].txncode);*/
  	HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"xmlInit  txncode[%s]--[%d]\n",
  	       sCRTallxmlnodebuf.stxmlnodebuf[liX].txncode,sCRTallxmlnodebuf.stxmlnodebuf[liX].usage_key);
    if (memcmp(sCRTallxmlnodebuf.stxmlnodebuf[liX].txncode,ltXmlTransDsp.txn_number,6) == 0
    	 && sCRTallxmlnodebuf.stxmlnodebuf[liX].usage_key == nSavKey )
     {
       bufindex= liX;
       break;
     }
  }
  HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"xmlInit  nBufN[%d]--liX[%d]\n",sCRTallxmlnodebuf.nBufN,liX);	     
  if(liX >= sCRTallxmlnodebuf.nBufN)
     return -1;
     
  for(liX = 0; liX < sCRTallxmlnodebuf.stxmlnodebuf[bufindex].nFldN; liX++)
  {
  	_xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
    _xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name);
    _xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);
    _xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1);
    _xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name2);
    _xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test2);
    _xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name3);
    _xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test3);
    _xmTrim(&sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nodepath);
     strcpy(father_node_name,sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
     strcpy(sp_node_name,sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     strcpy(attrname1,sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);
     strcpy(attrtest1,sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1); 
     strcpy(attrname2,sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name2);
     strcpy(attrtest2,sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test2); 
     strcpy(attrname3,sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name3);
     strcpy(attrtest3,sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test3); 
       
    /* ���Ӹ��ڵ� */
     if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_id ==0  )
     {
     	 HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  sp_node_name[%s]\n",sp_node_name);	 
     	  HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrname1[%s]\n",attrname1);
     	   HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrname2[%s]\n",attrname2);
     	    HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrname3[%s]\n",attrname3);
     	     HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrtest1[%s]\n",attrtest1);
     	      HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrtest2[%s]\n",attrtest2); 
     	      HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrtest3[%s]\n",attrtest3);     
     	pNode = (mxml_node_t *)XmlAddListValue(ptLocRoot, sp_node_name, NULL);	
     	 if (pNode == NULL)
         {
           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
           XmlFree(ptLocRoot);
           return -1;
         } 
     	if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==1)
     	{
     		pNode = (mxml_node_t *)XmlAddList(ptLocRoot, sp_node_name,attrname1, attrtest1);
     	   if (pNode == NULL)
           {
              HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
              XmlFree(ptLocRoot);
              return -1;
           } 
     	}
     	else if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==2)
     	{
     		pNode = (mxml_node_t *)XmlAddList(ptLocRoot, sp_node_name,attrname1, attrtest1);
            pNode = (mxml_node_t *)XmlAddList(ptLocRoot, sp_node_name, attrname2, attrtest2);
            if (pNode == NULL)
           {
              HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
              XmlFree(ptLocRoot);
              return -1;
           } 
     	}
     	else if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==3)
     	{
          pNode = (mxml_node_t *)XmlAddList(ptLocRoot, sp_node_name,attrname1, attrtest1);
          pNode = (mxml_node_t *)XmlAddList(ptLocRoot, sp_node_name, attrname2, attrtest2);
          pNode = (mxml_node_t *)XmlAddList(ptLocRoot, sp_node_name, attrname3, attrtest3);
          if (pNode == NULL)
           {
              HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
              XmlFree(ptLocRoot);
              return -1;
           } 
       }	     
     }
     else if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index ==0 &&
     	  sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_id !=0 )
     {
     	 HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  sp_node_name[%s]\n",sp_node_name);	 
     	 HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  father_node_name[%s]\n",father_node_name);
     	  HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrname1[%s]\n",attrname1);
     	   HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrname2[%s]\n",attrname2);
     	    HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrname3[%s]\n",attrname3);
     	     HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrtest1[%s]\n",attrtest1);
     	      HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrtest2[%s]\n",attrtest2); 
     	      HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrtest3[%s]\n",attrtest3);         
     	pTemp = (mxml_node_t*)FindNode(ptLocRoot, father_node_name);
     	 if (pTemp == NULL)
         {
           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
           XmlFree(ptLocRoot);
           return -1;
         } 
     	pNode = (mxml_node_t *)XmlAddListValue(pTemp, sp_node_name, NULL);
     	 if (pNode == NULL)
         {
           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
           XmlFree(ptLocRoot);
           return -1;
         } 	
     	if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==1)
     	{
     		pNode = (mxml_node_t *)XmlAddList(pTemp, sp_node_name,attrname1, attrtest1);
     		if (pNode == NULL)
            {
              HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
              XmlFree(ptLocRoot);
              return -1;
            } 
     	}
     	else if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==2)
     	{
     		pNode = (mxml_node_t *)XmlAddList(pTemp, sp_node_name,attrname1, attrtest1);
            pNode = (mxml_node_t *)XmlAddList(pTemp, sp_node_name, attrname2, attrtest2);
            if (pNode == NULL)
           {
             HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
             XmlFree(ptLocRoot);
             return -1;
           } 
     	}
     	else if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==3)
     	{
          pNode = (mxml_node_t *)XmlAddList(pTemp, sp_node_name,attrname1, attrtest1);
          pNode = (mxml_node_t *)XmlAddList(pTemp, sp_node_name, attrname2, attrtest2);
          pNode = (mxml_node_t *)XmlAddList(pTemp, sp_node_name, attrname3, attrtest3);
          if (pNode == NULL)
         {
           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
           XmlFree(ptLocRoot);
           return -1;
         } 
       }	     
     }
     else if (sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index !=0)
     {
         HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  sp_node_name[%s]\n",sp_node_name);	 
     	 HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  father_node_name[%s]\n",father_node_name);
     	  HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrname1[%s]\n",attrname1);
     	     HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"XmlAddListValue  attrtest1[%s]\n",attrtest1);       
     	nxmlOffset = sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nOffset;
     	memset(alTmp,0x00,sizeof(alTmp));
        memcpy(alTmp,&IPCrcvmsgbuf[nxmlOffset],
                 sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL); 
       HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"1xmlAddNode nxmlOffset ---INITvalues[%s]\n",alTmp);       
        _xmTrim(alTmp); 
        
      HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"1xmlAddNode nxmlOffset [%d]--nFldL[%d]---values[%s]\n",nxmlOffset,
             sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL,
             alTmp);
       pTemp = (mxml_node_t*)FindNode(ptLocRoot, father_node_name) ; 
       if (pTemp == NULL)
         {
           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
           XmlFree(ptLocRoot);
           return -1;
          }  
       if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==0)
     	{
          pNode = (mxml_node_t *)XmlAddListValue(pTemp, sp_node_name, alTmp);
          if (pNode == NULL)
         {
           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
           XmlFree(ptLocRoot);
           return -1;
          }  	          
        }
       else if(sCRTallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==1)
      {        
          pNode =  XmlAddList1Arrt(pTemp, sp_node_name, alTmp,attrname1, attrtest1);
         if (pNode == NULL)
         {
           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlAddList1Arrt error !");
           XmlFree(ptLocRoot);
           return -1;
          }  
       }
     }
  }
  /*���BUF����*/
  HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"*** DUMP BUF TEST ***\n");
  
  /* XMLתstring */
    memset(sXmlOutBuf,0x00,sizeof(sXmlOutBuf));
	*iXMLoutlen = XmlSaveString(ptLocRoot, sXmlOutBuf, 4096);
    if (iXMLoutlen < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlSaveString error !");
        XmlFree(ptLocRoot);
        return -1;
    }  
    _xmTrim(sXmlOutBuf);
    free(ptLocRoot);
    *iXMLoutlen= strlen(sXmlOutBuf);
    /**iXMLoutlen=strlen(sXmlOutBuf);*/
  HtLog ("xmlcreat.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"*** DUMP BUF TEST sXmlOutBuf---[%s]***\n",sXmlOutBuf);
  HtDebugString ("xmlcreat.log", HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, 
				sXmlOutBuf, strlen(sXmlOutBuf));

  return 0;
}

	
int parsexml(int nSavKey,char *XMLrevmsgbuf,int iXMLinlen,char *IPCsendmsgbuf,int *iXMLoutlen,AllXmlnodeBuf sPARallxmlnodebuf)
{
	FILE *fhd;
	int ilRc;
	int i,liX;  
	char c;
	int bufindex;
	int 	alllen =0;
	int nxmlOffset =0;
	char lentmp[5];
	int fldlen =0;
	int ret;
	char BufTmp[MSQ_MSG_SIZE_MAX];
	char	strXmlBuf[MSQ_MSG_SIZE_MAX];
	char attrtest1[61];
	char attrtest2[61];
	char attrtest3[61];
	char attrname1[40];
	char attrname2[40];
	char attrname3[40];
    char path_tmp[100];
    char father_node_name[41];
    char sp_node_name[41];
    
	mxml_node_t  *pRoot, *pTemp, *pInTree,*pList ,*pOutRoot;
	char saCompKey[11], saTmp[200], saDataLen[4];
	char loopTmp[2];
	char sCmdType[1+1] = {0};
	char sServiceId[30+1] = {0};
	char sReqBuf[4096] = {0};
	int  nReturnCode;
	int	 nValLen,iValueLen;  
	int  iRet;  
	int max_len;
	int loopcount=0;
	int loopnum=0;

	
	char txcode[11];
  int igMsgbodylen;
  int path_len=0;
  char alTmp[200];
	char alBuf[2048],alXpath[100];
	xml_trans_dsp ltXmlTransDsp;
  memset(alXpath,0,sizeof(alXpath));
  memset(attrtest1,0,sizeof(attrtest1));
  memset(attrtest2,0,sizeof(attrtest2));
  memset(attrtest3,0,sizeof(attrtest3));
  memset(attrname1,0,sizeof(attrname1));
  memset(attrname2,0,sizeof(attrname2));
  memset(attrname3,0,sizeof(attrname3));
  memset(alBuf,0,sizeof(alBuf));
  memset(BufTmp,0,sizeof(BufTmp));
  memset(path_tmp,0,sizeof(path_tmp));
  
  memset(strXmlBuf,0,MSQ_MSG_SIZE_MAX);
  
  /*memcpy(strXmlBuf,IPCsendmsgbuf,38);
  memset(&strXmlBuf[38],' ',MSQ_MSG_SIZE_MAX-38);*/
  memset(strXmlBuf,' ',MSQ_MSG_SIZE_MAX);
  memset(IPCsendmsgbuf,0,sizeof(IPCsendmsgbuf)); 
  
  HtDebugString ("xmlparse.log", HT_LOG_MODE_ERROR, __FILE__, __LINE__,XMLrevmsgbuf,iXMLinlen);
    _xmTrim(XMLrevmsgbuf);
   iXMLinlen = strlen(XMLrevmsgbuf);
   pRoot = (mxml_node_t *)XmlLoadString(XMLrevmsgbuf);
   if (pRoot == NULL)
   {
   	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlLoadFile Error !");
   	return(-1);
   }

   	HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"nSavKey[%d]\n",nSavKey);
  /*if(nSavKey==2)
  	{
  		memcpy(BufTmp,XMLrevmsgbuf,30);
  		memcpy(BufTmp+30,"UTF-8",5);
  		memcpy(BufTmp+35,XMLrevmsgbuf+40,1);
  		memcpy(BufTmp+36,XMLrevmsgbuf+42,iXMLinlen-42);
  		memset(XMLrevmsgbuf,0,MSQ_MSG_SIZE_MAX);
  		memcpy(XMLrevmsgbuf,BufTmp,iXMLinlen-6);
  		HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"xmlInit XMLrevmsgbuf[%s]\n",XMLrevmsgbuf);
  	}
  	if(nSavKey==3)
  	{
  		memcpy(BufTmp,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>",38);
  		memcpy(BufTmp+38,XMLrevmsgbuf+21,iXMLinlen-21);
  		memset(XMLrevmsgbuf,0,MSQ_MSG_SIZE_MAX);
  		memcpy(XMLrevmsgbuf,BufTmp,iXMLinlen+17);
  		XMLrevmsgbuf[iXMLinlen+17]=0x00;
  		HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"xmlInit XMLrevmsglen[%d]---turelen[%d]\n",iXMLinlen+18,strlen(XMLrevmsgbuf));
  		HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"xmlInit XMLrevmsgbuf[%s]\n",XMLrevmsgbuf);
  	}*/
   memset(txcode,0x00,sizeof(txcode));
	 /*ȡ���ӵĽڵ�ֵ*/
	  HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode can not find nBufN %d \n",sPARallxmlnodebuf.nBufN);
     for(liX = 0; liX < sPARallxmlnodebuf.nBufN; liX++)
  {
    if (sPARallxmlnodebuf.stxmlnodebuf[liX].bufid == 9999
    	 && sPARallxmlnodebuf.stxmlnodebuf[liX].usage_key == nSavKey)
    {
      bufindex= liX;
      break;
    }
  }

  if(liX >= sPARallxmlnodebuf.nBufN)
    {
   	   HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode can not find \n");
   	   free(pRoot);
       return -1;  
    }
 
  for(liX = 0; liX < sPARallxmlnodebuf.stxmlnodebuf[bufindex].nFldN; liX++)
  {  
  	 if( sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index == 0 )
  	 {  	 
          HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode can not find %s\n",sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name);
          continue;
      }    
     else
     	{
          HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode can not find %s\n",sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name);
           break;
       } 
   }

   if(liX >= sPARallxmlnodebuf.stxmlnodebuf[bufindex].nFldN)
   	{
   	   HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode sp_node_name:[%s] \n",sp_node_name);
       free(pRoot);
       return -1;  
    }
    HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode can not find \n");
  /*֧��һ���ؼ�������--XmlbufId==9999*/
   memset(father_node_name,0x00,sizeof(father_node_name));
   memset(sp_node_name,0x00,sizeof(sp_node_name));
     HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode father_node_name:[%s] \n", sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
     HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode father_node_name:[%s] \n",sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name);
    
   _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);  
   _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
   strcpy(father_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
   strcpy(sp_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name);
   HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode sp_node_name:[%s] \n",sp_node_name);
   HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode nodepath:[%s] \n",alXpath);
   
     /* �ͻ����жϽ��״��� */
   nValLen = XmlGetValue(pRoot, father_node_name,sp_node_name, txcode, sizeof(txcode)-1);
   if (nValLen <= 0)
   {
   	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"XmlGetValue serviceId err !");
   	free(pRoot);
   	return(-1);
   }
   HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode Usage:[%s] \n",txcode);
    _xmTrim(txcode);
  
  for(liX = 0; liX < sPARallxmlnodebuf.nBufN; liX++)
  {
  	_xmTrim(&sPARallxmlnodebuf.stxmlnodebuf[liX].txncode);
  	 HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "txcode Usage:[%s] \n",sPARallxmlnodebuf.stxmlnodebuf[liX].txncode);
    if (memcmp(txcode, sPARallxmlnodebuf.stxmlnodebuf[liX].txncode,strlen(txcode))== 0
    	 && sPARallxmlnodebuf.stxmlnodebuf[liX].usage_key == nSavKey)
    {
      bufindex= liX;
      break;
    }
  }
  if(liX >= sPARallxmlnodebuf.nBufN)
  {
     free(pRoot);
     return -1;
     
   }
  for(liX = 0; liX < sPARallxmlnodebuf.stxmlnodebuf[bufindex].nFldN; liX++)
  {  
  	 if( sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index == 0 
  	 && sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num == 0)
     continue;  
     
   memset(path_tmp,0x00,sizeof(path_tmp));
   _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name);
   path_len = strlen(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name);
   HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "i_attribute_num[%ld]\n",sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num);
   
   
   if (sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==1 &&
   	       sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index != 0 &&
   	    sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_repeat_or == 0)
   { 
   	 memset(&alBuf,0x00,sizeof(alBuf));
   	 memset(father_node_name,0x00,sizeof(father_node_name));
     memset(sp_node_name,0x00,sizeof(sp_node_name));
     memset(attrtest1,0,sizeof(attrtest1));  
     memset(attrname1,0,sizeof(attrname1));     
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1);
      
     strcpy(father_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
     strcpy(sp_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     strcpy(attrname1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);
     strcpy(attrtest1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1); 
      
     max_len=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL ;	        	     

    pList = (mxml_node_t *)FindNode1Arrt(pRoot, sp_node_name,attrname1,attrtest1);
	if (pList == NULL)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"FindNode [%s] Error", sp_node_name);
		free(pRoot);
	   return(-1);
	}		  

	 iValueLen = GetNodeText(pList, alBuf, max_len);
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue [%s] Error", sp_node_name);
		free(pRoot);
	    return(-1);
	 }
	 nxmlOffset = sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nOffset;
     HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " nxmlOffset:%d ---sp_node_name[%s]-alBuf[%s]\n",nxmlOffset,attrtest1,alBuf); 
     HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen--alllen[%d]----nFldL:[%d]--- \n",alllen,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL);  
     memcpy(&strXmlBuf[nxmlOffset],alBuf,strlen(alBuf));
      alllen+=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL;
     HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen-alllen:[%d]--- \n",alllen);  
   }
   else if (sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index != 0 &&
      sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==0 &&
      sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_repeat_or == 0)
   {   
   	 memset(&alBuf,0x00,sizeof(alBuf));
   	 memset(father_node_name,0x00,sizeof(father_node_name));
     memset(sp_node_name,0x00,sizeof(sp_node_name));
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     strcpy(father_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
     strcpy(sp_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name);  
     max_len=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL ;	        	     

	 iValueLen = XmlGetValue(pRoot, father_node_name, sp_node_name, alBuf, max_len);
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue sp_node_name[%s] -father_node_name[%s]Error", sp_node_name,father_node_name);
		free(pRoot);
	    return(-1);
	 }
	 nxmlOffset = sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nOffset;
     HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " nxmlOffset:%d ---sp_node_name[%s]-alBuf[%s]\n",nxmlOffset,sp_node_name,alBuf); 
      HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen--alllen[%d]----nFldL:[%d]--- \n",alllen,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL);  
      memcpy(&strXmlBuf[nxmlOffset],alBuf,strlen(alBuf));
      alllen+=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL;
      HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen-alllen:[%d]--- \n",alllen);  
   }
    else if (sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==1 &&
    	       sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index != 0 &&
    	    sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_repeat_or == 1)
    { 
    	 memset(&alBuf,0x00,sizeof(alBuf));
    	 memset(father_node_name,0x00,sizeof(father_node_name));
      memset(sp_node_name,0x00,sizeof(sp_node_name));
      memset(attrtest1,0,sizeof(attrtest1));  
      memset(attrname1,0,sizeof(attrname1));     
      _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);  
      _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
      _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);  
      _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1);
       
      strcpy(father_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
      strcpy(sp_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
      strcpy(attrname1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);
      strcpy(attrtest1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1); 
      
      /*����ѭ������,ѭ���ڵ���---����֧���ͻ���*/    
     pList = (mxml_node_t *)FindNode1Arrt(pRoot, "gdb:field","name","loopCount");
	 if (pList == NULL)
	 {
	 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"FindNode [%s] Error", sp_node_name);
	 	free(pRoot);
	    return(-1);
	 }		  
	    memset(loopTmp,0x00,sizeof(loopTmp));
	  iValueLen = GetNodeText(pList, loopTmp, 1);
	  if (iValueLen < 0 )
	  {
	 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	 			"XmlGetValue [%s] Error", sp_node_name);
	 	free(pRoot);
	     return(-1);
	  }
	  loopcount= atoi(loopTmp);
	  
	  pList = (mxml_node_t *)FindNode1Arrt(pRoot, "gdb:field","name","loopColumns");
	 if (pList == NULL)
	 {
	 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"FindNode [%s] Error", sp_node_name);
	 	free(pRoot);
	    return(-1);
	 }		  
	    memset(loopTmp,0x00,sizeof(loopTmp));
	  iValueLen = GetNodeText(pList, loopTmp, 1);
	  if (iValueLen < 0 )
	  {
	 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	 			"XmlGetValue [%s] Error", sp_node_name);
	 	free(pRoot);
	     return(-1);
	  }
	  loopnum = atoi(loopTmp);

      for(i=0;i<loopcount;i++)
      {   
          max_len=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL ;	        	     
          if(i==0)
          {
             pList = (mxml_node_t *)FindNode1Arrt(pRoot, sp_node_name,attrname1,attrtest1);
	         if (pList == NULL)
	         {
	  	       HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"FindNode [%s] Error", sp_node_name);
	           free(pRoot);
	           return(-1);
	         }		  
             
	         iValueLen = GetNodeText(pList, alBuf, max_len);
	         if (iValueLen < 0 )
	         {
	  	      HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	  	      		"XmlGetValue [%s] Error", sp_node_name);
	  	      		free(pRoot);
	            return(-1);
	         }
	         nxmlOffset = sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nOffset;
             HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " nxmlOffset:%d ---sp_node_name[%s]-alBuf[%s]\n",nxmlOffset,attrtest1,alBuf); 
              HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen--alllen[%d]----nFldL:[%d]--- \n",alllen,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL);  
             memcpy(&strXmlBuf[nxmlOffset],alBuf,strlen(alBuf));
             alllen+=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL;
             HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen-alllen:[%d]--- \n",alllen);  
         }
         else
         	{
         	
         		 pList = (mxml_node_t *)FindNodeArrt_next(pList, sp_node_name,attrname1,attrtest1);
	              if (pList == NULL)
	              {
	  	           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"FindNode [%s] Error", sp_node_name);
	               free(pRoot);
	                return(-1);
	              }		  
                  
	              iValueLen = GetNodeText(pList, alBuf, max_len);
	              if (iValueLen < 0 )
	              {
	  	           HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	  	           		"XmlGetValue [%s] Error", sp_node_name);
	                 free(pRoot);
	                 return(-1);
	              }
	              nxmlOffset = sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nOffset+i*45;
	          	                  
                  HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " nxmlOffset:%d ---sp_node_name[%s]-alBuf[%s]\n",nxmlOffset,attrtest1,alBuf); 
                  HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen--alllen[%d]----nFldL:[%d]--- \n",alllen,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL);  
                  memcpy(&strXmlBuf[nxmlOffset],alBuf,strlen(alBuf));
                  alllen+=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL;
                  HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen-alllen:[%d]--- \n",alllen);  
         	} 
      }
     
    }
    else if (sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index != 0 &&
      sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==0 &&
      sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_repeat_or == 1)
   {   
   	 memset(&alBuf,0x00,sizeof(alBuf));
   	 memset(father_node_name,0x00,sizeof(father_node_name));
     memset(sp_node_name,0x00,sizeof(sp_node_name));
     memset(attrtest1,0,sizeof(attrtest1));  
     memset(attrname1,0,sizeof(attrname1));     
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1);
      
     strcpy(father_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
     strcpy(sp_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     strcpy(attrname1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);
     strcpy(attrtest1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1); 
      
     max_len=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL ;	        	     

    pList = (mxml_node_t *)FindNode1Arrt(pRoot, sp_node_name,attrname1,attrtest1);
	if (pList == NULL)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					        			"FindNode [%s] Error", sp_node_name);
	   free(pRoot);
	   return(-1);
	}		  

	 iValueLen = GetNodeText(pList ,alBuf, max_len);
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue [%s] Error", sp_node_name);
	   free(pRoot);
	    return(-1);
	 }
	 nxmlOffset = sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nOffset;
      HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " nxmlOffset:%d ---sp_node_name[%s]-alBuf[%s]\n",nxmlOffset,sp_node_name,alBuf); 
      HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen--alllen[%d]----nFldL:[%d]--- \n",alllen,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL);  
      memcpy(&strXmlBuf[nxmlOffset],alBuf,strlen(alBuf));
      alllen+=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL;
      HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " strlen-alllen:[%d]--- \n",alllen);  
   }

   else if (sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==1 &&
    	sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index == 0)
   {
   	 memset(&alBuf,0x00,sizeof(alBuf));
   	 memset(father_node_name,0x00,sizeof(father_node_name));
     memset(sp_node_name,0x00,sizeof(sp_node_name));
     memset(attrtest1,0,sizeof(attrtest1));  
     memset(attrname1,0,sizeof(attrname1));     
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1);
      
     strcpy(father_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
     strcpy(sp_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     strcpy(attrname1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);
     strcpy(attrtest1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1); 
      
     max_len=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL ;	        	     

    pList = (mxml_node_t *)FindNode(pRoot, sp_node_name);
	if (pList == NULL)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					        			"FindNode [%s] Error", sp_node_name);
	   free(pRoot);
	   return(-1);
	} 
	
	 iValueLen = XmlGet(pList, attrname1, attrtest1, strlen(attrtest1));
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue [%s] Error", sp_node_name);
	    free(pRoot);
	    return(-1);
	 }
   }
   else if (sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==2 &&
   	 sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index == 0)
   {
   	   memset(&alBuf,0x00,sizeof(alBuf));
   	 memset(father_node_name,0x00,sizeof(father_node_name));
     memset(sp_node_name,0x00,sizeof(sp_node_name));
     memset(attrtest1,0,sizeof(attrtest1));  
     memset(attrname1,0,sizeof(attrname1));     
     memset(attrtest2,0,sizeof(attrtest2));  
      memset(attrname2,0,sizeof(attrname2));   
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1);
      _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name2);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test2);
      _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name3);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test3);
      
     strcpy(father_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
     strcpy(sp_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     strcpy(attrname1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);
     strcpy(attrtest1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1); 
     strcpy(attrname2,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name2);
     strcpy(attrtest2,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test2); 
      
     max_len=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL ;	        	     

    pList = (mxml_node_t *)FindNode(pRoot, sp_node_name);
	if (pList == NULL)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					        			"FindNode [%s] Error", sp_node_name);
					        			free(pRoot);
	   return(-1);
	} 
	
	 iValueLen = XmlGet(pList, attrname1, attrtest1, strlen(attrtest1));
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue [%s] Error", sp_node_name);
				free(pRoot);
	    return(-1);
	 }
	  iValueLen = XmlGet(pList, attrname2, attrtest2, strlen(attrtest2));
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue [%s] Error", sp_node_name);
				free(pRoot);
	    return(-1);
	 }
   }
  else  if (sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_attribute_num ==3 &&
   	    sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].i_fld_index == 0)
   {
     memset(&alBuf,0x00,sizeof(alBuf));
   	 memset(father_node_name,0x00,sizeof(father_node_name));
     memset(sp_node_name,0x00,sizeof(sp_node_name));
     memset(attrtest1,0,sizeof(attrtest1));  
     memset(attrname1,0,sizeof(attrname1));   
      memset(attrtest2,0,sizeof(attrtest2));  
      memset(attrname2,0,sizeof(attrname2));   
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1);
      _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name2);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test2);
      _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name3);  
     _xmTrim(sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test3);
      
     strcpy(father_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].father_node_name);
     strcpy(sp_node_name,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_node_name); 
     strcpy(attrname1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name1);
     strcpy(attrtest1,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test1); 
     strcpy(attrname2,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name2);
     strcpy(attrtest2,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test2); 
     strcpy(attrname3,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_name3);
     strcpy(attrtest3,sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].sp_attribute_test3); 
      
     max_len=sPARallxmlnodebuf.stxmlnodebuf[bufindex].stxmlnodeinf[liX].nFldL ;	        	     

    pList = (mxml_node_t *)FindNode(pRoot, sp_node_name);
	if (pList == NULL)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					        			"FindNode [%s] Error", sp_node_name);
					        			free(pRoot);
	   return(-1);
	} 
	
	 iValueLen = XmlGet(pList, attrname1, attrtest1, strlen(attrtest1));
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue [%s] Error", sp_node_name);
				free(pRoot);
	    return(-1);
	 }
	 
	 iValueLen = XmlGet(pList, attrname1, attrtest2, strlen(attrtest2));
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue [%s] Error", sp_node_name);
				free(pRoot);
	    return(-1);
	 }
	 
	 iValueLen = XmlGet(pList, attrname1, attrtest3, strlen(attrtest3));
	 if (iValueLen < 0 )
	 {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"XmlGetValue [%s] Error", sp_node_name);
				free(pRoot);
	    return(-1);
	 }
   }
  else 
  	{
  		/*��֧�ֵĵ�����*/
  		free(pRoot);
  		return -1;
  	}
   
  }
  /*_xmTrim(strXmlBuf); */
  alllen+=50;
  *iXMLoutlen = alllen;
   HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " alllen%d \n",alllen);
   memset(lentmp,0x00,strlen(lentmp));
  sprintf(lentmp,"%4.4d",alllen);
  memcpy(strXmlBuf+38,lentmp,4);  
  strXmlBuf[alllen] = '\0';
  HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " outbuf%d---strXmlBuf:%s \n",*iXMLoutlen,strXmlBuf); 
  memcpy(IPCsendmsgbuf,strXmlBuf,alllen); 
  IPCsendmsgbuf[alllen] = '\0';
 
  HtLog ("xmlparse.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, " outbuf%d---IPCsendmsgbuf:%s \n",*iXMLoutlen,IPCsendmsgbuf); 
  free(pRoot);
  return 0;
     
}

 
