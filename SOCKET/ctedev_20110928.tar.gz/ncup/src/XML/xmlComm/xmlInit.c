#include "xmlstruct.h"
#include "HtLog.h"

/*****************************************************************************/
/* FUNC:   int xmlInit (int argc, char **argv)                               */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �������ݿ�, ����ȫ�ֱ���, ��ȡ���в���,                           */
/*         ��ʼ����Ϣ����, �����ݿ��ȡxml��                                 */
/*****************************************************************************/

int BribdgexmlInit (int  nBufChgKey, AllXmlnodeBuf *vtpallxmlnodebuf)
{

	int				nReturnCode;	
	int       llResult;
	int       liX;

	long			lUsageKey;
  xml_trans_dsp                     stxmltransdsp;
  AllXmlnodeBuf                     stallxmlnodebuf;
  fdiMFldDspInfDef                  lfdiFldDspInf;
  memset(&stxmltransdsp,0x00,sizeof(xml_trans_dsp));
  memset(&stallxmlnodebuf,0x00,sizeof(AllXmlnodeBuf));
  memset(&lfdiFldDspInf,0x00,sizeof(fdiMFldDspInfDef));
	
  stallxmlnodebuf.nBufN = 0;
  memcpy(stxmltransdsp.comp_key ,"1",1);
  memcpy(stallxmlnodebuf.compkey,stxmltransdsp.comp_key,1);
  DbsXMLTRABSDSP( DBS_CURSOR, &stxmltransdsp);
  if(llResult = DbsXMLTRABSDSP( DBS_OPEN, &stxmltransdsp))
	{
		HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"DbsXMLTRABSDSP Error[%d]\n",llResult);
        return llResult;
	}
    while(DbsXMLTRABSDSP( DBS_FETCH, &stxmltransdsp) == 0) 
	{
		HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "xxxxxxxxxx[%ld]\n",stxmltransdsp.buf_index);
    if((liX = stallxmlnodebuf.nBufN++) >= xmlNMMaxBufDspN) {
			  DbsXMLTRABSDSP( DBS_CLOSE, &stxmltransdsp);
        return -1;
     } 
     if(llResult = nxmlPATnodebufLoad(
                         stxmltransdsp.usage_key,
                         stxmltransdsp.xml_index,
                         stxmltransdsp.buf_index,
                         &stallxmlnodebuf.stxmlnodebuf[liX])) 
     {
            DbsXMLTRABSDSP( DBS_CLOSE, &stxmltransdsp);
			   	  HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[%d]",liX);
            return llResult;
     } 
     stallxmlnodebuf.stxmlnodebuf[liX].usage_key = stxmltransdsp.usage_key;
     memcpy(stallxmlnodebuf.stxmlnodebuf[liX].txncode,stxmltransdsp.txn_number,strlen(stxmltransdsp.txn_number));
     stallxmlnodebuf.stxmlnodebuf[liX].bufid = stxmltransdsp.xml_index;
     HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[%d]",liX);
  }  
  DbsXMLTRABSDSP( DBS_CLOSE, &stxmltransdsp); 
  memcpy(vtpallxmlnodebuf,&stallxmlnodebuf,sizeof(*vtpallxmlnodebuf));
  return 0;
}

int PacksendxmlInit (int  nBufChgKey, AllXmlnodeBuf *vtpallxmlnodebuf)
{

	int				nReturnCode;	
	int       llResult;
	int       liX;

	long			lUsageKey;
  xml_trans_dsp                     stxmltransdsp;
  AllXmlnodeBuf                     stallxmlnodebuf;
  fdiMFldDspInfDef                  lfdiFldDspInf;
  memset(&stxmltransdsp,0x00,sizeof(xml_trans_dsp));
  memset(&stallxmlnodebuf,0x00,sizeof(AllXmlnodeBuf));
  memset(&lfdiFldDspInf,0x00,sizeof(fdiMFldDspInfDef));
 /*if(llResult = nMFldDspLoad(
                     nBufChgKey,
                     &lfdiFldDspInf)) {
        gbcipBufChgInf->nBufN = 0;
		    printf("nMFldDspLoad Error\n");
        return llResult;
    } */
  stallxmlnodebuf.nBufN = 0;
   memcpy(stxmltransdsp.comp_key ,"2",1);
   memcpy(stallxmlnodebuf.compkey,stxmltransdsp.comp_key,1);
  DbsXMLTRABSDSP( DBS_CURSOR, &stxmltransdsp);

  if(llResult = DbsXMLTRABSDSP( DBS_OPEN, &stxmltransdsp))
	{
		printf("DbsXMLTRABSDSP Error[%d]\n",llResult);
        return llResult;
	}


    while(DbsXMLTRABSDSP( DBS_FETCH, &stxmltransdsp) == 0) 
	{
    if((liX = stallxmlnodebuf.nBufN++) >= xmlNMMaxBufDspN) {
			  DbsXMLTRABSDSP( DBS_CLOSE, &stxmltransdsp);
			  
        return -1;
     } 
        
     if(llResult = nxmlCRTnodebufLoad(
                         stxmltransdsp.usage_key,
                         stxmltransdsp.xml_index,
                         stxmltransdsp.buf_index,
                         &stallxmlnodebuf.stxmlnodebuf[liX])) {
    

            return llResult;
        } 
    stallxmlnodebuf.stxmlnodebuf[liX].usage_key = stxmltransdsp.usage_key;
    memcpy(stallxmlnodebuf.stxmlnodebuf[liX].txncode,stxmltransdsp.txn_number,strlen(stxmltransdsp.txn_number));
    stallxmlnodebuf.stxmlnodebuf[liX].bufid = stxmltransdsp.xml_index;        
  } 
  DbsXMLTRABSDSP( DBS_CLOSE, &stxmltransdsp);
  memcpy(vtpallxmlnodebuf,&stallxmlnodebuf,sizeof(*vtpallxmlnodebuf));
  return 0;
}




int nxmlCRTnodebufLoad(
         int                          vlBufDspKey,  
         int                          vixmlindex,
         int                          viBufDspX,
         XmlnodeBuf*                 vsxmlnodebuf)
 {

    int                               liX,i;
    int                               llResult;
    char                               alXpath[100];
    tbl_xml_values                     stTblxmlValues;

    Tbl_fld_dsp_Def                    stflddspdef;
    Tbl_buf_dsp_Def                    stbufdspdef;
    memset(&stTblxmlValues,0x00,sizeof(stTblxmlValues));
    memset(&stflddspdef,0x00,sizeof(stflddspdef));
    memset(&stbufdspdef,0x00,sizeof(stbufdspdef));
    vsxmlnodebuf->nFldN = 0;
    stTblxmlValues.l_usage_key = vlBufDspKey;
    stTblxmlValues.i_buf_dsp_index = vixmlindex;
    DbsXMLVALUSEDSP( DBS_CURSOR, &stTblxmlValues);

    if(llResult = DbsXMLVALUSEDSP( DBS_OPEN, &stTblxmlValues))
        return llResult;

    while(DbsXMLVALUSEDSP( DBS_FETCH, &stTblxmlValues) == 0) 
	{
		if((liX = vsxmlnodebuf->nFldN++) >= xmlNMMaxNodeDspN)
		{
            DbsXMLVALUSEDSP( DBS_CLOSE, &stTblxmlValues);
            return -1;
    } 
     _xmTrim(&stTblxmlValues.sp_node_name);
    _xmTrim(&stTblxmlValues.sp_attribute_name1);
    _xmTrim(&stTblxmlValues.sp_attribute_test1);
    _xmTrim(&stTblxmlValues.sp_attribute_name2);
    _xmTrim(&stTblxmlValues.sp_attribute_test2);
    _xmTrim(&stTblxmlValues.sp_attribute_name3);
    _xmTrim(&stTblxmlValues.sp_attribute_test3);
    
    /* ���Ӹ��ڵ� */
   /* if(stTblxmlValues.father_node_id ==0)
       strcpy(alXpath,"/");
    else
    {
       strcpy(alXpath,"/");*/
       
       /*ȡ���ڵ�����*/
       memset(alXpath,0x00,sizeof(alXpath));
        if (stTblxmlValues.father_node_id == 0)
           	  memcpy(alXpath,&stTblxmlValues.sp_node_name,strlen(stTblxmlValues.sp_node_name));
          else
            getcrenodepath(&stTblxmlValues,alXpath); 
      _xmTrim(alXpath);
        
        memcpy(vsxmlnodebuf->stxmlnodeinf[liX].father_node_name,alXpath,strlen(alXpath));
		memcpy(vsxmlnodebuf->stxmlnodeinf[liX].nodepath,alXpath,strlen(alXpath));
		
		vsxmlnodebuf->stxmlnodeinf[liX].l_usage_key = stTblxmlValues.l_usage_key;
		vsxmlnodebuf->stxmlnodeinf[liX].i_buf_dsp_index = stTblxmlValues.i_buf_dsp_index;
		vsxmlnodebuf->stxmlnodeinf[liX].i_node_index = stTblxmlValues.i_node_index;
		vsxmlnodebuf->stxmlnodeinf[liX].father_node_id = stTblxmlValues.father_node_id;
	
		vsxmlnodebuf->stxmlnodeinf[liX].i_leaf_type = stTblxmlValues.i_leaf_type;
		vsxmlnodebuf->stxmlnodeinf[liX].i_fld_index = stTblxmlValues.i_fld_index;
		vsxmlnodebuf->stxmlnodeinf[liX].i_repeat_or = stTblxmlValues.i_repeat_or;
		vsxmlnodebuf->stxmlnodeinf[liX].i_attribute_num = stTblxmlValues.i_attribute_num;
		
		vsxmlnodebuf->stxmlnodeinf[liX].i_hold1_usr = stTblxmlValues.i_hold1_usr;
		memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_node_name , stTblxmlValues.sp_node_name,strlen(stTblxmlValues.sp_node_name));
	    memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_hold2_usr , stTblxmlValues.sp_hold2_usr,strlen(stTblxmlValues.sp_hold2_usr));
	    _xmTrim(stTblxmlValues.sp_attribute_name1);
	    _xmTrim(stTblxmlValues.sp_attribute_test1);
	    _xmTrim(stTblxmlValues.sp_attribute_name2);
	    _xmTrim(stTblxmlValues.sp_attribute_test2);
	    _xmTrim(stTblxmlValues.sp_attribute_name3);
	    _xmTrim(stTblxmlValues.sp_attribute_test3);
		memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_name1 ,stTblxmlValues.sp_attribute_name1,strlen(stTblxmlValues.sp_attribute_name1));
		memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_test1 ,stTblxmlValues.sp_attribute_test1,strlen(stTblxmlValues.sp_attribute_test1));
		memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_name2 ,stTblxmlValues.sp_attribute_name2,strlen(stTblxmlValues.sp_attribute_name2));
		memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_test2 ,stTblxmlValues.sp_attribute_test2,strlen(stTblxmlValues.sp_attribute_test2));
		memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_name3 ,stTblxmlValues.sp_attribute_name3,strlen(stTblxmlValues.sp_attribute_name3));
		memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_test3 ,stTblxmlValues.sp_attribute_test3,strlen(stTblxmlValues.sp_attribute_test3));
		
		
		
		stflddspdef.fld_id = stTblxmlValues.i_fld_index;
		stflddspdef.usage_key = 0;
		DbsFLDDSP(DBS_SELECT,&stflddspdef);
		vsxmlnodebuf->stxmlnodeinf[liX].nFldL = stflddspdef.fld_l;
		vsxmlnodebuf->stxmlnodeinf[liX].nFldType = stflddspdef.fld_type;	
		
		stbufdspdef.usage_key = 1;		
		stbufdspdef.buf_dsp_index = viBufDspX;
		stbufdspdef.fld_index = stTblxmlValues.i_fld_index;
		DbsBUFDSP(DBS_SELECT,&stbufdspdef);		
		vsxmlnodebuf->stxmlnodeinf[liX].nOffset = stbufdspdef.fld_offset;
		memset(&stTblxmlValues,0x00,sizeof(stTblxmlValues));
		memset(&stflddspdef,0x00,sizeof(stflddspdef));
        memset(&stbufdspdef,0x00,sizeof(stbufdspdef));
		HtLog ("XMLpacksend.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nodepath[%s]",vsxmlnodebuf->stxmlnodeinf[liX].nodepath);
  } /* end of while */
    
   if(llResult = DbsXMLVALUSEDSP( DBS_CLOSE, &stTblxmlValues))
        return llResult;

    return 0;
} 


int nxmlPATnodebufLoad(
         int                          vlBufDspKey,
         int                          vixmlindex,
         int                          viBufDspX,
         XmlnodeBuf*                 vsxmlnodebuf)
 {

    int                               liX, i;
    int                               llResult;
    char                               alXpath[100];
    tbl_xml_values                     stTblxmlValues;

    Tbl_fld_dsp_Def                    stflddspdef;
    Tbl_buf_dsp_Def                    stbufdspdef;
    memset(&stTblxmlValues,0x00,sizeof(stTblxmlValues));
		memset(&stflddspdef,0x00,sizeof(stflddspdef));
    memset(&stbufdspdef,0x00,sizeof(stbufdspdef));

    vsxmlnodebuf->nFldN = 0;
    stTblxmlValues.l_usage_key = vlBufDspKey;
     stTblxmlValues.i_buf_dsp_index = vixmlindex;     
    DbsXMLVALUSEDSP( DBS_CURSOR, &stTblxmlValues);
    HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
    "i_buf_dsp_index[%ld]--l_usage_key[%ld]",stTblxmlValues.i_buf_dsp_index,stTblxmlValues.l_usage_key);    
    if(llResult = DbsXMLVALUSEDSP( DBS_OPEN, &stTblxmlValues))
    {
        HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "DBS_OPENllResult:%d",llResult);
        return llResult;
    }
    while(1) 
	  {
	  	 memset(&stTblxmlValues,0x00,sizeof(stTblxmlValues));
	     memset(&stflddspdef,0x00,sizeof(stflddspdef));
       memset(&stbufdspdef,0x00,sizeof(stbufdspdef));
	  	 llResult = DbsXMLVALUSEDSP( DBS_FETCH, &stTblxmlValues) ;	  	 
	  	 if(llResult && llResult !=100)
	  	   return -1;
	  	 else if (llResult ==100)
	  	   break;
	  	 else
	  	 {

		      if((liX = vsxmlnodebuf->nFldN++) >= xmlNMMaxNodeDspN)
		      {
                  DbsXMLVALUSEDSP( DBS_CLOSE, &stTblxmlValues);
                  return -1;
               } 
           _xmTrim(&stTblxmlValues.sp_node_name);
          _xmTrim(&stTblxmlValues.sp_attribute_name1);
          _xmTrim(&stTblxmlValues.sp_attribute_test1);
          _xmTrim(&stTblxmlValues.sp_attribute_name2);
          _xmTrim(&stTblxmlValues.sp_attribute_test2);
          _xmTrim(&stTblxmlValues.sp_attribute_name3);
          _xmTrim(&stTblxmlValues.sp_attribute_test3);
          
          /* ���Ӹ��ڵ� */
          
          /*strcpy(alXpath,"/"); */
           /*ȡ���ڵ�����*/
               memset(alXpath,0x00,sizeof(alXpath));
           if (stTblxmlValues.father_node_id == 0)
           	  memcpy(alXpath,&stTblxmlValues.sp_node_name,strlen(stTblxmlValues.sp_node_name));
          else
             getparnodepath(&stTblxmlValues,alXpath);  
           _xmTrim(alXpath);   
          /*i = strlen(alXpath);
          alXpath[i-1]='\0'; */

              memcpy(vsxmlnodebuf->stxmlnodeinf[liX].father_node_name,alXpath,sizeof(alXpath));
		      memcpy(vsxmlnodebuf->stxmlnodeinf[liX].nodepath,alXpath,sizeof(alXpath));
		      
		      vsxmlnodebuf->stxmlnodeinf[liX].l_usage_key = stTblxmlValues.l_usage_key;
		      vsxmlnodebuf->stxmlnodeinf[liX].i_buf_dsp_index = stTblxmlValues.i_buf_dsp_index;
		      vsxmlnodebuf->stxmlnodeinf[liX].i_node_index = stTblxmlValues.i_node_index;
		      vsxmlnodebuf->stxmlnodeinf[liX].father_node_id = stTblxmlValues.father_node_id;
	        
		      vsxmlnodebuf->stxmlnodeinf[liX].i_leaf_type = stTblxmlValues.i_leaf_type;
		      vsxmlnodebuf->stxmlnodeinf[liX].i_fld_index = stTblxmlValues.i_fld_index;
		      vsxmlnodebuf->stxmlnodeinf[liX].i_repeat_or = stTblxmlValues.i_repeat_or;
		      vsxmlnodebuf->stxmlnodeinf[liX].i_attribute_num = stTblxmlValues.i_attribute_num;
		      
		      vsxmlnodebuf->stxmlnodeinf[liX].i_hold1_usr = stTblxmlValues.i_hold1_usr;
		      memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_node_name , stTblxmlValues.sp_node_name,sizeof(stTblxmlValues.sp_node_name));
	          memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_hold2_usr , stTblxmlValues.sp_hold2_usr,sizeof(stTblxmlValues.sp_hold2_usr));
		      memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_name1 ,stTblxmlValues.sp_attribute_name1,strlen(stTblxmlValues.sp_attribute_name1));
		      memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_test1 ,stTblxmlValues.sp_attribute_test1,strlen(stTblxmlValues.sp_attribute_test1));
		      memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_name2 ,stTblxmlValues.sp_attribute_name2,strlen(stTblxmlValues.sp_attribute_name2));
		      memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_test2 ,stTblxmlValues.sp_attribute_test2,strlen(stTblxmlValues.sp_attribute_test2));
		      memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_name3 ,stTblxmlValues.sp_attribute_name3,strlen(stTblxmlValues.sp_attribute_name3));
		      memcpy(vsxmlnodebuf->stxmlnodeinf[liX].sp_attribute_test3 ,stTblxmlValues.sp_attribute_test3,strlen(stTblxmlValues.sp_attribute_test3));
		      		      
		      
		      stflddspdef.fld_id = stTblxmlValues.i_fld_index;
		      stflddspdef.usage_key = 0;
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "l_usage_key[%d]",stTblxmlValues.l_usage_key);
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "stTblxmlValues.i_fld_index[%d]",stTblxmlValues.i_fld_index);
		      DbsFLDDSP(DBS_SELECT,&stflddspdef);
		      vsxmlnodebuf->stxmlnodeinf[liX].nFldL = stflddspdef.fld_l;
		      vsxmlnodebuf->stxmlnodeinf[liX].nFldType = stflddspdef.fld_type;	
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "stflddspdef.fld_l[%d]",stflddspdef.fld_l);
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "stflddspdef.fld_type[%d]",stflddspdef.fld_type);
		      
		      stbufdspdef.usage_key = 1;		      
		      stbufdspdef.buf_dsp_index = viBufDspX;
		       HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "viBufDspX[%d]",stbufdspdef.buf_dsp_index);
		      stbufdspdef.fld_index = stTblxmlValues.i_fld_index;
		      DbsBUFDSP(DBS_SELECT,&stbufdspdef);		
		      vsxmlnodebuf->stxmlnodeinf[liX].nOffset = stbufdspdef.fld_offset;
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "11i_fld_index[%d]",stTblxmlValues.i_fld_index);
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "22fld_offset[%d]",stbufdspdef.fld_offset);
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "fld_index[%d]",stbufdspdef.fld_index);
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nOffset[%d]",vsxmlnodebuf->stxmlnodeinf[liX].nOffset);
		      HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nodepath[%s]",vsxmlnodebuf->stxmlnodeinf[liX].nodepath);
		    }
    } /* end of while */
       
    if(llResult = DbsXMLVALUSEDSP( DBS_CLOSE, &stTblxmlValues))
       return llResult;

    return 0;
} 


int getcrenodepath(tbl_xml_values *stTblxmlValues, char *alXpath)
 {   
   int nodeindex;
   int llResult;
   tbl_xml_values lopcreltXmlValues;
   memset(&lopcreltXmlValues,0x00,sizeof(lopcreltXmlValues));
   memcpy(&lopcreltXmlValues,stTblxmlValues,sizeof(lopcreltXmlValues) );
    if(llResult = DbsXMLVALUSEDSP( DBS_CRTSELECT, &lopcreltXmlValues))
        return llResult;                  
    /*nodeindex  = lopcreltXmlValues.father_node_id ;*/ 
    _xmTrim(lopcreltXmlValues.sp_node_name);
    memcpy(alXpath,lopcreltXmlValues.sp_node_name,strlen(lopcreltXmlValues.sp_node_name));  
    HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "getpath[%s]\n",lopcreltXmlValues.sp_node_name);
   /*if(nodeindex !=0 )
      getcrenodepath(&lopcreltXmlValues,alXpath);
    
    strcat(alXpath,lopcreltXmlValues.sp_node_name);  
    strcat(alXpath,"/");  */ 
   return 0;          
 }

int getparnodepath(tbl_xml_values *stTblxmlValues, char *alXpath)
 {

   
   int i =0;
   int nodeindex;
   int llResult;
   tbl_xml_values lopparltXmlValues;
   memset(&lopparltXmlValues,0x00,sizeof(lopparltXmlValues));
   memcpy(&lopparltXmlValues,stTblxmlValues,sizeof(lopparltXmlValues) );
    if(llResult = DbsXMLVALUSEDSP( DBS_PARSELECT, &lopparltXmlValues))
        return llResult;                  
    /* nodeindex  = lopparltXmlValues.father_node_id ; */
    _xmTrim(lopparltXmlValues.sp_node_name);
    HtLog ("XMLBridge.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "getpath[%s]\n",lopparltXmlValues.sp_node_name);
   /*if(nodeindex !=0 )
      getparnodepath(&lopparltXmlValues,alXpath);*/
    memcpy(alXpath,lopparltXmlValues.sp_node_name,strlen(lopparltXmlValues.sp_node_name));
   /*strcat(alXpath,lopparltXmlValues.sp_node_name);*/  
   /*strcat(alXpath,"/");   */
   return 0;                   
 }
