#include "public.h"
#include "mcis.h"

/*����ԭ��*/
int swConnectser(char *aIp,int iPort);
int swTcprcv(int iSockfd,char *aBuffer,int *piLength);
int swTcpconnect( int iPort );
int swTcpsnd(int iSockfd,char *aBuffer,int iLen);
int swReadn(int iSockfd, char *aBuffer,int iLength);
int swConnsend(int iflag,int *iSockfd, char *aMsgbuf,int iMsglen);
int swSiginit();

int swSiginit()
{
	int	i;
	
	for ( i=0; i<63; i++ )
		signal(i,SIG_IGN);
	return(0);
}

int TcpSndRcvMsg(char *ip_addr,int iPort,char *aMsgbuf,int iMsglen,char *aRcvmsg,int *iRcvlen)
{
	int	ilRc;
	int	iSockfd;
	socklen_t  ilAddrlen;
	struct	linger slLinger;
	struct	sockaddr_in slCli_addr;
	
	/*�����������������*/
	iSockfd = swConnectser( ip_addr, iPort );
	if (iSockfd < 0) 
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swChek_comm() errno=%d[%s]",errno,strerror(errno));
		return(-1);
	}
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"���ӵ��������ɹ�");  
	ilAddrlen = sizeof(struct sockaddr_in);
	memset ((char *)&slCli_addr, 0, sizeof(struct sockaddr_in));
	
	ilRc = getsockname(iSockfd,(struct sockaddr*)&slCli_addr,&ilAddrlen);
	if ( ilRc == -1 )
	{  
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"read socket errno=%d[%s]",errno,strerror(errno));
		close(iSockfd);
		return(-1);
	}
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"getsockname SUCCESS");
	
	slLinger.l_onoff = 1 ;
	slLinger.l_linger = 1 ;
	
	ilRc = setsockopt(iSockfd,SOL_SOCKET,SO_LINGER,&slLinger,sizeof(struct linger));
	if ( ilRc ) 
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"Connected errno=%d[%s]",errno, strerror(errno));
		close(iSockfd);
		return(-1); 
	}
	
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"���ӵ�������{%s}�Ķ˿�[%d]�ɹ�",ip_addr,iPort);
	       
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"���ͱ��ĵ�������...");
	ilRc = swTcpsnd(iSockfd,aMsgbuf,iMsglen);   
	if ( ilRc < 0 ){
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"���ͱ��ĵ�������ʧ��");
		close(iSockfd);
		return(-1);
	}
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"�ȴ����յ�����������Ӧ��Ϣ");
	aRcvmsg[0] = 0x0;
	*iRcvlen = 0;
	ilRc = swTcprcv(iSockfd,aRcvmsg,iRcvlen);
	if ( ilRc )
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"���յ�����������Ӧ��Ϣʧ��");
		close(iSockfd);
		return(-1);
	}
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"���յ�����������Ӧ��Ϣ�ɹ�,���ĳ�����%d",*iRcvlen);
	close(iSockfd);
	return(0);
}


int swConnectser(char *aIp,int iPort)
{
	struct sockaddr_in slServ_addr;
	
	int ilSockfd;
	int ilRc;
	
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swConnetser()");
	/* create endpoint */
	if ((ilSockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__," socket()���� F[%s]:L[%d]:Connect Server Error",__FILE__,__LINE__);
		HtLog("xmlcli.log", 2,__FILE__,__LINE__," socket()���� Connect Server Error errno=%d[%s]",errno,strerror(errno));
		return -1;
	}
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"[%d]",iPort);
	
	slServ_addr.sin_family = AF_INET;
	slServ_addr.sin_addr.s_addr = inet_addr( aIp );
	slServ_addr.sin_port = htons( iPort );
	
	ilRc = connect(ilSockfd,(struct sockaddr *)&slServ_addr,sizeof(slServ_addr));
	if (ilRc < 0)
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"connect()����,F[%s]:L[%d]:Connect Server Error",__FILE__,__LINE__);
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"connect()����,Connect Server Error Code[%d]--%s",errno,strerror(errno));
		close(ilSockfd);
		return -1;
	}
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swConnectser()������=%d",ilSockfd);
	return ilSockfd;
}
 
int swTcprcv(int iSockfd,char *aBuffer,int *piLength)
{
	int	ilRc = -1;
	int	ilRcvlen=0;
	int	ilLength=0;
	char	alLen[20];
	
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swTcprcv()");
	/* ���ݳ��ȱ���ʽ��ȡ���� */
	ilRc = swReadn(iSockfd,alLen,5);
	if (ilRc)
	{
	  HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swReadn()��������,������=%d",ilRc);
	  return(-1);
	}
	alLen[5] = '\0';
	ilRcvlen = atoi(alLen);
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"rcv_len=%d",ilRcvlen);
	if(ilRcvlen > iMSGMAXLEN-1)
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"���ĳ��ȳ����������, ilRcvlen=%d",ilRcvlen);
		return(-1);
	}
		
	
	ilRc=swReadn(iSockfd,aBuffer,ilRcvlen);
	if ( ilRc )
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swReadn()����,������=%d",ilRc);
		return(-1);
	}
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"rcv_len=%d",ilRcvlen);
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"rcv_buff=%s",aBuffer);
	
	*piLength = ilRcvlen;
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swTcprcv()������=0");
    return(0);
}



int swReadn(int iSockfd, char *aBuffer,int iLength)
{
	int	ilLen = 0;
	int	ilTotalcnt=0;
	
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swReadn(),read_len=%d",iLength);
	for(;;)
	{
		ilLen = read(iSockfd, aBuffer+ilTotalcnt,iLength-ilTotalcnt);
		if (ilLen<0) 
		{
			if (errno==EINTR)
			{
				continue;
			}
			HtLog("xmlcli.log", 2,__FILE__,__LINE__,"read()��������,errno=%d[%s]",errno,strerror(errno));
			return(-1);
		}
		if (ilLen==0)
		{
			HtLog("xmlcli.log", 2,__FILE__,__LINE__,"read()�����ձ���");
			return(-1);
		}
		ilTotalcnt=ilTotalcnt+ilLen;
		if (ilTotalcnt >= iLength)
		{
			HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swReadn()������=0");
		 	return(0);
		}
	}
	return(0);
}


int swTcpsnd(int iSockfd,char *aBuffer,int iLen)
{
	int	ilSendlen = 0;
	int	ilCount= 0;
	
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swTcpsend()");
	for (;;)
	{
		ilSendlen = write(iSockfd,aBuffer+ilCount,iLen-ilCount);
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"ilSendlen=%d",ilSendlen);
		if (ilSendlen < 0)
		{
			if (errno==EINTR)
			{
				ilSendlen = 0;
				continue;
			}
			else
			{
				HtLog("xmlcli.log", 2,__FILE__,__LINE__,"write()��������,errno=%d[%s]",errno,strerror(errno));
				return(-1);
	  		}
		}
		if (ilSendlen == 0)
		{
			HtLog("xmlcli.log", 2,__FILE__,__LINE__,"write()���������ֽ���Ϊ0");
			return(-1);
		}
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"write() SUCCESS");
		ilCount=ilCount+ilSendlen;
		if (ilCount >= iLen) 
		{
			HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swTcpsend()������=0");
			return(0);
		}
	}
	return(0);
}

int swTcpconnect( int iPort )
{
	struct 	sockaddr_in slServ_addr;
	int 	ilSockid;
	int 	ilRc;
	
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swTcpconnect(%d)",iPort);
	memset((char *)&slServ_addr,0x00,sizeof(struct sockaddr_in));
	
	slServ_addr.sin_family = AF_INET;
	slServ_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	slServ_addr.sin_port = htons(iPort);
	ilSockid=socket(AF_INET,SOCK_STREAM,0);
	if (ilSockid==-1)
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"socket()����,����SOCKET����,errno=%d[%s]",errno,strerror(errno));
		return(-1);
	}
	ilRc=bind(ilSockid,(struct sockaddr*)&slServ_addr,sizeof(struct sockaddr_in));
	if (ilRc == -1)
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"bind()����,��SOCKET����,errno=%d[%s]",errno,strerror(errno));
		close(ilSockid);
		return(-1);
	}
	
	if (listen(ilSockid,SOMAXCONN)==-1)
	{
		HtLog("xmlcli.log", 2,__FILE__,__LINE__,"listen()����,�������Ӵ���,errno=%d[%s]",errno,strerror(errno));
		close(ilSockid);
		return(-1);
	}
	HtLog("xmlcli.log", 2,__FILE__,__LINE__,"swTcpconnect()������=%d",ilSockid);
	return(ilSockid);
}
