#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <math.h>
#include <memory.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <ctype.h>
#include <malloc.h>
#include <libgen.h>
#include <sys/signal.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>

#include <sys/timeb.h>
#include <sys/time.h>
#include <sys/times.h>

#define SUCCESS 0
#define FAIL    1
#define ixxMSGMAXLEN 1024

char    agDebugfile[100];
int     cgDebug;
int	DB_conn_flag;
char	agTest[244+1];

