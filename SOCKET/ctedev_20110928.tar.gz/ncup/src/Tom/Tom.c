/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Tom.c                                                    */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include "Tom.h"

typedef struct {
    char            inst_date       [   9];
    char            inst_time       [   7];
    char            msg_src_id      [   5];
    char            msg_dst_id      [   5];
    char            txn_num         [   5];
    char            trans_date_time [  11];
    char            sys_seq_num     [   7];
    char            key_rsp         [  49];
    char            revsal_flag     [   2];
    char            proc_seq_id     [   3];
} tbl_txn_log_tom;

char                gsSrvId[SRV_ID_LEN+1];
char                gsObjSrvId[SRV_ID_LEN+1];
char                gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char                gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq            gatSrvMsq[SRV_MSQ_NUM_MAX];
char                glcurrMonitorTime [27];               /* ��ص�ʱ�� */
char                gllastMonitorTime [27];               /* �ϴμ�ص�ʱ�� */
long                glInitMonitorTime = 0;               /* ��ʼʱ�� */
long                glMonitorInterval = 1;               /* ���ʱ�� */
int                 gnDoneItems = 0;         

void HandleExit(int);
int TomInit(short argc, char **argv);
void tomProcess();

int main(int argc, char **argv)
{
    char   sMsgBuf[MSQ_MSG_SIZE_MAX];
    int    nReturnCode;
    long   lBeginTime, lEndTime;
    struct tms        tTMS;
    memset(glcurrMonitorTime,0,sizeof(glcurrMonitorTime));
    memset(gllastMonitorTime,0,sizeof(gllastMonitorTime));
    nReturnCode = TomInit(argc, argv);
    if (nReturnCode) {
    
    HtLog("TOM.LOG", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Tom started.");
      printf("Tom: TomInit error %d\n", nReturnCode);
        exit (-1);
    }

    sigset(SIGTERM, HandleExit);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Tom started.");
    lBeginTime = lEndTime = 0;

    while (1)
    {
        HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "----while begin----");
        
        lBeginTime = times(&tTMS);
        gnDoneItems = 0;
        tomProcess();
        lEndTime = times(&tTMS);
        HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "tomProcess processed, used %ld ticks", 
              lEndTime - lBeginTime);
        if (lEndTime != lBeginTime)
        {
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "rate(%d/%d) = %d items",
                  gnDoneItems, lEndTime - lBeginTime, gnDoneItems/(lEndTime - lBeginTime));     
         }
        
        sleep(glMonitorInterval);
        HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "----while end ----");
    }
}

void tomSendTimeOutTxn(tbl_txn_log_tom* ptTblTxnLogTom)
{
    int             iRet;
    T_SwtToReqDef   tSwtToReq;
   
    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "toSendTimeOutTxn begin");
    memset(&tSwtToReq, 0, sizeof(tSwtToReq));
    tSwtToReq.lRtnMsgType = 1;
    memcpy(tSwtToReq.sTxnDate, ptTblTxnLogTom->trans_date_time, F007_LEN);
    memcpy(tSwtToReq.sSysSeqNum, ptTblTxnLogTom->sys_seq_num, FLD_SYS_SEQ_NUM_LEN); 
    memcpy(tSwtToReq.sToReserved, REASON_CODE_TIME_OUT, 4);
    memcpy(tSwtToReq.sToReserved + 4, ptTblTxnLogTom->msg_src_id, SRV_ID_LEN);
    memcpy(tSwtToReq.sToReserved + 4 + SRV_ID_LEN, ptTblTxnLogTom->msg_dst_id, SRV_ID_LEN);
    memcpy(tSwtToReq.sToReserved + 4 + 2 * SRV_ID_LEN, ptTblTxnLogTom->txn_num, FLD_TXN_NUM_LEN);
    memcpy(tSwtToReq.sSrcSrvId, SRV_ID_TOCTL, SRV_ID_LEN);
    memcpy(tSwtToReq.sSrvId, ptTblTxnLogTom->msg_dst_id, SRV_ID_LEN);
    
    iRet = MsqSnd(tSwtToReq.sSrvId, gatSrvMsq, 0, sizeof(tSwtToReq), (char *)&tSwtToReq);   
    if (iRet) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "MsqSnd error: %d", iRet);
    }
}
 
void tomProcess()
{
    int iRet ;
    int ireno=0;
    long tmpMonitorTime =0;
    tbl_txn_log_tom  tTblTxnLogTomDef;
    char timelast[100]={0};
    /*���ü�ص�ʱ������*/
    char timecurt[100]={0};
    if (0 == atol(glcurrMonitorTime)) {
        /*��ص�һ��ʹ�õļ������*/
         tmpMonitorTime -= glInitMonitorTime;
         GetDBoutTime( tmpMonitorTime,glcurrMonitorTime ,gllastMonitorTime);
    } else {
        /*���μ���������Сʱ������*/
        memcpy(gllastMonitorTime,glcurrMonitorTime,strlen(glcurrMonitorTime));
    }
    /*glcurrMonitorTime = time(NULL);*/
   GetDBoutTime( 0,glcurrMonitorTime ,glcurrMonitorTime);

    /*strftime(timelast, sizeof(timecurt), "%Y-%m-%d %H:%M:%S",
             localtime((time_t*)(&gllastMonitorTime )));
             
    strftime(timecurt, sizeof(timecurt), "%Y-%m-%d %H:%M:%S",
             localtime((time_t*)(&glcurrMonitorTime )));*/

    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
              "gllastTime time: %s",gllastMonitorTime);

    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
              "timecurt time: %s",glcurrMonitorTime);
    
   /* HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
          "gllastMonitorTime: [%ld], glcurrMonitorTime: [%ld]",
          gllastMonitorTime, glcurrMonitorTime);*/ 
   
    memset(&tTblTxnLogTomDef, 0, sizeof(tTblTxnLogTomDef));
    sprintf(tTblTxnLogTomDef.proc_seq_id, "%1.1d%1.1d", atoi(gsSrvSeqId),atoi(getenv(SRV_USAGE_KEY)));
    
        DbsTomTblTxnLogA(DBS_CURSOR, &tTblTxnLogTomDef);
        iRet = DbsTomTblTxnLogA(DBS_OPEN, &tTblTxnLogTomDef);
        if (iRet && ((ireno=DbsConnect()) == 0))
       {
       	    
            DbsTomTblTxnLogA(DBS_CURSOR, &tTblTxnLogTomDef);
            iRet = DbsTomTblTxnLogA(DBS_OPEN, &tTblTxnLogTomDef);
        } 
        if (iRet)
       { 
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
                  "DbsTomTblTxnLogA DBS_OPEN error: [%d]", iRet);
            DbsRollback();
            return;
        } 
        while (1)
        {
            memset(&tTblTxnLogTomDef, 0, sizeof(tTblTxnLogTomDef));
            iRet = DbsTomTblTxnLogA(DBS_FETCH, &tTblTxnLogTomDef);
            if (DBS_NOTFOUND == iRet)
                break;  
            if (iRet) {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                      "DbsTomTblTxnLogA DBS_FETCH error: [%d]", iRet);
                DbsTomTblTxnLogA(DBS_CLOSE, &tTblTxnLogTomDef);                
                DbsRollback();
                return; 
            }
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
                  "TimeOut Txn: [%s] [%s] [%s]", tTblTxnLogTomDef.inst_date,
                  tTblTxnLogTomDef.inst_time, tTblTxnLogTomDef.sys_seq_num);
            DbsBegin();
            iRet = DbsTomTblTxnLogA(DBS_UPDATE, &tTblTxnLogTomDef);
            if (iRet) {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                      "DbsTomTblTxnLogA DBS_UPDATE error: [%d]", iRet);
                DbsTomTblTxnLogA(DBS_CLOSE, &tTblTxnLogTomDef);
                DbsRollback();
                return; 
            }
            iRet = DbsCommit();
            if (iRet) {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                      "DbsCommit error: [%d]", iRet);
                DbsTomTblTxnLogA(DBS_CLOSE, &tTblTxnLogTomDef);
                DbsRollback();
                return;
            }
            if (tTblTxnLogTomDef.revsal_flag[0] == '0')
                tomSendTimeOutTxn(&tTblTxnLogTomDef);
            ++gnDoneItems;
        }
        iRet = DbsCommit();
        if (iRet) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                  "DbsCommit error: [%d]", iRet);
            DbsTomTblTxnLogA(DBS_CLOSE, &tTblTxnLogTomDef);
            DbsRollback();
            return;
        }
        DbsTomTblTxnLogA(DBS_CLOSE, &tTblTxnLogTomDef); 
 

    memset(&tTblTxnLogTomDef, 0, sizeof(tTblTxnLogTomDef));
    sprintf(tTblTxnLogTomDef.proc_seq_id, "%02ld", atol(gsSrvSeqId)); 
    DbsTomTblAuthTxnLog(DBS_CURSOR, &tTblTxnLogTomDef);
    iRet = DbsTomTblAuthTxnLog(DBS_OPEN, &tTblTxnLogTomDef);
    if (iRet && ((ireno=DbsConnect()) == 0)) {
        DbsTomTblAuthTxnLog(DBS_CURSOR, &tTblTxnLogTomDef);
        iRet = DbsTomTblAuthTxnLog(DBS_OPEN, &tTblTxnLogTomDef); 
    }
    if (iRet) {    
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
              "DbsTomTblAuthTxnLog DBS_OPEN error: [%d]", iRet);
        DbsRollback();
        return;
    }
    while (1) {
        memset(&tTblTxnLogTomDef, 0, sizeof(tTblTxnLogTomDef));
        iRet = DbsTomTblAuthTxnLog(DBS_FETCH, &tTblTxnLogTomDef);
        if (DBS_NOTFOUND == iRet)
            break;
        if (iRet) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                  "DbsTomTblAuthTxnLog DBS_FETCH error: [%d]", iRet);
            DbsTomTblAuthTxnLog(DBS_CLOSE, &tTblTxnLogTomDef);
            DbsRollback();
            return; 
        }
        HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "TimeOut Txn: [%s] [%s] [%s]", tTblTxnLogTomDef.inst_date,
              tTblTxnLogTomDef.inst_time, tTblTxnLogTomDef.sys_seq_num);
        DbsBegin();
        iRet = DbsTomTblAuthTxnLog(DBS_UPDATE, &tTblTxnLogTomDef);
        if (iRet) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                  "DbsTomTblAuthTxnLog DBS_UPDATE error: [%d]", iRet);
            DbsTomTblAuthTxnLog(DBS_CLOSE, &tTblTxnLogTomDef);
            DbsRollback();
            return;
        }
        iRet = DbsCommit();
        if (iRet) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
                  "DbsCommit error: [%d]", iRet);
            DbsTomTblAuthTxnLog(DBS_CLOSE, &tTblTxnLogTomDef);
            DbsRollback();
            return;
        }
        if (tTblTxnLogTomDef.revsal_flag[0] == '0')
            tomSendTimeOutTxn(&tTblTxnLogTomDef);
        ++gnDoneItems;
    }
    iRet = DbsCommit();
    if (iRet) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
              "DbsCommit error: [%d]", iRet);
        DbsTomTblAuthTxnLog(DBS_CLOSE, &tTblTxnLogTomDef);
        DbsRollback();
        return;
    }
    DbsTomTblAuthTxnLog(DBS_CLOSE, &tTblTxnLogTomDef);
}
                                                                

/*****************************************************************************/
/* FUNC:   int TomInit ( );                                                  */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ʼ��ϵͳ��̬����,����,������Ϣ��                                */
/*****************************************************************************/
int TomInit (short argc, char **argv)
{
    char            *pnInitTime;
    int             nReturnCode;
    long            lUsageKey;
    Tbl_srv_inf_Def tTblSrvInf;

    HtLog("Tom.log", HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "Begin" );
    /* get server id, arg 1 */
    strcpy(gsSrvId, argv[1]);
    strcpy(gsSrvSeqId, argv[2]);
    strcpy(gsObjSrvId, argv[3]);

    HtLog("Tom.log", HT_LOG_MODE_ERROR, __FILE__, __LINE__, "TOM param:, %s:%s:%s",gsSrvId,gsSrvSeqId,gsObjSrvId);
    if (getenv(SRV_USAGE_KEY))
    {
        lUsageKey=atoi(getenv(SRV_USAGE_KEY));
    }
   else
    {  
     
         HtLog("Tom.log", HT_LOG_MODE_ERROR, __FILE__, __LINE__, "TOM srv_useage_key env err","-1");
        return -1;
    }
    /* connect to database */
    nReturnCode = DbsConnect();
    if (nReturnCode)
        return (nReturnCode);

    /* get log file name from tbl_srv_inf */
    memset((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy(tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nReturnCode) {
        DbsDisconnect();
        return (nReturnCode);
    }
    CommonRTrim(tTblSrvInf.srv_name);
    sprintf(gsLogFile, "%s.%s.log", tTblSrvInf.srv_name, gsSrvSeqId);

    /* init Monitor Init Time */
    pnInitTime = getenv(ENV_TOM_INIT_TIME);
    if (NULL == pnInitTime) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "getenv INIT_MONITOR_TIME error, %d", errno);
        return -1;
    }
    glInitMonitorTime = atol(pnInitTime);
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "glInitMonitorTime: [%ld]", glInitMonitorTime);
          
    /* init Monitor Interval Time */ 
    pnInitTime = getenv(ENV_TOM_INTERVAL_TIME);
    if (NULL != pnInitTime) {
        glMonitorInterval = atol(pnInitTime);
    }
    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "glMonitorInterval: [%ld]", glMonitorInterval);
   
    /* init msg queue */
    memset((char *)gatSrvMsq, 0, SRV_MSQ_NUM_MAX * sizeof (T_SrvMsq));
    nReturnCode = MsqInit(gsSrvId, gatSrvMsq);
    if (nReturnCode) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "MsqInit error, %d.", nReturnCode);
        DbsDisconnect();
        return (nReturnCode);
    }
  
    return 0;
}

void HandleExit (int n)
{
    DbsDisconnect ();
    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Tom exits.");
    exit(1);
}
