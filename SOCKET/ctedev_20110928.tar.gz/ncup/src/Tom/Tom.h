#ifndef _TOM_H
#define _TOM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/times.h>
#include "HtLog.h"
#include "SrvDef.h"
#include "MsqOpr.h"
#include "db.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "IpcInt.h"
#include "ToOpr.h"
#include <signal.h> 

#define SRV_USAGE_KEY           "SRV_USAGE_KEY"  
#define ENV_TOM_INIT_TIME       "INIT_MONITOR_TIME"    /* ��ʼ���ʱ�� */
#define ENV_TOM_INTERVAL_TIME   "INIT_INTERVAL_TIME"   /* ɨ����ʱ�� */
#define ENV_TOM_INST_CD         "APS_INST_CD"          /* ͨ���������� */  


#endif       


