cd $FEHOME/src/hsmSrc
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Common
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Dbs
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/CstDbs
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Convert
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Cust
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Bridge
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Manage
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SwtBDT
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SwtTDB
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SwtBDB
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/PackSend
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SavFwd
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/ToCtl
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Dumpmsg
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Daemon
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCups
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommZK
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommPCS
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComPosp
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/C003
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommCB
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommCC
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommCon
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Tool/
make -f T001.mak clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Tool/
make -f T003.mak clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/HsmSrv/
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Tool/TPwd/
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Tom/
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/MngTxn/
make clean all
if [ $? -ne 0 ];then
  exit 1
fi
