#include "hsmsrv.h"

char 		sResult[100];
T_STRING 	operate_buf, response_buf;
char 		hsm56_response_code[2], err_code[2];
extern int	trace_level,log_level;
extern int	iSocketID;


int hsm56_cmd(T_STRING * p_operate_buf, T_STRING * p_response_buf)
{
	int ret;
 
	HsmTrace(logfile,trace_level,p_operate_buf->str_content,
			p_operate_buf->str_len,__FILE__,__LINE__);

	if( (ret = Send2HSM( iSocketID,
				p_operate_buf->str_content,
				p_operate_buf->str_len )) != p_operate_buf->str_len )
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm56_SndRcv:Send2HSM %d!", ret);
		CloseSocket(iSocketID);
		exit(0);
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsm56_SndRcv:Send2HSM OK!");

	ret = Recv4HSM( iSocketID, sResult, 300 );
	if(ret<= 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsm56_SndRcv:Recv4HSM error!" );
		CloseSocket(iSocketID);
		exit(0);
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsm56_SndRcv:Recv4HSM OK! len %d",ret);

	p_response_buf->str_len = ret;
	memcpy(p_response_buf->str_content, sResult, ret);

	HsmTrace(logfile,trace_level, p_response_buf->str_content,
			p_response_buf->str_len, __FILE__,__LINE__);
	
    return HSM_SUCCESS;
} 

int hsm56_SndRcv(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn) 
{
	int iResult;

	switch(hsmMsgIn->hsmOpr.saOprType)
	{
		case HSM_TEST:
			iResult = hsm56_Test(hsmSourKey,
								hsmDestKey,
								hsmMsgIn);
			break;

		case HSM_TRANSPIN:
			iResult = hsm56_TransPin(	hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_GENMAC:
			iResult = hsm56_GenMac(	hsmSourKey,
									hsmDestKey,
									hsmMsgIn);
			break;

		case HSM_VERIFYMAC:
			iResult = hsm56_VerifyMac(hsmSourKey,
									hsmDestKey,
									hsmMsgIn);
			break;

		case HSM_GENMACWITHKEY:
			iResult = hsm56_GenMacWithKey(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_VERIFYMACWITHKEY:
			iResult = hsm56_VerifyMacWithKey(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_CHANGEKEY:
			iResult = hsm56_ChangeKey(hsmSourKey,
									hsmDestKey,
									hsmMsgIn);
	}			
	return iResult;
}

int hsm56_Test(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	int iResult;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	add_tail(&operate_buf, "01", 2, 'A');
	iResult = hsm56_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, hsm56_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code,"00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm56_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}

	return HSM_SUCCESS;
}

int hsm56_TransPin(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	int		iResult,nPinLen;
	char	saPanData[16], saPanLen[3];
	char	saPinTmp[16],saNewPin[16];

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saPinTmp[0],0,sizeof(saPinTmp));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saPinTmp[0], 8);

	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
	{
   		add_tail(&operate_buf, "61", 2, 'A');
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'A');
		if( memcmp(hsmSourKey->pinkey1,"0000000000000000",16) == 0 &&
			memcmp(hsmDestKey->pinkey1,"0000000000000000",16) == 0 )
		{	/* DES */
    		add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 16, 'A');
		}
		else
		{
   			add_tail(&operate_buf, "Y", 1, 'A');
    		add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 32, 'A');
		}
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'A');
		if( memcmp(hsmSourKey->pinkey1,"0000000000000000",16) == 0 &&
			memcmp(hsmDestKey->pinkey1,"0000000000000000",16) == 0 )
		{	/* DES */
    		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 16, 'A');
		}
		else
		{	/* 3DES */
   			add_tail(&operate_buf, "Y", 1, 'A');
    		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 32, 'A');
		}
    	add_tail(&operate_buf, &saPinTmp[0], 16, 'A');

		memset(saPanData,'0',sizeof(saPanData));
		if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		{
			memset(saPanLen,0,sizeof(saPanLen));
			memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
			memcpy(&saPanData[4],
				&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
		}
    	add_tail(&operate_buf, &saPanData[0], 16, 'A');
	}
	else if(hsmSourKey->index[0] != 0)
	{
   		add_tail(&operate_buf, "68", 2, 'A');
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'A');
    	add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 16, 'A');
    	add_tail(&operate_buf, &saPinTmp[0], 16, 'A');

		memset(saPanData,'0',sizeof(saPanData));
		if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		{
			memset(saPanLen,0,sizeof(saPanLen));
			memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
			memcpy(&saPanData[4],
				&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
		}
    	add_tail(&operate_buf, &saPanData[0], 16, 'A');
	}
	else if(hsmDestKey->index[0] != 0)
	{
   		add_tail(&operate_buf, "60", 2, 'A');
   		add_tail(&operate_buf, "3", 1, 'A');
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'A');
		if( memcmp(hsmSourKey->pinkey1,"0000000000000000",16) == 0 &&
			memcmp(hsmDestKey->pinkey1,"0000000000000000",16) == 0 )
		{	/* DES */
    		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 16, 'A');
		}
		else
		{	/* 3DES */
   			add_tail(&operate_buf, "Y", 1, 'A');
    		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 32, 'A');
		}
    	add_tail(&operate_buf, &saPinTmp[0], 16, 'A');

		memset(saPanData,'0',sizeof(saPanData));
		if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		{
			memset(saPanLen,0,sizeof(saPanLen));
			memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
			memcpy(&saPanData[4],
				&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
		}
    	add_tail(&operate_buf, &saPanData[0], 16, 'A');
	}

	iResult = hsm56_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, hsm56_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code,"00", 2) == 0)
	{
        remove_head(&response_buf, saNewPin, 16, 'A');
		Str2Hex( &saNewPin[0], &hsmMsgIn->hsmOpr.saEnc[0], 16);
		return HSM_SUCCESS;
    }
    else
    {
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm56_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm56_GenMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16];
	char	saMacBlockLen[4];
	int		iResult;

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

   	add_tail(&operate_buf, "80", 2, 'A');
	if(hsmSourKey->index[0] != 0)
	{
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'A');
    	add_tail(&operate_buf, &hsmSourKey->mackey1[0], 16, 'A');
	}
	else
	{
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'A');
    	add_tail(&operate_buf, &hsmDestKey->mackey1[0], 16, 'A');
	}
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'A');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
			atoi(saMacBlockLen), 'A'); 

	iResult = hsm56_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, hsm56_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code,"00", 2) == 0)
    {
        remove_head(&response_buf, saMac, 16, 'A');
		memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8);
		return HSM_SUCCESS;
    }
    else
    {
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm56_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm56_GenMacWithKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16],saMacKey[32];
	char	saMacBlockLen[4];
	int		iResult;

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 16);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

   	add_tail(&operate_buf, "80", 2, 'A');
	if(hsmSourKey->index[0] != 0)
	{
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'A');
	}
	else
	{
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'A');
	}
	if(memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "16", 2) == 0)
	{	/* 3DES */
   		add_tail(&operate_buf, "Y", 1, 'A');
   		add_tail(&operate_buf, &saMacKey[0], 32, 'A');
	}
	else
	{	/* DES */
   		add_tail(&operate_buf, &saMacKey[0], 16, 'A');
	}
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'A');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
			atoi(saMacBlockLen), 'A'); 

	iResult = hsm56_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, hsm56_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code,"00", 2) == 0)
    {
        remove_head(&response_buf, saMac, 16, 'A');
		memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8);
		return HSM_SUCCESS;
    }
    else
    {
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm56_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm56_VerifyMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16];
	char	saMacBlockLen[4];
	int		iResult;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

   	add_tail(&operate_buf, "80", 2, 'A');
	if(hsmSourKey->index[0] != 0)
	{
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'A');
    	add_tail(&operate_buf, &hsmSourKey->mackey1[0], 16, 'A');
	}
	else
	{
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'A');
    	add_tail(&operate_buf, &hsmDestKey->mackey1[0], 16, 'A');
	}
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'A');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
			atoi(saMacBlockLen), 'A'); 
	iResult = hsm56_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, hsm56_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code,"00", 2) == 0)
    {
        remove_head(&response_buf, saMac, 16, 'A');
        if(memcmp(saMac, &hsmMsgIn->hsmOpr.saEnc[16], 8) == 0)
            return HSM_SUCCESS;
		else
            return HSM_FAIL;
	}
	else
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm56_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm56_VerifyMacWithKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16], saMacKey[16];
	char	saMacBlockLen[4];
	int		iResult;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 8);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

   	add_tail(&operate_buf, "80", 2, 'A');
	if(hsmSourKey->index[0] != 0)
	{
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'A');
	}
	else
	{
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'A');
	}
   	add_tail(&operate_buf, &saMacKey[0], 16, 'A');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'A');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
			atoi(saMacBlockLen), 'A'); 
	iResult = hsm56_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, hsm56_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code,"00", 2) == 0)
    {
        remove_head(&response_buf, saMac, 16, 'A');
        if(memcmp(saMac, &hsmMsgIn->hsmOpr.saEnc[16], 8) == 0)
            return HSM_SUCCESS;
		else
            return HSM_FAIL;
    }
    else
    {
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm56_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm56_ChangeKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac1[16],saMac2[16],saMacKey[32];
	char	saMacBlockLen[4];
	int		iResult,nKeyFlag;
	char	saKeyIndex[3];

	clear_string(&operate_buf);
	clear_string(&response_buf);

	memset(saMac1,0,sizeof(saMac1));
	memset(saMac2,0,sizeof(saMac2));
	memset(saMacKey,0,sizeof(saMacKey));

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	if(hsmMsgIn->hsmOpr.saEncWay[0] == '1')
		nKeyFlag = PIN_KEY_TYPE;
	else if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		nKeyFlag = MAC_KEY_TYPE;
	else
		return HSM_FAIL;

	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 16);
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[16], &saMac1[0], 8);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

	add_tail(&operate_buf, "81", 2, 'A');
	if(hsmSourKey->index[0] != 0)
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmSourKey->keyindex,2);
   		add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'A');
	}
	else
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmDestKey->keyindex,2);
   		add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'A');
	}
	if(memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "16", 2) == 0)
	{	/* 3DES */
		add_tail(&operate_buf, "Y", 1, 'A');
   		add_tail(&operate_buf, &saMacKey[0], 32, 'A');
   		add_tail(&operate_buf, &saMac1[0], 8, 'A');
	}
	else
	{	/* DES */
   		add_tail(&operate_buf, &saMacKey[0], 16, 'A');
   		add_tail(&operate_buf, &saMac1[0], 8, 'A');
		memcpy(&saMacKey[16],"0000000000000000",16);
	}
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'A');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
			atoi(saMacBlockLen), 'A'); 

	iResult = hsm56_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, hsm56_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code,"00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm56_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}

	if(lModifyKeyFile(saKeyIndex,nKeyFlag,saMacKey) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsm56_ChangeKey::to modify keyfile failure!");
		return HSM_FAIL;
	}

	return HSM_SUCCESS;
}
