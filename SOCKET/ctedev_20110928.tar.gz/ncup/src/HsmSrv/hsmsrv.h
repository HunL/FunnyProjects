#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <termio.h>
#include <fcntl.h>
#include <sys/msg.h>
#include <sys/time.h>

#include "config.h"
#include "softenc.h"

char	logfile[100];
int		os_type;

#define	HSMCHK_MSG_TYPE			9999

#define CHECKSUM_LEN    4

static int iInitKeyNeed = 1;

#define PIN_KEY_TYPE			1
#define MAC_KEY_TYPE			2

#define NO_LOG					0
#define NO_TRACE				0

#define SCO_UNIX_OS				1
#define ELSE_OS					2

#define IS_ASCII                1
#define IS_BCD                  2

#define NO_HSM					0
#define HSM_SOFT				1
#define HSM_30_TCP				2
#define HSM_30_COM				3
#define HSM_56_TCP				4
#define HSM_56_COM				5
#define HSM_10_TCP				6
#define HSM_10_COM				7
#define HSM_RACAL_TCP			8
#define HSM_RACAL_COM			9

#define HSM_SUCCESS				0
#define HSM_FAIL				-1

#define HSM_TEST				'0'
#define HSM_GENMAC				'1'
#define HSM_VERIFYMAC			'2'
#define HSM_VERIFYMACWITHKEY	'3'
#define HSM_GENMACWITHKEY		'4'
#define HSM_TRANSPIN			'5'
#define HSM_CHANGEKEY			'6'

#define HSM_GENZPK				'7'
#define HSM_GENTMK				'8'
#define HSM_GENTWK				'9'

#define HSM_VERIFYMACWITHKEY4POS	'a'
#define HSM_GENMACWITHKEY4POS		'b'

#define HSM_CHANGEZPK			'c'
#define HSM_CHANGEZAK			'd'
#define HSM_GENZAK			'e'
#define HSM_CVTPINKEY		'f'
#define HSM_VERIFYARQC         'g'
#define HSM_GENSCRIPTMAC         'h'
#define HSM_CVTMACKEY		'i'
#define HSM_TRANSPIN4ZK			'j'

typedef struct 
{
	char	saOprType;
	char	saEncWay[16];
	char	saCardNo[21];
	char	saRout[10];
	char	saEnc[24];
	char	saMacBlockLen[MAX_MAC_ELEMENT_LEN_LEN];
	char	saMacBlock[MAX_MAC_ELEMENT_LEN];
	char	saRspCode[2];

	char	saZAK[32];
	char	saZAKLMK[32];
	char	saZAKChkV[8];

	char	saZPK[32];
	char	saZPKLMK[32];
	char	saZPKChkV[8];

	char	saTMK[32];
	char	saTMKLMK[32];
	char	saTMKChkV[8];

	char	saPIK[32];
	char	saPIKLMK[32];
	char	saPIKChkV[8];

	char	saMAK[32];
	char	saMAKLMK[32];
	char	saMAKChkV[8];

	char	saTRK[32];
	char	saTRKLMK[32];
	char	saTRKChkV[8];
}HSMOprDef;

typedef struct
{
	long		nMsgType;
	HSMOprDef	hsmOpr;
}HSMMsgInDef;

typedef struct
{
	short str_len;
	char str_content[MAX_ENC_DATA_LEN] ;
}T_STRING ;

int ClientHsm(char *ip, int port, int i);
int Send2HSM(int fd,char *buf,int len);
int Recv4HSM(int fd,char *buf,int len);
int SndRcvHSM30COM(int fd,T_STRING * p_operate_buf, T_STRING * p_response_buf);

void collapse_from_db(unsigned char * db_str, short len, unsigned char * str);
void expand_to_db(unsigned char * str, short len, unsigned char * db_str);
void clear_string(T_STRING * p_str);
void add_tail(T_STRING * p_str, char * array, short len, char type);
void remove_head(T_STRING * p_str, char * array, short len, char type);
int istruealnum(char c);
long numin(char * str, short len);
void numout(char * str, short len, long num);
void preprocess_mac_element(char * mac_element, char * mac_element_len);
void get_checksum(char * mac_element, short len, char * checksum);
void preprocess_received_msg( char * data, short * len );
void on_timer(int sig);
