#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <fcntl.h>

#include "hsmsrv.h"
#include "softenc.h"
#include "DbsDef.h"

extern int trace_level,log_level,cmd_len,cmd_type,head_len;
extern char sHeadMess[100]; 
static unsigned short SEC_TIMEOUT = 0;

void HsmGetTime(char *sCurrentTime)
{
	time_t current;
	struct tm *tmCurrentTime;
	
	tzset();
	time(&current);
	tmCurrentTime = localtime(&current);
	sprintf(sCurrentTime, "%4d%02d%02d%02d%02d%02d",
	       tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1,
	       tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
	       tmCurrentTime->tm_min, tmCurrentTime->tm_sec);
}

void HsmLog(char *logfile, int loglevel, char *file, int line, char *fmt, ...)
{
	va_list ap;
	FILE 	*fp = NULL;
	char 	filename[101];
	char	saDateTime[15];

	memset(saDateTime,0,sizeof(saDateTime));
	HsmGetTime( saDateTime );

	memset(filename, 0, sizeof(filename));
	sprintf(filename,"%s/log/%s.%8.8s", 
			getenv("FEHOME"),logfile,saDateTime);

	if( loglevel == 0 ) return;

	if ( ( fp = fopen(filename, "a+") ) == NULL )
		return ;

	fprintf(fp, "[%4.4s-%2.2s-%2.2s %2.2s:%2.2s:%2.2s][%s][%d]",
			saDateTime,saDateTime+4,saDateTime+6,saDateTime+8,
			saDateTime+10,saDateTime+12,file,line);

	va_start(ap, fmt);
	vfprintf(fp, fmt, ap);
	va_end(ap);
	
	fprintf(fp, "\n");

	fflush(fp);

	fclose(fp);

	return ;
}

void HsmTrace(char *logfile, int loglevel, char *psBuf, int iLength, 
			char *iFile, int iLine )
{
	char 	filename1[101];
	register int i,j=0;
	char 	s[100], temp[5];
	FILE 	*fp=NULL;
	char	saDateTime[15];

	memset(saDateTime,0,sizeof(saDateTime));
	HsmGetTime( saDateTime );

	memset(filename1, 0, sizeof(filename1));
	sprintf(filename1,"%s/log/%s.%8.8s", 
			getenv("FEHOME"),logfile,saDateTime);

	if(loglevel == 0) return ;

	if ( ( fp = fopen(filename1, "a+") ) == NULL ) return ;

	fprintf(fp, "[%4.4s-%2.2s-%2.2s %2.2s:%2.2s:%2.2s][%s][%d]\n",
			saDateTime,saDateTime+4,saDateTime+6,saDateTime+8,
			saDateTime+10,saDateTime+12,iFile,iLine);

	memset(s, 0, sizeof(s));
	memset(s, '-', 80);
	fprintf(fp, "%s\n", s);

	for (i=0; i<iLength; i++)
	{
		if (j==0)
		{
			memset( s, ' ', sizeof(s));
			sprintf(temp,   "%04d:",i );
			memcpy( s, temp, 5);
			sprintf(temp,   ":%04d",i+15 );
			memcpy( &s[72], temp, 5);
		}
		sprintf( temp, "%02X ", (unsigned char)psBuf[i]);
		memcpy( &s[j*3+5+(j>7)], temp, 3);
		if ( isprint( psBuf[i]))
		{
			s[j+55+(j>7)]=psBuf[i];
		}
		else
		{
			s[j+55+(j>7)]='.';
		}
		j++;
		if ( j==16)
		{
			s[77]=0;
			fprintf(fp, "%s\n", s);
			j=0;
		}
	}

	if (j)
	{
		s[77]=0;
		fprintf(fp, "%s\n", s);
	}

	memset(s, 0, sizeof(s));
	memset(s, '-', 80);
	fprintf(fp, "%s\n", s);
	fflush(fp);

	fclose(fp);

	return ;
}


long lModifyKeyData(char *sKeyIndex, int nKeyFlag, char *sDataKey)
{
	int	i, ret;
	HSM_KEYFILE	hsmKeyFile;

	memset(&hsmKeyFile,0,sizeof(HSM_KEYFILE));
	memset(&hsmKeyFile,0x00,sizeof(HSM_KEYFILE));
	ret = DbsConnect();
	if( ret )
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,"�������ݿ�ʧ��:[d]", ret);
		return -1;
	}
	memcpy(hsmKeyFile.keyindex, sKeyIndex, 2);
	ret = DbsTblKeyParam( DBS_SELECT, &hsmKeyFile);
	if( ret )
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,"��ʼ����Կʧ��:[%d]", ret);
		DbsDisconnect();
		return -1;
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,"keyindex:[%s]", hsmKeyFile.keyindex);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"index:[%s]", hsmKeyFile.index);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"bmk:[%s]", hsmKeyFile.bmk);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"pinkey1:[%s]", hsmKeyFile.pinkey1);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"mackey1:[%s]", hsmKeyFile.mackey1);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"pinkey2:[%s]", hsmKeyFile.pinkey2);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"mackey2:[%s]", hsmKeyFile.mackey2);
	if(nKeyFlag == PIN_KEY_TYPE)
	{
		memcpy(hsmKeyFile.pinkey2,hsmKeyFile.pinkey1,DB_KEY_LEN*2);
		memcpy(hsmKeyFile.pinkey1,sDataKey,DB_KEY_LEN*2);
	}
	else if(nKeyFlag == MAC_KEY_TYPE)
	{
		memcpy(hsmKeyFile.mackey2,hsmKeyFile.mackey1,DB_KEY_LEN*2);
		memcpy(hsmKeyFile.mackey1,sDataKey,DB_KEY_LEN*2);
	}
	else
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"lModifyKeyFile::The Key Type Flag is Wrong(NOT 1 OR 2)!");
		return -1;
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,"keyindex:[%s]", hsmKeyFile.keyindex);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"index:[%s]", hsmKeyFile.index);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"bmk:[%s]", hsmKeyFile.bmk);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"pinkey1:[%s]", hsmKeyFile.pinkey1);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"mackey1:[%s]", hsmKeyFile.mackey1);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"pinkey2:[%s]", hsmKeyFile.pinkey2);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"mackey2:[%s]", hsmKeyFile.mackey2);
	
	ret = DbsTblKeyParam( DBS_UPDATE, &hsmKeyFile);
	if( ret )
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,"��ʼ����Կʧ��:[%d]", ret);
		DbsDisconnect();
		return -1;
	}
	DbsCommit();
	DbsDisconnect();
	iInitKeyNeed = 1;
	
	return 0;
}

int lReadKeyFile(int i, HSM_KEYFILE *hsmKeyFile)
{
	char	sKeyFileName[100];
	FILE	*fpKeyfile;

	memset(sKeyFileName,0,100);
	sprintf(sKeyFileName, "%s/key/key.%02d", (char *)getenv("HSMHOME"), i);
	fpKeyfile = fopen(sKeyFileName,"r");
	if(fpKeyfile == NULL)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"lReadKeyFile::Open Keyfile Error![%s]", sKeyFileName);
		return -1;
	}

	if((fread(hsmKeyFile,sizeof(HSM_KEYFILE),1,fpKeyfile)) == 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"lReadKeyFile::Read Keyfile Error %d!",errno);
		return -1;
	}

	fclose(fpKeyfile);
	return 0;

}

long lModifyKeyFile(char *sKeyIndex, int nKeyFlag, char *sDataKey)
{
	char		sKeyFileName[100];
	FILE		*fpKeyfile;
	HSM_KEYFILE	hsmKeyFile;

	memset(sKeyFileName,0,100);
	sprintf(sKeyFileName, "%s/key/key.%2.2s", (char *)getenv("HSMHOME"),sKeyIndex);

		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"sKeyFileName[%s],sKeyIndex[%s]",sKeyFileName,sKeyIndex);

	fpKeyfile = fopen(sKeyFileName,"r");
	if(fpKeyfile == NULL)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"lModifyKeyFile::Open Keyfile Error!");
		return -1;
	}

	memset(&hsmKeyFile,0,sizeof(HSM_KEYFILE));
	if((fread(&hsmKeyFile,sizeof(HSM_KEYFILE),1,fpKeyfile)) == 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"lModifyKeyFile::Read Keyfile Error!");
		return -1;
	}
	fclose(fpKeyfile);

	fpKeyfile = fopen(sKeyFileName,"w");
	if(nKeyFlag == PIN_KEY_TYPE)
	{
		memcpy(hsmKeyFile.pinkey2,hsmKeyFile.pinkey1,DB_KEY_LEN*2);
		memcpy(hsmKeyFile.pinkey1,sDataKey,DB_KEY_LEN*2);
	}
	else if(nKeyFlag == MAC_KEY_TYPE)
	{
		memcpy(hsmKeyFile.mackey2,hsmKeyFile.mackey1,DB_KEY_LEN*2);
		memcpy(hsmKeyFile.mackey1,sDataKey,DB_KEY_LEN*2);
	}
	else
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"lModifyKeyFile::The Key Type Flag is Wrong(NOT 1 OR 2)!");
		return -1;
	}

	if((fwrite(&hsmKeyFile,sizeof(HSM_KEYFILE),1,fpKeyfile)) == 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"lModifyKeyFile::Write Keyfile Error!");
		return -1;
	}
	fclose(fpKeyfile);

	iInitKeyNeed = 1;

	return 0;
}

int Send2HSM(int fd, char *buf, int len)
{
	char			sSendBuf[512];
	char			sHeadBuf[10];
	unsigned char	headlen[2+1];
	int				sendlen,helen;
	struct	timeval tv;
	fd_set	allset;

	memset(sSendBuf, 0, sizeof(sSendBuf));
	memset(sHeadBuf, 0, sizeof(sHeadBuf));

	switch(cmd_len)
	{
	case 0 : 
		sSendBuf[0] = (len >> 8) & 0xff;
		sSendBuf[1] = len & 0xff;

		memcpy(&sSendBuf[2],buf,len);
		sendlen=len+2;
		break;
	case 1 :
		if(cmd_type == IS_BCD)
		{
			sSendBuf[0] = len % 256;
		}
		else
		{
			sprintf(sHeadBuf, "%1d", cmd_len);
			memcpy(sSendBuf, sHeadBuf, 1);
		}
		memcpy(&sSendBuf[1],buf,len);
		sendlen=len+1;
		break;
	case 2 :
		if(cmd_type == IS_BCD)
		{
			sSendBuf[0] = len / 256;
			sSendBuf[1] = len % 256;
		}
		else
		{
			sprintf(sHeadBuf, "%02d", cmd_len);
			memcpy(sSendBuf, sHeadBuf, 2);
		}
		memcpy(&sSendBuf[2],buf,len);
		sendlen=len+2;
		break;
	case 3 :
		if(cmd_type == IS_BCD)
		{
			sSendBuf[0] = len / (256*256);
			sSendBuf[1] = len / 256;
			sSendBuf[2] = len % 256;
		}
		else
		{
			sprintf(sHeadBuf, "%03d", cmd_len);
			memcpy(sSendBuf, sHeadBuf, 3);
		}
		memcpy(&sSendBuf[3],buf,len);
		sendlen=len+3;
		break;
	case 4 :
		if(cmd_type == IS_BCD)
		{
			sSendBuf[0] = len / (256*256*256);
			sSendBuf[1] = len / (256*256);
			sSendBuf[2] = len / 256;
			sSendBuf[3] = len % 256;
		}
		else
		{
			sprintf(sHeadBuf, "%04d", cmd_len);
			memcpy(sSendBuf, sHeadBuf, 4);
		}
		memcpy(&sSendBuf[4],buf,len);
		sendlen=len+4;
		break;
	default:
		memcpy(sSendBuf,buf,len);
		sendlen=len;
		break;
	}

	if(send(fd,sSendBuf,sendlen,0) != sendlen)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"Send2HSM:send()! errno = [%d]",errno);
		return -1;
	}

	return len;
}

int Recv4HSM(int fd, char *buf,int len)
{
	int		rc,nLen;
	char	sRcvBuf[512];
	char	sHeadBuf[5];
	fd_set	allset;
	struct timeval tv;

	switch(cmd_len)
	{
	case 1 :
		memset(sHeadBuf,0,sizeof(sHeadBuf));
		if((rc = recv(fd,sHeadBuf,1,0)) < 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"Recv4HSM:recv()! errno = [%d]",errno);
			return(-1);
		}
		nLen = sHeadBuf[0];
		break;

	case 2 :
		memset(sHeadBuf,0,sizeof(sHeadBuf));
		if((rc = recv(fd,sHeadBuf,2,0)) < 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"Recv4HSM:recv()rc = [%d]! errno = [%d]",rc,errno);
			return(-1);
		}
		if(cmd_type == IS_BCD)
			nLen = sHeadBuf[0]*256+sHeadBuf[1];
		else
			nLen = atoi(sHeadBuf);
			
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"sHeadBuf = [%s]",sHeadBuf);
			
		break;
	case 3 :
		memset(sHeadBuf,0,sizeof(sHeadBuf));
		if((rc = recv(fd,sHeadBuf,3,0)) < 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"Recv4HSM:recv()! errno = [%d]",errno);
			return(-1);
		}
		if(cmd_type == IS_BCD)
			nLen = sHeadBuf[0]*256*256+sHeadBuf[1]*256+sHeadBuf[3];
		else
			nLen = atoi(sHeadBuf);
		break;
	case 4 :
		memset(sHeadBuf,0,sizeof(sHeadBuf));
		if((rc = recv(fd,sHeadBuf,4,0)) < 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"Recv4HSM:recv()! errno = [%d]",errno);
			return(-1);
		}
		if(cmd_type == IS_BCD)
			nLen = sHeadBuf[0]*256*256*256+sHeadBuf[1]*256*256+sHeadBuf[3]*256+sHeadBuf[4];
		else
			nLen = atoi(sHeadBuf);
		break;
	default :
		nLen = len;
		break;
	}

	memset(sRcvBuf,0,sizeof(sRcvBuf));
	if((rc = recv(fd,sRcvBuf,nLen,0)) < 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"Recv4HSM:recv()! errno = [%d]",errno);
		return(-1);
	}
	else
	{
		memcpy(buf,sRcvBuf,rc);
		return(rc);
	}

}

void add_tail(T_STRING * p_str, char * array, short len, char type)
{
	char buf[500];
	short add_len;
	int num;

	switch(type)
	{
	case 'L' : memcpy(buf, array, len); buf[len] = '0';
	           add_len = (len+1)/2;
	           collapse_from_db( (unsigned char*)buf, 2*add_len, 
	          (unsigned char*)(p_str->str_content + p_str->str_len));
	           p_str->str_len += add_len;
	           break;
	case 'A' : memcpy(buf, array, len); buf[len] = '0';
	           memcpy((unsigned char*)(p_str->str_content + p_str->str_len),
	           buf, len);
	           p_str->str_len += len;
	           break;
	           
	case 'R' : if(len%2 == 1)
	           {
	               buf[0] = '0';
	               memcpy(buf+1, array, len);
	           }
	           else
	           {
	               memcpy(buf, array, len);
	           }

	           add_len = (len+1)/2;
	           collapse_from_db( (unsigned char*)buf, 2*add_len,
	          (unsigned char*)(p_str->str_content + p_str->str_len));
	           p_str->str_len += add_len;
	           break;
	           
	case 'H' : memcpy( buf, array, len); buf[len] = '0';
	           num = atoi(buf);
	           buf[0] = (num/256)%256; buf[1] = num%256;
	           memcpy(p_str->str_content + p_str->str_len, buf, 2);
	           p_str->str_len += 2;
	           break;
                   
	default :  memcpy(p_str->str_content + p_str->str_len, array, len);
	           p_str->str_len += len;
	}

	return;
}

void remove_head(T_STRING * p_str, char * array, short len, char type)
{
	char buf[500];
	short remove_len;
        
	switch(type)
	{
	case 'L' : remove_len = (len+1)/2;
	           expand_to_db((unsigned char*)p_str->str_content, remove_len,
	                        (unsigned char*)buf);
	           memcpy( array, buf, len);
	           break;
	case 'R' : remove_len = (len+1)/2;
	           expand_to_db((unsigned char*)p_str->str_content, remove_len,
	                        (unsigned char*)buf);
	           if(len%2 == 1)
	           {
	                     memcpy( array, buf+1, len);
	           }
	           else
	           {
	                     memcpy( array, buf, len);
	           }
	           break;
	default :  remove_len = len;
	           memcpy(array, p_str->str_content, len);
	}

	p_str->str_len -= remove_len;

	memmove(p_str->str_content, p_str->str_content + remove_len,
			p_str->str_len);

	return;
}

void clear_string(T_STRING * p_str)
{
	p_str->str_len = 0;
	
	return;
}

void expand_to_db(unsigned char * str, short len, unsigned char * db_str)
{
        short i;
        unsigned char high_byte, low_byte;

        for (i = 0; i < len; i++)
        {
                high_byte = str[i] >> 4;
                low_byte = str[i] & 0x0f ;

                high_byte += 0x30;

                if (high_byte > 0x39)
                        db_str[i * 2] = high_byte + 0x07;
                else
                        db_str[i * 2] = high_byte;

                low_byte += 0x30;
                if (low_byte > 0x39)
                        db_str[i * 2 + 1] = low_byte + 0x07;
                else
                        db_str[i * 2 + 1] = low_byte;
        }

        return;
}

void collapse_from_db(unsigned char * db_str, short len, unsigned char * str)
{
        short i ;
        unsigned char high_byte , low_byte ;

        for (i = 0; i < len; i += 2)
        {
                high_byte = db_str[i];
                low_byte = db_str[i + 1];

                if (high_byte > 0x39)
                        high_byte -= 0x37;
                else
                        high_byte -= 0x30;

                if (low_byte > 0x39)
                        low_byte -= 0x37;
                else
                        low_byte -= 0x30;

                str[i / 2] = (high_byte << 4) | low_byte;
        }

        return;
}

int init_port(char *address)
{
	struct termio tbuf ;
	unsigned short flags ;
	int fd;

	fd = open (address ,O_RDWR ) ;
	if (fd == -1)
	{
		return (-1);
	}

	ioctl ( fd,TCGETA,&tbuf ) ;
	flags = tbuf.c_lflag ;
	tbuf.c_cflag = (B19200) ;
	tbuf.c_cflag |= (CS8|CREAD) ;
	tbuf.c_cflag |= (CLOCAL|HUPCL);
	tbuf.c_iflag &= ~ISTRIP;
	tbuf.c_lflag &= ~(ECHO|ECHOE|ECHOK|ECHONL);
	tbuf.c_lflag |= ICANON;
	tbuf.c_cc[VEOF] = 0x03 ;
	tbuf.c_cc[VEOL] = 0x03 ;
	tbuf.c_cc[VEOL2] = 0x03 ;

	ioctl ( fd , TCSETA , &tbuf ) ;

	return fd;
}

int ConnectSocket(char *ip,int port)
{
	struct					sockaddr_in psckadd;
	int						sckcli;
	struct linger			Linger;
	int						on=1;

	memset((char *)(&psckadd),'0',sizeof(struct sockaddr_in));
	psckadd.sin_family            = AF_INET;
	psckadd.sin_addr.s_addr       = inet_addr(ip);
	psckadd.sin_port=htons((u_short)port);

	if((sckcli = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"ConnectSocket:can not open stream socket");
		return(-1);
	}

	if (connect(sckcli,(struct sockaddr *)(&psckadd),sizeof(struct sockaddr_in)) < 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"ConnectSocket:cannot connect to server! svr_ip = [%s] port = [%d]",ip,port);
		CloseSocket(sckcli);
		return(-2);
   	}

	Linger.l_onoff = 1;
	Linger.l_linger = 0;
	if (setsockopt(sckcli,SOL_SOCKET,SO_LINGER,(char *)&Linger,sizeof(Linger)) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"ConnectSocket:setsockopt linger!");
		CloseSocket(sckcli);
		return(-3);
	}

	if (setsockopt(sckcli, SOL_SOCKET, SO_OOBINLINE, (char *)&on, sizeof(on)))
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"ConnectSocket:setsockopt SO_OOBINLINE!");
		CloseSocket(sckcli);
		return(-4);
	}

	on = 1;
	if (setsockopt(sckcli, IPPROTO_TCP, TCP_NODELAY, (char *)&on, sizeof(on)))
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"ConnectSocket:setsockopt: TCP_NODELAY");
		CloseSocket(sckcli);
		return(-5);
	}
	return(sckcli);
}

int CloseSocket(int sockfd)
{
	shutdown(sockfd, 2);

	if (close(sockfd) != 0)
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"closesocket error!");
	else
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"closesocket successfully!");

	return(0);
}

void preprocess_mac_element(char * mac_element, char * mac_element_len)
{
	short len, return_len = 0, mac_element_pos = 0, blank_now = 0;
	char current_char;
	char temp_mac_element[MAX_MAC_ELEMENT_LEN];

	len = (short)numin(mac_element_len, MAX_MAC_ELEMENT_LEN_LEN);
	memcpy(temp_mac_element, mac_element, MAX_MAC_ELEMENT_LEN);
	memset(mac_element, ' ', MAX_MAC_ELEMENT_LEN);

	while (' ' == temp_mac_element[mac_element_pos++]
			&& mac_element_pos != len);

	if (mac_element_pos == len)
			return_len = 0;
	else
	{
		if (mac_element_pos) mac_element_pos--;

		while (mac_element_pos != len)
		{
			current_char = toupper(temp_mac_element[mac_element_pos++]);

			if (istruealnum(current_char) || '.' == current_char ||
				',' == current_char)
			{
				if (blank_now) mac_element[return_len++] = ' ';
					blank_now = 0;
				mac_element[return_len++] = current_char;
				continue;
			}

			if (' ' == current_char)
			{
				blank_now = 1;
				continue;
			}

		}

	}

	numout(mac_element_len, MAX_MAC_ELEMENT_LEN_LEN, return_len);

	return;
}

int istruealnum(char c)
{
	if ('a' <= c && c <= 'z') return 1;
	if ('A' <= c && c <= 'Z') return 1;
	if ('0' <= c && c <= '9') return 1;

	return 0;
}

long numin(char * str, short len)
{
	char buf[50];

	memcpy(buf, str, len);
	buf[len] = 0;

	return (atol(buf));
}

void numout(char * str, short len, long num)
{
	char buf[51];

	sprintf(buf, "%050d", num);
	memcpy(str, buf + 50 - len, len);

	return;
}

int SndRcvHSM30COM(int encrypter_handle, T_STRING * p_operate_buf, T_STRING * p_response_buf)
{
	short len, i, flag;
 
	char temp_operate_buf[MAX_ENC_DATA_LEN + 6];
	char temp_response_buf[MAX_ENC_DATA_LEN + 6];

	char checksum[CHECKSUM_LEN];

	temp_operate_buf[0] = 0x02;
	
	memcpy(temp_operate_buf + 1, p_operate_buf->str_content, p_operate_buf->str_len);
	       
	get_checksum(p_operate_buf->str_content, p_operate_buf->str_len, checksum);
		     
	memcpy(temp_operate_buf + p_operate_buf->str_len + 1, checksum, CHECKSUM_LEN);
	       
	temp_operate_buf[p_operate_buf->str_len + 5] = 0x03;

	HsmLog(logfile,log_level,__FILE__,__LINE__,"SndRcvHSM30COM:begin");

	len = write(encrypter_handle, temp_operate_buf, p_operate_buf->str_len + 6);

	if (len != p_operate_buf->str_len + 6)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,"SndRcvHSM30COM:Comm error when write to encrypter");
		return -1;
	}

	HsmLog(logfile,log_level,__FILE__,__LINE__,"SndRcvHSM30COM:write ok");

	sigset(SIGALRM, on_timer);
	alarm(5);

	HsmLog(logfile,log_level,__FILE__,__LINE__,"SndRcvHSM30COM:begin read");
	len = read(encrypter_handle, temp_response_buf, 100 + 6);
	if (-1 == len) 
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,"SndRcvHSM30COM:Comm error when read from encrypter");
		return -2;
	}

	alarm(0);

	preprocess_received_msg( temp_response_buf, &len);
	if (len <=0) return -3;

	if (len > CHECKSUM_LEN)
	{
		get_checksum(temp_response_buf + 1, (short)(len - 5), checksum);

		if (memcmp(checksum, temp_response_buf + len - 4, CHECKSUM_LEN))
			return -4;

		p_response_buf->str_len = len - 5;
		memcpy(p_response_buf->str_content, temp_response_buf + 1,
		    len - 5);
	}
	else
	{
		p_response_buf->str_len = len - 1;
		memcpy(p_response_buf->str_content, temp_response_buf + 1,
		    len - 1);
	}

	return 0;
}

void preprocess_received_msg( char * data, short * len )
{
	short i, j;

	if( ( char)data[*len - 1] == ( char)0x03 )
		*len = *len - 1;
	
	for( i=0; i<*len; i++)
	{
		if( ( char)data[i] == ( char)0x02 )
		break;
	}
	
	if( i == 0 )
		return;

	for( j=0; j<( *len - i); j++)
		data[j] = data[j+i];

	*len = *len - i;
}

void get_checksum(char * mac_element, short len, char * checksum)
{
	unsigned long sum = 0;
	short i;
	char buf[5];
	
	for (i = 0; i < len; sum += mac_element[i++]);
	sprintf(buf, "%04x", sum);
		
	for (i = 0; i < 4; buf[i] = toupper(buf[i]), i++);
	memcpy(checksum, buf, CHECKSUM_LEN);
	
	return;
}

void on_timer(int sig)
{
}

int get_8_value(char *str1, char *str2, int len)
{
	int i,k;

	i=k=0;

	for(i=0;i<len;i++)
		str2[i] = str1[i];

	k=i;

	for(i=0;i<8-len;i++)
		str2[k+i] = 0x00;
	str2[8] = '\0';

	return 0;
}

void calc_mac_8(char *buf, int len, char *mac)
{
	int i,j;
	char tmp[20];

	memset(tmp, 0, sizeof(tmp));

	for(i=0;i<8;i++) mac[i]=0;

	for(i=0;i<len;i+=8)
	{
		if((len-i)<8)
		{
			get_8_value(buf+i,tmp,len-i);
			for(j=0;j<8;j++) mac[j]=mac[j]^tmp[j];
		}
		else
		{
			for(j=0;j<8;j++) mac[j]=mac[j]^buf[i+j];
		}
	}
	return;
}
