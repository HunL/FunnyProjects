#include "hsmsrv.h"

char		sMsgHead[100];
static char 		sResult[300+1];
char		RacalPinKey[16];
T_STRING 	operate_buf, response_buf;
char 		hsmracal_response_code[2], err_code[2];
extern int	trace_level,log_level,hsm_type,head_len;
extern char	gsMsgHead[100];
extern int	iSocketID;

int hsmracal_cmd(T_STRING * p_operate_buf, T_STRING * p_response_buf)
{
	int ret;

	HsmTrace(logfile,trace_level,p_operate_buf->str_content,
			p_operate_buf->str_len,__FILE__,__LINE__);

	if(hsm_type == HSM_RACAL_TCP)
	{
		if( (ret = Send2HSM( iSocketID,
					p_operate_buf->str_content,
					p_operate_buf->str_len )) != p_operate_buf->str_len )
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
					"hsmracal_cmd:Send2HSM error!");
			CloseSocket(iSocketID);
			exit(0);
		}

		ret = Recv4HSM( iSocketID, sResult, 300 );
		if(ret<= 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmracal_cmd:Recv4HSM error!" );
			CloseSocket(iSocketID);
			exit(0);
		}

		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"iSocketID[%d]",iSocketID);

		p_response_buf->str_len = ret;
		memcpy(p_response_buf->str_content, sResult, ret);
	}
	else
	{
		ret = SndRcvHSM30COM(iSocketID, p_operate_buf, p_response_buf);
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmracal_cmd:SndRcvHSM30COM error [%d]!", ret);
		if (ret < 0) exit(0);
	}
	HsmTrace(logfile,trace_level, p_response_buf->str_content,
			p_response_buf->str_len, __FILE__,__LINE__);

    return HSM_SUCCESS;
}

int hsmracal_SndRcv(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	int iResult,nOpr;

	switch(hsmMsgIn->hsmOpr.saOprType)
	{
		case HSM_TEST:
			iResult = hsmracal_Test(hsmSourKey,
								hsmDestKey,
								hsmMsgIn);
			break;

		case HSM_TRANSPIN:
			iResult = hsmracal_TransPin(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;
			
		case HSM_TRANSPIN4ZK:
			iResult = hsmracal_TransPin4ZK(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_GENMAC:
			iResult = hsmracal_GenMac(hsmSourKey,
									hsmDestKey,
									hsmMsgIn);
			break;

		case HSM_VERIFYMAC:
			iResult = hsmracal_VerifyMac(hsmSourKey,
									hsmDestKey,
									hsmMsgIn);
			break;

		case HSM_GENMACWITHKEY:
			iResult = hsmracal_GenMacWithKey(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_VERIFYMACWITHKEY:
			iResult = hsmracal_VerifyMacWithKey(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_GENMACWITHKEY4POS:
			iResult = hsmracal_GenMacWithKey4POS(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_VERIFYMACWITHKEY4POS:
			iResult = hsmracal_VerifyMacWithKey4POS(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_CVTPINKEY:
			iResult = hsmracal_ConvertPINKey(hsmSourKey,
									hsmDestKey,
									hsmMsgIn);

			break;
			
		case HSM_CHANGEKEY:
			iResult = hsmracal_ChangeKey(hsmSourKey,
									hsmDestKey,
									hsmMsgIn);

			break;

		case HSM_GENZAK:
			iResult = hsmracal_GenZAK(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;


		case HSM_GENZPK:
			iResult = hsmracal_GenZPK(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_GENTMK:
			iResult = hsmracal_GenTMK(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_GENTWK:
			iResult = hsmracal_GenTWK(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;
			
		case HSM_CHANGEZAK:
			iResult = hsmracal_ChangeZAK(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_CHANGEZPK:
			iResult = hsmracal_ChangeZPK(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;
			
		case HSM_VERIFYARQC:
			iResult = hsmracal_VerifyARQC(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;
			
		case HSM_GENSCRIPTMAC:
			iResult = hsmracal_GenScriptMac(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

	}
	return iResult;
}

int hsmracal_Test(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char  sBufLen[2];
	int iResult;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "A0", 2, 'A');
	add_tail(&operate_buf, "0", 1, 'A');
	add_tail(&operate_buf, "001", 3, 'A');
	add_tail(&operate_buf, "Z", 1, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_Test:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}

	return HSM_SUCCESS;
}

int hsmracal_TransPin(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	int		iResult,nPinLen;
	char	saPanData[16+1],saPanLen[3],saPanTmp[8+1];
	char	saPinTmp[16+1],saNewPin[16+1];
	char	saPinLen[2],sBufLen[2],saFormat[2];

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saPinTmp[0],0,sizeof(saPinTmp));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], saPinTmp, 16);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmSourKey->index[%s]hsmDestKey->index[%s]",hsmSourKey->index,hsmDestKey->index);
	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
	{ 	/* תPIN ZPK->ZPK */
		/* ������������������ */
		add_tail(&operate_buf, "CC", 2, 'A');
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 32, 'A');
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 32, 'A');

		add_tail(&operate_buf, "12", 2, 'A');

		add_tail(&operate_buf, &saPinTmp[0], 16, 'A');

		add_tail(&operate_buf, "01", 2, 'A');
		add_tail(&operate_buf, "01", 2, 'A');

        /* test begin */
        /*HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmOpr.saEncWay[0]: [%16.16s], hsmOpr.saCardNo: %21.21s",
			&hsmMsgIn->hsmOpr.saEncWay, &hsmMsgIn->hsmOpr.saCardNo);*/
	    /* test end */
		memset(saPanData,'0',sizeof(saPanData));
		if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		{
			memset(saPanLen,0,sizeof(saPanLen));
			memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
			memcpy(&saPanData[4],
				&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
		}
		add_tail(&operate_buf, &saPanData[4], 12, 'A');
	}
	else if(hsmSourKey->index[0] != 0)
	{	/* ��PIN */
	}
	else if(hsmDestKey->index[0] != 0)
	{	/* ��PIn */
	}

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');

	if(memcmp(err_code, "00", 2) == 0)
	{
        	remove_head(&response_buf, saPinLen, 2, 'A');
        	remove_head(&response_buf, saNewPin, 16, 'A');
        	remove_head(&response_buf, saFormat, 2, 'A');
		Str2Hex( &saNewPin[0], &hsmMsgIn->hsmOpr.saEnc[0], 16);
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_TransPin End!");
		return HSM_SUCCESS;
    }
    else
    {
        HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_TransPin:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	
}

int hsmracal_TransPin4ZK(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	int		iResult,nPinLen;
	char	saPanData[16+1],saPanLen[3],saPanTmp[8+1];
	char	saPinTmp[16+1],saNewPin[16+1];
	char	saPinLen[2],sBufLen[2],saFormat[2];

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saPinTmp[0],0,sizeof(saPinTmp));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], saPinTmp, 16);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmSourKey->index[%s]hsmDestKey->index[%s]",hsmSourKey->index,hsmDestKey->index);
	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
	{ 	/* תPIN ZPK->ZPK */
		add_tail(&operate_buf, "CC", 2, 'A');
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 32, 'A');
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 32, 'A');

		add_tail(&operate_buf, "12", 2, 'A');

		add_tail(&operate_buf, &saPinTmp[0], 16, 'A');

		add_tail(&operate_buf, "01", 2, 'A');
		add_tail(&operate_buf, "03", 2, 'A');

        /* test begin */
        /*HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmOpr.saEncWay[0]: [%16.16s], hsmOpr.saCardNo: %21.21s",
			&hsmMsgIn->hsmOpr.saEncWay, &hsmMsgIn->hsmOpr.saCardNo);*/
	    /* test end */
		memset(saPanData,'0',sizeof(saPanData));
		if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		{
			memset(saPanLen,0,sizeof(saPanLen));
			memcpy(saPanLen,&hsmMsgIn->hsmOpr.saTRK[0],2);
			memcpy(&saPanData[4],
				&hsmMsgIn->hsmOpr.saTRK[2+atoi(saPanLen)-13],12);
		}
		add_tail(&operate_buf, &saPanData[4], 12, 'A');
	}
	else if(hsmSourKey->index[0] != 0)
	{	/* ��PIN */
	}
	else if(hsmDestKey->index[0] != 0)
	{	/* ��PIn */
	}

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');

	if(memcmp(err_code, "00", 2) == 0)
	{
        	remove_head(&response_buf, saPinLen, 2, 'A');
        	remove_head(&response_buf, saNewPin, 16, 'A');
        	remove_head(&response_buf, saFormat, 2, 'A');
    }
    else
    {
        HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_TransPin4ZK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	
	clear_string(&operate_buf);
	clear_string(&response_buf);
	
	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');
	
	/* תPIN ZPK->ZPK */
	add_tail(&operate_buf, "CC", 2, 'A');
	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 32, 'A');
	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 32, 'A');

	add_tail(&operate_buf, "12", 2, 'A');

	add_tail(&operate_buf, &saNewPin[0], 16, 'A');

	add_tail(&operate_buf, "03", 2, 'A');
	add_tail(&operate_buf, "01", 2, 'A');

	memset(saPanData,'0',sizeof(saPanData));
	if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
	{
		memset(saPanLen,0,sizeof(saPanLen));
		memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
		memcpy(&saPanData[4],
			&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
	}
	add_tail(&operate_buf, &saPanData[4], 12, 'A');
	
	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');

	if(memcmp(err_code, "00", 2) == 0)
	{
        	remove_head(&response_buf, saPinLen, 2, 'A');
        	remove_head(&response_buf, saNewPin, 16, 'A');
        	remove_head(&response_buf, saFormat, 2, 'A');
        	
        	Str2Hex( &saNewPin[0], &hsmMsgIn->hsmOpr.saEnc[0], 16);
            HsmLog(logfile,log_level,__FILE__,__LINE__,
                    "hsmracal_TransPin4ZK End!");
            return HSM_SUCCESS;
    }
    else
    {
        HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_TransPin4ZK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	
}

int hsmracal_GenMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16+1];
	char	saMacBlockLen[4+1],saMacBLen[4+1];
	char	sBufLen[2];
	int	iResult;
	char    saZPK[32+1];

	clear_string(&operate_buf);
	clear_string(&response_buf);

	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmSourKey->index[%s]hsmDestKey->index[%s]",hsmSourKey->index,hsmDestKey->index);
	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "MS", 2, 'A');
	add_tail(&operate_buf, "0", 1, 'A');
	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
	{
	    add_tail(&operate_buf, "0", 1, 'A');
	}
	else if(hsmSourKey->index[0] != 0 )
	{
	    add_tail(&operate_buf, "1", 1, 'A');
	}
	
	if(hsmSourKey->index[0] != 0 )
	{
	    if(memcmp(&hsmSourKey->mackey1[16], "0000000000000000", 16) == 0 ||
	        memcmp(&hsmSourKey->mackey1[16], "                ", 16) == 0)
	        add_tail(&operate_buf, "00", 2, 'A');
	    else
	        add_tail(&operate_buf, "10", 2, 'A');
	}
	else
	    add_tail(&operate_buf, "00", 2, 'A');

	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
	{
		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saEnc[0], 16, 'A');
		HsmLog(logfile,log_level,__FILE__,__LINE__,"TAK ATM:[%16.16s]", &hsmMsgIn->hsmOpr.saEnc[0]);
	}
	else if(hsmSourKey->index[0] != 0 )
	{
	    if(memcmp(&hsmSourKey->mackey1[16], "0000000000000000", 16) == 0 ||
	        memcmp(&hsmSourKey->mackey1[16], "                ", 16) == 0)
	    {
            add_tail(&operate_buf, &hsmSourKey->mackey1[0], 16, 'A');
	        HsmLog(logfile,log_level,__FILE__,__LINE__,"ZAK CUP:[%16.16s]", &hsmSourKey->mackey1[0]);
	    }
	    else
	    {
	        add_tail(&operate_buf, "X", 1, 'A');
	        add_tail(&operate_buf, &hsmSourKey->mackey1[0], 32, 'A');
	        HsmLog(logfile,log_level,__FILE__,__LINE__,"ZAK CUP:[%32.32s]", &hsmSourKey->mackey1[0]);
	    }
	}
	else
	{
		add_tail(&operate_buf, &hsmDestKey->mackey1[0], 16, 'A');
		HsmLog(logfile,log_level,__FILE__,__LINE__,"ZAK:[%16.16s]", &hsmSourKey->mackey1[0]);
	}
	add_tail(&operate_buf, "0", 1, 'A');

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);
	sprintf(saMacBLen, "%03X", atoi(saMacBlockLen));
	add_tail(&operate_buf, saMacBLen, 3, 'A');
	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0],
			atoi(saMacBlockLen), 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmracal_cmd.iResult[%d]",iResult);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) == 0)
	{
		remove_head(&response_buf, saMac, 16, 'A');
		HsmLog(logfile,log_level,__FILE__,__LINE__,"saMac:[%16.16s]", saMac);
		memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8);
		/*Str2Hex(saMac, &hsmMsgIn->hsmOpr.saEnc[16], 16);*/
		HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmracal_GenMac End!");
		return HSM_SUCCESS;
	}
	else
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmracal_GenMac:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsmracal_GenMacWithKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16+1],saMacKey[32+1],saLMacKey[32+1];
	char	saMacBlockLen[4+1],saMacBLen[4+1];
	char	sBufLen[2],sLFlg[1];
	int	iResult;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str(&hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 16);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	if(memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "16", 2) == 0)
	{
   		add_tail(&operate_buf, "MI", 2, 'A');
   		add_tail(&operate_buf, "X", 1, 'A');
   		add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
   		add_tail(&operate_buf, "X", 1, 'A');
   		add_tail(&operate_buf, &saMacKey[0], 32, 'A');

		iResult = hsmracal_cmd(&operate_buf, &response_buf);
		if(iResult != HSM_SUCCESS) return HSM_FAIL;

		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenMacWithKey:ok!" );

		remove_head(&response_buf, sBufLen, 2, 'A');

		if(head_len != 0)
			remove_head(&response_buf, sMsgHead, head_len, 'A');
		remove_head(&response_buf, hsmracal_response_code, 2, 'A');
		remove_head(&response_buf, err_code, 2, 'A');
		if(memcmp(err_code, "00", 2) != 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmracal_GenMacWithKey:error[%c%c]!", err_code[0],err_code[1] );
			return HSM_FAIL;
		}
		remove_head(&response_buf, sLFlg, 1, 'A');
		remove_head(&response_buf, saLMacKey, 32, 'A');

		clear_string(&operate_buf);
		clear_string(&response_buf);

		if(head_len != 0)
			add_tail(&operate_buf, gsMsgHead, head_len, 'A');

   		add_tail(&operate_buf, "MU", 2, 'A');
		add_tail(&operate_buf, "0010", 4, 'A');
		add_tail(&operate_buf, "X", 1, 'A');
   		add_tail(&operate_buf, &saLMacKey[0], 32, 'A');
		add_tail(&operate_buf, "0", 1, 'A');
	}
	else if(memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "10", 2) == 0)
	{
   		add_tail(&operate_buf, "FK", 2, 'A');
		add_tail(&operate_buf, "1", 1, 'A');
   		add_tail(&operate_buf, "X", 1, 'A');
   		add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
   		add_tail(&operate_buf, &saMacKey[0], 16, 'A');

		iResult = hsmracal_cmd(&operate_buf, &response_buf);
		if(iResult != HSM_SUCCESS) return HSM_FAIL;

		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenMacWithKey:ok!" );

		remove_head(&response_buf, sBufLen, 2, 'A');

		if(head_len != 0)
			remove_head(&response_buf, sMsgHead, head_len, 'A');
		remove_head(&response_buf, hsmracal_response_code, 2, 'A');
		remove_head(&response_buf, err_code, 2, 'A');
		if(memcmp(err_code, "00", 2) != 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmracal_GenMacWithKey:error[%c%c]!", err_code[0],err_code[1] );
			return HSM_FAIL;
		}
		remove_head(&response_buf, saLMacKey, 16, 'A');

		clear_string(&operate_buf);
		clear_string(&response_buf);

		if(head_len != 0)
			add_tail(&operate_buf, gsMsgHead, head_len, 'A');

   		add_tail(&operate_buf, "MQ", 2, 'A');
		add_tail(&operate_buf, "0", 1, 'A');
   		add_tail(&operate_buf, &saLMacKey[0], 16, 'A');
	}
	else
	{
   		add_tail(&operate_buf, "MQ", 2, 'A');
		add_tail(&operate_buf, "0", 1, 'A');
		if(hsmSourKey->index[0] != 0)
		{
   			add_tail(&operate_buf, &hsmSourKey->mackey1[0], 16, 'A');
		}
		else
		{
   			add_tail(&operate_buf, &hsmDestKey->mackey1[0], 16, 'A');
		}
	}

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);
	sprintf(saMacBLen, "%03X", atoi(saMacBlockLen));
	add_tail(&operate_buf, saMacBLen, 3, 'A');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0],
			atoi(saMacBlockLen), 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) == 0)
    	{
        	remove_head(&response_buf, saMac, 8, 'A');
		memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8);
		return HSM_SUCCESS;
    	}
    	else
    	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenMacWithKey:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsmracal_GenMacWithKey4POS(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
        char    saMac1[16+1],saMac2[16+1],saMac3[16+1],saMac4[16+1],saMac5[16+1],saMac6[16+1],saMacKey[16+1];
        char    saMac33[16+1];
	char	saMacBlockLen[4+1];
	char	sBufLen[2];
	int	iResult,j;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 16);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

        memset(saMac1,0,sizeof(saMac1));
        calc_mac_8(hsmMsgIn->hsmOpr.saMacBlock, atoi(saMacBlockLen), saMac1);
        memset(saMac2,0,sizeof(saMac2));
        Hex2Str(saMac1, saMac2, 8);

	if(head_len != 0)
        {
                memset( &gsMsgHead[0], 0, head_len);
                add_tail(&operate_buf, gsMsgHead, head_len, 'A');
        }

        add_tail(&operate_buf, "MS", 2, 'A');
        add_tail(&operate_buf, "0000", 4, 'A');
        add_tail(&operate_buf, &saMacKey[0], 16, 'A');
        add_tail(&operate_buf, "0", 1, 'A');
        add_tail(&operate_buf, "008", 3, 'A');
        add_tail(&operate_buf, &saMac2[0], 8, 'A');

        iResult = hsmracal_cmd(&operate_buf, &response_buf);
        if(iResult != HSM_SUCCESS) return HSM_FAIL;

        remove_head(&response_buf, sBufLen, 2, 'A');

        if(head_len != 0)
                remove_head(&response_buf, sMsgHead, head_len, 'A');
        remove_head(&response_buf, hsmracal_response_code, 2, 'A');
        remove_head(&response_buf, err_code, 2, 'A');
        if(memcmp(err_code, "00", 2) == 0)
        {
                remove_head(&response_buf, saMac3, 16, 'A');
                Str2Hex(saMac3, saMac33, 16);
                memset(saMac4,0,sizeof(saMac4));
                for(j=0;j<8;j++) saMac4[j]=saMac33[j]^saMac2[8+j];

                clear_string(&operate_buf);
                clear_string(&response_buf);

                if(head_len != 0)
                {
                        memset( &gsMsgHead[0], 0, head_len);
                        add_tail(&operate_buf, gsMsgHead, head_len, 'A');
                }

                add_tail(&operate_buf, "MS", 2, 'A');
                add_tail(&operate_buf, "0000", 4, 'A');
                add_tail(&operate_buf, &saMacKey[0], 16, 'A');
                add_tail(&operate_buf, "0", 1, 'A');
                add_tail(&operate_buf, "008", 3, 'A');
                add_tail(&operate_buf, &saMac4[0], 8, 'A');

                iResult = hsmracal_cmd(&operate_buf, &response_buf);
                if(iResult != HSM_SUCCESS) return HSM_FAIL;

                remove_head(&response_buf, sBufLen, 2, 'A');

                if(head_len != 0)
                        remove_head(&response_buf, sMsgHead, head_len, 'A');
                remove_head(&response_buf, hsmracal_response_code, 2, 'A');
                remove_head(&response_buf, err_code, 2, 'A');
                if(memcmp(err_code, "00", 2) == 0)
                {
                        remove_head(&response_buf, saMac5, 8, 'A');
			memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac5,8);
			return HSM_SUCCESS;
                }
                else
                {
                        HsmLog(logfile,log_level,__FILE__,__LINE__,
                                "hsmracal_GenMacWithKey4POS:error[%c%c]!", err_code[0],err_code[1] );
                        return HSM_FAIL;

                }
        }
        else
        {
                HsmLog(logfile,log_level,__FILE__,__LINE__,
                        "hsmracal_GenMacWithKey4POS:error[%c%c]!", err_code[0],err_code[1] );
                return HSM_FAIL;
        }
}

int hsmracal_VerifyMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMacBlockLen[4+1],saMacBLen[4+1],saMac[8+1];
	char	sBufLen[2];
	int	iResult;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;


	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "MS", 2, 'A');
	add_tail(&operate_buf, "0", 1, 'A');
	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
	    add_tail(&operate_buf, "0", 1, 'A');
	else
	    add_tail(&operate_buf, "1", 1, 'A');
	
	if(hsmSourKey->index[0] != 0 )
	{
	    if(memcmp(&hsmSourKey->mackey1[16], "0000000000000000", 16) == 0 ||
	        memcmp(&hsmSourKey->mackey1[16], "                ", 16) == 0)
	        add_tail(&operate_buf, "00", 2, 'A');
	    else
	        add_tail(&operate_buf, "10", 2, 'A');
	}
	else
	    add_tail(&operate_buf, "00", 2, 'A');

	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,"TAK:[%16.16s]",  hsmMsgIn->hsmOpr.saEnc);
		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saEnc[0], 16, 'A');
	}
	else if(hsmSourKey->index[0] != 0)
	{
	    if(memcmp(&hsmSourKey->mackey1[16], "0000000000000000", 16) == 0 ||
	        memcmp(&hsmSourKey->mackey1[16], "                ", 16) == 0)
	    {
	        HsmLog(logfile,log_level,__FILE__,__LINE__,"ZAK:[%16.16s]",  hsmSourKey->mackey1);
		    add_tail(&operate_buf, &hsmSourKey->mackey1[0], 16, 'A');
	    }
	    else
	    {
	        add_tail(&operate_buf, "X", 1, 'A');
	        HsmLog(logfile,log_level,__FILE__,__LINE__,"ZAK:[%32.32s]",  hsmSourKey->mackey1);
		    add_tail(&operate_buf, &hsmSourKey->mackey1[0], 32, 'A');
	    }
	}
	else
	{
		add_tail(&operate_buf, &hsmDestKey->mackey1[0], 16, 'A');
	}

	 add_tail(&operate_buf, "0", 1, 'A');

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);
	sprintf(saMacBLen, "%03X", atoi(saMacBlockLen));
	add_tail(&operate_buf, saMacBLen, 3, 'A');
	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0],
			atoi(saMacBlockLen), 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) == 0)
	{
		memset(saMac, 0, sizeof(saMac));
		remove_head(&response_buf, saMac, 8, 'A');
		HsmLog(logfile,log_level,__FILE__,__LINE__,"msg mac:[%8.8s]",  &hsmMsgIn->hsmOpr.saEnc[16]);
		HsmLog(logfile,log_level,__FILE__,__LINE__,"hsm mac:[%8.8s]",  saMac);
		if(memcmp(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8) == 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmracal_VerifyMac End!");
			return HSM_SUCCESS;
		}
		else
			return HSM_FAIL;
	}
	else
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_VerifyMac:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsmracal_VerifyMacWithKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	return HSM_FAIL;
}

int hsmracal_VerifyMacWithKey4POS(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac1[16+1],saMac2[16+1],saMac3[16+1],saMac4[16+1],saMac5[16+1],saMac6[16+1],saMacKey[16+1];
	char	saMac33[16+1];
	char	saMacBlockLen[4+1];
	char	sBufLen[2];
	int	iResult,j;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 8);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

	memset(saMac1,0,sizeof(saMac1));
	calc_mac_8(hsmMsgIn->hsmOpr.saMacBlock, atoi(saMacBlockLen), saMac1);
	memset(saMac2,0,sizeof(saMac2));
	Hex2Str(saMac1, saMac2, 8);

	if(head_len != 0)
	{
		memset( &gsMsgHead[0], 0, head_len);
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');
	}

   	add_tail(&operate_buf, "MS", 2, 'A');
	add_tail(&operate_buf, "0000", 4, 'A');
   	add_tail(&operate_buf, &saMacKey[0], 16, 'A');
	add_tail(&operate_buf, "0", 1, 'A');
	add_tail(&operate_buf, "008", 3, 'A');
	add_tail(&operate_buf, &saMac2[0], 8, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) == 0)
    	{
        	remove_head(&response_buf, saMac3, 16, 'A');
		Str2Hex(saMac3, saMac33, 16);
		memset(saMac4,0,sizeof(saMac4));
		for(j=0;j<8;j++) saMac4[j]=saMac33[j]^saMac2[8+j];

		clear_string(&operate_buf);
		clear_string(&response_buf);

		if(head_len != 0)
		{
			memset( &gsMsgHead[0], 0, head_len);
			add_tail(&operate_buf, gsMsgHead, head_len, 'A');
		}

		add_tail(&operate_buf, "MS", 2, 'A');
		add_tail(&operate_buf, "0000", 4, 'A');
		add_tail(&operate_buf, &saMacKey[0], 16, 'A');
		add_tail(&operate_buf, "0", 1, 'A');
		add_tail(&operate_buf, "008", 3, 'A');
		add_tail(&operate_buf, &saMac4[0], 8, 'A');

		iResult = hsmracal_cmd(&operate_buf, &response_buf);
		if(iResult != HSM_SUCCESS) return HSM_FAIL;

		remove_head(&response_buf, sBufLen, 2, 'A');

		if(head_len != 0)
			remove_head(&response_buf, sMsgHead, head_len, 'A');
		remove_head(&response_buf, hsmracal_response_code, 2, 'A');
		remove_head(&response_buf, err_code, 2, 'A');
		if(memcmp(err_code, "00", 2) == 0)
		{
			remove_head(&response_buf, saMac5, 8, 'A');
			if(memcmp(saMac5, &hsmMsgIn->hsmOpr.saEnc[16], 8) == 0)
				return HSM_SUCCESS;
			else
				return HSM_FAIL;
		}
		else
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmracal_VerifyMacWithKey4POS:error[%c%c]!", err_code[0],err_code[1] );
			return HSM_FAIL;
		}
	}
	else
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_VerifyMacWithKey4POS:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsmracal_ConvertPINKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saLMacKey[48+1],sLFlg[2];
	char	saMacBlockLen[4+1];
	int		iResult,nKeyFlag;
	char	saKeyIndex[3];
	char	sBufLen[2];

		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmracal_ConvertPINKey start." );
	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
	{
		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmSourKey->index[0][%d]",hsmSourKey->index[0] );
		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmDestKey->index[0][%d]",hsmDestKey->index[0] );
		return HSM_FAIL;
	}

	nKeyFlag = PIN_KEY_TYPE;
	
	if(head_len != 0)
	{
		memset(&gsMsgHead[0], 0, head_len);
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');
	}

	add_tail(&operate_buf, "FA", 2, 'A');
	if(hsmSourKey->index[0] != 0)
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmSourKey->keyindex,2);
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
	}
	else
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmDestKey->keyindex,2);
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmDestKey->bmk[0], 32, 'A');
	}
	
	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, hsmMsgIn->hsmOpr.saZPK, 32, 'A');

	HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"operate_buf[%s]",operate_buf.str_content );
	HsmLog("fclracal.log",log_level,__FILE__,__LINE__,
		"hsmracal_ConvertPINKey:start!" );
	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ConvertPINKey:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0) /* mod by chenwu 2010.8.19 */
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_ConvertPINKey:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	memset(saLMacKey, 0, sizeof(saLMacKey));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saLMacKey, 32, 'A');

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"saKeyIndex[%s],nKeyFlag[%d]",saKeyIndex,nKeyFlag );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"saLMacKey[%s]",saLMacKey );

	if(lModifyKeyData(saKeyIndex,nKeyFlag,saLMacKey) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_ConvertPINKey:to modify keyfile failure!");
		return HSM_FAIL;
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"lModifyKeyData:ok!" );
	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmracal_ConvertPINKey End!");

	return HSM_SUCCESS;
}

int hsmracal_ConvertMACKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
    char	saMac1[8+1],saMac2[8+1],saMacKey[32+1];
	char	saLMacKey[48+1],sLFlg[2];
	char	saMacBlockLen[4+1];
	int		iResult,nKeyFlag;
	char	saKeyIndex[3];
	char	sBufLen[2];

		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmracal_ConvertMACKey start." );
	clear_string(&operate_buf);
	clear_string(&response_buf);
    
    memset(saMac1, 0, sizeof(saMac1));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 16);
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[20], &saMac1[0], 8);
	
	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
	{
		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmSourKey->index[0][%d]",hsmSourKey->index[0] );
		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmDestKey->index[0][%d]",hsmDestKey->index[0] );
		return HSM_FAIL;
	}

	nKeyFlag = MAC_KEY_TYPE;
	
	if(head_len != 0)
	{
		memset(&gsMsgHead[0], 0, head_len);
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');
	}

	add_tail(&operate_buf, "FK", 2, 'A');
	add_tail(&operate_buf, "1", 1, 'A');
	if(hsmSourKey->index[0] != 0)
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmSourKey->keyindex,2);
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
	}
	else
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmDestKey->keyindex,2);
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmDestKey->bmk[0], 32, 'A');
	}
	
	add_tail(&operate_buf, hsmMsgIn->hsmOpr.saZAK, 16, 'A');

	HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"operate_buf[%s]",operate_buf.str_content );
	HsmLog("fclracal.log",log_level,__FILE__,__LINE__,
		"hsmracal_ConvertMACKey:start!" );
	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ConvertMACKey:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_ConvertMACKey:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	memset(saLMacKey, 0, sizeof(saLMacKey));
    remove_head(&response_buf, saLMacKey, 16, 'A');
    memcpy(saLMacKey+16,"0000000000000000",16);
    HsmLog(logfile,log_level,__FILE__,__LINE__,
            "saLMacKey:[%16.16s]", saLMacKey);
    
    memset(saMac2, 0, sizeof(saMac2));
	remove_head(&response_buf, saMac2, 8, 'A');
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsm chkval:[%8.8s], oth chkval:[%8.8s]", saMac2, saMac1);

	if(memcmp(saMac1,saMac2,8) != 0)
	{
		memset(saMac2, 0, sizeof(saMac2));
		remove_head(&response_buf, saMac2, 8, 'A');
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm chkval:[%8.8s], oth chkval:[%8.8s]", saMac2, saMac1);
		if(memcmp(saMac1,saMac2,8) != 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmracal_ChangeKey:compare checkvalue failure!");
			return HSM_FAIL;
		}
	}
    
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"saKeyIndex[%s],nKeyFlag[%d]",saKeyIndex,nKeyFlag );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"saLMacKey[%s]",saLMacKey );

	if(lModifyKeyData(saKeyIndex,nKeyFlag,saLMacKey) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_ConvertPINKey:to modify keyfile failure!");
		return HSM_FAIL;
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"lModifyKeyData:ok!" );
	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmracal_ConvertPINKey End!");

	return HSM_SUCCESS;
}

int hsmracal_ChangeKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac1[8+1],saMac2[8+1],saMacKey[32+1];
	char	saLMacKey[48+1],sLFlg[2];
	char	saMacBlockLen[4+1];
	int		iResult,nKeyFlag;
	char	saKeyIndex[3];
	char	sBufLen[2];

		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmracal_ChangeKey start." );
	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
	{
		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmSourKey->index[0][%d]",hsmSourKey->index[0] );
		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmDestKey->index[0][%d]",hsmDestKey->index[0] );
		return HSM_FAIL;
	}

	if(hsmMsgIn->hsmOpr.saEncWay[0] == '1')
		nKeyFlag = PIN_KEY_TYPE;
	else if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		nKeyFlag = MAC_KEY_TYPE;
	else
	{
		HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"hsmMsgIn->hsmOpr.saEncWay[0][%d]",hsmMsgIn->hsmOpr.saEncWay[0] );
		return HSM_FAIL;
	}
	memset(saMac1, 0, sizeof(saMac1));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 16);
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[20], &saMac1[0], 8);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

	if(head_len != 0)
	{
		memset(&gsMsgHead[0], 0, head_len);
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');
	}

	if (nKeyFlag == PIN_KEY_TYPE)
		add_tail(&operate_buf, "FA", 2, 'A');
	else
	{
		add_tail(&operate_buf, "FK", 2, 'A');
		add_tail(&operate_buf, "1", 1, 'A');
	}

	if(hsmSourKey->index[0] != 0)
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmSourKey->keyindex,2);
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
	}
	else
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmDestKey->keyindex,2);
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &hsmDestKey->bmk[0], 32, 'A');
	}
	if(memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "16", 2) == 0 ||
	    memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "26", 2) == 0)
	{
		add_tail(&operate_buf, "X", 1, 'A');
		add_tail(&operate_buf, &saMacKey[0], 32, 'A');
	}
	else
	{
		add_tail(&operate_buf, &saMacKey[0], 16, 'A');
	}

	HsmLog("fclracal.log",log_level,__FILE__,__LINE__,"operate_buf[%s]",operate_buf.str_content );
	HsmLog("fclracal.log",log_level,__FILE__,__LINE__,
		"hsmracal_ChangeKey:start!" );
	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ChangeKey:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0 && memcmp(err_code, "01", 2) != 0) /* mod by chenwu 2010.8.19 */
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_ChangeKey:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	memset(saLMacKey, 0, sizeof(saLMacKey));
	if(memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "16", 2) == 0 ||
	    memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "26", 2) == 0)
	{
		remove_head(&response_buf, sLFlg, 1, 'A');
		remove_head(&response_buf, saLMacKey, 32, 'A');
	}
	else
	{

		remove_head(&response_buf, saLMacKey, 16, 'A');
		memcpy(saLMacKey+16,"0000000000000000",16);
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"saLMacKey:[%16.16s]", saLMacKey);
	}

	memset(saMac2, 0, sizeof(saMac2));
	remove_head(&response_buf, saMac2, 8, 'A');
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsm chkval:[%8.8s], oth chkval:[%8.8s]", saMac2, saMac1);

	if(memcmp(saMac1,saMac2,8) != 0)
	{
		memset(saMac2, 0, sizeof(saMac2));
		remove_head(&response_buf, saMac2, 8, 'A');
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm chkval:[%8.8s], oth chkval:[%8.8s]", saMac2, saMac1);
		if(memcmp(saMac1,saMac2,8) != 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmracal_ChangeKey:compare checkvalue failure!");
			return HSM_FAIL;
		}
	}

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"saKeyIndex[%s],nKeyFlag[%d]",saKeyIndex,nKeyFlag );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"saLMacKey[%s]",saLMacKey );

	if(lModifyKeyData(saKeyIndex,nKeyFlag,saLMacKey) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_ChangeKey:to modify keyfile failure!");
		return HSM_FAIL;
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"lModifyKeyData:ok!" );
	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmracal_ChangeKey End!");

	return HSM_SUCCESS;
}

int hsmracal_GenTMK(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac1[8+1],saMac2[8+1],saMacKey[32+1];
	char	saTMK1[32+1],saTMK2[32+1],saTMKChkV[8+1];
	char	saLMacKey[48+1],sLFlg[2];
	char	saMacBlockLen[4+1];
	int	iResult,nKeyFlag;
	char	saKeyIndex[3];
	char	sBufLen[2];

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "HC", 2, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	/*add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 32, 'A');*/
	add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
   	add_tail(&operate_buf, ";XX0", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenTMK:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenTMK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	/**********
	memset(saTMK1, 0, sizeof(saTMK1));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saTMK1, 32, 'A');
	memset(saTMK2, 0, sizeof(saTMK2));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saTMK2, 32, 'A');

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "FE", 2, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &saTMK2[0], 32, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenTMK:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenTMK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	*****/
	memset(saTMK1, 0, sizeof(saTMK1));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saTMK1, 32, 'A');
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saTMK2, 32, 'A');
	remove_head(&response_buf, saTMKChkV, 16, 'A');

	memcpy(&hsmMsgIn->hsmOpr.saTMK[0],saTMK1,32);
	memcpy(&hsmMsgIn->hsmOpr.saTMKLMK[0],saTMK2,32);
	memcpy(&hsmMsgIn->hsmOpr.saTMKChkV[0],saTMKChkV,8);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"chkv:[%s]", saTMKChkV);

	return HSM_SUCCESS;
}

int hsmracal_GenTWK(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saTMK[32+1],saPIK[32+1],saMAK[32+1],saTRK[32+1];
	char	saPIKChkV[8+1],saMAKChkV[8+1],saTRKChkV[8+1];
	char	saTMK1[32+1],saTMK2[32+1];
	char	saLMacKey[48+1],sLFlg[2];
	char	saMacBlockLen[4+1];
	int	iResult,nKeyFlag;
	char	sBufLen[2];

	memset(saTMK, 0, sizeof(saTMK));
	memcpy(&saTMK[0], &hsmMsgIn->hsmOpr.saTMK[0], 32);

	/* GEN PIK */
	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "HC", 2, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &saTMK[0], 32, 'A');
   	add_tail(&operate_buf, ";XX0", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenTWK TPK:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenTWK TPK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	memset(saTMK1, 0, sizeof(saTMK1));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saTMK1, 32, 'A');
	memset(saTMK2, 0, sizeof(saTMK2));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saTMK2, 32, 'A');

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "BU", 2, 'A');
	add_tail(&operate_buf, "FF", 2, 'A');
	add_tail(&operate_buf, "1", 1, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &saTMK2[0], 32, 'A');
	add_tail(&operate_buf, ";", 1, 'A');
   	add_tail(&operate_buf, "002", 3, 'A');
   	add_tail(&operate_buf, ";XX0", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenTWK TPK CHV:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenTWK TPK CHV:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}

	memset(saPIKChkV, 0, sizeof(saPIKChkV));
	remove_head(&response_buf, saPIKChkV, 8, 'A');

	memcpy(&hsmMsgIn->hsmOpr.saPIK[0],saTMK1,32);
	memcpy(&hsmMsgIn->hsmOpr.saPIKLMK[0],saTMK2,32);
	memcpy(&hsmMsgIn->hsmOpr.saPIKChkV[0],saPIKChkV,8);

	/* MAK */
	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "HA", 2, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &saTMK[0], 32, 'A');
   	add_tail(&operate_buf, ";ZZ0", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenTWK TAK:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenTWK TAK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	memset(saTMK1, 0, sizeof(saTMK1));
	memset(saTMK2, 0, sizeof(saTMK2));
	remove_head(&response_buf, saTMK1, 16, 'A');
	remove_head(&response_buf, saTMK2, 16, 'A');

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "BU", 2, 'A');
	add_tail(&operate_buf, "FF", 2, 'A');
	add_tail(&operate_buf, "0", 1, 'A');

	add_tail(&operate_buf, &saTMK2[0], 16, 'A');
	add_tail(&operate_buf, ";", 1, 'A');
   	add_tail(&operate_buf, "003", 3, 'A');
   	add_tail(&operate_buf, ";ZZ0", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenTWK TAK CHV:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenTWK TAK CHV:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}

	memset(saMAKChkV, 0, sizeof(saMAKChkV));
	remove_head(&response_buf, saMAKChkV, 8, 'A');

	memcpy(&hsmMsgIn->hsmOpr.saMAK[0],saTMK1,16);
	memcpy(&hsmMsgIn->hsmOpr.saMAK[16],"0000000000000000",16);
	memcpy(&hsmMsgIn->hsmOpr.saMAKLMK[0],saTMK2,16);
	memcpy(&hsmMsgIn->hsmOpr.saMAKLMK[16],"0000000000000000",16);
	memcpy(&hsmMsgIn->hsmOpr.saMAKChkV[0],saMAKChkV,8);

	/* TRK */
	/***
	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "HC", 2, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &saTMK[0], 32, 'A');
   	add_tail(&operate_buf, ";XX0", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenTWK PIK:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenTWK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	memset(saTMK1, 0, sizeof(saTMK1));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saTMK1, 32, 'A');
	memset(saTMK2, 0, sizeof(saTMK2));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saTMK2, 32, 'A');

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "BU", 2, 'A');
	add_tail(&operate_buf, "FF", 2, 'A');
	add_tail(&operate_buf, "1", 1, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &saTMK2[0], 32, 'A');
	add_tail(&operate_buf, ";", 1, 'A');
   	add_tail(&operate_buf, "002", 3, 'A');
   	add_tail(&operate_buf, ";XX0", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenTMK:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenTMK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}

	memset(saTRKChkV, 0, sizeof(saTRKChkV));
	remove_head(&response_buf, saTRKChkV, 16, 'A');

	memcpy(&hsmMsgIn->hsmOpr.saTRK[0],saTMK1,32);
	memcpy(&hsmMsgIn->hsmOpr.saTRKLMK[0],saTMK2,32);
	memcpy(&hsmMsgIn->hsmOpr.saTRKChkV[0],saTRKChkV,8);
	****/

	return HSM_SUCCESS;
}

int hsmracal_GenZAK(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saZAK1[33],saZAK2[33],saZAKChkV[7];
	char	saLMacKey[48],sLFlg[2];
	char	saMacBlockLen[4];
	int	iResult,nKeyFlag;
	char	saKeyIndex[3];
	char	sBufLen[2];

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "FI", 2, 'A');
	add_tail(&operate_buf, "1", 1, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
	/*add_tail(&operate_buf, ";XX0", 4, 'A');*/
	add_tail(&operate_buf, ";ZZ1", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenZAK:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenZAK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	memset(saZAK1, 0, sizeof(saZAK1));
	/*remove_head(&response_buf, sLFlg, 1, 'A');*/
	remove_head(&response_buf, saZAK1, 16, 'A');
	memset(saZAK1+16, '0', 16);
	memset(saZAK2, 0, sizeof(saZAK2));
	/*remove_head(&response_buf, sLFlg, 1, 'A');*/
	remove_head(&response_buf, saZAK2, 16, 'A');
	memset(saZAK2+16, '0', 16);
	memset(saZAKChkV, 0, sizeof(saZAKChkV));
	remove_head(&response_buf, saZAKChkV, 6, 'A');

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenZAK:saZAK1[%32.32s]!", saZAK1 );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenZAK:saZAK2[%32.32s]!", saZAK2 );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenZAK:saZAKChkV[%6.6s]!", saZAKChkV );

	memcpy(&hsmMsgIn->hsmOpr.saZAK[0],saZAK1,32);
	memcpy(&hsmMsgIn->hsmOpr.saZAKLMK[0],saZAK2,32);
	memcpy(&hsmMsgIn->hsmOpr.saZAKChkV[0],saZAKChkV,6);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmracal_GenZAK End!");

	return HSM_SUCCESS;
}

int hsmracal_GenZPK(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saZPK1[33],saZPK2[33],saZPKChkV[17];
	char	saLMacKey[48],sLFlg[2];
	char	saMacBlockLen[4];
	int	iResult,nKeyFlag;
	char	saKeyIndex[3];
	char	sBufLen[2];

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "IA", 2, 'A');

	add_tail(&operate_buf, "X", 1, 'A');
	add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
   	add_tail(&operate_buf, ";XX0", 4, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenZPK:ok!" );

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenZPK:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
	memset(saZPK1, 0, sizeof(saZPK1));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saZPK1, 32, 'A');
	memset(saZPK2, 0, sizeof(saZPK2));
	remove_head(&response_buf, sLFlg, 1, 'A');
	remove_head(&response_buf, saZPK2, 32, 'A');
	memset(saZPKChkV, 0, sizeof(saZPKChkV));
	remove_head(&response_buf, saZPKChkV, 16, 'A');

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenZPK:saZPK1[%32.32s]!", saZPK1 );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenZPK:saZPK2[%32.32s]!", saZPK2 );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_GenZPK:saZPKChkV[%8.8s]!", saZPKChkV );

	memcpy(&hsmMsgIn->hsmOpr.saZPK[0],saZPK1,32);
	memcpy(&hsmMsgIn->hsmOpr.saZPKLMK[0],saZPK2,32);
	memcpy(&hsmMsgIn->hsmOpr.saZPKChkV[0],saZPKChkV,8);
	HsmLog(logfile,log_level,__FILE__,__LINE__,"hsmracal_GenZPK End!");

	return HSM_SUCCESS;
}

int hsmracal_ChangeZAK(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saZAK[32+1];
	int	iResult,nKeyFlag;
	char	saKeyIndex[3];

	if(hsmSourKey->index[0] != 0)
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmSourKey->keyindex,2);

	}
	else
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmDestKey->keyindex,2);
	}

	nKeyFlag = MAC_KEY_TYPE;

	memset(saZAK,0,sizeof(saZAK));
	memcpy(saZAK,&hsmMsgIn->hsmOpr.saZAKLMK[0],32);

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ChangeZAK:saKeyIndex[%s],nKeyFlag[%d]",saKeyIndex,nKeyFlag );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ChangeZAK:saZAK[%s]",saZAK);

	if(lModifyKeyData(saKeyIndex,nKeyFlag,saZAK) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_ChangeZAK:to modify keyfile failure!");
		return HSM_FAIL;
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ChangeZAK:lModifyKeyData ok!" );

	return HSM_SUCCESS;
}

int hsmracal_ChangeZPK(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saZPK[32+1];
	int	iResult,nKeyFlag;
	char	saKeyIndex[3];

	if(hsmSourKey->index[0] != 0)
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmSourKey->keyindex,2);

	}
	else
	{
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmDestKey->keyindex,2);
	}

	nKeyFlag = PIN_KEY_TYPE;

	memset(saZPK,0,sizeof(saZPK));
	memcpy(saZPK,&hsmMsgIn->hsmOpr.saZPKLMK[0],32);

	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ChangeZPK:saKeyIndex[%s],nKeyFlag[%d]",saKeyIndex,nKeyFlag );
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ChangeZPK:saZPK[%s]",saZPK);

	if(lModifyKeyData(saKeyIndex,nKeyFlag,saZPK) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_ChangeZPK:to modify keyfile failure!");
		return HSM_FAIL;
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,
		"hsmracal_ChangeZPK:lModifyKeyData ok!" );

	return HSM_SUCCESS;
}

int hsmracal_VerifyARQC(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMacBlockLen[4+1],saMacBLen[4+1],saMac[8+1];
	char	sBufLen[2];
	int	iResult;
	char	saPanData[16+1],saPanLen[3+1];
	char    sARQCData[16+1];
	char    sARCData[3] = {0};
	char    sTemp[100];
	int iDataLen;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;


	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "KW", 2, 'A');
	add_tail(&operate_buf, "1", 1, 'A');
	add_tail(&operate_buf, "9", 1, 'A');
	add_tail(&operate_buf, "X", 1, 'A');
	
	/*HSM_KEYFILE pinkey ���MK-AC*/
	if(hsmSourKey->index[0] != 0)
	    add_tail(&operate_buf, &hsmSourKey->bmk[0], 32, 'A');
	else
	    add_tail(&operate_buf, &hsmDestKey->bmk[0], 32, 'A');
    
    /*HSMOprDef saCardNo ���PAN����
    add_tail(&operate_buf, "08", 2, 'A');*/
    
    /*HSMOprDef saCardNo ���PAN/PAN���к�*/
    memset(sTemp, 0, sizeof(sTemp));
    Str2Hex(&hsmMsgIn->hsmOpr.saCardNo[0], sTemp, 16);
    add_tail(&operate_buf, sTemp, 8, 'A');
    
    /*HSMOprDef saPIKChkV ���ATC*/
    add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saPIKChkV[0], 2, 'A');
    
    /*HSMOprDef saMacBlockLen ��Ž������ݳ���*/
    memset(saPanLen, 0, sizeof(saPanLen));
    Hex2Str(hsmMsgIn->hsmOpr.saMacBlockLen, saPanLen, 1);
    add_tail(&operate_buf, &saPanLen[0], 2, 'A');
    
    memcpy(saPanLen, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 1);
    iDataLen = saPanLen[0];
    HsmLog(logfile,log_level,__FILE__,__LINE__,"���ݳ��� Hex[%2X] iDataLen[%d]", saPanLen[0], iDataLen);
    
    /*HSMOprDef saMacBlock ��Ž�������*/
    add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], iDataLen, 'A');
    
    add_tail(&operate_buf, ";", 1, 'A');
    
    /*HSMOprDef saPIK ���ARQC*/
    memset(sARQCData, 0, sizeof(sARQCData));
    add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saPIK[0], 8, 'A');
    
    /*ARC 
    add_tail(&operate_buf, sARCData, 2, 'A');*/
    
    /* ARC */
    add_tail(&operate_buf, "00", 2, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) == 0)
	{
		memset(saMac, 0, sizeof(saMac));
		remove_head(&response_buf, saMac, 8, 'A');
		memcpy(&hsmMsgIn->hsmOpr.saEnc[0],saMac,8);
		/*HsmLog(logfile,log_level,__FILE__,__LINE__,"ARPC:[%8.8s]",  saMac);*/
		return HSM_SUCCESS;
	}
	else
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_VerifyARQC:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsmracal_GenScriptMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMacBlockLen[4+1],saMacBLen[4+1],saMac[16+1];
	char	sBufLen[2];
	int	iResult;
	char	saPanData[16+1],saPanLen[3+1];
	char    sARQCData[16+1];
	char    sARCData[3] = {0};
	char    sTemp[100];
	int iDataLen;

	clear_string(&operate_buf);
	clear_string(&response_buf);
HsmTrace(logfile,trace_level, hsmMsgIn->hsmOpr.saMacBlock, 10, __FILE__,__LINE__);
	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;


	if(head_len != 0)
		add_tail(&operate_buf, gsMsgHead, head_len, 'A');

	add_tail(&operate_buf, "UB", 2, 'A');
	add_tail(&operate_buf, "1", 1, 'A');
	add_tail(&operate_buf, "3", 1, 'A');
	add_tail(&operate_buf, "109", 3, 'A');
	add_tail(&operate_buf, "X", 1, 'A');
	
	/*HSM_KEYFILE pinkey ���MK-AC*/
	if(hsmSourKey->index[0] != 0)
	    add_tail(&operate_buf, &hsmSourKey->mackey1[0], 32, 'A');
	else
	    add_tail(&operate_buf, &hsmDestKey->mackey1[0], 32, 'A');
    
    add_tail(&operate_buf, "1", 1, 'A');
    
    /*HSMOprDef saCardNo �����ɢ����*/
    add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saCardNo[0], 16, 'A');
    
    /*HSMOprDef saPIKChkV ��Ź������� ATC*/
    memset(sTemp, '0', sizeof(sTemp));
    add_tail(&operate_buf, sTemp, 12, 'A');
    add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saPIKChkV[0], 4, 'A');
    
    add_tail(&operate_buf, "1", 1, 'A');
    
    /*IV-MAC Ĭ��ֵ8BYTE 0*/
    memset(sTemp, '0', sizeof(sTemp));
    add_tail(&operate_buf, sTemp, 16, 'A');
    
    /*HSMOprDef saMacBlockLen ���MAC�������ݳ���*/
    add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'A');
    memset(saPanLen, 0, sizeof(saPanLen));
    memcpy(saPanLen, hsmMsgIn->hsmOpr.saMacBlockLen, 3);
    
    /*HSMOprDef saMacBlock ���MAC��������*/
    memset(sTemp, 0, sizeof(sTemp));
    HsmTrace(logfile,trace_level, hsmMsgIn->hsmOpr.saMacBlock, atoi(saPanLen), __FILE__,__LINE__);
    Hex2Str(&hsmMsgIn->hsmOpr.saMacBlock[0], sTemp, atoi(saPanLen)); 
    HsmTrace(logfile,trace_level, sTemp, atoi(saPanLen)*2, __FILE__,__LINE__);
    add_tail(&operate_buf, sTemp, atoi(saPanLen)*2, 'A');
    
    add_tail(&operate_buf, "2", 1, 'A');

	iResult = hsmracal_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, sBufLen, 2, 'A');

	if(head_len != 0)
		remove_head(&response_buf, sMsgHead, head_len, 'A');
	remove_head(&response_buf, hsmracal_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code, "00", 2) == 0)
	{
		memset(saMac, 0, sizeof(saMac));
		remove_head(&response_buf, saMac, 8, 'A');
		memcpy(&hsmMsgIn->hsmOpr.saEnc[0],saMac,8);
		/*HsmLog(logfile,log_level,__FILE__,__LINE__,"ARPC:[%8.8s]",  saMac);*/
		return HSM_SUCCESS;
	}
	else
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmracal_GenScriptMac:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}
