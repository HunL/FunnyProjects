#ifndef _SOFTENC_H
#define _SOFTENC_H

#define ENC_SUCC  0
#define ENC_FAIL -1

#define MAX_MAC_ELEMENT_LEN		512
#define MAX_MAC_ELEMENT_LEN_LEN		3

#define MAX_ENC_DATA_LEN		1024	

#define MAC_LEN 8
#define PIN_LEN 8
#define KEY_LEN 8

#define DB_PIN_LEN 16
#define DB_MAC_LEN 16
#define DB_KEY_LEN 16

int isHexStr( char *sSrc, int nLen );
void Hex2Str( char *sSrc,  char *sDest, int nSrcLen );
int Str2Hex( char *sSrc, char *sDest, int nSrcLen );
int isIBMPin( char *sPin );
int EncipherKey( char *sEncBmk, char *sPlainKey, char *sEncKey );
int DecipherPin( char *sEncBmk, char *sEncPinKey, char *sHexEncPin, char *sCustomPin );
int EncipherPin( char *sEncBmk, char *sEncPinKey,char *sCustomPin,char *sHexEncPin);
int VerifyMac( char *sEncBmk, char *sEncMacKey, char *sMac, char *sMacElement, int nMacElementLen );
int GenMac( char *sEncBmk, char *sEncMacKey, char *sMacElement, int nMacElementLen, char *sMac );
int TranslatePin (char *SrcEncBmk, char *DesEncBmk, char *SrcEncPinKey,char *DesEncPinKey,char *SrcHexEncPin,char *DesHexEncPin);
int EncipherKeyUseKey( char *sZmk,char *sPlainKey, char *sEncKey );

#endif
