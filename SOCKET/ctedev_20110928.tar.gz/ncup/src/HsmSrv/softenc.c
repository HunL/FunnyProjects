#include "hsmsrv.h"
#include "softenc.h"

extern int	trace_level,log_level;

void vBitXOR( char * InputString, char * Key, 
			char * OutputString, short Length)
{
	short i, k = 0;

	for( i = 0; i < Length; i++)
	{
		OutputString[i] = InputString[i] ^ Key[k];
 		k = (k + 1) % 8;	
	}
}  

int isHexStr( char *sSrc, int nLen )
{
	int i;

	for( i = 0; i < nLen; i++ )
		if( !isxdigit(sSrc[i]) )
			return 0;

	return 1;

}

void Hex2Str( char *sSrc,  char *sDest, int nSrcLen )
{
	int  i;
	char szTmp[3];
  
	for( i = 0; i < nSrcLen; i++ )
	{
		sprintf( szTmp, "%02X", (unsigned char) sSrc[i] );
		memcpy( &sDest[i * 2], szTmp, 2 );
	}

}

int Str2Hex( char *sSrc, char *sDest, int nSrcLen )
{
	int i, nHighBits, nLowBits;
	
	for( i = 0; i < nSrcLen; i += 2 )
	{
		nHighBits = sSrc[i];
		nLowBits  = sSrc[i + 1];

		if( nHighBits > 0x39 ) 
			nHighBits -= 0x37;
		else
			nHighBits -= 0x30;
					
		if( i == nSrcLen - 1 )
			nLowBits = 0;
		else if( nLowBits > 0x39 ) 
			nLowBits -= 0x37;
		else
			nLowBits -= 0x30;
			
		sDest[i / 2] = (nHighBits << 4) | (nLowBits & 0x0f);
	}

	return 0;
}

int EncipherKey( char *sEncBmk, char *sPlainKey, char *sEncKey )
{
	char sHexPlainKey[KEY_LEN];
	char sHexEncKey[KEY_LEN];
	char sHexMasterKey[KEY_LEN*2];
	
	if( Str2Hex( sPlainKey, sHexPlainKey, DB_KEY_LEN ) )
		return -1;

	if( Str2Hex( sEncBmk, sHexMasterKey, DB_KEY_LEN*2 ) )
		return -2;
		
	EncipherSingleKey( sHexMasterKey, sHexPlainKey, sHexEncKey);
	Hex2Str( sHexEncKey, sEncKey, KEY_LEN );
	return 0;
}

int EncipherKeyUseKey( char *sZmk,char *sPlainKey, char *sEncKey )
{
	char sHexPlainKey[KEY_LEN];
	char sHexEncKey[KEY_LEN];
	char sHexPlainZmk[KEY_LEN];
	
	if( Str2Hex( sPlainKey, sHexPlainKey, DB_KEY_LEN ) )
		return -1;

	if( Str2Hex( sZmk, sHexPlainZmk, DB_KEY_LEN ) )
		return -2;

	EncipherHalfKey( sHexPlainZmk, sHexPlainKey , sHexEncKey );
	Hex2Str( sHexEncKey, sEncKey, KEY_LEN );
	return 0;
}

int isIBMPin( char *sPin )
{
	int i, j;

	if( memcmp(&sPin[0],"04",2) != 0 && memcmp(&sPin[0],"06",2) != 0 ) 
		return 0;

	for( i = 0; i < DB_PIN_LEN; i++ )
		if( !isdigit(sPin[i]) )
			break;
	
	for( j = i; j < DB_PIN_LEN; j++ )
		if( sPin[j] != 'F' )
			break;

	if( j < DB_PIN_LEN ) return 0;

	return i;
}

int DecipherPin(char *sEncBmk, char *sEncPinKey, 
				char *sHexEncPin, char *sCustomPin )
{
	char sHexEncPik[KEY_LEN], sHexPlainPik[KEY_LEN];
	char sHexPlainPin[PIN_LEN], sPlainPin[DB_PIN_LEN];
	int  nPinLen;
	char sHexMasterKey[KEY_LEN*2];
	
	if( Str2Hex( sEncPinKey, sHexEncPik, DB_KEY_LEN ) )
		return -1;
	
	if( Str2Hex( sEncBmk, sHexMasterKey, DB_KEY_LEN*2 ) )
		return -2;

	DecipherSingleKey( sHexMasterKey, sHexEncPik , sHexPlainPik );
	DecipherHalfKey( sHexPlainPik, sHexEncPin , sHexPlainPin );

	/*
	Hex2Str( sHexPlainPin, sPlainPin, PIN_LEN );

	nPinLen = isIBMPin( sPlainPin );
	if( !nPinLen )
		return -3;
	*/

	memcpy( sCustomPin, sHexPlainPin, PIN_LEN);

	return 0;
}

int EncipherPin(char *sEncBmk, char *sEncPinKey,
				char *sCustomPin,char *sHexEncPin)
{
	char sHexEncPik[KEY_LEN], sHexPlainPik[KEY_LEN];
	char sHexPlainPin[PIN_LEN], sPlainPin[DB_PIN_LEN];
	int  nPinLen,i;
	char sHexMasterKey[KEY_LEN*2];
	
	if( Str2Hex( sEncPinKey, sHexEncPik, DB_KEY_LEN ) )
		return -1;
	
	if( Str2Hex( sEncBmk, sHexMasterKey, DB_KEY_LEN*2 ) )
		return -2;

	DecipherSingleKey( sHexMasterKey, sHexEncPik , sHexPlainPik );

	EncipherHalfKey( sHexPlainPik, sCustomPin, sHexEncPin );

	return 0;
}

int VerifyMac( 	char *sEncBmk, char *sEncMacKey, 
				char *sMac, char *sMacElement, int nMacElementLen )
{
	int i, nRet;
	char sNewMac[DB_MAC_LEN];
	
	nRet = GenMac(sEncBmk, sEncMacKey, sMacElement, nMacElementLen, sNewMac);
	
	if( nRet ) return nRet;
	
	for( i = 0; i < MAC_LEN; i++ )
		if( sNewMac[i] != sMac[i] )
			return -1;
	return 0;

}

int GenMac( char *sEncBmk, char *sEncMacKey, 
			char *sMacElement, int nMacElementLen, 
            char *sMac )
{
	char sHexEncMak[KEY_LEN], sHexPlainMak[KEY_LEN];
	char sHexMac[MAC_LEN];
	int  i;	
	char sHexMasterKey[KEY_LEN*2];
	
	if( nMacElementLen > MAX_MAC_ELEMENT_LEN )
		return -1;
	
	if( Str2Hex( sEncMacKey, sHexEncMak, DB_KEY_LEN ) )
		return -2;
	
	if( Str2Hex( sEncBmk, sHexMasterKey, DB_KEY_LEN*2 ) )
		return -3;

 	if( DecipherSingleKey( sHexMasterKey, sHexEncMak , sHexPlainMak ) )
		return -4;

	if( EnMAC( sMacElement, nMacElementLen, sHexPlainMak, sHexMac ) )
		return -5;

	Hex2Str( sHexMac, sMac, MAC_LEN );
	sMac[MAC_LEN]=0;

	return 0;

}

int TranslatePin( char *SrcEncBmk, char *DesEncBmk, 
				char *SrcEncPinKey,char *DesEncPinKey,
				char *SrcHexEncPin,char *DesHexEncPin)
{
	char SrcHexEncPik[KEY_LEN], SrcHexPlainPik[KEY_LEN];
	char DesHexEncPik[KEY_LEN], DesHexPlainPik[KEY_LEN];
	char SrcHexPlainPin[PIN_LEN];
	int  nPinLen;
	char SrcHexBmk[KEY_LEN*2],DesHexBmk[KEY_LEN*2];
	
	if( Str2Hex( SrcEncPinKey, SrcHexEncPik, DB_KEY_LEN ) )
		return -1;

	if( Str2Hex( DesEncPinKey, DesHexEncPik, DB_KEY_LEN ) )
		return -2;

	if( Str2Hex( SrcEncBmk, SrcHexBmk, DB_KEY_LEN*2 ) )
		return -3;

	if( Str2Hex( DesEncBmk, DesHexBmk, DB_KEY_LEN*2 ) )
		return -4;

	DecipherSingleKey( SrcHexBmk, SrcHexEncPik, SrcHexPlainPik );

	DecipherSingleKey( DesHexBmk, DesHexEncPik, DesHexPlainPik );

	DecipherHalfKey( SrcHexPlainPik, SrcHexEncPin , SrcHexPlainPin );

	EncipherHalfKey( DesHexPlainPik, SrcHexPlainPin , DesHexEncPin );

	return 0;
}
