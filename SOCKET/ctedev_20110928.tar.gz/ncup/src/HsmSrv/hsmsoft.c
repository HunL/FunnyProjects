#include "hsmsrv.h"

extern int	trace_level,log_level;

int hsmsoft_SndRcv(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn) 
{
	int iResult;

	switch(hsmMsgIn->hsmOpr.saOprType)
	{
		case HSM_TEST:
			iResult = 0;
			break;

		case HSM_TRANSPIN:
			iResult = hsmsoft_TransPin( hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_GENMAC:
			iResult = hsmsoft_GenMac(	hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_VERIFYMAC:
			iResult = hsmsoft_VerifyMac(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_VERIFYMACWITHKEY:
			iResult = hsmsoft_VerifyMacWithKey(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_GENMACWITHKEY:
			iResult = hsmsoft_GenMacWithKey(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_CHANGEKEY:
			iResult = hsmsoft_ChangeKey(hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

	}			
	return iResult;
}

int hsmsoft_TransPin(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	int		iResult,nPinLen;
	char	saPanData[16],saPanTmp[8];
	char	saPanLen[3];
	char	saPlainPin[16];

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
		iResult = TranslatePin( &hsmSourKey->bmk[0],
								&hsmDestKey->bmk[0],
								&hsmSourKey->pinkey1[0],
								&hsmDestKey->pinkey1[0],
								&hsmMsgIn->hsmOpr.saEnc[0],
								&hsmMsgIn->hsmOpr.saEnc[0]);
	else if(hsmSourKey->index[0] != 0)
	{
		iResult = DecipherPin( &hsmSourKey->bmk[0],
							&hsmSourKey->pinkey1[0],
							&hsmMsgIn->hsmOpr.saEnc[0],
							&hsmMsgIn->hsmOpr.saEnc[0]);
		if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		{
			memset(saPanData,'0',sizeof(saPanData));
			memset(saPanLen,0,sizeof(saPanLen));
			memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
			memcpy(&saPanData[4],
				&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
			Str2Hex(saPanData,saPanTmp,16);
			vBitXOR(&hsmMsgIn->hsmOpr.saEnc[0], saPanTmp, 
					&hsmMsgIn->hsmOpr.saEnc[0], 8);
		}

		Hex2Str(&hsmMsgIn->hsmOpr.saEnc[0], saPlainPin, PIN_LEN );

		nPinLen = isIBMPin( saPlainPin );
		if( !nPinLen )
			iResult = -9;
	}
	else if(hsmDestKey->index[0] != 0)
	{
		if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		{
			memset(saPanData,'0',sizeof(saPanData));
			memset(saPanLen,0,sizeof(saPanLen));
			memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
			memcpy(&saPanData[4],
				&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
			Str2Hex(saPanData,saPanTmp,16);
			vBitXOR(&hsmMsgIn->hsmOpr.saEnc[0], saPanTmp, 
					&hsmMsgIn->hsmOpr.saEnc[0], 8);
		}

		iResult = EncipherPin( &hsmDestKey->bmk[0],
							&hsmDestKey->pinkey1[0],
							&hsmMsgIn->hsmOpr.saEnc[0],
							&hsmMsgIn->hsmOpr.saEnc[0]);
	}
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv: iResult = [%d]", iResult);
	if(iResult)
		return HSM_FAIL;
	else
		return HSM_SUCCESS;
}

int hsmsoft_GenMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16];
	char	saMacBlockLen[4];
	int		iResult;

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);
	if(hsmSourKey->index[0] != 0)
		iResult = GenMac( 	&hsmSourKey->bmk[0],
							&hsmSourKey->mackey1[0],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen),
							&saMac[0]);
	else
		iResult = GenMac( 	&hsmDestKey->bmk[0],
							&hsmDestKey->mackey1[0],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen),
							&saMac[0]);
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv: iResult = [%d]", iResult);
	if(iResult)
	{
		return HSM_FAIL;
	}
	else
	{
		memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8);
		return HSM_SUCCESS;
	}
}

int hsmsoft_GenMacWithKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16],saMacKey[16];
	char	saMacBlockLen[4];
	int		iResult;

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 8);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);
	if(hsmSourKey->index[0] != 0)
		iResult = GenMac( 	&hsmSourKey->bmk[0],
							&saMacKey[0],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen),
							&saMac[0]);
	else
		iResult = GenMac( 	&hsmDestKey->bmk[0],
							&saMacKey[0],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen),
							&saMac[0]);
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv: iResult = [%d]", iResult);
	if(iResult)
	{
		return HSM_FAIL;
	}
	else
	{
		memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8);
		return HSM_SUCCESS;
	}
}

int hsmsoft_VerifyMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16];
	char	saMacBlockLen[4];
	int		iResult;

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);
	if(hsmSourKey->index[0] != 0)
		iResult = VerifyMac(&hsmSourKey->bmk[0],
							&hsmSourKey->mackey1[0],
							&hsmMsgIn->hsmOpr.saEnc[16],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen));
	else
		iResult = VerifyMac(&hsmDestKey->bmk[0],
							&hsmDestKey->mackey1[0],
							&hsmMsgIn->hsmOpr.saEnc[16],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen));
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv: iResult = [%d]", iResult);
	if(iResult)
		return HSM_FAIL;
	else
		return HSM_SUCCESS;
}

int hsmsoft_VerifyMacWithKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMacKey[16];
	char	saMacBlockLen[4];
	int		iResult;

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 8);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);
	if(hsmSourKey->index[0] != 0)
		iResult = VerifyMac(&hsmSourKey->bmk[0],
							&saMacKey[0],
							&hsmMsgIn->hsmOpr.saEnc[16],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen));
	else
		iResult = VerifyMac(&hsmDestKey->bmk[0],
							&saMacKey[0],
							&hsmMsgIn->hsmOpr.saEnc[16],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen));
	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv: iResult = [%d]", iResult);
	if(iResult)
		return HSM_FAIL;
	else
		return HSM_SUCCESS;
}

int hsmsoft_ChangeKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[8],saMacKey[32];
	char	saMacBlockLen[4];
	int		iResult,nKeyFlag;
	char	saKeyIndex[3];

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	if(hsmMsgIn->hsmOpr.saEncWay[0] == '1')
		nKeyFlag = PIN_KEY_TYPE;
	else if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		nKeyFlag = MAC_KEY_TYPE;
	else
		return HSM_FAIL;

	memset(&saMac[0],0,sizeof(saMac));
	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 8);
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[16], &saMac[0], 4);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);
	if(hsmSourKey->index[0] != 0)
	{
		iResult = VerifyMac(&hsmSourKey->bmk[0],
							&saMacKey[0],
							&saMac[0],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen));
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmSourKey->keyindex,2);
	}
	else
	{
		iResult = VerifyMac(&hsmDestKey->bmk[0],
							&saMacKey[0],
							&saMac[0],
							&hsmMsgIn->hsmOpr.saMacBlock[0],
							atoi(saMacBlockLen));
		memset(saKeyIndex,0,sizeof(saKeyIndex));
		memcpy(saKeyIndex,hsmDestKey->keyindex,2);
	}

	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv: iResult = [%d]", iResult);
	if(iResult)
	{
		return HSM_FAIL;
	}

	memcpy(&saMacKey[16],"0000000000000000",16);
	if(lModifyKeyFile(saKeyIndex,nKeyFlag,saMacKey) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsoft_ChangeKey::to modify keyfile failure!");
		return HSM_FAIL;
	}

	return HSM_SUCCESS;
}
