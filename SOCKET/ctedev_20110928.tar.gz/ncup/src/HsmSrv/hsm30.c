#include "hsmsrv.h"

char 		sResult[100];
T_STRING 	operate_buf, response_buf;
char 		hsm30_response_code, err_code[2];
extern int	trace_level,log_level,hsm_type;
extern int	iSocketID;

int hsm30_cmd(T_STRING * p_operate_buf, T_STRING * p_response_buf)
{
	int ret;
 
	HsmTrace(logfile,trace_level,p_operate_buf->str_content,
			p_operate_buf->str_len,__FILE__,__LINE__);

	if(hsm_type == HSM_30_TCP)
	{
		if( (ret = Send2HSM( iSocketID,
					p_operate_buf->str_content,
					p_operate_buf->str_len )) != p_operate_buf->str_len )
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:Send2HSM error!");
			CloseSocket(iSocketID);
			exit(0);
		}

		ret = Recv4HSM( iSocketID, sResult, 300 );
		if(ret<= 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:Recv4HSM error!" );
			CloseSocket(iSocketID);
			exit(0);
		}

		p_response_buf->str_len = ret;
		memcpy(p_response_buf->str_content, sResult, ret);
	}
	else
	{
		ret = SndRcvHSM30COM(iSocketID, p_operate_buf, p_response_buf);
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsm30_SndRcv:SndRcvHSM30COM error [%d]!", ret);
		if (ret < 0) exit(0);
	}
	HsmTrace(logfile,trace_level, p_response_buf->str_content,
			p_response_buf->str_len, __FILE__,__LINE__);

    return HSM_SUCCESS;
} 

int hsm30_SndRcv(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn) 
{
	int iResult;

	switch(hsmMsgIn->hsmOpr.saOprType)
	{
		case HSM_TEST:
			iResult = hsm30_Test(hsmSourKey,
								hsmDestKey,
								hsmMsgIn);
			break;

		case HSM_TRANSPIN:
			iResult = hsm30_TransPin(	hsmSourKey,
										hsmDestKey,
										hsmMsgIn);
			break;

		case HSM_GENMAC:
			iResult = hsm30_GenMac(	hsmSourKey,
									hsmDestKey,
									hsmMsgIn);
			break;

		case HSM_VERIFYMAC:
			iResult = hsm30_VerifyMac(hsmSourKey,
									hsmDestKey,
									hsmMsgIn);
			break;

		case HSM_GENMACWITHKEY:
			iResult = hsm30_GenMacWithKey(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_VERIFYMACWITHKEY:
			iResult = hsm30_VerifyMacWithKey(hsmSourKey,
											hsmDestKey,
											hsmMsgIn);
			break;

		case HSM_CHANGEKEY:
			iResult = hsm30_ChangeKey(hsmSourKey,
									hsmDestKey,
									hsmMsgIn);
	}			
	return iResult;
}

int hsm30_Test(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	int iResult;

	clear_string(&operate_buf);
	clear_string(&response_buf);

	add_tail(&operate_buf, "01", 2, 'R');
	iResult = hsm30_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, &hsm30_response_code, 1, 'A');
	if(hsm30_response_code != 'A')
	{
		remove_head(&response_buf, err_code, 2, 'R');
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}

	return HSM_SUCCESS;
}

int hsm30_TransPin(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	int		iResult,nPinLen;
	char	saPanData[16],saPanLen[3],saPanTmp[8];
	char	saPinTmp[16],saNewPin[16];

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	if(hsmSourKey->index[0] != 0 && hsmDestKey->index[0] != 0)
	{
		memset(&saPinTmp[0],0,sizeof(saPinTmp));
		Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saPinTmp[0], 8);
		
		if( memcmp(hsmSourKey->pinkey1,"0000000000000000",16) == 0 ||
			memcmp(hsmDestKey->pinkey1,"0000000000000000",16) == 0 )
		{	/* DES */
   			add_tail(&operate_buf, "61", 2, 'R');
    		add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 16, 'R');
    		add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'H');
   			add_tail(&operate_buf, "FFFF", 4, 'R');
    		add_tail(&operate_buf, &saPinTmp[0], 16, 'R');
    		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 16, 'R');
    		add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'H');
		}
		else
		{	/* 3DES */
   			add_tail(&operate_buf, "0406", 4, 'R');
    		add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'H');
   			add_tail(&operate_buf, "10", 2, 'R');
    		add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 32, 'R');
    		add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'H');
   			add_tail(&operate_buf, "10", 2, 'R');
    		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 32, 'R');
			if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
			{
   				add_tail(&operate_buf, "01", 2, 'R');
   				add_tail(&operate_buf, "01", 2, 'R');
			}
			else
			{
   				add_tail(&operate_buf, "06", 2, 'R');
   				add_tail(&operate_buf, "06", 2, 'R');
			}
    		add_tail(&operate_buf, &saPinTmp[0], 16, 'R');
			if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
			{
				memset(saPanData,'0',sizeof(saPanData));
				memset(saPanLen,0,sizeof(saPanLen));
				memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
    			add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saCardNo[2], atoi(saPanLen), 'N');
   				add_tail(&operate_buf, ";", 1, 'N');
    			add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saCardNo[2], atoi(saPanLen), 'N');
   				add_tail(&operate_buf, ";", 1, 'N');
			}
		}
	}
	else if(hsmSourKey->index[0] != 0)
	{
		if( memcmp(hsmSourKey->pinkey1,"0000000000000000",16) == 0 )
		{	/* DES */
			memset(&saPinTmp[0],0,sizeof(saPinTmp));
			Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saPinTmp[0], 8);
		
   			add_tail(&operate_buf, "98", 2, 'R');
    		add_tail(&operate_buf, &hsmSourKey->pinkey1[0], 16, 'R');
    		add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'H');
    		add_tail(&operate_buf, &saPinTmp[0], 16, 'R');

			memset(saPanData,'0',sizeof(saPanData));
			if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
			{
				memset(saPanLen,0,sizeof(saPanLen));
				memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
				memcpy(&saPanData[4],
					&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
			}
    		add_tail(&operate_buf, &saPanData[0], 16, 'R');
		}
		else
		{	/* 3DES */
		}
	}
	else if(hsmDestKey->index[0] != 0)
	{
		if( memcmp(hsmDestKey->pinkey1,"0000000000000000",16) == 0 )
		{	/* DES */
			memset(saPanData,'0',sizeof(saPanData));
			if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
			{
				memset(saPanLen,0,sizeof(saPanLen));
				memcpy(saPanLen,&hsmMsgIn->hsmOpr.saCardNo[0],2);
				memcpy(&saPanData[4],
					&hsmMsgIn->hsmOpr.saCardNo[2+atoi(saPanLen)-13],12);
				Str2Hex(saPanData,saPanTmp,16);
				vBitXOR(&hsmMsgIn->hsmOpr.saEnc[0], saPanTmp, 
						&hsmMsgIn->hsmOpr.saEnc[0], 8);
			}
			memset(&saPinTmp[0],0,sizeof(saPinTmp));
			Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saPinTmp[0], 8);
		
   			add_tail(&operate_buf, "60", 2, 'R');
    		add_tail(&operate_buf, &hsmDestKey->pinkey1[0], 16, 'R');
    		add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'H');
    		add_tail(&operate_buf, &saPinTmp[0], 16, 'R');
		}
		else
		{	/* 3DES */
		}
	}

	iResult = hsm30_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, &hsm30_response_code, 2, 'A');
	remove_head(&response_buf, err_code, 2, 'A');
	if(memcmp(err_code,"00", 2) == 0)
	{
        remove_head(&response_buf, saNewPin, 16, 'A');
		Str2Hex( &saNewPin[0], &hsmMsgIn->hsmOpr.saEnc[0], 16);
		return HSM_SUCCESS;
    }
    else
    {
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm30_GenMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16];
	char	saMacBlockLen[4];
	int		iResult;

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

   	add_tail(&operate_buf, "84", 2, 'R');
	if(hsmSourKey->index[0] != 0)
	{
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'H');
   		add_tail(&operate_buf, "0", 1, 'R');
    	add_tail(&operate_buf, &hsmSourKey->mackey1[0], 16, 'R');
	}
	else
	{
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'H');
   		add_tail(&operate_buf, "0", 1, 'R');
    	add_tail(&operate_buf, &hsmDestKey->mackey1[0], 16, 'R');
	}
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'H');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
			atoi(saMacBlockLen), 'A'); 

	iResult = hsm30_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, &hsm30_response_code, 1, 'A');
	if(hsm30_response_code == 'A')
    {
        remove_head(&response_buf, saMac, 16, 'R');
		memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8);
		return HSM_SUCCESS;
    }
    else
    {
		remove_head(&response_buf, err_code, 2, 'R');
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm30_GenMacWithKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac[16],saMacKey[32];
	char	saMacBlockLen[4];
	int		iResult;

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 16);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

	if(memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "16", 2) == 0)
	{
   		add_tail(&operate_buf, "0410", 4, 'R');
   		add_tail(&operate_buf, "01", 2, 'R');
		if(hsmSourKey->index[0] != 0)
		{
    		add_tail(&operate_buf, &hsmSourKey->index[0], 4, 'H');
		}
		else
		{
    		add_tail(&operate_buf, &hsmDestKey->index[0], 4, 'H');
		}
   		add_tail(&operate_buf, "10", 2, 'R');
   		add_tail(&operate_buf, "01", 2, 'R');
   		add_tail(&operate_buf, &saMacKey[0], 32, 'R');
   		add_tail(&operate_buf, "0000000000000000", 16, 'R');
   		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'H');
   		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
				atoi(saMacBlockLen), 'A'); 
	}
	else
	{
   		add_tail(&operate_buf, "84", 2, 'R');
		if(hsmSourKey->index[0] != 0)
		{
    		add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'H');
		}
		else
		{
    		add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'H');
		}
   		add_tail(&operate_buf, "0", 1, 'R');
   		add_tail(&operate_buf, &saMacKey[0], 16, 'R');
   		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'H');
   		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
				atoi(saMacBlockLen), 'A'); 
	}

	iResult = hsm30_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, &hsm30_response_code, 1, 'A');
	if(hsm30_response_code == 'A')
    {
        remove_head(&response_buf, saMac, 16, 'R');
		memcpy(&hsmMsgIn->hsmOpr.saEnc[16],saMac,8);
		return HSM_SUCCESS;
    }
    else
    {
		remove_head(&response_buf, err_code, 2, 'R');
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm30_VerifyMac(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMacBlockLen[4];
	int		iResult;

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

   	add_tail(&operate_buf, "87", 2, 'R');
	if(hsmSourKey->index[0] != 0)
	{
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'H');
   		add_tail(&operate_buf, "0", 1, 'R');
    	add_tail(&operate_buf, &hsmSourKey->mackey1[0], 16, 'R');
	}
	else
	{
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'R');
   		add_tail(&operate_buf, "0", 1, 'R');
    	add_tail(&operate_buf, &hsmDestKey->mackey1[0], 16, 'R');
	}
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saEnc[16], 8, 'R');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'H');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
			atoi(saMacBlockLen), 'A'); 
	iResult = hsm30_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, &hsm30_response_code, 1, 'A');
	if(hsm30_response_code == 'A')
    {
		return HSM_SUCCESS;
	}
	else
	{
		remove_head(&response_buf, err_code, 2, 'R');
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm30_VerifyMacWithKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMacKey[16];
	char	saMacBlockLen[4];
	int		iResult;

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	memset(&saMacKey[0],0,sizeof(saMacKey));
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 8);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

   	add_tail(&operate_buf, "87", 2, 'R');
	if(hsmSourKey->index[0] != 0)
	{
   		add_tail(&operate_buf, "0", 1, 'R');
    	add_tail(&operate_buf, &hsmSourKey->index[1], 3, 'H');
	}
	else
	{
   		add_tail(&operate_buf, "0", 1, 'R');
    	add_tail(&operate_buf, &hsmDestKey->index[1], 3, 'H');
	}
   	add_tail(&operate_buf, &saMacKey[0], 16, 'R');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saEnc[16], 8, 'R');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'H');
   	add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
			atoi(saMacBlockLen), 'A'); 
	iResult = hsm30_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, &hsm30_response_code, 1, 'A');
	if(memcmp(err_code,"00", 2) == 0)
    {
		return HSM_SUCCESS;
    }
    else
    {
		remove_head(&response_buf, err_code, 2, 'R');
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
	}
}

int hsm30_ChangeKey(
		HSM_KEYFILE *hsmSourKey,
		HSM_KEYFILE *hsmDestKey,
		HSMMsgInDef *hsmMsgIn)
{
	char	saMac1[8],saMac2[8],saMacKey[32];
	char	saMacBlockLen[4];
	int		iResult,nKeyFlag;
	char	saKeyIndex[3];

    clear_string(&operate_buf);
    clear_string(&response_buf);

	if(hsmSourKey->index[0] == 0 && hsmDestKey->index[0] == 0)
		return HSM_FAIL;

	if(hsmMsgIn->hsmOpr.saEncWay[0] == '1')
		nKeyFlag = PIN_KEY_TYPE;
	else if(hsmMsgIn->hsmOpr.saEncWay[0] == '2')
		nKeyFlag = MAC_KEY_TYPE;
	else
		return HSM_FAIL;

	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[0], &saMacKey[0], 16);
	Hex2Str( &hsmMsgIn->hsmOpr.saEnc[16], &saMac1[0], 4);

	memset(saMacBlockLen,0,sizeof(saMacBlockLen));
	memcpy(saMacBlockLen,hsmMsgIn->hsmOpr.saMacBlockLen,3);

	if(memcmp(&hsmMsgIn->hsmOpr.saEncWay[0], "16", 2) == 0)
	{
   		add_tail(&operate_buf, "0411", 4, 'R');
   		add_tail(&operate_buf, "01", 2, 'R');
		if(hsmSourKey->index[0] != 0)
		{
			memset(saKeyIndex,0,sizeof(saKeyIndex));
			memcpy(saKeyIndex,hsmSourKey->keyindex,2);
    		add_tail(&operate_buf, &hsmSourKey->index[0], 4, 'H');
		}
		else
		{
			memset(saKeyIndex,0,sizeof(saKeyIndex));
			memcpy(saKeyIndex,hsmDestKey->keyindex,2);
    		add_tail(&operate_buf, &hsmDestKey->index[0], 4, 'H');
		}
   		add_tail(&operate_buf, "10", 2, 'R');
   		add_tail(&operate_buf, "01", 2, 'R');
   		add_tail(&operate_buf, &saMacKey[0], 32, 'R');
   		add_tail(&operate_buf, "0000000000000000", 16, 'R');
   		add_tail(&operate_buf, &saMac1[0], 8, 'R');
   		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'H');
   		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
				atoi(saMacBlockLen), 'A'); 
	}
	else
	{
   		add_tail(&operate_buf, "81", 2, 'R');
   		add_tail(&operate_buf, &saMacKey[0], 16, 'R');
		if(hsmSourKey->index[0] != 0)
		{
			memset(saKeyIndex,0,sizeof(saKeyIndex));
			memcpy(saKeyIndex,hsmSourKey->keyindex,2);
    		add_tail(&operate_buf, &hsmSourKey->index[0], 4, 'H');
		}
		else
		{
			memset(saKeyIndex,0,sizeof(saKeyIndex));
			memcpy(saKeyIndex,hsmDestKey->keyindex,2);
    		add_tail(&operate_buf, &hsmDestKey->index[0], 4, 'H');
		}
   		add_tail(&operate_buf, &saMac1[0], 8, 'R');
   		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlockLen[0], 3, 'H');
   		add_tail(&operate_buf, &hsmMsgIn->hsmOpr.saMacBlock[0], 
				atoi(saMacBlockLen), 'A'); 

		memcpy(&saMacKey[16],"0000000000000000",16);
	}

	iResult = hsm30_cmd(&operate_buf, &response_buf);
	if(iResult != HSM_SUCCESS) return HSM_FAIL;

	remove_head(&response_buf, &hsm30_response_code, 1, 'A');
	if(hsm30_response_code != 'A')
    {
		remove_head(&response_buf, err_code, 2, 'R');
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsm30_SndRcv:error[%c%c]!", err_code[0],err_code[1] );
		return HSM_FAIL;
    }

	if(lModifyKeyFile(saKeyIndex,nKeyFlag,saMacKey) != 0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsm30_ChangeKey::to modify keyfile failure!");
		return HSM_FAIL;
	}

	return HSM_SUCCESS;
}
