/*****************************************************************************/
/*				TOPLINK -- Shanghai Huateng Software System Inc.		  */
/*****************************************************************************/
/* PROGRAM NAME: hsmsrv.c													 */
/* DESCRIPTIONS: hsm process server.										 */
/*****************************************************************************/
/*							 MODIFICATION LOG							  */
/* DATE		PROGRAMMER	 DESCRIPTION									*/
/*****************************************************************************/
#include "hsmsrv.h"
#include "DbsDef.h"

int			iReqQueId,iRspQueId;
int			iSocketID;
int			iResult,ret,rc;
HSMMsgInDef	hsmMsgInRet,hsmMsgTmp;
static struct data_table datatables[HSM_NUMBERS];
int			trace_level,log_level,hsm_type,key_num,cmd_len,cmd_type;
int			head_len;
char		gsMsgHead[100];
HSM_KEYFILE	hsmKeyFile[HSM_MAXKEYS];

main(int argc,char **argv)
{
	int 	counter,hsmport,hsmnum,i;
	char	hsmip[HSM_IPLEN+1];
	char 	paramvalue[20];
	int		reqqkey,rspqkey;
	char	cmdbuf[100];
 
	memset(logfile,0,sizeof(logfile));
	memcpy(logfile,"hsmsrv",6);

	memset(paramvalue,0,20);
	ret=GetParamValue("TRACE_LEVEL",paramvalue);
	if(ret<0)
	{
		printf("hsmsrv:get trace_level error!\n");
		trace_level=NO_TRACE;
	}
	else
		trace_level=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("LOG_LEVEL",paramvalue);
	if(ret<0)
	{
		printf("hsmsrv:get log_level error!\n");
		log_level=NO_LOG;
	}
	else
		log_level=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("REQ_MSQKEY",paramvalue);
	if(ret<0)
	{
		printf("hsmsrv:get REQ_MSQKEY error!\n");
		exit(-1);
	}
	else
		reqqkey=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("RSP_MSQKEY",paramvalue);
	if(ret<0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmsrv:get RSP_MSQKEY error");
		exit(-1);
	}
	else
		rspqkey=atoi(paramvalue);

	iReqQueId = msgget(reqqkey, 0660|IPC_CREAT);
	iRspQueId = msgget(rspqkey, 0660|IPC_CREAT);

	if(iReqQueId == -1 || iRspQueId == -1)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv:msgget error[%d]",errno);
		exit(-1);
	}

	if(InitDataTypes(datatables,HSM_NUMBERS)<0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv:InitDataTypes error[%d]",errno);
		exit(-1);
	}

	memset(paramvalue,0,20);
	ret=GetParamValue("HSM_TYPE",paramvalue);
	if(ret<0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv:get hsm_type error!");
		hsm_type=NO_HSM;
	}
	else
		hsm_type=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("HSM_KEYNUM",paramvalue);
	if(ret<0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv:get key_num error!");
		key_num=1;
	}
	else
		key_num=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("OS_TYPE",paramvalue);
	if(ret<0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv:get os_type error!");
		os_type=SCO_UNIX_OS;
	}
	else
	   	os_type=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("CMD_LEN",paramvalue);
	if(ret<0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv:get cmd_len error!");
		cmd_len=0;
	}
	else
	   	cmd_len=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("CMD_TYPE",paramvalue);
	if(ret<0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsvr:get cmd_type error!");
		cmd_type=IS_ASCII;
	}
	else
		cmd_type=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("HEAD_LEN",paramvalue);
	if(ret<0)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsvr:get head_len error!");
		head_len=0;
	}
	else
		head_len=atoi(paramvalue);

	if(head_len != 0)
	{
		memset(paramvalue,0,20);
		memset(gsMsgHead,0,sizeof(gsMsgHead));
		ret=GetParamValue("HEAD_MESS",paramvalue);
		if(ret<0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmsvr:get message head error!");
			memset(gsMsgHead, ' ', head_len);
		}
		else
			memcpy(gsMsgHead, paramvalue, head_len);
	}

	counter=0;
	while(1)
	{
		if(datatables[counter].useflag==-1)
			break;

		memset(hsmip,0,HSM_IPLEN+1);
		strcpy(hsmip,datatables[counter].hsmip);
		hsmport=datatables[counter].hsmport;
		hsmnum=datatables[counter].hsmnum;

		if(hsm_type == HSM_30_COM || hsm_type == HSM_56_COM || hsm_type == HSM_10_COM || hsm_type == HSM_RACAL_COM)
		{
			if(hsmnum > 1)
			{
				HsmLog(logfile,log_level,__FILE__,__LINE__,
					"hsmsrv:hsmnum > 1, error");
				exit(-1);
			}
		}

		for(i=0;i<hsmnum;i++)
		{
			rc=fork();
			switch(rc)
			{
			case 0:
				ClientHsm(hsmip, hsmport, i);
				exit(0);
			case -1:
				HsmLog(logfile,log_level,__FILE__,__LINE__,
					"hsmsrv:fork error [%d]",rc);
				exit(-1);
			default:
				break;
			}
		}
		counter++;
	}
}

int ClientHsm(char *ip, int port, int ihsm)
{
	int				i,nNumber,ret;

	memset(logfile,0,sizeof(logfile));
	sprintf(logfile,"hsmsrv.%d",ihsm);

	if(hsm_type == HSM_30_TCP || hsm_type == HSM_56_TCP || hsm_type == HSM_10_TCP || hsm_type == HSM_RACAL_TCP)
	{
		memset(logfile,0,sizeof(logfile));
		sprintf(logfile,"hsmsrv.%s.%d",ip,ihsm);

		while((iSocketID = ConnectSocket(ip, port)) < 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
					"hsmsrv: cannot connect to hsm ip = [%s] port = [%d]",
					ip,port);
			sleep(5);
			continue;
		}

		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmsrv: connect to hsm ok! svr_ip = [%s] port = [%d] id = [%d]", ip,port,iSocketID);
	}

	if(hsm_type == HSM_30_COM || hsm_type == HSM_56_COM || hsm_type == HSM_10_COM || hsm_type == HSM_RACAL_COM)

	{
		while((iSocketID = init_port(ip)) < 0)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,
					"hsmsrv: cannot open com ip = [%s]", ip);
			sleep(5);
			continue;
		}

		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"hsmsrv: connect to hsm ok! svr_ip = [%s] id = [%d]",
				ip,iSocketID);
	}

	HsmLog(logfile,log_level,__FILE__,__LINE__,
			"hsmsrv: started...");
	nNumber = 0;
	iInitKeyNeed = 1;
	while(1)
	{
		HsmLog(logfile,log_level,__FILE__,__LINE__,
	   			"hsmsrv: waitting for request...");

		memset(&hsmMsgInRet,0,sizeof(hsmMsgInRet));
		if ((iResult = msgrcv(iReqQueId, &hsmMsgInRet, 1024,
							0,MSG_NOERROR)) == -1) {
			HsmLog(logfile,log_level,__FILE__,__LINE__,
					"hsmsrv: msgrcv error! %d",iResult);
			sleep(1);
			continue;
		}

		HsmLog(logfile,log_level,__FILE__,__LINE__,
				"the %d message begin", nNumber++);

		HsmTrace(logfile,trace_level,(char *)&hsmMsgInRet,
			sizeof(HSMMsgInDef),__FILE__,__LINE__);

		if(iInitKeyNeed)
		{
			memset(&hsmKeyFile[0],0,sizeof(HSM_KEYFILE));
			/**********
			for(i=0;i<key_num;i++)
				memset(&hsmKeyFile[i],0,sizeof(HSM_KEYFILE));
			for(i=0;i<key_num;i++)
				lReadKeyFile(i,&hsmKeyFile[i]);
			************/
			/********ͨ�����ݿ���������Կ******/
			ret = DbsConnect();
			if(ret)
			{
				HsmLog(logfile,log_level,__FILE__,__LINE__,"�������ݿ�ʧ��:[d]", ret);
				return -1;
			}
			DbsTblKeyParam( DBS_CURSOR, &hsmKeyFile[0]);
			ret = DbsTblKeyParam( DBS_OPEN, &hsmKeyFile[0]);
			if(ret)
			{
				HsmLog(logfile,log_level,__FILE__,__LINE__,"��ʼ����Կʧ��:[%d]", ret);
				DbsDisconnect();
				return -1;
			}
			for(i=0;i<key_num;i++)
				memset(&hsmKeyFile[i],0,sizeof(HSM_KEYFILE));

			i = 0;
			while( (ret = DbsTblKeyParam( DBS_FETCH, &hsmKeyFile[i])) == 0 )
			{
				if(ret == DBS_NOTFOUND)
					break;
				i++;
			}

			key_num = i;
			DbsTblKeyParam( DBS_CLOSE, &hsmKeyFile[0]);
			DbsDisconnect();
			/*iInitKeyNeed = 0;*/
		}
		/*
		for(i=0;i<key_num;i++)
		{
			HsmLog(logfile,log_level,__FILE__,__LINE__,"key_index:[%s]", hsmKeyFile[i].keyindex);
			HsmLog(logfile,log_level,__FILE__,__LINE__,"index:[%s]", hsmKeyFile[i].index);
			HsmLog(logfile,log_level,__FILE__,__LINE__,"bmk:[%s]", hsmKeyFile[i].bmk);
			HsmLog(logfile,log_level,__FILE__,__LINE__,"pinkey1:[%s]", hsmKeyFile[i].pinkey1);
			HsmLog(logfile,log_level,__FILE__,__LINE__,"mackey1:[%s]", hsmKeyFile[i].mackey1);
			HsmLog(logfile,log_level,__FILE__,__LINE__,"pinkey2:[%s]", hsmKeyFile[i].pinkey2);
			HsmLog(logfile,log_level,__FILE__,__LINE__,"mackey2:[%s]", hsmKeyFile[i].mackey2);
		}
		*/
		

		memset(&hsmSourKey,0,sizeof(HSM_KEYFILE));
		if(hsmMsgInRet.hsmOpr.saRout[0] == 'Y')
		{
			for(i=0;i<key_num;i++)
			{
				if(memcmp(&hsmMsgInRet.hsmOpr.saRout[1],
						hsmKeyFile[i].index,4) == 0)
				{
					memcpy(&hsmSourKey,&hsmKeyFile[i],sizeof(HSM_KEYFILE));
					break;
				}
			}
		}

		memset(&hsmDestKey,0,sizeof(HSM_KEYFILE));
		if(hsmMsgInRet.hsmOpr.saRout[5] == 'Y')
		{
			for(i=0;i<key_num;i++)
			{
				if(memcmp(&hsmMsgInRet.hsmOpr.saRout[6],
						hsmKeyFile[i].index,4) == 0)
				{
					memcpy(&hsmDestKey,&hsmKeyFile[i],sizeof(HSM_KEYFILE));
					break;
				}
			}
		}

		HsmLog(logfile,log_level,__FILE__,__LINE__,"hsm_type:[%d]", hsm_type);
		switch(hsm_type)
		{
			case NO_HSM:
				iResult = HSM_SUCCESS;
				break;

			case HSM_SOFT:
				iResult = hsmsoft_SndRcv( &hsmSourKey,
										&hsmDestKey,
										&hsmMsgInRet);
				break;

			case HSM_30_TCP:
			case HSM_30_COM:
				iResult = hsm30_SndRcv( &hsmSourKey,
										&hsmDestKey,
										&hsmMsgInRet);
				break;

			case HSM_56_TCP:
			case HSM_56_COM:
				iResult = hsm56_SndRcv( &hsmSourKey,
										&hsmDestKey,
										&hsmMsgInRet);
				break;
			case HSM_RACAL_TCP:
			case HSM_RACAL_COM:
				iResult = hsmracal_SndRcv( &hsmSourKey,
										&hsmDestKey,
										&hsmMsgInRet);
				break;
		}
		if(iResult == HSM_FAIL)
			memcpy(hsmMsgInRet.hsmOpr.saRspCode,"96",2);
		else
			memcpy(hsmMsgInRet.hsmOpr.saRspCode,"00",2);

		HsmLog(logfile,log_level,__FILE__,__LINE__,
	   			"iRspQueId [%d][%2.2s]",iRspQueId, hsmMsgInRet.hsmOpr.saRspCode);

		if ((iResult = msgsnd(iRspQueId, (char *)&hsmMsgInRet,
					sizeof(HSMMsgInDef)-sizeof(long), 0)) < 0) {
			HsmLog(logfile,log_level,__FILE__,__LINE__,
						"hsmsrv: msgsnd error[%d]",errno);
			continue;
		}
	}
}
