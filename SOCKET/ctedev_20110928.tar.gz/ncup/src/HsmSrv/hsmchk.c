/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: hsmchk.c	    											 */
/* DESCRIPTIONS: hsm check process server.                                   */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/msg.h>

#include "hsmsrv.h"
#include "DbsDef.h"

static int rmsgid;
static int smsgid;

int	trace_level,log_level,cmd_len,cmd_type;
char*	CommTimeOut;
int hsmchk_timeout_flag;

void hsmchk_Timeout(int sig)
{
	hsmchk_timeout_flag = 1;
}

void test_signal(int sig)
{
	if(sig == SIGHUP)
	{
		HsmLog("hsmchk",log_level,__FILE__,__LINE__,"Receive signal SIGHUP");
	}
	if(sig == SIGINT)
	{
		HsmLog("hsmchk",log_level,__FILE__,__LINE__,"Receive signal SIGINT");
	}
	if(sig == SIGKILL)
	{
		HsmLog("hsmchk",log_level,__FILE__,__LINE__,"Receive signal SIGKILL");
	}
	if(sig == SIGQUIT)
	{
		HsmLog("hsmchk",log_level,__FILE__,__LINE__,"Receive signal SIGQUIT");
	}
	if(sig == SIGTERM)
	{
		HsmLog("hsmchk",log_level,__FILE__,__LINE__,"Receive signal SIGTERM");
	}
}
int main(int argc,char *argv[])
{
	HSMMsgInDef	hsmMsgIn;

	int rc,ret,fd,interval,timeout;
	int reqqkey,rspqkey;
	char paramvalue[20];

	sigset(SIGHUP, test_signal);

	sigset(SIGINT, test_signal);

	sigset(SIGKILL, test_signal);

	sigset(SIGQUIT, test_signal);

	sigset(SIGTERM, test_signal);


	bzero(paramvalue,sizeof(paramvalue));
	rc=GetParamValue("TIMEINTERVAL",paramvalue);
	if(rc<0)
		interval=60;
	else
		interval=atoi(paramvalue);

	rc=GetParamValue("TIMEOUT",paramvalue);
	if(rc<0)
		timeout=10;
	else
		timeout=atoi(paramvalue);

	bzero(paramvalue,sizeof(paramvalue));
	ret=GetParamValue("REQ_MSQKEY",paramvalue);
	if(ret<0)
	{
		printf("hsmchk:get REQ_MSQKEY error!\n");
		exit(0);
	}
	else
		reqqkey=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("RSP_MSQKEY",paramvalue);
	if(ret<0)
	{
		printf("hsmchk:get RSP_MSQKEY error!\n");
		exit(0);
	}
	else
		rspqkey=atoi(paramvalue);

	memset(paramvalue,0,20);
	ret=GetParamValue("LOG_LEVEL",paramvalue);
	if(ret<0)
	{
		printf("hsmchk:get log_level error!\n");
		log_level=NO_LOG;
	}
	else
		log_level=atoi(paramvalue);

	rc=fork();
	if(rc)
		exit(0);

	fd = open("/dev/null", O_RDWR);
	if (fd > 0) {
		close(0);
		close(1);
		close(2);
		dup(fd);
		dup(fd);
		dup(fd);
		close(fd);
	}

	rmsgid=msgget(reqqkey,0660);
	if(rmsgid<0)
	{
		printf("hsmchk:create receive msgkey error!\n");
		exit(0);
	}

	smsgid=msgget(rspqkey,0660);
	if(smsgid<0)
	{
		printf("hsmchk:create send msgkey error!\n");
		exit(0);
	}

	HsmLog("hsmchk",log_level,__FILE__,__LINE__,
			"hsmchk: started");
	for(;;)
	{
		memset(&hsmMsgIn,0,sizeof(HSMMsgInDef));
		msgrcv(smsgid, &hsmMsgIn, sizeof(HSMMsgInDef),
				HSMCHK_MSG_TYPE, IPC_NOWAIT);

		memset(&hsmMsgIn,0,sizeof(HSMMsgInDef));
		hsmMsgIn.nMsgType = HSMCHK_MSG_TYPE;
		hsmMsgIn.hsmOpr.saOprType = HSM_TEST;

		msgsnd(rmsgid,&hsmMsgIn,sizeof(HSMMsgInDef)-sizeof(long),0);

		hsmchk_timeout_flag = 0;
		sigset(SIGALRM, hsmchk_Timeout);
		alarm(timeout);

		ret = -1;
		while ((ret = msgrcv(smsgid, &hsmMsgIn,
						sizeof(HSMMsgInDef),HSMCHK_MSG_TYPE, 0)) < 0 &&
				hsmchk_timeout_flag == 0 )
		{
			HsmLog("hsmchk",log_level,__FILE__,__LINE__,
					"hsmchk: msgrcv error %d",ret);
			if (errno == EINTR) continue;
			break;
		}
		alarm(0);

		if (hsmchk_timeout_flag == 1)
		{
			HsmLog("hsmchk",log_level,__FILE__,__LINE__,
					"hsmchk: restart hsmsrv");
			system("runhsmsrv");
			continue;
		}
		HsmLog("hsmchk",log_level,__FILE__,__LINE__,
				"hsmchk: hsmsrv running");
		sleep(interval);
	}
}
