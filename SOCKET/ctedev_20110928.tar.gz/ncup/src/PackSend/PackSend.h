#ifndef __PACK_SEND_H
#define __PACK_SEND_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/times.h>
#include <sys/timeb.h>
#include <sys/types.h>
#include <memory.h>
#include <signal.h>
#include <errno.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "CvtOpr.h"
#include "xmlstruct.h"

int PackSendInit (short argc, char **argv);
void HandleExit (int n);
#define SAPSEnvRuleN				"TL_PACKSEND_RULE_N"

#endif
