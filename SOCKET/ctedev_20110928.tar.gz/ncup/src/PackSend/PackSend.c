/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: SafFwd.c													 */
/* DESCRIPTIONS: The save and forward process server.                        */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/* 2005-04-06  Yu Tong        Change for NCUP                                */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/PackSend/PackSend.c,v 1.1.1.1.4.4 2011/09/23 02:54:34 ctedev Exp $";

#include "PackSend.h"

char		gsSrvId[SRV_ID_LEN+1];
char		gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char        gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq	gatSrvMsq[SRV_MSQ_NUM_MAX];

char 		gsParamMsgCompressFlag[2];

Tbl_conv_type_Def 	gatConvType[CONV_TYPE_NUM_MAX];
T_UsageTransRuleDef gatUsageTransRule[CVT_USAGE_TRANS_RULE_NUM_MAX];
stIpcDftRuleDef 	tIpcDftRule;
bciMBufChgInfDef	tBufChgRule;
/* del by lgm 20110328
AllXmlnodeBuf  sCRTallxmlnodebuf;
 del end */

void main(short	argc, char **argv)
{
	char	sSrcSrvId[SRV_ID_LEN+1];
	char	sToSrvId[SRV_ID_LEN+1];
	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	char	sIntMsgBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	char	sTmpLogFile[LOG_NAME_LEN_MAX];
	int 	nMsgInLen;
	int 	nIntMsgLen;
	int 	nMsgOutLen;
	int     nSavKey = 0;
	char	sMsqType[FLD_MSQ_TYPE_LEN+1];
	int		nReturnCode;
	long	lMsqType;
	char	sTotalLen[5];
	char	sTxnNum[FLD_TXN_NUM_LEN+1];
	char    sLogTime[128];
    char    sDateTime[16];
    
	long   	lBeginTime, lEndTime;
	struct tms    tTMS;

	if(argc < 3)
	{
		printf("Usage:%s srvid seq\n", argv[0]);
		exit(-1);
	}

	nReturnCode = PackSendInit (argc, argv);
	if (nReturnCode)
	{
		printf("PackSend: PackSendInit error[%d]\n",nReturnCode);
		exit(-2);
	}
		
	sprintf (sTmpLogFile, "%s.log", gsLogFile);

	if (sigset(SIGTERM, HandleExit) == SIG_ERR)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"sigset SIGTERM error, %d.", errno);
		exit(-3);
	}

	HtLog (sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "PackSend started.");

    lBeginTime = 0;
	lEndTime = 0;

	while (1)
	{
		sprintf (sTmpLogFile, "%s.log", gsLogFile);

		memset (sMsgInBuf, 0, sizeof(sMsgInBuf) );
		nMsgInLen = MSQ_MSG_SIZE_MAX;
		sigrelse (SIGTERM);
		nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, 
							&nMsgInLen, sMsgInBuf);
		sighold (SIGTERM);
		if (nReturnCode)
		{
			if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
			{
				HtLog( sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"MsqRcv error, %d.", nReturnCode);
				exit(-4);
			}
			else
				continue;
		}

        lBeginTime = times( &tTMS);

		/* uncompress msg */
        if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
        {
            /* uncompress msg */
            /* sMsgBuf, nMsgLen -> sIntMsgBuf, nIntMsgLen */
            memset(sIntMsgBuf,0,sizeof(sIntMsgBuf));
            UnCompressbuf(sMsgInBuf, nMsgInLen, sIntMsgBuf, &nIntMsgLen);
            memset(sMsgInBuf,0,sizeof(sMsgInBuf));
            nMsgInLen = nIntMsgLen;
            memcpy (sMsgInBuf, sIntMsgBuf, nIntMsgLen);
        }

		memset (sSrcSrvId, 0, sizeof (sToSrvId));
		memcpy (sSrcSrvId, sMsgInBuf, SRV_ID_LEN);

		memset (sToSrvId, 0, sizeof (sToSrvId));
		memcpy (sToSrvId, sMsgInBuf+SRV_ID_LEN, SRV_ID_LEN);

		/*
		memset (sMsqType, 0, sizeof (sMsqType));
		memcpy (sMsqType, sMsgInBuf+SRV_ID_LEN*2, FLD_MSQ_TYPE_LEN);
		lMsqType = atol (sMsqType);
		*/

		sprintf (sTmpLogFile, "%s.%s.log", gsLogFile, sToSrvId);

		HtLog( sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"received %d byte msg, from srv id %s, to srv id %s", 
				nMsgInLen, sSrcSrvId, sToSrvId);
		
		HtDebugString (sTmpLogFile, HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, 
					sMsgInBuf, nMsgInLen);
		

		/* msg format convert */
		nMsgOutLen = MSQ_MSG_SIZE_MAX;

		nReturnCode = CvtInToOut (gatConvType, gatUsageTransRule, &tIpcDftRule, &tBufChgRule, nMsgInLen, sMsgInBuf, &nMsgOutLen, sMsgOutBuf);
		if (nReturnCode)
		{
			HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"CvtInToOut error [%d]", nReturnCode);
			continue;
		}
		
		/*����ת��ת���ȡԭת�������������*/
		if((!memcmp(sMsgInBuf+207,"1443",4) || !memcmp(sMsgInBuf+207,"1453",4) || !memcmp(sMsgInBuf+207,"2443",4) || !memcmp(sMsgInBuf+207,"2453",4)) && (!memcmp(sMsgInBuf+382,"0316",4)))
		{
			memcpy(sMsgOutBuf+68,sMsgInBuf+3058,15);
			memcpy(sMsgOutBuf+83,"     ",5);
			memcpy(sMsgOutBuf+108,sMsgInBuf+3073,9);
		}
    
		 /* end */
		HtDebugString (sTmpLogFile, HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, 
				sMsgOutBuf, nMsgOutLen);
    	
		
		if(memcmp(sMsgOutBuf+SRV_ID_LEN, SRV_ID_COMM_CON, SRV_ID_LEN) == 0)
		{
			memset (sMsqType, 0, sizeof (sMsqType));
			memcpy (sMsqType, sMsgOutBuf+SRV_ID_LEN*2, FLD_MSQ_TYPE_LEN);
			lMsqType = atol (sMsqType);
		}
		else
		{
			lMsqType = 0;
		}
		
		
		nReturnCode = MsqSnd (sToSrvId, gatSrvMsq, lMsqType, nMsgOutLen, sMsgOutBuf);
		if (nReturnCode)
		{
			HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"MsqSnd to %s error, %d. lMsqType[%d]", sToSrvId, nReturnCode, lMsqType);
			continue;
		}

		HtLog (sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"Send msg to %s", sToSrvId);

        lEndTime = times( &tTMS);
	}
}

/*****************************************************************************/
/* FUNC:   int PackSendInit (short argc, char **argv)                        */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �������ݿ�, ����ȫ�ֱ���, ��ȡ���в���,                           */
/*         ��ʼ����Ϣ����, �����ݿ��ȡת�������                            */
/*****************************************************************************/
int PackSendInit (short argc, char **argv)
{
	char			sTmpLogFile[LOG_NAME_LEN_MAX];
	int				i,iRet;
	int				nReturnCode;
	long            lUsageKey;
	char            sConFigFileName[255+1]={0};   /* �����ļ��� */     
	Tbl_srv_inf_Def	tTblSrvInf;

	strcpy (gsSrvId, argv[1]);
	strcpy (gsSrvSeqId, argv[2]);
	if (getenv (MSG_COMPRESS_FLAG))
		strcpy (gsParamMsgCompressFlag, getenv (MSG_COMPRESS_FLAG));
	else
		strcpy (gsParamMsgCompressFlag, FLAG_NO);
	
	if (getenv(SRV_USAGE_KEY))
		lUsageKey=atoi (getenv(SRV_USAGE_KEY));
	else
		return -1;

	/* connect to database */
    nReturnCode = DbsConnect ();
	if (nReturnCode)
		return (nReturnCode);
	
	/* get log file name from tbl_srv_inf */
	memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
	tTblSrvInf.usage_key = lUsageKey;
	memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);


	nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
	if (nReturnCode)
	{
		DbsDisconnect ();
		return (nReturnCode);
	}

	CommonRTrim(tTblSrvInf.srv_name);
	sprintf (gsLogFile, "%s.%s", tTblSrvInf.srv_name, gsSrvSeqId);
	sprintf (sTmpLogFile, "%s.log", gsLogFile);

	/* init msg queue */
	memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
	nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"MsqInit error, %d.", nReturnCode);
		DbsDisconnect ();
		return (nReturnCode);
	}
	
	/* init ISO8583 convert rule */
	memset ((char *)gatConvType, 0, sizeof (gatConvType));
	memset ((char *)gatUsageTransRule, 0, sizeof (gatUsageTransRule));
	nReturnCode = CvtInit (gatConvType, gatUsageTransRule);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CvtInit error, %d.", nReturnCode);
		DbsDisconnect ();
		return (nReturnCode);
	}

	memset(&tBufChgRule,0,sizeof(bciMBufChgInfDef));
	nReturnCode = BufChgLoad(1,&tBufChgRule);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "BufChgLoad error, %d.", nReturnCode);
		DbsDisconnect ();
		return (nReturnCode);
	}

    /***************************************
	for (i = 0; i < tBufChgRule.nBufN; i++)
	{
	    HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "iBufChgX: %d", tBufChgRule.bceaBufEle[i].iBufChgX);
		for (j = 0; j < tBufChgRule.bceaBufEle[i].nFldN; j++)
		    HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"i: %02d, j: %02d, nDestOffset: %04d, nSourOffset :%04d, nFldL: %04d, nChgType: %d", i, j,
			tBufChgRule.bceaBufEle[i].fceaFldEle[j].nDestOffset,
			tBufChgRule.bceaBufEle[i].fceaFldEle[j].nSourOffset,
			tBufChgRule.bceaBufEle[i].fceaFldEle[j].nFldL,
			tBufChgRule.bceaBufEle[i].fceaFldEle[j].nChgType);
	}
    ***************************************/

	memset(&tIpcDftRule,0,sizeof(stIpcDftRuleDef));
    nReturnCode = IpcDftLoad(1,&tIpcDftRule);
    if (nReturnCode)
    {
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "IpcDftLoad error, %d.", nReturnCode);
		DbsDisconnect ();
		return (nReturnCode);
    }
    
#if 0 /* XML��أ�ȥ�� del by lgm 20110328 */
    /* init XML inf data add by tangbin begin*/
    memset(&sCRTallxmlnodebuf,0,sizeof(AllXmlnodeBuf));
    nReturnCode = PacksendxmlInit(1,&sCRTallxmlnodebuf);
    if (nReturnCode)
    {
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "xmlIpcDftLoad error, %d.", nReturnCode);
		DbsDisconnect ();
		return (nReturnCode);
    }
    /*init XML inf data add by tangbin end*/
#endif /* del end */
    
	/* disconnect db */
	nReturnCode = DbsDisconnect ();
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"DbsDisconnect error, %d.", nReturnCode);
	}

    /* ��ʼ���㷢����ͷ���� */
	if(getenv("GFHEADER_CFG_PATH"))
    {
        /*sprintf(sConFigFileName, "%s", (char *)getenv(GFHEADER_CFG_PATH));*/
        strcpy (sConFigFileName, (char *)getenv ("GFHEADER_CFG_PATH"));
    }
    else
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "env value:[GFHEADER_CFG_PATH] is Null");
        return -1;
    }
    
    /* ���ÿ��������� */
	iRet=HTGetProfileString("CB", "RUN_PRI", GFHeaderCfg_CC.sRunPri, 2, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sRunPri from [%s] err",sConFigFileName);
        return -1;
    }
	iRet=HTGetProfileString("CB", "FW_NUM", GFHeaderCfg_CC.sFwNum, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sFwNum from [%s] err",sConFigFileName);
        return -1;
    }
	iRet=HTGetProfileString("CB", "VER_NO", GFHeaderCfg_CC.sVerNo, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sVerNo from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "TO_ENC", GFHeaderCfg_CC.sToEnc, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sToEnc from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "CHNL_ID", GFHeaderCfg_CC.sChnlId, 3, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sChnlId from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "CHNL_SEG_1", GFHeaderCfg_CC.sChnlSeg1, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sChnlSeg1 from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "CHNL_SEG_2", GFHeaderCfg_CC.sChnlSeg2, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sChnlSeg2 from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "NETGATE_NO", GFHeaderCfg_CC.sNetgateNo, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sNetgateNo from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "BUS_SYS", GFHeaderCfg_CC.sBusSys, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sBusSys from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "LAN_ID", GFHeaderCfg_CC.sLanId, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sLanId from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "SND_ID", GFHeaderCfg_CC.sSndId, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sSndId from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "RCV_ID_1", GFHeaderCfg_CC.sRcvId1, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sRcvId1 from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "RCV_ID_2", GFHeaderCfg_CC.sRcvId2, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sRcvId2 from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("CB", "UNI_TELLER", GFHeaderCfg_CC.sUniTeller, 10, sConFigFileName);
    if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_CC.sUniTeller from [%s] err",sConFigFileName);
        return -1;
    }
    
    
    /* �ܿز������� */
	iRet=HTGetProfileString("ZK", "RUN_PRI", GFHeaderCfg_ZK.sRunPri, 2, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sRunPri from [%s] err",sConFigFileName);
        return -1;
    }
	iRet=HTGetProfileString("ZK", "FW_NUM", GFHeaderCfg_ZK.sFwNum, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sFwNum from [%s] err",sConFigFileName);
        return -1;
    }
	iRet=HTGetProfileString("ZK", "VER_NO", GFHeaderCfg_ZK.sVerNo, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sVerNo from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "TO_ENC", GFHeaderCfg_ZK.sToEnc, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sToEnc from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "CHNL_ID", GFHeaderCfg_ZK.sChnlId, 3, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sChnlId from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "CHNL_SEG_1", GFHeaderCfg_ZK.sChnlSeg1, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sChnlSeg1 from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "CHNL_SEG_2", GFHeaderCfg_ZK.sChnlSeg2, 1, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sChnlSeg2 from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "NETGATE_NO", GFHeaderCfg_ZK.sNetgateNo, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sNetgateNo from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "BUS_SYS", GFHeaderCfg_ZK.sBusSys, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sBusSys from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "LAN_ID", GFHeaderCfg_ZK.sLanId, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sLanId from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "SND_ID", GFHeaderCfg_ZK.sSndId, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sSndId from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "RCV_ID_1", GFHeaderCfg_ZK.sRcvId1, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sRcvId1 from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "RCV_ID_2", GFHeaderCfg_ZK.sRcvId2, 4, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sRcvId2 from [%s] err",sConFigFileName);
        return -1;
    }
    iRet=HTGetProfileString("ZK", "TXN_LAN_CHNL", GFHeaderCfg_ZK.sTxnLanChnl, 3, sConFigFileName);
	if (iRet < 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get GFHeaderCfg_ZK.sTxnLanChnl from [%s] err",sConFigFileName);
        return -1;
    }
    

	return (0);
}

void HandleExit (int n)
{
	char	sTmpLogFile[LOG_NAME_LEN_MAX];
	
	sprintf (sTmpLogFile, "%s.log", gsLogFile);
	
	HtLog(	sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "PackSend exits.");
	exit( 1 );
}

