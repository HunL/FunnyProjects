/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Convert.c                                                    */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-21  CHEN LIANG     Changed for NCUP                               */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Convert/Convert.c,v 1.1.1.1 2011/08/19 10:55:53 ctedev Exp $";

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#include "DbsTbl.h"
#include "DbsDef.h"
#include "Convert.h"
#include "IpcInt.h"
#include "HtLog.h"

char            gsLogFileName[200];
static unsigned char SAEbcdicAscii[256] =
    {0x00, 0x01, 0x02, 0x03, 0x9C, 0x09, 0x86, 0x7F,
     0x97, 0x8D, 0x8E, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
     0x10, 0x11, 0x12, 0x13, 0x9D, 0x85, 0x08, 0x87,
     0x18, 0x19, 0x92, 0x8F, 0x1C, 0x1D, 0x1E, 0x1F,
     0x80, 0x81, 0x82, 0x83, 0x84, 0x0A, 0x17, 0x1B,
     0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x05, 0x06, 0x07,
     0x90, 0x91, 0x16, 0x93, 0x94, 0x95, 0x96, 0x04,
     0x98, 0x99, 0x9A, 0x9B, 0x14, 0x15, 0x9E, 0x1A,
     0x20, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
     0xA7, 0xA8, 0x5B, 0x2E, 0x3C, 0x28, 0x2B, 0x21,
     0x26, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
     0xB0, 0xB1, 0x5D, 0x24, 0x2A, 0x29, 0x3B, 0x5E,
     0x2D, 0x2F, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
     0xB8, 0xB9, 0x7C, 0x2C, 0x25, 0x5F, 0x3E, 0x3F,
     0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF, 0xC0, 0xC1,
     0xC2, 0x60, 0x3A, 0x23, 0x40, 0x27, 0x3D, 0x22,
     0xC3, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
     0x68, 0x69, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9,
     0xCA, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70,
     0x71, 0x72, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xD0,
     0xD1, 0x7E, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
     0x79, 0x7A, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7,
     0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
     0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
     0x7B, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
     0x48, 0x49, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED,
     0x7D, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50,
     0x51, 0x52, 0xEE, 0xEF, 0xF0, 0xF1, 0xF2, 0xF3,
     0x5C, 0x9F, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
     0x59, 0x5A, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9,
     0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
     0x38, 0x39, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF};

static unsigned char SAAsciiEbcdic[256] =
    {0x00, 0x01, 0x02, 0x03, 0x9C, 0x09, 0x86, 0x7F,
     0x97, 0x8D, 0x8E, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
     0x10, 0x11, 0x12, 0x13, 0x9D, 0x85, 0x08, 0x87,
     0x18, 0x19, 0x92, 0x8F, 0x1C, 0x1D, 0x1E, 0x1F,
     0x80, 0x81, 0x82, 0x83, 0x84, 0x0A, 0x17, 0x1B,
     0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x05, 0x06, 0x07,
     0x90, 0x91, 0x16, 0x93, 0x94, 0x95, 0x96, 0x04,
     0x98, 0x99, 0x9A, 0x9B, 0x14, 0x15, 0x9E, 0x1A,
     0x20, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
     0xA7, 0xA8, 0x5B, 0x2E, 0x3C, 0x28, 0x2B, 0x21,
     0x26, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
     0xB0, 0xB1, 0x5D, 0x24, 0x2A, 0x29, 0x3B, 0x5E,
     0x2D, 0x2F, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
     0xB8, 0xB9, 0x7C, 0x2C, 0x25, 0x5F, 0x3E, 0x3F,
     0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF, 0xC0, 0xC1,
     0xC2, 0x60, 0x3A, 0x23, 0x40, 0x27, 0x3D, 0x22,
     0xC3, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
     0x68, 0x69, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9,
     0xCA, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70,
     0x71, 0x72, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xD0,
     0xD1, 0x7E, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
     0x79, 0x7A, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7,
     0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
     0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
     0x7B, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
     0x48, 0x49, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED,
     0x7D, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50,
     0x51, 0x52, 0xEE, 0xEF, 0xF0, 0xF1, 0xF2, 0xF3,
     0x5C, 0x9F, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
     0x59, 0x5A, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9,
     0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
     0x38, 0x39, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF};

short ConvCutBlankTailLen(unsigned char *vspInputStr, short nMaxLen)
{
	short i;
	short j;

	j = nMaxLen;

	for (i=0; i<= nMaxLen; i++)
	{
		if (vspInputStr[i] == ' ' || vspInputStr[i] == '\0')
		{
			j = i;
			break;
		}
	}

	return j;
}

short nMAsciiHexToBinary(
         unsigned char* vspSourceStr,
         short          vnSourceStrL,
         unsigned char* vspDestStr) {

    if(vnSourceStrL % 2)
        return -1;

    for(; vnSourceStrL > 0; vnSourceStrL -= 2) {
        if(*vspSourceStr >= '0' &&
           *vspSourceStr <= '9')
            *vspDestStr = ((*vspSourceStr++) - '0') * 16;
        else if(*vspSourceStr >= 'a' && 
                *vspSourceStr <= 'f')
            *vspDestStr = ((*vspSourceStr++) - 'a' + 10) * 16;
        else if(*vspSourceStr >= 'A' && 
                *vspSourceStr <= 'F')
            *vspDestStr = ((*vspSourceStr++) - 'A' + 10) * 16;
        else
            return LFail;
        if(*vspSourceStr >= '0' &&
           *vspSourceStr <= '9')
            (*vspDestStr++) += ((*vspSourceStr++) - '0');
        else if(*vspSourceStr >= 'a' && 
                *vspSourceStr <= 'f')
            (*vspDestStr++) += ((*vspSourceStr++) - 'a' + 10);
        else if(*vspSourceStr >= 'A' && 
                *vspSourceStr <= 'F')
            (*vspDestStr++) += ((*vspSourceStr++) - 'A' + 10);
        else
            return -1;
    } /* end of for */

    return 0;
} /* end of nMAsciiHexToBinary */

short nMLoadFldInf(
         long               vlFldInfKey,
         Tbl_fld_inf_Def*   vtpTblFldInf,
         FldRuleInfDef*  vfripFldInf) {

    short   liFldX;

    for(liFldX = 0; liFldX < MAX_FLD_NUM; liFldX++)
        vfripFldInf[liFldX].iBeginPtr = -2;
    vtpTblFldInf->usage_key = vlFldInfKey;
    DbsFLDINF(
       DBS_CURSOR,
       vtpTblFldInf);
    
    if(DbsFLDINF(
          DBS_OPEN,
          vtpTblFldInf))
        return -1;

    while(DbsFLDINF(
             DBS_FETCH,
             vtpTblFldInf) == 0) {
        if((liFldX = vtpTblFldInf->fld_index) >= MAX_FLD_NUM)
            return -2;
        vfripFldInf[liFldX].iBeginPtr = -1;
        vfripFldInf[liFldX].nFldLenL = vtpTblFldInf->len_len;
        vfripFldInf[liFldX].nDataMaxL = vtpTblFldInf->data_max_len;
        vfripFldInf[liFldX].nLenExpVal = vtpTblFldInf->len_exp_val;
        vfripFldInf[liFldX].nIndSym = vtpTblFldInf->ind_sym;
        vfripFldInf[liFldX].nDataFormat = vtpTblFldInf->data_format;
        vfripFldInf[liFldX].nLenCharSet = vtpTblFldInf->len_char_set;
        vfripFldInf[liFldX].nDataCharSet = vtpTblFldInf->data_char_set;
    } /* end of while */
    
    if(DbsFLDINF(
          DBS_CLOSE,
          vtpTblFldInf))
        return -3;

    return 0;
} /* end of nMLoadFldInf */

short nMLoadMsgInf(
         long               vlMsgInfKey,
         Tbl_msg_inf_Def*   vtpTblMsgInf,
         short*             vnpMsgNum,
         MsgRuleInfDef*  vmripMsgInf) {

    short   liMsgX;

    *vnpMsgNum = 0;
    vtpTblMsgInf->usage_key = vlMsgInfKey;
    DbsMSGINF(
       DBS_CURSOR,
       vtpTblMsgInf);
    
    if(DbsMSGINF(
          DBS_OPEN,
          vtpTblMsgInf))
        return -1;

    while((DbsMSGINF(
              DBS_FETCH,
              vtpTblMsgInf) == 0) &&
          ((liMsgX = (*vnpMsgNum)++) < MAX_MSG_NUM)) {
        vmripMsgInf[liMsgX].nTxnNumber = vtpTblMsgInf->txn_num;
        vmripMsgInf[liMsgX].iIpcIndex = vtpTblMsgInf->ipc_index;
        vmripMsgInf[liMsgX].iBmpIndex = vtpTblMsgInf->bmp_index;
        vmripMsgInf[liMsgX].iMandBmpIndex = vtpTblMsgInf->mand_bmp_index;
        memcpy(
           vmripMsgInf[liMsgX].saMsgType,
           &vtpTblMsgInf->msg_type[0],
           F000_MSG_TYPE_LEN);
        memcpy(
           vmripMsgInf[liMsgX].saTxnCode,
           &vtpTblMsgInf->txn_code[0],
           F129_TXN_CODE_LEN);
    } /* end of while */
    
    if(DbsMSGINF(
          DBS_CLOSE,
          vtpTblMsgInf))
        return -2;

    return 0;
} /* end of nMLoadMsgInf */
    
short nMLoadConInf(
         long               vlConInfKey,
         Tbl_con_inf_Def*   vtpTblConInf,
         short*             vnpConNum,
         ConRuleInfDef*  vcripConInf) {

    short   liConX;

    *vnpConNum = 0;
    vtpTblConInf->usage_key = vlConInfKey;
    DbsCONINF(
       DBS_CURSOR,
       vtpTblConInf);
    
    if(DbsCONINF(
          DBS_OPEN,
          vtpTblConInf))
        return -1;

    while((DbsCONINF(
               DBS_FETCH,
              vtpTblConInf) == 0) &&
          ((liConX = (*vnpConNum)++) < MAX_CON_NUM)) {
        vcripConInf[liConX].iFldIndex = vtpTblConInf->fld_index;
        vcripConInf[liConX].iBeginPtr = vtpTblConInf->begin_byte_pos;
        if(vtpTblConInf->format_chg_need) {
            vcripConInf[liConX].nValL = 
				ConvCutBlankTailLen((unsigned char *)&vtpTblConInf->val, 35) / 2;
        /*  vcripConInf[liConX].nValL = vtpTblConInf->val.len / 2; */
            if(nMAsciiHexToBinary(
                  (unsigned char *)&vtpTblConInf->val[0],
                  strlen(vtpTblConInf->val),
             /*   &vtpTblConInf->val.arr[0],
                  vtpTblConInf->val.len,  */
                  &vcripConInf[liConX].saVal[0]))
                return -1;
        }
        else {
            vcripConInf[liConX].nValL = 
				ConvCutBlankTailLen((unsigned char *)&vtpTblConInf->val, 35);
         /* vcripConInf[liConX].nValL = vtpTblConInf->val.len; */
            memcpy(
               vcripConInf[liConX].saVal,
               vtpTblConInf->val,
               strlen(vtpTblConInf->val));
           /*  vtpTblConInf->val.arr,
               vtpTblConInf->val.len);  */
        } /* end of if */
        vcripConInf[liConX].nTxnNumber = vtpTblConInf->txn_num;
    } /* end of while */
    
    if(DbsCONINF(
          DBS_CLOSE,
          vtpTblConInf) != LSqlSuccess)
        return -1;

    liConX = *vnpConNum - 1;
    vcripConInf[liConX--].iNextGrp = *vnpConNum;
    for(; liConX >= 0; liConX--) {
      //  if(vcripConInf[liConX].nTxnNumber == vcripConInf[liConX + 1].nTxnNumber)
        if((vcripConInf[liConX].nTxnNumber == vcripConInf[liConX + 1].nTxnNumber) && (vcripConInf[liConX].iFldIndex < vcripConInf[liConX + 1].iFldIndex))  /* add by shine, support many to one*/
            vcripConInf[liConX].iNextGrp = vcripConInf[liConX + 1].iNextGrp;
        else
            vcripConInf[liConX].iNextGrp = liConX + 1;
    } /* end of for */

    return 0;
} /* end of nMLoadConInf */

short nMLoadBmpInf(
         long                vlBmpInfKey,
         Tbl_bmp_inf_Def*    vtpTblBmpInf,
         BmpRuleInfDef*   vbripBmpInf) {

    short   liBmpX;
	/*
	int ret;
	*/

    vtpTblBmpInf->usage_key = vlBmpInfKey;
    HtLog ("Bridge.1.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"vlBmpInfKey[%l]",vlBmpInfKey); 
    DbsBMPINF(
       DBS_CURSOR,
       vtpTblBmpInf);
    
    if(DbsBMPINF(
          DBS_OPEN,
          vtpTblBmpInf) != LSqlSuccess)
        return -1;

    while((DbsBMPINF(
              DBS_FETCH,
              vtpTblBmpInf) == 0)) {
        if((liBmpX = vtpTblBmpInf->bmp_index) >= MAX_BMP_NUM)
		{
		            return -1; 
        }
        if(nMAsciiHexToBinary(
              (unsigned char *)&vtpTblBmpInf->bmp_val,
              ConvCutBlankTailLen((unsigned char *)&vtpTblBmpInf->bmp_val, 32),
              &vbripBmpInf[liBmpX].saVal[0]))
        {
            return -1;
        }
        if(((vbripBmpInf[liBmpX].saVal[0] & 0x80) &&
            (ConvCutBlankTailLen((unsigned char *)&vtpTblBmpInf->bmp_val, 32) != 32)) ||
           (((vbripBmpInf[liBmpX].saVal[0] & 0x80) == 0) &&
             (ConvCutBlankTailLen((unsigned char *)&vtpTblBmpInf->bmp_val, 32) != 16))) 
        {
		    return -1;
        }
    } /* end of while */

    if(DbsBMPINF(
          DBS_CLOSE,
          vtpTblBmpInf) != LSqlSuccess)
        return -1;

    return 0;
} /* end of nMLoadBmpInf */

short nMCalcIpc(
         FldRuleInfDef*  vfripFldInf,
         unsigned char*     vspIpcStr,
         short              vnIpcStrL,
         IpcRuleInfDef*  viripIpcInf) {

    short   liFldX;

    for(liFldX = 0; liFldX < MAX_FLD_NUM; liFldX++)
        viripIpcInf->naFld[liFldX] = -1;
    viripIpcInf->nMsgL = 0;
    liFldX = -1;
    for(; vnIpcStrL > 0; vnIpcStrL--, vspIpcStr++) {
        if(ISNUMBER(*vspIpcStr)) {
            if(liFldX == -1)
                liFldX = *vspIpcStr - '0';
            else
                liFldX = liFldX * 10 + *vspIpcStr - '0';
        } 
        else if(liFldX != -1) {
            if(liFldX >= MAX_FLD_NUM ||
               vfripFldInf[liFldX].iBeginPtr == -2 ||
               viripIpcInf->naFld[liFldX] != -1)
                return -1;
            viripIpcInf->naFld[liFldX] = viripIpcInf->nMsgL;
            viripIpcInf->nMsgL += (
               vfripFldInf[liFldX].nFldLenL + 
               vfripFldInf[liFldX].nDataMaxL + 
               vfripFldInf[liFldX].nIndSym);
            liFldX = -1;
        } /* end of if */
    } /* end of for */
    return 0;
} /* end of nMCalcIpc */

short nMLoadIpcInf(
         long               vlIpcInfKey,
         Tbl_ipc_inf_Def*   vtpTblIpcInf,
         FldRuleInfDef*  vfripFldInf,
         IpcRuleInfDef*  viripIpcInf) {

    short   liIpcX;

    vtpTblIpcInf->usage_key = vlIpcInfKey;
    DbsIPCINF(
       DBS_CURSOR,
       vtpTblIpcInf);
    
    if(DbsIPCINF(
          DBS_OPEN,
          vtpTblIpcInf))
        return -1;

    while((DbsIPCINF(
              DBS_FETCH,
              vtpTblIpcInf) == 0)) {
        if((liIpcX = vtpTblIpcInf->ipc_index) >= MAX_IPC_NUM)
            return -2; 
        
        if(nMCalcIpc(
              vfripFldInf,
              (unsigned char *)&vtpTblIpcInf->ipc_val[0],
              strlen(vtpTblIpcInf->ipc_val),
              &viripIpcInf[liIpcX]))
            return -3;
    } /* end of while */

    if(DbsIPCINF(
          DBS_CLOSE,
          vtpTblIpcInf))
        return -4;

    return 0;
} /* end of nMLoadIpcInf */

short ConvInit(
         long                   vlFldInfKey,
         long                   vlMsgInfKey,
         long                   vlConInfKey,
         long                   vlBmpInfKey,
         long                   vlIpcInfKey,
         TransRuleInfDef*    vtripTransRule) {

    Tbl_fld_inf_Def ltTblFldInf;
    Tbl_msg_inf_Def ltTblMsgInf;
    Tbl_con_inf_Def ltTblConInf;
    Tbl_bmp_inf_Def ltTblBmpInf;
    Tbl_ipc_inf_Def ltTblIpcInf;

	short	nReturnCode;

    if(nReturnCode = nMLoadFldInf(
          					vlFldInfKey,
          					&ltTblFldInf,
          					&vtripTransRule->taFldInf[0])) {
        DbsFLDINF(
           DBS_CLOSE,
           &ltTblFldInf);
        return NUsrErrFldInf;
    } /* end of if */

    if(nReturnCode = nMLoadMsgInf(
          					vlMsgInfKey,
          					&ltTblMsgInf,
          					&vtripTransRule->nMsgNum,
          					&vtripTransRule->taMsgInf[0])) {
        DbsMSGINF(
           DBS_CLOSE,
           &ltTblMsgInf);
        return NUsrErrMsgInf;
    } /* end of if */

    if(nReturnCode = nMLoadConInf(
							vlConInfKey,
							&ltTblConInf,
							&vtripTransRule->nConNum,
							&vtripTransRule->taConInf[0])) {
        DbsCONINF(
           DBS_CLOSE,
           &ltTblConInf);
        return NUsrErrConInf;
    } /* end of if */
    
    if(nReturnCode = nMLoadBmpInf(
          vlBmpInfKey,
          &ltTblBmpInf,
          &vtripTransRule->taBmpInf[0])) {
        DbsBMPINF(
           DBS_CLOSE,
           &ltTblBmpInf);
         return NUsrErrBmpInf;
    } /* end of if */

    if(nReturnCode = nMLoadIpcInf(
          vlIpcInfKey,
          &ltTblIpcInf,
          &vtripTransRule->taFldInf[0],
          &vtripTransRule->taIpcInf[0])) {
        DbsIPCINF(
           DBS_CLOSE,
           &ltTblIpcInf);
        return NUsrErrIpcInf;
    } /* end of if */

    return 0;
} /* end of ConvInit */

void vMNonasciiToAscii(
        unsigned char*  vspInStr,
        short*          vnpInStrL,
        unsigned char*  vspOutStr,
        short           vnOutStrL,
        short           vnCharSet) {

    short   liBufX;
	short	nTmp;
	char	sTmp[4];

    switch(vnCharSet) {
    case NCharSetEbcdic:
        for(; vnOutStrL > 0; vnOutStrL--)
            *vspOutStr++ = SAEbcdicAscii[*vspInStr++];
        *vnpInStrL = vnOutStrL;
        return;

    case NCharSetBcdl:
        for(liBufX = 0; liBufX < vnOutStrL; liBufX++) {
            if(liBufX % 2)
                *vspOutStr++ = (*vspInStr++ & 0x0f) + '0';
            else
                *vspOutStr++ = ((*vspInStr >> 4) & 0x0f) + '0';
        } /* end of for */
        *vnpInStrL = (vnOutStrL + 1) / 2;
        return;

    case NCharSetBcdr:
        *vnpInStrL = (vnOutStrL + 1) / 2;
        vspInStr += ((vnOutStrL + 1) / 2);
        vspOutStr += vnOutStrL;
		liBufX = *vnpInStrL * 2;
        for(; liBufX >= (*vnpInStrL*2-vnOutStrL); liBufX--) {
            if((liBufX+1) % 2)
                *vspOutStr-- =
                   (((*vspInStr--) >> 4) & 0x0f) + '0';
            else
                *vspOutStr-- = (*vspInStr & 0x0f) + '0';
        } /* end of for */
        return;

	case NCharSetBinary:
		if ((vnOutStrL < 2) || (vnOutStrL > 3))
		{
           memcpy(
              vspOutStr,
              vspInStr,
              vnOutStrL);
           *vnpInStrL = vnOutStrL;
		   return;
		}
		nTmp = *vspInStr;
		if (vnOutStrL == 2)
		{
			*vnpInStrL = 1;
			sprintf(sTmp, "%02d", nTmp);
		}
		else
		if (vnOutStrL == 3)
		{
			*vnpInStrL = 2;
			vspInStr++;
			nTmp = nTmp * 256 + (*vspInStr);
			sprintf(sTmp, "%03d", nTmp);
		}
		memcpy(vspOutStr, sTmp, vnOutStrL);
		return;

    default:
        memcpy(
           vspOutStr,
           vspInStr,
           vnOutStrL);
        *vnpInStrL = vnOutStrL;
    } /* end of switch */
} /* end of vMNonasciiToAscii */

short nMBmpAnalysis(
         unsigned char*     vspBmpStr,
         short*             vnpBitNum,
         FldRuleInfDef*  vfripFldInf) {

    char    lsaBmpFilter[8] = {0x80, 0x40, 0x20, 0x10, 8, 4, 2, 1};
    short   liByteX;
    short   liBitX;
    short   liFldX;
	short	liByteXMax;

    if(*vspBmpStr & lsaBmpFilter[0])
	{
        *vnpBitNum = 128;
		liByteXMax = 16;
	}
    else
	{
        *vnpBitNum = 64;
		liByteXMax = 8;
	}

    for(liByteX = 0, liFldX = 1; liByteX < liByteXMax; liByteX++, vspBmpStr++) {
        for(liBitX = 0; liBitX < 8; liBitX++, liFldX++) {
            if(vfripFldInf[liFldX].iBeginPtr != -2)
                vfripFldInf[liFldX].iBeginPtr = -1;
            if(*vspBmpStr & lsaBmpFilter[liBitX]) {
                if(vfripFldInf[liFldX].iBeginPtr == -2)
                    return(liFldX * 10 + NIllNullFld);
                if(liFldX <= *vnpBitNum)
                    vfripFldInf[liFldX].iBeginPtr = 0;
            } /* end of if */
        } /* end of for */
    } /* end of for */

	if (liByteXMax == 8)
	{
		for (liFldX = 65; liFldX <= 128; liFldX++)
            if(vfripFldInf[liFldX].iBeginPtr != -2)
                vfripFldInf[liFldX].iBeginPtr = -1;
	}

    return 0;
} /* end of nMBmpAnalysis */

short nMFormatChk(
         unsigned char* vspMsg,
         short          vnMsgL,
         short          vnMsgType)
{

    short   liStrX;
    short   liBufX;
    short   lnSpaceBegin;

    switch(vnMsgType) {
    case NFormatANS:
        return 0;

    case NFormatAN:
        lnSpaceBegin = NFalse;
        for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
            if(ISNUMBER(*vspMsg) ||
               ISALPHA(*vspMsg)) {
                if(lnSpaceBegin)
                    return -1;
            }
            else if(ISSPACE(*vspMsg))
                lnSpaceBegin = NTrue;
            else
                return -1;
        } /* end of for */
        return 0;

    case NFormatSN:
        if((*vspMsg != 'D') &&
           (*vspMsg != 'C'))
            return -1;
        vspMsg++;
        vnMsgL--;

    case NFormatN:
        for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
            if(!ISNUMBER(*vspMsg))
                return -1;
        } /* end of for */
        return 0;

    case NFormatZ:
        for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
            if(!ISNUMBER(*vspMsg) &&
               *vspMsg != '=')
                return -1;
        } /* end of for */
        return 0;

    case NFormatMMDDhhmmss:
        if(vnMsgL != 10)
            return -1;
        if((memcmp(&vspMsg[0],
               "01",
               2) < 0) ||
           (memcmp(&vspMsg[0],
               "12",
               2) > 0))
            return -1;
        if((memcmp(&vspMsg[2],
               "01",
               2) < 0) ||
           (memcmp(&vspMsg[2],
               "31",
               2) > 0))
            return -1;
        if(memcmp(&vspMsg[4],
              "23",
              2) > 0)
            return -1;
        if(memcmp(&vspMsg[6],
              "59",
              2) > 0)
            return -1;
        if(memcmp(&vspMsg[8],
              "59",
              2) > 0)
            return -1;
        for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
            if(!ISNUMBER(*vspMsg))
                return -1;
        } /* end of for */
        return 0;

    case NFormatMMDD:
        if(vnMsgL != 4)
            return -1;
        if((memcmp(&vspMsg[0],
               "01",
               2) < 0) ||
           (memcmp(&vspMsg[0],
               "12",
               2) > 0))
            return -1;
        if((memcmp(&vspMsg[2],
               "01",
               2) < 0) ||
           (memcmp(&vspMsg[2],
               "31",
               2) > 0))
            return -1;
        for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
            if(!ISNUMBER(*vspMsg))
                return -1;
        } /* end of for */
        return 0;

    case NFormathhmmss:
        if(vnMsgL != 6)
            return -1;
        if(memcmp(&vspMsg[0],
              "23",
              2) > 0)
            return -1;
        if(memcmp(&vspMsg[2],
              "59",
              2) > 0)
            return -1;
        if(memcmp(&vspMsg[4],
              "59",
              2) > 0)
            return -1;
        for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
            if(!ISNUMBER(*vspMsg))
                return -1;
        } /* end of for */
        return 0;

    case NFormatYYMMDD:
        if(vnMsgL != 6)
            return -1;
        if(memcmp(&vspMsg[0],
              "99",
              2) > 0)
            return -1;
        if((memcmp(&vspMsg[2],
               "01",
               2) < 0) ||
           (memcmp(&vspMsg[2],
               "12",
               2) > 0))
            return -1;
        if((memcmp(&vspMsg[4],
               "01",
               2) < 0) ||
           (memcmp(&vspMsg[4],
               "31",
               2) > 0))
            return -1;
        for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
            if(!ISNUMBER(*vspMsg))
                return -1;
        } /* end of for */
        return 0;

    case NFormatP1:
        if(vnMsgL != 2 &&
           vnMsgL != 51 &&
           vnMsgL != 100 &&
           vnMsgL != 149 &&
           vnMsgL != 198)
            return -1;
        for(; vnMsgL > 0; vspMsg++, vnMsgL--) {
            if(!ISNUMBER(*vspMsg))
                return -1;
        } /* end of for */
        return 0;

    case NFormatP2:
        if(vnMsgL != 20 &&
           vnMsgL != 40 &&
           vnMsgL != 60)
            return -1;
        for(liStrX = vnMsgL / 20; liStrX > 0; liStrX--) {
            if(memcmp(
                  vspMsg,
                  "10",
                  2) && 
               memcmp(
                  vspMsg,
                  "30",
                  2) &&
               memcmp(
                  vspMsg,
                  "19",
                  2))
                return -1;
            vspMsg += 2;
            if(memcmp(
                  vspMsg,
                  "01",
                  2) && 
               memcmp(
                  vspMsg,
                  "02",
                  2) &&
               memcmp(
                  vspMsg,
                  "16",
                  2))
                return -1;
            vspMsg += 2;
            lnSpaceBegin = NFalse;
            for(liBufX = 0; liBufX < 3; vspMsg++, liBufX++) {
                if(ISNUMBER(*vspMsg) ||
                   ISALPHA(*vspMsg)) {
                    if(lnSpaceBegin)
                        return -1;
                }
                else if(ISSPACE(*vspMsg))
                    lnSpaceBegin = NTrue;
                else
                    return -1;
            } /* end of for */
            if((*vspMsg != 'D') &&
               (*vspMsg != 'C'))
                return -1;
            for(++vspMsg, liBufX = 12; liBufX > 0; liBufX--, vspMsg++) {
                if(!ISNUMBER(*vspMsg))
                    return -1;
            } /* end of for */
        } /* end of for */
        return 0;

    case NFormatP3:
        if(vnMsgL < 4)
            return -1;
        for(liBufX = 0; liBufX < 4; vspMsg++, liBufX++) {
            if(!ISNUMBER(*vspMsg))
                return -1;
        } /* end of for */
        return 0;

    default:
        return -1;
    } /* end of switch */

} /* end of nMFormatChk */

short nMGetTxnNumber(
         unsigned char*     vspMsg,
         FldRuleInfDef*  vfripFldInf,
         ConRuleInfDef*  vcripConInf,
         short              vnConNum,
         short*             vnpTxnNumber) {

    short   liConX;
    short   liFldX;
    short   liBufX;

    liConX = 0;
    while(liConX < vnConNum) {
		/* �趨����ƥ�����liFldX */
        liFldX = vcripConInf[liConX].iFldIndex;
		/* ��������ƥ�����Ϣ�����vspMsg����ʼλ��liBufX */
        liBufX =
           vfripFldInf[liFldX].iBeginPtr + 
           vfripFldInf[liFldX].nFldLenL +
           vcripConInf[liConX].iBeginPtr - 1;
		/* ����ƥ�����liFldX���� */
		/* ����ƥ�����Ϣ�յ�λ�ð�����liFldX��֮�� 
			�þֵ��� vcripConInf[liConX].nValL 
			<= vfripFldInf[liFldX].nFldL - vcripConInf[liConX].iBeginPtr + 1*/
		/* ����ƥ�����Ϣ��ͬ */
        if((vfripFldInf[liFldX].iBeginPtr >= 0) &&   
           	(liBufX + vcripConInf[liConX].nValL <=
            		vfripFldInf[liFldX].iBeginPtr +
            		vfripFldInf[liFldX].nFldL) &&
           	(memcmp(&vspMsg[liBufX],
               		&vcripConInf[liConX].saVal[0],
               		vcripConInf[liConX].nValL) == 0))
		{
			/* �Ѿ�ƥ����һ�� */
            if(vcripConInf[liConX].iNextGrp == (liConX++) + 1)
			{
                *vnpTxnNumber = vcripConInf[--liConX].nTxnNumber;
                return 0;
            } /* end of if */ 
        }
        else {
			/* ������һ������ʧ�ܣ���������һ�����ʼλ�� */
            liConX = vcripConInf[liConX].iNextGrp;
        } /* end of if */
    } /* end of while */

    return -1;
} /* end of nMGetTxnNumber */

short nMGetMsgInf(
         MsgRuleInfDef*  vmripMsgInf,
         short              vnMsgNum,
         short              vnTxnNumber,
         short*             vnpBmpIndex,
         short*             vnpMandBmpIndex,
         short*             vnpIpcIndex,
         unsigned char*     vspTxnCode,
         unsigned char*     vspMsgType) {
    
    short   liMsgX;

    for(liMsgX = 0; (liMsgX < vnMsgNum) &&
                    (vmripMsgInf[liMsgX++].nTxnNumber != vnTxnNumber););

    if(vmripMsgInf[--liMsgX].nTxnNumber != vnTxnNumber) 
        return -1;

    *vnpBmpIndex = vmripMsgInf[liMsgX].iBmpIndex;
    *vnpMandBmpIndex = vmripMsgInf[liMsgX].iMandBmpIndex;
HtLog ("convert.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "*vnpBmpIndex[%d]",*vnpBmpIndex);
HtLog ("convert.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "*vnpMandBmpIndex[%d]",*vnpMandBmpIndex);
    *vnpIpcIndex = vmripMsgInf[liMsgX].iIpcIndex;
    memcpy(
       vspTxnCode,
       &vmripMsgInf[liMsgX].saTxnCode[0],
       F129_TXN_CODE_LEN);
    memcpy(
       vspMsgType,
       &vmripMsgInf[liMsgX].saMsgType[0],
       F000_MSG_TYPE_LEN);

    return 0;
} /* end of nMGetMsgInf */

short nMFldTranslate(
         unsigned char**    vsppInBuf,
         short*             vnpInBufL,
         short              vnMaxInBufL,
         short              vnInBufCharSet, 
         short              vnInBufCompress, 
         unsigned char**    vsppOutBuf,
         short*             vnpOutBufL,
         FldRuleInfDef*  vfripFldInf) {

    short           lnInBufL;
    short           lnFldL;
    unsigned char   lsaFldL[4];

    vfripFldInf->iBeginPtr = *vnpOutBufL;
    if(vfripFldInf->nFldLenL == 0)
        lnFldL = vfripFldInf->nDataMaxL;
    else {
    	/*
        if((!vnInBufCompress) ||
           (vfripFldInf->nLenCharSet == NCharSetAscii))
        050906 do not check vnInBufCompress */
        if (vfripFldInf->nLenCharSet == NCharSetAscii)
            vMNonasciiToAscii(
               *vsppInBuf,
               &lnInBufL,
               *vsppOutBuf,
               vfripFldInf->nFldLenL,
               vnInBufCharSet);
        else
            vMNonasciiToAscii(
               *vsppInBuf,
               &lnInBufL,
               *vsppOutBuf,
               vfripFldInf->nFldLenL,
               vfripFldInf->nLenCharSet);


        if(nMFormatChk(
              *vsppOutBuf,
              vfripFldInf->nFldLenL,
              NFormatN))
            return NIllLenExp;

        memcpy(
           lsaFldL,
           *vsppOutBuf,
           vfripFldInf->nFldLenL);
        lsaFldL[vfripFldInf->nFldLenL] = ' ';
        lnFldL = atoi(
                    (char*)(&lsaFldL[0]));

        if((lnFldL > vfripFldInf->nDataMaxL) ||
           ((vfripFldInf->nLenExpVal) &&
            (lnFldL != vfripFldInf->nLenExpVal)))
            return NIllLenExp;

        *vsppInBuf += lnInBufL;
        *vnpInBufL += lnInBufL;
        *vsppOutBuf += vfripFldInf->nFldLenL;
        *vnpOutBufL += vfripFldInf->nFldLenL;

        if(*vnpInBufL > vnMaxInBufL)
            return NIllLenExp;
    } /* end of if */
                
    vfripFldInf->nFldL = vfripFldInf->nFldLenL + lnFldL;

	/*
    if((!vnInBufCompress) ||
       (vfripFldInf->nDataCharSet == NCharSetAscii))
        050906 do not check vnInBufCompress */
    if(vfripFldInf->nDataCharSet == NCharSetAscii)
        vMNonasciiToAscii(
           *vsppInBuf,
           &lnInBufL,
           *vsppOutBuf,
           lnFldL,
           vnInBufCharSet);
    else
        vMNonasciiToAscii(
           *vsppInBuf,
           &lnInBufL,
           *vsppOutBuf,
           lnFldL,
           vfripFldInf->nDataCharSet);

    /******** add by yu0 for 8583.log begin********/
#if 0
    {
		int				i;
		char			c;
        c = (unsigned char)(*vsppOutBuf[0]);
		if( vfripFldInf->nDataCharSet==NCharSetBinary && isascii(c)) 
		{
			HtLogNoDate( gsLogFileName,"		[");
			for( i = 0; i < lnInBufL; i++ )
				HtLogNoDate( gsLogFileName,"%02X ",(unsigned char)(*vsppInBuf)[i] );
			HtLogNoDate( gsLogFileName,"]\n" );
		}		
		else
		{
			HtLogNoDate ( gsLogFileName,"		[%*.*s].\n",lnInBufL,lnInBufL,*vsppOutBuf);
		}
	}
#endif
   /******** add by yu0 for 8583.log end  ********/
    if(nMFormatChk(
          *vsppOutBuf,
          lnFldL,
          vfripFldInf->nDataFormat))
        return NIllFormatDataExp;
    
    *vsppInBuf += lnInBufL;
    *vnpInBufL += lnInBufL;
    *vsppOutBuf += lnFldL;
    *vnpOutBufL += lnFldL;

    if(*vnpInBufL > vnMaxInBufL)
        return NIllMaxlenDataExp;
    
    return 0;
} /* end of nMFldTranslate */

short ConvOutToIn(
         void*                  vvpInBuf,
         short                  vnInBufL,
         short                  vnInBufCharSet, 
         short                  vnInBufCompres, 
         TransRuleInfDef*    vtripTransRule,
         void*                  vvpOutBuf,
         short*                 vnpOutBufL) {

    char            lsaBmpFilter[8] = {0x80, 0x40, 0x20, 0x10, 8, 4, 2, 1};
    short           liFldX;
    short           liBitX;
    short           liBufX;
    short           liBmpX;
    short           liIpcX;
    short           lnResult;
    short           lnBitNum = 0;
    short           lnBitNum0;
    short           lnInBufL;
    short           lnOutBufL;
    short           liMandBmpX;
    short           lnTxnNumber;
	unsigned char	lsaTxnNumber[F130_TXN_NUMBER_LEN+1];
	/*
    short*          lnpTmpVal;
	*/
    unsigned char   lsErrBmp;
    unsigned char   lsaTxnCode[F129_TXN_CODE_LEN];
    unsigned char   lsaMsgType[F000_MSG_TYPE_LEN];
    unsigned char   lsaNewHead[F131_NEW_HEAD_LEN];
    unsigned char   lsaOutBuf[NMaxMsgBufL * 2];
    unsigned char*  lspInBuf;
    unsigned char*  lspTmpBuf;
    unsigned char*  lspOutBuf;

    if(vnInBufL > NMaxMsgBufL ||
       vnInBufL < 0) 
        return NIllLenExp;

    lspInBuf = vvpInBuf;
	if(lspInBuf[0] != '0')	
	{
		memset(lsaNewHead,0,sizeof(lsaNewHead));
		memcpy(lsaNewHead,(char *)lspInBuf,F131_NEW_HEAD_LEN);
		lspInBuf = lspInBuf + 46;
		vnInBufL = vnInBufL - 46;
	}
    lspOutBuf = vvpOutBuf;
    lspTmpBuf = &lsaOutBuf[0];
    lnInBufL = 0;
    lnOutBufL = 0;
    vtripTransRule->taFldInf[0].iBeginPtr = 0;

    /******** add by yu0 for 8583.log begin********/
#if 0
    strcpy( gsLogFileName,"8583.log" );
	HtLogNoDate ( gsLogFileName,"\n\n");
	HtLogNoDate ( gsLogFileName, "MsgType=[%4.4s],BITMAP=[",lspInBuf );
	HtLogNoDate ( gsLogFileName, "ConvOutToIn Debug.\n" ) ; 
	{
		int i;
		
		for( i = 4; i < 16+4; i++ )
			HtLogNoDate( gsLogFileName,"%02X",(unsigned char *)lspInBuf[i] );
	}	HtLogNoDate ( gsLogFileName, "]\n" );
#endif
    /******** add by yu0 for 8583.log end********/
	lnBitNum0 = 128;
    for(liFldX = 0; liFldX <= lnBitNum0; liFldX++) {
        switch(liFldX) {
        case 1:
            if(nMBmpAnalysis(
                  lspInBuf,
                  &lnBitNum,
                  &vtripTransRule->taFldInf[0])) 
                return (liFldX * 10 + NIllBMPDataExp);
            vtripTransRule->taFldInf[1].iBeginPtr = lnOutBufL;
            memcpy(
               lspTmpBuf,
               lspInBuf,
               lnBitNum / 8);
            lspInBuf += lnBitNum / 8;
            lnInBufL += lnBitNum / 8;
            lspTmpBuf += lnBitNum / 8;
            lnOutBufL += lnBitNum / 8;
            if(lnInBufL > vnInBufL)
                return (liFldX * 10 + NIllOutputDataExp);
			lnBitNum0 = lnBitNum;
            break;

        default:
            if(vtripTransRule->taFldInf[liFldX].iBeginPtr < 0)
                break;
    /******** add by yu0 for 8583.log begin********/
#if 0
            HtLogNoDate ( gsLogFileName,"Bit [%d] = \t",liFldX );
#endif
    /******** add by yu0 for 8583.log end  ********/
            lnResult = nMFldTranslate(
                          &lspInBuf,
                          &lnInBufL,
                          vnInBufL,
                          vnInBufCharSet, 
                          vnInBufCompres,
                          &lspTmpBuf,
                          &lnOutBufL,
                          &vtripTransRule->taFldInf[liFldX]);

            if(lnResult)
                return (liFldX * 10 + lnResult);
        } /* end of switch */
    } /* end of for */

    if(nMGetTxnNumber(
          &lsaOutBuf[0],
          &vtripTransRule->taFldInf[0],
          &vtripTransRule->taConInf[0],
          vtripTransRule->nConNum,
          &lnTxnNumber))
        return (130 * 10 + NIllDataExp);
HtLog ("convert.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "OutToIn lnTxnNumber[%d]",lnTxnNumber);
	
    if(nMGetMsgInf(
          &vtripTransRule->taMsgInf[0],
          vtripTransRule->nMsgNum,
          lnTxnNumber,
          &liBmpX,
          &liMandBmpX,
          &liIpcX,
          &lsaTxnCode[0],
          &lsaMsgType[0]))
        return (131 * 10 + NIllDataExp);

    lspTmpBuf = &lsaOutBuf[vtripTransRule->taFldInf[1].iBeginPtr];
    for(liBufX = 0; liBufX < lnBitNum / 8; liBufX++, lspTmpBuf++) {
        if(lsErrBmp = 
              (*lspTmpBuf &
               vtripTransRule->taBmpInf[liMandBmpX].saVal[liBufX]) ^
               vtripTransRule->taBmpInf[liMandBmpX].saVal[liBufX]) {
            for(liBitX = 0; (lsErrBmp & lsaBmpFilter[liBitX++]) == 0;);
            liFldX = liBufX * 8 + liBitX;
            return (liFldX * 10 + NIllBmpNull);
        } /* end of if */
		/* add by ChenLiang 2005-08-31 */
        if(lsErrBmp = 
              (*lspTmpBuf |
               vtripTransRule->taBmpInf[liBmpX].saVal[liBufX]) ^
               vtripTransRule->taBmpInf[liBmpX].saVal[liBufX]) {
            for(liBitX = 0; (lsErrBmp & lsaBmpFilter[liBitX++]) == 0;);
            liFldX = liBufX * 8 + liBitX;
            return (liFldX * 10 + NIllBmpNull);
        } /* end of if */
    } /* end of for */

    memset(
       lspOutBuf,
       ' ',
       4096); 
    for(liFldX = 0; liFldX < MAX_FLD_NUM; liFldX++) {
        liBufX = vtripTransRule->taIpcInf[liIpcX].naFld[liFldX];
        liBitX = vtripTransRule->taFldInf[liFldX].iBeginPtr;    
        switch(liFldX) {
		case 131:
			if(liBufX >= 0)
				{
				memcpy(&lspOutBuf[liBufX],&lsaNewHead[0],F131_NEW_HEAD_LEN);
			  }
			break;

        case 130:
            if(liBufX < 0)
                return (130 * 10 + NIllBmpNull);
			sprintf((char *)&lsaTxnNumber, "%04d", lnTxnNumber);
			memcpy(
				&lspOutBuf[liBufX],
				&lsaTxnNumber[0],
				F130_TXN_NUMBER_LEN);
            break;

        case 129:
            if(liBufX >= 0)
                memcpy(
                   &lspOutBuf[liBufX],
                   &lsaTxnCode[0],
                   F129_TXN_CODE_LEN);
            break;

        default:
            if(liBufX < 0)
                break;
            if(vtripTransRule->taFldInf[liFldX].nIndSym) {
                if(liBitX < 0) {
                    lspOutBuf[liBufX] = SIndNull;
                    break;
                }
                else
                    lspOutBuf[liBufX++] = SIndFull;
            } /* end of if */
            if(liBitX >= 0)
                memcpy(
                   &lspOutBuf[liBufX],
                   &lsaOutBuf[liBitX],
                   vtripTransRule->taFldInf[liFldX].nFldL);
        } /* end of switch */
    } /* end of for */                    
       *vnpOutBufL = vtripTransRule->taIpcInf[liIpcX].nMsgL; 
        
    return 0;
} /* end of ConvOutToIn */

short nMBuildBmp(
         FldRuleInfDef*  vfripFldInf,
         short*             vnBitNum,
         unsigned char*     vspBmpStr) {

    char    lsaBmpFilter[8] = {0x80, 0x40, 0x20, 0x10, 8, 4, 2, 1};
    short   liBufX;
    short   liBitX;
	short	nSndFlag;
    
    for(liBufX = 0; liBufX < 8; liBufX++, vspBmpStr++) {
        *vspBmpStr = 0;
        for(liBitX = 0; liBitX < 8; liBitX++)
            if(vfripFldInf[liBufX * 8 + liBitX + 1].iBeginPtr >= 0)
                *vspBmpStr += lsaBmpFilter[liBitX];
    } /* end of for (1. first bitmap) */
	if (*vnBitNum == 64)
	{
        vfripFldInf->iBeginPtr = -1;
		return 0;
	}

	/* input *vnBitNum == 128 */
	nSndFlag = 0;
    for(liBufX = 8; liBufX < 16; liBufX++, vspBmpStr++) {
        *vspBmpStr = 0;
        for(liBitX = 0; liBitX < 8; liBitX++)
            if(vfripFldInf[liBufX * 8 + liBitX + 1].iBeginPtr >= 0)
			{
                *vspBmpStr += lsaBmpFilter[liBitX];
				nSndFlag = 1;
			}
    } /* end of for (2. second bitmap) */

	if (nSndFlag == 1) /* 128 */
	{
        vfripFldInf->iBeginPtr = 0;
		*vnBitNum = 128;
	}
	else if (nSndFlag == 0) /* 64 */
	{
        vfripFldInf->iBeginPtr = -1;
		*vnBitNum = 64;
		vspBmpStr -= 16;
		if (vfripFldInf[1].iBeginPtr >= 0)
        	*vspBmpStr -= lsaBmpFilter[0];
	}
	else
        return -1;

    return 0;
} /* end of nMBuildBmp */

void vMAsciiToNonascii(
        unsigned char*  vspInStr,
        short           vnInStrL,
        unsigned char*  vspOutStr,
        short*          vnpOutStrL,
        short           vnCharSet) {

    short   liBufX;
	short	nTmp;
	char	sTmp[4];

    switch(vnCharSet) {
    case NCharSetEbcdic:
        for(; vnInStrL > 0; vnInStrL--)
            *vspOutStr++ = SAAsciiEbcdic[*vspInStr++];
        *vnpOutStrL = vnInStrL;
        return;

    case NCharSetBcdl:
        for(liBufX = 0; liBufX < vnInStrL; liBufX++) {
            if(liBufX % 2)
                (*vspOutStr++) += ((*vspInStr++) - '0');
            else
                *vspOutStr = ((*vspInStr++) - '0') * 0x10;
        } /* end of for */
        *vnpOutStrL = (vnInStrL + 1) / 2;
        return;

    case NCharSetBcdr:
        *vnpOutStrL = (vnInStrL + 1) / 2;
        *vspOutStr = 0;
        for(; vnInStrL > 0; vnInStrL--) {
            if(vnInStrL % 2)
                (*vspOutStr++) += ((*vspInStr++) - '0');
            else
                *vspOutStr = ((*vspInStr++) - '0') * 0x10;
        } /* end of for */
        return;

	case NCharSetBinary:
		if ((vnInStrL < 2) || (vnInStrL > 3))
		{
           memcpy(
              vspOutStr,
              vspInStr,
              vnInStrL);
           *vnpOutStrL = vnInStrL;
		   return;
		}
		memcpy(sTmp, vspInStr, vnInStrL);
		sTmp[vnInStrL] = 0;
		nTmp = atoi(sTmp);
		if (vnInStrL == 2) 
		{
			*vnpOutStrL = 1;
			*vspOutStr = nTmp;
		}
		else
		if (vnInStrL == 3) 
		{
			*vnpOutStrL = 2;
			*vspOutStr = nTmp / 256;
			vspOutStr++;
			*vspOutStr = nTmp % 256;
		}
		return;

    default:
        memcpy(
           vspOutStr,
           vspInStr,
           vnInStrL);
        *vnpOutStrL = vnInStrL;
    } /* end of switch */
} /* end of vMNonasciiToAscii */

short nMMsgTranslate(
         unsigned char*     vspInBuf,
         short              vnOutBufCharSet, 
         short              vnOutBufCompress, 
         unsigned char**    vsppOutBuf,
         short              vnMaxOutBufL,
         short*             vnpOutBufL,
         FldRuleInfDef*  vfripFldInf) {

	/*
    short           lnInBufL;
	*/
    short           lnFldL;
    short           lnOutBufL;
    unsigned char   lsaFldL[4];

    vspInBuf += vfripFldInf->nIndSym;
    if(vfripFldInf->nFldLenL == 0)
        lnFldL = vfripFldInf->nDataMaxL;
    else {
        if(*vnpOutBufL + vfripFldInf->nFldLenL > vnMaxOutBufL)
            return NIllBmpNull;

        if(nMFormatChk(
              vspInBuf,
              vfripFldInf->nFldLenL,
              NFormatN))
           return NIllLenExp;

        memcpy(
           &lsaFldL[0],
           vspInBuf,
           vfripFldInf->nFldLenL);
        lsaFldL[vfripFldInf->nFldLenL] = ' ';
        lnFldL = atoi(
                    (char*)(&lsaFldL[0]));
        if((lnFldL > vfripFldInf->nDataMaxL) ||
           ((vfripFldInf->nLenExpVal) &&
            (lnFldL != vfripFldInf->nLenExpVal)))
            return NIllLenExp;

		/*
        if((!vnOutBufCompress) ||
           (vfripFldInf->nLenCharSet == NCharSetAscii))
        050906 do not check vnOutBufCompress */
        if(vfripFldInf->nLenCharSet == NCharSetAscii)
            vMAsciiToNonascii(
               vspInBuf,
               vfripFldInf->nFldLenL,
               *vsppOutBuf,
               &lnOutBufL,
               vnOutBufCharSet);
        else
            vMAsciiToNonascii(
               vspInBuf,
               vfripFldInf->nFldLenL,
               *vsppOutBuf,
               &lnOutBufL,
               vfripFldInf->nLenCharSet);

        vspInBuf += vfripFldInf->nFldLenL,
        *vsppOutBuf += lnOutBufL;
        *vnpOutBufL += lnOutBufL;
    } /* end of if */
                
    if(*vnpOutBufL + lnFldL > vnMaxOutBufL)
        return NIllBmpNull;
    
    if(nMFormatChk(
          vspInBuf,
          lnFldL,
          vfripFldInf->nDataFormat))
    {
        return NIllFormatDataExp;
    }

	/*
    if((!vnOutBufCompress) ||
       (vfripFldInf->nDataCharSet == NCharSetAscii))
        050906 do not check vnOutBufCompress */
    if(vfripFldInf->nDataCharSet == NCharSetAscii)
        vMAsciiToNonascii(
           vspInBuf,
           lnFldL,
           *vsppOutBuf,
           &lnOutBufL,
           vnOutBufCharSet);
    else
        vMAsciiToNonascii(
           vspInBuf,
           lnFldL,
           *vsppOutBuf,
           &lnOutBufL,
           vfripFldInf->nDataCharSet);
    
    /******** add by yu0 for 8583.log begin********/
#if 0
    {
		int				i;
		char			c;
		
		c = (unsigned char)(*vsppOutBuf[0]);
		if( vfripFldInf->nDataCharSet==NCharSetBinary && isascii(c))
		{
			HtLogNoDate( gsLogFileName,"		[");
			for( i = 0; i < lnOutBufL; i++ )
				HtLogNoDate( gsLogFileName,"%02X ",(unsigned char)(*vsppOutBuf)[i] );
			HtLogNoDate( gsLogFileName,"]\n" );
		}		
		else
		{
			HtLogNoDate ( gsLogFileName,"		[%*.*s].\n",lnOutBufL,lnOutBufL,*vsppOutBuf);
		}
	}
#endif
	/******** add by yu0 for 8583.log end  ********/
    *vsppOutBuf += lnOutBufL;
    *vnpOutBufL += lnOutBufL;
    
    return 0;
} /* end of nMMsgTranslate */

short ConvInToOut(
         void*                  vvpInBuf,
         short                  vnInBufL,
         short                  vnOutBufCharSet, 
         short                  vnOutBufCompres, 
         TransRuleInfDef*    vtripTransRule,
         void*                  vvpOutBuf,
         short*                 vnpOutBufL) {

	/*
    short           liBitX;
	*/
    short           liFldX;
    short           liBmpX;
    short           liIpcX;
    short           lnResult;
    short           lnBitNum = 0;
    short           liMandBmpX;
    short           lnTxnNumber;
	unsigned char	lsaTxnNumber[F130_TXN_NUMBER_LEN+1];
    short           lnMaxOutBufL;
    unsigned char   lsaMsgType[F000_MSG_TYPE_LEN];
    unsigned char   lsaTxnCode[F129_TXN_CODE_LEN];
    unsigned char*  lspInBuf;
    unsigned char*  lspOutBuf;
    /*
    unsigned char*  lspOutTmpBuf;
	int				i;
	*/
	int       nOffset ,lnFldL,lnFldLenL ;
	int				i;
	
    lspInBuf = vvpInBuf;
    lspOutBuf = vvpOutBuf;
    if(vnInBufL > NMaxMsgBufL ||
       vnInBufL < 2) 
        return NIllLenExp;

    lnMaxOutBufL = *vnpOutBufL; 
	memcpy(&lsaTxnNumber[0], &lspInBuf[HEADER_BUF_LEN], F130_TXN_NUMBER_LEN);
	lsaTxnNumber[F130_TXN_NUMBER_LEN] = 0;
	lnTxnNumber = atoi((char *)&lsaTxnNumber);
HtLog ("convert.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "InToOut lnTxnNumber[%d]",lnTxnNumber);
    if(nMGetMsgInf(
          &vtripTransRule->taMsgInf[0],
          vtripTransRule->nMsgNum,
          lnTxnNumber,
          &liBmpX,
          &liMandBmpX,
          &liIpcX,
          &lsaTxnCode[0],
          &lsaMsgType[0]))
        return (131 * 10 + NIllDataExp);

HtDebugString ("convert.log", HT_LOG_MODE_ERROR, __FILE__, __LINE__,&vtripTransRule->taMsgInf[liBmpX].saMsgType[0],4);
HtDebugString ("convert.log", HT_LOG_MODE_ERROR, __FILE__, __LINE__,&vtripTransRule->taBmpInf[liBmpX].saVal[0],16);
    if(nMBmpAnalysis(
          &vtripTransRule->taBmpInf[liBmpX].saVal[0],
          &lnBitNum,
          &vtripTransRule->taFldInf[0])) 
        return (1 * 10 + NIllDataExp);

    for(liFldX = 2; liFldX <= lnBitNum; liFldX++)
	{
        if((vtripTransRule->taFldInf[liFldX].iBeginPtr != -2) &&
           ((vtripTransRule->taIpcInf[liIpcX].naFld[liFldX] == -1) ||
            ((vtripTransRule->taFldInf[liFldX].nIndSym) &&
             (FLDNONEXIST(
                 lspInBuf[vtripTransRule->taIpcInf[liIpcX].naFld[liFldX]])))))
            vtripTransRule->taFldInf[liFldX].iBeginPtr = -1;
         
         /* add by lgm */
         if ( vtripTransRule->taFldInf[liFldX].iBeginPtr != -1 )
      	{
			if(vtripTransRule->taFldInf[liFldX].nFldLenL == 0)
			{
				lnFldL = vtripTransRule->taFldInf[liFldX].nDataMaxL;

				nOffset = vtripTransRule->taIpcInf[liIpcX].naFld[liFldX];

				for ( i = 0 ; i  < lnFldL ; i++ )
				{
					if(lspInBuf[nOffset+i] != 0x20 )
						break ;
				}

				if( i == lnFldL )
					vtripTransRule->taFldInf[liFldX].iBeginPtr = -1;
			}
		    else
		    {
		    	lnFldLenL = vtripTransRule->taFldInf[liFldX].nFldLenL ;

		    	nOffset = vtripTransRule->taIpcInf[liIpcX].naFld[liFldX];

		        for ( i = 0 ; i  < lnFldLenL ; i++ )
		        {
	        		if(lspInBuf[nOffset+i] != 0x20 )
	        			break ;
		        }

		        if( i == lnFldLenL )
		        	 vtripTransRule->taFldInf[liFldX].iBeginPtr = -1;
		     }
	   }
	   /* add end */
	}
  /*add by xu zhen*/
  if(!memcmp(&lspInBuf[vtripTransRule->taIpcInf[liIpcX].naFld[61]],"      ",6)){
  	     vtripTransRule->taFldInf[61].iBeginPtr = -1;
  }

  if(!memcmp(&lspInBuf[vtripTransRule->taIpcInf[liIpcX].naFld[57]],"      ",6)){
  	     vtripTransRule->taFldInf[57].iBeginPtr = -1;
  }
   /*end*/
    *vnpOutBufL = 0;
	if(lspInBuf[0] == '\x2E')
	{
    	*vnpOutBufL = HEADER_BUF_LEN;
		memcpy(lspOutBuf,lspInBuf,HEADER_BUF_LEN);
		lspOutBuf += HEADER_BUF_LEN;
	}

    /******** add by yu0 for 8583.log begin********/
#if 0
    strcpy( gsLogFileName,"8583.log" );
	HtLogNoDate ( gsLogFileName, "\n\n" );
	HtLogNoDate ( gsLogFileName, "ConvInToOut Debug.\n" ) ; 
#endif
   /******** add by yu0 for 8583.log end  ********/
    for(liFldX = 0; liFldX <= lnBitNum; liFldX++) {
        switch(liFldX) {
        case 0:
    /******** add by yu0 for 8583.log begin********/
#if 0
        HtLogNoDate ( gsLogFileName,"Bit [%d] =\t",liFldX );
#endif		
    /******** add by yu0 for 8583.log end  ********/
            lnResult = nMMsgTranslate(
                          &lsaMsgType[0],
                          vnOutBufCharSet, 
                          vnOutBufCompres,
                          &lspOutBuf,
                          lnMaxOutBufL, 
                          vnpOutBufL,
                          &vtripTransRule->taFldInf[liFldX]);
            if(lnResult)
            {
                return (liFldX * 10 + lnResult);
            }
            break;

        case 1: 
            if(nMBuildBmp(
                  &vtripTransRule->taFldInf[0],
                  &lnBitNum,
                  lspOutBuf))
                return (1 * 10 + NIllLenExp);
    /******** add by yu0 for 8583.log begin********/
#if 0
            HtLogNoDate ( gsLogFileName, "BITMAP=[" );
			{
				int i;
				
				for( i = 0; i < 16; i++ )
					HtLogNoDate( gsLogFileName,"%02X",(unsigned char *)lspOutBuf[i] );
			}
			HtLogNoDate ( gsLogFileName, "]\n" );
#endif
   /******** add by yu0 for 8583.log end  ********/
            *vnpOutBufL += (lnBitNum / 8);
            lspOutBuf += (lnBitNum / 8);
            break;

        default:
            if(vtripTransRule->taFldInf[liFldX].iBeginPtr < 0)
                break;
            
    /******** add by yu0 for 8583.log begin********/
#if 0
        HtLogNoDate ( gsLogFileName,"Bit [%d] =\t",liFldX );
#endif	
   /******** add by yu0 for 8583.log end  ********/
            lnResult = nMMsgTranslate(
                          &lspInBuf[vtripTransRule->taIpcInf[liIpcX].naFld[liFldX]],
                          vnOutBufCharSet, 
                          vnOutBufCompres,
                          &lspOutBuf,
                          lnMaxOutBufL, 
                          vnpOutBufL,
                          &vtripTransRule->taFldInf[liFldX]);
            if(lnResult)
                return (liFldX * 10 + lnResult);
        } /* end of switch */
    } /* end of for */

    return 0;
} /* end of ConvInToOut */
