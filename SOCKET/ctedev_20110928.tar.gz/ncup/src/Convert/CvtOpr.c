/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: CvtOpr.c													 */
/* DESCRIPTIONS: The save and forward process server.                        */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-26  Yu Tong        Initial Version                                */
/*****************************************************************************/
static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Convert/CvtOpr.c,v 1.1.1.1 2011/08/19 10:55:53 ctedev Exp $"; 

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <memory.h>

#include "IpcInt.h"
#include "DbsTbl.h"
#include "TxnNum.h"
#include "Convert.h"
#include "CvtOpr.h"
#include "ErrCode.h"
#include "MsqOpr.h"
#include "SrvDef.h"
#include "BufChg.h"

/*****************************************************************************/
/* FUNC:   int CvtInit (Tbl_conv_type_Def *ptConvType,                       */
/*                      T_UsageTransRuleDef *ptUsageTransRule );             */
/* INPUT:  ��                                                                */
/* OUTPUT: ptConvType: tbl_conv_type��¼                                     */
/*         ptUsageTransRule: ���usage_key��ISO8583ת������                  */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ʽת���ĳ�ʼ������, ��ת��������ص��ڴ���                      */
/*****************************************************************************/
int CvtInit (Tbl_conv_type_Def *ptConvType, T_UsageTransRuleDef *ptUsageTransRule )
{
	int		nReturnCode;
	int		i, j;
	
	/* load tbl_conv_type */
	nReturnCode = DbsConvTypeLoad (CONV_TYPE_NUM_MAX, ptConvType);
	if (nReturnCode)
		return nReturnCode;
	
	/* init ptUsageTransRule */
	for (j = 0; j < CVT_USAGE_TRANS_RULE_NUM_MAX; j++)
		(ptUsageTransRule+j)->usage_key = -1;
		
	/* for each distinct usage_key load its ISO8583 trans rule */
	for (i = 0; i < CONV_TYPE_NUM_MAX; i++)
	{
		if ((ptConvType+i)->buf_chg_type[0] == CONV_CHG_TYPE_8583)
		{
			for (j = 0;
				j < CVT_USAGE_TRANS_RULE_NUM_MAX &&
					(ptUsageTransRule+j)->usage_key != -1;
				j++)
			{
				if ((ptUsageTransRule+j)->usage_key ==
					(ptConvType+i)->usage_key)
					break;
			}
			if (j == CVT_USAGE_TRANS_RULE_NUM_MAX)
				return 0;
			if ((ptUsageTransRule+j)->usage_key == -1)
			{
				(ptUsageTransRule+j)->usage_key = (ptConvType+i)->usage_key;
				nReturnCode = ConvInit( (ptConvType+i)->usage_key,
										(ptConvType+i)->usage_key, 
										(ptConvType+i)->usage_key,
										(ptConvType+i)->usage_key,
										(ptConvType+i)->usage_key, 
										&((ptUsageTransRule+j)->tTransRule));
				if (nReturnCode)
				{
					return (ERR_CODE_CONV_BASE + nReturnCode);
				}
			}
		}
	}
	
	return 0;
}

/*****************************************************************************/
/* FUNC:   int CvtOutToIn ( Tbl_conv_type_Def *ptConvType,                   */
/*                          T_UsageTransRuleDef *ptUsageTransRule            */
/*                          stIpcDftRuleDef     *ptIpcDftRule                */
/*                          bciMBufChgInfDef    *ptBufChgRule                */
/*                          int nSrcMsgLen, char *sSrcMsgBuf,                */
/*                          int *pnDestMsgLen, char *sDestMsgBuf);           */
/* INPUT:  ptConvType: tbl_conv_type��¼                                     */
/*         ptUsageTransRule: ���usage_key��ISO8583ת������                  */
/*         ptIpcDftRule: ���Ĭ��IPC                                         */
/*         ptBufChgRule: ���BUFCHGת������                                  */
/*         nSrcMsgLen: ��ת����buffer����                                    */
/*         sSrcMsgBuf: ��ת����buffer                                        */
/* OUTPUT: pnDestMsgLen: ת�����buffer����                                  */
/*         sDestMsgBuf: ת�����buffer                                       */
/*         sTxnNum: ת����Ľ��״���, 4λ����                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���ⲿ��ʽ����Ϣת��Ϊ�ڲ�IPC��ʽ                                 */
/*****************************************************************************/
int CvtOutToIn(	Tbl_conv_type_Def *ptConvType,
				T_UsageTransRuleDef *ptUsageTransRule,
				stIpcDftRuleDef *ptIpcDftRule,
				bciMBufChgInfDef *ptBufChgRule,
				int nSrcMsgLen,
				char *sSrcMsgBuf,
				int *pnDestMsgLen,
				char *sDestMsgBuf,
				char *sTxnNum)
{
	char			sTmpMsgBuf[MSQ_MSG_SIZE_MAX];
	short			nLen;
	int				nReturnCode;
	int				i, j;
	int				nTmpMsgLen;
	T_IpcIntMngDef	tIpcIntMng;
	T_IpcIntTxnDef	tIpcIntTxn;

	HtLog("CvtOpr.log", HT_LOG_MODE_NORMAL, __FILE__, __LINE__,"enter CvtOutToIn...");
	for (i = 0; i < CONV_TYPE_NUM_MAX; i++)
	{
		if (!memcmp ((ptConvType+i)->srv_id, sSrcMsgBuf, SRV_ID_LEN) &&
			(ptConvType+i)->buf_chg_type[0] == CONV_CHG_TYPE_8583)
		{
			for (j = 0; j < CVT_USAGE_TRANS_RULE_NUM_MAX; j++)
			{
				if ((ptUsageTransRule+j)->usage_key == (ptConvType+i)->usage_key)
					break;
			}
			if (j < CVT_USAGE_TRANS_RULE_NUM_MAX)
			{
				/* ISO8583 convert */
				nReturnCode =
				ConvOutToIn(
					(unsigned char *)sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER, 
					nSrcMsgLen-SRV_ID_LEN*2-FLD_MSQ_TYPE_LEN-FLD_TIME_STAMP_LEN-FLD_GF_HEADER,
					0,
					0,
					&((ptUsageTransRule+j)->tTransRule),
					(unsigned char *)sDestMsgBuf,
					&nLen);
				if (nReturnCode)
					return ERR_CODE_CONV_BASE+nReturnCode;
				
				/*if (!memcmp (sSrcMsgBuf, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN)||!memcmp (sSrcMsgBuf, "1802", SRV_ID_LEN)||!memcmp (sSrcMsgBuf, "1801", SRV_ID_LEN))*/

				if (!memcmp(sSrcMsgBuf, "16", 2) ||
					!memcmp(sSrcMsgBuf, "1802", SRV_ID_LEN) ||
					!memcmp(sSrcMsgBuf, "1801", SRV_ID_LEN) ||
					!memcmp(sSrcMsgBuf, "1811", SRV_ID_LEN) ||
					!memcmp (sSrcMsgBuf, "1803", SRV_ID_LEN)||
					!memcmp (sSrcMsgBuf, "1804", SRV_ID_LEN)||
					!memcmp (sSrcMsgBuf, "2001", SRV_ID_LEN)||
					!memcmp (sSrcMsgBuf, "2002", SRV_ID_LEN))
				{
					// HtLog ("Bridge.1805.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ok in 8583convert");
					/* msg from CUPS, copy to out buf */
					memset (sTxnNum, 0, FLD_TXN_NUM_LEN + 1);
					memcpy (sTxnNum, sDestMsgBuf + HEADER_BUF_LEN, FLD_TXN_NUM_LEN);
					if (sTxnNum[0] == TXN_NUM_MANAGE)
					{
						memset ((char *)&tIpcIntMng, ' ', sizeof (tIpcIntMng));
						/* copy ISO8583 message into internal IPC */
						memcpy (tIpcIntMng.sMsgSrcId, sSrcMsgBuf, SRV_ID_LEN);
						memcpy (tIpcIntMng.sMsqType, sSrcMsgBuf+SRV_ID_LEN*2, FLD_MSQ_TYPE_LEN);
						memcpy (tIpcIntMng.sTimeStamp, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN, FLD_TIME_STAMP_LEN);
						memcpy (tIpcIntMng.sGfHeader, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN, FLD_GF_HEADER);
						memcpy (tIpcIntMng.sHeaderBuf, sDestMsgBuf, nLen);
						/* copy message into out buf */
						*pnDestMsgLen = sizeof (tIpcIntMng);
						memset (sDestMsgBuf, ' ', sizeof (sDestMsgBuf));
						memcpy (sDestMsgBuf, (char *)&tIpcIntMng, *pnDestMsgLen);
					}
					else
					{
							memset ((char *)&tIpcIntTxn, ' ', sizeof (tIpcIntTxn));
						/* copy ISO8583 message into internal IPC */
						memcpy (tIpcIntTxn.sMsgSrcId, sSrcMsgBuf, SRV_ID_LEN);
						memcpy (tIpcIntTxn.sMsqType, sSrcMsgBuf+SRV_ID_LEN*2, FLD_MSQ_TYPE_LEN);
						memcpy (tIpcIntTxn.sTimeStamp, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN, FLD_TIME_STAMP_LEN);
						memcpy (tIpcIntTxn.sGfHeader, sSrcMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN, FLD_GF_HEADER);
						tIpcIntTxn.sConvTxnNum[0] = 'N';
						memcpy (tIpcIntTxn.sHeaderBuf, sDestMsgBuf, nLen);

						/* copy message into out buf */
						*pnDestMsgLen = sizeof (tIpcIntTxn);
						memset (sDestMsgBuf, ' ', sizeof (sDestMsgBuf));
						memcpy (sDestMsgBuf, (char *)&tIpcIntTxn, *pnDestMsgLen);
					}
					return 0;
				}
				/*��������ת������*/
				else
				{
					nTmpMsgLen = nLen+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER;
					memcpy(sTmpMsgBuf, sSrcMsgBuf,
						SRV_ID_LEN*2 + FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER);
					memcpy(sTmpMsgBuf + SRV_ID_LEN*2 + FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,
						sDestMsgBuf, nLen);
						
				    HtLog("CvtOpr.log", HT_LOG_MODE_NORMAL, __FILE__, __LINE__,"CvtCustOutToIn begin 1......");
					nReturnCode = CvtCustOutToIn(	ptIpcDftRule,
													ptBufChgRule,
													nTmpMsgLen,
													sTmpMsgBuf,
													pnDestMsgLen,
													sDestMsgBuf,
													sTxnNum);
					return nReturnCode;
				}
			}
			else
				return ERR_CODE_CONV_NO_RULE;
		}
	}
    /*��������ת������*/
	if ( i == CONV_TYPE_NUM_MAX)
	{
	    
	    HtLog("CvtOpr.log", HT_LOG_MODE_NORMAL, __FILE__, __LINE__,"CvtCustOutToIn begin 2......");
		nReturnCode = CvtCustOutToIn(	ptIpcDftRule,
										ptBufChgRule,
										nSrcMsgLen,
										sSrcMsgBuf,
										pnDestMsgLen,
										sDestMsgBuf,
										sTxnNum);
	    HtLog("CvtOpr.log", HT_LOG_MODE_NORMAL, __FILE__, __LINE__,"sTxnNum[%s]nReturnCode[%d]",sTxnNum,nReturnCode);
		return nReturnCode;
	}

	return 0;
}

/*****************************************************************************/
/* FUNC:   int CvtInToOut ( Tbl_conv_type_Def *ptConvType,                   */
/*                          T_UsageTransRuleDef *ptUsageTransRule            */
/*                          char *sSrvId, int nSrcMsgLen, char *sSrcMsgBuf,  */
/*                          int *pnDestMsgLen, char *sDestMsgBuf);           */
/* INPUT:  ptConvType: tbl_conv_type��¼                                     */
/*         ptUsageTransRule: ���usage_key��ISO8583ת������                  */
/*         ptIpcDftRule: ���Ĭ��IPC                                         */
/*         ptBufChgRule: ���BUFCHGת������                                  */
/*         nSrcMsgLen: ��ת����buffer����                                    */
/*         sSrcMsgBuf: ��ת����buffer                                        */
/*         pnDestMsgLen: sDestMsgBuf����                                     */
/* OUTPUT: pnDestMsgLen: ת�����buffer����                                  */
/*         sDestMsgBuf: ת�����buffer                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���ڲ�IPC��ʽ����Ϣת��Ϊ�ⲿ��ʽ                                 */
/*****************************************************************************/
int CvtInToOut(	Tbl_conv_type_Def *ptConvType,
				T_UsageTransRuleDef *ptUsageTransRule,
				stIpcDftRuleDef *ptIpcDftRule,
				bciMBufChgInfDef *ptBufChgRule,
				int nSrcMsgLen,
				char *sSrcMsgBuf,
				int *pnDestMsgLen,
				char *sDestMsgBuf)
{
    #define POS_DEST_ID 6

	char			sDestId[F032_VAL_LEN+1];
	char			sSrcId[F032_VAL_LEN+1];
	char			sTotalLen[5];
	char			sTmpMsgBuf[MSQ_MSG_SIZE_MAX];
	int				nTmpMsgLen;
	short			nLen;
	int				nReturnCode;
	int				i, j;
	/*
	int				nMsgLen;
	*/
	T_IpcIntTxnDef	tIpcIntTxn;
	
	for (i = 0; i < CONV_TYPE_NUM_MAX; i++)
	{
		if (!memcmp((ptConvType+i)->srv_id, sSrcMsgBuf + SRV_ID_LEN,
				SRV_ID_LEN) &&
			(ptConvType+i)->buf_chg_type[0] == CONV_CHG_TYPE_8583)
		{
			for (j = 0; j < CVT_USAGE_TRANS_RULE_NUM_MAX; j++)
			{
				if ((ptUsageTransRule+j)->usage_key == (ptConvType+i)->usage_key)
					break;
			}
			if (j < CVT_USAGE_TRANS_RULE_NUM_MAX)
			{	
				if (!memcmp (sSrcMsgBuf + SRV_ID_LEN, "16", SRV_ID_LEN - 2) ||
					!memcmp (sSrcMsgBuf + SRV_ID_LEN, "1802", SRV_ID_LEN) ||
					!memcmp (sSrcMsgBuf+SRV_ID_LEN, "1801", SRV_ID_LEN) ||
					!memcmp (sSrcMsgBuf+SRV_ID_LEN, "1811", SRV_ID_LEN) ||
					!memcmp (sSrcMsgBuf+SRV_ID_LEN, "1803", SRV_ID_LEN)||
					!memcmp (sSrcMsgBuf+SRV_ID_LEN, "1804", SRV_ID_LEN)||
					!memcmp (sSrcMsgBuf+SRV_ID_LEN, "2001", SRV_ID_LEN)||
					!memcmp (sSrcMsgBuf+SRV_ID_LEN, "2002", SRV_ID_LEN))
				{
					/* msg from CUPS, get 8583 buf */
					memset ((char *)&tIpcIntTxn, ' ', sizeof (tIpcIntTxn));
					memcpy (&tIpcIntTxn, sSrcMsgBuf, nSrcMsgLen);
					/* exchange src and dest id */
					if (tIpcIntTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] ==
						TXN_NUM_TDB_RSP)
					{
						memcpy(sDestId, tIpcIntTxn.sHeaderBuf+POS_DEST_ID,
								F032_VAL_LEN);
						memcpy(sSrcId,
								tIpcIntTxn.sHeaderBuf+POS_DEST_ID+F032_VAL_LEN,
								F032_VAL_LEN);
						memcpy(tIpcIntTxn.sHeaderBuf+POS_DEST_ID, sSrcId,
								F032_VAL_LEN);
						memcpy(tIpcIntTxn.sHeaderBuf+POS_DEST_ID+F032_VAL_LEN,
								sDestId,
								F032_VAL_LEN);
					}
					nTmpMsgLen = nSrcMsgLen -
								(tIpcIntTxn.sHeaderBuf - (char *)&tIpcIntTxn);
					memcpy(sTmpMsgBuf, tIpcIntTxn.sHeaderBuf,
						nSrcMsgLen-(tIpcIntTxn.sHeaderBuf-(char *)&tIpcIntTxn));
				}
				else
				{
					nReturnCode = CvtCustInToOut(	ptIpcDftRule,
													ptBufChgRule,
													nSrcMsgLen,
													sSrcMsgBuf,
													&nTmpMsgLen,
													sTmpMsgBuf);
					if (nReturnCode)
						return nReturnCode;
				}
				
				/* ISO8583 convert */
				nLen = *pnDestMsgLen;
				nReturnCode =
				ConvInToOut(
					(unsigned char *)sTmpMsgBuf, 
					nTmpMsgLen,
					0,
					0,
					&((ptUsageTransRule+j)->tTransRule),
					(unsigned char *)sDestMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,
					&nLen);
	
				if (nReturnCode)
					return ERR_CODE_CONV_BASE+nReturnCode;
					
				if (sDestMsgBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER] == '\x2E')
				{
					sprintf (sTotalLen, "%04d", nLen);
					memcpy (sDestMsgBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+2, sTotalLen, 4);
				}
				memcpy(sDestMsgBuf, sSrcMsgBuf, SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER);
				if (!memcmp(sSrcMsgBuf+SRV_ID_LEN, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
					memcpy (sDestMsgBuf+SRV_ID_LEN*2,"                ",
						FLD_MSQ_TYPE_LEN);
				*pnDestMsgLen = nLen + SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER;
				return 0;
					
			}
			else
				return ERR_CODE_CONV_NO_RULE;
		}
	}
	if (i == CONV_TYPE_NUM_MAX)
	{
		nReturnCode = CvtCustInToOut(ptIpcDftRule,
										ptBufChgRule,
										nSrcMsgLen,
										sSrcMsgBuf,
										pnDestMsgLen,
										sDestMsgBuf);
		return nReturnCode;
	}
	
	return 0;
}
