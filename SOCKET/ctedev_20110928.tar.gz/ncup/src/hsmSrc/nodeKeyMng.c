#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "hsm/unionErrCode.h"
#include "hsm/centerREC.h"

char desKeyType[][3+1] = {"zpk","zak","zmk","tmk","tpk","tak","pvk","cvk","zek","wwk","bdk","edk",""};

char *UnionGetKeyAppIDOfSpecNode(char *nodeName)
{
	char	*ptr;
	char	varName[128];
	
	// �Ȳ��Ƿ�Ϊ�ýڵ㶨����ר�ŵ���Կ����Ӧ�ñ��
	sprintf(varName,"keyAppIDOf%s",nodeName);	// ������
	if ((ptr = getenv(varName)) != NULL)
		return(ptr);
	
	// �ٲ��Ƿ�Ϊ��Կ������ȱʡ����Կ����Ӧ�ñ��
	if ((ptr = getenv("appIDOfKey")) != NULL)	// ������
		return(ptr);

	// ���÷����ĵ�Ӧ�ñ��
	return(UnionGetIDOfEsscAPI());
}

int UnionGetNodeKeyName(char *node,char *type,char *fullName)
{
	char typeLower[3+1];
	int ret = 0;
	if (node == NULL || type == NULL || strlen(type) > 3 || fullName == NULL)
		return(errCodeParameter);
	strcpy(typeLower,type);
	UnionToLowerCase(typeLower);
	if (IsUnionDesKey(typeLower) < 0)
		return(errCodeParameter);
	if ((ret = UnionConnectCenterREC()) < 0)
	{
		UnionUserErrLog("in UnionGetNodeKeyName:: UnionConnectCenterREC!\n");
		return(ret);
	}
	sprintf(fullName,"%s.%s.%s",UnionGetKeyAppIDOfSpecNode(node),node,typeLower);
		return 0;
}

int IsUnionDesKey(char *type)
{
	char (*pDesKeyType)[3+1];
	int  i = 0;
	
	pDesKeyType = &desKeyType[0];
	for(i=0;strlen(*pDesKeyType)!=0;i++)
	{
		if (strcmp(type,*pDesKeyType) == 0)
			return i;
		pDesKeyType++;
	}
	return -1;
}

int UnionGetNodePKName(char *node,char *fullName)
{
	int ret = 0;
	if (node == NULL || fullName == NULL)
		return(errCodeParameter);
	
	if ((ret = UnionConnectCenterREC()) < 0)
	{
		UnionUserErrLog("in UnionGetNodeKeyName:: UnionConnectCenterREC!\n");
		return(ret);
	}
	sprintf(fullName,"%s.%s.pk",UnionGetKeyAppIDOfSpecNode(node),node);
		return 0;
}


