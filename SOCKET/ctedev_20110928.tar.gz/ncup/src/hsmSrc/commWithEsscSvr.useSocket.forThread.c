//	Author:		Wolfgang Wang
//	Copyright:	Union Tech. Guangzhou
//	Date:		2006/3/6

#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <setjmp.h>
#include <stdlib.h>

#include "hsm/unionAPI.h"
#include "hsm/UnionSocket.h"
#include "hsm/unionErrCode.h"

#include "hsm/commWithEsscSvr.h"
#include "hsm/centerREC.h"


jmp_buf			gcommSvrJmpEnv;
int			gcommSvrJmpSet = 0;
int			gunionIgnoreSignals = 0;
int 			gunionSckHDL = -1;

void UnionClientCommTimeout();

void UnionReleaseCommWithHsmSvr()
{
	if (gunionSckHDL >= 0)
		UnionCloseSocket(gunionSckHDL);
	gunionSckHDL = -1;
}

int UnionCommWithHsmSvrForThread(char *serviceCode,char *reqStr,int lenOfReqStr,char *resStr,int sizeOfResStr)
{
	unsigned char	lenBuf[10+1];
	int		ret;
	int		len;
	int		tryTimes = 0;
	char		tmpBuf[2048+1];
	char		answerAppID[10+1];
	char		answerServiceID[10+1];
	int		offset;
	char		resCode[6+1];

	if ((serviceCode == NULL) || (reqStr == NULL) || (lenOfReqStr < 0) || (resStr == NULL))
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: parameter error! lenOfReqStr = [%d]!\n",lenOfReqStr);
		return(errCodeParameter);
	}
		
	// ��ʼ�����л���
	if ((ret = UnionConnectCenterREC()) < 0)
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: UnionConnectCenterREC!\n");
		return(ret);
	}

	if (!gunionIgnoreSignals)
	{
		gunionIgnoreSignals = 1;
		signal(SIGPIPE,SIG_IGN);
	}

	memset(tmpBuf,0,sizeof(tmpBuf));
	len = 0;
	memcpy(tmpBuf+len,UnionGetIDOfEsscAPI(),2);
	len += 2;
	memcpy(tmpBuf+len,serviceCode,3);
	len += 3;
	tmpBuf[len] = '1';
	len++;
	if (lenOfReqStr + len >= sizeof(tmpBuf))
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr [%d] too long!\n",lenOfReqStr);
		if (lenOfReqStr > 0)
		{
			reqStr[lenOfReqStr] = 0;
			UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s]\n",lenOfReqStr,reqStr);
		}
		return(errCodeParameter);
	}
	memcpy(tmpBuf+len,reqStr,lenOfReqStr);
	len += lenOfReqStr;
	tmpBuf[len] = 0;	
	UnionNullLogWithTime("lenOfReqStr=[%04d]reqStr=[%s]\n",len,tmpBuf);
	
	// ���ó�ʱ���� 
#ifdef _LINUX_
	if (sigsetjmp(gcommSvrJmpEnv,1) != 0)
#else
	if (setjmp(gcommSvrJmpEnv) != 0)
#endif
	{
		UnionSystemErrLog("in UnionCommWithHsmSvrForThread:: timeout!\n");
		if (lenOfReqStr > 0)
		{
			reqStr[lenOfReqStr] = 0;
			UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s]\n",lenOfReqStr,reqStr);
		}
		goto errorExit;
	}
	alarm(UnionGetTimeoutOfCenterSecuSvr());
	signal(SIGALRM,UnionClientCommTimeout);

retry:
	tryTimes++;
	if (tryTimes > conMaxNumOfEssc + 1)	// ���Թ�ָ������
	{
		if (gunionSckHDL >= 0)
		{
			UnionCloseSocket(gunionSckHDL);
			gunionSckHDL = -1;
		}
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s%s%s%s]\n",lenOfReqStr+2+3+1,
			UnionGetIDOfEsscAPI(),serviceCode,"1",reqStr);
		alarm(0);		// Mary add, 20081103
		return(errCodeAPICommWithEssc);
	}
	if (gunionSckHDL < 0)
	{	// ������ESSC������
		if ((gunionSckHDL = UnionCreateSocketClient(UnionGetIPAddrOfCenterSecuSvr(tryTimes),UnionGetPortOfCenterSecuSvr(tryTimes))) < 0)
		{
			UnionUserErrLog("in UnionCommWithHsmSvrForThread:: UnionCreateSocketClient [%s][%d]!\n",
					UnionGetIPAddrOfCenterSecuSvr(tryTimes),UnionGetPortOfCenterSecuSvr(tryTimes));
			goto retry;
		}
	}

	// ���ͱ��ĳ���	
	lenBuf[0] = len / 256;
	lenBuf[1] = len % 256;
	UnionSetSendTimes(tryTimes);		// Mary add, 20081114
	if ((ret = UnionSendToSocket(gunionSckHDL,lenBuf,2)) < 0)
	{
		if (tryTimes > 1)		// Mary add, 20081114
			UnionUserErrLog("in UnionCommWithHsmSvrForThread:: UnionSendToSocket!\n");
		goto sckErr;
	}
	// ���ͱ�������
	if ((ret = UnionSendToSocket(gunionSckHDL,(unsigned char *)tmpBuf,len)) < 0)
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: UnionSendToSocket!\n");
		goto sckErr;
	}
	if ((ret = UnionReceiveFromSocketUntilLen(gunionSckHDL,lenBuf,2)) != 2)
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: UnionReceiveFromSocketUntilLen!\n");
		goto sckErr;
	}
	if ((len = lenBuf[0] * 256 + lenBuf[1]) >= sizeof(tmpBuf))
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: expected len [%d] > receiveBuffer [%d]!\n",len,sizeof(tmpBuf));
		ret = errCodeAPIBufferSmallForRecvData;
		goto errorExit;
	}
	if (len == 0)
		goto normalExit;
	if (len < 0)
		goto errorExit;
	if ((ret = UnionReceiveFromSocketUntilLen(gunionSckHDL,(unsigned char *)tmpBuf,len)) != len)
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: UnionReceiveFromSocketUntilLen [%d] != expected [%d]!\n",ret,len);
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s%s%s%s]\n",lenOfReqStr+2+3+1,
			UnionGetIDOfEsscAPI(),serviceCode,"1",reqStr);
		ret = errCodeAPIRecvDataLenNotEqualDefinedLen;
		goto errorExit;
	}
	tmpBuf[len] = 0;
	UnionNullLogWithTime("lenOfResStr=[%04d]resStr=[%s]\n",len,tmpBuf);
normalExit:
	alarm(0);
	if (UnionIsShortConnectionUsed())
	{
		UnionCloseSocket(gunionSckHDL);
		gunionSckHDL = -1;
	}
	if ((len < 2 + 3 + 1 + 6) || (tmpBuf[2+3] != '0'))
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: UnionUnpackEsscResponsePackage!\n");
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s%s%s%s]\n",lenOfReqStr+2+3+1,
			UnionGetIDOfEsscAPI(),serviceCode,"1",reqStr);
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfResStr=[%04d]resStr=[%s]\n",len,tmpBuf);
		return(errCodeAPIRecvDataLenNotEqualDefinedLen);
	}
	memset(answerServiceID,0,sizeof(answerServiceID));
	memset(answerAppID,0,sizeof(answerAppID));
	offset = 0;
	memcpy(answerAppID,tmpBuf+offset,2);
	offset += 2;
	memcpy(answerServiceID,tmpBuf+offset,3);
	offset += 3;
	if ((strcmp(answerAppID,UnionGetIDOfEsscAPI()) != 0) || 
		(strcmp(answerServiceID,serviceCode) != 0))
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: not response to this request!\n");
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s%s%s%s]\n",lenOfReqStr+2+3+1,
			UnionGetIDOfEsscAPI(),serviceCode,"1",reqStr);
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfResStr=[%04d]resStr=[%s]\n",len,tmpBuf);
		return(errCodeEsscMDL_ReqAndResNotIsIndentified);
	}
	offset++;
	memcpy(resCode,tmpBuf+offset,6);
	resCode[6] = 0;
	offset += 6;
	if ((ret = atoi(resCode)) < 0)
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: ret from server = [%d]\n",ret);
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s%s%s%s]\n",lenOfReqStr+2+3+1,
			UnionGetIDOfEsscAPI(),serviceCode,"1",reqStr);
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfResStr=[%04d]resStr=[%s]\n",len,tmpBuf);
		return(ret);
	}
	if ((len - offset) >= sizeOfResStr)
	{
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: sizeOfResStr too small!\n");
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s%s%s%s]\n",lenOfReqStr+2+3+1,
			UnionGetIDOfEsscAPI(),serviceCode,"1",reqStr);
		UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfResStr=[%04d]resStr=[%s]\n",len,tmpBuf);
		return(errCodeSmallBuffer);
	}
	memcpy(resStr,tmpBuf+offset,len-offset);	
	return(len-offset);

sckErr:
	UnionCloseSocket(gunionSckHDL);
	gunionSckHDL = -1;
	goto retry;
	
errorExit:
	alarm(0);
	UnionCloseSocket(gunionSckHDL);
	gunionSckHDL = -1;
	UnionUserErrLog("in UnionCommWithHsmSvrForThread:: lenOfReqStr=[%04d]reqStr=[%s%s%s%s]\n",lenOfReqStr+2+3+1,
			UnionGetIDOfEsscAPI(),serviceCode,"1",reqStr);
	if (ret >= 0)
		return(errCodeAPIShouldReturnMinusButRetIsNotMinus);
	else
		return(ret);
}

void UnionClientCommTimeout()
{
	//signal(SIGALRM,SIG_IGN);
	UnionUserErrLog("in UnionClientCommTimeout:: HSM time out!\n");
	gcommSvrJmpSet = 1;
#ifdef _LINUX_
	siglongjmp(gcommSvrJmpEnv,10);
#else
	longjmp(gcommSvrJmpEnv,10);
#endif
}

