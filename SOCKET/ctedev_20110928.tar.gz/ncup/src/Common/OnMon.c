/*****************************************************************************/
/*                   Shanghai Huateng Software System Inc.                   */
/*****************************************************************************/
/* PROGRAM NAME: OnMon.c                                                     */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*                                                                           */
/*****************************************************************************/
static char *Id = "$Id: OnMon.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdarg.h>
#include <time.h>
#include <sys/time.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/stat.h>
#include <string.h>
#include <memory.h>
#include "IpcInt.h"
#include "OnMon.h"
#include "TxnNum.h"
#define MSQ_GET_FLAG    0660

struct{
    
    char    baoweichangdu[4];
    char    bishu[3];
    char    sTransmsnDateTime[14];    
    char    sSysSeqNum[FLD_SYS_SEQ_NUM_LEN];
    char    bran_code[11];
	char    bran_codefa[11];
    char    sAcqInstIdCode[F032_VAL_LEN];
    char    sFwdInstIdCode[F033_VAL_LEN];
    char    mer_code[15];
    char    sCardAccptrTermnlId[F041_LEN];
    char    sPrimaryAcctNum[F002_VAL_LEN];
    char    sAmtTrans[F004_LEN];
    char    sTxnNum[4];
    char    sRespCode[F039_LEN+1];	
}MsgStruct;

int SendMsgMonitor(int nMsgSize, char *sMsgBuf);

int SwitchMon(int nMonMode, T_IpcIntTxnDef *vptIpcIntTxn)
{
	/*
    int         nReturnCode;
    int         nMonitorMode;
	*/
	
    int         nMsgLen;
    int         nMonTurnMode;
    char        sLogTime[128];
    char        sDateTime[16];
    char        sMsgBuf[1024];
    char        *lspTmp;

    time_t      lTime;
    struct tm   *tTmLocal;

	int         year;
    char        cyear[5];
	char        length[5];
	int         nLength;

    if ((lspTmp = getenv(ON_MON_TURN_MODE)) == NULL)
    {
        nMonTurnMode = ON_MON_TURN_ON;
    }
    else
    {
        nMonTurnMode = atoi(lspTmp);
    }

    if (nMonTurnMode == ON_MON_TURN_OFF)
    {
        return 0;
    }
    /* get current time */
    memset(sLogTime, 0x00, sizeof(sLogTime));
    memset(sDateTime, 0x00, sizeof(sDateTime));
    lTime = time(NULL);
    tTmLocal = localtime(&lTime);
    strftime(sLogTime, sizeof(sLogTime), "%m%d %H%M%S", tTmLocal);
    strftime(sDateTime, sizeof(sDateTime), "%Y%m%d%H%M%S", tTmLocal);

    /* set monitor information */
    memset(&MsgStruct, ' ', sizeof(MsgStruct));
    memset(sMsgBuf, 0, sizeof(sMsgBuf));

    year = 1900 + tTmLocal->tm_year;
    gcvt(year, 4, cyear);
   
	memset(MsgStruct.sTransmsnDateTime, 0 , 14);
	memcpy(MsgStruct.sTransmsnDateTime, cyear, 4);
    memcpy(MsgStruct.baoweichangdu, "0127"  , 4);
	memcpy(MsgStruct.bishu,"001"    ,3);
    memcpy(MsgStruct.sTransmsnDateTime, vptIpcIntTxn->sTransmsnDateTime ,14); 
    memcpy(MsgStruct.sSysSeqNum, vptIpcIntTxn->sSysSeqNum, FLD_SYS_SEQ_NUM_LEN);
	/*����������  ****/
    if (nMonMode == 0||vptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_RSP)
	{
	memcpy(MsgStruct.bran_code,vptIpcIntTxn->sAcqInstIdCode, F032_VAL_LEN); 
	memcpy(MsgStruct.bran_codefa,vptIpcIntTxn->sRcvgInstIdCode, F100_VAL_LEN);
	}

	/* ���������� **/
	else if(nMonMode == 1||vptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_RSP)
	{
    memcpy(MsgStruct.bran_code,vptIpcIntTxn->sRcvgInstIdCode, F100_VAL_LEN);
	memcpy(MsgStruct.bran_codefa, vptIpcIntTxn->sMisc+127-10  ,  8);
	memcpy(MsgStruct.bran_codefa+8, "   ", 3);
	}
    memcpy(MsgStruct.sAcqInstIdCode,  vptIpcIntTxn->sAcqInstIdCode, F032_VAL_LEN);
    memcpy(MsgStruct.sFwdInstIdCode, vptIpcIntTxn->sFwdInstIdCode, F033_VAL_LEN);
    memcpy(MsgStruct.mer_code, vptIpcIntTxn->sCardAccptrId, 15);
    memcpy(MsgStruct.sCardAccptrTermnlId, vptIpcIntTxn->sCardAccptrTermnlId, F041_LEN);
    memcpy(MsgStruct.sPrimaryAcctNum, vptIpcIntTxn->sPrimaryAcctNum, F002_VAL_LEN);
    memcpy(MsgStruct.sAmtTrans, vptIpcIntTxn->sAmtTrans, F004_LEN);
    memcpy(MsgStruct.sTxnNum, vptIpcIntTxn->sTxnNum, 4);


	/*sprintf(rsp, "%d", nMonMode);
    memcpy(MsgStruct.sRespCode, rsp, F039_LEN);
	*/
	memcpy(MsgStruct.sRespCode,vptIpcIntTxn->sRespCode, 2);
    MsgStruct.sRespCode[2] = 0;

	memcpy(sMsgBuf, &MsgStruct, sizeof(MsgStruct));
    nMsgLen = 131;

	nLength = nMsgLen - 4;
	sprintf(length, "%d", nLength);
	memcpy(MsgStruct.baoweichangdu, length  , 4);
    SendMsgMonitor(nMsgLen, sMsgBuf);
    return 0;    
}

int SendMsgMonitor(int nMsgSize, char *sMsgBuf)
{
    int               code;
    char              *lspTmp;
    static int        nMsqId;
    long              nMsqKey;
    static int        nMsqNumMax;
    static int        nInitialFlag = 0;

    struct msqid_ds   qds;

    if (nInitialFlag == 0) 
    {
        /* get msq key */
        if ((lspTmp = getenv(ON_MON_MSQ_KEY)) == NULL)
        {
            nInitialFlag = 0;
            return -1;
        }
        else 
        {
            nMsqKey = atol(lspTmp);
        }
HtLog ("Monitor.1.log", 1, __FILE__,__LINE__,
                        "getenv(ON_MON_MSQ_KEY), [%s]. .", getenv(ON_MON_MSQ_KEY));

        /* get msg queue max num */
        if((lspTmp = getenv(ON_MON_MSQ_NUM_MAX)) == NULL)
        {
            nMsqNumMax = ON_MON_MSQ_NUM_MAX_DEFAULT;
        }
        else
        {
            if((nMsqNumMax = atoi(lspTmp)) <= 0)
            {
                nMsqNumMax = ON_MON_MSQ_NUM_MAX_DEFAULT;
            }
        }

        nMsqId = msgget(nMsqKey, MSQ_GET_FLAG|IPC_CREAT);
        if (nMsqId == -1)
        {
            nInitialFlag = 0;
            return -1;
        }

        nInitialFlag = 1;
    }

    if (msgctl(nMsqId, IPC_STAT, &qds) == -1)
    {
        nInitialFlag = 0;
        return -1; 
    }

    if (qds.msg_qnum > nMsqNumMax)
    {
        nInitialFlag = 0;
        return -1;
    }
HtLog ("Monitor.1.log", 1, __FILE__,__LINE__,
                        "nMsqId, %d. .", nMsqId);
                        
HtDebugString("Monitor.1.log", 3, __FILE__,__LINE__, sMsgBuf, nMsgSize);

    code = msgsnd(nMsqId, sMsgBuf, nMsgSize, 0);
    if (code == -1)
    {
    	HtLog ("Monitor.1.log", 1, __FILE__,__LINE__,
                        "error Monitor msgsnd error .");
        nInitialFlag = 0;
        return -1;
    }

    return 0;
}
