/*****************************************************************************/
/*               NCUP -- Shanghai Huateng Software System Inc.               */
/*****************************************************************************/
/* PROGRAM NAME: Common.c                                                    */
/* DESCRIPTIONS: The common routines, including                              */
/*               CommonGetCurrentTime -- Get the system time by format       */
/*                                       (YYYYMMDDHHMMSS)                    */
/*               CommonGetCurrentDate -- Get the system date by format       */
/*                                       (YYYYMMDD)                          */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initial Version Creation                       */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Common/Common.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";

#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <string.h>
/*#include <iconv.h>*/

#include "HtLog.h"

#include "SrvDef.h"
#include "IpcInt.h"

#define C_NULL_CHG	':'
#define IS_NUMBER(x)                    (x >= '0' && x <= '9')
#define M_IS_LOWERHEX(x)                ((x >= 'a') && (x <= 'f'))
#define M_IS_UPPERHEX(x)                ((x >= 'A') && (x <= 'F'))

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentDate (char *sCurrentDate);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentDate   -- the string of current date                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system date with the format (YYYYMMDD).                   */
/*****************************************************************************/
void  CommonGetCurrentDate(char *sCurrentDate)
{  
   time_t current;
   struct tm *tmCurrentTime;
   
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentDate, "%4d%02d%02d", tmCurrentTime->tm_year + 1900, 
           tmCurrentTime->tm_mon + 1, tmCurrentTime->tm_mday);
}

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentTime (char *sCurrentTime);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentTime   -- the string of current time                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system time with the format (YYYYMMDDhhmmss).             */
/*****************************************************************************/
void CommonGetCurrentTime(char *sCurrentTime)
{  
   time_t current;
   struct tm *tmCurrentTime;
   
   tzset();
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentTime, "%4d%02d%02d%02d%02d%02d", 
           tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1, 
           tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
           tmCurrentTime->tm_min, tmCurrentTime->tm_sec);
}

int CommonRTrim(char *caDest)
{
	int i;
	for( i=strlen(caDest)-1; i>=0 ; i-- )
	{
		if( caDest[i] !=' ')
		{
			break;
		}
	}
	caDest[i+1] = 0;
	return 0;
}

int CommonLTrim( char *caDest )
{
    int i;
    char lsTmp[1024];
    memset(lsTmp, 0, sizeof(lsTmp));

    for( i = 0; i< strlen(caDest) ; i++ )
    {
        if( caDest[i] ==' ')
        {
            continue;
        }
        lsTmp[i] = caDest[i];
    }
    strcpy(caDest, lsTmp);
	return 0;
}

void Hex2Str( char *sSrc,  char *sDest, int nSrcLen )
{
	int  i;
	char szTmp[3];

	for( i = 0; i < nSrcLen; i++ )
	{
		sprintf( szTmp, "%02X", (unsigned char) sSrc[i] );
		memcpy( &sDest[i * 2], szTmp, 2 );
	}
	return ;
}

void Str2Hex( char *sSrc, char *sDest, int nSrcLen )
{
    int i, nHighBits, nLowBits;

    for( i = 0; i < nSrcLen; i += 2 )
    {
        nHighBits = sSrc[i];
        nLowBits  = sSrc[i + 1];

        if( nHighBits > 0x39 )
            nHighBits -= 0x37;
        else
            nHighBits -= 0x30;

        if( i == nSrcLen - 1 )
            nLowBits = 0;
        else if( nLowBits > 0x39 )
            nLowBits -= 0x37;
        else
            nLowBits -= 0x30;

        sDest[i / 2] = (nHighBits << 4) | (nLowBits & 0x0f);
    }
	return ;
}

int DecodeNull (char *sStr, int nLen)
{

	int				i;
	
	for (i = 0; i < nLen; i++)
		if (sStr[i] == C_NULL_CHG)
			sStr[i] = 0x00;
	return 0;
}

int EncodeNull (char *sStr, int nLen)
{

	int				i;
	
	for (i = 0; i < nLen; i++)
		if (sStr[i] == 0x00)
			sStr[i] = C_NULL_CHG;
	return 0;
}
/*
char * code_convert(char *encFrom, char *encTo, const char * in)
{
	static char  bufout[1024], *sin, *sout;
	size_t  lenin, lenout, ret;
	iconv_t c_pt;

	if ((c_pt = iconv_open(encTo, encFrom)) == (iconv_t)-1)
	{
		HtLog("test.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "iconv_open false: %s ==> %s [%d,%s]", encFrom, encTo, errno, strerror(errno));
		return NULL;
	}
	iconv(c_pt, NULL, NULL, NULL, NULL);
	lenin  = strlen(in) + 1;
	lenout = 1024;
	sin    = (char *)in;
	sout   = bufout;
	ret = iconv(c_pt, &sin, (size_t *)&lenin, &sout, (size_t *)&lenout);
	if (ret == -1)
	{
		HtLog("test.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "iconv false: %s ==> %s [%d,%s]", encFrom, encTo, errno, strerror(errno));
		return NULL;
	}
	iconv_close(c_pt);
	return bufout;
}
*/

int nMCalcIn(
         int*                         vlpNumVal,
         void*                          vvpNumStr,
         int                          vnNumStrL) {

    unsigned char*                              lspNumStr;

    lspNumStr = vvpNumStr;
    *vlpNumVal = 0;
    for(; (vnNumStrL > 0) && (*lspNumStr == 0); vnNumStrL--, lspNumStr++);
    if(vnNumStrL > sizeof(*vlpNumVal))
        return -1;
    for(; vnNumStrL > 0; vnNumStrL--, lspNumStr++)
        *vlpNumVal = *vlpNumVal * 256 + *lspNumStr;
    return 0;
} /* end of nMCalcIn */

int nMCalcOut(
         unsigned short                          vlNumVal,
         void*                          vvpNumStr,
         int                          vnNumStrL) {

    unsigned char*                              lspNumStr;

    lspNumStr = vvpNumStr;
    memset(
       vvpNumStr,
       0,
       vnNumStrL);
    lspNumStr += (vnNumStrL - 1);
    for(; (vnNumStrL > 0) && (vlNumVal > 0); vnNumStrL--, lspNumStr--) {
        *lspNumStr = vlNumVal % 256;
        vlNumVal /= 256;
    } /* end of for */
    if(vlNumVal > 0)
        return -1;
    return 0;
} /* end of nMCalcOut */

int nMNumIn(
         int*                         vlpNumVal,
         void*                          vvpNumStr,
         int                          vnNumStrL) {

    unsigned char*                              lspNumStr;

    lspNumStr = vvpNumStr;
    *vlpNumVal = 0;
    for(; vnNumStrL > 0; vnNumStrL--, lspNumStr++) {
        if((vnNumStrL > 8) &&
           (*lspNumStr != '0'))
            return -1;
        if(IS_NUMBER(*lspNumStr))
            *vlpNumVal = *vlpNumVal * 10 + *lspNumStr - '0';
        else
            return -2;
    } /* end of for */
    return 0;
} /* end of nMNumIn */

int nMNumOut(
         int                          vlNumVal,
         void*                          vvpNumStr,
         int                          vnNumStrL) {

    unsigned char*                              lspNumStr;

    lspNumStr = vvpNumStr;
    if(vnNumStrL < 1)
        return -1;
    lspNumStr += (vnNumStrL - 1);
    for(; vnNumStrL > 0; vnNumStrL--, lspNumStr--) {
        *lspNumStr = vlNumVal % 10 + '0';
        vlNumVal = vlNumVal / 10;
    } /* end of for */
    if(vlNumVal)
        return -2;
    return 0;
} /* end of nMNumOut */

/*add by fucl*/
bcd_to_asc (ascii_buf , bcd_buf , conv_len , type)
unsigned char   *ascii_buf , *bcd_buf , type ;
int             conv_len ;
{
    int         cnt ;

    if (conv_len & 0x01 && type) {
        cnt = 1 ;
        conv_len ++ ;
    }
    else
        cnt = 0 ;
    for ( ; cnt < conv_len ; cnt ++ , ascii_buf ++ ) {
        *ascii_buf = ( ( cnt & 0x01 ) ? ( *bcd_buf ++ & 0x0f ) : ( *bcd_buf >> 4) ) ;
        *ascii_buf += ( ( *ascii_buf > 9 ) ? ( 'A' - 10 ) : '0' ) ;
    }

    return ;
}

asc_to_bcd ( bcd_buf , ascii_buf , conv_len , type )
unsigned char   *bcd_buf , *ascii_buf ;
int             conv_len,  type  ;
{
	int         cnt ;
	char        ch , ch1 ;

	if ( conv_len & 0x01 && type )
		ch1 = 0 ;
	else
		ch1 = 0x55 ;

	for ( cnt = 0 ; cnt < conv_len ; ascii_buf ++ , cnt ++ ) {
		if ( *ascii_buf >= 'a' )
			ch = *ascii_buf - 'a' + 10 ;
		else if ( *ascii_buf >= 'A' )
			ch = *ascii_buf- 'A' + 10 ;
		else if ( *ascii_buf >= '0' )
			ch = *ascii_buf-'0' ;
		else
			ch = 0;
		if ( ch1 == 0x55 )
			ch1 = ch ;
		else {
			*bcd_buf ++ = (ch1 << 4) | ch ;
			ch1 = 0x55 ;
		}
	}
	if ( ch1 != 0x55 )
		*bcd_buf = ch1 << 4 ;

	return ;
}
/*end fucl*/



int nMHexAsciiToBin(
         void*                          vvpOrigData,
         int                          vnOrigDataL,
         void*                          vvpResult) {

    unsigned char*                              lspOrigData;
    unsigned char*                              lspResult;

    lspOrigData = vvpOrigData;
    lspResult = vvpResult;

    for(; vnOrigDataL > 0; vnOrigDataL -= 2, lspResult++) {
        if(IS_NUMBER(*lspOrigData))
            *lspResult = ((*lspOrigData++) - '0') << 4;
        else if(M_IS_LOWERHEX(*lspOrigData))
            *lspResult = ((*lspOrigData++) - 'a' + 10) << 4;
        else if(M_IS_UPPERHEX(*lspOrigData))
            *lspResult = ((*lspOrigData++) - 'A' + 10) << 4;
        else
            return -1;
        if(IS_NUMBER(*lspOrigData))
            *lspResult += ((*lspOrigData++) - '0');
        else if(M_IS_LOWERHEX(*lspOrigData))
            *lspResult += ((*lspOrigData++) - 'a' + 10);
        else if(M_IS_UPPERHEX(*lspOrigData))
            *lspResult += ((*lspOrigData++) - 'A' + 10);
        else
            return -2;
    } /* end of for */

    return 0;
} /* end of nMHexAsciiToBin */

static unsigned char AsciiToEbcdicBuf[256] =
{
         /* 0,8   1,9   2,A   3,B   4,C   5,D   6,E   7,F */

/* 0 */     0x00, 0x01, 0x02, 0x03, 0x37, 0x2D, 0x2E, 0x2F,
/* 0 */     0x16, 0x05, 0x25, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
/* 1 */     0x10, 0x11, 0x12, 0x13, 0x3C, 0x3D, 0x32, 0x26,
/* 1 */     0x18, 0x19, 0x3F, 0x27, 0x1C, 0x1D, 0x1E, 0x1F,
/* 2 */     0x40, 0x4F, 0x7F, 0x7B, 0x5B, 0x6C, 0x50, 0x7D,
/* 2 */     0x4D, 0x5D, 0x5C, 0x4E, 0x6B, 0x60, 0x4B, 0x61,
/* 3 */     0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
/* 3 */     0xF8, 0xF9, 0x7A, 0x5E, 0x4C, 0x7E, 0x6E, 0x6F,
/* 4 */     0x7C, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7,
/* 4 */     0xC8, 0xC9, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6,
/* 5 */     0xD7, 0xD8, 0xD9, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6,
/* 5 */     0xE7, 0xE8, 0xE9, 0x4A, 0xE0, 0x5A, 0x5F, 0x6D,
/* 6 */     0x79, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
/* 6 */     0x88, 0x89, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96,
/* 7 */     0x97, 0x98, 0x99, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
/* 7 */     0xA7, 0xA8, 0xA9, 0xC0, 0x6A, 0xD0, 0xA1, 0x07,
/* 8 */     0x20, 0x21, 0x22, 0x23, 0x24, 0x15, 0x06, 0x17,
/* 8 */     0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x09, 0x0A, 0x1B,
/* 9 */     0x30, 0x31, 0x1A, 0x33, 0x34, 0x35, 0x36, 0x08,
/* 9 */     0x38, 0x39, 0x3A, 0x3B, 0x04, 0x14, 0x3E, 0xE1,
/* A */     0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
/* A */     0x49, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
/* B */     0x58, 0x59, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
/* B */     0x68, 0x69, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75,
/* C */     0x76, 0x77, 0x78, 0x80, 0x8A, 0x8B, 0x8C, 0x8D,
/* C */     0x8E, 0x8F, 0x90, 0x9A, 0x9B, 0x9C, 0x9D, 0x9E,
/* D */     0x9F, 0xA0, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
/* D */     0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
/* E */     0xB8, 0xB9, 0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF,
/* E */     0xCA, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xDA, 0xDB,
/* F */     0xDC, 0xDD, 0xDE, 0xDF, 0xEA, 0xEB, 0xEC, 0xED,
/* F */     0xEE, 0xEF, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF
};

static unsigned char EbcdicToAsciiBuf[256] =
{
         /* 0,8   1,9   2,A   3,B   4,C   5,D   6,E   7,F */

/* 0 */ 	0x00, 0x01, 0x02, 0x03, 0x9C, 0x09, 0x86, 0x7F,
/* 0 */     0x97, 0x8D, 0x8E, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
/* 1 */     0x10, 0x11, 0x12, 0x13, 0x9D, 0x85, 0x08, 0x87,
/* 1 */     0x18, 0x19, 0x92, 0x8F, 0x1C, 0x1D, 0x1E, 0x1F,
/* 2 */     0x80, 0x81, 0x82, 0x83, 0x84, 0x0A, 0x17, 0x1B,
/* 2 */     0x88, 0x89, 0x8A, 0x8B, 0x8C, 0x05, 0x06, 0x07,
/* 3 */     0x90, 0x91, 0x16, 0x93, 0x94, 0x95, 0x96, 0x04,
/* 3 */     0x98, 0x99, 0x9A, 0x9B, 0x14, 0x15, 0x9E, 0x1A,
/* 4 */     0x20, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6,
/* 4 */     0xA7, 0xA8, 0x5B, 0x2E, 0x3C, 0x28, 0x2B, 0x21,
/* 5 */     0x26, 0xA9, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF,
/* 5 */     0xB0, 0xB1, 0x5D, 0x24, 0x2A, 0x29, 0x3B, 0x5E,
/* 6 */     0x2D, 0x2F, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7,
/* 6 */     0xB8, 0xB9, 0x7C, 0x2C, 0x25, 0x5F, 0x3E, 0x3F,
/* 7 */     0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF, 0xC0, 0xC1,
/* 7 */     0xC2, 0x60, 0x3A, 0x23, 0x40, 0x27, 0x3D, 0x22,
/* 8 */     0xC3, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
/* 8 */     0x68, 0x69, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9,
/* 9 */     0xCA, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F, 0x70,
/* 9 */     0x71, 0x72, 0xCB, 0xCC, 0xCD, 0xCE, 0xCF, 0xD0,
/* A */     0xD1, 0x7E, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
/* A */     0x79, 0x7A, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7,
/* B */     0xD8, 0xD9, 0xDA, 0xDB, 0xDC, 0xDD, 0xDE, 0xDF,
/* B */     0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
/* C */     0x7B, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
/* C */     0x48, 0x49, 0xE8, 0xE9, 0xEA, 0xEB, 0xEC, 0xED,
/* D */     0x7D, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50,
/* D */     0x51, 0x52, 0xEE, 0xEF, 0xF0, 0xF1, 0xF2, 0xF3,
/* E */     0x5C, 0x9F, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
/* E */     0x59, 0x5A, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9,
/* F */     0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
/* F */     0x38, 0x39, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF
	};
	
void vAsc2Ebcdic( char* sDest, char* sSrc, int nBytes )
{
	int i;

	for( i = 0; i < nBytes; i++ )
		sDest[i] = AsciiToEbcdicBuf[(unsigned char)sSrc[i]];

} /* end of vAsc2Ebcdic() */


void vEbcdic2Asc( char* sDest, char* sSrc, int nBytes )
{
	int i;

	for( i = 0; i < nBytes; i++ )
		sDest[i] = EbcdicToAsciiBuf[(unsigned char)sSrc[i]];

} /* end of vEbcdic2Asc() */


 /*
 ***********************************************
 * �������ܣ�������������֮����������
 * ���������epczFormat ���ڸ�ʽ
 *           epczBeginDate, epczEndDate �ַ���ʽ��ʱ��
 * �������: ��������
 ***********************************************
 */
int diffDate( char *epczFormat, char *epczBeginDate, char *epczEndDate )
{
   char aczYear[2][5], aczMonth[2][3], aczDay[2][3];
   int i;
   struct tm stTime1, stTime2;
   time_t tT1, tT2;
   static char *pczFormat[] = { "4YMD", "4Y-M-D", "4Y/M/D", "4Y M D",
                                "MD4Y", "M-D-4Y", "M/D/4Y", "M D 4Y",
                                "DM4Y", "D-M-4Y", "D/M/4Y", "D M 4Y" };
   struct _SeekPos { int m_Year; int m_Month; int m_Day; };
   static struct _SeekPos astPos[] = {
                                { 0, 4, 6}, { 0, 5, 8 }, { 0, 5, 8 },
                                { 2, 0, 4}, { 3, 0, 6 }, { 3, 0, 6 },
                                { 0, 2, 4}, { 0, 3, 6 }, { 0, 3, 6 }
                                      };

   for( i = 0; i < 9; i++ )
   {
      if( strcmp( epczFormat, pczFormat[i] ) == 0 )
      {
         break;
      }
   }
   if( i == 9 )
   {
      return -1;
   }
   memset( aczYear, 0, sizeof(aczYear) );
   memset( aczMonth, 0, sizeof(aczMonth) );
   memset( aczDay, 0, sizeof(aczDay) );

   memcpy( aczYear[0],  epczBeginDate + astPos[i].m_Year,  4 );
   memcpy( aczMonth[0], epczBeginDate + astPos[i].m_Month, 2 );
   memcpy( aczDay[0],   epczBeginDate + astPos[i].m_Day,   2 );
   memcpy( aczYear[1],  epczEndDate + astPos[i].m_Year,  4 );
   memcpy( aczMonth[1], epczEndDate + astPos[i].m_Month, 2 );
   memcpy( aczDay[1],   epczEndDate + astPos[i].m_Day,   2 );

   memset( &stTime1, 0, sizeof(stTime1) );
   memset( &stTime2, 0, sizeof(stTime2) );
   stTime1.tm_year = atoi( aczYear[0] )-1900;
   stTime1.tm_mon  = atoi( aczMonth[0] )-1;
   stTime1.tm_mday = atoi( aczDay[0] );
   stTime2.tm_year = atoi( aczYear[1] )-1900;
   stTime2.tm_mon  = atoi( aczMonth[1] )-1;
   stTime2.tm_mday = atoi( aczDay[1] );
   tT1 = mktime( &stTime1 );
   tT2 = mktime( &stTime2 );

   return (int)(abs(tT1-tT2)/86400);
}

void showTxnIpc(T_IpcIntTxnDef *InIpc)
{
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgSrcId:\t%.4s", InIpc->sMsgSrcId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgDestId:\t%.4s", InIpc->sMsgDestId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsqType:\t%.16s", InIpc->sMsqType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvTxnNum:\t%.1s", InIpc->sConvTxnNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSysSeqNum:\t%.6s", InIpc->sSysSeqNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransType:\t%.1s", InIpc->sTransType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransState:\t%.1s", InIpc->sTransState);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostDate:\t%.8s", InIpc->sHostDate);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostSSN:\t%.12s", InIpc->sHostSSN);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTermSSN:\t%.12s", InIpc->sTermSSN);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyRsp:\t%.32s", InIpc->sKeyRsp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyRevsal:\t%.32s", InIpc->sKeyRevsal);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyCancel:\t%.32s", InIpc->sKeyCancel);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHeaderBuf:\t%.46s", InIpc->sHeaderBuf);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTxnNum:\t%.4s", InIpc->sTxnNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransCode:\t%.3s", InIpc->sTransCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgType:\t%.4s", InIpc->sMsgType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF002Ind:\t%c", InIpc->cF002Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPrimaryAcctNumLen:\t%.2s", InIpc->sPrimaryAcctNumLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPrimaryAcctNum:\t%.19s", InIpc->sPrimaryAcctNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sProcessingCode:\t%.6s", InIpc->sProcessingCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtTrans:\t%.12s", InIpc->sAmtTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtSettlmt:\t%.12s", InIpc->sAmtSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtCdhldrBil:\t%.12s", InIpc->sAmtCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransmsnDateTime:\t%.10s", InIpc->sTransmsnDateTime);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvRateSettlmt:\t%.8s", InIpc->sConvRateSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvRateCdhldrBil:\t%.8s", InIpc->sConvRateCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSysTraceAuditNum:\t%.6s", InIpc->sSysTraceAuditNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTimeLocalTrans:\t%.6s", InIpc->sTimeLocalTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateLocalTrans:\t%.4s", InIpc->sDateLocalTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF014Ind:\t%c", InIpc->cF014Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateExpr:\t%.4s", InIpc->sDateExpr);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateSettlmt:\t%.4s", InIpc->sDateSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateConv:\t%.4s", InIpc->sDateConv);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMchntType:\t%.4s", InIpc->sMchntType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstCntryCode:\t%.3s", InIpc->sAcqInstCntryCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosEntryModeCode:\t%.3s", InIpc->sPosEntryModeCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardSeqId:\t%.3s", InIpc->sCardSeqId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosCondCode:\t%.2s", InIpc->sPosCondCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF026Ind:\t%c", InIpc->cF026Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosPinCaptrCode:\t%.2s", InIpc->sPosPinCaptrCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF028Ind:\t%c", InIpc->cF028Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtTransFee:\t%.9s", InIpc->sAmtTransFee);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstIdCodeLen:\t%.2s", InIpc->sAcqInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstIdCode:\t%.11s", InIpc->sAcqInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwdInstIdCodeLen:\t%.2s", InIpc->sFwdInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwdInstIdCode:\t%.11s", InIpc->sFwdInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF035Ind:\t%c", InIpc->cF035Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack2DataLen:\t%.2s", InIpc->sTrack2DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack2Data:\t%.37s", InIpc->sTrack2Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF036Ind:\t%c", InIpc->cF036Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack3DataLen:\t%.3s", InIpc->sTrack3DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack3Data:\t%.104s", InIpc->sTrack3Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRetrivlRefNum:\t%.12s", InIpc->sRetrivlRefNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF038Ind:\t%c", InIpc->cF038Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAuthrIdResp:\t%.6s", InIpc->sAuthrIdResp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRespCode:\t%.2s", InIpc->sRespCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrTermnlId:\t%.8s", InIpc->sCardAccptrTermnlId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrId:\t%.15s", InIpc->sCardAccptrId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrNameLoc:\t%.40s", InIpc->sCardAccptrNameLoc);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF044Ind:\t%c", InIpc->cF044Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlRespCodeLen:\t%.2s", InIpc->sAddtnlRespCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlRespCode:\t%.25s", InIpc->sAddtnlRespCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack1DataLen:\t%.2s", InIpc->sTrack1DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack1Data:\t%.79s", InIpc->sTrack1Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataPrivateLen:\t%.3s", InIpc->sAddtnlDataPrivateLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataPrivate:\t%.512s", InIpc->sAddtnlDataPrivate);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeTrans:\t%.3s", InIpc->sCurrcyCodeTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeSettlmt:\t%.3s", InIpc->sCurrcyCodeSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeCdhldrBil:\t%.3s", InIpc->sCurrcyCodeCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF052Ind:\t%c", InIpc->cF052Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPinData:\t%.8s", InIpc->sPinData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF053Ind:\t%c", InIpc->cF053Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSecRelatdCtrlInfo:\t%.16s", InIpc->sSecRelatdCtrlInfo);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF054Ind:\t%c", InIpc->cF054Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlAmtLen:\t%.3s", InIpc->sAddtnlAmtLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlAmt:\t%.120s", InIpc->sAddtnlAmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataLen:\t%.3s", InIpc->sAddtnlDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlData:\t%.100s", InIpc->sAddtnlData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFldReservedLen:\t%.3s", InIpc->sFldReservedLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFldReserved:\t%.30s", InIpc->sFldReserved);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sChAuthInfoLen:\t%.3s", InIpc->sChAuthInfoLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sChAuthInfo:\t%.200s", InIpc->sChAuthInfo);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF062Ind:\t%c", InIpc->cF062Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSwitchingDataLen:\t%.3s", InIpc->sSwitchingDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSwitchingData:\t%.200s", InIpc->sSwitchingData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFinaclNetDataLen:\t%.3s", InIpc->sFinaclNetDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFinaclNetData:\t%.200s", InIpc->sFinaclNetData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sOrigDataElemts:\t%.42s", InIpc->sOrigDataElemts);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sReplacementAmts:\t%.42s", InIpc->sReplacementAmts);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgSecurityCode:\t%.8s", InIpc->sMsgSecurityCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRcvgInstIdCodeLen:\t%.2s", InIpc->sRcvgInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRcvgInstIdCode:\t%.11s", InIpc->sRcvgInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF102Ind:\t%c", InIpc->cF102Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId1Len:\t%.2s", InIpc->sAcctId1Len);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId1:\t%.28s", InIpc->sAcctId1);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF103Ind:\t%c", InIpc->cF103Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId2Len:\t%.2s", InIpc->sAcctId2Len);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId2:\t%.28s", InIpc->sAcctId2);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF104Ind:\t%c", InIpc->cF104Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransDescrptLen:\t%.3s", InIpc->sTransDescrptLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransDescrpt:\t%.100s", InIpc->sTransDescrpt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF121Ind:\t%c", InIpc->cF121Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sNationalSwResvedLen:\t%.3s", InIpc->sNationalSwResvedLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sNationalSwResved:\t%.100s", InIpc->sNationalSwResved);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF122Ind:\t%c", InIpc->cF122Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstResvdLen:\t%.3s", InIpc->sAcqInstResvdLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstResvd:\t%.100s", InIpc->sAcqInstResvd);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF123Ind:\t%c", InIpc->cF123Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sIssrInstResvdLen:\t%.3s", InIpc->sIssrInstResvdLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sIssrInstResvd:\t%.100s", InIpc->sIssrInstResvd);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF064Ind:\t%c", InIpc->cF064Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMAC064:\t%.8s", InIpc->sMAC064);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF128Ind:\t%c", InIpc->cF128Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMAC128:\t%.8s", InIpc->sMAC128);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostTransFee1:\t%.12s", InIpc->sHostTransFee1);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostTransFee2:\t%.12s", InIpc->sHostTransFee2);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTlrNum:\t%.8s", InIpc->sTlrNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sOpenInst:\t%.15s", InIpc->sOpenInst);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sStlmInst:\t%.15s", InIpc->sStlmInst);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMiscFlag:\t%.32s", InIpc->sMiscFlag);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMisc:\t%.128s", InIpc->sMisc);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "===========================================================\n" );
}