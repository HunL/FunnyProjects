#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <errno.h>
#include <sys/msg.h>
#include <signal.h>

#include "EncOpr.h"

static int hsm_req_qid;
static int hsm_rsp_qid;
static int hsm_initiated = 0;
static int hsm_timeout=10;
int hsm_timeout_flag = 0;

void   hsm_TimeOut(int sig)
{
	hsm_timeout_flag = 1;
}

int hsm_srv_init()
{
	int iRet;
	char sFileName[128+1]={0};
	char paramvalue[128+1]={0};
	int iReqKey;
	int iRspKey;

	if(hsm_initiated) return HSM_SUCCESS;

	memset(paramvalue,0,20);
	iRet=GetParamValue("REQ_MSQKEY",paramvalue);
	if(iRet<0)
	{
		return HSM_FAIL;
	}
	else
	{
		iReqKey=atoi(paramvalue);
	}

	memset(paramvalue,0,20);
	iRet=GetParamValue("RSP_MSQKEY",paramvalue);
	if(iRet<0)
	{
		return HSM_FAIL;
	}
	else
	{
		iRspKey=atoi(paramvalue);
	}

	memset(paramvalue,0,20);
	iRet=GetParamValue("TIMEOUT",paramvalue);
	if(iRet<0)
	{
		hsm_timeout=10;
	}
	else
	{
		hsm_timeout=atoi(paramvalue);
	}

	hsm_req_qid = msgget(iReqKey, 0660);
	hsm_rsp_qid = msgget(iRspKey, 0660);

	if (hsm_req_qid == -1 || hsm_rsp_qid == -1)
	{
		return HSM_FAIL;
	}
	else
	{
		hsm_initiated = 1;
		return HSM_SUCCESS;
	}

}

int	nEncOpr(HSMOprDef *hsmOpr)
{
	int				nMsgLen,iResult;
	HSMMsgInDef		hsmMsgIn,hsmMsgTmp;


	if(hsm_srv_init() != HSM_SUCCESS)
	{
		return HSM_FAIL;
	}
	

	for(;;) {
		memset(&hsmMsgTmp,0,sizeof(hsmMsgTmp));
			if((iResult = msgrcv(hsm_rsp_qid, &hsmMsgTmp, sizeof(HSMMsgInDef),
				getpid(),IPC_NOWAIT)) < 0)
		break;
	}

	memset(&hsmMsgIn,0,sizeof(HSMMsgInDef));
	hsmMsgIn.nMsgType = getpid();
	memcpy(&hsmMsgIn.hsmOpr,hsmOpr,sizeof(HSMOprDef));

	
	
	
	iResult = msgsnd(hsm_req_qid, &hsmMsgIn, sizeof(HSMMsgInDef)-sizeof(long),0);
	if (iResult != 0)
	{
		
		return HSM_FAIL;
	}

	
	hsm_timeout_flag=0;
	sigset(SIGALRM, hsm_TimeOut);
	alarm(hsm_timeout);

	nMsgLen = -1;

	while ((nMsgLen = msgrcv(hsm_rsp_qid, &hsmMsgIn,
				sizeof(HSMMsgInDef),getpid(), 0)) < 0 &&
				hsm_timeout_flag == 0 )
	{
		if (errno == EINTR) continue;
		break;
	}

	alarm(0);
	if (nMsgLen < 0 || hsm_timeout_flag == 1)
	{
		return HSM_FAIL;
	}

	
	  

	if(memcmp(hsmMsgIn.hsmOpr.saRspCode, "00", 2) == 0)
	{
		memcpy(hsmOpr,&hsmMsgIn.hsmOpr,sizeof(HSMOprDef));
		return HSM_SUCCESS;
	}
	else
	{
		return HSM_FAIL;
	}
}


/************************************ �ļ����� ***********************/
