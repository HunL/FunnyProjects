static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Common/CalcString.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";

#define MAX_MAC_ELEMENT_LEN           256
#define MAX_MAC_ELEMENT_LEN_LEN       3

int istruealnum(char c);
long numin(char * str, short len);
void numout(char * str, short len, long num);
/********************************************************************
			Module name:	AddString
			Function   :	Add a string into another by value
			Input      :	d: to be added string
										dlen: length of dest string
										s: source string
										slen: length of source string
			Output     :	void
			Create Date:	Mar 1, 1996
			Last Modify:	Aug 6, 1996
********************************************************************/
void AddString( char * d, int dlen, char * s, int slen)
{
	int i,j,vals;
	int carry=0, res;

	if (( dlen==0) || ( slen==0)) return;
	if ( dlen<slen) return;

	for( i=dlen-1, j=slen-1; i>=0; i--,j--)
	{
		if ( j<0)
			vals='0';
		else
			vals=s[j];

		res=d[i]-'0'+vals-'0'+carry;

		d[i]=res%10+'0';
		carry=res/10;
	}
}

/********************************************************************
			Module name:	MinString
			Function   :	Min a string into another by value
			Input      :	d: to be mined string
										dlen: length of dest string
										s: source string
										slen: length of source string
			Output     :	the sign of result: '+' or '-'
			Create Date:	Mar 1, 1996
			Last Modify:	Aug 6, 1996
********************************************************************/
char MinString( char * d, int dlen, char * s, int slen)
{
	int i, j, carry=0;
	signed char vals, res;

	if (( dlen==0) || ( slen==0)) return 0;
	if ( dlen<slen) return 0;

	for( i=dlen-1, j=slen-1; i>=0; i--, j--)
	{
		if ( j<0)
			vals='0';
		else
			vals=s[j];

		res=d[i]-carry-vals;

		if ( res<0)
		{
			carry=1;
			res+=10;
		}
		else
		{
			carry=0;
		}
		d[i]=res+'0';
	}
	return ( carry==1?'-':'+');
}

void preprocess_mac_element(char * mac_element, char * mac_element_len)
{
	short len, return_len = 0, mac_element_pos = 0, blank_now = 0;
	char current_char;
	char temp_mac_element[MAX_MAC_ELEMENT_LEN];

	len = (short)numin(mac_element_len, MAX_MAC_ELEMENT_LEN_LEN);
	memcpy(temp_mac_element, mac_element, MAX_MAC_ELEMENT_LEN);
	memset(mac_element, ' ', MAX_MAC_ELEMENT_LEN);

	while (' ' == temp_mac_element[mac_element_pos++]
				&& mac_element_pos != len);

	if (mac_element_pos == len)
     	return_len = 0;
	else
	{
		if (mac_element_pos) mac_element_pos--;

		while (mac_element_pos != len)
		{
			current_char = toupper(temp_mac_element[mac_element_pos++]);

    		if (istruealnum(current_char) || '.' == current_char || ',' == current_char)
			{
				if (blank_now) mac_element[return_len++] = ' ';
						blank_now = 0;
				mac_element[return_len++] = current_char;
				continue;
			}

			if (' ' == current_char)
			{
				blank_now = 1;
				continue;
			}
        }
    }

	numout(mac_element_len, MAX_MAC_ELEMENT_LEN_LEN, return_len);
    return;

}

int istruealnum(char c)
{
	if ('a' <= c && c <= 'z') return 1;
	if ('A' <= c && c <= 'Z') return 1;
	if ('0' <= c && c <= '9') return 1;

	return 0;
}

long numin(char * str, short len)
{
	char buf[50];

	memcpy(buf, str, len);
	buf[len] = 0;

	return (atol(buf));
}

void numout(char * str, short len, long num)
{
	char buf[51];

	sprintf(buf, "%050ld", num);
	memcpy(str, buf + 50 - len, len);

	return;
}

