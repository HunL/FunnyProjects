/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: ToOpr.c                                                     */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*                                                                           */
/*****************************************************************************/
static char * id = "$Id: ToOpr.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <errno.h>
#include "SrvDef.h"
#include "MsqOpr.h"
#include "IpcInt.h"
#include "TxnNum.h"
#include "ToOpr.h"
#include "SrvParam.h"
#include "ErrCode.h"
#include "HtLog.h"

void SigAlarmProc ();

/*****************************************************************************/
/* FUNC:   int ToCtrlReq (char *sSrvId, char *sSrvSeqId, T_SrvMsq *ptSrvMsq, */
/*                        T_SwtToReqDef *ptSwtToReq, T_IpcIntTxnDef *ptTxn); */
/* INPUT:  sSrvId: server id                                                 */
/*         sSrvSeqId: һ��server idͬʱ���ж��ʱ, ÿ����˳���, ��λ������  */
/*         ptSrvMsq: ���ڴ��server id��queue id                             */
/*         ptSwtToReq: ����ToCtl������IPC                                    */
/*                     nTransCode, nToCtlTime, sTxnDate�Ѹ�ֵ                */
/* OUTPUT: ptSwtToReq: ��ToCtl�õ���Ӧ��IPC                                  */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ToCtl��������, ������Ӧ��,                                      */
/*         ��ʱ��TOCTL_WAIT_SECOND(ϵͳ����)��δ�յ�Ӧ����ʧ�ܴ���           */
/*                                                                           */
/*         Mody by liushj ���TO���̲������ã���ˮ��ȡ��TO���Ʒֲ�����       */
/*                                                                           */
/*****************************************************************************/
int ToCtrlReq( char           *sSrvId,
               char           *sSrvSeqId,
               T_SrvMsq       *ptSrvMsq,
               T_SwtToReqDef  *ptSwtToReq,
               T_IpcIntTxnDef *ptIpcIntTxn )
{
    int            nReturnCode;
    int            nToCtlWaitSecond;
    int            nMsgSize;
    long           lRcvMsqType;
    T_SwtToReqDef  ptSwtToReqTmp;
	int            nTOPCount;
 
    if(ptSwtToReq->nTransCode ==TOCTL_NORMAL_SECOND)
       return 0;
    /* get TOCTL_WAIT_SECOND */
    nToCtlWaitSecond = atoi(getenv("TOCTL_WAIT_SECOND"));
    if (nToCtlWaitSecond == 0)
        nToCtlWaitSecond = TOCTL_WAIT_SECOND_DEFAULT;
	/* get TO process Count */
    if (getenv("TO_PROCESS_COUNT"))
		nTOPCount = atoi(getenv("TO_PROCESS_COUNT"));
	else
	    nTOPCount = 1;

    memcpy(ptSwtToReq->sSrcSrvId, sSrvId, SRV_ID_LEN);
    memcpy(ptSwtToReq->sSrvId, SRV_ID_TOCTL, SRV_ID_LEN);
    lRcvMsqType = atoi(sSrvId) * 100 + atoi(sSrvSeqId);
    ptSwtToReq->lRtnMsgType = lRcvMsqType;

    /* recv on queue to clear any unreceived msg */
    nMsgSize = sizeof(*ptSwtToReq);
    while ((nReturnCode = MsqRcv(SRV_ID_TOCTL,
                                 ptSrvMsq,
                                 lRcvMsqType,
                                 MSQ_RCV_MODE_NONBLOCK, 
                                 &nMsgSize,
                                 (char *)&ptSwtToReqTmp)) == 0);
    if (nReturnCode != ERR_CODE_MSQ_NO_MSG)
    {
        return (nReturnCode);
    }

    /* send req to ToCtl */
    memcpy(ptSwtToReq->sSrcSrvId, sSrvId, SRV_ID_LEN);
    memcpy(ptSwtToReq->sSrvId, SRV_ID_TOCTL, SRV_ID_LEN);
    ptSwtToReq->lRtnMsgType = lRcvMsqType;
    nReturnCode = MsqSnd(SRV_ID_TOCTL,
                         ptSrvMsq,
                         atoi(SRV_ID_TOCTL) * 100 + (atoi(ptSwtToReq->sSysSeqNum)%nTOPCount + 1),
                         sizeof(*ptSwtToReq),
                         (char *)ptSwtToReq);
    if (nReturnCode)
    {
        return (nReturnCode);
    }
    
    /* receive reply from ToCtl */
    /* set alarm time */
    sigset(SIGALRM, SigAlarmProc);
    alarm(nToCtlWaitSecond);
    nMsgSize = sizeof(*ptSwtToReq);
    nReturnCode = MsqRcv(SRV_ID_TOCTL,
                         ptSrvMsq,
                         lRcvMsqType,
                         MSQ_RCV_MODE_BLOCK,
                         &nMsgSize,
                         (char *)ptSwtToReq);
    alarm (0);
    if (nReturnCode)
    {
        sigset(SIGALRM, SIG_IGN);
        return (nReturnCode);
    }

    return (0);
}

void SigAlarmProc ()
{
}
