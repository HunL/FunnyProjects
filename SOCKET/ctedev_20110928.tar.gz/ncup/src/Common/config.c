#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <memory.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>

#include "config.h"

#define TMPLENGH	100
#define TMPLEN	20

#define PARAMLEN	20
#define VALUELEN	30

int SplitNItem(char *pBuf,char *pValue,char cSplit,int numbers,int datalen)
{
	char *p,*p1;
	int i;
	p=pBuf;
	for(i=0;i<numbers;i++)
	{
		p1=strchr(p,cSplit);
		if(!p1)
		{
			printf("this line is [%s]  error!\n",pBuf);
			return (-1);
		}

		if(p1-p<datalen)
		{
			strncpy(pValue,p,p1-p);
			pValue[p1-p]=0;
		}
		else
		{
			strncpy(pValue,p,datalen);
			pValue[datalen]=0;
		}
		p=p1+1;
	}
	return (0);
}

int InitDataTypes(struct data_table *tables,int numbers)
{
	int i,fd,rc;
	char tmpbuf[TMPLENGH],filename[TMPLENGH];
	char *point;
	char hsmip[HSM_IPLEN+1],hsmport[HSM_PORTLEN+1],hsmnum[HSM_NUMLEN+1];
	int counter;

	for(i=0;i<numbers;i++)
		tables[i].useflag=-1;

	bzero(filename,TMPLENGH);
	sprintf(filename,"%s/%s",getenv("FEHOME"),HSMCFG_INI);
	fd=open(filename,O_RDONLY);
	if(fd<0)
	{
		printf("open file [%s] error!\n",filename);
		return (-1);
	}

	rc=lseek(fd,0L,SEEK_SET);
	if(rc<0)
	{
		close(fd);
		printf("leek file [%s] error!\n",filename);
		return (-2);
	}

	counter=0;
	while(1)
	{
		bzero(hsmip,HSM_IPLEN+1);
		bzero(hsmport,HSM_PORTLEN+1);
		bzero(hsmnum,HSM_NUMLEN+1);

		point=tmpbuf;
		while(1)
		{
			rc=read(fd,point,1);
			if(rc!=1){
				close(fd);
				return (0);
			}
			if((*point)==0x0a)
				break;
			if(*point==' '|| *point=='\t');
			else
				point++;
		}
		*point=0x00;

		if(point-tmpbuf<1 || point-tmpbuf>100)
		{
			printf("[%s] this line [%s] is blank or overlength!\n",
				filename,tmpbuf);
			continue;
		}

		if(SplitNItem(tmpbuf,hsmip,'|',1,HSM_IPLEN)<0)
		{
			printf("[%s] get hsmip errro!\n",tmpbuf);
			continue;
		}
		if(SplitNItem(tmpbuf,hsmport,'|',2,HSM_PORTLEN)<0)
		{
			printf("[%s] get hsmport errro!\n",tmpbuf);
			continue;
		}
		if(IsNumStr(hsmport,strlen(hsmport))<0)
		{
			printf("hsmport [%s] is error!\n",hsmport);
			continue;
		}

		if(SplitNItem(tmpbuf,hsmnum,'|',3,HSM_NUMLEN)<0)
		{
			printf("[%s] get hsmnum errro!\n",tmpbuf);
			continue;
		}
		if(IsNumStr(hsmnum,strlen(hsmnum))<0)
		{
			printf("hsmnum[%s] is error!\n",hsmnum);
			continue;
		}

		strncpy(tables[counter].hsmip,hsmip,strlen(hsmip));
		tables[counter].hsmip[strlen(hsmip)]=0;
		tables[counter].hsmport=atoi(hsmport);
		tables[counter].hsmnum=atoi(hsmnum);
		tables[counter].useflag=1;

		counter++;
		if(counter>=numbers)
		{
			printf("[%s] too more lines!\n",filename);
			break;
		}
	}
	return (0);
}


int IsNumStr(char *str,int length)
{
	int i;
	for(i=0;i<length;i++)
	{
		if(*(str+i)<'0' || *(str+i)>'9')
			return (-1);
	}
	return (0);
}

int CSplitItem( char * pBuf,char *pParam,char * pValue,char cSplit,char cStart,char cEnd )
{
	char * pSplit;
	char * pStart;
	char * pEnd;
	short int    nCharNum;

	pSplit=strchr(pBuf,cSplit);
	if (pSplit == NULL)
		return (-1);
	if (pSplit == pBuf)
		return (-1);
	if ((pSplit - pBuf +1) == strlen(pBuf))
		return (-1);

	pStart = pBuf;
	pEnd = pSplit - 1;
	while((*pStart) == ' ')
	 {
		if (pStart == pEnd)
			return (-1);
		pStart ++;
	 }
	while((*pEnd) == ' ')
	 {
		if (pEnd == pStart)
			return (-1);
		pEnd --;
	 }
	nCharNum=pEnd-pStart+1;
	memcpy(pParam,pStart,nCharNum);
	pParam[nCharNum]='\0';


	pStart=strchr(pBuf,cStart);
	pEnd=strrchr(pBuf,cEnd);
	if(pStart==NULL || pEnd==NULL)
		return (-1);

	if(pEnd-pStart-1<=0)
		return (-1);

	nCharNum=pEnd-pStart-1;
	memcpy(pValue,pStart+1,nCharNum);
	pValue[nCharNum]='\0';
	return(0);
}


int GetParamValue(char * ParamName,char * ParamValue)
{
	int fd,rc;
	char tmpbuf[TMPLENGH];
	char paramname[PARAMLEN],value[VALUELEN];
	char *point;

	bzero(tmpbuf,TMPLENGH);
	sprintf(tmpbuf,"%s/%s",getenv("FEHOME"),HSMSVR_INI);
	fd=open(tmpbuf,O_RDONLY);
	if(fd<0)
	{
		 printf("Open Param File %s Error!\n",tmpbuf);
		 return (-1);
	}
	rc=lseek(fd,0L,SEEK_SET);
	if(rc<0)
	{
		close(fd);
		printf("Leek Param %s Failed =%d\n",tmpbuf,errno);
		return (-1);
	}

	while(1)
	{
		bzero(tmpbuf,TMPLENGH);
		bzero(paramname,PARAMLEN);
		bzero(value,VALUELEN);

		point=tmpbuf;
		while(1){
			rc=read(fd,point,1);
			if(rc!=1){
				close(fd);
				return (-1);
			}
			if((*point)==0x0a)
				break;
			point++;
		}
		*point=0x00;

		if(point-tmpbuf<1)
			continue;

		if(CSplitItem(tmpbuf,paramname,value,'=','[',']')<0)
			continue;

		if(strcmp(ParamName,paramname))
			continue;

		strcpy(ParamValue,value);
		break;
	}
	close(fd);

	return (0);
}
