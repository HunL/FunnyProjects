/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: SplitDe55.c                                                 */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/

static char * id = "$Id: SplitDE55.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Public.h"
#include "HtLog.h"

/*Tag�ĳ�������*/
int DelHexICCDataByTag(char* ICC, char* Tag, int ICCLen, int* NewLen)
{
	char          HexTag[3];
	int           ICCLength,nPos;
	char          AscVal[255+1];
	char          EBcdVal[255+1];
	int           EBcdLen,TagLen=0,TailLen;
	char          caTag[5];

	nPos=0;
	/*cMRightTrim(Tag);*/
	
	TagLen=strlen(Tag);
	
	/*Tag[TagLen]='\0';*/
    
	TailLen = ICCLen;

    memset(HexTag,  0x00, sizeof(HexTag));
	memset(&AscVal, 0x00, sizeof(AscVal)  );
	memset(&EBcdVal,0x00, sizeof(EBcdVal) );

    
    nMHexAsciiToBin(Tag,
					TagLen,
					HexTag);
	TagLen = TagLen / 2;

    
	while ( nPos < ICCLen )
	{

        if (ICC[nPos] == HexTag[0] &&
        	ICC[nPos + TagLen - 1] == HexTag[TagLen - 1] )
        {
        	EBcdLen = ICC[nPos + TagLen] ;
			memcpy(&ICC[nPos],
				   &ICC[nPos + TagLen + 1 + EBcdLen],
				   TailLen - TagLen - 1 - EBcdLen   );

            *NewLen = ICCLen - TagLen - 1 - EBcdLen;
        	return 0;
        }
        else
        {
        	/*���Tag�ĵ�һ�ֽڵ�1��5λԪΪ1����Ϊ2λ������Ϊ1λ*/
        	if ((ICC[nPos] & 0x1F) == 0x1F)
			{
        		nPos += 2;
				TailLen = TailLen - 2;
            }
        	else
			{
        		nPos += 1;
				TailLen = TailLen - 1;
            }

        	/*Lenֻ��һλ,EBcdLenΪ��Tagֵ�ĳ���*/
        	EBcdLen = ICC[nPos];
			if(EBcdLen <= 0)
			{
				*NewLen = ICCLen;
				return 0;
			}
        	nPos++ ;
			TailLen = TailLen - 1;

        	/*λ����EBcdLen*/
        	nPos += EBcdLen ;
			TailLen = TailLen - EBcdLen;

        }

	}  /* while */

	*NewLen = ICCLen;
	return 0;
}

int ChgHexICCDataByTag(char* ICC, char* Tag, int ICCLen, char *ChgTag, int* NewLen)
{
	char          HexTag[3],HexChgTag[3];
	int           ICCLength,nPos;
	char          AscVal[255+1];
	char          EBcdVal[255+1];
	int           EBcdLen,TagLen=0,TailLen,ChgTagLen=0;

	nPos=0;
	/*cMRightTrim(Tag);*/
	TagLen=strlen(Tag);
	/*Tag[TagLen]='\0';*/

	/*cMRightTrim(ChgTag);*/
	ChgTagLen=strlen(ChgTag);
	/*ChgTag[ChgTagLen]='\0';*/

	TailLen = ICCLen;

    memset(HexTag, 0x00, sizeof(HexTag));
    memset(HexChgTag, 0x00, sizeof(HexChgTag));
	memset(&AscVal,    0x00, sizeof(AscVal)  );
	memset(&EBcdVal,   0x00, sizeof(EBcdVal) );

    nMHexAsciiToBin(Tag,
					TagLen,
					HexTag);
	TagLen = TagLen / 2;

    nMHexAsciiToBin(ChgTag,
					ChgTagLen,
					HexChgTag);
	ChgTagLen = ChgTagLen / 2;

	while ( nPos < ICCLen )
	{
        if (ICC[nPos] == HexTag[0] &&
        	ICC[nPos + TagLen - 1] == HexTag[TagLen - 1] )
        {
			memcpy(&ICC[nPos], &HexChgTag[0], ChgTagLen);

            *NewLen = ICCLen;
        	return 0;
        }
        else
        {
        	/*���Tag�ĵ�һ�ֽڵ�1��5λԪΪ1����Ϊ2λ������Ϊ1λ*/
        	if ((ICC[nPos] & 0x1F) == 0x1F)
			{
        		nPos += 2;
				TailLen = TailLen - 2;
            }
        	else
			{
        		nPos += 1;
				TailLen = TailLen - 1;
            }

        	/*Lenֻ��һλ,EBcdLenΪ��Tagֵ�ĳ���*/
        	EBcdLen = ICC[nPos];
			if(EBcdLen <= 0)
			{
				*NewLen = ICCLen;
				return 0;
			}
        	nPos++ ;
			TailLen = TailLen - 1;

        	/*λ����EBcdLen*/
        	nPos += EBcdLen ;
			TailLen = TailLen - EBcdLen;
    	}
	}  /* while */

	*NewLen = ICCLen;
	return 0;
}
#if 0
int GetHexF055Data(char *buf, char * sF055Val, int iF055Len)
{
    int  len,i;
    char sTemp[3];
    
    for(i=0 , i<iF055Len, i++)
    {
        if(i == 0)
        {
            memset(sTemp, 0, sizeof(sTemp));
            Hex2Str(sF055Val, sTemp, 1);
            Hex2Bin(sSrc, 1, sDes);
        }
    }
    memset(sF055HexVal, 0, sizeof(sF055HexVal));
    memcpy(sF055HexVal, sF055Val, iF055Len);
    
    
    
    return len;
}
#endif
