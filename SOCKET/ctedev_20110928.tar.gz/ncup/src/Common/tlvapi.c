#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tlvapi.h"

static void parse_tlv_tag(tlv_buf_t *tag, char *src)
{
    if (0x1f == (src[0]&0x1f))
        tag->size = 2;
    else
        tag->size = 1;

    tag->data = src;
}

static int parse_tlv_length(tlv_buf_t *tlv, char *src)
{
    char *t;

    if (0 == src[0]) {
        tlv->size = 0;
        tlv->data = NULL;
    } else if (0x80 > src[0]) {
        tlv->size = (int)src[0];
        tlv->data = &src[1];
    } else if (0x81 == src[0]) {
        tlv->size = (int)src[1];
        tlv->data = &src[2];
    } else if (0x82 == src[0]) {
        t = (char*)&(tlv->size);
        t[0] = src[2];
        t[1] = src[1];
        t[2] = 0x00;
        t[3] = 0x00;
        tlv->data = &src[3];
    } else if (0x83 == src[0]) {
        t = (char*)&(tlv->size);
        t[0] = src[3];
        t[1] = src[2];
        t[2] = src[1];
        t[3] = 0x00;
        tlv->data = &src[4];
    } else {
        return -1;
    }

    return 0;
}

static int tlv_parser(tlv_data_t *tlv, char *src, int size)
{
    int  rv;
    int  offset;
    char *ptr  = src;
    char *head = src;
    
    /* Parse Tlv Data Tag */
    parse_tlv_tag(&(tlv->tag), ptr);
    /* ptr point to the head of the length data of tlv data */
    ptr = &(tlv->tag.data[tlv->tag.size]);
    /* Parse Tlv Data Length */
    rv  = parse_tlv_length(&(tlv->val), ptr);
    if (rv != 0)
        return -1;
    
    /* ptr point to the head of the next tlv data */
    if (tlv->val.data==NULL && tlv->val.size==0)
        ptr = &(tlv->tag.data[tlv->tag.size+1]);
    else
        ptr = &(tlv->val.data[tlv->val.size]);
    /* check format */
    offset = (int)(ptr - head);
    return offset<=size ? 0 : -2;
}

static int parse_tlv_data_t(char **buf, char *tag, char *src, int size)
{
    int  rv;
    int  len;
    int  offset = 0;
    char *last  = src;
    char *next  = src;
    tlv_data_t tlv;
    
    len = strlen(tag);
    while(size > 0) {
        rv = tlv_parser(&tlv, next, size);
        if (rv != 0)
            return -1;
        
        if ((len==tlv.tag.size) && (!memcmp(tag, tlv.tag.data, len))) {
            *buf = tlv.val.data;
            return tlv.val.size;
        }

        last = next;
        /* next point to the start of next tlv data */
        if (tlv.val.data==NULL && tlv.val.size==0)
            next = &(tlv.tag.data[tlv.tag.size+1]);
        else
            next = &(tlv.val.data[tlv.val.size]);
        /* compute the size of the tlv data */
        offset = (int)(next - last);
        size  -= offset;
    }

    return -2;
}

int parse_tlv_data(char *buf, char *tag, char *src, int size)
{
    int  len;
    char *ptr = NULL;
    
    len = parse_tlv_data_t(&ptr, tag, src, size);
    if (len < 0 )
        return -1;

    memcpy(buf, ptr, len);
    return len;
}

int parse_tlv_data_tmplt(char *buf, char *tag, char *tmplt, char *src, int size)
{
    int  len;
    char buf_tag[2] = {0};
    char *last = src;
    char *next = NULL;
    
    if (tmplt != NULL) {
        while(tmplt[0] != '\0' && size > 0) {
            buf_tag[0] = tmplt[0];
            len = parse_tlv_data_t(&next, buf_tag, last, size);
            if (len < 0)
                return -1;
            
            size = len;
            last = next;
            ++tmplt;
        }
    }
    
    if (size <= 0)
        return -2;

    len = parse_tlv_data_t(&next, tag, last, size);
    if (len < 0)
        return -3;
    
    memcpy(buf, next, len);
    return len;
}

int count_tlv_substring(char *src, int size)
{
    int   rv;
    int   count  = 0;    
    int   offset = 0;
    char *last;
    char *next = src;
    tlv_data_t tlv;

    while (size > 0) {
        rv = tlv_parser(&tlv, next, size);
        if (rv != 0)
            return -1;

        last = next;
        if (tlv.val.data==NULL && tlv.val.size==0)
            next = &(tlv.tag.data[tlv.tag.size+1]);
        else
            next = &(tlv.val.data[tlv.val.size]);
        offset = (int)(next - last);
        size -= offset;
        ++count;
    }

    return count;
}

int unpack_tlv_data(tlv_data_t **dst, char *src, int size)
{
    int    i;
    int    rv;
    int    offset;
    int    count;
    char   *last;
    char   *next = src;
    tlv_data_t *ptr = NULL;
    
    count = count_tlv_substring(src, size);
    if (count < 0)
        return -1;

    /* Assign memory for dst */
    *dst  = (tlv_data_t*)calloc(count, sizeof(tlv_data_t));
    if (NULL == *dst)
        return -2;

    i = 0;
    ptr = *dst;
    while(i < count) {
        /* parse tlv data */
        rv = tlv_parser(&(ptr[i]), next, size);
        if (rv != 0) {
            free(*dst);
            *dst = NULL;
            return -3;
        }
        
        last = next;
        if (ptr[i].val.data==NULL && ptr[i].val.size==0)
            next = &(ptr[i].tag.data[ptr[i].tag.size+1]);
        else
            next = &(ptr[i].val.data[ptr[i].val.size]);
        offset = (int)(next - last);
        size  -= offset;
        ++i;
    }

    return count;
}

int pack_tlv_data(char *buf, char *tag, char *src, int size)
{
    int  tag_len;
    int  length = 0;
    char *ptr = buf;
    char *tmp = NULL;
    
    tag_len = strlen(tag);
    /* Check Tag Format */ 
    if ((tag_len<1 || tag_len > 2) 
     || ((tag[0]&0x1f)==0x1f && tag_len!=2)
     || ((tag[0]&0x1f)!=0x1f && tag_len!=1))
        return -1;
    
    memcpy(ptr, tag, tag_len);
    ptr += tag_len;
    
    if (size < 0x80) {
        ptr[0] = size&0xff;
        memcpy(&ptr[1], src, size);
        length += tag_len + 1 + size;
    } else if (size > 0x80 && size <= 0xff) {
        ptr[0] = 0x81;
        ptr[1] = size&0xff;
        memcpy(&ptr[2], src, size);
        length += tag_len + 2 + size;
    } else if (size > 0xff && size <= 0xffff) {
        tmp = (char*)&size;
        ptr[0] = 0x82;
        ptr[1] = tmp[1];
        ptr[2] = tmp[0];
        memcpy(&ptr[3], src, size);
        length += tag_len + 3 + size;
    } else if (size > 0xffff && size <= 0xffffff) {
        tmp = (char*)&size;
        ptr[0] = 0x83;
        ptr[1] = tmp[2];
        ptr[2] = tmp[1];
        ptr[3] = tmp[0];
        memcpy(&ptr[4], src, size);
        length += tag_len + 4 + size;
    } else {
        return -2;
    }
    
    return length;
}

int pack_tlv_data_dp(char *buf, char *tag, char *src, int size, int *tlLen, int *tlvLen)
{
    int  tag_len;
    char *ptr = buf;
    char *tmp = NULL;
    
    tag_len = strlen(tag);
    /* Check Tag Format */ 
    if ((tag_len<1 || tag_len > 2) 
     || ((tag[0]&0x1f)==0x1f && tag_len!=2)
     || ((tag[0]&0x1f)!=0x1f && tag_len!=1))
        return -1;
    
    memcpy(ptr, tag, tag_len);
    ptr += tag_len;
    
    if (size < 0x80) {
        ptr[0] = size&0xff;
        memcpy(&ptr[1], src, size);
        *tlLen += tag_len + 1;
        *tlvLen += tag_len + 1 + size;
    } else if (size > 0x80 && size <= 0xff) {
        ptr[0] = 0x81;
        ptr[1] = size&0xff;
        memcpy(&ptr[2], src, size);
        *tlLen += tag_len + 2;
        *tlvLen += tag_len + 2 + size;
    } else if (size > 0xff && size <= 0xffff) {
        tmp = (char*)&size;
        ptr[0] = 0x82;
        ptr[1] = tmp[1];
        ptr[2] = tmp[0];
        memcpy(&ptr[3], src, size);
        *tlLen += tag_len + 3;
        *tlvLen += tag_len + 3 + size;
    } else if (size > 0xffff && size <= 0xffffff) {
        tmp = (char*)&size;
        ptr[0] = 0x83;
        ptr[1] = tmp[2];
        ptr[2] = tmp[1];
        ptr[3] = tmp[0];
        memcpy(&ptr[4], src, size);
        *tlLen += tag_len + 4;
        *tlvLen += tag_len + 4 + size;
    } else {
        return -2;
    }
    
    return 0;
}

