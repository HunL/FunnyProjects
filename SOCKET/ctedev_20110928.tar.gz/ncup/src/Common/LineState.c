/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: LineState.c                                                 */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-04  YU TONG        Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Common/LineState.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";

#include <stdlib.h>
#include <sys/msg.h>
#include <memory.h>
#include "SrvDef.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "LineStat.h"
#include "HtLog.h"

/*****************************************************************************/
/* FUNC:   int LineStateChg (char *sSrvId, int nLineStat);                   */
/* INPUT:  sSrvId: server id                                                 */
/*         nLineState: ͨѶ��·״̬,                                         */
/*                     LINE_STATE_CONNECT, LINE_STATE_DISCONNECT             */
/*                     LINE_STATE_RESET                                      */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �޸�server id��Ӧ����·��״̬, ��tbl_line_inf                     */
/*         ��һ��������, line_state��1; ��һ������, line_state��1            */
/*         ע: ֻ�ڽ����µķ�������ʱ���ô˺���, ��������ӿɲ����          */
/*****************************************************************************/
int LineStateChg (char *sSrvId, char *sLineIndex, int nStat)
{
	int					nLineState;
	int					nReturnCode;
	Tbl_line_inf_Def	tTblLineInf;
	
	/* get line inf */
	memset ((char *)&tTblLineInf, 0x00, sizeof (tTblLineInf));
	memcpy (tTblLineInf.srv_id, sSrvId, SRV_ID_LEN);
	memcpy (tTblLineInf.line_index, sLineIndex, 1);

	nReturnCode = DbsLINEINF(DBS_SELECT, &tTblLineInf);
	if (nReturnCode)
		return (nReturnCode);

	nLineState = atoi (tTblLineInf.line_state);
	
	switch (nStat)
	{
	case LINE_STATE_CONNECT:
		if (nLineState < atoi(tTblLineInf.line_max))
			sprintf (tTblLineInf.line_state, "%02d", nLineState+1);
		break;
	case LINE_STATE_DISCONNECT:
		if (nLineState > 0)
			sprintf (tTblLineInf.line_state, "%02d", nLineState-1);
		break;
	case LINE_STATE_RESET:
		sprintf (tTblLineInf.line_state, "%02d", 0);
		break;
	default:
		DbsRollback ();
		return -1;
	}
	
	nReturnCode = DbsLINEINF(DBS_UPDATE, &tTblLineInf);
	if (nReturnCode)
	{
		DbsRollback ();
		return (nReturnCode);
	}

	DbsCommit ();
	return 0;
}

/*****************************************************************************/
/* FUNC:   int LineStateCheck (char *sSrvId, int *pnLineStat);               */
/* INPUT:  sSrvId: server id                                                 */
/* OUTPUT: nLineState: ͨѶ��·״̬,                                         */
/*                     LINE_STATE_CONNECT, LINE_STATE_DISCONNECT             */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���server id��Ӧ����·��״̬, ��tbl_line_inf                     */
/*****************************************************************************/
int LineStateCheck (char *sSrvId, char *sLineIndex, int *pnLineStat)
{
	int					nReturnCode;
	Tbl_line_inf_Def	tTblLineInf;
	
	/* get line inf */
	memset ((char *)&tTblLineInf, 0x00, sizeof (tTblLineInf));
	memcpy (tTblLineInf.srv_id, sSrvId, SRV_ID_LEN);
	memcpy (tTblLineInf.line_index, sLineIndex, 1);
	nReturnCode = DbsLINEINF(DBS_SELECT, &tTblLineInf);
	if (nReturnCode)
		return (nReturnCode);

	HtLog ("Switch.1.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "tTblLineInf.line_state[%s]", tTblLineInf.line_state);

	/* check line state */
	if (atoi (tTblLineInf.line_state) > 0)
		*pnLineStat = LINE_STATE_CONNECT;
	else
		*pnLineStat = LINE_STATE_DISCONNECT;
	return (0);
}
