#ifndef __BRIDGE_H
#define __BRIDGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <memory.h>
#include <signal.h>
#include <ctype.h>
#include <errno.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "TxnNum.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "CvtOpr.h"
#include "xmlstruct.h"

/* tbl_bank_bin_inf��¼��, ֻ�������п� */
#define CARD_INF_NUM_MAX		500
/* tbl_route_inf��¼�� */
#define ROUTE_INF_NUM_MAX		600

int BridgeInit (int argc, char **argv);
int CheckCard (char *sIpcIntBuf, char *sTxnNum);
int CardCompareTrack (char *sTrack, char *sCardId);
int GetRoute (char *sSrcSrvId, char *sTxnNum, char *sDestSrvId);
void HandleExit (int n);


#define SABEnvRuleN				"TL_BRIDGE_RULE_N"

#endif


