/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Bridge.c													 */
/* DESCRIPTIONS: The save and forward process server.                        */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/* 2005-04-06  Yu Tong        Changed for NCUP                               */
/* 2009-03-02  Li Xinxin	  Add Comment by Li								 */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Bridge/Bridge.c,v 1.2.2.2 2011/09/23 02:54:34 ctedev Exp $";

#include "Bridge.h"

char				gsSrvId[SRV_ID_LEN+1];
char				gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char				gsLogFile[LOG_NAME_LEN_MAX];
char				gsCheckCardFlag[2];

T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];
char				gsParamMsgCompressFlag[2];
int					gnCardInfNum;
Tbl_bank_bin_inf_Def    gatBankBinInf[CARD_INF_NUM_MAX];
int					gnRouteInfNum;
Tbl_route_inf_Def	gatRouteInf[ROUTE_INF_NUM_MAX];
Tbl_conv_type_Def 	gatConvType[CONV_TYPE_NUM_MAX];
T_UsageTransRuleDef gatUsageTransRule[CVT_USAGE_TRANS_RULE_NUM_MAX],gatUsageTransRule2[CVT_USAGE_TRANS_RULE_NUM_MAX];
stIpcDftRuleDef 	tIpcDftRule;
bciMBufChgInfDef	tBufChgRule;

/* del by lgm 20110328
AllXmlnodeBuf  sPARallxmlnodebuf;
del end */

int main(int argc, char **argv)
{
	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	char	sIntMsgBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	char	sSrcSrvId[SRV_ID_LEN+1];
	char	sToSrvId[SRV_ID_LEN+1];
	char	sTxnNum[FLD_TXN_NUM_LEN+1];
	char	sTmpLogFile[LOG_NAME_LEN_MAX];
	char	sTmpErrLogFile[LOG_NAME_LEN_MAX];
	char    sBufIn[1024+1];
	char    sBufOut[1024+1];
	
	int		nReturnCode;
	int 	nMsgInLen;
	int		nIntMsgLen;

	int		nMsgOutLen;
	int     nSavKey = 0;
	

	long    lBeginTime, lEndTime;
	struct tms  tTMS;
	
	
	strcpy(gsLogFile, "Bridge" );
	sprintf (sTmpLogFile, "%s.log", gsLogFile);
	if(argc < 3)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Usage:%s srvid seq\n", argv[0]);
		exit(-1);
	}

	nReturnCode = BridgeInit (argc, argv);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Bridge: BridgeInit error[%d]\n",nReturnCode);
		exit(-2);
	}

	if (sigset(SIGTERM, HandleExit) == SIG_ERR)
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d.", errno);

	HtLog (sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Bridge started.");

	lBeginTime = 0;
	lEndTime = 0;

	while (1)
	{
		sprintf (sTmpLogFile, "%s.log", gsLogFile);
		
		memset(sMsgInBuf,0,sizeof(sMsgInBuf));
		
		nMsgInLen = MSQ_MSG_SIZE_MAX;
		sigrelse (SIGTERM);
		nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, 
								&nMsgInLen, sMsgInBuf);
		sighold (SIGTERM);
		if (nReturnCode)
		{
			if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
			{
				HtLog( sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"MsqRcv error, %d.", nReturnCode);
				exit(-3);
			}
			else
				continue;
		}

		lBeginTime = times( &tTMS);

		memset (sSrcSrvId, 0, sizeof (sSrcSrvId));
		memcpy (sSrcSrvId, sMsgInBuf, SRV_ID_LEN);

		sprintf (sTmpLogFile, "%s.%s.log", gsLogFile, sSrcSrvId);

		HtLog( sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"received %d byte msg from %s.", nMsgInLen, sSrcSrvId);
		HtDebugString (sTmpLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
				sMsgInBuf, nMsgInLen);
		
		/* msg format convert */
		memset(sTxnNum, 0, sizeof(sTxnNum));
				
		nReturnCode = CvtOutToIn(gatConvType,
								gatUsageTransRule,
								&tIpcDftRule,
								&tBufChgRule,
								nMsgInLen,
								sMsgInBuf,
								&nMsgOutLen,
								sMsgOutBuf,
								sTxnNum);
		if (nReturnCode)
		{
			HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"CvtOutToIn error [%d]", nReturnCode);
			HtDebugString (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
				sMsgInBuf, nMsgInLen);
			sprintf (sTmpErrLogFile, "%s.%s.err.log", gsLogFile, sSrcSrvId);
			HtLog(sTmpErrLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"CvtOutToIn error [%d]", nReturnCode);
			HtDebugString(sTmpErrLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
				sMsgInBuf, nMsgInLen);
			continue;
		}
		HtLog( sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTxnNum [%s].", sTxnNum);		
		HtDebugString (sTmpLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
					sMsgOutBuf, nMsgOutLen);
		
		lEndTime = times(&tTMS);
		HtLog(sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__,
			"CvtOutToIn processed, used %ld ticks", lEndTime - lBeginTime);

		HtLog( sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTxnNum [%s].", sTxnNum);
		/* ͨ����bin���齻���� */	
		if (!strcmp(gsCheckCardFlag, FLAG_YES))
		{
		    HtLog( sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTxnNum [%s].", sTxnNum);
			nReturnCode = CheckCard(sMsgOutBuf, sTxnNum);
			if (nReturnCode)
			{
				HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"CheckCard error [%d]", nReturnCode);
			    continue;
			}
		}

		
		/* get route data */
		lBeginTime = times(&tTMS);
		memset(sToSrvId, 0, sizeof (sToSrvId));
		nReturnCode = GetRoute(sSrcSrvId, sTxnNum, sToSrvId);
		if (nReturnCode)
		{
			HtLog(sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"GetRoute select error, %d. msg src %s, txn num %s", 
				nReturnCode, sSrcSrvId, sTxnNum);
			continue;
		}
		lEndTime = times( &tTMS);
		HtLog(sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__,
			"GetRoute processed, used %ld ticks", lEndTime - lBeginTime);

        /* compress msg */
        if (!strcmp(gsParamMsgCompressFlag, FLAG_YES))
        {
            /* compress msg */
            /* sMsgOutBuf, nMsgOutLen -> sIntMsgBuf, nIntMsgLen */
            memset(sIntMsgBuf,0,sizeof(sIntMsgBuf));
            Compressbuf(sMsgOutBuf, nMsgOutLen, sIntMsgBuf, &nIntMsgLen);
            memset(sMsgOutBuf,0,sizeof(sMsgOutBuf));
            nMsgOutLen = nIntMsgLen;
            memcpy(sMsgOutBuf, sIntMsgBuf, nIntMsgLen);
        }
    				
		nReturnCode = MsqSnd(sToSrvId, gatSrvMsq, 0, nMsgOutLen, sMsgOutBuf);
		if (nReturnCode)
		{
			HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"MsqSnd to %s error, %d.", sToSrvId, nReturnCode);
			continue;
		}
		
		HtLog(sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"send msg to %s, msg src %s, txn num %s", 
				sToSrvId, sSrcSrvId, sTxnNum);
		lEndTime = times( &tTMS);
	}
}

/*****************************************************************************/
/* FUNC:   int BridgeInit (int argc, char **argv)                          */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �������ݿ�, ����ȫ�ֱ���, ��ȡ���в���,                           */
/*         ��ʼ����Ϣ����, �����ݿ��ȡת������������п�������·�ɱ�        */
/*****************************************************************************/
int BridgeInit (int argc, char **argv)
{
	char			sTmpLogFile[LOG_NAME_LEN_MAX];
	int				nReturnCode;
	Tbl_srv_inf_Def	tTblSrvInf;
	long			lUsageKey;
	/*
	char*  patUsageTransRule;
	*/

	/* get server id arg 1; server seq arg 2 */
	strcpy(gsSrvId, argv[1]);
	strcpy(gsSrvSeqId, argv[2]);
	
	/* get param, check card flag */
	if (getenv (BDG_CHECK_CARD_FLAG))
		strcpy(gsCheckCardFlag, getenv (BDG_CHECK_CARD_FLAG)); 
	else
		strcpy (gsCheckCardFlag, FLAG_NO);
	/* get param, compress flag */
	if (getenv (MSG_COMPRESS_FLAG))
		strcpy(gsParamMsgCompressFlag, getenv (MSG_COMPRESS_FLAG)); 
	else
		strcpy (gsParamMsgCompressFlag, FLAG_NO);
	
	/* connect to database */
    nReturnCode = DbsConnect ();
	if (nReturnCode)
		return (nReturnCode);
	
	/* get log file name from tbl_srv_inf */
	if (getenv(SRV_USAGE_KEY))
		lUsageKey=atoi (getenv(SRV_USAGE_KEY));
	else
	{
		DbsDisconnect ();
		return -1;
	}
	memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
	tTblSrvInf.usage_key = lUsageKey;
	memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);

        HtLog ("var111.log", 1, __FILE__,__LINE__, "usage_key %d, srvid %s", tTblSrvInf.usage_key, tTblSrvInf.srv_id);

	nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
	if (nReturnCode)
	{
		DbsDisconnect ();
		return (nReturnCode);
	}

	CommonRTrim(tTblSrvInf.srv_name);
	sprintf (gsLogFile, "%s.%s", tTblSrvInf.srv_name, gsSrvSeqId);
	sprintf (sTmpLogFile, "%s.log", gsLogFile);
	/*get log file name end*/
		
	/*initial message queue and related message queue*/
	HtLog (sTmpLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "MsqInit begin ." );	  
	memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
	nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d.", nReturnCode);	  
		DbsDisconnect ();
		return (nReturnCode);
	}
	
	/* init ISO8583 convert rule */
	memset ((char *)gatConvType, 0, sizeof (gatConvType));
	memset ((char *)gatUsageTransRule, 0, sizeof (gatUsageTransRule));
	nReturnCode = CvtInit (gatConvType, gatUsageTransRule);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CvtInit error, %d.", nReturnCode);	  
		DbsDisconnect ();
		return (nReturnCode);
	
	}
  	/*add by xu zhen*/  
  	/*
	nReturnCode=shmget(1000,sizeof (gatUsageTransRule),0660|IPC_CREAT);
	if(nReturnCode<0) 
	    HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "shmget, %d.", nReturnCode);	  
	patUsageTransRule=shmat(nReturnCode,0,0);
	memcpy(patUsageTransRule,(char *)gatUsageTransRule,sizeof (gatUsageTransRule));
	memcpy((char *)gatUsageTransRule2,patUsageTransRule,sizeof (gatUsageTransRule));
  	*/
		
	/*end*/
	memset(&tBufChgRule,0,sizeof(bciMBufChgInfDef));
	nReturnCode = BufChgLoad(1,&tBufChgRule);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "BufChgLoad error, %d.", nReturnCode);	  
		DbsDisconnect ();
		return (nReturnCode);
	}

	memset(&tIpcDftRule,0,sizeof(stIpcDftRuleDef));
    nReturnCode = IpcDftLoad(1,&tIpcDftRule);
    if (nReturnCode)
    {
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "IpcDftLoad error, %d.", nReturnCode);	  
		DbsDisconnect ();
		return (nReturnCode);
    }

	/* init route inf data */
	memset ((char *)gatRouteInf, 0, sizeof (gatRouteInf));
	gnRouteInfNum = ROUTE_INF_NUM_MAX;
	nReturnCode = DbsRouteInfLoad (&gnRouteInfNum, gatRouteInf);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"DbsRouteInfLoad error, %d.", nReturnCode);	  
		DbsDisconnect ();
		return (nReturnCode);
	}

#if 0 /* XML��أ�ȥ�� del by lgm 20110328 */
	/* init XML inf data add by tangbin begin*/
    memset(&sPARallxmlnodebuf,0,sizeof(AllXmlnodeBuf));
    HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "xmlIpcDftLoad ");
    nReturnCode = BribdgexmlInit(1,&sPARallxmlnodebuf);
    if (nReturnCode)
    {
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "xmlIpcDftLoad error, %d.", nReturnCode);
		DbsDisconnect ();
		return (nReturnCode);
    }
    /*init XML inf data add by tangbin end*/
#endif /* del end */
	
	
	/* init card inf data 	*/
	memset ((char *)gatBankBinInf, 0, sizeof (gatBankBinInf));
    gnCardInfNum = CARD_INF_NUM_MAX;
    HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsBankBinInfLoad");
    nReturnCode = DbsBankBinInfLoad (&gnCardInfNum, gatBankBinInf);
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"DbsBankBinInfLoad error, %d.", nReturnCode);	  
		DbsDisconnect ();
		return (nReturnCode);
	}
	
	/* disconnect db */
	nReturnCode = DbsDisconnect ();
	if (nReturnCode)
	{
		HtLog (sTmpLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"DbsDisconnect error, %d.", nReturnCode);	  
	}

	return (0);
}

/*****************************************************************************/
/* FUNC:   int CheckCard (char *sIpcIntBuf, char *sTxnNum)                   */
/* INPUT:  sIpcIntBuf: ����������Ϣ, ��ʽ���ڲ���IPC�ṹ                     */
/*         sTxnNum: ���״���                                                 */
/* OUTPUT: sIpcIntBuf: ��Ϣ�еĽ��״�����ܱ��޸�                            */
/*         sTxnNum: �޸ĺ�Ľ��״���, ������޸�, ����ԭֵ                   */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �Ա���������, ���ݿ�������Ƿ��Ǳ��п�,                           */
/*         �Ա��п�����, �޸Ľ��״���                                        */
/*****************************************************************************/
int CheckCard (char *sIpcIntBuf, char *sTxnNum)
{
	int         i,iBinIndex;
	int         a,b;
	T_IpcIntTxnDef	tIpcIntTxn;
	
	if (sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_MANAGE)
		return 0;
	
	memcpy ((char *)&tIpcIntTxn, sIpcIntBuf, sizeof (tIpcIntTxn));
	HtLog ("Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,"first sTxnNum [%s]", sTxnNum);
	
	/* ������ - Ĭ��Ϊ�ո� */
	memcpy(tIpcIntTxn.sOpenInst+4, "  ", 2);
	
	/* ������Ӧ�������÷���籣�Ľ��ף�����F032�ж���������Ӧ�𣬻��Ǳ�����Ӧ�� */
	if(!memcmp(sTxnNum, "1306", 4) ||
	    !memcmp(sTxnNum, "1316", 4) ||
	    !memcmp(sTxnNum, "2316", 4) ||
	    !memcmp(sTxnNum, "3316", 4) ||
	    !memcmp(sTxnNum, "4316", 4))
	{
	    if(memcmp(tIpcIntTxn.sAcqInstIdCode, "0306", 4) != 0)
	    {
	        sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_TDB_RSP;
            tIpcIntTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_TDB_RSP;
	    }
	}
	
	/* ���������ף��������ֽ��ֵ -> 1375  �������ֽ��ֵ���� -> 2375  */
	if(sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ)
	{
	    if(memcmp(sTxnNum, "1945", 4) ==0)
	    {
	        memcpy(sTxnNum, "1375", 4);
	        memcpy(tIpcIntTxn.sTxnNum, "1375", 4);
	    }
	    
	    if(memcmp(sTxnNum, "2945", 4) ==0)
	    {
	        memcpy(sTxnNum, "2375", 4);
	        memcpy(tIpcIntTxn.sTxnNum, "2375", 4);
	    }
	    
	    iBinIndex = CardCompareCarno (tIpcIntTxn.sPrimaryAcctNum);
	    if (iBinIndex >= 0)
	    {
	        /* ������ - �����ֽ��÷���籣 */
	        memcpy(tIpcIntTxn.sOpenInst+4, gatBankBinInf[iBinIndex].card_tp, 2);
	    }   
	}
	
	/* ����������ʹ�ñ����������룬�жϿ�������Ǳ��п������¸�ֵ������
	    ·�ɵ�����ͳһ���롢���ÿ��������ֽ𿨡�÷���籣��������ϵͳ */
	if((sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_REQ)  &&
	    memcmp(tIpcIntTxn.sProcessingCode, "40", 2) != 0)
	{
        
        iBinIndex = CardCompareCarno (tIpcIntTxn.sPrimaryAcctNum);
        
        if (iBinIndex >= 0)
	    {
	        /* card issued from this bank */
	        if(memcmp(gatBankBinInf[iBinIndex].card_tp, "01", 2) == 0)
	        {
	            sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_BDB_REQ;
	            tIpcIntTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_BDB_REQ;
	        }
	        
	        /* ���������ÿ� */
            if(memcmp(gatBankBinInf[iBinIndex].card_tp, "00", 2) == 0 ||
                memcmp(gatBankBinInf[iBinIndex].card_tp, "02", 2) == 0)
            {
	            /* ���ڽ��� */
	            if(memcmp(tIpcIntTxn.sPosCondCode, "64", F025_LEN) == 0)
	            {
	                if(memcmp(sTxnNum, "1101", 4) == 0)
                    {
	                    memcpy(sTxnNum, "1117", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "1117", 4);
	                }
	                else if(memcmp(sTxnNum, "2101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "2117", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "2117", 4);
	                }
	                else if(memcmp(sTxnNum, "3101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "3117", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "3117", 4);
	                }
	                else if(memcmp(sTxnNum, "4101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "4117", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "4117", 4);
	                }
	                else if(memcmp(sTxnNum, "5151", 4) == 0)
	                {
	                    memcpy(sTxnNum, "5117", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "5117", 4);
	                }
	                else
	                {
	                    HtLog( "Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	                        "Not Support txn, TxnNum[%s] , CardType[%s], AcctNo[%-19.19s], discard this msg. ", 
	                        sTxnNum, gatBankBinInf[iBinIndex].card_tp, tIpcIntTxn.sPrimaryAcctNum);
	                    /*return -99;*/
	                    memcpy(tIpcIntTxn.sMAC064, "-99", 3);
	                }
	            }
	            else if(memcmp(tIpcIntTxn.sPosCondCode, "65", F025_LEN) == 0)
	            {
	                if(memcmp(sTxnNum, "1201", 4) == 0)
	                {
	                    memcpy(sTxnNum, "1805", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "1805", 4);
	                }
	                else if(memcmp(sTxnNum, "1101", 4) == 0)
                    {
	                    memcpy(sTxnNum, "1815", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "1815", 4);
	                }
	                else if(memcmp(sTxnNum, "2101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "2815", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "2815", 4);
	                }
	                else if(memcmp(sTxnNum, "3101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "3815", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "3815", 4);
	                }
	                else if(memcmp(sTxnNum, "4101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "4815", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "4815", 4);
	                }
	                else if(memcmp(sTxnNum, "5151", 4) == 0)
	                {
	                    memcpy(sTxnNum, "5835", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "5835", 4);
	                }
	                else
	                {
	                    HtLog( "Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	                        "Not Support txn, TxnNum[%s] , CardType[%s], AcctNo[%-19.19s], discard this msg. ", 
	                        sTxnNum, gatBankBinInf[iBinIndex].card_tp, tIpcIntTxn.sPrimaryAcctNum);
	                    /*return -99;*/
	                    memcpy(tIpcIntTxn.sMAC064, "-99", 3);
	                }
	            }
	            else if(memcmp(tIpcIntTxn.sPosCondCode, "66", F025_LEN) == 0)
	            {
	                if(memcmp(sTxnNum, "1101", 4) == 0)
                    {
	                    memcpy(sTxnNum, "1825", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "1825", 4);
	                }
	                else if(memcmp(sTxnNum, "2101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "2825", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "2825", 4);
	                }
	                else if(memcmp(sTxnNum, "3101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "3825", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "3825", 4);
	                }
	                else if(memcmp(sTxnNum, "4101", 4) == 0)
	                {
	                    memcpy(sTxnNum, "4825", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "4825", 4);
	                }
	                else if(memcmp(sTxnNum, "5151", 4) == 0)
	                {
	                    memcpy(sTxnNum, "5845", 4);
	                    memcpy(tIpcIntTxn.sTxnNum, "5845", 4);
	                }
	                else
	                {
	                    HtLog( "Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	                        "Not Support txn, TxnNum[%s] , CardType[%s], AcctNo[%-19.19s], discard this msg. ", 
	                        sTxnNum, gatBankBinInf[iBinIndex].card_tp, tIpcIntTxn.sPrimaryAcctNum);
	                    /*return -99;*/
	                    memcpy(tIpcIntTxn.sMAC064, "-99", 3);
	                }
	            }
	            else
	            {
	                sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_CBDB_REQ;
	                tIpcIntTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_CBDB_REQ;
	            }
            }
            
            /* �����������ֽ� */
            if(memcmp(gatBankBinInf[iBinIndex].card_tp, "03", 2) == 0)
            {
                if(memcmp(sTxnNum, "120", 3) == 0)
                {
	                memcpy(sTxnNum, "1255", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "1255", 4);
	            }
	            else if(memcmp(sTxnNum, "110", 3) == 0)
                {
	                memcpy(sTxnNum, "1365", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "1365", 4);
	            }
	            else if(memcmp(sTxnNum, "210", 3) == 0)
                {
	                memcpy(sTxnNum, "2365", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "2365", 4);
	            }
	            else if(memcmp(sTxnNum, "310", 3) == 0)
                {
	                memcpy(sTxnNum, "3365", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "3365", 4);
	            }
	            else if(memcmp(sTxnNum, "410", 3) == 0)
                {
	                memcpy(sTxnNum, "4365", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "4365", 4);
	            }
	            else if(memcmp(sTxnNum, "515", 3) == 0)
                {
	                memcpy(sTxnNum, "5365", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "5365", 4);
	            }
	            else
	            {
	                sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_BDB_REQ;
	                tIpcIntTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] = TXN_NUM_BDB_REQ;
	            }
	                
            }
            
            /* ������÷���籣�� */
            if(memcmp(gatBankBinInf[iBinIndex].card_tp, "04", 2) == 0)
            {
                if(memcmp(sTxnNum, "120", 3) == 0)
                {
	                memcpy(sTxnNum, "1305", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "1305", 4);
	            }
	            else if(memcmp(sTxnNum, "110", 3) == 0)
                {
	                memcpy(sTxnNum, "1315", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "1315", 4);
	            }
	            else if(memcmp(sTxnNum, "210", 3) == 0)
                {
	                memcpy(sTxnNum, "2315", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "2315", 4);
	            }
	            else if(memcmp(sTxnNum, "310", 3) == 0)
                {
	                memcpy(sTxnNum, "3315", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "3315", 4);
	            }
	            else if(memcmp(sTxnNum, "410", 3) == 0)
                {
	                memcpy(sTxnNum, "4315", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "4315", 4);
	            }
	            else
	            {
	                HtLog( "Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	                "Not Support txn, TxnNum[%s] , CardType[%s], AcctNo[%-19.19s], discard this msg. ", 
	                sTxnNum, gatBankBinInf[iBinIndex].card_tp, tIpcIntTxn.sPrimaryAcctNum);
	                /*return -99;*/
	                memcpy(tIpcIntTxn.sMAC064, "-99", 3);
	            }
	                
            }
            
            /* ������ */
            memcpy(tIpcIntTxn.sOpenInst+4, gatBankBinInf[iBinIndex].card_tp, 2);
	        HtLog ("Bridge.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"sTxnNum [%s]", sTxnNum);
	    }
    }
    
    /* �����������жϿ�������Ǵ�ֵ�������¸�ֵ�����룬·�ɵ���ֵ��ϵͳ */
    if(sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
    {
        iBinIndex = CardCompareCarno (tIpcIntTxn.sPrimaryAcctNum);
		
        if (iBinIndex >= 0)
	    {
	        /* card issued from this bank */
	        if(memcmp(gatBankBinInf[iBinIndex].card_tp, "01", 2) == 0)
	        {
	            /* ��ǿ���POS���ף���֧��Ԥ��Ȩ��Ԥ��Ȩ�������� */
	            if(!memcmp(sTxnNum, "1013", 4) ||
	                !memcmp(sTxnNum, "2013", 4) ||
	                !memcmp(sTxnNum, "3013", 4) ||
	                !memcmp(sTxnNum, "4013", 4) ||
	                !memcmp(sTxnNum, "1093", 4) ||
	                !memcmp(sTxnNum, "2093", 4) ||
	                !memcmp(sTxnNum, "3093", 4) ||
	                !memcmp(sTxnNum, "4093", 4))
	            {
	                HtLog( "Bridge.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 
	                "Not Support txn, TxnNum[%s] , CardType[%s], AcctNo[%-19.19s].", 
	                sTxnNum, gatBankBinInf[iBinIndex].card_tp, tIpcIntTxn.sPrimaryAcctNum);
	                /* һ�ڶԲ�֧�ֵĽ��ף������������ */
	                /*memcpy(tIpcIntTxn.sMisc+69,"Y",1);
					memcpy(tIpcIntTxn.sRespCode,F039_NOT_SUPPORT,2);
					memcpy (sIpcIntBuf, (char *)&tIpcIntTxn, sizeof (tIpcIntTxn));*/
	                /*return -1;*/
	            }
	        }
	        /* �����������ֽ��� */
            else if(memcmp(gatBankBinInf[iBinIndex].card_tp, "03", 2) == 0)
            {
                if(memcmp(sTxnNum, "120", 3) == 0)
                {
	                memcpy(sTxnNum, "1253", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "1253", 4);
	            }
	            else if(memcmp(sTxnNum, "110", 3) == 0)
                {
	                memcpy(sTxnNum, "1363", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "1363", 4);
	            }
	            else if(memcmp(sTxnNum, "210", 3) == 0)
                {
	                memcpy(sTxnNum, "2363", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "2363", 4);
	            }
	            else if(memcmp(sTxnNum, "310", 3) == 0)
                {
	                memcpy(sTxnNum, "3363", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "3363", 4);
	            }
	            else if(memcmp(sTxnNum, "410", 3) == 0)
                {
	                memcpy(sTxnNum, "4363", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "4363", 4);
	            }
	            else if(memcmp(sTxnNum, "515", 3) == 0)
                {
	                memcpy(sTxnNum, "5363", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "5363", 4);
	            }
	            else if(memcmp(sTxnNum, "1373", 4) == 0 ||
	                memcmp(sTxnNum, "2373", 4) == 0 ||
	                memcmp(sTxnNum, "1383", 4) == 0 ||
	                memcmp(sTxnNum, "2383", 4) == 0 ||
	                memcmp(sTxnNum, "1393", 4) == 0 ||
	                memcmp(sTxnNum, "2393", 4) == 0)
                {
	            }
	            else
	            {
	                HtLog( "Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	                "Not Support txn, TxnNum[%s] , CardType[%s], AcctNo[%-19.19s], ", 
	                sTxnNum, gatBankBinInf[iBinIndex].card_tp, tIpcIntTxn.sPrimaryAcctNum);
	                /* ��֧�ֵĵ����ֽ��ཻ�ף�discard */
	                /*memcpy(tIpcIntTxn.sMisc+69,"Y",1);
					memcpy(tIpcIntTxn.sRespCode,F039_NOT_SUPPORT,2);
					memcpy (sIpcIntBuf, (char *)&tIpcIntTxn, sizeof (tIpcIntTxn));*/
	                /*return -99;*/
	                memcpy(tIpcIntTxn.sMAC064, "-99", 3);
	            }
            }
            /* ������÷���籣���� */
            else if(memcmp(gatBankBinInf[iBinIndex].card_tp, "04", 2) == 0)
            {
                if(memcmp(sTxnNum, "120", 3) == 0)
                {
	                memcpy(sTxnNum, "1303", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "1303", 4);
	            }
	            else if(memcmp(sTxnNum, "110", 3) == 0)
                {
	                memcpy(sTxnNum, "1313", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "1313", 4);
	            }
	            else if(memcmp(sTxnNum, "210", 3) == 0)
                {
	                memcpy(sTxnNum, "2313", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "2313", 4);
	            }
	            else if(memcmp(sTxnNum, "310", 3) == 0)
                {
	                memcpy(sTxnNum, "3313", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "3313", 4);
	            }
	            else if(memcmp(sTxnNum, "410", 3) == 0)
                {
	                memcpy(sTxnNum, "4313", 4);
	                memcpy(tIpcIntTxn.sTxnNum, "4313", 4);
	            }
	            else
	            {
	                HtLog( "Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	                "Not Support txn, TxnNum[%s] , CardType[%s], AcctNo[%-19.19s], discard this txn.", 
	                sTxnNum, gatBankBinInf[iBinIndex].card_tp, tIpcIntTxn.sPrimaryAcctNum);
	                /* ��֧�ֵ�÷���籣���ף�discard */
	                /*memcpy(tIpcIntTxn.sMisc+69,"Y",1);
					memcpy(tIpcIntTxn.sRespCode,F039_NOT_SUPPORT,2);
					memcpy (sIpcIntBuf, (char *)&tIpcIntTxn, sizeof (tIpcIntTxn));*/
	                /*return -99;*/
	                memcpy(tIpcIntTxn.sMAC064, "-99", 3);
	            }
            }
            
            /* ������ */
            memcpy(tIpcIntTxn.sOpenInst+4, gatBankBinInf[iBinIndex].card_tp, 2);
	    }
	    else
	    {
	        HtLog( "Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
	        "û�д˿� error, TxnNum[%s] , AcctNo[%-19.19s]", 
	        sTxnNum, tIpcIntTxn.sPrimaryAcctNum);
	        /* һ�ڶԲ�֧�ֵĽ��ף������������ */
	        /*memcpy(tIpcIntTxn.sMisc+69,"Y",1);
			memcpy(tIpcIntTxn.sRespCode,F039_NOT_SUPPORT,2);
			memcpy (sIpcIntBuf, (char *)&tIpcIntTxn, sizeof (tIpcIntTxn));*/
	        /*return -1;*/
	    }
    }
	
	memcpy (sIpcIntBuf, (char *)&tIpcIntTxn, sizeof (tIpcIntTxn));
    HtLog ("Bridge.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sTxnNum [%s]", sTxnNum);
    return 0;
}

/*****************************************************************************/
/* FUNC:   int CardCompareTrack (char *sTrack, char *sCardId)                */
/* INPUT:  sTrack: 2��3�ŵ�����                                              */
/*         sCardId: ��ʶ����                                                 */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �뿨ʶ����һ��, -1: �뿨ʶ���벻һ��                           */
/* DESC:   �Ƚϴŵ������뿨ʶ�����Ƿ���ͬ                                    */
/*****************************************************************************/
int CardCompareTrack (char *sTrack, char *sCardId)
{
    int i=0;

	while (sCardId[i] == ' ' || (isdigit (sCardId[i]) && sTrack[i] == sCardId[i]))
		i++;

	if (isdigit(sCardId[i])) 
		return -1;
	else
		return 0;
}

/*****************************************************************************/
/* FUNC:   int GetRoute (char *sSrcSrvId, char *sTxnNum, char *sDestSrvId)   */
/* INPUT:  sSrcSrvId: ��Ϣ��Դserver id                                      */
/*         sTxnNum: ������                                                   */
/* OUTPUT: sDestSrvId: ��������Ϣ��server id                                 */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ������Ϣ��Դ�ͽ�������Ҵ�������Ϣ��server id                     */
/*****************************************************************************/
int GetRoute (char *sSrcSrvId, char *sTxnNum, char *sDestSrvId)
{
	int				i;
	
	for (i = 0; i < gnRouteInfNum; i++)
	{
		if (!memcmp (gatRouteInf[i].txn_num, sTxnNum, FLD_TXN_NUM_LEN ))
		{
			memcpy (sDestSrvId, gatRouteInf[i].msg_to_id, SRV_ID_LEN);
			break;
		}
	}
	
	if (i == gnRouteInfNum)	
	{
		return ERR_CODE_BRD_NO_ROUTE;
	}
	
	return 0;
}

void HandleExit (int n)
{
	char	sTmpLogFile[LOG_NAME_LEN_MAX];
	
	sprintf (sTmpLogFile, "%s.log", gsLogFile);
	HtLog(	sTmpLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Bridge exits.");
	exit( 1 );
}



/*****************************************************************************/
/* FUNC:   int CardCompareCarno (char *carno)                                */
/* INPUT:  carno: ���׿���                                                   */
/* OUTPUT: ��                                                                */
/* RETURN: i: ��bin���ڱ���¼����, -1: �Ǳ��п�                              */
/* DESC:   �ȽϿ���ǰ��λ�Ƿ����ڱ��п�bin                                   */
/*****************************************************************************/
int CardCompareCarno (char *carno)
{
    int     i=0;
    char    sBinLen[3], sCardBin[15];
		
    for(i=0; i<gnCardInfNum; i++)
    {
        memset(sBinLen, 0, sizeof(sBinLen));
        /*memset(sCardBin, 0, sizeof(sCardBin));*/
        memcpy(sBinLen, gatBankBinInf[i].bin_len, 2);
        /*memcpy(sCardBin, carno, atoi(sBinLen));*/
        
        if (memcmp(carno, gatBankBinInf[i].bin_sta_no, atoi(sBinLen)) >= 0 &&
            memcmp(carno, gatBankBinInf[i].bin_end_no, atoi(sBinLen)) <= 0)
        {
            return i;
        }   
    }
    
    return -1;
}
