/*****************************************************************************/

/*                NCUP -- Shanghai Huateng Software System Inc.              */

/*****************************************************************************/

/* PROGRAM NAME: CvtCust.c                                                   */

/* DESCRIPTIONS: message format convert between internal ipc and host msg    */

/*****************************************************************************/

/*                             MODIFICATION LOG                              */

/* DATE        PROGRAMMER     DESCRIPTION                                    */

/* 2005-04-19  YU TONG        Initialize                                     */

/*****************************************************************************/

static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/BPCust/CvtCust.c,v 1.1.1.1.4.1 2011/09/23 02:54:34 ctedev Exp $";

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <memory.h>

#include <math.h>



#include "IpcInt.h"

#include "TxnNum.h"

#include "SrvDef.h"

#include "BufChg.h"

#include "DbsDef.h"





extern char gsLogFile[LOG_NAME_LEN_MAX];

extern GFHEADER_CFG GFHeaderCfg_CC;

extern GFHEADER_CFG GFHeaderCfg_ZK;



int CvtCustOutToIn (stIpcDftRuleDef *ptIpcDftRule, bciMBufChgInfDef *ptBufChgRule, int nSrcMsgLen, char *sSrcMsgBuf, int *pnDestMsgLen, char *sDestMsgBuf, char *sTxnNum)

{
	/*����SWTBONES����Ҫ�õ�*/
	return 0;
}



int CvtCustInToOut(stIpcDftRuleDef *ptIpcDftRule, bciMBufChgInfDef *ptBufChgRule, int nSrcMsgLen, char *sSrcMsgBuf, int *pnDestMsgLen, char *sDestMsgBuf)
{
	/*����SWTBONES����Ҫ�õ�*/
	return 0;
}


