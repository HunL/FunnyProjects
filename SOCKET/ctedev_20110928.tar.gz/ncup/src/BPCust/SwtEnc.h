#ifndef _ENC_H

#include "SrvParam.h"

#define NETWORK_MNG_CD_POS 8
#define MNG_DES_FLAG       "001"
#define MNG_3DES_FLAG      "003"
#define MAX_MAC_ELEMENT_LEN    256 	
#define MAX_MAC_ELEMENT_LEN_LEN   3


#define MAC_LEN              8
#define MAC_EXPAND_LEN       16
#define CHK_VALUE_LEN        4
#define CHK_EXPAND_VALUE_LEN 8 

int istruealnum(char c);
long numin(char * str, short len);
void numout(char * str, short len, long num);
#endif
