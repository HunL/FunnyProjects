#ifndef __SWT_CUST_H
#define __SWT_CUST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <errno.h>
#include <sys/msg.h>
#include <sys/times.h>
#include <time.h>
#include <math.h>

#include "SrvDef.h"
#include "TxnNum.h"
#include "IpcInt.h"
#include "BPIpcInt.h"
#include "Common.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "CstDbsTbl.h"
#include "HtLog.h"
#include "SrvParam.h"
#include "ErrCode.h"
#include "EncOpr.h"
#include "MsqOpr.h"
#include "LineStat.h"
#include "db.h"
#include "unionAPI.h"

#define MSG_SRC_ID_ANY      "9999"
#define    CST_BANK_TLR_NUM     10000

T_InstTxnParamVal InstTxnParamVal;


#endif
