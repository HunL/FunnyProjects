/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: SwtCommon.c                                                 */
/* DESCRIPTIONS: handle normal req from CUP and its rsp from host            */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-14  YU TONG        Initialize                                     */
/*****************************************************************************/
static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/BPCust/SwtCommon.c,v 1.2.4.1 2011/09/23 02:54:34 ctedev Exp $";

#include "SwtCommon.h"

/*****************************************************************************/
/* FUNC:   double DecRound(double value,int dot)                             */
/* INPUT:  value: Ҫ����ת����˫���ȸ�������                                 */
/*         dot	: ��������Ҫ������λ��                                       */
/* OUTPUT: NULL                                                              */
/* RETURN: �ɹ���ת���������                                                */
/* DESC	 : ��������ת������                                                  */
/*****************************************************************************/

double DecRound(double value,int dot)
{
	char ss[40],ss1[40];
	double aa;

	sprintf(ss1,"%s%dlf","%.",dot);	
	if(value>=0) /* ���C���Ե������������� */
	    aa=value+0.00000001;
	else
	    aa=value-0.00000001;
	sprintf(ss,ss1,aa);	
	aa=atof(ss);	
	return aa;
}

int InitTblTxn (Tbl_bonus_txn_Def *ptTxn)
{
	/* init ptTxn to all 0x00,
	   set revsal_flag, cancel_flag to '-', batch_flag to FLAG_NO_C
	   set revsal_ssn, cancel_ssn, batch_date, misc_2 to all 0x00 */
	memset ((char *)ptTxn, 0, sizeof (*ptTxn));

	memcpy (ptTxn->trans_state,    TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN);
	memset (ptTxn->revsal_flag      , REV_CAN_FLAG_NULL, 1);
	memset (ptTxn->cancel_flag      , REV_CAN_FLAG_NULL, 1);
	memset (ptTxn->amt_return       , '0', sizeof (ptTxn->amt_return)-1 );

	/* set inst_date, inst_time to current db date time */
	memcpy (ptTxn->inst_date        , gsTimeCurTs, 8);
	memcpy (ptTxn->inst_time        , gsTimeCurTs+8, 6);

	return 0;
}


/*****************************************************************************/
/* FUNC:   int MoveIpc2Txn (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptTxn )*/
/* INPUT:  ptIpcIntTxn: ������, ��ʽ���ڲ���IPC�ṹ                        */
/* OUTPUT: ptTxn: ��Ӧ��tbl_bonus_txn�ļ�¼                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ptIpcIntTxn������дptTxn                                        */
/*****************************************************************************/
int MoveIpc2Txn (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptTxn )
{
	char    sFuncName[] = "MoveIpc2Txn";
	char    *Track2P;
	int        nReturnCode;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDB_REQ:
			InitTblTxn (ptTxn);

            /***********************************************************
            * set misc_2 time add by tangb for double Machine ToCtl->Tom
            *************************************************************/
            if (gnTimeOutFlag)
                sprintf(ptTxn->tom_flag_1, "%1.1d%1.1d", 1 , atoi(getenv(SRV_USAGE_KEY)));
            else
                sprintf(ptTxn->tom_flag_1, "%1.1d%1.1d", 0 ,atoi(getenv(SRV_USAGE_KEY)));
            memcpy (ptTxn->tom_flag_2        , gsTimeOutTs    , 26);
            HtLog ("lgm.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "gsTimeOutTs[%26.26s].", gsTimeOutTs);

    
			/* ����revsal_flag, cancel_flag��ʼֵ */
			switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
			{
				case TXN_NUM_NORMAL:
				case TXN_NUM_CANCEL:
					memset (ptTxn->revsal_flag      , REV_CAN_FLAG_NORMAL, 1);
					memset (ptTxn->cancel_flag      , REV_CAN_FLAG_NORMAL, 1);
					break;
				case TXN_NUM_REVSAL:
				case TXN_NUM_CANCEL_REVSAL:
				case TXN_NUM_NOTICE:
					break;
			}

			if (ptIpcIntTxn->sTransChnl[0] == ' ')
			    memcpy (ptTxn->trans_chnl, "POS ", FLD_TRANS_CHNL_LEN);
			else
				memcpy (ptTxn->trans_chnl, ptIpcIntTxn->sTransChnl, FLD_TRANS_CHNL_LEN);

			memcpy (ptTxn->sys_seq_num      , ptIpcIntTxn->sSysSeqNum            , F011_LEN);
			memcpy (ptTxn->msg_src_id       , ptIpcIntTxn->sMsgSrcId            , SRV_ID_LEN);
			memcpy (ptTxn->txn_num          , ptIpcIntTxn->sTxnNum                , FLD_TXN_NUM_LEN);
			memcpy (ptTxn->trans_code       , ptIpcIntTxn->sTransCode            , FLD_TXN_CODE_LEN);

			memcpy (ptTxn->key_rsp            , ptIpcIntTxn->sKeyRsp                , KEY_RSP_LEN);
			memcpy (ptTxn->key_revsal        , ptIpcIntTxn->sKeyRevsal            , KEY_REVSAL_LEN);
			memcpy (ptTxn->key_cancel        , ptIpcIntTxn->sKeyCancel            , KEY_CANCEL_LEN);

            if(memcmp(ptIpcIntTxn->sMsgSrcId, "1801", 4) == 0 ||
                memcmp(ptIpcIntTxn->sMsgSrcId, "1802", 4) == 0)
            {
                memcpy (ptIpcIntTxn->sFwTransDate, ptIpcIntTxn->sSwitchingData, 4);
                memcpy (ptIpcIntTxn->sFwTransDate+4, ptIpcIntTxn->sTransmsnDateTime, 4);
                
                memcpy (ptIpcIntTxn->sFwTransTime, ptIpcIntTxn->sTransmsnDateTime+4, FLD_FW_TRANS_TIME_LEN);
                
                memset (ptIpcIntTxn->sFwTransSsn, '0', 16);
                memcpy (ptIpcIntTxn->sFwTransSsn+16, ptIpcIntTxn->sSysTraceAuditNum, 6);
            }
			memcpy (ptTxn->fw_trans_date         , ptIpcIntTxn->sFwTransDate                , FLD_FW_TRANS_DATE_LEN);
			memcpy (ptTxn->fw_trans_time         , ptIpcIntTxn->sFwTransTime                , FLD_FW_TRANS_TIME_LEN);
			memcpy (ptTxn->fw_trans_ssn         , ptIpcIntTxn->sFwTransSsn                , FLD_FW_TRANS_SSN_LEN);
			
			memcpy (ptTxn->mid_time         , ptIpcIntTxn->sMidTime                , FLD_MID_TIME_LEN);
			memcpy (ptTxn->mid_ssn         , ptIpcIntTxn->sMidSsn                , FLD_MID_SSN_LEN);
			memcpy (ptTxn->mid_tag         , ptIpcIntTxn->sMidTag                , FLD_MID_TAG_LEN);
			
			memcpy (ptTxn->bp_header       , ptIpcIntTxn->sBpHeader            , FLD_BP_HEADER);
			
			if (ptIpcIntTxn->sMsgType[0] != ' ')
			    memcpy (ptTxn->msg_type         , ptIpcIntTxn->sMsgType                , F000_MSG_TYPE_LEN);
			else
			    memset (ptTxn->msg_type    , ' ', F000_MSG_TYPE_LEN);
			    
			if (ptIpcIntTxn->cF002Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->pan_len          , ptIpcIntTxn->sPrimaryAcctNumLen    , F002_LEN_LEN);
				memcpy (ptTxn->pan              , ptIpcIntTxn->sPrimaryAcctNum        , F002_VAL_LEN);
			}
			else
			{
				memset (ptTxn->pan_len          , ' ', F002_LEN_LEN);
				memset (ptTxn->pan              , ' ', F002_VAL_LEN);
			}
			
			memcpy (ptTxn->processing_code  , ptIpcIntTxn->sProcessingCode        , F003_LEN);
			memcpy (ptTxn->amt_trans        , ptIpcIntTxn->sAmtTrans            , F004_LEN);
			memcpy (ptTxn->trans_date_time  , ptIpcIntTxn->sTransmsnDateTime    , F007_LEN);
			/*memcpy (ptTxn->cup_ssn          , ptIpcIntTxn->sSysTraceAuditNum    , F011_LEN);*/
			memcpy (ptTxn->time_local_trans , ptIpcIntTxn->sTimeLocalTrans        , F012_LEN);
			memcpy (ptTxn->date_local_trans , ptIpcIntTxn->sDateLocalTrans        , F013_LEN);
			
		 	memcpy (ptTxn->date_settlmt     , ptIpcIntTxn->sDateSettlmt            , F015_LEN);
			memcpy (ptTxn->mchnt_type       , ptIpcIntTxn->sMchntType            , F018_LEN);
			memcpy (ptTxn->pos_entry_mode   , ptIpcIntTxn->sPosEntryModeCode    , F022_LEN);
			memcpy (ptTxn->pos_cond_code    , ptIpcIntTxn->sPosCondCode            , F025_LEN);
			if (ptIpcIntTxn->cF026Ind == FLAG_YES_C)
				memcpy (ptTxn->pos_pin_cap_code , ptIpcIntTxn->sPosPinCaptrCode        , F026_LEN);
			else
				memset (ptTxn->pos_pin_cap_code , ' ', F026_LEN);
			
			memcpy (ptTxn->acq_inst_id_code , ptIpcIntTxn->sAcqInstIdCode        , F032_VAL_LEN);
			memcpy (ptTxn->fwd_inst_id_code , ptIpcIntTxn->sFwdInstIdCode        , F033_VAL_LEN);
			memcpy (ptTxn->retrivl_ref      , ptIpcIntTxn->sRetrivlRefNum        , F037_LEN);
			if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
				memcpy (ptTxn->authr_id_resp    , ptIpcIntTxn->sAuthrIdResp            , F038_LEN);
			else
				memset (ptTxn->authr_id_resp    , ' ', F038_LEN);
			memcpy (ptTxn->resp_code        , ptIpcIntTxn->sRespCode            , F039_LEN);
			memcpy (ptTxn->card_accp_term_id, ptIpcIntTxn->sCardAccptrTermnlId    , F041_LEN);
			memcpy (ptTxn->card_accp_id     , ptIpcIntTxn->sCardAccptrId        , F042_LEN);
			memcpy (ptTxn->card_accp_name   , ptIpcIntTxn->sCardAccptrNameLoc    , F043_LEN);
			memcpy (ptTxn->currcy_code_trans, ptIpcIntTxn->sCurrcyCodeTrans        , F049_LEN);
			if (ptIpcIntTxn->cF054Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->addtnl_amt_len   , ptIpcIntTxn->sAddtnlAmtLen        , F054_LEN_LEN);
				memcpy (ptTxn->addtnl_amt       , ptIpcIntTxn->sAddtnlAmt            , F054_VAL_DB_LEN);
			}
			else
			{
				memset (ptTxn->addtnl_amt_len   , ' ', F054_LEN_LEN);
				memset (ptTxn->addtnl_amt       , ' ', F054_VAL_DB_LEN);
			}
			memcpy (ptTxn->fld_reserved_len , ptIpcIntTxn->sFldReservedLen        , F060_LEN_LEN);
			memcpy (ptTxn->fld_reserved     , ptIpcIntTxn->sFldReserved            , F060_VAL_LEN);
			if (ptIpcIntTxn->cF062Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->switch_data_len  , ptIpcIntTxn->sSwitchingDataLen    , F062_LEN_LEN);
				memcpy (ptTxn->switch_data      , ptIpcIntTxn->sSwitchingData        , F062_VAL_LEN);
			}
			else
			{
				memset (ptTxn->switch_data_len  , ' ', F062_LEN_LEN);
				memset (ptTxn->switch_data      , ' ', F062_VAL_LEN);
			}
			
			if (ptIpcIntTxn->cF122Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->acq_swresved_len , ptIpcIntTxn->sAcqInstResvdLen    , F122_LEN_LEN);
				memcpy (ptTxn->acq_swresved     , ptIpcIntTxn->sAcqInstResvd   , F122_VAL_LEN);
			}
			else
			{
				memset (ptTxn->acq_swresved_len , ' '   , F122_LEN_LEN);
				memset (ptTxn->acq_swresved     , ' '   , F122_VAL_LEN);
			}
			
			if (ptIpcIntTxn->sOrderId[0] != ' ')
			    memcpy (ptTxn->order_id  , ptIpcIntTxn->sOrderId        , FLD_ORDER_ID_LEN);
			if (ptIpcIntTxn->sConsumeType[0] != ' ')
			    memcpy (ptTxn->consume_type  , ptIpcIntTxn->sConsumeType        , FLD_CONSUME_TYPE_LEN);
			memcpy (ptTxn->msq_type         , ptIpcIntTxn->sMsqType                , FLD_MSQ_TYPE_LEN);
			memcpy (ptTxn->misc_flag        , ptIpcIntTxn->sMiscFlag            , FLD_MISC_FLAG_LEN);
			memcpy (ptTxn->misc_1           , ptIpcIntTxn->sMisc1                , FLD_MISC_LEN);
			memcpy (ptTxn->misc_2           , ptIpcIntTxn->sMisc2                , FLD_MISC_LEN);
			if (ptIpcIntTxn->sLoopReq[0] != ' ')
			    memcpy (ptTxn->loop_req           , ptIpcIntTxn->sLoopReq                , FLD_LOOP_LEN);
			if (getenv ( "THIS_IP_ADDR"))
				strcpy(ptTxn->req_node, getenv ("THIS_IP_ADDR")); 
			
			break;


		case TXN_NUM_BDB_RSP:
			if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
				memcpy (ptTxn->authr_id_r    , ptIpcIntTxn->sAuthrIdResp, F038_LEN);
			memcpy (ptTxn->resp_code        , ptIpcIntTxn->sRespCode, F039_LEN);
			memcpy (ptTxn->resp_desp        , ptIpcIntTxn->sRespDesp, FLD_RESP_DESP_LEN);
			if (ptIpcIntTxn->cF054Ind == FLAG_YES_C)
			{
				memcpy (ptTxn->addtnl_amt_len   , ptIpcIntTxn->sAddtnlAmtLen, F054_LEN_LEN);
				memcpy (ptTxn->addtnl_amt       , ptIpcIntTxn->sAddtnlAmt, F054_VAL_DB_LEN);
			}
			memcpy (ptTxn->loop_rsp        , ptIpcIntTxn->sLoopRsp, FLD_LOOP_LEN);
			if (getenv ( "THIS_IP_ADDR"))
				strcpy(ptTxn->rsp_node, getenv ("THIS_IP_ADDR"));
			
			break;

		default: 
			break;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:   int MoveTxn2Ipc (Tbl_bonus_txn_Def *ptTxn, T_IpcIntBonusDef *ptIpcIntTxn )*/
/* INPUT:  ptIpcIntTxn: ������, ��ʽ���ڲ���IPC�ṹ                        */
/* OUTPUT: ptTxn: ��Ӧ��tbl_bonus_txn�ļ�¼                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ptIpcIntTxn������дptTxn                                        */
/*****************************************************************************/
int MoveTxn2Ipc (Tbl_bonus_txn_Def *ptTxn, T_IpcIntBonusDef *ptIpcIntTxn )
{
	char    sFuncName[] = "MoveTxn2Ipc";
	char    sAcqInstIdCode[F032_VAL_LEN + 1];
	char    sFwdInstIdCode[F033_VAL_LEN + 1];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memset ((char *)ptIpcIntTxn, ' ', sizeof (*ptIpcIntTxn));

	memcpy (ptIpcIntTxn->sSysSeqNum                , ptTxn->sys_seq_num      , F011_LEN);
	memcpy (ptIpcIntTxn->sMsgSrcId                , ptTxn->msg_src_id       , SRV_ID_LEN);
	memcpy (ptIpcIntTxn->sTxnNum                , ptTxn->txn_num          , FLD_TXN_NUM_LEN);
	memcpy (ptIpcIntTxn->sTransCode                , ptTxn->trans_code       , FLD_TXN_CODE_LEN);
	memcpy (ptIpcIntTxn->sTransChnl                , ptTxn->trans_chnl       , FLD_TRANS_CHNL_LEN);
	memcpy (ptIpcIntTxn->sTransState            , ptTxn->trans_state      , FLD_TRANS_STATE_LEN);
	
	memcpy (ptIpcIntTxn->sFwTransDate            , ptTxn->fw_trans_date      , FLD_FW_TRANS_DATE_LEN);
	memcpy (ptIpcIntTxn->sFwTransTime            , ptTxn->fw_trans_time      , FLD_FW_TRANS_TIME_LEN);
	memcpy (ptIpcIntTxn->sFwTransSsn            , ptTxn->fw_trans_ssn      , FLD_FW_TRANS_SSN_LEN);
	
	memcpy (ptIpcIntTxn->sMsgType                , ptTxn->msg_type         , F000_MSG_TYPE_LEN);
	ptIpcIntTxn->cF002Ind = (ptTxn->pan_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sPrimaryAcctNumLen        , ptTxn->pan_len          , F002_LEN_LEN);
	memcpy (ptIpcIntTxn->sPrimaryAcctNum        , ptTxn->pan              , F002_VAL_LEN);
	memcpy (ptIpcIntTxn->sProcessingCode        , ptTxn->processing_code  , F003_LEN);
	memcpy (ptIpcIntTxn->sAmtTrans                , ptTxn->amt_trans        , F004_LEN);
	memcpy (ptIpcIntTxn->sTransmsnDateTime        , ptTxn->trans_date_time  , F007_LEN);
	memcpy (ptIpcIntTxn->sSysTraceAuditNum        , ptTxn->sys_seq_num          , F011_LEN);
	memcpy (ptIpcIntTxn->sTimeLocalTrans        , ptTxn->time_local_trans , F012_LEN);
	memcpy (ptIpcIntTxn->sDateLocalTrans        , ptTxn->date_local_trans , F013_LEN);
	ptIpcIntTxn->cF015Ind = (ptTxn->date_settlmt[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sDateSettlmt            , ptTxn->date_settlmt     , F015_LEN);
	memcpy (ptIpcIntTxn->sMchntType                , ptTxn->mchnt_type       , F018_LEN);
	memcpy (ptIpcIntTxn->sPosEntryModeCode        , ptTxn->pos_entry_mode   , F022_LEN);
	memcpy (ptIpcIntTxn->sPosCondCode            , ptTxn->pos_cond_code    , F025_LEN);
	ptIpcIntTxn->cF026Ind = (ptTxn->pos_pin_cap_code[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sPosPinCaptrCode        , ptTxn->pos_pin_cap_code , F026_LEN);
	memcpy (sAcqInstIdCode, ptTxn->acq_inst_id_code , F032_VAL_LEN);
	sAcqInstIdCode[F032_VAL_LEN] = 0;
	CommonRTrim(sAcqInstIdCode);
	sprintf(ptIpcIntTxn->sAcqInstIdCodeLen, "%02d", (int)strlen(sAcqInstIdCode));
	memcpy (ptIpcIntTxn->sAcqInstIdCode            , ptTxn->acq_inst_id_code , F032_VAL_LEN);
	memcpy (sFwdInstIdCode, ptTxn->fwd_inst_id_code , F033_VAL_LEN);
	sFwdInstIdCode[F033_VAL_LEN] = 0;
	CommonRTrim(sFwdInstIdCode);
	sprintf(ptIpcIntTxn->sFwdInstIdCodeLen, "%02d", (int)strlen(sFwdInstIdCode));
	memcpy (ptIpcIntTxn->sFwdInstIdCode            , ptTxn->fwd_inst_id_code , F033_VAL_LEN);
	memcpy (ptIpcIntTxn->sRetrivlRefNum            , ptTxn->retrivl_ref      , F037_LEN);

	ptIpcIntTxn->cF038Ind = (ptTxn->authr_id_resp[0] != ' '&&ptTxn->authr_id_resp[0] != 0) ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAuthrIdResp            , ptTxn->authr_id_resp    , F038_LEN);

	memcpy (ptIpcIntTxn->sRespCode                , ptTxn->resp_code        , F039_LEN);
	memcpy (ptIpcIntTxn->sCardAccptrTermnlId    , ptTxn->card_accp_term_id, F041_LEN);
	memcpy (ptIpcIntTxn->sCardAccptrId            , ptTxn->card_accp_id     , F042_LEN);
	memcpy (ptIpcIntTxn->sCardAccptrNameLoc        , ptTxn->card_accp_name   , F043_LEN);
	
	memcpy (ptIpcIntTxn->sCurrcyCodeTrans        , ptTxn->currcy_code_trans, F049_LEN);
	
	ptIpcIntTxn->cF052Ind = FLAG_NO_C;
	ptIpcIntTxn->cF053Ind = FLAG_NO_C;
	ptIpcIntTxn->cF054Ind = (ptTxn->addtnl_amt_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAddtnlAmtLen            , ptTxn->addtnl_amt_len   , F054_LEN_LEN);
	memcpy (ptIpcIntTxn->sAddtnlAmt                , ptTxn->addtnl_amt       , F054_VAL_DB_LEN);
	memcpy (ptIpcIntTxn->sFldReservedLen        , ptTxn->fld_reserved_len , F060_LEN_LEN);
	memcpy (ptIpcIntTxn->sFldReserved            , ptTxn->fld_reserved     , F060_VAL_LEN);
	
	ptIpcIntTxn->cF062Ind = (ptTxn->switch_data_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sSwitchingDataLen        , ptTxn->switch_data_len  , F062_LEN_LEN);
	memcpy (ptIpcIntTxn->sSwitchingData            , ptTxn->switch_data      , F062_VAL_LEN);
	
	ptIpcIntTxn->cF122Ind = (ptTxn->acq_swresved_len[0] != ' ') ? FLAG_YES_C: FLAG_NO_C;
	memcpy (ptIpcIntTxn->sAcqInstResvdLen    , ptTxn->acq_swresved_len , F123_LEN_LEN);
	memcpy (ptIpcIntTxn->sAcqInstResvd        , ptTxn->acq_swresved     , F123_VAL_LEN);
	
	memcpy (ptIpcIntTxn->sMsqType                , ptTxn->msq_type         , FLD_MSQ_TYPE_LEN);
	memcpy (ptIpcIntTxn->sMiscFlag                , ptTxn->misc_flag        , FLD_MISC_FLAG_LEN);
	memcpy (ptIpcIntTxn->sMisc1                    , ptTxn->misc_1           , FLD_MISC_LEN);
	memcpy (ptIpcIntTxn->sMisc2                    , ptTxn->misc_2           , FLD_MISC_LEN);
	
	memcpy (ptIpcIntTxn->sBpType                    , ptTxn->bp_type           , FLD_BP_TYPE_LEN);
	memcpy (ptIpcIntTxn->sConsumeType                    , ptTxn->consume_type           , FLD_CONSUME_TYPE_LEN);
	
	memcpy (ptIpcIntTxn->sLoopReq                    , ptTxn->loop_req           , FLD_LOOP_LEN);
	memcpy (ptIpcIntTxn->sLoopRsp                    , ptTxn->loop_rsp           , FLD_LOOP_LEN);
    memcpy (ptIpcIntTxn->sOrderId                    ,ptTxn->order_id            ,FLD_ORDER_ID_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int InsertSafMsg (T_IpcIntBonusDef *ptSendIpcIntTxn, Tbl_bonus_txn_Def *ptTxn, char *sCount)
{
	char            sFuncName[] = "InsertSafMsg";
	int                nCount;
	int                nReturnCode;
	int                nMsgLen;
	Tbl_saf_msg_Def    tSafMsg;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nCount = %d .", atoi(sCount) );

	nCount = atoi (sCount);
	if (nCount > 0)
	{
		DbsBegin ();
		memset ((char *)&tSafMsg, 0, sizeof (tSafMsg));
		memcpy (tSafMsg.inst_date, ptTxn->inst_date, 8);
		memcpy (tSafMsg.inst_time, ptTxn->inst_time, 6);
		memcpy (tSafMsg.msg_src_id, ptTxn->msg_src_id, SRV_ID_LEN);
		memcpy (tSafMsg.txn_num, ptTxn->txn_num, FLD_TXN_NUM_LEN);
		memcpy (tSafMsg.sys_seq_num, ptTxn->sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
		memcpy (tSafMsg.msg_dest_srv_id, ptSendIpcIntTxn->sMsgDestId, SRV_ID_LEN);
		memcpy (tSafMsg.send_count, sCount, 2);
		memset (tSafMsg.center_stlm_date, ' ', 8);
		memcpy (tSafMsg.center_stlm_date, ptTxn->date_settlmt, 4);
		memset (tSafMsg.host_stlm_date, ' ', 8);
		nMsgLen = sizeof (*ptSendIpcIntTxn);
		sprintf (tSafMsg.msg_len, "%04d", nMsgLen);
		EncodeNull ((char *)ptSendIpcIntTxn, nMsgLen);
		if (nMsgLen > 3072)
		{
			memcpy (tSafMsg.msg_ipc1, (char *)ptSendIpcIntTxn, 3072);
			memcpy (tSafMsg.msg_ipc2, ((char *)ptSendIpcIntTxn)+3072, nMsgLen-3072);
		}
		else
		{
			memcpy (tSafMsg.msg_ipc1, (char *)ptSendIpcIntTxn, nMsgLen);
		}

		nReturnCode = DbsSafMsg (DBS_INSERT, &tSafMsg);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsSafMsg insert error, %d.", nReturnCode);
			DbsRollback ();
			return -1;
		}
		DbsCommit ();
	}
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CopyOrigTxnInfo (Tbl_bonus_txn_Def *ptTxn, T_IpcIntBonusDef *ptIpcIntTxn)
{
	char   sTemp[20];
	/*memcpy (ptIpcIntTxn->sCurrcyCodeTrans        ,  ptTxn->currcy_code_trans  , F049_LEN);*/
	memcpy (ptIpcIntTxn->sBpType        ,           ptTxn->bp_type , FLD_BP_TYPE_LEN);
	memcpy (ptIpcIntTxn->sConsumeType        ,      ptTxn->consume_type , FLD_CONSUME_TYPE_LEN);
	/*memcpy (ptIpcIntTxn->sMchntType                , ptTxn->mchnt_type       , F018_LEN);*/
    
    /*memcpy (ptIpcIntTxn->sFwTransId        ,      ptTxn->fw_trans_id , FLD_FW_TRANS_ID_LEN);
    memcpy (ptIpcIntTxn->sFwTransDate        ,      ptTxn->fw_trans_date , FLD_FW_TRANS_DATE_LEN);
    memcpy (ptIpcIntTxn->sFwTransTime        ,      ptTxn->fw_trans_time , FLD_FW_TRANS_TIME_LEN);
    memcpy (ptIpcIntTxn->sFwTransSsn        ,      ptTxn->fw_trans_ssn , FLD_FW_TRANS_SSN_LEN);*/
    
	return 0;
}

/*****************************************************************************/
/* FUNC:   int SendRevsalOnError (T_IpcIntBonusDef *ptIpcIntTxn, int nIndex) */
/* INPUT:  ptIpcIntTxn: �ڲ�IPC, ��Ӧ�����׵����ݿ��¼                    */
/*         nIndex: gatTxnInf�иý��׵��±�                                   */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �ڴ����ٵ��ĳɹ�Ӧ���Ӧ��ʱʱ, �ɵ��ô˺������ͳ�������        */
/*****************************************************************************/
int SendRevsalOnError (T_IpcIntBonusDef *ptIpcIntTxn, int nIndex, char *sReasonCode)
{
	char            sFuncName[] = "SendRevsalOnError";
	char            sMsgSrcId[SRV_ID_LEN+1];
	char            sTxnNum[FLD_TXN_NUM_LEN+1];
	char            sCurrentTime[15];
	int                nFldReservedLen;
	int                nReturnCode;
	int                nRevsalIndex;
	int                i;
	T_IpcIntBonusDef    tIpcIntRevsal;
    memset(sCurrentTime,0x00,sizeof(sCurrentTime));
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "gatTxnInf.to_txn_num[%4.4s],nIndex[%d]", 
		gatTxnInf[nIndex].to_txn_num, nIndex);

	memcpy((char *)&tIpcIntRevsal, ptIpcIntTxn, sizeof (*ptIpcIntTxn));
	memcpy(tIpcIntRevsal.sMsgDestId, "1903", 4);
	
	if (strlen(gatTxnInf[nIndex].to_txn_num) &&
			gatTxnInf[nIndex].to_txn_num[0] != ' ')
	{
		/* need to send reversal */

		/* change ipc to reversal ipc */
	/*	if (!memcmp(tIpcIntRevsal.sMsgSrcId, SRV_ID_COMM_P, 4))
			memcpy (tIpcIntRevsal.sHeaderBuf + 6, "00010000    03050000    ", 22);
  */
		memcpy (tIpcIntRevsal.sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN);
		memcpy (tIpcIntRevsal.sTransState, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN);
		memcpy (tIpcIntRevsal.sTxnNum, gatTxnInf[nIndex].to_txn_num, FLD_TXN_NUM_LEN);
		tIpcIntRevsal.sTransCode[FLD_TXN_CODE_LEN-1] = TRANS_CODE_REVSAL;
		/* clear F039 */
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntTxn sRespCode[%2.2s] .", ptIpcIntTxn->sRespCode);
	 	memset (tIpcIntRevsal.sRespCode, ' ', F039_LEN); 
		/* MSG TYPE */
		memcpy (tIpcIntRevsal.sMsgType, MSG_TYPE_REVSAL, F000_MSG_TYPE_LEN);
		
		/* F090 */
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransChnl[%4.4s]", 
		       ptIpcIntTxn->sTransChnl);
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sFwTransSsn[%22.22s]", 
		       ptIpcIntTxn->sFwTransSsn);
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sFwTransDate[%8.8s]", 
		       ptIpcIntTxn->sFwTransDate);
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sFwTransTime[%6.6s]", 
		       ptIpcIntTxn->sFwTransTime);
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMsgSrcId[%4.4s]", 
		       ptIpcIntTxn->sMsgSrcId);
		
		memcpy (tIpcIntRevsal.sTransChnl, ptIpcIntTxn->sTransChnl, FLD_TRANS_CHNL_LEN);
		/* ȱ��ԭ���𷽱�ʶ */
		memcpy (tIpcIntRevsal.sFwTransSsn, ptIpcIntTxn->sFwTransSsn, FLD_FW_TRANS_SSN_LEN);
		memcpy (tIpcIntRevsal.sFwTransDate, ptIpcIntTxn->sFwTransDate, FLD_FW_TRANS_DATE_LEN);
		memcpy (tIpcIntRevsal.sFwTransTime, ptIpcIntTxn->sFwTransTime, FLD_FW_TRANS_TIME_LEN);
		
        /*F007*/
        CommonGetCurrentTime(sCurrentTime);
        memcpy(tIpcIntRevsal.sTransmsnDateTime,sCurrentTime+4,10);
       
		memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
		memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);
		memset (sTxnNum, 0, sizeof (sTxnNum));
		memcpy (sTxnNum, gatTxnInf[nIndex].to_txn_num, FLD_TXN_NUM_LEN);
		nReturnCode = GetTxnInfoIndex( sMsgSrcId, sTxnNum, &nRevsalIndex );
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetTxnInfoIndex error, %d.", nReturnCode);
			return -1;
		}

		/* process reversal txn */
		for( i = 0; i < MAXTXNS; i++ )
		{
			if( memcmp( tIpcIntRevsal.sTxnNum, gaTxns[i].caTxnNum, FLD_TXN_NUM_LEN ) == 0 )
			{
				if (memcmp( gaTxns[i].caMsgSrcId, MSG_SRC_ID_ANY, SRV_ID_LEN ) == 0 )
				{
					break;
				}
				else
				{
					if (memcmp( ptIpcIntTxn->sMsgSrcId, gaTxns[i].caMsgSrcId, SRV_ID_LEN ) == 0 )
					{
						break;
					}
				}
			}
		}

		if( i == MAXTXNS )
		{
			nReturnCode = SwtCustHandleTransaction(&tIpcIntRevsal, nRevsalIndex);
		}
		else
		{
			nReturnCode = gaTxns[i].pfTxnFun(&tIpcIntRevsal, nRevsalIndex);
		}

		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HandleRvslReqTDB error, %d.", nReturnCode);
			return -1;
		}
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:   int SendMsg (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptTxn,      */
/*                      Tbl_bonus_txn_Def *ptOrigTxn)                              */
/* INPUT:  ptIpcIntTxn: ������, ��ʽ���ڲ���IPC�ṹ                        */
/*         ptTxn: tbl_txn��¼, ָ�����Ϊ��                                  */
/*         ptOrigTxn: ԭʼ����, tbl_txn��¼, ָ�����Ϊ��                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��gatTxnInf��������PackSend���;ܾ�Ӧ����                       */
/*****************************************************************************/
int SendMsg (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptTxn, Tbl_bonus_txn_Def *ptOrigTxn)
{
	char    sFuncName[] = "SendMsg";
	char    sMsgBuf[MSQ_MSG_SIZE_MAX];
	int     nMsgLen;
	int        nReturnCode;
	int        nLineStat;
	char    summary[201]="";
    char    sTmp1[4+1];
	int i;
	char    sLineIndex[2] = {0};
	T_BpHeaderDef * ptBpHeader;

	long lEndTime , lBeginTime;
	
	T_IpcIntTxnDef    tPosIpcIntTxn;
	 
	struct tms        tTMS;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransmsnDateTime[%10.10s]", ptIpcIntTxn->sTransmsnDateTime);
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "sMsgSrcId[%4.4s], sMsgDestId[%4.4s]",ptIpcIntTxn->sMsgSrcId, ptIpcIntTxn->sMsgDestId);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "ptIpcIntTxn->sTxnNum[%4.4s]",ptIpcIntTxn->sTxnNum);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "ptIpcIntTxn->sPosCondCode[%2.2s]",ptIpcIntTxn->sPosCondCode);
	/* clear msq type if this is a request msg */
	if (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_REQ ||
			ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ ||
			ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ )
	{
		/*
		memset( ptIpcIntTxn->sMsqType, '0', FLD_MSQ_TYPE_LEN);

		*/
	}
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "ptIpcIntTxn->cF014Ind [%c] ptIpcIntTxn->sDateExpr [%-04.04s]", ptIpcIntTxn->cF014Ind, ptIpcIntTxn->sDateExpr);
	lBeginTime = times( &tTMS);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "ptIpcIntTxn->sMsgDestId--%4.4s ptIpcIntTxn->sTxnNum--%4.4s",
	            ptIpcIntTxn->sMsgDestId, ptIpcIntTxn->sTxnNum);
	nReturnCode = SwtCustAfterTblTxnOpr (ptIpcIntTxn, ptTxn, ptOrigTxn);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"SwtCustAfterTblTxnOpr error, %d.", nReturnCode);
		return -1;
	}
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransmsnDateTime[%10.10s].", ptIpcIntTxn->sTransmsnDateTime);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "ptIpcIntTxn->sMsgDestId--%4.4s",ptIpcIntTxn->sMsgDestId);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "ptIpcIntTxn->sFwdInstIdCode--%8.8s",ptIpcIntTxn->sFwdInstIdCode);
  
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "ptIpcIntTxn->sMsgSrcId--%4.4s ptIpcIntTxn->sMsgDestId--%4.4s",ptIpcIntTxn->sMsgSrcId, ptIpcIntTxn->sMsgDestId);
	lEndTime = times( &tTMS);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "SwtCustAfterTblTxnOpr processed, used %ld ticks", lEndTime - lBeginTime);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sLoopReq [%-512.512s]", ptIpcIntTxn->sLoopReq);
    HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, ptIpcIntTxn->sLoopReq, 512);

	/* ��F014��ȱʡֵ ������������������ */
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "ptIpcIntTxn->cF014Ind [%c] ptIpcIntTxn->sDateExpr [%4.4s]", ptIpcIntTxn->cF014Ind, ptIpcIntTxn->sDateExpr);
	if(ptIpcIntTxn->sDateExpr[0] == ' ' || ptIpcIntTxn->sDateExpr[0] == 0x00)
	{    
	    ptIpcIntTxn->cF014Ind = FLD_IND_VAL_Y;
	    memcpy( ptIpcIntTxn->sDateExpr, F014_DEFAULT, F014_LEN);
    }

	/***************
	 * ����MAC
	 ****************/
	 /*if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0 ||
	    memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0 ||
	    memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0 ||
	    memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_MZ, SRV_ID_LEN) == 0)
	{
	    nReturnCode = GenerateMAC (ptIpcIntTxn);
	    if (nReturnCode)
	    {
	    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	    			"GenerateMAC error, %d.", nReturnCode);
	    	return -1;
	    }
	}
	else
	{
	    ptIpcIntTxn->cF128Ind = 'Y';
		memcpy(ptIpcIntTxn->sMAC128, "FFFFFFFF", F128_LEN);
	}*/

	/***********************
	 * ��ⷢ��Ŀ����·״̬
	 ************************/
	if(memcmp(ptIpcIntTxn->sMsgDestId,"1702",4)==0 )
	 {
        strcpy (sLineIndex, getenv(SRV_USAGE_KEY));
	    nReturnCode = LineStateCheck (ptIpcIntTxn->sMsgDestId, sLineIndex, &nLineStat);
	    if (nReturnCode || (nReturnCode == 0 && nLineStat != LINE_STATE_CONNECT))
	    {
	    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
	    			"LineStateCheck return %d, line state %d.", nReturnCode, nLineStat);
	    	return -1;
	    }		
    }

	if(memcmp(ptIpcIntTxn->sMsgDestId,"1903",4)==0)
	{
	    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"sTxnNum[%4.4s]", ptIpcIntTxn->sTxnNum);
		if(memcmp(ptIpcIntTxn->sTxnNum, "1805", 4) == 0)
		{
			memcpy(ptIpcIntTxn->sFwTransId, "SWTC", 4);
			memcpy(ptIpcIntTxn->sMidTag, ptTxn->mid_tag, FLD_MID_TAG_LEN);
			memcpy(ptIpcIntTxn->sPrimaryAcctNum, ptTxn->pan, F002_VAL_LEN);
			memcpy(ptIpcIntTxn->sBpType, "001", 3);
			memcpy(ptIpcIntTxn->sCardAccptrId, ptTxn->card_accp_id, F042_LEN);
			memcpy(ptIpcIntTxn->sCardAccptrTermnlId, ptTxn->card_accp_term_id, F041_LEN);
		}
		memcpy(ptIpcIntTxn->sFwTransId, "SWTC", 4);
	}
	
	/* ������Ӧ��ʹ�ñ�����������Ӧ�� */
	if((ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_RSP) ||
	    (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_CBDB_RSP))
	{
	    /* �����ཻ�� */
	    if(memcmp(ptIpcIntTxn->sTxnNum, "1806", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "1202", 4);
	    else if(!memcmp(ptIpcIntTxn->sTxnNum, "1816", 4) && 
			    !memcmp(ptIpcIntTxn->sPosCondCode, "65", 2))
	        memcpy(ptIpcIntTxn->sTxnNum, "1102", 4);
		else if(!memcmp(ptIpcIntTxn->sTxnNum, "1816", 4) && 
			    !memcmp(ptIpcIntTxn->sPosCondCode, "66", 2))
	        memcpy(ptIpcIntTxn->sTxnNum, "1826", 4);
		else if(!memcmp(ptIpcIntTxn->sTxnNum, "1826", 4) && 
			    !memcmp(ptIpcIntTxn->sPosCondCode, "66", 2))
	        memcpy(ptIpcIntTxn->sTxnNum, "1826", 4);
	    else if(!memcmp(ptIpcIntTxn->sTxnNum, "2816", 4) ||
			    !memcmp(ptIpcIntTxn->sTxnNum, "2826", 4))
	        memcpy(ptIpcIntTxn->sTxnNum, "2102", 4);
	    else if(!memcmp(ptIpcIntTxn->sTxnNum, "3816", 4) ||
			    !memcmp(ptIpcIntTxn->sTxnNum, "3826", 4))
	        memcpy(ptIpcIntTxn->sTxnNum, "3102", 4);
		else if(!memcmp(ptIpcIntTxn->sTxnNum, "4816", 4) ||
			    !memcmp(ptIpcIntTxn->sTxnNum, "4826", 4))
	        memcpy(ptIpcIntTxn->sTxnNum, "4102", 4);
	    else if(memcmp(ptIpcIntTxn->sTxnNum, "5836", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "5152", 4);
		else if(memcmp(ptIpcIntTxn->sTxnNum, "5846", 4) == 0)
	        memcpy(ptIpcIntTxn->sTxnNum, "5152", 4);
	
    }
      /* �ͻ����̳ǻ��ֱ���ͷ */
    if(memcmp(ptIpcIntTxn->sMsgDestId, "1831", 4) == 0)
    {
		memset(ptIpcIntTxn->sBpHeader,' ',80);			    
        ptBpHeader = (T_BpHeaderDef *)ptIpcIntTxn->sBpHeader;
        
	    memcpy(ptBpHeader->sTotLen, "0139", 4);
	    memcpy(ptBpHeader->sVerNo, "1", 1);
	    memcpy(ptBpHeader->sToEnc, "0", 1);
	    memcpy(ptBpHeader->sCommCode, "500001", 6);
	    memcpy(ptBpHeader->sCommType, "0", 1);
	    memcpy(ptBpHeader->sRcvId, "NIBS", 4);	    
	    memcpy(ptBpHeader->sSndId, "SWT1", 4);	   
	    memcpy(ptBpHeader->sSndSn, ptIpcIntTxn->sMidSsn, FLD_MID_SSN_LEN);  
	    
	    memcpy(ptBpHeader->sSndDate, ptIpcIntTxn->sFwTransDate, 8);
	    memcpy(ptBpHeader->sSndTime, ptIpcIntTxn->sFwTransTime, 6);	           
	    memcpy(ptBpHeader->sTradeCode, "ibs001", 6);	      	                
	    memcpy(ptBpHeader->sErrCode, "  ", 2);
	    memcpy(ptBpHeader->sErrMsg, "       ", 7);
	    memcpy(ptBpHeader->sReserved1, "        ", 8);
	       
    }
    /* ����תԭIPC */
    if(memcmp(ptIpcIntTxn->sMsgDestId, "1801", 4) == 0 ||
        memcmp(ptIpcIntTxn->sMsgDestId, "1802", 4) == 0 ||
        memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CC, 4) == 0)
    {
        memset(&tPosIpcIntTxn, ' ', sizeof(T_IpcIntTxnDef));
        if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CC, 4) == 0)
        {
            nReturnCode = BufChgOpr(52,ptIpcIntTxn,&tPosIpcIntTxn,&tBufChgRule);
            if(nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "BufChgOpr err, index 52.");
                return -1;
            }
        }
        else
        {
            nReturnCode = BufChgOpr(44,ptIpcIntTxn,&tPosIpcIntTxn,&tBufChgRule);
            if(nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "BufChgOpr err, index 44.");
                return -1;
            }
        }
        
        
        /* ѹ����Ϣ�� */
	    if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
	    {
	    	/* compress msg */
	    	Compressbuf ((char *)&tPosIpcIntTxn, sizeof (tPosIpcIntTxn), sMsgBuf, &nMsgLen);
	    }
	    else
	    {HtDebugString ("lgm.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, ptIpcIntTxn->sLoopReq, 512);
	    	nMsgLen = sizeof (tPosIpcIntTxn);
	    	memcpy (sMsgBuf, (char *)&tPosIpcIntTxn, nMsgLen);
	    }
    }
    else
    {
	    /* ѹ����Ϣ�� */
	    if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
	    {
	    	/* compress msg */
	    	Compressbuf ((char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn), sMsgBuf, &nMsgLen);
	    }
	    else
	    {HtDebugString ("lgm.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, ptIpcIntTxn->sLoopReq, 512);
	    	nMsgLen = sizeof (*ptIpcIntTxn);
	    	memcpy (sMsgBuf, (char *)ptIpcIntTxn, nMsgLen);
	    }
    }

    HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, sMsgBuf, nMsgLen);
    
	nReturnCode = MsqSnd (SRV_ID_PACKSEND, gatSrvMsq, 0, nMsgLen, sMsgBuf);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqSnd error, %d.", nReturnCode);
		return -1;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}


int CheckRevsalTxn (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckRevsalTxn";
	char    sPanLen[F002_LEN_LEN+1];
	int     nPanLen;
	int     nReturnCode;
	char    sCurrentTime[15];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	/* DBS_SELECT22: txn_num, key_revsal */
	
	ptOrigTxn->txn_num[INDEX_TXN_NUM_TYPE] --;
       
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"DbsBonusTxn select22  txn_num=%4.4s,key_revsal=%32.32s.",
			ptOrigTxn->txn_num, ptOrigTxn->key_revsal);

	nReturnCode = DbsBonusTxn (DBS_SELECT22, ptOrigTxn );

	if( nReturnCode != 0 )
	{
		ptOrigTxn->key_revsal[KEY_RSP_LEN] = 0;
		ptOrigTxn->txn_num[FLD_TXN_NUM_LEN] = 0;
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsBonusTxn select22 error, %d. txn_num=%4.4s,key_revsal=%32.32s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		
		return 0;
	}

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sMsgSrcId[%4.4s]", ptIpcIntTxn->sMsgSrcId );
    
    /* ���ÿ��Զ�������F037 = F007����λ + F011 */
    if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_CBDB_REQ)
    {
        if(memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) == 0)
        {
            memcpy (ptIpcIntTxn->sRetrivlRefNum, ptIpcIntTxn->sTransmsnDateTime+4, 6);
            memcpy (ptIpcIntTxn->sRetrivlRefNum+6, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
        }
    }
    
	if (memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) )
	{
		/* check originl txn status */
		/* check F002, F004, txn state, revsal_flag, cancel_flag */
		if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
		{
			memset (sPanLen, 0, sizeof (sPanLen));
			memcpy (sPanLen, ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
			nPanLen = atoi (sPanLen);
			if (memcmp (ptOrigTxn->pan, ptIpcIntTxn->sPrimaryAcctNum, nPanLen))
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"check txn pan fail. txn_num=%4.4s,key_revsal=%32.32s.",
						ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
				memcpy (sRespCode, F039_INVALID_PAN, F039_LEN);
				return 0;
			}
		}
		else
		{
			memset (sPanLen, 0, sizeof (sPanLen));
			memcpy (sPanLen, ptOrigTxn->pan_len, F002_LEN_LEN);
			nPanLen = atoi (sPanLen);
			memcpy (ptIpcIntTxn->sPrimaryAcctNumLen, ptOrigTxn->pan_len, F002_LEN_LEN);
			memset (ptIpcIntTxn->sPrimaryAcctNum, ' ', F002_VAL_LEN);
			memcpy (ptIpcIntTxn->sPrimaryAcctNum, ptOrigTxn->pan, nPanLen);
		}

		if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN) &&
				memcmp (ptOrigTxn->trans_state, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN))
		{
		    if(memcmp(ptIpcIntTxn->sTxnNum, "2383", 4) == 0 ||
		        memcmp(ptIpcIntTxn->sTxnNum, "2385", 4) == 0)
		    {
		        if(memcmp(ptOrigTxn->misc_flag+14+4, "00", 2) != 0)
		        {
		            memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		            /*add by xu zhen*/
			        memcpy(ptIpcIntTxn->sAuthrIdResp,ptOrigTxn->authr_id_resp,F038_LEN);
			        memcpy(ptIpcIntTxn->sPosEntryModeCode,ptOrigTxn->pos_entry_mode,F022_LEN);
			        /*end*/
		            return 0;
		        }
		    }
		    else
		    {
			    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			    		"check txn state fail. txn_num=%4.4s,key_revsal=%32.32s.",
			    		ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			    memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
			    /*add by xu zhen*/
			    memcpy(ptIpcIntTxn->sAuthrIdResp,ptOrigTxn->authr_id_resp,F038_LEN);
			    memcpy(ptIpcIntTxn->sPosEntryModeCode,ptOrigTxn->pos_entry_mode,F022_LEN);
			    /*end*/
			    return 0;
			}
		}
		if (ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"check txn cancel flag fail. txn_num=%4.4s,key_revsal=%32.32s.",
					ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
			return 0;
		}
		
		if (ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL )
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"check txn revsal flag fail. txn_num=%4.4s,key_revsal=%32.32s.",
					ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			memcpy (sRespCode, F039_DUPL_TXN, F039_LEN);
			return 0;
		}
		
		/* ����Ƿ��ճ���(��������������) */
		if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_REQ ||
		    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
		{
		    memset(sCurrentTime, 0, sizeof(sCurrentTime));
			SetToTime(-1);
            memcpy(sCurrentTime, gsTimeCurTs, 14);
	        /*CommonGetCurrentTime(sCurrentTime);*/
	        HtLog("lgm.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ptOrigTxn->inst_date[%8.8s] sCurrentTime[%8.8s]", ptOrigTxn->inst_date, sCurrentTime);
	        if(memcmp(ptOrigTxn->inst_date, sCurrentTime, 8) != 0)
	        {
	            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    		"check revsal txn date error. txn_num=%4.4s, key_revsal=%32.32s. orig_date[%8.8s] revsal_date[%8.8s]",
		    		ptOrigTxn->txn_num,ptOrigTxn->key_revsal, ptOrigTxn->inst_date, sCurrentTime);
		        memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		        return 0;
	        }
	    }
	}
	/*add by xu zhen*/
	if (memcmp (ptOrigTxn->amt_trans, ptIpcIntTxn->sAmtTrans, F004_LEN)&&(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_BDT_REQ))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn amount fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s,OrigAmt=%12.12s,Amt=%12.12s",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id,ptOrigTxn->amt_trans,ptIpcIntTxn->sAmtTrans);
		memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
		return 0;
	}
	/*end*/
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CheckConfirmTxn (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckConfirmTxn";
	char    sPanLen[F002_LEN_LEN+1];
	int        nPanLen;
	int        nReturnCode;
	Tbl_bonus_txn_Def    stTxn;
	memset(&stTxn,0,sizeof(Tbl_bonus_txn_Def));

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	/* DBS_SELECT22: txn_num, key_revsal */
	ptOrigTxn->txn_num[INDEX_TXN_NUM_TYPE] --;

	nReturnCode = DbsTxn (DBS_SELECT22, ptOrigTxn );

	if( nReturnCode != 0)
	{
		ptOrigTxn->key_revsal[KEY_RSP_LEN] = 0;
		ptOrigTxn->txn_num[FLD_TXN_NUM_LEN] = 0;
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsTxn select22 error, %d. txn_num=%4.4s,key_revsal=%32.32s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		return 0;
	}
  
	if (memcmp (ptIpcIntTxn->sMsgSrcId, SRV_ID_SWITCH, SRV_ID_LEN) )
	{
		/* check originl txn status */
		/* check F002, F004 */
		memset (sPanLen, 0, sizeof (sPanLen));
		memcpy (sPanLen, ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
		nPanLen = atoi (sPanLen);
		if (memcmp (ptOrigTxn->pan, ptIpcIntTxn->sPrimaryAcctNum, nPanLen)&&(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_BDT_REQ) )
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"check txn pan fail. txn_num=%4.4s,key_revsal=%32.32s.",
					ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			memcpy (sRespCode, F039_INVALID_PAN, F039_LEN);
			return 0;
		}
		if (memcmp (ptOrigTxn->amt_trans, ptIpcIntTxn->sAmtTrans, F004_LEN)&&(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] != TXN_NUM_BDT_REQ))
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"check txn amount fail. txn_num=%4.4s,key_revsal=%32.32s.",
					ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
			memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
			return 0;
		}

		/* check txn state */
		switch (ptOrigTxn->trans_state[0])
		{
			case TRANS_STATE_SUCC_C:
				/* check cancel_flag */
				if (ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL)
				{
					memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
					HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
							"check txn cancel flag fail. txn_num=%4.4s,key_revsal=%32.32s.",
							ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
				}
				else
				{
					if (ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL )
					{
						memcpy (sRespCode, F039_DUPL_TXN, F039_LEN);
						HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
								"check txn revsal flag fail. txn_num=%4.4s,key_revsal=%32.32s.",
								ptOrigTxn->txn_num,ptOrigTxn->key_revsal);
					}
				}
				break;
			case TRANS_STATE_NO_RSP_C:
			case TRANS_STATE_TIME_OUT_C:
			case TRANS_STATE_NO_ACCT_RSP_C:
			case TRANS_STATE_ACCT_TO_C:
				memcpy (sRespCode, F039_SUCC_FAULT_6, F039_LEN);
				break;
			case TRANS_STATE_REJ_BY_CUPS_C:
			case TRANS_STATE_REJ_BY_HOST_C:
			case TRANS_STATE_REJ_PIN_MAC_C:
			case TRANS_STATE_REJ_BY_FE_C:
				memcpy (sRespCode, F039_SUCC_FAULT_5, F039_LEN);
				break;
			default:
				memcpy (sRespCode, F039_MAL_FUNCTION, F039_LEN);
				break;
		}
	}
	else
		memcpy (sRespCode, F039_SUCC_FAULT_6, F039_LEN);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int CheckCancelTxn (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckCancelTxn";
	char    sPanLen[F002_LEN_LEN+1];
	int        nPanLen;
	int        nReturnCode;
	char    sCurrentTime[15];
    char    sCurrentDate[8+1];
    
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy (sRespCode, F039_SUCCESS, F039_LEN);

	ptOrigTxn->txn_num[INDEX_TXN_NUM_TYPE] = ptOrigTxn->txn_num[INDEX_TXN_NUM_TYPE] - 2;

	/* DBS_SELECT23: txn_num, key_cancel*/
	nReturnCode = DbsBonusTxn (DBS_SELECT23, ptOrigTxn );

	if( nReturnCode != 0 )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsBonusTxn select23 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		return 0;
	}
    
	/* check originl txn status */
	/* check F002, F004, txn state, revsal_flag, cancel_flag */

	/***��鿨��***/
	memset (sPanLen, 0, sizeof (sPanLen));
	memcpy (sPanLen, ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
	nPanLen = atoi (sPanLen);
	if (memcmp (ptOrigTxn->pan, ptIpcIntTxn->sPrimaryAcctNum, nPanLen))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn pan fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INVALID_PAN, F039_LEN);
		return 0;
	}
		
    if ( (memcmp(ptIpcIntTxn->sTxnNum,"3015",4 )==0) || (memcmp(ptIpcIntTxn->sTxnNum,"3013",4 )==0)|| (memcmp(ptIpcIntTxn->sTxnNum,"3011",4 )==0) || (memcmp(ptIpcIntTxn->sTxnNum,"5015",4 )==0))
    {
    	if (memcmp (ptOrigTxn->amt_return, ptIpcIntTxn->sAmtTrans, F004_LEN))
    	{
    		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
    				"check txn amount fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s",
    				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
    		memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
    		return 0;
    	}
    }
    else
    {
    	if (memcmp (ptOrigTxn->amt_trans, ptIpcIntTxn->sAmtTrans, F004_LEN))
    	{
    		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
    				"check txn amount fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
    				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
    		memcpy (sRespCode, F039_INCORRECT_AMT, F039_LEN);
    		return 0;
    	}
    }
	 
	if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn state fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy (sRespCode, F039_INVALID_TXN, F039_LEN);
		return 0;
	}
	
	
	if (ptOrigTxn->cancel_flag[0] != REV_CAN_FLAG_NORMAL ||
		ptOrigTxn->revsal_flag[0] != REV_CAN_FLAG_NORMAL ||
		memcmp(ptOrigTxn->trans_state, TRANS_STATE_HAD_RETURN, 1) == 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn cancel flag fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s,cancel_flag[%1.1s] revsal_flag[%1.1s] ",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id,ptOrigTxn->cancel_flag,ptOrigTxn->revsal_flag);
		memcpy (sRespCode, F039_SUSP_MALFUNC, F039_LEN);
		return 0;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}


/* �����֡����ּ��ֽ��˻� */
int CheckReturnTxnAll (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptOrigTxn, char *sRespCode)
{
	char    sFuncName[] = "CheckReturnTxnAll";
	int     nReturnCode = 0;	
	double  allamt = 0 ;
	char    sBonusAmt[13]; 
	char    sTransAmt[13];
	char    sAllAmt[13];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	memcpy(sRespCode, F039_SUCCESS, F039_LEN);
	memset(sBonusAmt, 0, sizeof(sBonusAmt));
	memset(sTransAmt, 0, sizeof(sTransAmt));
	memset(sAllAmt, 0, sizeof(sAllAmt));

	memcpy(sTransAmt, ptIpcIntTxn->sAmtTrans, 12);
	CommonRTrim(sTransAmt);
	CommonLTrim(sTransAmt);
	if(strlen(sTransAmt) == 0)
		sTransAmt[0] = '0';

	if(!memcmp(ptOrigTxn->txn_num, "5845", FLD_TXN_NUM_LEN))
	{
	    memcpy(sBonusAmt, ptIpcIntTxn->sAddtnlAmt, 12);
	    CommonRTrim(sBonusAmt);
	    CommonLTrim(sBonusAmt);
	    if(strlen(sBonusAmt) == 0)
		    sBonusAmt[0] = '0';
	}

	/* DBS_SELECT23: key_cancel, txn_num */
	if(!memcmp(ptOrigTxn->txn_num, "5835", FLD_TXN_NUM_LEN))
	{
		/* ������POS�˻� */
		memcpy(ptOrigTxn->txn_num, "1815", FLD_TXN_NUM_LEN);
	}else if(!memcmp(ptOrigTxn->txn_num, "5845", FLD_TXN_NUM_LEN))
	{
		/* ���ּ��ֽ��˻� */
		memcpy(ptOrigTxn->txn_num, "1825" ,FLD_TXN_NUM_LEN);
	}else
	{
	    memcpy(sRespCode, "40", F039_LEN);
		return 0;
	}	
	
	nReturnCode = DbsBonusTxn (DBS_SELECT23, ptOrigTxn);
	if( nReturnCode != 0 && nReturnCode != DBS_NOTFOUND)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsTxn select23 error, %d. txn_num=%4.4s,key_cancel=%32.32s.",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel);
		memcpy (sRespCode, F039_ORIG_TXN_NOT_FOUND, F039_LEN);
		return 0;
	}	

	if (memcmp (ptOrigTxn->trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN) 
	    && memcmp (ptOrigTxn->trans_state, TRANS_STATE_HAD_RETURN, FLD_TRANS_STATE_LEN))
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"check txn state fail. txn_num=%4.4s,key_cancel=%32.32s,pan=%19.19s,authid=%8.8s,merid=%15.15s.",
				ptOrigTxn->txn_num,ptOrigTxn->key_cancel,ptOrigTxn->pan,ptOrigTxn->authr_id_resp,ptOrigTxn->card_accp_id);
		memcpy(sRespCode, F039_INVALID_TXN, F039_LEN);
		return 0;
	}
	
	/***�ж��ʺ� **/
	if ( memcmp(ptIpcIntTxn->sPrimaryAcctNum , ptOrigTxn->pan , F002_VAL_LEN ) != 0 )
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR,__FILE__,__LINE__,"�ʺ�error[%19.19s][%s]",ptIpcIntTxn->sPrimaryAcctNum,ptOrigTxn->pan);
		memcpy (sRespCode, "25", F039_LEN);
		return 0;
	}
	
	/***�ж��˻���***/
	if ((atof(ptOrigTxn->amt_trans) - atof(sTransAmt)) < M_ZERO )  /**�˻����̫�� **/
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"���  error, %d. txn_num=%4.4s,key_cancel=%32.32s,amtold[%f],TH[%f].",
				nReturnCode,ptOrigTxn->txn_num,ptOrigTxn->key_cancel,atof(ptOrigTxn->amt_trans) , atof(sTransAmt));
		memcpy (sRespCode, "61", F039_LEN);
		return 0;
	}
	else
	{
		/**�Ƚ��˻������ۼƽ�� */
		if((atof(ptOrigTxn->amt_return) + atof(sTransAmt) - atof(ptOrigTxn->amt_trans) > D_ZERO) &&
			!memcmp(ptOrigTxn->txn_num, "1815", 4))
		{
			HtLog(gsLogFile, HT_LOG_MODE_ERROR,__FILE__,__LINE__,"error, Orig.amt_return[%12.12s],sTransAmt[%12.12s],Orig.amt_trans[%12.12s]",ptOrigTxn->amt_return,sTransAmt, ptOrigTxn->amt_trans);
			memcpy(sRespCode, "61", F039_LEN);
			return 0;
		}
		else if((atof(ptOrigTxn->amt_return)+atof(sTransAmt)+atof(sBonusAmt) - atof(ptOrigTxn->amt_trans) > D_ZERO) &&
			!memcmp(ptOrigTxn->txn_num, "1825", 4))
		{
			HtLog(gsLogFile, HT_LOG_MODE_ERROR,__FILE__,__LINE__,"error, Orig.amt_return[%12.12s],sTransAmt[%12.12s],sBonusAmt[%12.12s],Orig.amt_trans[%12.12s]",ptOrigTxn->amt_return,sTransAmt,sBonusAmt,ptOrigTxn->amt_trans);
			memcpy(sRespCode, "61", F039_LEN);
			return 0;
		}
		else
		{
			/**�ۼƸ����˻���� **/
			if(!memcmp(ptOrigTxn->txn_num, "1815", 4))
			    allamt = atof(sTransAmt) + atof(ptOrigTxn->amt_return);
			else if(!memcmp(ptOrigTxn->txn_num, "1825", 4))
				allamt = atof(sTransAmt) + atof(sBonusAmt) + atof(ptOrigTxn->amt_return);
            else
				allamt = 0.00;
			sprintf(sAllAmt, "%012.0f", allamt);
			memcpy(ptOrigTxn->amt_return, sAllAmt, 12);
			HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
					"allamt[%.2f],sAllAmt[%s],amt_return[%12.12s]", allamt, sAllAmt, ptOrigTxn->amt_return);
			
			DbsBegin ();
			/***************
			 * ��¼���ݿ�
			 ****************/
			nReturnCode = DbsBonusTxn(DBS_UPDATE4, ptOrigTxn);
			if (nReturnCode )
			{
				DbsRollback ();
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn update error, %d. Discard this message.", nReturnCode);

				return -1;
			}
			DbsCommit();
            memcpy(ptOrigTxn->trans_state, TRANS_STATE_HAD_RETURN, 1);
			HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
					"keyrsp[%32.32s],txnnum[%4.4s]", ptOrigTxn->key_rsp, ptOrigTxn->txn_num);
			nReturnCode = DbsBonusTxn(DBS_UPDATE13, ptOrigTxn);
			if(nReturnCode)
			{
				DbsRollback ();
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DbsTxn update error[%d]", nReturnCode);

				return -1;
			}
			DbsCommit();			
		}
	}

	HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int SetKeyRsp (T_IpcIntBonusDef *ptIpcIntTxn)
{
	char    sFuncName[] = "SetKeyRsp";
	int        nReturnCode;
	int        i;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	nReturnCode = SwtCustSetKeyRsp (ptIpcIntTxn);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sKeyRsp:");
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int SetKeyRevsal (T_IpcIntBonusDef *ptIpcIntTxn)
{
	char    sFuncName[] = "SetKeyRevsal";
	int     nReturnCode;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	nReturnCode = SwtCustSetKeyRevsal (ptIpcIntTxn);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sKeyRevsal:");
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, ptIpcIntTxn->sKeyRevsal, KEY_REVSAL_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int SetKeyCancel (T_IpcIntBonusDef *ptIpcIntTxn)
{
	char    sFuncName[] = "SetKeyCancel";
	int     nReturnCode;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	nReturnCode = SwtCustSetKeyCancel (ptIpcIntTxn);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sKeyCancel:");
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, ptIpcIntTxn->sKeyCancel, KEY_CANCEL_LEN);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

void SetToTime(int nRouteIndex)
{
	 long retun=0;
	 char timecurt[27];
	 char timeout[27];
	 memset(timecurt,0x00,sizeof(timecurt));
	 memset(timeout,0x00,sizeof(timeout));
	 memset(gsTimeOutTs,0x00,sizeof(gsTimeOutTs));
	 memset(gsTimeCurTs,0x00,sizeof(gsTimeCurTs));
	 /*��ȡ���ݿ�ʱ��+��ʱʱ��*/
    if(nRouteIndex == -1)
        retun = GetDBoutTime( 0,timecurt ,timeout);
    else
        retun = GetDBoutTime( atol(gatTxnInf[nRouteIndex].msg_to),timecurt ,timeout);
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,"insert cur time return: [%d]",retun);
    
   /* long lCurrTime = time(NULL);
    long lToTime;
    char  timecurt[100]={0};

  
    strftime(timecurt, sizeof(timecurt), "%Y-%m-%d %H:%M:%S",
             localtime((time_t*)(&lCurrTime)));
    
   HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
              "insert cur time: %s",timecurt);

   lToTime = lCurrTime + gatTxnRouteInf[nRouteIndex].nToTime;
    strftime(gsTimeOutTs, sizeof(gsTimeOutTs), "%Y-%m-%d %H:%M:%S",
             localtime((time_t*)(&lToTime)));*/
             
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "insert cur time: %s",timecurt);
    if(retun == 0)
    {
        memcpy(gsTimeCurTs,timecurt,4);       /*year*/
        memcpy(gsTimeCurTs+4,timecurt+5,2);   /*month*/
        memcpy(gsTimeCurTs+6,timecurt+8,2);   /*day*/
        memcpy(gsTimeCurTs+8,timecurt+11,2);  /*hour*/
        memcpy(gsTimeCurTs+10,timecurt+14,2); /*minute*/
        memcpy(gsTimeCurTs+12,timecurt+17,2); /*second*/
    }
    else
        CommonGetCurrentTime(gsTimeCurTs);
        
   HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "insert txn+ti timeout: %s",timeout);
    memcpy(gsTimeOutTs,timeout,strlen(timeout));
   HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "insert txn+ti time: %s",gsTimeOutTs);
 
    if (atoi(gatTxnInf[nRouteIndex].msg_to) > 0)
        gnTimeOutFlag = 1;
    else
        gnTimeOutFlag = 0;

   HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
              "TXN toTime value : %d gnTimeOutFlag:%d ",atoi(gatTxnInf[nRouteIndex].msg_to),gnTimeOutFlag);
}
