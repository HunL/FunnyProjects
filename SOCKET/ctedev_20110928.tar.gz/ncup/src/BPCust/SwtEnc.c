#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "HtLog.h"
#include "EncOpr.h"
#include "IpcInt.h"
#include "SwtEnc.h"
#include "TxnNum.h"
#include "DbsDef.h"
#include "SrvDef.h"

extern char gsLogFile[LOG_NAME_LEN_MAX];

typedef struct
{
    int  iTagLen;
	char sTagVal[5];
} st_F055Tag;

st_F055Tag sF055Tag[] = 
{
    {4,"9F26"},
    {4,"9F27"},
    {4,"9F10"},
    {4,"9F37"},
    {4,"9F36"},
    {2,"95"},
    {2,"9A"},
    {2,"9C"},
    {4,"9F02"},
    {4,"5F2A"},
    {2,"82"},
    {4,"9F1A"},
    {4,"9F03"},
    {4,"9F33"}
};

st_F055Tag sF055Tag01[] = 
{
    {4,"9F02"},
    {4,"9F03"},
    {4,"9F1A"},
    {2,"95"},
    {4,"5F2A"},
    {2,"9A"},
    {2,"9C"},
    {4,"9F37"},
    {2,"82"},
    {4,"9F36"},
    {4,"9F10"}
};


int VerifyTermMac(char *sMacBlock, int nMacBlockLen, int nMacKeyLen, char *sMacKey, char *sMac)
{
    int        iRet;
    HSMOprDef  tHsmOpr;

    memset(&tHsmOpr, 0, sizeof(tHsmOpr));

    if (8 == nMacKeyLen)
        tHsmOpr.saEncWay[1] = '0';
    else if (16 == nMacKeyLen)
        tHsmOpr.saEncWay[1] = '6';
    else
        return -1;

    tHsmOpr.saOprType = HSM_VERTMMACWITHATM;
    sprintf(tHsmOpr.saMacBlockLen, "%0*d",
            HSM_MAC_BLOCK_LEN_LEN, nMacBlockLen);
    memcpy(tHsmOpr.saMacBlock, sMacBlock, nMacBlockLen);
    memcpy(tHsmOpr.saEnc, sMac, 8);
    iRet = nEncOpr(&tHsmOpr);
    if (iRet)
        return iRet;

    return 0;
}

int GenTermMac(char *sMacBlock, int nMacBlockLen, int nMacKeyLen, char *sMacKey, char *sMac)
{
    int        iRet;
    HSMOprDef  tHsmOpr;

    memset(&tHsmOpr, 0, sizeof(tHsmOpr));

    if (8 == nMacKeyLen)
        tHsmOpr.saEncWay[1] = '0';
    else if (16 == nMacKeyLen)
        tHsmOpr.saEncWay[1] = '6';
    else
        return -1;

    tHsmOpr.saOprType = HSM_GENTMMACWITHATM;
    sprintf(tHsmOpr.saMacBlockLen, "%0*d",
            HSM_MAC_BLOCK_LEN_LEN, nMacBlockLen);
    memcpy(tHsmOpr.saMacBlock, sMacBlock, nMacBlockLen);
    /*memcpy(tHsmOpr.saTmk, sMacKey, 2 * nMacKeyLen); */
    iRet = nEncOpr(&tHsmOpr);
    if (iRet)
        return iRet;

    memcpy(sMac, tHsmOpr.saEnc, 8);
    return 0;
}

int ChangeWorkKey(T_IpcIntMngDef *ptIpcIntMngDef, char *sKey, int nIndex)
{
    int iRet;
    HSMOprDef  tHsmOpr;

    memset(&tHsmOpr, 0, sizeof(tHsmOpr));
    tHsmOpr.saEncWay[0] = ptIpcIntMngDef->sSecurityRelatedInfo[0];
    tHsmOpr.saEncWay[1] = ptIpcIntMngDef->sSecurityRelatedInfo[1];
    tHsmOpr.saOprType = HSM_CHANGETMKEYWITHATM;
    /*tHsmOpr.nTmkIndex = nIndex;*/
    if ('0' == tHsmOpr.saEncWay[1])
        memcpy(tHsmOpr.saEnc, ptIpcIntMngDef->sMsgSecurityCode, 8);
    else if ('6' == tHsmOpr.saEncWay[1])
        memcpy(tHsmOpr.saEnc, ptIpcIntMngDef->sAddtnlDataPrivate + 2, 16);
    else
        return -1;

    iRet = nEncOpr(&tHsmOpr);
    if (iRet)
        return iRet;
    /*memcpy(sKey, tHsmOpr.saTmk, sizeof(tHsmOpr.saTmk));*/
    return 0;
}
#if 0
int GenTermWorkKey(T_IpcIntMngDef *ptIpcIntMngDef, int nTmkIndex, T_Atm_WorkKey *ptWorkKey)
{
    int        iRet, iPos;
    char       sNetMngCd[3];
    HSMOprDef  tHsmOpr;

    if (NULL == ptIpcIntMngDef || NULL == ptWorkKey)
        return -1;

    memset(&tHsmOpr, 0, sizeof(tHsmOpr));

    memcpy(sNetMngCd, &ptIpcIntMngDef->sFldReserved[NETWORK_MNG_CD_POS],
           sizeof(sNetMngCd));
    HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
          "sNetWorkMngCd: [%3.3s]", sNetMngCd);

    ptWorkKey->nMacKeyLen = 8;
    if (!memcmp(sNetMngCd, MNG_DES_FLAG, sizeof(sNetMngCd))) {
        tHsmOpr.saEncWay[1] = '0';
        ptWorkKey->nPinKeyLen = 8;
        ptWorkKey->nTrkKeyLen = 8;
    } else if (!memcmp(sNetMngCd, MNG_3DES_FLAG, sizeof(sNetMngCd))) {
        tHsmOpr.saEncWay[1] = '6';
        ptWorkKey->nPinKeyLen = 16;
        ptWorkKey->nTrkKeyLen = 16;
    } else
        return -1;

    tHsmOpr.saOprType = HSM_GENTMWKWITHATM;
    /*tHsmOpr.nTmkIndex = nTmkIndex;*/
    iRet = nEncOpr(&tHsmOpr);
    if (iRet)
        return iRet;

    iPos = 0;
    /* PIN KEY */
    memcpy(ptWorkKey->sLmkPinKey, tHsmOpr.saMacBlock + iPos, 2 * ptWorkKey->nPinKeyLen);
    iPos += 2 * ptWorkKey->nPinKeyLen;
    memcpy(ptWorkKey->sZmkPinKey,
           tHsmOpr.saMacBlock + iPos, ptWorkKey->nPinKeyLen);
    iPos += ptWorkKey->nPinKeyLen;
    memcpy(ptWorkKey->sPinKeyChkValue,
           tHsmOpr.saMacBlock + iPos, CHK_EXPAND_VALUE_LEN);
    iPos += CHK_EXPAND_VALUE_LEN;

    /* MAC KEY */
    memcpy(ptWorkKey->sLmkMacKey, tHsmOpr.saMacBlock + iPos, 2 * ptWorkKey->nMacKeyLen);
    iPos += 2 * ptWorkKey->nMacKeyLen;
    memcpy(ptWorkKey->sZmkMacKey, tHsmOpr.saMacBlock + iPos, ptWorkKey->nMacKeyLen);
    iPos += ptWorkKey->nMacKeyLen;
    memcpy(ptWorkKey->sMacKeyChkValue, tHsmOpr.saMacBlock + iPos, CHK_EXPAND_VALUE_LEN);
    iPos += CHK_EXPAND_VALUE_LEN;

    /* DATA KEY */
    memcpy(ptWorkKey->sLmkTrkKey, tHsmOpr.saMacBlock + iPos, 2 * ptWorkKey->nTrkKeyLen);
    iPos += 2 * ptWorkKey->nTrkKeyLen;
    memcpy(ptWorkKey->sZmkTrkKey, tHsmOpr.saMacBlock + iPos, ptWorkKey->nTrkKeyLen);
    iPos += ptWorkKey->nTrkKeyLen;
    memcpy(ptWorkKey->sTrkKeyChkValue, tHsmOpr.saMacBlock + iPos, CHK_EXPAND_VALUE_LEN);
    iPos += CHK_EXPAND_VALUE_LEN;

    return 0;
}
#endif
int TransPanTrack(T_IpcIntTxnDef *ptIpcIntTxnDef, char *sTrkKeyVal, char * sTrkKeyLen)
{
    int        nRet,nTrkKeyLen;
    HSMOprDef  tHsmOpr;
    char       sDataBlock[512];
    int        nDataBlockLen = 512;
    int        nValLen,nPosn,nTrack1Len,nTrack2Len;
    char       sDataBlockLen[300],sDisFlag[2];
    char       sValLen[10],sOrigData[512];

    memset(&tHsmOpr, 0, sizeof(tHsmOpr));

    nTrkKeyLen = atoi(sTrkKeyLen);

    if ( 8 == nTrkKeyLen )
       tHsmOpr.saEncWay[1] = '0';
    else if (16 == nTrkKeyLen)
       tHsmOpr.saEncWay[1] = '6';
    else
       return -1;

    memcpy(tHsmOpr.saRout + 6, "00", 2);
    tHsmOpr.saRout[5] = 'Y';
    tHsmOpr.saOprType = HSM_DISPANTRACKWITHATM;

    nRet = GenPanTrack(ptIpcIntTxnDef, sTrkKeyVal, sTrkKeyLen, sDataBlock, &nDataBlockLen);
    if (nRet)
       return nRet;

    HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
                   sDataBlock, nDataBlockLen);

    memset(sDisFlag, 0, sizeof(sDisFlag));
    memcpy(sDisFlag, sDataBlock, 1);
    sprintf(tHsmOpr.saMacBlockLen, "%0*d",
            HSM_MAC_BLOCK_LEN_LEN, nDataBlockLen);
    memcpy(tHsmOpr.saMacBlock, sDataBlock, nDataBlockLen);
    /*memcpy(tHsmOpr.saTmk, sTrkKeyVal, 2 * nTrkKeyLen);*/
    nRet = nEncOpr(&tHsmOpr);
    if (nRet)
        return nRet;

    HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,
                   tHsmOpr.saMacBlock, 100);
    nDataBlockLen = 0;
    nTrack1Len = 0;
    nTrack2Len = 0;
    memset(sDataBlockLen, 0, sizeof(sDataBlockLen));
    memset(sDataBlock, 0, sizeof(sDataBlock));
    memset(sOrigData, 0, sizeof(sOrigData));
    memcpy(sDataBlockLen, tHsmOpr.saMacBlock, 3);
    nDataBlockLen = atoi(sDataBlockLen);
    memcpy(sOrigData, tHsmOpr.saMacBlock+3, nDataBlockLen);
    if (sDisFlag[0] == '1') {
        if (ptIpcIntTxnDef->cF002Ind == FLAG_YES_C) {
           nPosn = 0;
           memset(sDataBlock, 0, sizeof(sDataBlock));
           bcd_to_asc (sDataBlock , sOrigData, 2*nDataBlockLen , 0);
           memset(sValLen, 0, sizeof(sValLen));
           memcpy(sValLen, sDataBlock+nPosn, 2);
           nValLen = atoi(sValLen);
           /* ���� */
           memset(&ptIpcIntTxnDef->sPrimaryAcctNum[0], ' ', F002_VAL_LEN);
           memcpy(ptIpcIntTxnDef->sPrimaryAcctNumLen, sValLen, 2);
           nPosn += 2;
           memcpy(ptIpcIntTxnDef->sPrimaryAcctNum, sDataBlock+nPosn, nValLen);
           nPosn += nValLen;

           memset(sDataBlockLen, 0, sizeof(sDataBlockLen));
           memset(sOrigData, 0, sizeof(sOrigData));
           if (ptIpcIntTxnDef->cF035Ind == FLAG_YES_C) {
               memcpy(sDataBlockLen, tHsmOpr.saMacBlock+3+nDataBlockLen, 3);
               nTrack1Len = atoi(sDataBlockLen);
               memcpy(sOrigData, tHsmOpr.saMacBlock+3+nDataBlockLen+3, nTrack1Len);
           } else if (ptIpcIntTxnDef->cF036Ind == FLAG_YES_C) {
               memcpy(sDataBlockLen, tHsmOpr.saMacBlock+3+nDataBlockLen, 3);
               nTrack2Len = atoi(sDataBlockLen);
               memcpy(sOrigData, tHsmOpr.saMacBlock+3+nDataBlockLen+3, nTrack2Len);
           } else
               return 0;
        }
        if (ptIpcIntTxnDef->cF035Ind == FLAG_YES_C) {
           nPosn = 0;
           memset(sDataBlock, 0, sizeof(sDataBlock));
           if (ptIpcIntTxnDef->cF002Ind == FLAG_YES_C)
               bcd_to_asc (sDataBlock , sOrigData, 2*nTrack1Len , 0);
           else
               bcd_to_asc (sDataBlock , sOrigData, 2*nDataBlockLen, 0);
           memset(sValLen, 0, sizeof(sValLen));
           memcpy(sValLen, sDataBlock, 2);
           nValLen = atoi(sValLen);
           nPosn += 2;
           memcpy(ptIpcIntTxnDef->sTrack2DataLen, sValLen, 2);
           memcpy(ptIpcIntTxnDef->sTrack2Data, sDataBlock+nPosn, nValLen);
           nPosn += nValLen;

           memset(sDataBlockLen, 0, sizeof(sDataBlockLen));
           memset(sOrigData, 0, sizeof(sOrigData));
           if (ptIpcIntTxnDef->cF002Ind == FLAG_YES_C &&
               ptIpcIntTxnDef->cF036Ind == FLAG_YES_C) {
               memcpy(sDataBlockLen, tHsmOpr.saMacBlock+3+nDataBlockLen+3+nTrack1Len, 3);
               nTrack2Len = atoi(sDataBlockLen);
               memcpy(sOrigData,tHsmOpr.saMacBlock+3+nDataBlockLen+3+nTrack1Len+3, nTrack2Len);
           }else if (ptIpcIntTxnDef->cF036Ind == FLAG_YES_C){
               memcpy(sDataBlockLen, tHsmOpr.saMacBlock+3+nDataBlockLen, 3);
               nTrack2Len = atoi(sDataBlockLen);
               memcpy(sOrigData, tHsmOpr.saMacBlock+3+nDataBlockLen+3, nTrack2Len);
           } else
               return 0;
        }

        if (ptIpcIntTxnDef->cF036Ind == FLAG_YES_C) {
           nPosn = 0;
           memset(sDataBlock, 0, sizeof(sDataBlock));
           if (ptIpcIntTxnDef->cF002Ind == FLAG_YES_C ||
               ptIpcIntTxnDef->cF035Ind == FLAG_YES_C )
               bcd_to_asc (sDataBlock , sOrigData, 2*nTrack2Len , 0);
           else
               bcd_to_asc (sDataBlock , sOrigData, 2*nDataBlockLen, 0);
           memset(sValLen, 0, sizeof(sValLen));
           memcpy(sValLen, sDataBlock, 4);
           nValLen = atoi(sValLen);
           memcpy(ptIpcIntTxnDef->sTrack3DataLen, sValLen+1, 3);
           nPosn += 3;
           memcpy(ptIpcIntTxnDef->sTrack3Data, sDataBlock+4, nValLen);
           nPosn += nValLen;
        }
      } else {
           /* ���� */
           HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
                 "nDataBlockLen[%d]",nDataBlockLen);
           ptIpcIntTxnDef->cF002Ind = FLAG_YES_C;
           memcpy(ptIpcIntTxnDef->sPrimaryAcctNumLen, sDataBlockLen+1, F002_LEN_LEN);
           memcpy(ptIpcIntTxnDef->sPrimaryAcctNum, sOrigData, nDataBlockLen);
           nPosn += nDataBlockLen;
      }
      return 0;
}

int GenPanTrack(T_IpcIntTxnDef *ptIpcIntTxnDef,
                char *sTrkKeyVal,
                char *sTrkKeyLen,
                char *sDataBlock,
                int *nDataBlockLen)
{
    int   nRet,nTrkKeyLen,nLen;
    int   nPosn,nNum,nPanLen;
    char  sPanLen[256], sBcdBuf[25];
    char  sNum[3],sPanVal[25];

    nNum = 0;
    nPosn = 0;

    nTrkKeyLen = atoi(sTrkKeyLen);

    switch (ptIpcIntTxnDef->sTxnNum[INDEX_TXN_NUM_REQ_RSP]) {
        case TXN_REQ:
             sDataBlock[0] = '1';
             nPosn ++;
             nPosn ++;
             if(ptIpcIntTxnDef->cF002Ind == FLAG_YES_C) {
                nNum ++;
                memcpy(sDataBlock+nPosn, sTrkKeyLen, 2);
                nPosn += 2;
                memcpy(sDataBlock+nPosn, sTrkKeyVal, 2*nTrkKeyLen);
                nPosn += 2*nTrkKeyLen;
                memset(sPanLen, 0, sizeof(sPanLen));
                memcpy(sPanLen, ptIpcIntTxnDef->sPrimaryAcctNumLen, F002_LEN_LEN);
                nPanLen = atoi(sPanLen);
                sprintf(sPanLen, "%03d", nPanLen);
                memcpy(sDataBlock+nPosn, sPanLen, 3);
                nPosn += 3;
                memcpy(sDataBlock+nPosn, ptIpcIntTxnDef->sPrimaryAcctNum, nPanLen);
                nPosn += nPanLen;
             }
             if (ptIpcIntTxnDef->cF035Ind == FLAG_YES_C) {
                nNum ++;
                sprintf(sDataBlock+nPosn, sTrkKeyLen, 2);
                nPosn += 2;
                memcpy(sDataBlock+nPosn, sTrkKeyVal, 2*nTrkKeyLen);
                nPosn += 2*nTrkKeyLen;
                memset(sPanLen, 0, sizeof(sPanLen));
                memcpy(sPanLen, ptIpcIntTxnDef->sTrack2DataLen, 2);
                nPanLen = atoi(sPanLen);
                sprintf(sPanLen, "%03d", nPanLen);
                memcpy(sDataBlock+nPosn, sPanLen, 3);
                nPosn += 3;
                memcpy(sDataBlock+nPosn, ptIpcIntTxnDef->sTrack2Data, nPanLen);
                nPosn += nPanLen;
             }
             if (ptIpcIntTxnDef->cF036Ind == FLAG_YES_C) {
                nNum ++;
                sprintf(sDataBlock+nPosn, sTrkKeyLen,2);
                nPosn += 2;
                memcpy(sDataBlock+nPosn, sTrkKeyVal, 2*nTrkKeyLen);
                nPosn += 2*nTrkKeyLen;
                memset(sPanLen, 0, sizeof(sPanLen));
                memcpy(sPanLen, ptIpcIntTxnDef->sTrack3DataLen, F036_LEN_LEN);
                nPanLen = atoi(sPanLen);
                sprintf(sPanLen, "%03d", nPanLen);
                memcpy(sDataBlock+nPosn, sPanLen, 3);
                nPosn += 3;
                memcpy(sDataBlock+nPosn, ptIpcIntTxnDef->sTrack3Data, nPanLen);
                nPosn += nPanLen;
             }
             sprintf(sNum, "%d", nNum);
             memcpy(sDataBlock+1, sNum, 1);
             *nDataBlockLen = nPosn;
             return 0;
             break;
        case TXN_RSP:
             sDataBlock[0] = '0';
             nPosn ++;
             nPosn ++;
             if (ptIpcIntTxnDef->cF002Ind == FLAG_YES_C) {
                nNum ++;
                sprintf(sDataBlock+nPosn, sTrkKeyLen, 2);
                nPosn += 2;
                memcpy(sDataBlock+nPosn, sTrkKeyVal, 2*nTrkKeyLen);
                nPosn += 2*nTrkKeyLen;
                memset(sPanLen, 0, sizeof(sPanLen));
                memcpy(sPanLen, ptIpcIntTxnDef->sPrimaryAcctNumLen, F002_LEN_LEN);
                nPanLen = atoi(sPanLen)+F002_LEN_LEN;
                nLen = atoi(sPanLen);
                memset(sPanVal, 0x00, nPanLen);
                memcpy(sPanVal, ptIpcIntTxnDef->sPrimaryAcctNumLen, F002_LEN_LEN);
                memcpy(sPanVal+F002_LEN_LEN, ptIpcIntTxnDef->sPrimaryAcctNum, nLen);
                if ( 0 != (nPanLen % 2))
                   nPanLen ++;
                memset(sBcdBuf, 0, sizeof(sBcdBuf));
                asc_to_bcd ( sBcdBuf, sPanVal, nPanLen, 0);
                nLen = nPanLen/2;
                nLen += (16-nLen);
                sprintf(sPanLen, "%03d", nLen);
                memcpy(sDataBlock+nPosn, sPanLen, 3);
                nPosn += 3;
                memcpy(sDataBlock+nPosn, sBcdBuf, nLen);
                nPosn += nLen;
             }
             sprintf(sNum, "%d", nNum);
             memcpy(sDataBlock+1, sNum, 1);
             *nDataBlockLen = nPosn;
             return 0;
             break;
        default:
              return -1;
    }
}

void atm_preprocess_mac_element(char * mac_element, char * mac_element_len)
{
	short len, return_len = 0, mac_element_pos = 0, blank_now = 0;
	char current_char;
	char temp_mac_element[MAX_MAC_ELEMENT_LEN];

	len = (short)numin(mac_element_len, MAX_MAC_ELEMENT_LEN_LEN);
	memcpy(temp_mac_element, mac_element, MAX_MAC_ELEMENT_LEN);
	memset(mac_element, ' ', MAX_MAC_ELEMENT_LEN);

	while (' ' == temp_mac_element[mac_element_pos++]
				&& mac_element_pos != len);

	if (mac_element_pos == len)
     	return_len = 0;
	else
	{
		if (mac_element_pos) mac_element_pos--;

		while (mac_element_pos != len)
		{
			current_char = toupper(temp_mac_element[mac_element_pos++]);

			if (istruealnum(current_char) || '.' == current_char || ',' == current_char)
			{
				if (blank_now) mac_element[return_len++] = ' ';
						blank_now = 0;
				mac_element[return_len++] = current_char;
				continue;
			}

			if (' ' == current_char)
			{
				blank_now = 1;
				continue;
			}
		}
	}

	numout(mac_element_len, MAX_MAC_ELEMENT_LEN_LEN, return_len);
	return;

}

/* ����MAC�� */
int GenMacBlock (T_IpcIntTxnDef *ptIpcIntTxn, char *sMacBlockLen, char *sMacBlock)
{
	#define     MAC_F090_LEN    20
	char        sFuncName[] = "GenMacBlock";
	char        *pcMacPos;
	char        sTmpLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int         nLen;
	char        sLen[4];
	char        sAuthId[6+1];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	/* ���� MAC element including:
	������   0, 7, 11, 39, 53, 70, 100
	������   0, 2, 3, 4, 7, 11, 18, 25, 32, 33, 38, 39, 41, 42, 90 */
	memset (sMacBlock, ' ', HSM_MAC_BLOCK_LEN_MAX);
	pcMacPos = sMacBlock;

	if (ptIpcIntTxn->sTxnNum[0] == TXN_NUM_MANAGE)
	{
		  /* field 0, msg type */
		nLen = F000_MSG_TYPE_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sMsgType, &nLen);
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMsgType[%4.4s] .", ((T_IpcIntMngDef *)ptIpcIntTxn)->sMsgType);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 7, transmision date tiem */
		nLen = F007_LEN;
		  CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sTransmsnDateTime, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 11, ssn */
		nLen = F011_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sSysTraceAuditNum, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 39, response code */
		if (((T_IpcIntMngDef *)ptIpcIntTxn)->sRespCode[0] != ' ' &&
		   ((T_IpcIntMngDef *)ptIpcIntTxn)->sRespCode[0] != 0x00)
		{
			nLen = F039_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sRespCode, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 53, sSecurityRelatedInfo */
		nLen = F053_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sSecurityRelatedInfo, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 70, sNetwkMgmtInfoCode */
		nLen = F070_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sNetwkMgmtInfoCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 100, panlen, pan */
		if (((T_IpcIntMngDef *)ptIpcIntTxn)->cF100Ind == FLAG_YES_C)
		{
			nLen = F100_LEN_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sRcvgInstIdCodeLen, &nLen);
			pcMacPos = pcMacPos + nLen;
			memset(sLen, 0, sizeof(sLen));
			memcpy(sLen, ((T_IpcIntMngDef *)ptIpcIntTxn)->sRcvgInstIdCodeLen, F100_LEN_LEN);
			nLen = atoi(sLen);
			CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sRcvgInstIdCode, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* get rid of the last space */
		pcMacPos--;
		
		/* set MAC block len */
		sprintf (sTmpLen, "%03d", (int)(pcMacPos - sMacBlock));
		memcpy (sMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);
	}
	else
	{
		/* field 0, msg type */
		nLen = F000_MSG_TYPE_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sMsgType, &nLen);
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMsgType[%4.4s] .", ((T_IpcIntTxnDef *)ptIpcIntTxn)->sMsgType);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 2, panlen, pan */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF002Ind == FLAG_YES_C)
		{
			nLen = F002_LEN_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sPrimaryAcctNumLen, &nLen);
			pcMacPos = pcMacPos + nLen;
			memset(sLen, 0, sizeof(sLen));
			memcpy(sLen, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sPrimaryAcctNumLen, F002_LEN_LEN);
			nLen = atoi(sLen);
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sPrimaryAcctNum, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 3, processing code */
		nLen = F003_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sProcessingCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		  HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "F003 .[%6.6s]", ((T_IpcIntTxnDef *)ptIpcIntTxn)->sProcessingCode);
		/* field 4, transaction amount */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->sAmtTrans[0] != ' ' &&
		       ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAmtTrans[0] != 0x00)
		{
			nLen = F004_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAmtTrans, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}

		/* field 7, transmision date tiem */
		nLen = F007_LEN;
	    CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sTransmsnDateTime, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 11, ssn */
		nLen = F011_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sSysTraceAuditNum, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 18, merchant type */
		nLen = F018_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sMchntType, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 25, pos condition code */
		nLen = F025_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sPosCondCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 28, amt trans fee */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF028Ind == FLAG_YES_C)
		{
			nLen = F028_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAmtTransFee, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 32, acquiring inst id */
		nLen = F032_LEN_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcqInstIdCodeLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = 8;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcqInstIdCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 33, forwarding inst id */
		nLen = F033_LEN_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sFwdInstIdCodeLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = 8;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sFwdInstIdCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 38, auth id */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF038Ind == FLAG_YES_C)
		{
			memset(sAuthId, 0, sizeof(sAuthId));
			memcpy(sAuthId, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAuthrIdResp, F038_LEN);
			if(memcmp(sAuthId, "      ", F038_LEN) != 0)
			{
				AllTrim(sAuthId);
				nLen = strlen(sAuthId);
				CopyMacElement (pcMacPos, sAuthId, &nLen);
				pcMacPos = pcMacPos + nLen + 1;
			}
		}
		
		/* field 39, response code */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->sRespCode[0] != ' ' &&
		   ((T_IpcIntTxnDef *)ptIpcIntTxn)->sRespCode[0] != 0x00)
		{
			nLen = F039_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sRespCode, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 41, terminal id */
		nLen = F041_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sCardAccptrTermnlId, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 42, merchant id */
		nLen = F042_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sCardAccptrId, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 90, original data elements */
		if ((ptIpcIntTxn->sTxnNum[0] == TXN_NUM_REVSAL
		    || ptIpcIntTxn->sTxnNum[0] == TXN_NUM_CANCEL
		    || ptIpcIntTxn->sTxnNum[0] == TXN_NUM_CANCEL_REVSAL
		    || ptIpcIntTxn->sTxnNum[0] == TXN_NUM_NOTICE)
		    && ((T_IpcIntTxnDef *)ptIpcIntTxn)->sOrigDataElemts[0] != ' '
		    && ((T_IpcIntTxnDef *)ptIpcIntTxn)->sOrigDataElemts[0] != 0x00)
		{
			nLen = 20;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sOrigDataElemts, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		  /* field 102, panlen, Account Identification 1 */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF102Ind == FLAG_YES_C)
		{
			nLen = F102_LEN_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId1Len, &nLen);
			pcMacPos = pcMacPos + nLen;
			memset(sLen, 0, sizeof(sLen));
			memcpy(sLen, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId1Len, F102_LEN_LEN);
			nLen = atoi(sLen);
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId1, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 103, panlen, Account Identification 2 */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF103Ind == FLAG_YES_C)
		{
			nLen = F103_LEN_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId2Len, &nLen);
			pcMacPos = pcMacPos + nLen;
			memset(sLen, 0, sizeof(sLen));
			memcpy(sLen, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId2Len, F103_LEN_LEN);
			nLen = atoi(sLen);
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId2, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* get rid of the last space */
		pcMacPos--;
		
		/* set MAC block len */
		sprintf (sTmpLen, "%03d", (int)(pcMacPos - sMacBlock));
		memcpy (sMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

	return 0;
}

/* ������������MAC�� */
int GenMacBlock1 (T_IpcIntTxnDef *ptIpcIntTxn, char *sMacBlockLen, char *sMacBlock)
{
	#define     MAC_F090_LEN    20
	char        sFuncName[] = "GenMacBlock1";
	char        *pcMacPos;
	char        sTmpLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int         nLen;
	char        sLen[4];
	char        sAuthId[6+1];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	/* ���� MAC element including:
	������   0, 7, 11, 39, 53, 70, 100
	������   0, 2, 3, 4, 7, 11, 18, 25, 32, 33, 38, 39, 41, 42, 90 */
	memset (sMacBlock, ' ', HSM_MAC_BLOCK_LEN_MAX);
	pcMacPos = sMacBlock;

	if (ptIpcIntTxn->sTxnNum[0] == TXN_NUM_MANAGE)
	{
		  /* field 0, msg type */
		nLen = F000_MSG_TYPE_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sMsgType, &nLen);
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMsgType[%4.4s] .", ((T_IpcIntMngDef *)ptIpcIntTxn)->sMsgType);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 7, transmision date tiem */
		nLen = F007_LEN;
		  CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sTransmsnDateTime, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 11, ssn */
		nLen = F011_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sSysTraceAuditNum, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 39, response code */
		if (((T_IpcIntMngDef *)ptIpcIntTxn)->sRespCode[0] != ' ' &&
		   ((T_IpcIntMngDef *)ptIpcIntTxn)->sRespCode[0] != 0x00)
		{
			nLen = F039_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sRespCode, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 53, sSecurityRelatedInfo */
		nLen = F053_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sSecurityRelatedInfo, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 70, sNetwkMgmtInfoCode */
		nLen = F070_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sNetwkMgmtInfoCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 100, panlen, pan */
		if (((T_IpcIntMngDef *)ptIpcIntTxn)->cF100Ind == FLAG_YES_C)
		{
			nLen = F100_LEN_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sRcvgInstIdCodeLen, &nLen);
			pcMacPos = pcMacPos + nLen;
			memset(sLen, 0, sizeof(sLen));
			memcpy(sLen, ((T_IpcIntMngDef *)ptIpcIntTxn)->sRcvgInstIdCodeLen, F100_LEN_LEN);
			nLen = atoi(sLen);
			CopyMacElement (pcMacPos, ((T_IpcIntMngDef *)ptIpcIntTxn)->sRcvgInstIdCode, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* get rid of the last space */
		pcMacPos--;
		
		/* set MAC block len */
		sprintf (sTmpLen, "%03d", (int)(pcMacPos - sMacBlock));
		memcpy (sMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);
	}
	else
	{
		/* field 0, msg type */
		nLen = F000_MSG_TYPE_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sMsgType, &nLen);
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMsgType[%4.4s] .", ((T_IpcIntTxnDef *)ptIpcIntTxn)->sMsgType);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 2, panlen, pan */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF002Ind == FLAG_YES_C)
		{
			nLen = F002_LEN_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sPrimaryAcctNumLen, &nLen);
			pcMacPos = pcMacPos + nLen;
			memset(sLen, 0, sizeof(sLen));
			memcpy(sLen, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sPrimaryAcctNumLen, F002_LEN_LEN);
			nLen = atoi(sLen);
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sPrimaryAcctNum, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 3, processing code */
		nLen = F003_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sProcessingCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		  HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "F003 .[%6.6s]", ((T_IpcIntTxnDef *)ptIpcIntTxn)->sProcessingCode);
		/* field 4, transaction amount */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->sAmtTrans[0] != ' ' &&
		       ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAmtTrans[0] != 0x00)
		{
			nLen = F004_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAmtTrans, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}

		/* field 7, transmision date tiem */
		nLen = F007_LEN;
        CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sMisc, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 11, ssn */
		nLen = F011_LEN;
        CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sMisc+F007_LEN, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 18, merchant type */
		nLen = F018_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sMchntType, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 25, pos condition code */
		nLen = F025_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sPosCondCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 28, amt trans fee */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF028Ind == FLAG_YES_C)
		{
			nLen = F028_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAmtTransFee, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 32, acquiring inst id */
		nLen = F032_LEN_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcqInstIdCodeLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = 8;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcqInstIdCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 33, forwarding inst id */
		nLen = F033_LEN_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sFwdInstIdCodeLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = 8;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sFwdInstIdCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 38, auth id */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF038Ind == FLAG_YES_C)
		{
			memset(sAuthId, 0, sizeof(sAuthId));
			memcpy(sAuthId, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAuthrIdResp, F038_LEN);
			if(memcmp(sAuthId, "      ", F038_LEN) != 0)
			{
				AllTrim(sAuthId);
				nLen = strlen(sAuthId);
				CopyMacElement (pcMacPos, sAuthId, &nLen);
				pcMacPos = pcMacPos + nLen + 1;
			}
		}
		
		/* field 39, response code */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->sRespCode[0] != ' ' &&
		   ((T_IpcIntTxnDef *)ptIpcIntTxn)->sRespCode[0] != 0x00)
		{
			nLen = F039_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sRespCode, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 41, terminal id */
		nLen = F041_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sCardAccptrTermnlId, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 42, merchant id */
		nLen = F042_LEN;
		CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sCardAccptrId, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
		
		/* field 90, original data elements */
		if ((ptIpcIntTxn->sTxnNum[0] == TXN_NUM_REVSAL
		    || ptIpcIntTxn->sTxnNum[0] == TXN_NUM_CANCEL
		    || ptIpcIntTxn->sTxnNum[0] == TXN_NUM_CANCEL_REVSAL
		    || ptIpcIntTxn->sTxnNum[0] == TXN_NUM_NOTICE)
		    && ((T_IpcIntTxnDef *)ptIpcIntTxn)->sOrigDataElemts[0] != ' '
		    && ((T_IpcIntTxnDef *)ptIpcIntTxn)->sOrigDataElemts[0] != 0x00)
		{
			nLen = 20;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sOrigDataElemts, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		  /* field 102, panlen, Account Identification 1 */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF102Ind == FLAG_YES_C)
		{
			nLen = F102_LEN_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId1Len, &nLen);
			pcMacPos = pcMacPos + nLen;
			memset(sLen, 0, sizeof(sLen));
			memcpy(sLen, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId1Len, F102_LEN_LEN);
			nLen = atoi(sLen);
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId1, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* field 103, panlen, Account Identification 2 */
		if (((T_IpcIntTxnDef *)ptIpcIntTxn)->cF103Ind == FLAG_YES_C)
		{
			nLen = F103_LEN_LEN;
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId2Len, &nLen);
			pcMacPos = pcMacPos + nLen;
			memset(sLen, 0, sizeof(sLen));
			memcpy(sLen, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId2Len, F103_LEN_LEN);
			nLen = atoi(sLen);
			CopyMacElement (pcMacPos, ((T_IpcIntTxnDef *)ptIpcIntTxn)->sAcctId2, &nLen);
			pcMacPos = pcMacPos + nLen + 1;
		}
		
		/* get rid of the last space */
		pcMacPos--;
		
		/* set MAC block len */
		sprintf (sTmpLen, "%03d", (int)(pcMacPos - sMacBlock));
		memcpy (sMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

	return 0;
}

/* �ܿ�ʹ�� */
int GenMacBlock4CupsMng (T_IpcIntMngDef *ptIpcIntMng, char *sMacBlockLen, char *sMacBlock)
{
	#define     MAC_F090_LEN    20
	char        sFuncName[] = "GenMacBlock4CupsMng";
	char        *pcMacPos;
	char        sTmpLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int         nLen;
	char        sLen[4];
	char        sAuthId[6+1];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	/* ����ͳһ���� MAC element including:
	����ͷ   ������ʶ,����ϸ��,ҵ��ϵͳ,��������,��������,���׷������� */
	memset (sMacBlock, ' ', HSM_MAC_BLOCK_LEN_MAX);
	pcMacPos = sMacBlock;
    
#if 0
    /* ������ʶ */
    nLen = 3;
    CopyMacElement (pcMacPos, "EXG", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* ����ϸ�� */
    nLen = 1;
    CopyMacElement (pcMacPos, "1", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* ҵ��ϵͳ */
    nLen = 4;
    CopyMacElement (pcMacPos, "EXGS", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* �������� */
    nLen = 6;
    if(memcmp(ptIpcIntMng->sTxnNum, "6405", 4) == 0)
        CopyMacElement (pcMacPos, "BAT601", &nLen);
    else if(memcmp(ptIpcIntMng->sTxnNum, "6415", 4) == 0)
        CopyMacElement (pcMacPos, "BAT602", &nLen);
    else if(memcmp(ptIpcIntMng->sTxnNum, "6415", 4) == 0)
        CopyMacElement (pcMacPos, "BAT603", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* �������� */
    nLen = 8;
    CopyMacElement (pcMacPos, "        ", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* ���׷������� */
    nLen = 3;
    CopyMacElement (pcMacPos, "EXG", &nLen);
    pcMacPos = pcMacPos + nLen;
#endif
	
	/* ������,Lib��,File��,Member��,�������� (�ļ��ϴ�����֪ͨ) */
	if(memcmp(ptIpcIntMng->sTxnNum, "6405", 4) == 0 ||
	    memcmp(ptIpcIntMng->sTxnNum, "6406", 4) == 0)
	{
	    nLen = 6;
	    CopyMacElement (pcMacPos, "      ", &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    nLen = 10;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sCreditsNum, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    nLen = 10;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sCreditsRevsalNum, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    nLen = 10;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sDebitsNum, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    nLen = 8;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sHostDate, &nLen);
	    pcMacPos = pcMacPos + nLen;
	}
	/* ��������,��Ŀ����,�ļ��� (�ļ�����) */
	else if(memcmp(ptIpcIntMng->sTxnNum, "6415", 4) == 0 ||
	        memcmp(ptIpcIntMng->sTxnNum, "6416", 4) == 0)
	{
	    nLen = 8;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sHostDate, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    nLen = 10;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sDebitsRevsalNum, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    nLen = 10;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sTransferNum, &nLen);
	    pcMacPos = pcMacPos + nLen;
	}
	/* ԭ��������,ԭ������ˮ (�ļ�״̬��ѯ) */
	else if(memcmp(ptIpcIntMng->sTxnNum, "6425", 4) == 0 ||
	        memcmp(ptIpcIntMng->sTxnNum, "6426", 4) == 0)
	{
	    nLen = 8;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sAddtnlDataPrivate+2, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    nLen = 22;
	    CopyMacElement (pcMacPos, ptIpcIntMng->sAddtnlDataPrivate, &nLen);
	    pcMacPos = pcMacPos + nLen;
	}
	
	/* set MAC block len */
	sprintf (sTmpLen, "%03d", (int)(pcMacPos - sMacBlock));
	memcpy (sMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

	return 0;
}

/* �ܿ�ʹ�� */
int GenMacBlock4CupsTxn (T_IpcIntTxnDef *ptIpcIntTxn, char *sMacBlockLen, char *sMacBlock)
{
	#define     MAC_F090_LEN    20
	char        sFuncName[] = "GenMacBlock4CupsTxn";
	char        *pcMacPos;
	char        sTmpLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int         nLen, i;
	char        sLen[4];
	char        sAuthId[6+1];

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	/* ����ͳһ���� MAC element including:
	����ͷ   ������ʶ,����ϸ��,ҵ��ϵͳ,��������,��������,���׷������� */
	memset (sMacBlock, ' ', HSM_MAC_BLOCK_LEN_MAX);
	pcMacPos = sMacBlock;
    
#if 0
    /* ������ʶ */
    nLen = 3;
    CopyMacElement (pcMacPos, "EXG", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* ����ϸ�� */
    nLen = 1;
    CopyMacElement (pcMacPos, "1", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* ҵ��ϵͳ */
    nLen = 4;
    CopyMacElement (pcMacPos, "EXGS", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* �������� */
    nLen = 6;
    if(memcmp(ptIpcIntTxn->sTxnNum, "1383", 4) == 0)
        CopyMacElement (pcMacPos, "DEP605", &nLen);
    else if(memcmp(ptIpcIntTxn->sTxnNum, "2383", 4) == 0)
        CopyMacElement (pcMacPos, "DEP606", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* �������� */
    nLen = 8;
    CopyMacElement (pcMacPos, "        ", &nLen);
    pcMacPos = pcMacPos + nLen;
    
    /* ���׷������� */
    nLen = 3;
    if(memcmp(&ptIpcIntTxn->sFldReserved[8], "03", 2) == 0 ||
	    memcmp(&ptIpcIntTxn->sFldReserved[8], "10", 2) == 0)
	{
	    CopyMacElement (pcMacPos, "POS", &nLen);
	}
	else
	{
	    CopyMacElement (pcMacPos, "   ", &nLen);
	}
	pcMacPos = pcMacPos + nLen;
#endif

	i = 0;
	/* Ȧ������ */
	if(memcmp(ptIpcIntTxn->sTxnNum, "1383", 4) == 0 ||
	    memcmp(ptIpcIntTxn->sTxnNum, "1385", 4) == 0)
	{
	    /* ���� */
	    i += 16;
	    /* ����2 */
	    i += 16;
	    /* LMK ����ֵ */
	    i += 16;
	    /* ZMK ����ֵ */
	    i += 16;
	    /* PINУ��ֵ */
	    i += 8;
	    /* MACУ��ֵ */
	    i += 8;
	    /* ���������� */
	    i += 29;
	    
	    /* ����ϸ�� */
	    nLen = 3;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 3;
	    
	    /* ������ */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ������ */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ת���������� */
	    nLen = 4;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 4;
	    
	    /* ת���ʺ����� */
	    nLen = 1;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 1;
	    
	    /* ת������/�˺� */
	    nLen = 19;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sPrimaryAcctNum, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    /* �ұ� */
	    nLen = 3;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 3;
	    
	    /* ���׽�� */
	    nLen = 7;
	    CopyMacElement (pcMacPos, "0000000", &nLen);
	    pcMacPos = pcMacPos + nLen;
	    nLen = 12;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sAmtTrans, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    /* ��ŵ���־ */
	    i += 1;
	    /* ���ܱ�׼ */
	    i += 1;
	    /* ���ܱ�־ */
	    i += 1;
	    /* �������� */
	    i += 1;
        
	    /* ��������ȡ��־ */
	    nLen = 1;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 1;
	    
	    /* ��ȡ�����ѷ�ʽ */
	    nLen = 1;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 1;
	    
	    /* �����ѽ�� */
	    nLen = 19;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 19;
	    
	    /* ���׹�Ա�� */
        i += 4;
        /* ��Ȩ���� */
        i += 4;
	    
	    /* �������� */
	    nLen = 8;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 8;
	    
	    /* ժҪ���� */
	    nLen = 3;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 3;
	    
	    /* �����־ */
	    nLen = 1;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 1;
	    
	    /* ���� */
        i += 100;
	    
	}
	/* Ȧ��Ӧ�� */
	if(memcmp(ptIpcIntTxn->sTxnNum, "1384", 4) == 0 ||
	    memcmp(ptIpcIntTxn->sTxnNum, "1386", 4) == 0)
	{
	    /* ���� */
	    i += 16;
	    /* ����2 */
	    i += 16;
	    /* LMK ����ֵ */
	    i += 16;
	    /* ZMK ����ֵ */
	    i += 16;
	    /* PINУ��ֵ */
	    i += 8;
	    /* MACУ��ֵ */
	    i += 8;
	    /* ���������� */
	    i += 29;
	    
	    /* ����ϸ�� */
	    nLen = 3;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 3;
	    
	    /* ������ */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ������ */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ת���������� */
	    i += 4;
	    
	    /* ת���ʺ����� */
	    i += 1;
	    
	    /* ת������/�˺� */
	    nLen = 19;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sPrimaryAcctNum, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    /* �ұ� */
	    nLen = 3;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 3;
	    
	    /* ���׽�� */
	    nLen = 7;
	    CopyMacElement (pcMacPos, "0000000", &nLen);
	    pcMacPos = pcMacPos + nLen;
	    nLen = 12;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sAmtTrans, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    /* ��ŵ���־ */
	    i += 1;
	    /* ���ܱ�׼ */
	    i += 1;
	    /* ���ܱ�־ */
	    i += 1;
	    /* �������� */
	    i += 1;
        
	    /* ��������ȡ��־ */
	    i += 1;
	    
	    /* ��ȡ�����ѷ�ʽ */
	    nLen = 1;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 1;
	    
	    /* ʵ�������ѽ�� */
	    nLen = 19;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 19;
	    
	    /* ת���ʺſ������ */
	    nLen = 7;
	    CopyMacElement (pcMacPos, "0000000", &nLen);
	    pcMacPos = pcMacPos + nLen;
	    nLen = 12;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sAddtnlAmt, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    
	    /* ���׹�Ա�� */
        i += 4;
        /* ��Ȩ���� */
        i += 4;
	    
	    /* �������� */
	    nLen = 8;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sHostDate, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 8;
	    
	    /* ժҪ���� */
	    i += 3;
	    
	    /* �����־ */
	    i += 1;
	    
	    /* ���� */
        i += 100;
	    
	}
	/* Ȧ��������� */
	else if(memcmp(ptIpcIntTxn->sTxnNum, "2383", 4) == 0 ||
	        memcmp(ptIpcIntTxn->sTxnNum, "2385", 4) == 0)
	{
	    /* ԭ��Χ������ˮ�� */
	    i += 22;
	    /* ԭ��Χ�������� */
	    i += 8;
        
	    /* ԭ��Χ����ʱ�� */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ԭ���������� */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ԭ����ϸ�� */
	    nLen = 3;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 3;
	    
	    /* ������ */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ������ */
	    i += 6;
	    /* ת������ */
	    i += 19;
	    /* ���׽�� */
	    i += 19;
	    /* �ұ� */
	    i += 3;
	    /* ժҪ���� */
        i += 3;
        /* �������� */
        i += 8;
        /* ���� */
        i += 256;
	}
	/* Ȧ�����Ӧ�� */
	else if(memcmp(ptIpcIntTxn->sTxnNum, "2384", 4) == 0 ||
	        memcmp(ptIpcIntTxn->sTxnNum, "2386", 4) == 0)
	{
	    /* ԭ��Χ������ˮ�� */
	    i += 22;
	    /* ԭ��Χ�������� */
	    i += 8;
        
	    /* ԭ��Χ����ʱ�� */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ԭ���������� */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ԭ����ϸ�� */
	    nLen = 3;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 3;
	    
	    /* ������ */
	    nLen = 6;
	    CopyMacElement (pcMacPos, ptIpcIntTxn->sF059Val+i, &nLen);
	    pcMacPos = pcMacPos + nLen;
	    i += 6;
	    
	    /* ������ */
	    i += 6;
	    /* ת������ */
	    i += 19;
	    /* ���׽�� */
	    i += 19;
	    /* �ұ� */
	    i += 3;
	    /* ժҪ���� */
        i += 3;
        /* �������� */
        i += 8;
        /* ���� */
        i += 256;
	}
	
	/* set MAC block len */
	sprintf (sTmpLen, "%03d", (int)(pcMacPos - sMacBlock));
	memcpy (sMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

	return 0;
}


int CopyMacElement (char *pcMacPos, char *sMacElement, int *pnMacElementLen)
{
	memcpy (pcMacPos, sMacElement, *pnMacElementLen);
	return 0;
}


#if 0
int istruealnum(char c)
{
	if ('a' <= c && c <= 'z') return 1;
	if ('A' <= c && c <= 'Z') return 1;
	if ('0' <= c && c <= '9') return 1;

	return 0;
}
#endif
long numin(char * str, short len)
{
	char buf[50];

	memcpy(buf, str, len);
	buf[len] = 0;

	return (atol(buf));
}

void numout(char * str, short len, long num)
{
	char buf[51];

	sprintf(buf, "%050ld", num);
	memcpy(str, buf + 50 - len, len);

	return;
}

#if 0
/*add by yao 20091116ͨ�����ܻ���������Կ*/
int GenNewMacKey (char *TermId, char *NewMacKey, char *NewMacKeyC )
{
        char            sFuncName[] = "GenNewMacKey";
        char            sHsmIndexATM[HSM_INDEX_LEN+1];
        int             nReturnCode;
        HSMOprDef       tHsmOpr;
        Tbl_atm_stat_Def tTblAtmStatInf;

        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

        memset(&tTblAtmStatInf, 0, sizeof(tTblAtmStatInf));
        memcpy(tTblAtmStatInf.terminal_code, TermId, F041_LEN);

        nReturnCode = DbsAtmStat(DBS_SELECT1, &tTblAtmStatInf);
        if (nReturnCode) {
          HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "term_id not fund  error %d.", tTblAtmStatInf.terminal_code, nReturnCode);
          return nReturnCode;
        }

        memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

        /*���ܻ�����Կ*/
        if(memcmp(tTblAtmStatInf.comm_pid, "1601", 4)==0)
        {
          /*�ɰ汾�ӿ�����Կ*/
          if(tTblAtmStatInf.terminal_vendor[0] == ' ')
          {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get sHsmIndexAtm Old error.");
            return -1;
          }
          else
          {
            memcpy(sHsmIndexATM, tTblAtmStatInf.terminal_vendor, 4);
          }
        }
        else
        {
          /*�°汾�ӿ�����Կ*/
          if(tTblAtmStatInf.atm_bmk[0] == ' ')
          {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get sHsmIndexAtm error.");
            return -1;
          }
          else
          {
            memcpy(sHsmIndexATM, tTblAtmStatInf.atm_bmk, 4);
          }
        }

        tHsmOpr.saOprType = HSM_NEWMACKEYWITHATM;
        tHsmOpr.saRout[0] = 'Y';
        memcpy (tHsmOpr.saRout+1, sHsmIndexATM, HSM_INDEX_LEN);

        nReturnCode = nEncOpr (&tHsmOpr);
        if (nReturnCode != HSM_SUCCESS)
        {
            /*HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);*/
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr HSM_NEWMACKEYWITHATM error.");
            return -1;
        }

        memcpy(NewMacKey,tHsmOpr.saMacBlock,16);
        memcpy(NewMacKeyC,&tHsmOpr.saMacBlock[16],16);
        /*HtLog ("SON.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "NewMac=[%32.32s]",tHsmOpr.saMacBlock);*/

        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
        return 0;
}

int GenNewPinKey (char *TermId, char *NewPinKey, char *NewPinKeyC )
{
        char            sFuncName[] = "GenNewPinKey";
        char            sHsmIndexATM[HSM_INDEX_LEN+1];
        int             nReturnCode;
        HSMOprDef       tHsmOpr;
        Tbl_atm_stat_Def tTblAtmStatInf;

        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

        memset(&tTblAtmStatInf, 0, sizeof(tTblAtmStatInf));
        memcpy(tTblAtmStatInf.terminal_code, TermId, F041_LEN);

        nReturnCode = DbsAtmStat(DBS_SELECT1, &tTblAtmStatInf);
        if (nReturnCode) {
          HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "term_id not fund  error %d.", tTblAtmStatInf.terminal_code, nReturnCode);
          return nReturnCode;
        }

        memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

        /*���ܻ�����Կ*/
        if(tTblAtmStatInf.atm_bmk[0] == ' ')
        {
          HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get sHsmIndexAtm error.");
          return -1;
        }
        else
        {
          memcpy(sHsmIndexATM, tTblAtmStatInf.atm_bmk, 4);
        }

        tHsmOpr.saOprType = HSM_NEWPINKEYWITHATM;
        tHsmOpr.saRout[0] = 'Y';
        memcpy (tHsmOpr.saRout+1, sHsmIndexATM, HSM_INDEX_LEN);

        nReturnCode = nEncOpr (&tHsmOpr);
        if (nReturnCode != HSM_SUCCESS)
        {
            /*HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);*/
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr HSM_NEWPINKEYWITHATM error.");
            return -1;
        }
        memcpy(NewPinKey,tHsmOpr.saMacBlock,32);
        memcpy(NewPinKeyC,&tHsmOpr.saMacBlock[32],16);

        /*HtLog ("SON.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "NewPin=[%48.48s]",tHsmOpr.saMacBlock);*/

        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
        return 0;
}
/*add end*/
#endif

int GenMacBlockOld (char *sMacBlockLen, char *sMacBlock, T_IpcIntTxnDef *ptIpcIntTxn)
{
	#define     MAC_F090_LEN    20
	char        sFuncName[] = "GenMacBlock";
	char        *pcMacPos;
	char        sTmpLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int         nLen;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	/* MAC element including:
	   0, 2, 3, 4, 7, 11, 18, 25, 32, 33, 38, 39, 41, 42, 90 */
	memset (sMacBlock, ' ', HSM_MAC_BLOCK_LEN_MAX);
	pcMacPos = sMacBlock;

	/* field 0, msg type */
	nLen = F000_MSG_TYPE_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sMsgType, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 2, panlen, pan */
	if (ptIpcIntTxn->cF002Ind == FLAG_YES_C)
	{
		nLen = F002_LEN_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sPrimaryAcctNumLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = F002_VAL_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sPrimaryAcctNum, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* field 3, processing code */
	nLen = F003_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sProcessingCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 4, transaction amount */
	nLen = F004_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sAmtTrans, &nLen);
	if (nLen > 0)
		pcMacPos = pcMacPos + nLen + 1;

	/* field 7, transmision date tiem */
	nLen = F007_LEN;
	if(memcmp(ptIpcIntTxn->sMsgDestId,"1601",4)==0)
			CopyMacElement (pcMacPos, ptIpcIntTxn->sTransmsnDateTime, &nLen);
	else
			CopyMacElement (pcMacPos, ptIpcIntTxn->sAcqInstResvd, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 11, ssn */
	nLen = F011_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sSysTraceAuditNum, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/* field 18, merchant type */
	if (memcmp (ptIpcIntTxn->sMsgType, "0430", 4) != 0)
	{
		nLen = F018_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sMchntType, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* field 25, pos condition code
	nLen = F025_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sPosCondCode, &nLen);
	pcMacPos = pcMacPos + nLen + 1;*/

	if (memcmp (ptIpcIntTxn->sMsgDestId, "1601", SRV_ID_LEN) == 0)
	{
		nLen = F032_LEN_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sAcqInstIdCodeLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = F032_VAL_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sAcqInstIdCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;

		nLen = F033_LEN_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sFwdInstIdCodeLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = F033_VAL_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sFwdInstIdCode, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* field 38, auth id */
	if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
	{
		nLen = F038_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sAuthrIdResp, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/* field 39, response code */
	nLen = F039_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sRespCode, &nLen);
	if (nLen > 0)
		pcMacPos = pcMacPos + nLen + 1;

	if (memcmp (ptIpcIntTxn->sTxnNum, TXN_NUM_TRT_TDB_RSP, FLD_TXN_NUM_LEN) != 0 &&
			memcmp (ptIpcIntTxn->sTxnNum, TXN_NUM_TVT_TDB_RSP, FLD_TXN_NUM_LEN) != 0)
	{
		/* field 41, terminal id */
		nLen = F041_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sCardAccptrTermnlId, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}

	/*49
	if (memcmp (ptIpcIntTxn->sMsgDestId, "1601", SRV_ID_LEN) == 0)
	{
		nLen = F049_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sCurrcyCodeTrans, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}*/

	/*60
	if (memcmp (ptIpcIntTxn->sMsgDestId, "1600", SRV_ID_LEN) == 0)
	{
		nLen = F060_LEN_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sFldReservedLen, &nLen);
		pcMacPos = pcMacPos + nLen;
		nLen = F060_VAL_LEN;
		CopyMacElement (pcMacPos, ptIpcIntTxn->sFldReserved, &nLen);
		pcMacPos = pcMacPos + nLen + 1;
	}*/

	/* field 90, original data elements */
	nLen = MAC_F090_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sOrigDataElemts, &nLen);
	if (nLen > 0)
		pcMacPos = pcMacPos + nLen + 1;

	if(memcmp(ptIpcIntTxn->sMsgType, "0420", 4)==0 && memcmp (ptIpcIntTxn->sMsgSrcId, "1601", 4)==0)
	{
		pcMacPos--;
		nLen = 22;
		CopyMacElement (pcMacPos, "0000311452000003114520", &nLen);
		if (nLen > 0)
			pcMacPos = pcMacPos + nLen + 1;
	}

	/*102*/
	nLen = F102_LEN_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sAcctId1Len, &nLen);
	pcMacPos = pcMacPos + nLen;
	nLen = F102_VAL_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sAcctId1, &nLen);
	pcMacPos = pcMacPos + nLen + 1;

	/*103*/
	nLen = F103_LEN_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sAcctId2Len, &nLen);
	pcMacPos = pcMacPos + nLen;
	nLen = F103_VAL_LEN;
	CopyMacElement (pcMacPos, ptIpcIntTxn->sAcctId2, &nLen);
	pcMacPos = pcMacPos + nLen + 1;


	/* get rid of the last space */
	pcMacPos--;

	/* set MAC block len */
	sprintf (sTmpLen, "%03d", (int)(pcMacPos - sMacBlock));
	memcpy (sMacBlockLen, sTmpLen, HSM_MAC_BLOCK_LEN_LEN);


	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int GenerateMAC (T_IpcIntTxnDef *ptIpcIntTxn)                    */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                       */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Է��͵������������Ϣ, �ڷ���PackSendǰ���øú�������MAC     */
/*****************************************************************************/
int GenerateMAC (T_IpcIntTxnDef *ptIpcIntTxn )
{
	char		sFuncName[] = "GenerateMAC";
	char		sLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int			nReturnCode;
	HSMOprDef	tHsmOpr;

	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntTxn->sTxnNum:[%4.4s]", ptIpcIntTxn->sTxnNum);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntTxn->sRespCode:[%2.2s]", ptIpcIntTxn->sRespCode);

	if (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_RSP &&
			memcmp (ptIpcIntTxn->sRespCode, "A0", 2) == 0)
	{
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "No need to generate MAC for unsuccess response to CUP.");
		ptIpcIntTxn->cF064Ind = FLAG_YES_C;
		ptIpcIntTxn->cF128Ind = FLAG_YES_C;
	}
	else
	{
		memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

		/* prepare MAC block */
		if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0)
		    nReturnCode = GenMacBlock4CupsTxn (ptIpcIntTxn, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
		else
		    nReturnCode = GenMacBlock (ptIpcIntTxn, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GenMacBlock error, %d.", nReturnCode);
			return -1;
		}

		memset (sLen, 0, sizeof (sLen));
		memcpy (sLen, tHsmOpr.saMacBlockLen, HSM_MAC_BLOCK_LEN_LEN);
		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,  __LINE__, tHsmOpr.saMacBlock, atoi (sLen));

		/* generaate MAC */
		tHsmOpr.saOprType = HSM_GENMAC;
		tHsmOpr.saRout[0] = 'Y';
		if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0)
		    memcpy(&tHsmOpr.saRout[1],"0001",4);
		else if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0)
		    memcpy(&tHsmOpr.saRout[1],"0002",4);
		else if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0)
		    memcpy(&tHsmOpr.saRout[1],"0007",4);
		else if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_MZ, SRV_ID_LEN) == 0)
		    memcpy(&tHsmOpr.saRout[1],"0008",4);
	    else
	    {
	        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, " sMsgDestId [%04.04s] error , not find", ptIpcIntTxn->sMsgDestId);
			return -1;
	    }

		nReturnCode = nEncOpr (&tHsmOpr);
		nReturnCode = 0;
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
			return -1;
		}

		ptIpcIntTxn->cF064Ind = FLAG_YES_C;
		ptIpcIntTxn->cF128Ind = FLAG_YES_C;
		memcpy (ptIpcIntTxn->sMAC064, tHsmOpr.saEnc+16, F064_LEN);
		memcpy (ptIpcIntTxn->sMAC128, tHsmOpr.saEnc+16, F128_LEN);
	}

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int GenerateMACMng (T_IpcIntMngDef *ptIpcIntMng)                 */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                       */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �ܿ�ʹ��                                                          */
/*****************************************************************************/
int GenerateMACMng (T_IpcIntMngDef *ptIpcIntMng )
{
	char		sFuncName[] = "GenerateMACMng";
	char		sLen[HSM_MAC_BLOCK_LEN_LEN+1];
	int			nReturnCode;
	HSMOprDef	tHsmOpr;

	HtLog(	gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntMng->sTxnNum:[%4.4s]", ptIpcIntMng->sTxnNum);
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntMng->sRespCode:[%2.2s]", ptIpcIntMng->sRespCode);

	memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

	/* prepare MAC block */
    nReturnCode = GenMacBlock4CupsMng (ptIpcIntMng, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GenerateMACMng error, %d.", nReturnCode);
		return -1;
	}

	memset (sLen, 0, sizeof (sLen));
	memcpy (sLen, tHsmOpr.saMacBlockLen, HSM_MAC_BLOCK_LEN_LEN);
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,  __LINE__, tHsmOpr.saMacBlock, atoi (sLen));

	/* generaate MAC */
	tHsmOpr.saOprType = HSM_GENMAC;
	tHsmOpr.saRout[0] = 'Y';
    memcpy(&tHsmOpr.saRout[1],"0007",4);

	nReturnCode = nEncOpr (&tHsmOpr);
	nReturnCode = 0;
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
		return -1;
	}

	ptIpcIntMng->cF128Ind = FLAG_YES_C;
	memcpy (ptIpcIntMng->sMAC128, tHsmOpr.saEnc+16, F128_LEN);

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int VerifyMAC (T_IpcIntTxnDef *ptIpcIntTxn )
{
	char        sFuncName[] = "VerifyMAC";
	char        sHsmIndex[HSM_INDEX_LEN+1] = {0};
	HSMOprDef   tHsmOpr;
	int         nReturnCode;
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

	/* prepare MAC block */
	if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0)
	    nReturnCode = GenMacBlock4CupsTxn(ptIpcIntTxn, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
	else
	    nReturnCode = GenMacBlock(ptIpcIntTxn, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GenMacBlock error, %d.", nReturnCode);
		return -1;
	}

	/* ��������ֱ�Ӹ�ֵ���� */
	if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0)
	{
		memcpy(sHsmIndex, "0001", 4);
	}
	else if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0)
	{
		memcpy(sHsmIndex, "0002", 4);
	}
	else if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0)
	{
	    memcpy(sHsmIndex, "0007", 4);
	}
	else
	{
	    memcpy(sHsmIndex, "0008", 4);
	}


	tHsmOpr.saOprType = HSM_VERIFYMAC;
	tHsmOpr.saRout[0] = 'Y';
	memcpy (tHsmOpr.saRout+1, sHsmIndex, HSM_INDEX_LEN);


	memcpy(tHsmOpr.saEnc+16, ptIpcIntTxn->sMAC128, F128_LEN);

	nReturnCode = nEncOpr (&tHsmOpr);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"nEncOpr OprType[%c] error [%d].", tHsmOpr.saOprType, nReturnCode);
		return -1;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/* �ܿ�ʹ�� */
int VerifyMACMng (T_IpcIntMngDef *ptIpcIntMng )
{
	char        sFuncName[] = "VerifyMACMng";
	char        sHsmIndex[HSM_INDEX_LEN+1] = {0};
	HSMOprDef   tHsmOpr;
	int         nReturnCode;
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

	/* prepare MAC block */
    nReturnCode = GenMacBlock4CupsMng(ptIpcIntMng, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GenMacBlock4CupsMng error, %d.", nReturnCode);
		return -1;
	}

    memcpy(sHsmIndex, "0007", 4);

	tHsmOpr.saOprType = HSM_VERIFYMAC;
	tHsmOpr.saRout[0] = 'Y';
	memcpy (tHsmOpr.saRout+1, sHsmIndex, HSM_INDEX_LEN);

	memcpy(tHsmOpr.saEnc+16, ptIpcIntMng->sMAC128, F128_LEN);

	nReturnCode = nEncOpr (&tHsmOpr);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"nEncOpr OprType[%c] error [%d].", tHsmOpr.saOprType, nReturnCode);
		return -1;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/* ������������MAC�� */
int VerifyMAC1 (T_IpcIntTxnDef *ptIpcIntTxn )
{
	char        sFuncName[] = "VerifyMAC1";
	char        sHsmIndex[HSM_INDEX_LEN+1] = {0};
	HSMOprDef   tHsmOpr;
	int         nReturnCode;
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

	/* prepare MAC block */
	if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0)
	    nReturnCode = GenMacBlock4CupsTxn(ptIpcIntTxn, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
	else
	    nReturnCode = GenMacBlock1(ptIpcIntTxn, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GenMacBlock1 error, %d.", nReturnCode);
		return -1;
	}

	/* ��������ֱ�Ӹ�ֵ���� */
	if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0)
	{
		memcpy(sHsmIndex, "0001", 4);
	}
	else if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUPS, SRV_ID_LEN) == 0)
	{
		memcpy(sHsmIndex, "0002", 4);
	}
	else if(memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_ZK, SRV_ID_LEN) == 0)
	{
	    memcpy(sHsmIndex, "0007", 4);
	}
	else
	{
	    memcpy(sHsmIndex, "0008", 4);
	}


	tHsmOpr.saOprType = HSM_VERIFYMAC;
	tHsmOpr.saRout[0] = 'Y';
	memcpy (tHsmOpr.saRout+1, sHsmIndex, HSM_INDEX_LEN);


	memcpy(tHsmOpr.saEnc+16, ptIpcIntTxn->sMAC128, F128_LEN);

	nReturnCode = nEncOpr (&tHsmOpr);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"nEncOpr OprType[%c] error [%d].", tHsmOpr.saOprType, nReturnCode);
		return -1;
	}

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}


int TransferPin (T_IpcIntBonusDef *ptIpcIntTxn )
{
	char    sFuncName[] = "TransferPin";
	int     nReturnCode;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	nReturnCode = SwtCustTransferPin (ptIpcIntTxn);

	if (nReturnCode)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "SwtCustTransferPin error [%d].", nReturnCode);
		return -1;
	}
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int TransferPin4ZK (T_IpcIntTxnDef *ptIpcIntTxn )
{
	char    sFuncName[] = "TransferPin4ZK";
	int     nReturnCode;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	nReturnCode = SwtCustTransferPin4ZK (ptIpcIntTxn);

	if (nReturnCode)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "SwtCustTransferPin4ZK error [%d].", nReturnCode);
		return -1;
	}
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int VerifyARQC (T_IpcIntTxnDef *ptIpcIntTxn )
{
	char        sFuncName[] = "VerifyARQC";
	HSMOprDef   tHsmOpr;
	int         nReturnCode;
	char        sF055Len[F055_LEN_LEN+1], sF055Val[F055_LEN+1], sTagName[2+1];
	char        sF002Len[F002_LEN_LEN+1];
	int         iF002Len, iF055Len, i;
	char        sTempData[22];
	int         iTotLen;
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

	tHsmOpr.saOprType = HSM_VERIFYARQC;
	tHsmOpr.saRout[0] = 'Y';
	memcpy (tHsmOpr.saRout+1, "0010", HSM_INDEX_LEN);
    
    memset(sF055Len, 0, sizeof(sF055Len));
    memcpy(sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
    iF055Len = atoi(sF055Len);
    
    iTotLen = 0;
    /* 5F34 PAN���к� */
    sTagName[0] = 0x5F;
    sTagName[1] = 0x34;
    sTagName[2] = 0x00;
    memset(sF055Val, 0, sizeof(sF055Val));
    memset(sTempData, 0, sizeof(sTempData));
    memset(sF002Len, 0, sizeof(sF002Len));
    memcpy(sF002Len, ptIpcIntTxn->sPrimaryAcctNumLen, F002_LEN_LEN);
    iF002Len = atoi(sF002Len);
    memcpy(sTempData, ptIpcIntTxn->sPrimaryAcctNum, iF002Len);
    nReturnCode = parse_tlv_data(sF055Val, sTagName, ptIpcIntTxn->sICData, iF055Len);
    if(nReturnCode > 0)
        Hex2Str(sF055Val, sTempData+iF002Len, 1);
    else
        memcpy(sTempData+iF002Len, "00", 2);
    iF002Len = strlen(sTempData);
    memcpy(tHsmOpr.saCardNo, sTempData+(iF002Len-16), 16);
    /* ��� PAN���к� */
    memcpy(ptIpcIntTxn->sTransDescrpt+2+iTotLen, tHsmOpr.saCardNo, 16);
    iTotLen += 16;
    
    /*9F36 ATC*/
    sTagName[0] = 0x9F;
    sTagName[1] = 0x36;
    sTagName[2] = 0x00;
    memset(sF055Val, 0, sizeof(sF055Val));
    nReturnCode = parse_tlv_data(sF055Val, sTagName, ptIpcIntTxn->sICData, iF055Len);
    if(nReturnCode > 0)
    {
        /*Hex2Str(sF055Val, tHsmOpr.saPIKChkV, 2);*/
        memcpy(tHsmOpr.saPIKChkV, sF055Val, 2);
        HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "9F36 ATC Value ��");
        HtDebugString ("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, tHsmOpr.saPIKChkV, 2);
    }
    else
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"get 9F36 ATC error [%d]. OprType[%c].", nReturnCode, tHsmOpr.saOprType);
		return -1;
    }
    /* ��� ATC */
    Hex2Str(tHsmOpr.saPIKChkV, ptIpcIntTxn->sTransDescrpt+2+iTotLen, 2);
    iTotLen += 4;
    
    /*��������*/
    iF002Len = 0;
    for(i=0; i<11; i++)
    {
        memset(sTagName, 0, sizeof(sTagName));
        memset(sF055Val, 0, sizeof(sF055Val));
        Str2Hex(sF055Tag01[i].sTagVal, sTagName, sF055Tag01[i].iTagLen);
        /*HtLog("SwtEnc.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "i [%d]", i);
        HtDebugString ("SwtEnc.log", HT_LOG_MODE_ERROR, __FILE__, __LINE__, sTagName, sF055Tag[i].iTagLen/2);*/
        nReturnCode = parse_tlv_data(sF055Val, sTagName, ptIpcIntTxn->sICData, iF055Len);
        if(nReturnCode > 0)
        {
            /*HtDebugString ("SwtEnc.log", HT_LOG_MODE_ERROR, __FILE__, __LINE__, sF055Val, nReturnCode);*/
            if(memcmp(sF055Tag01[i].sTagVal, "9F10", 4) == 0)
            {
                memcpy(tHsmOpr.saMacBlock+iF002Len, sF055Val+3, 4);
                iF002Len += 4;
            }
            else
            {
                memcpy(tHsmOpr.saMacBlock+iF002Len, sF055Val, nReturnCode);
                iF002Len += nReturnCode;
            }
        }
    }
    HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������ݳ���:[%d]", iF002Len);
    HtDebugString ("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, tHsmOpr.saMacBlock, iF002Len);
    
    /*�������ݳ���*/
    /*sprintf(tHsmOpr.saMacBlockLen, "%02d", iF002Len);*/
    /*tHsmOpr.saMacBlockLen[0] = iF002Len % 256;*/
    if(nReturnCode = nMCalcOut(
								iF002Len,
								&tHsmOpr.saMacBlockLen[0],
								1))
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"�������ݳ��� nMCalcOut error [%d].", nReturnCode);
		return -1;
    }
    
    /*ARQC*/
    sTagName[0] = 0x9F;
    sTagName[1] = 0x26;
    sTagName[2] = 0x00;
    memset(sF055Val, 0, sizeof(sF055Val));
    nReturnCode = parse_tlv_data(sF055Val, sTagName, ptIpcIntTxn->sICData, iF055Len);
    if(nReturnCode > 0)
    {
        /*Hex2Str(sF055Val, tHsmOpr.saPIKChkV, 2);*/
        memcpy(tHsmOpr.saPIK, sF055Val, 8);
        HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "9F26 ARQC Value ��");
        HtDebugString ("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, tHsmOpr.saPIK, 8);
    }
    else
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"get 9F26 ARQC error [%d]. no need to gen ARPC.", nReturnCode);
		return 0;
    }
    /* ��� ARQC */
    Hex2Str(tHsmOpr.saPIK, ptIpcIntTxn->sTransDescrpt+2+iTotLen, 8);
    iTotLen += 16;
    
    /* �����ų��� */
    memset(sTempData, 0, sizeof(sTempData));
	sprintf(sTempData, "%02d", iTotLen);
	memcpy(ptIpcIntTxn->sTransDescrpt, sTempData, 2);
	
	nReturnCode = nEncOpr (&tHsmOpr);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"nEncOpr OprType[%c] error [%d].", tHsmOpr.saOprType, nReturnCode);
		return -1;
	}
	
	/* ���ARPC */
	Hex2Str(tHsmOpr.saEnc, ptIpcIntTxn->sTransDescrpt+2+iTotLen, 8);
	iTotLen += 16;
	
	/* �����ų��� */
	memset(sTempData, 0, sizeof(sTempData));
	sprintf(sTempData, "%02d", iTotLen);
	memcpy(ptIpcIntTxn->sTransDescrpt, sTempData, 2);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

int GenScriptMac(T_IpcIntTxnDef *ptIpcIntTxn )
{
    char        sFuncName[] = "GenScriptMac";
	HSMOprDef   tHsmOpr;
	int         nReturnCode;
	char        sF055Len[F055_LEN_LEN+1], sF055Val[F055_LEN+1], sTagName[2+1];
	char        sF002Len[F002_LEN_LEN+1];
	int         iF002Len, iF055Len, i;
	char        sTempData[22];
	int         iTag71Len, iDataLen, iF104Len;
	char        sTag71Val[100];
	char        sTag71Len[4] = {0};
	char        sF104Len[2+1] = {0};
	
	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	
	memset ((char *)&tHsmOpr, 0, sizeof (tHsmOpr));

	tHsmOpr.saOprType = HSM_GENSCRIPTMAC;
	tHsmOpr.saRout[0] = 'Y';
	memcpy (tHsmOpr.saRout+1, "0010", HSM_INDEX_LEN);
    
    memset(sF055Len, 0, sizeof(sF055Len));
    memcpy(sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
    iF055Len = atoi(sF055Len);
    
    /* û��ԭʼ���ݣ����� */
    if(ptIpcIntTxn->sTransDescrpt[0] == ' ' || ptIpcIntTxn->sTransDescrpt[0] == 0x00)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"GenScriptMac error ,Field sTransDescrpt no data.");
		return -1;
    }
    
    memcpy(sF104Len, ptIpcIntTxn->sTransDescrpt, 2);
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ic data len [%s]", sF104Len);
    if(atoi(sF104Len) <= 0)
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"GenScriptMac error ,Field sTransDescrpt no data.");
		return -1;
    }
    
    iF104Len = 0;
    /* ȡPAN���к� */
    if(atoi(sF104Len) >= 16)
    {
        memcpy(tHsmOpr.saCardNo, ptIpcIntTxn->sTransDescrpt+2+iF104Len, 16);
        iF104Len += 16;
        HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "PAN���к� Value ��[%16.16s]", tHsmOpr.saCardNo);
    }
    else
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"GenScriptMac error ,no PAN���к� data.");
		return -1;
    }
    
    /* ȡATC */
    if(atoi(sF104Len) >= (16+4))
    {
        memcpy(tHsmOpr.saPIKChkV, ptIpcIntTxn->sTransDescrpt+2+iF104Len, 4);
        iF104Len += 4;
        HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "9F36 ATC Value ��[%4.4s]", tHsmOpr.saPIKChkV);
    }
    else
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"GenScriptMac error ,no ATC data.");
		return -1;
    }
    
    /* ����Ƿ񱣴�ARQC */
    if(atoi(sF104Len) < (16+4+16))
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"GenScriptMac error ,no ARQC data.");
		return -1;
    }
    
    /*��������*/
    
    /*mod by wuzw for test 0x72*/
    /*
    sTagName[0] = 0x71;*/
    
    sTagName[0] = 0x72;
    sTagName[1] = 0x00;
    sTagName[2] = 0x00;
    memset(sF055Val, 0, sizeof(sF055Val));  
    nReturnCode = parse_tlv_data(sF055Val, sTagName, ptIpcIntTxn->sICData, iF055Len);
    if(nReturnCode > 0)
    {
        HtDebugString ("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, sF055Val, nReturnCode);
        /* CLA��INS��P1��P2 ��Lc */
        memcpy(tHsmOpr.saMacBlock, sF055Val+2, 5);
        /* ATC */
        Str2Hex(tHsmOpr.saPIKChkV, tHsmOpr.saMacBlock+5, 4);
        /* Ӧ������ */
        Str2Hex(ptIpcIntTxn->sTransDescrpt+2+iF104Len, tHsmOpr.saMacBlock+5+2, 16);
        /* �����������е����� */
        iDataLen = sF055Val[6];
        HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ű��������ĳ��� ��[%d]", iDataLen);
        memcpy(tHsmOpr.saMacBlock+5+2+8, sF055Val+2+5, iDataLen-4);
        HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ű������������ݣ�");
        HtDebugString ("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, sF055Val+2+5, iDataLen-4);
        HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "MAC�������ݣ�");
        HtDebugString ("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__, __LINE__, tHsmOpr.saMacBlock, 5+2+8+(iDataLen-4));
        
        /* �����ű����� */
        iTag71Len = nReturnCode;
        memset(sTag71Val, 0, sizeof(sTag71Val));
        memcpy(sTag71Val, sF055Val, iTag71Len);
    }
    else
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"GenScriptMac error, get 72 Tag error [%d]. OprType[%c].", nReturnCode, tHsmOpr.saOprType);
		return -1;
    }
    
    /*�������ݳ���*/
    memset(sTempData, 0, sizeof(sTempData)); 
    /*sprintf(sTempData, "%03d", nReturnCode-2-4);*/
    sprintf(sTempData, "%03d", 5+2+8+(iDataLen-4));
    HtLog("SwtEnc.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������ݳ��� Value ��[%-3.3s]", sTempData);
    memcpy(tHsmOpr.saMacBlockLen, sTempData, 3);

	nReturnCode = nEncOpr (&tHsmOpr);
	if (nReturnCode != HSM_SUCCESS)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"nEncOpr OprType[%c] error [%d].", tHsmOpr.saOprType, nReturnCode);
		return -1;
	}
	
	/* ������ܻ����ص�MAC */
	Str2Hex(tHsmOpr.saEnc, ptIpcIntTxn->sMAC064, 8);
	
	/* ����F055 */
	memcpy(sTag71Len, ptIpcIntTxn->sICData+1, 1);
	iF055Len = 0;
	memset(ptIpcIntTxn->sICDataLen, 0, F055_LEN_LEN);
	memset(ptIpcIntTxn->sICData, ' ', F055_LEN);
	
	/* Tag 91 */
	/* �����ARPC������Tag 91 */
	if(ptIpcIntTxn->sTransDescrpt[2+36] != ' ' && ptIpcIntTxn->sTransDescrpt[2+36] != 0x00)
	{
	    ptIpcIntTxn->sICData[iF055Len] = 0x91;
	    iF055Len += 1;
	    ptIpcIntTxn->sICData[iF055Len] = 0x0A;
	    iF055Len += 1;
	    Str2Hex(ptIpcIntTxn->sTransDescrpt+2+36, &ptIpcIntTxn->sICData[iF055Len], 16);
	    iF055Len += 8;
	    ptIpcIntTxn->sICData[iF055Len] = '0';
	    iF055Len += 1;
	    ptIpcIntTxn->sICData[iF055Len] = '0';
	    iF055Len += 1;
	}
	
	/* Tag 71 */
	
	 /*mod by wuzw for test 0x72*/
    /*
	ptIpcIntTxn->sICData[iF055Len] = 0x71;*/
	ptIpcIntTxn->sICData[iF055Len] = 0x72;
	iF055Len += 1;
	ptIpcIntTxn->sICData[iF055Len] = sTag71Len[0];
	iF055Len += 1;
	memcpy(sTag71Val+(iTag71Len-4), ptIpcIntTxn->sMAC064, 4);
	memcpy(&ptIpcIntTxn->sICData[iF055Len], sTag71Val, iTag71Len);
	iF055Len += iTag71Len;
	
	memset(sF055Len, 0, sizeof(sF055Len));
	sprintf(sF055Len, "%03d", iF055Len);
	memcpy(ptIpcIntTxn->sICDataLen, sF055Len, F055_LEN_LEN);

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}
