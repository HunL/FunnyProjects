
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: SwtCust.c                                                    */
/* DESCRIPTIONS: customrize transaction process                              */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-19  YU TONG        Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/BPCust/SwtCust.c,v 1.3.2.1 2011/09/23 02:54:34 ctedev Exp $" ;

#include "SwtCust.h"
#include "Quota.h"
#include "XFT.h"
   
typedef struct
{
	char		sBranchNo[9+1];
	char		sBankNo[9+1];
	char		sSsnType[1+1];
	char		sSsnSeqno[2+1];
	char		sTlrNo[5+1];
	char		sTlrDsp[80+1];
}T_IpcTlrDef;
static int	 gnTlr_Num;
static T_IpcTlrDef gnBank_Tlr_Inf[CST_BANK_TLR_NUM];

char gsSwtCustLogFile[LOG_NAME_LEN_MAX]="SwtCust.log";

/*****************************************************************************/
/* FUNC:    int SwtCustHandleTransaction (T_IpcIntTxnDef *ptIpcIntTxn,        */
/*                                        int nIndex)                         */
/* INPUT:  ptIpcIntTxn: ��������ϵͳ����Ϣ                                    */
/*         nIndex: �ý�����gatTxnInf�е��±�                                 */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: ��Switch���յ��Ǳ�׼�Ľ���, �����øú���������Ϣ                    */
/*****************************************************************************/
int SwtCustHandleTransaction (T_IpcIntBonusDef *ptIpcIntTxn, int nIndex)
{
	char  sFuncName[] = "SwtCustHandleTransaction";

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	return 0;
}


/*****************************************************************************/
/* FUNC:    int SwtCustCheckTxn (T_IpcIntTxnDef *ptIpcIntTxn,                 */
/*                              char *sRespCode)                             */
/* INPUT:  ptIpcIntTxn: ������Ϣ                                             */
/* OUTPUT: sRespCode: ����鲻ͨ��ʱ,  ���;ܾ�Ӧ�����е�Ӧ����            */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch��������, ���������øú���������ɿͻ����ļ��          */
/*****************************************************************************/
int SwtCustCheckTxn (T_IpcIntBonusDef *ptIpcIntTxn, char *sRespCode)
{
	char	sFuncName[] = "SwtCustCheckTxn";
	int	 nReturnCode;
	int	 nIsSpecialTxn=0;
	int	 nLen;
	char	sTxnNum[4+1];
	char	sDate[4];
	char	OldNew[2];
	char	sTmp [28+1];
	char	sTmpLen [2+1];	
	double  sAmt;

	HtLog(  gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	HtLog(  gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Txn is %4.4s.", ptIpcIntTxn->sTxnNum);
	/*HtDebugString (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, ptIpcIntTxn->sMisc, 128);*/
	memset(sTmp, 0, sizeof(sTmp));
	memset(sTmpLen, 0, sizeof(sTmpLen));

	memset(sTxnNum , 0 , sizeof(sTxnNum));
	memcpy(sTxnNum, ptIpcIntTxn->sTxnNum, 4 );

	if (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_TDB_REQ)
	{
		
	}

	memcpy(sRespCode, F039_SUCCESS, F039_LEN);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustBeforeTblTxnOpr (T_IpcIntBonusDef *ptIpcIntTxn,          */
/*                                     Tbl_bonus_txn_Def *ptTxn,                    */
/*                                     Tbl_bonus_txn_Def *ptOrigTxn)                */
/* INPUT:  ptIpcIntTxn: ��Ϣ                                                 */
/*         ptTxn: ��tbl_txn��¼��Ӧ                                          */
/* OUTPUT: ptTxn                                                             */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Խ��յ�����Ϣ, �ڲ����������ݿ�ǰ���øú���,                */
/*        �ɸ���ptTxn��ĳЩ��������ݱ��浽���ݿ���                            */
/*        ע: ptIpcIntTxn�����ݲ��ɸ���                                        */
/*****************************************************************************/
int SwtCustBeforeTblTxnOpr (T_IpcIntBonusDef *ptIpcIntTxn, Tbl_bonus_txn_Def *ptTxn, Tbl_bonus_txn_Def *ptOrigTxn)
{
	char  sFuncName[] = "SwtCustBeforeTblTxnOpr";
	char	sCurrentTime[15];
	int	  nReturnCode, i,j,loopnum;
	char  sTransAmt[12 + 1],sTxnFee[9];
	char loopbuf[512+1];
	char  sAmt[10+1];
	char  sAmtLen[3+1];  
	char  sTemp[15+1];
	char  sTmpFee[8+1];
	char  sTmpFee1[10+1];
	char  sTmpFee2[10+1];
	char  sNowTime[14+1];
	char  momeytmp[12+1];
	long   momeyvle;
	char  sSysTraceAuditNum[12+1];
	T_BpHeaderDef * ptBpHeader;

	char	sTmpAmt[15+1];
	char	sTmpAmt1[12+1];
	char	sTmpAmt2[12+1];
	char	sTmpMcht[15+1];
	char    sData[100];

	char	sTmpLen[2+1];
	int	num;
	char sTmp[2];
	
	char sF055Val[1000];
	char sF055Len[F055_LEN_LEN+1];
	char sF104Len[2+1] = {0};
	
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "%s begin.", sFuncName);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "sTxnNum[%4.4s].", ptIpcIntTxn->sTxnNum);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "sMsgDestId[%4.4s].", ptIpcIntTxn->sMsgDestId);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "gsTimeCurTs[%14.14s].", gsTimeCurTs);
  if(memcmp(ptIpcIntTxn->sTransChnl,"POSP",4)!=0)
  	{
	  HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "�Ƿ�ϲ�֧�� 1:�࿨����֧�� 0:�ͻ�����֧��---[%1.1s].", ptIpcIntTxn->sMiscFlag);
	  HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "֧������ 1:����+�ֽ� 0:������----[%1.1s].", ptIpcIntTxn->sConsumeType);
    }
	
			
	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDB_REQ:
		    /*memset(ptIpcIntTxn->sFwTransSsn, '0', 16);
		    memcpy(ptIpcIntTxn->sFwTransSsn+16, ptIpcIntTxn->sSysSeqNum, FLD_FW_TRANS_SSN_LEN-16);
		    memcpy(ptIpcIntTxn->sFwTransDate, gsTimeCurTs, FLD_FW_TRANS_DATE_LEN);
		    memcpy(ptIpcIntTxn->sFwTransTime, gsTimeCurTs+8, FLD_FW_TRANS_TIME_LEN);*/
		    
		    memcpy(ptIpcIntTxn->sMidTime, ptIpcIntTxn->sTransmsnDateTime, FLD_MID_TIME_LEN);
		    memset(ptIpcIntTxn->sMidSsn, '0', 6);
		    memcpy(ptIpcIntTxn->sMidSsn+6, ptIpcIntTxn->sSysSeqNum, FLD_MID_SSN_LEN-6);
		    
		    /* POS������ */
		    if(memcmp(ptIpcIntTxn->sMsgSrcId, "1801", SRV_ID_LEN) == 0 ||
		        memcmp(ptIpcIntTxn->sMsgSrcId, "1802", SRV_ID_LEN) == 0)
		    {
		        memset(ptIpcIntTxn->sOrderId, ' ', FLD_ORDER_ID_LEN);
		        memcpy(ptIpcIntTxn->sOrderId, ptIpcIntTxn->sRetrivlRefNum, F037_LEN);
		    }
		    
			/*�ͻ������ֱ���ͷ*/
			if(memcmp(ptIpcIntTxn->sMsgDestId,"1903",4)==0)
			{
			    memset(ptIpcIntTxn->sBpHeader,' ',80);
			    
                ptBpHeader = (T_BpHeaderDef *)ptIpcIntTxn->sBpHeader;
                
	            memcpy(ptBpHeader->sTotLen, "    ", 4);
	            memcpy(ptBpHeader->sVerNo, "1", 1);
	            memcpy(ptBpHeader->sToEnc, "0", 1);
	            memcpy(ptBpHeader->sCommCode, "500001", 6);
	            memcpy(ptBpHeader->sCommType, "0", 1);
	            memcpy(ptBpHeader->sRcvId, "BPMS", 4);
	            
	            if(memcmp(ptIpcIntTxn->sTransChnl,"POSP",4)==0)
	                memcpy(ptBpHeader->sSndId, "SWTC", 4);
	            else
	                memcpy(ptBpHeader->sSndId, "MALL", 4);
	            memcpy(ptTxn->fw_trans_id, ptBpHeader->sSndId, FLD_FW_TRANS_ID_LEN);
	                
	             if(memcmp(ptIpcIntTxn->sTransChnl,"POSP",4)==0)
	                   memcpy(ptBpHeader->sSndSn, ptIpcIntTxn->sFwTransSsn, 22);  
	            else
	              memcpy(ptBpHeader->sSndSn, ptIpcIntTxn->sMidSsn, FLD_MID_SSN_LEN);  
	         
	            memcpy(ptBpHeader->sSndDate, ptIpcIntTxn->sFwTransDate, 8);
	            memcpy(ptBpHeader->sSndTime, ptIpcIntTxn->sFwTransTime, 6);
	            
	            if(memcmp(ptIpcIntTxn->sTxnNum,"1805",4)==0)
	                memcpy(ptBpHeader->sTradeCode, "bms005", 6);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"1815",4) ||
					    !memcmp(ptIpcIntTxn->sTxnNum,"1825",4))
	                memcpy(ptBpHeader->sTradeCode, "bms102", 6);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"2815",4) ||
					    !memcmp(ptIpcIntTxn->sTxnNum,"2825",4))
	                memcpy(ptBpHeader->sTradeCode, "bms201", 6);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"3815",4) ||
					    !memcmp(ptIpcIntTxn->sTxnNum,"3825",4))
	                memcpy(ptBpHeader->sTradeCode, "bms202", 6);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"4815",4) ||
					    !memcmp(ptIpcIntTxn->sTxnNum,"4825",4))
	                memcpy(ptBpHeader->sTradeCode, "bms301", 6);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"1845",4) && 
	             	    !memcmp(ptIpcIntTxn->sMiscFlag,"0",1) )
	                memcpy(ptBpHeader->sTradeCode, "bms103", 6);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"1845",4) && 
	             	    !memcmp(ptIpcIntTxn->sMiscFlag,"1",1) )
	                memcpy(ptBpHeader->sTradeCode, "bms102", 6);
	                
	            memcpy(ptBpHeader->sErrCode, "  ", 2);
	            memcpy(ptBpHeader->sErrMsg, "       ", 7);
	            memcpy(ptBpHeader->sReserved1, "        ", 8);
	            
	            memcpy(ptTxn->bp_header,ptIpcIntTxn->sBpHeader,80);

			}
			/*POS�࿨����֧���ͻ���ѭ����*/
			if((!memcmp(ptIpcIntTxn->sTxnNum, "1815", 4) ||
				!memcmp(ptIpcIntTxn->sTxnNum, "1825", 4)) &&
				!memcmp(ptIpcIntTxn->sMsgDestId, "1903", 4))
			{
			    /* ѭ���� */
			    i = 0;
			    memcpy(ptIpcIntTxn->sLoopReq+i, "0000", 4); /* ѭ�����ʶ */
			    i += 4;
			    memcpy(ptIpcIntTxn->sLoopReq+i, "001", 3); /* ѭ�����¼�� */
			    i += 3;
			    memcpy(ptIpcIntTxn->sLoopReq+i, "007", 3); /* ѭ�������ֶθ��� */
			    i += 3;
			    memcpy(ptIpcIntTxn->sLoopReq+i, ptIpcIntTxn->sPrimaryAcctNum, 19); /* ���� */
			    i += 19;
			    memcpy(ptIpcIntTxn->sLoopReq+i, "1  ", 3); /* �������� */
			    i += 3;
			    memcpy(ptTxn->bp_type, "1  ", FLD_BP_TYPE_LEN);
				if(!memcmp(ptIpcIntTxn->sTxnNum, "1825", 4))
			        memcpy(ptIpcIntTxn->sLoopReq+i, "1", 1); /* �������� */
				else
					memcpy(ptIpcIntTxn->sLoopReq+i, "0", 1); /* �������� */
			    i += 1;

				if(!memcmp(ptIpcIntTxn->sTxnNum, "1815", 4))
					memcpy(ptTxn->consume_type, "0", FLD_CONSUME_TYPE_LEN);
				else
					memcpy(ptTxn->consume_type, "1", FLD_CONSUME_TYPE_LEN);

				memcpy(ptIpcIntTxn->sLoopReq+i, "CNY", 3); /* ���� */
			    i += 3;
			    memcpy(ptIpcIntTxn->sLoopReq+i, ptIpcIntTxn->sAmtTrans+3, 9); /* �����ѽ�� */
			    i += 9;
				if(!memcmp(ptIpcIntTxn->sTxnNum, "1815", 4))
			        memcpy(ptIpcIntTxn->sLoopReq+i, ptIpcIntTxn->sAmtTrans+3, 9); /* ����֧����� */
                else
				{
                    memset(sData, 0, sizeof(sData));
					memcpy(sData, ptIpcIntTxn->sAddtnlAmt+3, 9);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sAddtnlAmt[%s]", sData);
					sprintf(ptIpcIntTxn->sLoopReq+i, "%09d", atoi(sData));	
					HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntTxn->sLoopReq+i[%9.9s]", ptIpcIntTxn->sLoopReq+i);
                }
				i += 9;
			    memset(ptIpcIntTxn->sLoopReq+i, ' ', 10); /* �ۼ����ֶ� */
			    i += 10;
			    memset(sTemp, 0, sizeof(sTemp));
			    sprintf(sTemp, "%03d", i);
			    memcpy(ptBpHeader->sTotLen, sTemp, 3); /* ��ʱ���ѭ���峤�� */
			    memcpy(ptTxn->loop_req ,ptIpcIntTxn->sLoopReq, FLD_LOOP_LEN);
			    HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ���峤�� [%d]", i);
		    }

		    /*�̳�/CC�࿨����֧���ͻ���ѭ����*/
		    if(!memcmp(ptIpcIntTxn->sTxnNum, "1845", 4) &&
		    	!memcmp(ptIpcIntTxn->sMiscFlag,"1",1) &&
		    	!memcmp(ptIpcIntTxn->sMsgDestId, "1903", 4))
			{
			    /* �̳�/CCѭ����----ת��Ϊ����ѭ���� */			    

			    memset(loopbuf,0x00,sizeof(loopbuf));
			    memset(sTmp,0x00,sizeof(sTmp));
			    memcpy(loopbuf,ptIpcIntTxn->sLoopReq,512);
			    memcpy(sTmp,loopbuf+4,1);
			    loopnum = atoi(sTmp);
			    memset(ptIpcIntTxn->sLoopReq,0x00,512);
			    i = 0;
			    memcpy(ptIpcIntTxn->sLoopReq+i, "0000", 4); /* ѭ�����ʶ */
			    i += 4;
			    memcpy(ptIpcIntTxn->sLoopReq+i, "00", 2); /* ѭ�����¼�� */
			    i += 2;
			    memcpy(ptIpcIntTxn->sLoopReq+i, loopbuf+4, 1); /* ѭ�����¼�� */
			    i += 1;
			   
			    memcpy(ptIpcIntTxn->sLoopReq+i, "007", 3); /* ѭ�������ֶθ��� */
			    i += 3;
			    
			   for(j=0;j<loopnum;j++)
			   {
			       memcpy(ptIpcIntTxn->sLoopReq+i, loopbuf+6+j*45, 19); /* ���� */
			       i += 19;
			       memset(momeytmp,0x00,sizeof(momeytmp));
			       memcpy(momeytmp, loopbuf+6+32+j*45, 3); 
			       momeyvle=atol(momeytmp);
			       memset(momeytmp,' ',sizeof(momeytmp));
			       sprintf(momeytmp,"%-1ld",momeyvle);
			       memcpy(ptIpcIntTxn->sLoopReq+i, momeytmp, 1); /* �������� */	
			       memcpy(ptIpcIntTxn->sLoopReq+i+1,"  ", 2); /* �������� */				       
			       i += 3;
				   memcpy(ptIpcIntTxn->sLoopReq+i, ptIpcIntTxn->sConsumeType, 1); /* �������� */
			       i += 1;
			                          
                   memcpy(ptTxn->consume_type, ptIpcIntTxn->sConsumeType, FLD_CONSUME_TYPE_LEN);
                   if(memcmp(ptIpcIntTxn->sConsumeType, "1", 1)==0)
	               {
	               	 memset(momeytmp,0x00,sizeof(momeytmp));
	                 memcpy(momeytmp, loopbuf+6+23+j*45, 9);
	                 momeyvle=atol(momeytmp);
	                 if(momeyvle > 0)
	                 {
	                   memset(ptIpcIntTxn->sPrimaryAcctNum,0x00,sizeof(ptIpcIntTxn->sPrimaryAcctNum));
	                   memset(ptTxn->pan,0x00,sizeof(ptTxn->pan));
	                   memset(ptIpcIntTxn->sAmtTrans,0x00,sizeof(ptIpcIntTxn->sAmtTrans));
	                   memset(ptTxn->amt_trans,0x00,sizeof(ptTxn->amt_trans));
	                  
	                   memcpy(ptIpcIntTxn->sPrimaryAcctNum ,loopbuf+6+j*45,19); /* ���� */
	                   memcpy(ptTxn->pan,loopbuf+6+j*45,19);
	                   
	                    ptIpcIntTxn->cF014Ind='Y';
	                   memcpy(ptIpcIntTxn->sCardAccptrNameLoc,loopbuf+6+19+j*45,4); /* ��Ƭ��Ч��*/
	                   memcpy(ptIpcIntTxn->sDateExpr ,loopbuf+6+19+j*45,4); /* ��Ƭ��Ч��*/
	                   memcpy(ptTxn->card_accp_name ,loopbuf+6+19+j*45,4); /* ��Ƭ��Ч��*/
	                   
	                    sprintf(momeytmp, "%012d", momeyvle);
	                   memcpy(ptIpcIntTxn->sAmtTrans ,momeytmp, 12); /* ��� */
	                   memcpy(ptTxn->amt_trans ,momeytmp, 12);
	                 }               
	               }
                                      
				   memcpy(ptIpcIntTxn->sLoopReq+i, "CNY", 3); /* ���� */
			       i += 3;
			       memcpy(ptIpcIntTxn->sLoopReq+i, "         ", 9); /* �����ѽ�� */
			       i += 9;
			       memcpy(ptIpcIntTxn->sLoopReq+i, "         ", 9); /* ����֧����� */
				   i += 9;
			       memcpy(ptIpcIntTxn->sLoopReq+i, loopbuf+6+35+j*45, 10); /* �ۼ����ֶ� */
			       i += 10;
			   }
			   memset(sTemp, 0, sizeof(sTemp));
			   sprintf(sTemp, "%03d", i);
			   memcpy(ptBpHeader->sTotLen, sTemp, 3); /* ��ʱ���ѭ���峤�� */
			   
			   /*���ּ��ֽ����ѣ��ֽ𲿷ݴ�ţ����ѿ���ţ���Ƭ��Ч�ڴ�ţ��ͻ������*/
			   
	            memcpy(ptIpcIntTxn->sAcqInstResvd+40 ,ptIpcIntTxn->sCardAccptrId,15); /* �̳��ص�� */
                if(memcmp(ptIpcIntTxn->sConsumeType, "0", 1)==0)
	            {
	               ptIpcIntTxn->cF014Ind='Y';
	              memcpy(ptIpcIntTxn->sCardAccptrNameLoc,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	              memcpy(ptIpcIntTxn->sDateExpr ,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	              memcpy(ptTxn->card_accp_name ,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	              memcpy(ptIpcIntTxn->sPrimaryAcctNum ,loopbuf+6,19); /* ���� */
	              memcpy(ptTxn->pan,loopbuf+6,19);	                   
	              memcpy(ptIpcIntTxn->sAmtTrans ,loopbuf+6+23, 9); /* ��� */
	              memcpy(ptTxn->amt_trans ,loopbuf+6+23, 9);
	            }
			   
			   
			   HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ���峤�� [%d]", i);
			   
		    } 
		    /*�̳�/CC�ͻ�����֧���ͻ���*/
		    if(!memcmp(ptIpcIntTxn->sTxnNum, "1845", 4)&&
		    	!memcmp(ptIpcIntTxn->sMiscFlag,"0",1)&&
		    	!memcmp(ptIpcIntTxn->sMsgDestId, "1903", 4))
			{
			    /* �ͻ�����֧���ͻ��� */			    
			    memset(loopbuf,0x00,sizeof(loopbuf));
			    memset(sTmp,0x00,sizeof(sTmp));
			    memcpy(loopbuf,ptIpcIntTxn->sLoopReq,512);

			    memcpy(ptIpcIntTxn->sPrimaryAcctNum, loopbuf+6, 19); /* ���� */
			    memset(momeytmp,0x00,sizeof(momeytmp));
			    memcpy(momeytmp, loopbuf+6+32, 3); 
			    momeyvle=atol(momeytmp);
			    memset(momeytmp,' ',sizeof(momeytmp));
			    sprintf(momeytmp,"%-1ld",momeyvle);
			    memcpy(ptIpcIntTxn->sBpType, momeytmp, 1); /* �������� */	
			    memcpy(ptIpcIntTxn->sBpType+1, "  ", 2); /* �������� */	
			    		       		
				memcpy(ptIpcIntTxn->sConsumeType, ptIpcIntTxn->sConsumeType, 1); /* �������� */
			    memcpy(ptIpcIntTxn->sMisc2+28, "          ", 10); /* ֧��ģʽ */	
			    memcpy(ptIpcIntTxn->sMisc2, "         ", 9); /* �����ѽ�� */		
			    memcpy(ptIpcIntTxn->sMisc2+9, "         ", 9); /* ����֧����� */
			    memcpy(ptIpcIntTxn->sMisc2+18, loopbuf+6+35, 10); /* �ۼ����ֶ� ����*/
			    memcpy(ptIpcIntTxn->sCurrcyCodeTrans, "CNY", 3); /* ���� */    
			                   
                memcpy(ptTxn->consume_type, ptIpcIntTxn->sConsumeType, FLD_CONSUME_TYPE_LEN);
                if(memcmp(ptIpcIntTxn->sConsumeType, "1", 1)==0)
	            {
	               	 memset(momeytmp,0x00,sizeof(momeytmp));
	                 memcpy(momeytmp, loopbuf+6+23, 9);
	                 momeyvle=atol(momeytmp);
	                 if(momeyvle > 0)
	                 {
	                   memset(ptIpcIntTxn->sPrimaryAcctNum,0x00,sizeof(ptIpcIntTxn->sPrimaryAcctNum));
	                   memset(ptTxn->pan,0x00,sizeof(ptTxn->pan));
	                   memset(ptIpcIntTxn->sAmtTrans,0x00,sizeof(ptIpcIntTxn->sAmtTrans));
	                   memset(ptTxn->amt_trans,0x00,sizeof(ptTxn->amt_trans));
	                  
	                   memcpy(ptIpcIntTxn->sPrimaryAcctNum ,loopbuf+6,19); /* ���� */
	                   memcpy(ptTxn->pan,loopbuf+6,19);
	                   
	                    ptIpcIntTxn->cF014Ind='Y';
	                   memcpy(ptIpcIntTxn->sCardAccptrNameLoc,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	                   memcpy(ptIpcIntTxn->sDateExpr ,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	                   memcpy(ptTxn->card_accp_name ,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	                   
	                   sprintf(momeytmp, "%012d", momeyvle);
	                   memcpy(ptIpcIntTxn->sAmtTrans ,momeytmp, 12); /* ��� */
	                   memcpy(ptTxn->amt_trans ,momeytmp, 12);
	                   
	                 }               
	             }
                                                         			
			    memset(sTemp, 0, sizeof(sTemp));
			    sprintf(sTemp, "%03d", 0);
			    memcpy(ptBpHeader->sTotLen, sTemp, 3); /* ��ʱ���ѭ���峤�� */
			    
			    memcpy(ptIpcIntTxn->sAcqInstResvd+40 ,ptIpcIntTxn->sCardAccptrId,15); /* �̳��ص�� */
                if(memcmp(ptIpcIntTxn->sConsumeType, "0", 1)==0)
	            {
	               ptIpcIntTxn->cF014Ind='Y';
	              memcpy(ptIpcIntTxn->sCardAccptrNameLoc,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	              memcpy(ptIpcIntTxn->sDateExpr ,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	              memcpy(ptTxn->card_accp_name ,loopbuf+6+19,4); /* ��Ƭ��Ч��*/
	              memcpy(ptIpcIntTxn->sPrimaryAcctNum ,loopbuf+6,19); /* ���� */
	              memcpy(ptTxn->pan,loopbuf+6,19);	                   
	              memcpy(ptIpcIntTxn->sAmtTrans ,loopbuf+6+23, 9); /* ��� */
	              memcpy(ptTxn->amt_trans ,loopbuf+6+23, 9);
	            }
	            
			    HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ���峤�� [%d]", i);
		    }
			 
			/* ���浽���ÿ���MsgType , ProcCode */
			if(memcmp(ptIpcIntTxn->sMsgDestId, SRV_ID_COMM_CC, 4) == 0)
			{
			    if(!memcmp(ptIpcIntTxn->sTxnNum,"1825",4))/*���ּ��ֽ����ѽ�������*/
	            	memcpy(ptTxn->misc_2+40,"0200000000",10);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"2825",4))/*����(����)��ԭ*/
	            	memcpy(ptTxn->misc_2+40,"0400000000",10);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"3825",4))/*����(����)����*/
	            	memcpy(ptTxn->misc_2+40,"0200000000",10);
	            else if(!memcmp(ptIpcIntTxn->sTxnNum,"4825",4))/*����(����)������ԭ*/
	            	memcpy(ptTxn->misc_2+40,"0400020000",10);
			} 
			if(!memcmp(ptIpcIntTxn->sTxnNum, "1825", 4) ||
			   !memcmp(ptIpcIntTxn->sTxnNum, "3825", 4))
			{
			    HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTrack2Data[%37.37s]", ptIpcIntTxn->sTrack2Data);
				HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sPinData[%8.8s]", ptIpcIntTxn->sPinData);
                memcpy(ptTxn->misc_2+50, ptIpcIntTxn->sTrack2Data, 37);
				memcpy(ptTxn->misc_2+50+37, ptIpcIntTxn->sPinData, F052_LEN);				
			}

			if(!memcmp(ptIpcIntTxn->sTxnNum, "3815", 4))
			{
			    memcpy(ptIpcIntTxn->sAddtnlAmtLen, ptOrigTxn->addtnl_amt_len, F054_LEN_LEN);
				memcpy(ptIpcIntTxn->sAddtnlAmt, ptOrigTxn->addtnl_amt, F054_VAL_LEN);			    
			}
				
			break;
		case TXN_NUM_BDB_RSP:
			HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTxnNum[%4.4s]", ptIpcIntTxn->sTxnNum);
			HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMsgSrcId[%4.4s]", ptIpcIntTxn->sMsgSrcId);
			HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sRespCode[%2.2s]", ptIpcIntTxn->sRespCode);
		    if(memcmp(ptIpcIntTxn->sTxnNum, "1806", 4) == 0 &&
		       memcmp(ptIpcIntTxn->sMsgSrcId, "1903", 4) == 0)
		    {
		        if(memcmp(ptIpcIntTxn->sRespCode, "00", F039_LEN) == 0)
		        {
		            /* F054 ������� */
		            ptIpcIntTxn->cF054Ind = 'Y';
		            
		            memcpy(ptIpcIntTxn->sAddtnlAmtLen , "040", F054_LEN_LEN);
		            
		            memset( ptIpcIntTxn->sAddtnlAmt , '0' , 40);
		            i = 0;
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, "90", 2);
		            i += 2;
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, "01", 2);
		            i += 2;
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, "999", 3);
		            i += 3;
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, "C", 1);
		            i += 1;
		            
		            memset(sAmt, 0, sizeof(sAmt));
		            memset(sAmtLen, 0, sizeof(sAmtLen));
		            /*get bp balance*/
		            memcpy(sAmt, ptIpcIntTxn->sLoopRsp+33, 10);
		            CommonLTrim(sAmt);
		            CommonRTrim(sAmt);
		            sprintf(sAmtLen, "%03d", strlen(sAmt));
		            i += (10-atoi(sAmtLen));
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, sAmt, atoi(sAmtLen));
		            i += (atoi(sAmtLen)+2);
		            
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, "90", 2);
		            i += 2;
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, "02", 2);
		            i += 2;
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, "156", 3);
		            i += 3;
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, "C", 1);
		            i += 1;
		            
		            memset(sAmt, 0, sizeof(sAmt));
		            memset(sAmtLen, 0, sizeof(sAmtLen));
		            /* get bp value */
		            memcpy(sAmt, ptIpcIntTxn->sLoopRsp+52, 10);
		            CommonLTrim(sAmt);
		            CommonRTrim(sAmt);
		            sprintf(sAmtLen, "%03d", strlen(sAmt));
		            memset(ptIpcIntTxn->sAddtnlAmt+i, '0', 12-atoi(sAmtLen));
		            i += (12-atoi(sAmtLen));
		            memcpy(ptIpcIntTxn->sAddtnlAmt+i, sAmt, atoi(sAmtLen));
		            i += atoi(sAmtLen);
		            
		            
		            /* F122 ׷�ӻ��ֵ���ʱ�� */
		            memset(sAmtLen, 0, sizeof(sAmtLen));
		            memcpy(sAmtLen, ptTxn->acq_swresved_len, F122_LEN_LEN);
		            memcpy(ptTxn->acq_swresved+atoi(sAmtLen), ptIpcIntTxn->sLoopRsp+44, 8);
		            memset(sAmt, 0, sizeof(sAmt));
		            sprintf(sAmt, "%03d", atoi(sAmtLen)+8);
		            memcpy(ptTxn->acq_swresved_len, sAmt, F122_LEN_LEN);
		        }
		    }
		    
		    if(memcmp(ptIpcIntTxn->sMsgSrcId, "1903", 4) == 0)
		    {
		        if(!memcmp(ptIpcIntTxn->sRespCode, "00", F039_LEN) &&
				   (!memcmp(ptIpcIntTxn->sTxnNum, "1816", 4) ||
				    !memcmp(ptIpcIntTxn->sTxnNum, "1826", 4))
				  )
		        {
		            /* F054 �����ѽ��-9������֧�����-9���ۼ����ֶ�-10���������-10 */
		            ptIpcIntTxn->cF054Ind = 'Y';		            
		            memcpy(ptIpcIntTxn->sAddtnlAmtLen , "038", F054_LEN_LEN);

					/* F054 �����ѽ��-9 */
					memset(sData, 0, sizeof(sData));					
					memcpy(sData, ptIpcIntTxn->sLoopRsp+36, 9);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					sprintf(ptIpcIntTxn->sAddtnlAmt, "%09d", atoi(sData));

					/* ����֧�����-9 */
					memset(sData, 0, sizeof(sData));					
					memcpy(sData, ptIpcIntTxn->sLoopRsp+36+9, 9);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					sprintf(ptIpcIntTxn->sAddtnlAmt+9, "%09d", atoi(sData));

					/* �ۼ����ֶ�-10 */
					memset(sData, 0, sizeof(sData));					
					memcpy(sData, ptIpcIntTxn->sLoopRsp+36+9+9, 10);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					sprintf(ptIpcIntTxn->sAddtnlAmt+9+9, "%010d", atoi(sData));

					/* �������-10 */
					memset(sData, 0, sizeof(sData));					
					memcpy(sData, ptIpcIntTxn->sLoopRsp+36+9+9+10, 10);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					sprintf(ptIpcIntTxn->sAddtnlAmt+9+9+10, "%010d", atoi(sData));					

					memcpy(ptTxn->addtnl_amt_len, "038", F054_LEN_LEN);
					memcpy(ptTxn->addtnl_amt, ptIpcIntTxn->sAddtnlAmt, 38);
		        }
				if(!memcmp(ptIpcIntTxn->sRespCode, "00", F039_LEN) &&
				   (!memcmp(ptIpcIntTxn->sTxnNum, "3816", 4) ||
				    !memcmp(ptIpcIntTxn->sTxnNum, "3826", 4))
				  )
				{
				    /* F054 �����ѽ��-9������֧�����-9���ۼ����ֶ�-10���������-10 */
		            ptIpcIntTxn->cF054Ind = 'Y';		            
		            memcpy(ptIpcIntTxn->sAddtnlAmtLen , "038", F054_LEN_LEN);

					/* F054 �����ѽ��-9 */
					memset(sData, 0, sizeof(sData));					
					memcpy(sData, ptIpcIntTxn->sMisc2, 9);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					sprintf(ptIpcIntTxn->sAddtnlAmt, "%09d", atoi(sData));

					/* ����֧�����-9 */
					memset(sData, 0, sizeof(sData));					
					memcpy(sData, ptIpcIntTxn->sMisc2+9, 9);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					sprintf(ptIpcIntTxn->sAddtnlAmt+9, "%09d", atoi(sData));

					/* �ۼ����ֶ�-10 */
					memset(sData, 0, sizeof(sData));					
					memcpy(sData, ptIpcIntTxn->sMisc2+9+9, 10);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					sprintf(ptIpcIntTxn->sAddtnlAmt+9+9, "%010d", atoi(sData));

					/* �������-10 */
					memset(sData, 0, sizeof(sData));					
					memcpy(sData, ptIpcIntTxn->sMisc2+9+9+10, 10);
					CommonRTrim(sData);
					CommonLTrim(sData);
					if(strlen(sData) == 0)
						sData[0] = '0';
					sprintf(ptIpcIntTxn->sAddtnlAmt+9+9+10, "%010d", atoi(sData));					

					memcpy(ptTxn->addtnl_amt_len, "038", F054_LEN_LEN);
					memcpy(ptTxn->addtnl_amt, ptIpcIntTxn->sAddtnlAmt, 38);
				}
		    }
			break;
	}
	
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustAfterTblTxnOpr (T_IpcIntTxnDef *ptSendIpcIntTxn,      */
/*                                     Tbl_bonus_txn_Def *ptTxn,                   */
/*                                     Tbl_bonus_txn_Def *ptOrigTxn)               */
/* INPUT:  ptSendIpcIntTxn: ��Ҫ���͵���Ϣ                                   */
/*         ptTxn: ��tbl_txn��¼��Ӧ                                          */
/* OUTPUT: ptSendIpcIntTxn                                                   */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Խ��յ�����Ϣ, �ڲ����������ݿ����øú���,               */
/*        �ɸ���ptSendIpcIntTxn�����ݿ��¼��ĳЩ��������ݷŵ�������Ϣ��,   */
/*        ptSendIpcIntTxn��ͨ��PackSend����ʽת�������ⷢ��                  */
/*        ע: ptTxn�����ݲ��ɸ���                                            */
/*****************************************************************************/
int SwtCustAfterTblTxnOpr (T_IpcIntBonusDef *ptSendIpcIntTxn, Tbl_bonus_txn_Def *ptTxn, Tbl_bonus_txn_Def *ptOrigTxn)
{
	char  sFuncName[] = "SwtCustAfterTblTxnOpr";
	char  sAmt[13];
	char  sTemp[16];

	int	nReturnCode, nMaxRspCodeMapN = 0, i;
	
	
    char  sTmpFee[10+1];
	char  sTmpMcht[15+1];
	double  dAmt = 0.00;
	int num;
	char	sTxnNum[4+1];
	
	char	sTmpLen[3+1];
	
	char    sF055Len[F055_LEN_LEN+1];
	char    sF055Val[F055_LEN+1];

	HtLog(gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s begin.", sFuncName);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TxnNum: %4.4s", ptSendIpcIntTxn->sTxnNum );	
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "SrcId[%4.4s] DstId[%4.4s]", ptSendIpcIntTxn->sMsgSrcId, ptSendIpcIntTxn->sMsgDestId);
    HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sPosCondCode[%2.2s]", ptSendIpcIntTxn->sPosCondCode);

	memset(sTxnNum , 0 , sizeof(sTxnNum));
	memcpy(sTxnNum, ptSendIpcIntTxn->sTxnNum, 4 );

	switch (ptSendIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDB_REQ:
		case TXN_NUM_CBDB_REQ:
		    if(memcmp(ptSendIpcIntTxn->sMsgDestId, SRV_ID_COMM_CC, 4) == 0)
		    {
			    nReturnCode = SetCreditCard (ptSendIpcIntTxn,ptTxn,ptOrigTxn);
			    if(nReturnCode)
			    {
			    	HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "SetCreditCard %d err.", nReturnCode);
			    	return -1;
			    }
			}			
			break; 
		case TXN_NUM_BDB_RSP:
			HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "sMisc1[%16.16s]",ptSendIpcIntTxn->sMisc1); 
			HtLog(gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "sMsgDestId[%4.4s]",ptSendIpcIntTxn->sMsgDestId);
		    if(!memcmp(ptSendIpcIntTxn->sMsgDestId, "1801", 4) ||
			   !memcmp(ptSendIpcIntTxn->sMsgDestId, "1802", 4)) /*POSP*/
			{
				memcpy(ptSendIpcIntTxn->sTransmsnDateTime,ptSendIpcIntTxn->sMisc1,F007_LEN);
				memcpy(ptSendIpcIntTxn->sSysTraceAuditNum,ptSendIpcIntTxn->sMisc1+F007_LEN,F011_LEN);
			}
			 if(!memcmp(ptSendIpcIntTxn->sMsgDestId, "1831", 4)) /*�̳�*/
			{
				memcpy(ptSendIpcIntTxn->sFwTransDate,&ptSendIpcIntTxn->sMisc1[0],8);
				memcpy(ptSendIpcIntTxn->sFwTransTime,&ptSendIpcIntTxn->sMisc1[8],6);
				memcpy(ptSendIpcIntTxn->sMidSsn,&ptSendIpcIntTxn->sMisc1[14],12);
			}
			break;
	}

	HtLog( gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}
/*****************************************************************************/
/* FUNC:    int SwtCustSetKeyRsp (T_IpcIntBonusDef *ptIpcIntTxn)                */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                        */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Ա�����,������������Ӧ����Ϣ,                              */
/*        �ڸ��Ƶ�Tbl_bonus_txn_Defǰ���øú���                                     */
/*        ������, �ú����������еĹؼ����¼��sKeyRsp��, ������Ӧ��ʱƥ������ */
/*        ��Ӧ��, �ú�����Ӧ���еĹؼ����¼��sKeyRsp��, ��ƥ������            */
/*****************************************************************************/
int SwtCustSetKeyRsp (T_IpcIntBonusDef *ptIpcIntTxn)
{
	char  sFuncName[] = "SwtCustSetKeyRsp";
	int	  i;
 
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransmsnDateTime[%10.10s]", ptIpcIntTxn->sTransmsnDateTime);
    HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sSysTraceAuditNum[%6.6s]", ptIpcIntTxn->sSysTraceAuditNum);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sTransChnl[%4.4s]", ptIpcIntTxn->sTransChnl);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDB_REQ:
		case TXN_NUM_BDB_RSP:
		     i = 0;
			 memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);
			 i += F007_LEN;
			 memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
			 i += F011_LEN;
			 memcpy (ptIpcIntTxn->sKeyRsp+i, ptIpcIntTxn->sTransChnl, FLD_TRANS_CHNL_LEN);
			break;
		default:
			break;
	}

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustSetKeyRevsal (T_IpcIntBonusDef *ptIpcIntTxn)             */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                        */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                                */
/* DESC: Switch�Ա�����,��������������Ϣ,                                    */
/*        �ڸ��Ƶ�Tbl_bonus_txn_Defǰ���øú���                                     */
/*        ����ͨ����, �ú����������еĹؼ����¼��sKeyRevsal��,                */
/*                ����������ʱƥ��ԭʼ����                                    */
/*        �Գ�������, �ú�����ԭʼ�������ݼ�¼��sKeyRevsal��, ��ƥ��ԭ����    */
/*****************************************************************************/
int SwtCustSetKeyRevsal (T_IpcIntBonusDef *ptIpcIntTxn)
{
	char  sFuncName[] = "SwtCustSetKeyRevsal";
	int	  i,j;
	char  sTemp[20];
	char saTDate[9];
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDB_REQ:
			switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
			{
				case TXN_NUM_NORMAL:
				case TXN_NUM_CANCEL:
					i = 0;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sMisc1+F007_LEN , F011_LEN);
					i += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sMisc1 , F007_LEN);
					i += F007_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sCardAccptrId, F042_LEN);
					break;

				case TXN_NUM_REVSAL:
				case TXN_NUM_CANCEL_REVSAL:
                case TXN_NUM_NOTICE:
					i = 0;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, &ptIpcIntTxn->sOrigDataElemts[F000_MSG_TYPE_LEN] , F011_LEN);
					i += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, &ptIpcIntTxn->sOrigDataElemts[F000_MSG_TYPE_LEN+F011_LEN] , F007_LEN);
					i += F007_LEN;
					memcpy (ptIpcIntTxn->sKeyRevsal+i, ptIpcIntTxn->sCardAccptrId, F042_LEN);
					break;
			}
	}
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustSetKeyCancel (T_IpcIntBonusDef *ptIpcIntTxn)            */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                       */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Ա�����,��������������Ϣ,                                    */
/* �ڸ��Ƶ�Tbl_bonus_txn_Defǰ���øú���                                           */
/* ����ͨ����, �ú����������еĹؼ����¼��sKeyCancel��,                     */
/* ����������ʱƥ��ԭʼ����                                                  */
/* �Գ�������, �ú�����ԭʼ�������ݼ�¼��sKeyCancel��, ��ƥ��ԭ����          */
/*****************************************************************************/
int SwtCustSetKeyCancel (T_IpcIntBonusDef *ptIpcIntTxn)
{
	char  sFuncName[] = "SwtCustSetKeyCancel";
	int   i,j;

	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDB_REQ:
			switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
			{
				case TXN_NUM_NORMAL:
					i = 0;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sMisc1+F007_LEN , F011_LEN);
					i += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sMisc1 , F007_LEN);
					i += F007_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sCardAccptrId, F042_LEN);
					break;
	
				case TXN_NUM_NOTICE:
				case TXN_NUM_CANCEL:
					i = 0;
					memcpy (ptIpcIntTxn->sKeyCancel+i, &ptIpcIntTxn->sOrigDataElemts[F000_MSG_TYPE_LEN] , F011_LEN);
					i += F011_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, &ptIpcIntTxn->sOrigDataElemts[F000_MSG_TYPE_LEN+F011_LEN] , F007_LEN);
					i += F007_LEN;
					memcpy (ptIpcIntTxn->sKeyCancel+i, ptIpcIntTxn->sCardAccptrId, F042_LEN);
					break;
			}
			break;
	}
	HtLog(	gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}


/*****************************************************************************/
/* FUNC:   int SwtCustTransferPin (T_IpcIntBonusDef *ptIpcIntTxn)            */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                       */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Խ��յ������������������Ϣ,                                 */
/*       �ڵ��ú�����֤MAC����øú�����PINת��                              */
/*****************************************************************************/
int SwtCustTransferPin (T_IpcIntBonusDef  *ptIpcIntTxn)
{
	int			nReturnCode;
	HSMOprDef	tHsmOpr;
	char		sMsgSrcId[4+1],sMsgDestId[4+1];
	char		sSrcKeyIndex[5+1],sDestKeyIndex[5+1];
	
	memset(sMsgSrcId, 0 ,sizeof(sMsgSrcId));
	memcpy(sMsgSrcId, ptIpcIntTxn->sMsgSrcId, 4);
	memset(sMsgDestId, 0 ,sizeof(sMsgDestId));
	memcpy(sMsgDestId, ptIpcIntTxn->sMsgDestId, 4);
HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sMsgSrcId[%s] sMsgDestId[%s]", sMsgSrcId, sMsgDestId);
	memset(sSrcKeyIndex, 0x00, sizeof(sSrcKeyIndex));
	switch ( atoi(sMsgSrcId) )
	{
		case 1702:/*���ÿ�*/
			sprintf(sSrcKeyIndex,"Y%04s","0004");
			break;
		case 1801:/*POSP*/
		case 1802:/*POSP*/
			sprintf(sSrcKeyIndex,"Y%04s","0005");
			break;
		default:
			break;
	}
	
	memset(sDestKeyIndex, 0x00, sizeof(sDestKeyIndex));
	sprintf(sDestKeyIndex,"Y%04s","0004");
#if 0
	switch ( atoi(sMsgDestId) )
	{
		case 1702:/*���ÿ�*/
			sprintf(sDestKeyIndex,"Y%04s","0004");
			break;
		case 1801:/*POSP*/
		case 1802:/*POSP*/
			sprintf(sDestKeyIndex,"Y%04s","0005");
		default:
			break;
	}
#endif
	
	
	if(ptIpcIntTxn->cF052Ind == FLAG_YES_C)
	{
		memset((char *)&tHsmOpr,0,sizeof(HSMOprDef));

		tHsmOpr.saOprType = HSM_TRANSPIN;
		memcpy(&tHsmOpr.saRout[0],sSrcKeyIndex,5);
		memcpy(&tHsmOpr.saRout[5],sDestKeyIndex,5);

		memcpy(tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
		memcpy(tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
		memcpy(tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
		memcpy(tHsmOpr.saEnc, ptIpcIntTxn->sPinData, 8);

		nReturnCode = nEncOpr (&tHsmOpr);
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
			return -1;
		}
		ptIpcIntTxn->cF052Ind = FLAG_YES_C;
		memcpy (ptIpcIntTxn->sPinData, tHsmOpr.saEnc, F052_LEN);
	}
	else
	{
		ptIpcIntTxn->sPosEntryModeCode[2] = F022_WITH_OUT_PIN;
		ptIpcIntTxn->cF026Ind = FLAG_NO_C;
		ptIpcIntTxn->cF052Ind = FLAG_NO_C;
		memcpy(ptIpcIntTxn->sPinData, "NPINNPIN", F052_LEN);
		ptIpcIntTxn->cF053Ind = FLAG_NO_C;
	}
	return 0;
}

/*****************************************************************************/
/* FUNC:    int SwtCustTransferRspCode                                       */
/* INPUT:  HOSTRSPCODE                                                       */
/* OUTPUT:                                                                   */
/*         nMaxRspCodeMapN Ӧ����ת����������                                */
/*         tBrhCodeMap Ӧ����ת������                                        */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:      ����Ӧ����ת������                                             */
/*****************************************************************************/
int SwtCustTransferRspCode(T_IpcIntBonusDef *ptIpcIntTxn)
{
	static	int  sInitflag=1;
	/*static  int nMaxRspCodeMapN = 0;*/
	int nReturnCode;
	int i ;

	/* static Tbl_rsp_code_map_Def tRspCodeMap[5000]; */

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"SwtCustTransferRspCode begin");
	/*if (sInitflag)
	{
		nReturnCode = LoadRspCodeMap(&nMaxRspCodeMapN, &tRspCodeMap);
	 	if(nReturnCode)
		{
			 HtLog(	gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LoadRspCodeMap %d.", nReturnCode);
			 return nReturnCode;
		}
		sInitflag = 0 ;
	}*/
	
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"ptIpcIntTxn->sMsgSrcId:[%4.4s]",ptIpcIntTxn->sMsgSrcId);
	
	if ( ( ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_CBDB_RSP ||
               ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_RSP) &&  
	     ( memcmp(ptIpcIntTxn->sMsgSrcId,"1702",4) == 0 ) )    /* ���ÿ� */
	{
		if(memcmp(&ptIpcIntTxn->sRespCode,"00",2) != 0) 
		{
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"Original sRespCode[%2.2s]",ptIpcIntTxn->sRespCode);
			 for( i=0;i<gnMaxRspCodeMapLen;i++)
			 {			   
				if((memcmp(tRspCodeMap[i].src_id, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN) == 0) && 
				   (memcmp(tRspCodeMap[i].src_rsp_code, &ptIpcIntTxn->sRespCode, 2) == 0))  
				break;
			 }
			 if(i == gnMaxRspCodeMapLen)
			 {
				return -1;
			 }
			 else
			 {
				memcpy(ptIpcIntTxn->sRespCode,tRspCodeMap[i].dest_rsp_code,F039_LEN);
			 }
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"Dest sRespCode[%2.2s]",ptIpcIntTxn->sRespCode);
		}
	}
	
        if (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDB_RSP &&  
	    !memcmp(ptIpcIntTxn->sMsgSrcId, "1903", 4))    /* ����ϵͳ */
	{
		if(memcmp(ptIpcIntTxn->sRespCode,"00",2) != 0) 
		{
			 for( i=0;i<gnMaxRspCodeMapLen;i++)
			 {
				if(memcmp(tRspCodeMap[i].src_id, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN) == 0)
				{
				    if(memcmp(tRspCodeMap[i].src_rsp_code, ptIpcIntTxn->sRespDesp, 7) == 0)
				        break;
				}
			 }
			 if(i == gnMaxRspCodeMapLen)
			 {
			    /* �Ҳ�����¼��Ĭ�ϸ�ֵ01 */
				memcpy(ptIpcIntTxn->sRespCode, "01", F039_LEN);
			 }
			 else
			 {
				memcpy(ptIpcIntTxn->sRespCode,tRspCodeMap[i].dest_rsp_code,F039_LEN);
			 }
			 HtLog (gsSwtCustLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"Dest sRespCode[%2.2s]",ptIpcIntTxn->sRespCode);
		}
	}

	HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"SwtCustTransferRspCode end");
	return 0;
	
}

/*****************************************************************************/
/* FUNC:   int SwtCustTransferPin4ZK (T_IpcIntTxnDef *ptIpcIntTxn)           */
/* INPUT:  ptIpcIntTxn: �����Ӧ����                                       */
/* OUTPUT: ptIpcIntTxn: �����Ӧ����                                       */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC: Switch�Խ��յ������������������Ϣ,                                 */
/*       �ڵ��ú�����֤MAC����øú�����PINת��                              */
/*****************************************************************************/
int SwtCustTransferPin4ZK (T_IpcIntTxnDef  *ptIpcIntTxn)
{
	int			nReturnCode;
	HSMOprDef	tHsmOpr;
	char		sMsgSrcId[4+1],sMsgDestId[4+1];
	char		sSrcKeyIndex[5+1],sDestKeyIndex[5+1];
	
	memset(sMsgSrcId, 0 ,sizeof(sMsgSrcId));
	memcpy(sMsgSrcId, ptIpcIntTxn->sMsgSrcId, 4);
	memset(sMsgDestId, 0 ,sizeof(sMsgDestId));
	memcpy(sMsgDestId, ptIpcIntTxn->sMsgDestId, 4);
HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sMsgSrcId[%s] sMsgDestId[%s]", sMsgSrcId, sMsgDestId);
	memset(sSrcKeyIndex, 0x00, sizeof(sSrcKeyIndex));
	switch ( atoi(sMsgSrcId) )
	{
		case 1601:/*����*/
			sprintf(sSrcKeyIndex,"Y%04s","0001");
			break;
		case 1801:/*POSP*/
		case 1802:/*POSP*/
			sprintf(sSrcKeyIndex,"Y%04s","0005");
			break;
		default:
			break;
	}
	
	memset(sDestKeyIndex, 0x00, sizeof(sDestKeyIndex));
	switch ( atoi(sMsgDestId) )
	{
		case 1613:/*�ܿ�*/
			sprintf(sDestKeyIndex,"Y%04s","0007");
			break;
		default:
			break;
	}
	
	if(ptIpcIntTxn->cF052Ind == FLAG_YES_C)
	{

		memset((char *)&tHsmOpr,0,sizeof(HSMOprDef));

		tHsmOpr.saOprType = HSM_TRANSPIN4ZK;
		memcpy(&tHsmOpr.saRout[0],sSrcKeyIndex,5);
		memcpy(&tHsmOpr.saRout[5],sDestKeyIndex,5);

		memcpy(tHsmOpr.saEncWay, ptIpcIntTxn->sSecRelatdCtrlInfo,F053_LEN);
		/* ������ǿ� */
		memcpy(tHsmOpr.saCardNo, ptIpcIntTxn->sPrimaryAcctNumLen,F002_LEN_LEN);
		memcpy(tHsmOpr.saCardNo+2, ptIpcIntTxn->sPrimaryAcctNum,F002_VAL_LEN);
		/* �����ֽ� */
		memcpy(tHsmOpr.saTRK, ptIpcIntTxn->sAcctId2Len,F002_LEN_LEN);
		memcpy(tHsmOpr.saTRK+2, ptIpcIntTxn->sAcctId2,F002_VAL_LEN);
		
		memcpy(tHsmOpr.saEnc, ptIpcIntTxn->sPinData, 8);

		nReturnCode = nEncOpr (&tHsmOpr);
		if (nReturnCode != HSM_SUCCESS)
		{
			HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
			return -1;
		}
		ptIpcIntTxn->cF052Ind = FLAG_YES_C;
		memcpy (ptIpcIntTxn->sPinData, tHsmOpr.saEnc, F052_LEN);
	}
	else
	{
		ptIpcIntTxn->sPosEntryModeCode[2] = F022_WITH_OUT_PIN;
		ptIpcIntTxn->cF026Ind = FLAG_NO_C;
		ptIpcIntTxn->cF052Ind = FLAG_NO_C;
		memcpy(ptIpcIntTxn->sPinData, "NPINNPIN", F052_LEN);
		ptIpcIntTxn->cF053Ind = FLAG_NO_C;
	}
	return 0;
}

/*********************************************************************************/
/* FUNC:   int SetCreditCard (T_IpcIntBonusDef *ptIpcIntTxn,Tbl_bonus_txn_Def *ptTxn, Tbl_bonus_txn_Def *ptOrigTxn)*/
/* INPUT:  ptIpcIntTxn: �ڲ�IPC��ṹ                                            */
/*         ptOrigTxn                                                             */
/* OUTPUT: ��                                                                    */
/* RETURN: 0: �ɹ�, -1: ����                                                     */
/* DESC:   ��䷢�����ÿ��Ķ�������                                              */
/*********************************************************************************/
int SetCreditCard(T_IpcIntBonusDef *ptIpcIntTxn,Tbl_bonus_txn_Def *ptTxn, Tbl_bonus_txn_Def *ptOrigTxn)
{
	char sFuncName[] = "SetCreditCard";
	char sTransAmt[15];
	char sAmt[15];
	char sAmt2[15];
	char sCurrentTime[15];
	char sAmtTrans[13+1];
   
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
	
	/* �ж�4���Ƿ�Ϊ0 */
	memset(sTransAmt, 0, sizeof(sTransAmt));
	memcpy(sTransAmt, ptIpcIntTxn->sAmtTrans, F004_LEN);
	CommonRTrim(sTransAmt);
	CommonLTrim(sTransAmt);
	if(strlen(sTransAmt) == 0)
		memcpy(ptIpcIntTxn->sAmtTrans, "000000000000", F004_LEN);
		 
	if(!memcmp(ptIpcIntTxn->sTxnNum,"1997",4) || !memcmp(ptIpcIntTxn->sTxnNum,"1207",4))
	{
		memcpy(ptIpcIntTxn->sAmtTrans, "000000000000", F004_LEN);
		/*memcpy(ptIpcIntTxn->sPosEntryModeCode, "021", 3);*/
	}
 
 	/*�̳ǻ��ֿͻ���*/
	if(memcmp(&ptIpcIntTxn->sTransChnl,"POSP",4)!=0)
	{
	   memcpy(ptIpcIntTxn->sDateExpr ,ptIpcIntTxn->sCardAccptrNameLoc,4); /* ��Ƭ��Ч��*/
	   memcpy(ptIpcIntTxn->sAcqInstResvd+40 ,ptIpcIntTxn->sCardAccptrId,15); /* �̳��̻��ص�� */
	   memcpy(ptIpcIntTxn->sCurrcyCodeTrans,"156",F049_LEN); /*����*/

	}
    /* ���ÿ�֧����ֵ */
	if(!memcmp(ptIpcIntTxn->sTxnNum, "1825", 4) && 
	   !memcmp(ptIpcIntTxn->sTransChnl, "POSP", 4))
	{
        memset(sAmt, 0, sizeof(sAmt));
		memset(sAmt2, 0, sizeof(sAmt2));
		memcpy(sAmt, ptIpcIntTxn->sAddtnlAmt, 9);
		memcpy(sAmt2, ptIpcIntTxn->sAddtnlAmt+9, 9);
		CommonRTrim(sAmt);
		CommonRTrim(sAmt2);
		CommonLTrim(sAmt);
		CommonLTrim(sAmt2);
		if(strlen(sAmt) == 0)
			sAmt[0] = '0';
		if(strlen(sAmt2) == 0)
			sAmt2[0] = '0';
		memset(sAmtTrans, 0, sizeof(sAmtTrans));		
		sprintf(sAmtTrans, "%012d", atoi(sAmt) - atoi(sAmt2));
		memcpy(ptIpcIntTxn->sAmtTrans, sAmtTrans, 12);
	}
	if(!memcmp(ptIpcIntTxn->sTxnNum, "3825", 4) && 
	   !memcmp(ptIpcIntTxn->sTransChnl, "POSP", 4))
	{
	    memset(sAmt, 0, sizeof(sAmt));
		memset(sAmt2, 0, sizeof(sAmt2));
		memcpy(sAmt, ptOrigTxn->addtnl_amt, 9);
		memcpy(sAmt2, ptOrigTxn->addtnl_amt+9, 9);
		CommonRTrim(sAmt);
		CommonRTrim(sAmt2);
		CommonLTrim(sAmt);
		CommonLTrim(sAmt2);
		if(strlen(sAmt) == 0)
			sAmt[0] = '0';
		if(strlen(sAmt2) == 0)
			sAmt2[0] = '0';
		memset(sAmtTrans, 0, sizeof(sAmtTrans));		
		sprintf(sAmtTrans, "%012d", atoi(sAmt) - atoi(sAmt2));
		memcpy(ptIpcIntTxn->sAmtTrans, sAmtTrans, 12);
	}

	if(memcmp(ptIpcIntTxn->sTxnNum,"1997",4) && 
	   memcmp(ptIpcIntTxn->sTxnNum,"1207",4) &&
	   !memcmp(ptIpcIntTxn->sMsgDestId, "1702", 4)&& 
	   !memcmp(&ptIpcIntTxn->sTransChnl,"POSP",4))
	{
        memset(sAmt, 0, sizeof(sAmt));
		memcpy(sAmt, ptTxn->addtnl_amt, atoi(ptTxn->addtnl_amt_len));
		CommonRTrim(sAmt);
		CommonLTrim(sAmt);
		if(strlen(sAmt) == 0)
			sAmt[0] = '0';
		memset(sAmtTrans, 0, sizeof(sAmtTrans));
		sprintf(sAmtTrans, "%012d", atoi(sAmt));		
		memcpy(ptIpcIntTxn->sAddtnlAmt, sAmtTrans, 12);
		memcpy(ptIpcIntTxn->sAddtnlAmtLen, "012", 3);
		ptIpcIntTxn->cF054Ind = 'Y';
	}

    /*F037ʹ�ã�F007����λ+F011
    memcpy(ptIpcIntTxn->sRetrivlRefNum, ptIpcIntTxn->sMisc+4, F037_LEN);*/
    
	/* ����sKeyRsp��sMisc2,������tbl_txn�еĽ��׼�¼ʹ��  */
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntTxn->sKeyRsp[%32.32s],txn_num[%4.4s]", 
	  ptIpcIntTxn->sKeyRsp, ptIpcIntTxn->sTxnNum);
	memcpy(ptIpcIntTxn->sMisc2, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
	HtLog(gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sMisc2[%32.32s]", ptIpcIntTxn->sMisc2);
		
    /* F122�����͵����ÿ�������,�ٿ�����8583��ṹ��F062 */
	memset(ptIpcIntTxn->sSwitchingData, '0', F122_VAL_LEN);
	/* ��������  */
	if(!memcmp(ptIpcIntTxn->sTxnNum,"1825",4))/*���ѽ�������*/
		memcpy(&ptIpcIntTxn->sSwitchingData[0],"0200000000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"2825",4) || 
		    !memcmp(ptIpcIntTxn->sTxnNum,"2815",4))/*���ѻ�ԭ*/
		memcpy(&ptIpcIntTxn->sSwitchingData[0],"0400000000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"3825",4))/*���ѳ���*/
		memcpy(&ptIpcIntTxn->sSwitchingData[0],"0220000000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"4825",4))/*���ѳ�����ԭ*/
		memcpy(&ptIpcIntTxn->sSwitchingData[0],"0400020000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"1997",4))/*��У��*/
		memcpy(&ptIpcIntTxn->sSwitchingData[0],"0920000000",10);
	else if(!memcmp(ptIpcIntTxn->sTxnNum,"1207",4))/*��У��, ��ѯ */
		memcpy(&ptIpcIntTxn->sSwitchingData[0],"0900310000",10);
	else
	{
		HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sTxnNum[%4.4s] %s err.", ptIpcIntTxn->sTxnNum,sFuncName);
		return -1;
	}
	
	/* ��������   */
	/* ������Դ   */
	if(memcmp(&ptIpcIntTxn->sTransChnl,"POSP",4)==0)
	{
	    memcpy(&ptIpcIntTxn->sSwitchingData[10],"AS",2);
	    memcpy(&ptIpcIntTxn->sSwitchingData[12],"JF",2);
	}
	 else
	{
	    memcpy(&ptIpcIntTxn->sSwitchingData[10],"SC",2);
	    memcpy(&ptIpcIntTxn->sSwitchingData[12],"SC",2);
	}
	
	
	/* ����ԭʼ��������ʱ��   */
	memcpy(sCurrentTime, gsTimeCurTs, 14);
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_REVSAL || 
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_CANCEL_REVSAL ||
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_CANCEL)
	{
	    /* ���ڻ�ԭ���� */
		if(ptOrigTxn->misc_flag[0] != ' ' && ptOrigTxn->trans_date_time[0] != ' ')
		{
			memcpy(&ptIpcIntTxn->sSwitchingData[14], &ptOrigTxn->misc_flag[0], 4);
			memcpy(&ptIpcIntTxn->sSwitchingData[18], ptOrigTxn->trans_date_time, F007_LEN);
		}
		else
		{
		    HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "cc txn get orig date error.");
		    return -1;
		}
	}
	else
	{
	    memcpy(&ptIpcIntTxn->sSwitchingData[14],sCurrentTime,4);
	    memcpy(&ptIpcIntTxn->sSwitchingData[18],ptIpcIntTxn->sTransmsnDateTime,F007_LEN);
    }
	
	/* �м�ƽ̨��������ʱ��   */
	memcpy(&ptIpcIntTxn->sSwitchingData[28],sCurrentTime,4);
	memcpy(&ptIpcIntTxn->sSwitchingData[32],ptIpcIntTxn->sTransmsnDateTime,F007_LEN);
	
	/*�յ���������n-11*/
	/*��ת��������n-11*/
	
	/* ��Ȩ����	*/
	if(ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_REVSAL || 
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_CANCEL_REVSAL ||
	    ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE] == TXN_NUM_CANCEL)
		if (ptIpcIntTxn->cF038Ind == FLAG_YES_C)
		{
			memcpy(&ptIpcIntTxn->sSwitchingData[64], ptIpcIntTxn->sAuthrIdResp, F038_LEN);
	        HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sAuthrIdRespF038_LEN[%6.6s].", ptIpcIntTxn->sAuthrIdResp);
		}
	
	/*��Ӧ����An-2*/
	/*���׷���n-4*/
	/*��������n-6*/
	
	/* �̻�����	*/
	/*memcpy(&ptIpcIntTxn->sNationalSwResved[82], "000100000100453", 15);*/
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sSwitchingData[%100.100s].", ptIpcIntTxn->sSwitchingData);
	
	memset(ptIpcIntTxn->sAddtnlAmt, '0', F054_VAL_LEN);
	/* PIN-BLOCK	*/
	if(ptIpcIntTxn->sPosEntryModeCode[2] == '0' || ptIpcIntTxn->sPosEntryModeCode[2] == '1')
		if (ptIpcIntTxn->cF052Ind == FLAG_YES_C)
		{
			Hex2Str(ptIpcIntTxn->sPinData, &ptIpcIntTxn->sAddtnlAmt[0], F052_LEN);
			memcpy(&ptIpcIntTxn->sAddtnlAmt[16], "01", 2);		/*PIN BLOCK FORMAT*/
		}
	
	/* �ŵ���ʶ   */
	memcpy(&ptIpcIntTxn->sAddtnlAmt[18],"0",1);
	/*if (ptIpcIntTxn->sTrack1Data[0]!= ' ')
		memcpy(&ptIpcIntTxn->sAddtnlAmt[18],"1",1);*/
	if (ptIpcIntTxn->cF035Ind == FLAG_YES_C)
		memcpy(&ptIpcIntTxn->sAddtnlAmt[18],"2",1);
/*	if (ptIpcIntTxn->cF036Ind == FLAG_YES_C)
		memcpy(&ptIpcIntTxn->sAddtnlAmt[18],"3",1);*/
		
	/*������n-12*/
	
	switch (ptIpcIntTxn->sTxnNum[INDEX_TXN_NUM_TYPE])
	{
		case TXN_NUM_REVSAL:
		case TXN_NUM_CANCEL:
		case TXN_NUM_CANCEL_REVSAL:
			/*ԭ���ױ������ͣ����ڻ�ԭ����*/
			if(!memcmp(ptIpcIntTxn->sTxnNum, "4825", 4))
			    memcpy(&ptIpcIntTxn->sAddtnlAmt[31], "0220", F000_MSG_TYPE_LEN);
            else if(!memcmp(ptIpcIntTxn->sTxnNum, "3825", 4) ||
				    !memcmp(ptIpcIntTxn->sTxnNum, "2825", 4))
				memcpy(&ptIpcIntTxn->sAddtnlAmt[31], "0200", F000_MSG_TYPE_LEN);
			else
				memcpy(&ptIpcIntTxn->sAddtnlAmt[31], ptOrigTxn->misc_2+36, F000_MSG_TYPE_LEN);
			
			/* ԭ���״������룻���ڻ�ԭ���� */
            if(!memcmp(ptIpcIntTxn->sTxnNum, "4825", 4) ||
			   !memcmp(ptIpcIntTxn->sTxnNum, "3825", 4) ||
			   !memcmp(ptIpcIntTxn->sTxnNum, "2825", 4))
			    memcpy(&ptIpcIntTxn->sAddtnlAmt[35], "000000", F003_LEN);
			else
				memcpy(&ptIpcIntTxn->sAddtnlAmt[35], ptOrigTxn->misc_2+36+4, F003_LEN);
			
			/*ԭ���׷�������ʱ�䣻���ڻ�ԭ����*/
			if(ptOrigTxn->misc_flag[0] != ' ' && ptOrigTxn->trans_date_time[0] != ' ')
			{
				memcpy(&ptIpcIntTxn->sAddtnlAmt[41],&ptOrigTxn->misc_flag[0],4);
				memcpy(&ptIpcIntTxn->sAddtnlAmt[41+4], ptOrigTxn->trans_date_time, F007_LEN);
			}
			else
			{
			    HtLog (gsSwtCustLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "cc txn get orig date error.");
		        return -1;
			}
	
			/*ԭ������ˮ�ţ����ڻ�ԭ����*/
            memcpy(&ptIpcIntTxn->sAddtnlAmt[55], ptOrigTxn->retrivl_ref, F037_LEN);
			break;
		default:
			break;
	}
	/*ǰ����ˮ��An-8*/
	
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sAddtnlAmt[%100.100s].", ptIpcIntTxn->sAddtnlAmt);
	HtLog (gsSwtCustLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
	return 0;
}
