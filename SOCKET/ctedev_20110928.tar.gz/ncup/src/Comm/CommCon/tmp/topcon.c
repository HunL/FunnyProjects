/***********  ������ ****************/ 
/***     cc menu.c -lcurses -omenu            */ 

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <unistd.h>
#include <stropts.h>
#include <poll.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <sys/param.h>
#include <errno.h>
#include <stdio.h> 
#include <curses.h> 
#include <ctype.h> 
#include <setjmp.h>

#define _EXTERN_
#include "HtLog.h"

#define E_SBREAK -1
#define    ENTER 10 
#define    ESCAPE 27 
#define    BUF_SIZE 1800 

char		gsLogFile[LOG_NAME_LEN_MAX];
static Timeout = 0;
jmp_buf Stackbuf;

char   sIpAddr[20 + 1];
int    nPort;

int iSocketId;

void ProcCommand(int iMenu,int iItem);

WINDOW *menubar,*messagebar,*temp,*temp1; 
char param[10][10][13]; 

static char menu[4][80] = {
"0|3|ϵͳ|����|����|",
"1|1|�˳�|",
"2|5|��·����|ǩ��|ǩ��|����MAC��Կ|����PIN��Կ|",
"3|1|����PIN��Կ|"};


void init_curses() 
{ 
     initscr(); 
     start_color(); 
     init_pair(1, COLOR_WHITE, COLOR_BLUE); 
     init_pair(2, COLOR_BLUE, COLOR_WHITE); 
     init_pair(3, COLOR_RED, COLOR_WHITE); 
     init_pair(4, COLOR_WHITE, COLOR_RED); 
     curs_set(0); 
     noecho(); 
     keypad(stdscr, TRUE); 
} 


void GetSubStr(char *des, char *src, char ch,int n) 
{ 
     int    i,len; 
     char   *p1,*p, tmp[300]; 

   strcpy( tmp, src ); 
   *des=0; 
   p1 = tmp; 
   i=0; 
   while(i<n) 
   { 
     i++; 
     p = (char *)strchr(p1,ch); 
     if(p != NULL) 
     { 
       *p++ = 0; 
       p1 = p;    
     } 
   } 
   p = (char *)strchr(p1,ch); 
   if(p != NULL) 
   { 
     *p = 0; 
     strcpy(des,p1); 
   } 
} 


int get_param() 
{ 
   int  i, j, k; 
   char xm[3], gs[3]; 

   for (j = 0; j < 10; j++) 
	   for(i = 0; i < 10; i++) 
		   memset(param[j][i], 0, 13); 
   for (k = 0; k < 4; k++)
   { 
       if (menu[k][0] == '#') continue; 
       GetSubStr(xm, menu[k], '|', 0); 
       GetSubStr(gs, menu[k], '|', 1); 
       j = atoi(xm); 
       for (i = 1; i <= atoi(gs); i++) 
       { 
           sprintf(param[j][0], "%s", gs); 
           GetSubStr(param[j][i], menu[k], '|', i + 1); 
       } 
   } 
   return 0; 
} 


void draw_menubar(WINDOW *menubar) 
{ 
      int i; 

      wbkgd(menubar,COLOR_PAIR(2)); 

      for(i=0;i<atoi(param[0][0]);i++) 
      { 
         	 wattron(menubar,COLOR_PAIR(3)); 
             mvwprintw(menubar,0,i*14+2,"%1d.",i+1); 
             wattroff(menubar,COLOR_PAIR(3));  
             mvwprintw(menubar,0,i*14+4,"%-12s",param[0][i+1]); 
      } 

} 


WINDOW **draw_menu(int menu) 
{ 
       int i,start_col; 
       WINDOW **items; 
       items=(WINDOW **)malloc((atoi(param[menu][0])+1)*sizeof(WINDOW *)); 
      start_col=(menu-1)*14+2-1; 

       items[0]=newwin(atoi(param[menu][0])+2,16,3,start_col); 
       wbkgd(items[0],COLOR_PAIR(2)); 
       box(items[0],ACS_VLINE,ACS_HLINE); 
       for(i=1;i<=atoi(param[menu][0]);i++) 
      { 
          items[i]=subwin(items[0],1,12,3+i,start_col+2 ); 
           wprintw(items[i],"%s",param[menu][i]); 
      } 
       wbkgd(items[1],COLOR_PAIR(4)); 
       wrefresh(items[0]); 
       return items; 
} 


void delete_menu(WINDOW **items,int count) 
{ 
       int i; 
       for(i=0;i<count;i++) delwin(items[i]); 
       free(items); 
} 

void display_cursor(void)
{
	printf("\033[?25h");
}


int scroll_menu(WINDOW **items,int *menu) 
{ 
      int key,count,selected=0; 

      count=atoi(param[*menu][0]); 

      wbkgd(items[selected+1],COLOR_PAIR(2)); 
      wnoutrefresh(items[selected+1]); 
      doupdate(); 

      do 
      { 
            if (key==KEY_DOWN || key==KEY_UP) 
            { 
                       wbkgd(items[selected+1],COLOR_PAIR(2)); 
                       wnoutrefresh(items[selected+1]); 
                       if (key==KEY_DOWN) 
                               selected=(selected+1) % count; 
                       else 
                               selected=(selected+count-1) % count; 
                       wbkgd(items[selected+1],COLOR_PAIR(4)); 
                       wnoutrefresh(items[selected+1]); 
                       doupdate(); 
            } 
            else if (key==KEY_LEFT || key==KEY_RIGHT) 
            { 
                       delete_menu(items,count+1); 
                       touchwin(stdscr); 
                       refresh(); 
                       if (key==KEY_LEFT) 
                  { 
                     *menu-=1; 
                     if(*menu<=0) *menu=atoi(param[0][0]); 
                          items=draw_menu(*menu); 
                             return scroll_menu(items,menu); 
                  } 
                  if (key==KEY_RIGHT) 
                  { 
                     *menu+=1; 
                     if(*menu>atoi(param[0][0])) *menu=1; 
                          items=draw_menu(*menu); 
                             return scroll_menu(items,menu); 
                  } 
            } 
            else if (key==ESCAPE || key=='0' || key=='q') 
            { 
               delete_menu(items,count+1); 
               return -1; 
            } 
            else if (key==ENTER) 
            { 
               delete_menu(items,count+1); 
               return selected; 
            } 
            key=getch(); 
     } while( 1 ) ;

} 


message(char *ss) 
{ 
          wbkgd(messagebar,COLOR_PAIR(2)); 
          wattron(messagebar,COLOR_PAIR(3));
        mvwprintw(messagebar,0,0,"%80s"," "); 
        mvwprintw(messagebar,0,(80-strlen(ss))/2-1,"%s",ss); 
          wattroff(messagebar,COLOR_PAIR(3)); 
       wrefresh(messagebar); 
} 


int main(int argc,char **argv) 
{ 
   int key,code,iPKey; 
   int selected_item; 
   char ss[81]; 
   char sResult[128];
   WINDOW **menu_items; 


   if (argc != 3){
	   printf("USE: %s ǰ��IP��ַ �˿�\n", argv[0]);
	   printf("USE: %s 127.0.0.1 19002\n", argv[0]);
	   exit(1);
   }


   nPort = atoi(argv[2]);
   strcpy(sIpAddr, argv[1]);

   if(get_param()) 
   { 
       printf("\n�������ļ� %s ��!\n",sResult); 
       exit(1); 
   } 
    
   init_curses(); 
   bkgd(COLOR_PAIR(1)); 
   menubar=subwin(stdscr, 1, 80, 1, 0); 
   messagebar=subwin(stdscr,1,80,24,0); 
   temp=subwin(stdscr,22,80,2,0); 
   temp1=subwin(stdscr,20,78,3,1 ); 
   strcpy(ss,"����ǰ�ü��׿���̨");
   mvwprintw(stdscr,0,(80-strlen(ss))/2-1,"%s",ss); 
   draw_menubar(menubar); 
   message("�밴���ּ�ѡ����Ӧ�˵�. ESC ��'0'���˳�."); 
   box(temp, ACS_VLINE,ACS_HLINE ); 
   refresh( ); 

   do { 
	  display_cursor();
      key=getch(); 
      if(!(isdigit(key)&&key>'0'&&key<=atoi(param[0][0])+'0'))
      {
          key = '1';
      }
      werase(messagebar); 
      wrefresh(messagebar); 
      iPKey = key-'0';
      menu_items=draw_menu(iPKey); 
      selected_item=scroll_menu(menu_items,&iPKey); 
      if((iPKey)==1&&(selected_item+1)==1) break;
      ProcCommand(iPKey,selected_item+1);
      touchwin(stdscr); 
      refresh(); 
   } while (key!=ESCAPE && key!='q' && key!='0'); 

   delwin(temp1); 
   delwin(temp); 
   delwin(menubar); 
   delwin(messagebar); 
   endwin(); 
   return(0); 
} 



void ProcCommand(int iMenu,int iItem)
{
	int code;
	char sMsgBuf[1024];
	int iBufLen;
    char sTemp[5];
    char sMessage[128];
    char sResult[128];
	char sIpAddr[16];
	unsigned short sPort;


	memset(sMsgBuf, '\0', sizeof(sMsgBuf));
	memset(sMsgBuf, ' ', 521);
	switch(iMenu)
    {
		case 2:
			 switch(iItem)
			 {
				case 1:  
				    memcpy(sMsgBuf, "6131", 4);
					break;
				case 2:  
				    memcpy(sMsgBuf, "6111", 4);
					break;
				case 3:  
				    memcpy(sMsgBuf, "6121", 4);
					break;
				case 4:  
				    memcpy(sMsgBuf, "6071", 4);
					break;
				case 5:  
				    memcpy(sMsgBuf, "6070", 4);
					break;
			 }
			 break;
        case 3: /* ATM���� */
             switch(iItem)
             {
				case 1:  
				    memcpy(sMsgBuf, "6323", 4);
					break;
             }
             break;
    }

	iSocketId = tcpOpen(sIpAddr, nPort, 2); 
	if (iSocketId < 0){
	      sprintf(sMessage,"��������ͨѶ��[%d]\n", errno);
		  message(sMessage); 
		  return;
	}

    code= WriteSocket(iSocketId, sMsgBuf, strlen(sMsgBuf));
    if (code < 0)
    {
        sprintf(sMessage,"������Ϣ��[%d]", code);
        message(sMessage);
        tcpClose(iSocketId);
        return;
    }

	sprintf(sMessage,"�ȴ�Ӧ��....");
	message(sMessage);

    code = ReadSocket(iSocketId, sMsgBuf, 10);
    if(code < 0)
    {
        sprintf(sMessage,"������Ϣ��[%d]",code);
        message(sMessage);
        tcpClose(iSocketId);
        return;
    }  
	memset(sMessage, 0, sizeof(sMessage));
    if(memcmp(sMsgBuf + 4, "00",  2)==0)
    {
        sprintf(sMessage, "������ɹ�");
        message(sMessage);
    }
    else
    {
		
        sprintf(sMessage, "�����ʧ��");
        memcpy(sMessage + 12, sMsgBuf + 4, 2);
        message(sMessage + 4);
    }
    tcpClose(iSocketId);
    return;
}

int tcpOpen (hostaddress,hostport,retrys)
char *hostaddress;
int  hostport;
int  retrys;
{
	struct sockaddr_in remote;
	int  sock;

    bzero(&remote, sizeof(remote));
    remote.sin_family = AF_INET;
	remote.sin_addr.s_addr = inet_addr(hostaddress);
    remote.sin_port = htons(hostport);

	while (retrys) 
	{
		if ( (sock = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
       	{
			if ( retrys > 0) 
			{	
				retrys--;
				continue;
			}
        	return(-2);
       	}

     	if ( connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0 )
       	{
			tcpClose(sock);
			if ( retrys > 0) 
			{	
				retrys--;
				continue;
			}
        	return(-3);
       	}

     	return(sock);
	} /* while */

       	return(-4);
}

/*
 * Function Name: tcpClose 
 * Parameter 1  : sock      Ҫ�رյ�socket�� 
 */
int tcpClose( sock )
int sock;
{
    	if ( fcntl( sock, F_SETFL, FNDELAY ) < 0 )
      		return( -1 );
    	if ( sock != 0 )
      		shutdown( sock, 2 );
    	close(sock);
    	return( 0 );
}

/*
 * Function Name:  IOTimeOut
 * Parameter 1  :  no         ������
 */
void IOTimeOut(int no )
{
  Timeout = 1;
  longjmp( Stackbuf, Timeout ); 
}

int WriteSocket(int socket_id_new,char *buf, int len) 
{                                             
	int  num, iWritelen; 
	char Buf_head[5];
	char saSendBuf[BUF_SIZE];

  	if (len == 0) return(0);

   	memset(saSendBuf,0,sizeof(saSendBuf));

   	sprintf(saSendBuf, "%04d", len);
	memcpy(saSendBuf+4,buf,len);

	len = len + 4;

    iWritelen=0; 
    for(;;)
    {
  		while((num=write(socket_id_new,&saSendBuf[iWritelen],
				len-iWritelen))<=0)
   		{	
			if (errno == EINTR) continue;
			return(E_SBREAK);
   		}
  
   		iWritelen+=num;
		if(iWritelen>=len) break;
    }
    return(iWritelen);
}

int ReadSocket(int socket_id_new,char *buf ,int nTimeOut)  
{
	int num, nLen, I=0;
	char tmp_buf[5], Buf_head[5];
	char tmp_Str[2000], sBody[1024];

    Timeout = 0;
    signal( SIGALRM, IOTimeOut );
    alarm( nTimeOut );

    setjmp( Stackbuf );
    if ( Timeout )
    {
        alarm( 0 );
        return( -1 );
    }

    num = read(socket_id_new, tmp_buf, 4);
	if ( num < 0 )
	{
        if (errno == EINTR) return;
		return (E_SBREAK);
	}

	if ( num == 0 ) return (E_SBREAK);
 
	memset(Buf_head, 0, sizeof(Buf_head));
	memcpy(Buf_head, tmp_buf, 4);	
	nLen = atoi(Buf_head);
	if ( nLen == 0 ) return (E_SBREAK);

   	while((num=read(socket_id_new, tmp_Str, nLen))<=0)
	{
	  	if(errno==EINTR) continue;
		return(E_SBREAK);
        }

	memcpy(buf, tmp_Str, nLen);

	return num ;
}
