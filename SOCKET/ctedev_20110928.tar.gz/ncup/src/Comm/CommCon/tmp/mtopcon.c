/***********  ������ ****************/ 
/***     cc menu.c -lcurses -omenu            */ 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <stropts.h>
#include <poll.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <sys/param.h>
#include <errno.h>
#include <stdio.h>
#include <curses.h>
#include <ctype.h>
#include <setjmp.h>


#define _EXTERN_
#include "HtLog.h"

#define E_SBREAK -1
#define    ENTER 10 
#define    ESCAPE 27 
#define    BUF_SIZE 1800 

char		gsLogFile[LOG_NAME_LEN_MAX];
static  int Timeout = 0;
jmp_buf Stackbuf;

char   sIpAddr[20 + 1];
int    nPort;

int iSocketId;

int ProcCommand(char *MsgCode);

int main(int argc,char **argv) 
{ 
	/*
   int key,code,iPKey; 
   int selected_item; 
   char ss[81]; 
   char sResult[128];
   */
   char MsgCode[4];


   if (argc != 4){
	   printf("USE: %s ǰ��IP��ַ �˿� ����\n", argv[0]);
	   printf("����:\n");
	   printf("    ����-��·����   :  6131 \n");
	   printf("    ����-ǩ��       :  6111 \n");
	   printf("    ����-ǩ��       :  6121 \n");
	   printf("    ����-����MAC��Կ:  6071 \n");
	   printf("    ����-����PIN��Կ:  6070 \n");
	   printf("    ����-����PIN��Կ:  6323 \n");
	   exit(1);
   }

   strcpy(sIpAddr, argv[1]);
   nPort = atoi(argv[2]);
   strcpy(MsgCode, argv[3]);

   if(ProcCommand(MsgCode)==0)
      return(0); 
   else
      return(-1); 
} 


int ProcCommand(char *MsgCode)
{
	int code;
	char sMsgBuf[1024];
	/*
	int iBufLen;
    char sTemp[5];
    char sResult[128];
	*/


	memset(sMsgBuf, '\0', sizeof(sMsgBuf));
	memset(sMsgBuf, ' ', 521);
    memcpy(sMsgBuf, MsgCode, 4);

	printf("����ǰ��....");
	iSocketId = tcpOpen(sIpAddr, nPort, 2); 
	if (iSocketId < 0){
	      printf("����ǰ��ͨѶ��[%d],id=%d\n", errno,iSocketId);
		  return(-1);
	}

	printf("\n������Ϣ....");
    code= WriteSocket(iSocketId, sMsgBuf, strlen(sMsgBuf));
    if (code < 0)
    {
        printf("������Ϣ��[%d]", code);
        tcpClose(iSocketId);
        return(-1);
    }
	printf("\n�ȴ�Ӧ��....");

    code = ReadSocket(iSocketId, sMsgBuf, 10);
    if(code < 0)
    {
        printf("������Ϣ��[%d]",code);
        tcpClose(iSocketId);
        return(-1);
    }  
    tcpClose(iSocketId);
	printf("\n");

    if(memcmp(sMsgBuf + 4, "00",  2)==0)
    {
        printf("������ɹ�! ");
    	return(0);
    }
    else
    {
		
        printf("�����ʧ��! ");
    	return(-1);
    }
}

int tcpOpen (hostaddress,hostport,retrys)
char *hostaddress;
int  hostport;
int  retrys;
{
	struct sockaddr_in remote;
	int  sock;

    bzero(&remote, sizeof(remote));
    remote.sin_family = AF_INET;
	remote.sin_addr.s_addr = inet_addr(hostaddress);
    remote.sin_port = htons(hostport);

	while (retrys) 
	{
		if ( (sock = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
       	{
			if ( retrys > 0) 
			{	
				retrys--;
				continue;
			}
        	return(-2);
       	}

     	if ( connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0 )
       	{
			tcpClose(sock);
			if ( retrys > 0) 
			{	
				retrys--;
				continue;
			}
        	return(-3);
       	}

     	return(sock);
	} /* while */

       	return(-4);
}

/*
 * Function Name: tcpClose 
 * Parameter 1  : sock      Ҫ�رյ�socket�� 
 */
int tcpClose( sock )
int sock;
{
    	if ( fcntl( sock, F_SETFL, FNDELAY ) < 0 )
      		return( -1 );
    	if ( sock != 0 )
      		shutdown( sock, 2 );
    	close(sock);
    	return( 0 );
}

/*
 * Function Name:  IOTimeOut
 * Parameter 1  :  no         ������
 */
void IOTimeOut(int no )
{
  Timeout = 1;
  longjmp( Stackbuf, Timeout ); 
}

int WriteSocket(int socket_id_new,char *buf, int len) 
{                                             
	int  num, iWritelen; 
	/*
	char Buf_head[5];
	*/
	char saSendBuf[BUF_SIZE];

  	if (len == 0) return(0);

   	memset(saSendBuf,0,sizeof(saSendBuf));

   	sprintf(saSendBuf, "%04d", len);
	memcpy(saSendBuf+4,buf,len);

	len = len + 4;

    iWritelen=0; 
    for(;;)
    {
  		while((num=write(socket_id_new,&saSendBuf[iWritelen],
				len-iWritelen))<=0)
   		{	
			if (errno == EINTR) continue;
			return(E_SBREAK);
   		}
  
   		iWritelen+=num;
		if(iWritelen>=len) break;
    }
    return(iWritelen);
}

int ReadSocket(int socket_id_new,char *buf ,int nTimeOut)  
{
	/*
	int num, nLen, I=0;
	*/
	int num, nLen;
	char tmp_buf[5], Buf_head[5];
	/*
	char tmp_Str[2000], sBody[1024];
	*/
	char tmp_Str[2000];

    Timeout = 0;
    signal( SIGALRM, IOTimeOut );
    alarm( nTimeOut );

    setjmp( Stackbuf );
    if ( Timeout )
    {
        alarm( 0 );
        return( -1 );
    }

    num = read(socket_id_new, tmp_buf, 4);
	if ( num < 0 )
	{
        if (errno == EINTR) return errno;
		return (E_SBREAK);
	}

	if ( num == 0 ) return (E_SBREAK);
 
	memset(Buf_head, 0, sizeof(Buf_head));
	memcpy(Buf_head, tmp_buf, 4);	
	nLen = atoi(Buf_head);
	if ( nLen == 0 ) return (E_SBREAK);

   	while((num=read(socket_id_new, tmp_Str, nLen))<=0)
	{
	  	if(errno==EINTR) continue;
		return(E_SBREAK);
        }

	memcpy(buf, tmp_Str, nLen);

	return num ;
}
