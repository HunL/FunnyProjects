/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: C003Comm.c			     									 */
/* DESCRIPTIONS: TCP/IP ȫ������Server/Client (ͬ���˿�֧�ֶ��client����)   */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/

#include "C003Comm.h"

#define NCMaxAddrL                      15
#define LCTrue                          1
#define NCMAXRemAddr                    16

#define C_TCP_MSG_LEN_IN_BIN(x)         (x == 'B')

int    lCPickParam();
int    C003CommInit (int , char **);
void vCQuit();
void vCFuneral();
void vCGoodPortPlus();
void vCKillAllSons();
void vCHandleChildDie(int);
int nCEstablishBind(unsigned int vnPortNum, void* vvpLocAddr, int* vhpSocketId);
int nCEstablishConnect(int viPortX);
void vCPortHandle(int viPortX);
void vCTcpSnd(int);
void vCTcpRcv(int);
void vCTcpSndEcho();

typedef struct {
    int                 hSocketId;
    unsigned int        nPortNum;
    int                 nLineIndex;
    char                saLocAddr[NCMaxAddrL + 1];
    char                saRemAddr[NCMAXRemAddr][NCMaxAddrL + 1];
} lpiListenPortInfDef;

pid_t                    gpidtMainPid;
int                      gnGoodPortN;
pid_t                    gpidtFatherPid;
int                      gnMaxPortN;
pid_t                    gpidtaSonPid[NCMaxPortN];
lpiListenPortInfDef      glpiaPort[NCMaxPortN];
int                      ghDataSocket;
pid_t                    gpidtSubPid;
int                      gnLoopNeed;
struct sockaddr_in       gsaddrAccept;
char                     gsTcpMsgLenType;
int                      gnTcpMsgLenL;
int                      gnTcpModeFullDuplex;
int                      gnTcpModeServer;
int                      gnPortX;
unsigned long             longIP; 

short					gnTimeOver;
short					gnTimeOverRcv;

int main(int argc, char **argv) 
{
    int              liX;
    int              nReturnCode, llResult, status;
    int              lnLineNumber;
    unsigned int     lsckltAddrLen;
    char*            lspTmp;
    pid_t            lpid;
    fd_set           readfds;
    int              fdmax = 0;

    gpidtMainPid = 0;
    gnGoodPortN = 0;
    nReturnCode = C003CommInit(argc, argv);
    if (nReturnCode != 0) {
        printf("C003Comm: C003CommInit error %d\n", nReturnCode);
        exit(-1);
    }

    if((gpidtFatherPid = getpid()) == -1) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call getpid(gpidtFatherPid) error %d\n", errno);
        exit(-2);
    } /* end of if */

    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call getpid(gpidtFatherPid) %d\n", gpidtFatherPid);
    gpidtMainPid = gpidtFatherPid;

    gnTcpModeFullDuplex = NTrue;
    gnTcpModeServer = NTrue;
    
    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "gnTcpModeFullDuplex[%d] gnTcpModeServer[%d]\n", 
          gnTcpModeFullDuplex, gnTcpModeServer);

    if ((lspTmp = getenv(SAMEnvCommMsgLenFmt)) == NULL) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call getenv(SAMEnvCommMsgLenFmt) error %d\n", errno);
        exit(-10);
    } /* end of if */

    gsTcpMsgLenType = *lspTmp++;
    if(((gnTcpMsgLenL = atoi(lspTmp)) < 0) || (gnTcpMsgLenL > NCMaxTcpMsgLenL)) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call atoi(gnTcpMsgLenL) error %d\n", errno);
        exit(-11);
    } /* end of if */
    
    /* ���ý��ճ�ʱʱ�� */
    if((lspTmp = getenv("TL_COMM_TIME_OVER")) == NULL) 
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "getenv TL_COMM_TIME_OVER error, %d", errno);
		DbsDisconnect ();
        exit(-6);
    } /* end of if */
    if(((gnTimeOver = atoi(lspTmp)) < 0))
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "atoi(gnTimeOver) error, %d", errno);
		DbsDisconnect ();
        exit(-7);
    } /* end of if */
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "gnTimeOver[%d]", gnTimeOver);

    if((lspTmp = getenv("TL_COMM_TIME_OVER_RCV")) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "getenv TL_COMM_TIME_OVER_RCV error, %d", errno);
		DbsDisconnect ();
        exit(-6);
    } /* end of if */
    if(((gnTimeOverRcv = atoi(lspTmp)) < 0))
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "atoi(gnTimeOverRcv) error, %d", errno);
		DbsDisconnect ();
        exit(-7);
    } /* end of if */
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "gnTimeOverRcv[%d]", gnTimeOverRcv);

    memset(gsLineIndex, 0, sizeof(gsLineIndex));
    strcpy (gsLineIndex, getenv(SAMEnvCommLineCfgKey));
    
    if (nReturnCode = lCPickParam()) {
        DbsDisconnect();
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "lCPickParam error, [%d][%d]\n", nReturnCode, errno);
        exit(-4);
    } /* end of if */
    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "gnMaxPortN [%d]\n", gnMaxPortN);
    
    DbsDisconnect();

    for (liX = 0; liX < gnMaxPortN; liX++)
        gpidtaSonPid[liX] = -1;
    
    if (sigset(SIGTERM, vCFuneral) == SIG_ERR) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call sigset(SIGTERM) error %d\n", errno);
        exit(-12);
    } /* end of if */

    if (sigset(SIGUSR1, vCGoodPortPlus) == SIG_ERR) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call sigset(SIGUSR1) error %d\n", errno);
        exit(-13);
    } /* end of if */
    
    if (sigset(SIGCLD, vCHandleChildDie) == SIG_ERR) {
        exit(-20);
    } /* end of if */
    
    sigset(SIGPIPE, SIG_IGN);

    for (liX = 0; liX < gnMaxPortN; liX++) {
        if (llResult = nCEstablishBind(
                         glpiaPort[liX].nPortNum,
                         &glpiaPort[liX].saLocAddr[0],
                         &glpiaPort[liX].hSocketId))
            exit(-14);
    } /* end of for */

    for (liX = 0; liX < gnMaxPortN; liX++) {
        if (listen(glpiaPort[liX].hSocketId, NCListenBlkLogNDft) == -1) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call listen() error %d", errno);
            exit(-15);
        } /* end of if */
    } /* end of for */

    lsckltAddrLen = sizeof(gsaddrAccept);
    vCKillAllSons();
    sleep(1);
    gnLoopNeed = NTrue;

    while (1) {
        FD_ZERO(&readfds);
        for (liX = 0; liX < gnMaxPortN; ++liX) {
             FD_SET(glpiaPort[liX].hSocketId, &readfds);
             fdmax = glpiaPort[liX].hSocketId > fdmax ? glpiaPort[liX].hSocketId : fdmax;
        }
        if (select(fdmax + 1, &readfds, NULL, NULL, NULL) < 0) {
            if (errno == EINTR)
                continue;
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call select error: %d", errno);
            exit(-30);
        }
        for (liX = 0; liX < gnMaxPortN; liX++) {
            if (FD_ISSET(glpiaPort[liX].hSocketId, &readfds)) {
                lsckltAddrLen = sizeof(gsaddrAccept);
                ghDataSocket = accept(glpiaPort[liX].hSocketId, (struct sockaddr *)&gsaddrAccept, &lsckltAddrLen);
                if (ghDataSocket < 0) {
                    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call accept error :%d", errno);
                    if (errno == EINTR) {
                        --liX;
                        continue;
                    }
                    exit(-31);
                }	               
               
                sighold(SIGCLD);
 
                if ((gpidtMainPid = fork()) == -1) {
                    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call fork() error %d\n", errno);
                    exit(-16);
                } /* end of if */

                if (gpidtMainPid == 0) {
                    sigrelse(SIGCLD);
                    vCPortHandle(liX);
                    exit(0);
                } else {
                    sigrelse(SIGCLD);
                    gpidtaSonPid[liX] = gpidtMainPid;
                    close(ghDataSocket);
                } /* end of if */
            }
        } /* end of for */
    }
} /* end of main */

int lCPickParam() 
{
    int                 lnLoop;
    int                 nPort, index; 
    Tbl_line_cfg_Def    tTblLineCfg;
    char                *lspTmp;

    gnMaxPortN = 0;
    nPort      = 0;
    memset(&tTblLineCfg, 0, sizeof(tTblLineCfg));
    
    if (gnTcpModeFullDuplex && gnTcpModeServer)
        gnMaxPortN = -1;

    if ((lspTmp = getenv(SAMEnvCommLineCfgKey)) == NULL) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call getenv(SAMEnvCommLineCfgKey, error %d\n", errno);
        return -1;
    }
    if ((tTblLineCfg.usage_key = atoi(lspTmp)) < 0) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call atoi(tTblLineCfg.usage_key), error %d\n", errno);
        return -2;
    }

    memcpy(&tTblLineCfg.srv_id[0], &gsSrvId[0], SRV_ID_LEN);

    DbsLINECFG(DBS_CURSOR, &tTblLineCfg);

    if (DbsLINECFG(DBS_OPEN, &tTblLineCfg))
        return -3;

    while (DbsLINECFG(DBS_FETCH, &tTblLineCfg) == 0) {
        if (gnMaxPortN >= NCMaxPortN) {
            DbsLINECFG(DBS_CLOSE,&tTblLineCfg);
            return -4;
        }
        
        if (gnTcpModeFullDuplex && gnTcpModeServer) {
            if (tTblLineCfg.out_sock_num != nPort) {
                nPort = tTblLineCfg.out_sock_num;
                index = 0;
                ++gnMaxPortN;
                memset(&glpiaPort[gnMaxPortN].saLocAddr[0], 0, 
                        sizeof(glpiaPort[gnMaxPortN].saLocAddr));
                memcpy(&glpiaPort[gnMaxPortN].saLocAddr[0], &tTblLineCfg.local_addr[0],
                       sizeof(glpiaPort[gnMaxPortN].saLocAddr)); 
                       glpiaPort[gnMaxPortN].nPortNum = tTblLineCfg.out_sock_num;
                       glpiaPort[gnMaxPortN].nLineIndex = tTblLineCfg.line_index;        
            }
            if (index >= NCMAXRemAddr) {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Remote Addr Num: [%d] Too Large\n", index);
                continue; 
             }
            memcpy(glpiaPort[gnMaxPortN].saRemAddr[index], &tTblLineCfg.remote_addr[0], 
                   sizeof(glpiaPort[gnMaxPortN].saRemAddr[0]));
            CommonRTrim(glpiaPort[gnMaxPortN].saRemAddr[index]);
            CommonLTrim(glpiaPort[gnMaxPortN].saRemAddr[index]);
            ++index;
            continue;                  
        }     
      
 
        memset(&glpiaPort[gnMaxPortN].saLocAddr[0], 0, 
               sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy(&glpiaPort[gnMaxPortN].saLocAddr[0], &tTblLineCfg.local_addr[0],
               sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy(glpiaPort[gnMaxPortN].saRemAddr[0], 
               &tTblLineCfg.remote_addr[0], sizeof(glpiaPort[gnMaxPortN].saRemAddr[0]));
        
        CommonRTrim(glpiaPort[gnMaxPortN].saRemAddr[0]);
        CommonLTrim(glpiaPort[gnMaxPortN].saRemAddr[0]);
        
        glpiaPort[gnMaxPortN].nLineIndex = tTblLineCfg.line_index; 
        glpiaPort[gnMaxPortN++].nPortNum = tTblLineCfg.out_sock_num; 

        if(gnTcpModeFullDuplex)
            continue;

        memset(&glpiaPort[gnMaxPortN].saLocAddr[0], 0,
               sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy(&glpiaPort[gnMaxPortN].saLocAddr[0], &tTblLineCfg.local_addr[0],
               sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy(glpiaPort[gnMaxPortN].saRemAddr[0], 
               &tTblLineCfg.remote_addr[0], sizeof(glpiaPort[gnMaxPortN].saRemAddr[0]));
        
        CommonRTrim(glpiaPort[gnMaxPortN].saRemAddr[0]);
        CommonLTrim(glpiaPort[gnMaxPortN].saRemAddr[0]);
        
        glpiaPort[gnMaxPortN].nLineIndex = tTblLineCfg.line_index; 
        glpiaPort[gnMaxPortN++].nPortNum = tTblLineCfg.in_sock_num; 
    
    } /* end of for */

    if (DbsLINECFG(DBS_CLOSE, &tTblLineCfg))
        return -5;
    
    if (gnTcpModeFullDuplex && gnTcpModeServer) 
        ++gnMaxPortN;

    return 0;
} /* end of lCPickParam */

void vCKillAllSons() {

    int     liX;
    int     lnResult;
    int     lnSleepNeed = NFalse;

    if (lnResult = sigignore(SIGCLD)) {
        exit(-18);
    } /* end of if */

    if (lnResult = sigignore(SIGUSR1)) {
        exit(-19);
    } /* end of if */

    for (liX = 0; liX < gnMaxPortN; liX++) {
        if(gpidtaSonPid[liX] != -1) {
            kill(gpidtaSonPid[liX], SIGTERM);
            gpidtaSonPid[liX] = -1;
            lnSleepNeed = NTrue;
        } /* end of if */
    } /* end of for */
    
    if (lnSleepNeed)
        sleep(3);

    if (sigset(SIGCLD, vCHandleChildDie) == SIG_ERR) {
        exit(-20);
    } /* end of if */

    sleep(1);

    if (sigset(SIGUSR1, vCGoodPortPlus) == SIG_ERR) {
        exit(-21);
    } /* end of if */
} /* end of vCKillAllSons */

int nCEstablishBind(unsigned int    vnPortNum,
                    void*            vvpLocAddr,
                    int*                vhpSocketId) 
{
    int                    lhListenSocket;
    int                    llOpt;
    struct linger        lslngrOpt;
    struct sockaddr_in    lsaddrinBind;
    int                    lnRetryNeed;

    for (lnRetryNeed = NCRetryTimeDft; lnRetryNeed-- > 0;) {
        if ((lhListenSocket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
            return -1;
        } /* end of if */

        llOpt = LCTrue;
        if (setsockopt(lhListenSocket, SOL_SOCKET, SO_KEEPALIVE, &llOpt, sizeof(llOpt))) {
            close(lhListenSocket);
            if (lnRetryNeed)
                continue;
            return -2;
        } /* end of if */

        lslngrOpt.l_onoff = LCTrue;
        lslngrOpt.l_linger = LCTrue;
        if (setsockopt(lhListenSocket, SOL_SOCKET, SO_LINGER, &lslngrOpt, sizeof(lslngrOpt))) {
            close(lhListenSocket);
            if (lnRetryNeed)
                continue;
            return -3;
        } /* end of if */

        llOpt = LCTrue;
        if (setsockopt(lhListenSocket, SOL_SOCKET, SO_REUSEADDR, &llOpt, sizeof(llOpt))) {
            close(lhListenSocket);
            if(lnRetryNeed)
                continue;
            return -4;
        } /* end of if */

        lsaddrinBind.sin_family = AF_INET;
        lsaddrinBind.sin_port = htons(vnPortNum);
        lsaddrinBind.sin_addr.s_addr = inet_addr(vvpLocAddr);
        
        if (bind(lhListenSocket, (struct sockaddr*)(&lsaddrinBind), sizeof(lsaddrinBind))) {
            close(lhListenSocket);
            if (lnRetryNeed) {
                sleep(LCPauseDft);
                continue;
            } /* end of if */
            return -5;
        } /* end of if */
        *vhpSocketId = lhListenSocket;
        return 0;
    } /* end of for */
} /* end of nCEstablishBind */

void vCPortHandle(int viPortX) 
{
    int             liX, iRet, i;
    unsigned int    lsckltAddrLen;
    char            lsTmp[NCMaxAddrL + 2];
    
    gnPortX = viPortX;
    
    if (gnTcpModeFullDuplex || viPortX % 2 == 0) {
        HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "LineStateChg LINE_STATE_CONNECT, gsSrvId[%s], gsLineIndex[%s]", gsSrvId, gsLineIndex);
        DbsConnect();
        iRet = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_CONNECT);
        if (iRet) 
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "LineStateChg srv_id: [%s], line_index: [%d] error: [%d]\n",
                  gsSrvId, glpiaPort[viPortX].nLineIndex, iRet);
        DbsDisconnect();        
    } 

    if ((gnTcpModeFullDuplex) &&
        ((gpidtSubPid = fork()) == -1)) {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call fork() error %d\n", errno);
        exit(-24);
    } /* end of if */

    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "gnTcpModeFullDuplex=[%d],viPortX=[%d],gpidtSubPid=[%d]\n",
          gnTcpModeFullDuplex,viPortX,gpidtSubPid);
    
    if (((!gnTcpModeFullDuplex) &&
         (viPortX % 2 != 0)) ||
         ((gnTcpModeFullDuplex) &&
          (gpidtSubPid == 0))) {
        vCTcpRcv(viPortX);
    } else {
        vCTcpSnd(viPortX);
    } /* end of if */
} /* end of vCPortHandle */

int nCEstablishConnect(int viPortX) 
{
    int                        lnRetrying;
    int                        lnLoopCtrl;
    struct sockaddr_in        lsaddrinRemote;
    int                        llOpt;
    struct linger            lslngrOpt;

    lnRetrying = NFalse;
    for (lnLoopCtrl = NCRetryTimeDft; lnLoopCtrl > 0; lnLoopCtrl--) {
        if ((ghDataSocket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "socket error %d\n", errno);
            return -1;
        } /* end of if */

        llOpt = LCTrue;
        if (setsockopt(ghDataSocket, SOL_SOCKET, SO_KEEPALIVE, &llOpt, sizeof(llOpt))) {
            close(ghDataSocket);
            return -2;
        } 

        lslngrOpt.l_onoff = LCTrue;
        lslngrOpt.l_linger = LCTrue;
        if (setsockopt(ghDataSocket, SOL_SOCKET, SO_LINGER, &lslngrOpt, sizeof(lslngrOpt))) {
            close(ghDataSocket);
            return -3;
        } 

        llOpt = LCTrue;
        if (setsockopt(ghDataSocket, SOL_SOCKET, SO_REUSEADDR, &llOpt, sizeof(llOpt))) {
            close(ghDataSocket);
            return -4;
        } 

        memset(&lsaddrinRemote, 0, sizeof(lsaddrinRemote));
        lsaddrinRemote.sin_port = htons(glpiaPort[viPortX].nPortNum);
        lsaddrinRemote.sin_family = AF_INET;
        lsaddrinRemote.sin_addr.s_addr = inet_addr(glpiaPort[viPortX].saRemAddr[0]);
           HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "port %d ip %s\n", glpiaPort[viPortX].nPortNum,
              glpiaPort[viPortX].saRemAddr[0]);

        if (connect(ghDataSocket, (struct sockaddr*)(&lsaddrinRemote), sizeof(lsaddrinRemote))) {
            lnRetrying = NTrue;
            close(ghDataSocket);
            sleep(5);
            continue;
        } /* end of if */
        break;
    } /* end of for */

    if (lnLoopCtrl <= 0) {
        close(ghDataSocket);
        return -5;
    } /* end of if */

    return 0;
} /* end of nCEstablishConnect */

void vCTcpSnd(int viPortX) 
{    
    int    lnMsgOutLen;
    int    lnMsgInLen;
    int    nReturnCode;
    char   sMsgInBuf[NCMaxMsgBufLen+1];
    char   sMsgOutBuf[NCMaxMsgBufLen+1];    
    char   sMsgLen[NCMaxTcpMsgLenL+1];
    
    
    sigset(SIGALRM, vCTcpSndEcho);
    
    for(;;) {        
        lnMsgInLen = NCMaxMsgBufLen;                        
        
        alarm(gnTimeOver);
        
        nReturnCode = MsqRcv(gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK,
                             &lnMsgInLen, sMsgInBuf);
        if (nReturnCode) 
        {
        	alarm(0);
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR) 
            {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "MsqRcv error, %d\n", errno);
                HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "before LineStateChg LINE_STATE_CONNECT");
                DbsConnect();
                nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_CONNECT);
                if (nReturnCode) {
                    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "LineStateChg error, %d\n", nReturnCode);
                }
                DbsDisconnect();
                HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "after LineStateChg LINE_STATE_CONNECT");
                if (gnTcpModeFullDuplex)
                    kill(gpidtSubPid, SIGTERM);
                vCQuit();
            } 
            else 
            {
                continue;
            }
        }
        alarm(0);
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "MsqRcv ok len[%d]\n", lnMsgInLen);
        
        HtWriteLog(gsMsgFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
			sMsgInBuf, lnMsgInLen);

        lnMsgInLen = lnMsgInLen-(SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER);

        memset(&sMsgOutBuf[0], 0, sizeof(sMsgOutBuf));
        if(sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER] == '\x2E')
        {
            sprintf(&sMsgOutBuf[0],"%04d",lnMsgInLen-46);
            memcpy(&sMsgOutBuf[4], &sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+46], lnMsgInLen-46);
            lnMsgOutLen = lnMsgInLen + 4 - 46;
        }
        else
        {
            sprintf(&sMsgOutBuf[0],"%04d",lnMsgInLen);
            memcpy(&sMsgOutBuf[4],&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER],lnMsgInLen);
            lnMsgOutLen = lnMsgInLen + 4;
        }    
                
        if (nReturnCode = nCSocketSnd(ghDataSocket, &sMsgOutBuf[0], &lnMsgOutLen)) 
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "socket snd error, %d\n", errno);
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "before LineStateChg LINE_STATE_CONNECT");
            DbsConnect();
            nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_CONNECT);
            if (nReturnCode) {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "LineStateChg error, %d\n", nReturnCode);
            }
            DbsDisconnect();
            HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "after LineStateChg LINE_STATE_CONNECT");
            if (gnTcpModeFullDuplex)
                kill(gpidtSubPid, SIGTERM);
            exit(-29);
        }
        
        HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
                    sMsgOutBuf, lnMsgOutLen);

        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "socket[%d] snd ok len[%d]\n", ghDataSocket,lnMsgOutLen);
    } /* end of for */
} /* end of vCTcpSnd */

void vCTcpRcv(int viPortX) 
{    
    int     lnDataL;         
    int     lnMsgInLen;
    int     lnMsgOutLen;
    int     nReturnCode;
    char    sMsgLen[NCMaxTcpMsgLenL+1];
    char    sMsgInBuf[NCMaxMsgBufLen + 1];
    char    sMsqType[FLD_MSQ_TYPE_LEN + 1];  
    char    sMsgOutBuf[NCMaxMsgBufLen + 1];
    char    sClientAddr[INET_ADDRSTRLEN+1] = {0};   
    char    sCurrentTime[14+1] = {0};         

    for(;;) {        
        lnDataL = gnTcpMsgLenL;      
        /*        
        alarm(gnTimeOverRcv);*/
                
        memset(&sMsgLen[0], 0, sizeof(sMsgLen));
        if (nReturnCode = nCSocketRcv(ghDataSocket, &sMsgLen[0], &lnDataL, 0)) 
        {
        	alarm(0);
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "socket rcv error, %d\n", errno);
            sleep(2);
            vCQuit();
        }
        alarm(0);        
        
        inet_ntop(AF_INET, &gsaddrAccept.sin_addr, sClientAddr, sizeof(sClientAddr)); 
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "\312\325\265\275IP[%s]\301\254\275\323\n", 
                  sClientAddr);             
                
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "socket rcv ok [%d] len:[%d] buf:[%s]\n", 
              nReturnCode, lnDataL, &sMsgLen[0]);   
              
        if(lnDataL<=0)
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket rcv len=%d", lnDataL);
            sleep(1);
			vCQuit();
		}        
              
        /* ECHO TEST ���� */
        if( memcmp(&sMsgLen[0],"0000",4) == 0 ) 
		{
			HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "socket rcv echo test");
            continue;
        }
                 
        /* ���ĳ��� - ACSII */
        lnMsgInLen = atoi(sMsgLen); 
        
        memset(sMsgInBuf, 0, sizeof(sMsgInBuf));
        if (nReturnCode = nCSocketRcv(ghDataSocket, &sMsgInBuf[0], &lnMsgInLen, 0)) 
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "socket rcverror, %d\n", errno);
            vCQuit();
            exit(-34);
        }        
        
        HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
                      sMsgInBuf, lnMsgInLen);                                                          
       
        memset(sMsgOutBuf, ' ', sizeof(sMsgOutBuf));
        memcpy(sMsgOutBuf, gsSrvId, SRV_ID_LEN);
        
        /* ��ȡ��ǰ���ձ���ʱ�� */
        CommonGetCurrentTime (sCurrentTime);
        memcpy(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN,
               sCurrentTime, FLD_TIME_STAMP_LEN);
               
        /* GF����ͷ��ո� */
       memset(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN,
               ' ', FLD_GF_HEADER);
        
        memcpy(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,
               sMsgInBuf, lnMsgInLen);
        lnMsgOutLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+lnMsgInLen;
        
        HtWriteLog(gsMsgFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
			sMsgOutBuf, lnMsgOutLen);
			
        nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, lnMsgOutLen, sMsgOutBuf);
        if (nReturnCode) 
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "MsqSnd ToSrvId[%s] error [%d][%d]\n",
                  gsToSrvId, nReturnCode, errno);
            sleep(1);
            continue;
        }
        HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "MsqSnd ToSrvId[%s] ok\n", gsToSrvId);
        
        if (gnTcpModeFullDuplex && getppid() == 1) 
        {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "zombile Process exit!\n");
            exit(-1);
        }
    } /* end of for */
} /* end of vCTcpRcv */

void vCHandleChildDie(int sig) 
{
    pid_t     lpidtSonPid;
    int       llStatLoc, nReturnCode;
    int       liX, status;

    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Begin wait son die pid = %d gnPortX = %d\n", 
              gpidtMainPid, gnPortX);
    sigset(SIGCLD, vCHandleChildDie);
    if (gpidtMainPid == 0) {
        if ((lpidtSonPid = wait(&llStatLoc)) == -1) {
            exit(-37);
        } /* end of if */

        DbsConnect();
        nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
        if (nReturnCode) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "LineStateChg error, %d\n", nReturnCode);
        }
        DbsDisconnect();

        exit(0);
    } else {
        if (sigignore(SIGUSR1)) {
            exit(-38);
        } /* end of if */

        while ((lpidtSonPid = waitpid(-1, &status, WNOHANG)) > 0) {
            for (liX=0; liX < gnMaxPortN; liX++) {
                if (lpidtSonPid == gpidtaSonPid[liX]) {
                    gpidtaSonPid[liX] = -1;
                    break;
                }
            }
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "lpid: [%d] exit\n", lpidtSonPid);
        }
        gnLoopNeed = NFalse;
    } /* end of if */
} /* end of vCHandleChildDie */

void vCFuneral() {

    int    lnErrLevel, nReturnCode;

    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Process begin to die pid = %d son_pid: %d\n", 
          gpidtMainPid, gpidtSubPid);
    if (sigignore(SIGTERM)) {
        exit(-40);
    } /* end of if */

    if (sigignore(SIGCLD)) {
        exit(-41);
    } /* end of if */

    if (sigignore(SIGUSR1)) {
        exit(-42);
    } /* end of if */

    if (gpidtMainPid == 0) {
        if ((gnTcpModeFullDuplex) &&
            (gpidtSubPid != 0)) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "LineStateChg: [%d], gsSrvId[%s], gsLineIndex[%s]", gnPortX, gsSrvId, gsLineIndex);
            
            DbsConnect();
            nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
            if (nReturnCode) {
                HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "LineStateChg error, %d\n", nReturnCode);
            }
            DbsDisconnect();
            
            kill(gpidtSubPid, SIGTERM);
            sleep(3);
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Kill son pid = %d\n", gpidtSubPid);
        } /* end of if */
        close(ghDataSocket);
        exit(0);
    } else {
        vCKillAllSons();
        exit(0);
    } /* end of if */
} /* end of vCFuneral */

void vCGoodPortPlus() 
{
    if (++gnGoodPortN == gnMaxPortN) {
        if (sighold(SIGCLD)) {
            HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "Call sighold(SIGCLD) error %d\n", errno);
            exit(-43);
        } /* end of if */

        if (sighold(SIGUSR1)) {
            exit(-44);
        } /* end of if */

        if (sigrelse(SIGCLD)) {
            exit(-45);
        } /* end of if */

        if (sigrelse(SIGUSR1)) {
            exit(-46);
        } /* end of if */
    } /* end of if */
} /* end of vCGoodPortPlus */

int C003CommInit (int argc, char **argv)
{
    int             i;
    int             nReturnCode;
    long            lUsageKey;
    char*			lspTmp;
    Tbl_srv_inf_Def tTblSrvInf;

    /* get server id, arg 1 */
    strcpy (gsSrvId, argv[1]);
    strcpy (gsSrvSeqId, argv[2]);
    strcpy(gsToSrvId, argv[3]);

    if (getenv(SRV_USAGE_KEY))
        lUsageKey=atoi (getenv(SRV_USAGE_KEY));
    else
        return -1;

    /* connect to database */
    nReturnCode = DbsConnect ();
    if (nReturnCode) return (nReturnCode);

    /* get log file name from tbl_srv_inf */
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nReturnCode) {
        DbsDisconnect ();
        return (nReturnCode);
    }
    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_id, gsSrvSeqId);
    sprintf (gsMsgFile, "%s.%s.msg", tTblSrvInf.srv_id, gsSrvSeqId);

    /* init msg queue */
    memset((char *)gatSrvMsq, 0, SRV_MSQ_NUM_MAX * sizeof (T_SrvMsq));
    nReturnCode = MsqInit(gsSrvId, gatSrvMsq);
    if (nReturnCode) 
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "MsqInit error, %d\n", nReturnCode);
        DbsDisconnect();
        return (nReturnCode);
    }
    

    
    return 0;
}

void vCQuit()
{
    close(ghDataSocket);

    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "vCQuit\n");

    exit(-30);
}


void vCTcpSndEcho()
{
	int		llResult;
	int		lnDataL;
	char	saMsg0[4+1];

	memset(saMsg0, '0', sizeof(saMsg0));

	lnDataL = 4;

    if(llResult = nCSocketSnd(ghDataSocket,saMsg0,&lnDataL))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCTcpSndEcho error, %d", errno);
		close(ghDataSocket);
		exit(-1);
    }
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "vCTcpSndEcho ok");
    return;
}
