#ifndef TL_HDR_FILE_C800RCVSND
#define TL_HDR_FILE_C800RCVSND

#include <errno.h>
#include <stdlib.h>

#define LOG_NAME_LEN_MAX                32
char                gsLogFile[LOG_NAME_LEN_MAX];

#define SACEnvCommTimeout               "TL_COMM_TIMEOUT"

#define LCMaxTimeout                    20
#define LCTcpRcvFlg                     0
#define LCTcpSndFlg                     0

#define NCRcvFlgReturnAfterData         1

#endif /* TL_HDR_FILE_C800RCVSND */
