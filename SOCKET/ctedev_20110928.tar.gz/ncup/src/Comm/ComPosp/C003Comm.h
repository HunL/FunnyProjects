#ifndef TL_HDR_FILE_C001COMM
#define TL_HDR_FILE_C001COMM

#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/times.h>
#include <sys/wait.h> 

#include "SrvDef.h"
#include "SrvParam.h"
#include "MsqOpr.h"
#include "ToOpr.h"
#include "HtLog.h"
#include "ErrCode.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "LineStat.h"

#define SAMEnvCommLineCfgKey            "TL_COMM_LINE_CFG_KEY"
#define SAMEnvCommMsgLenFmt             "TL_COMM_MSG_LEN_FORMAT"
#define SAMEnvCommTpduHdrLen			"TL_COMM_TPDU_HDR_LEN"
#define SAMEnvCommMode                  "TL_COMM_MODE"

#define NCRetryTimeDft                  5
#define LCPauseDft                      10
#define NCMaxPortN                      100
#define NCListenBlkLogNDft              5
#define NCMaxTcpMsgLenL                 4
#define NCMaxMsgBufLen                  1024

#define	NTrue							1
#define NFalse							0

char                gsSrvId[SRV_ID_LEN+1];
char                gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char                gsToSrvId[SRV_ID_LEN+1];
char                gsLogFile[LOG_NAME_LEN_MAX];
char                gsMsgFile[LOG_NAME_LEN_MAX];
Tbl_txn_inf_Def     gatTxnInf[TXN_INF_NUM_MAX];
T_SrvMsq            gatSrvMsq[SRV_MSQ_NUM_MAX];
char                gsLineIndex[2];

#endif /* TL_HDR_FILE_C001COMM */
