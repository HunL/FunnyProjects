/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: C005Comm.c			     									 */
/* DESCRIPTIONS: Comm with Bonus                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include "C005Comm.h"
#include "BPIpcInt.h"

#define  MSG_HEAD_LEN  4

char				gsSrvId[SRV_ID_LEN+1];
char				gsToSrvId[SRV_ID_LEN+1];
char				gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char				gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];
char				gsErrMsg[REPORT_ERR_MSG_LEN];

int					gnCommTpduL = 0;
char				gsCommTpdu[COMM_TPDU_LEN_MAX+1];
char				gsCommTerm[COMM_TERM_LEN_MAX+1];
char				sCommTermID[COMM_TERM_LEN_MAX+1];

char				gsIpAddr[20];
int					gnPort;
int					gnSocketID;
int					gnTimeOut;
int					gnSysError = 0;

void HandleExit (int n);
void tcpTimeOut();
void printHeader(char* sBuf);
void printReqBody(char* sBuf);
void printRspBody(char* sBuf);

#define	MAX_RSP_CODE_MAP_NUM	1000

int		nMaxRspCodeMapN, i;

int CommInit (short argc, char **argv);

int main(short	argc, char **argv)
{
	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	char	sIntMsgBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	char	sSrcSrvId[SRV_ID_LEN+1];
	int		nReturnCode;
	int 	nMsgInLen;
	int		nIntMsgLen;
	int		nMsgOutLen;
	char	sHostRspCode[5],sRspCodeDsp[33];
	char	sTrack2L[3],sTrack2V[38];
	char	sPanL[3],sPanV[20];
	char	sTxnAmt[13],sTxnAmtT[13];
	char    sDnrApproveCode[7];
	char    sLoopLen[4] = {0};

	if(argc < 4)
	{
		printf("Usage:%s srvid seq tosrvid ", argv[0]);
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "argc err");
		exit(-1);
	}

	nReturnCode = CommInit (argc, argv);
	if (nReturnCode)
	{
		printf("CommInit error[%d]\n",nReturnCode);
		exit(-2);
	}

	sigset(SIGTERM, HandleExit) ;

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s started", argv[0]);

	while (1)
	{
		memset(sMsgInBuf,0,sizeof(sMsgInBuf));
		nMsgInLen = MSQ_MSG_SIZE_MAX;
		sigrelse (SIGTERM);
		nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK,
								&nMsgInLen, sMsgInBuf);
		sighold (SIGTERM);
		if (nReturnCode)
		{
			if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"MsqRcv error, %d", nReturnCode);
				exit(-3);
			}
			else
				continue;
		}

		memset (sSrcSrvId, 0, sizeof (sSrcSrvId));
		memcpy (sSrcSrvId, sMsgInBuf, SRV_ID_LEN);

		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"received %d byte msg from %s", nMsgInLen, sSrcSrvId);

		nMsgInLen = nMsgInLen - SRV_ID_LEN*2 - FLD_MSQ_TYPE_LEN-FLD_TIME_STAMP_LEN;
		
		/*sprintf(sMsgOutBuf, "%04d", nMsgInLen);*/
		
		memcpy(sMsgOutBuf, sMsgInBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN, nMsgInLen);
        memcpy(sLoopLen, sMsgOutBuf, 3);
        if(atoi(sLoopLen) > 0)
            nMsgInLen = nMsgInLen - (512 - atoi(sLoopLen));
        
		gnSysError = 0;

		sigset(SIGALRM, tcpTimeOut);
		alarm(gnTimeOut);

		gnSocketID=tcpOpen(gsIpAddr,gnPort,2);
		if ( gnSocketID < 0 )
		{
			HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"tcpOpen error %d", gnSocketID);

			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "tcpOpen error %d", gnSocketID);


			alarm(0);
			gnSysError = -1;
		}
		else
		{
			HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"tcpOpen ok %d", gnSocketID);
		}
		if(gnSysError == 0)
		{
			nReturnCode=WriteSock(gnSocketID, nMsgInLen, sMsgOutBuf);
			if ( nReturnCode < 0 )
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"WriteSock error %d", nReturnCode);

				memset(gsErrMsg, 0, sizeof(gsErrMsg));
				sprintf(gsErrMsg, "WriteSocket error %d", nReturnCode);

				alarm(0);
				gnSysError = -2;
			}
		}

		if(gnSysError == 0)
		{
			memset(&ComBlock, 0, sizeof(ComBlock));
			nReturnCode=ReadSock(gnSocketID,ComBlock.Text);
			if ( nReturnCode < 0 )
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ReadSock error %d", nReturnCode);
				memset(gsErrMsg, 0, sizeof(gsErrMsg));
				sprintf(gsErrMsg, "ReadSocket error %d", nReturnCode);

				alarm(0);
				tcpClose(gnSocketID);
				continue;
			}
			ComBlock.iTotal = nReturnCode;
			HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
				(char *)ComBlock.Text, nReturnCode);
			/*������־ begin*/
            printHeader((char *)ComBlock.Text);
            printRspBody((char *)ComBlock.Text);
            /* ������־ end */
    
			tcpClose(gnSocketID);
		}
		alarm(0);	

	    nMsgOutLen = 0;
	    nMsgOutLen=4+nReturnCode+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN;
		memcpy(	sMsgOutBuf, gsSrvId, SRV_ID_LEN);
		memcpy(	sMsgOutBuf+SRV_ID_LEN, gsToSrvId, SRV_ID_LEN);
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2, "0000000000000000", FLD_MSQ_TYPE_LEN);
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN, "              ", FLD_TIME_STAMP_LEN);
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN, "    ", 4);
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+4,ComBlock.Text, nReturnCode);

        /* test by lgm */
        sleep(1);
        /* test */
		nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, nMsgOutLen, sMsgOutBuf);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"MsqSnd to %s error, %d", gsToSrvId, nReturnCode);

			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "MsqSnd to %s error %d", gsToSrvId, nReturnCode);

			continue;
		}

		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"send msg to %s", gsToSrvId);
	}
	return 0;
}

int lCPickParam()
{
	short				lnLoop;
	Tbl_line_cfg_Def	tTblLineCfg;
	char				*lspTmp;


    memset(
       &tTblLineCfg,
       0,
       sizeof(tTblLineCfg));

    if((lspTmp = getenv(
                    SAMEnvCommLineCfgKey)) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call getenv(SAMEnvCommLineCfgKey, error %d", errno);
		return -1;
	}
    if((tTblLineCfg.usage_key = atoi(
                                      lspTmp)) < 0) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call atoi(tTblLineCfg.usage_key), error %d", errno);
		return -2;
	}

    memcpy(
       &tTblLineCfg.srv_id[0],
       &gsSrvId[0],
       SRV_ID_LEN);

    DbsLINECFG(
       DBS_CURSOR,
       &tTblLineCfg);

    if(DbsLINECFG(
          DBS_OPEN,
          &tTblLineCfg))
        return -3;

    while(DbsLINECFG(
             DBS_FETCH,
             &tTblLineCfg) == 0)
    {
		memset( &gsIpAddr[0], 0x00, sizeof(gsIpAddr));
		memcpy( &gsIpAddr[0],
				&tTblLineCfg.remote_addr[0],
				sizeof(tTblLineCfg.remote_addr));

        gnPort = tTblLineCfg.out_sock_num;
    } /* end of for */

    if(DbsLINECFG(
          DBS_CLOSE,
          &tTblLineCfg))
        return -4;

    return 0;
} /* end of lCPickParam */

/*****************************************************************************/
/* FUNC:   int CommInit (short argc, char **argv)                            */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �������ݿ�, ����ȫ�ֱ���, ��ȡ���в���,                           */
/*         ��ʼ����Ϣ����                                                    */
/*****************************************************************************/
int CommInit (short argc, char **argv)
{
	int				i,liX;
	int				nReturnCode;
	Tbl_srv_inf_Def	tTblSrvInf;
    char			*lspTmp;
	int				lUsageKey;

	/* get server id arg 1; server seq arg 2; to server id arg 3 */
	strcpy(gsSrvId, argv[1]);
	strcpy(gsSrvSeqId, argv[2]);
	strcpy(gsToSrvId, argv[3]);
/*
	strcpy(gsIpAddr, argv[4]);
	gnPort = atoi(argv[5]);
*/
	/* connect to database */
    nReturnCode = DbsConnect ();
	if (nReturnCode) return (nReturnCode);

	/* get log file name from tbl_srv_inf */
	if (getenv(SRV_USAGE_KEY))
		lUsageKey=atoi (getenv(SRV_USAGE_KEY));
	else
		return -2;

	memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
	tTblSrvInf.usage_key = lUsageKey;
	memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
	nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
	if (nReturnCode)
		return (nReturnCode);

	sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_id, gsSrvSeqId);

	/* init msg queue */
	memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
	nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d", nReturnCode);
		return (nReturnCode);
	}

	if (getenv("TL_COMM_TIME_OUT"))
		gnTimeOut = atoi (getenv("TL_COMM_TIME_OUT"));
	else
		return -1;
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"gnTimeOut %d", gnTimeOut);

	memset(gsErrMsg, 0, sizeof(gsErrMsg));
	sprintf(gsErrMsg, "gnTimeOut %d", gnTimeOut);

    lCPickParam();

    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"Bonus Host IP[%s] Port[%d]", gsIpAddr,gnPort);
	/* disconnect db */
	nReturnCode = DbsDisconnect ();
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsDisconnect error, %d", nReturnCode);
	}
	return (0);
}

void HandleExit (int n)
{
	HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "HandleExit");
	exit( 1 );
}

/*
 * Function Name: tcpOpen
 * Parameter 1  : hostaddress  ��������IP��ַ
 * Parameter 2  : hostport     ���������˿ں�
 * Parameter 3  : retrys       ������������
 */

int tcpOpen (hostaddress,hostport,retrys)
char *hostaddress;
int  hostport;
int  retrys;
{
	struct sockaddr_in remote;
	int  sock;

    bzero(&remote, sizeof(remote));
    remote.sin_family = AF_INET;
	remote.sin_addr.s_addr = inet_addr(hostaddress);
    remote.sin_port = htons(hostport);

	while (retrys)
	{
		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"retrys %d", retrys);
		if ( (sock = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
       	{
			if ( retrys > 0)
			{
				retrys--;
				continue;
			}
        	return(-2);
       	}

		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"socket ok %d", sock);

     	if ( connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0 )
       	{
			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "connect error %s ip[%s] port[%d]",
				strerror(errno), hostaddress, hostport);
          HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			         "sconnect error %s ip[%s] port[%d]", strerror(errno), hostaddress, hostport);

			tcpClose(sock);
			if ( retrys > 0)
			{
				retrys--;
				continue;
			}
        	return(-3);
       	}

     	return(sock);
	} /* while */

	return(-4);
}

/*
 * Function Name: tcpClose
 * Parameter 1  : sock      Ҫ�رյ�socket��
 */
int tcpClose( sock )
int sock;
{
	if ( fcntl( sock, F_SETFL, FNDELAY ) < 0 )
		return( -1 );
	if ( sock != 0 )
		shutdown( sock, 2 );

	close( sock );
	return( 0 );
}

/*
 * Function Name:  tcpTimeOut
 */
void tcpTimeOut()
{
}

/*
 * Function Name:  ReadSock
 * Parameter 1  :  socketid   socket��
 * Parameter 2  :  buffer     ���ܻ�����
 * Parameter 3  :  timeout    ��ʱʱ��
 */
int ReadSock(socketid,buffer)
int socketid;
register char * buffer;
{
	int iRet;
	int num, nLen, I=0,nleft,nread;
 	unsigned char tmp_buf[5], Buf_head[5];
 	char tmp_Str[2000], sBody[1024];

   	num = read(socketid, tmp_buf, 4);
 	if ( num <= 0 )
 	{
 		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "read len error = %d", errno);
 		return (-1);
 	}

 	memset(Buf_head, 0, sizeof(Buf_head));
 	memcpy(Buf_head, tmp_buf, 4);
 	
    if (iRet = nMCalcIn(&nLen, tmp_buf, 4))
    {
        HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,  "nGetHexStr error %d", iRet);
        return -1;
    }
        
    /*int iRecvLen = iContentLen;
    
 	nLen = Buf_head[0]*256 + Buf_head[1];
	if ( nLen == 0 || nLen > BUF_SIZE )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "len error = %d", nLen);
		memset(gsErrMsg, 0, sizeof(gsErrMsg));
		sprintf(gsErrMsg, "read len error [%d]", nLen);

		return (-1);
	}*/
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "len = %d", nLen);

	nleft=nLen;
	while ( nleft > 0 )
	{
		nread = read(socketid, buffer, nleft);
		if (nread < 0)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"read socket error");
			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "read socket error %d", errno);

			return(-1);
		}
		if ( nread == 0 ) break;
		nleft -= nread;
		buffer += nread;

	}
	return (nLen-nleft);
}

/*
 * Function Name:  WriteSock
 * Parameter 1  :  socketid   socket��
 * Parameter 2  :  len        ���ͻ���������
 * Parameter 3  :  buffer     ���ͻ�����
 */
int WriteSock(socketid,len,buffer)
int socketid;
int len;
char * buffer;
{
	int  iRet;
	int  num, iWritelen;
 	unsigned char Buf_head[5] = {0};
 	char saSendBuf[BUF_SIZE];

 	if (len == 0) return(0);

 	memset(saSendBuf,0,sizeof(saSendBuf));
    
    if (iRet = nMCalcOut(len-4, Buf_head, 4))
    {
        HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,  "nGetHexStr error %d", iRet);
        return -1;
    }
    
    memcpy(saSendBuf, Buf_head, 4);
    
    memcpy(saSendBuf + 4, buffer+4, len-4);

	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
		saSendBuf, len);
    /*������־ begin*/
    printHeader(saSendBuf+4);
    printReqBody(saSendBuf);
    /* ������־ end */

    iWritelen=0;
	for(;;)
	{
		while((num=write(socketid,&saSendBuf[iWritelen],
				len-iWritelen))<=0)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"write socket error");
			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "write socket error %d", errno);

			return(-1);
		}

		iWritelen+=num;
		if(iWritelen>=len) break;
	}
	return(iWritelen);
}

void printHeader(char* sBuf)
{
    char* gsLogFile="CommBP.log";
    
    int i=0;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 
    "----------------------------------------------------------------------------");
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "BEGIN Header");
    
    /*HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ܳ��� [%4.4s]",sBuf + i);
    i += 4;*/
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�汾�� [%1.1s]",sBuf + i);
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ѻ��ʶ [%1.1s]",sBuf + i);
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ͨѶ���� [%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ͨѶ���� [%1.1s]",sBuf + i);    
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���շ���ʶ [%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���𷽱�ʶ [%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ˮ [%22.22s]",sBuf + i);
    i += 22;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%8.8s]",sBuf + i);
    i += 8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ʱ�� [%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���ش����ʶ [%2.2s]",sBuf + i);
    i += 2;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���ش������ [%7.7s]",sBuf + i);
    i += 7;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����λ1 [%8.8s]",sBuf + i);
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "END Header\n"); 
}

void printReqBody(char* sBuf)
{
    char* gsLogFile="CommBP.log";
    char sReqCode[7] = {0}; 
    
    memcpy(sReqCode, sBuf+57, 6);
    
    int i=80;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Body");
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��ϵͳ��ʶ [%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��ϵͳʱ�� [%10.10s]",sBuf + i);
    i += 10;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��ϵͳ��ˮ�� [%12.12s]",sBuf + i);
    i += 12;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ڵ��������ʶ [%8.8s]",sBuf + i);
    i += 8;
    if(!memcmp(sReqCode, "bms005", 6) || !memcmp(sReqCode, "000005", 6)) /* �����ֲ�ѯ */
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ǰҳ�� [%4.4s]",sBuf + i);    
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%19.19s]",sBuf + i);
        i += 19;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��ϵͳ������ [%80.80s]",sBuf + i);
        i += 80;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�̻��� [%15.15s]",sBuf + i);
        i += 15;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ն˺� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����Ա�� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�Ƿ�ֻ��ѯ�������� [%1.1s]",sBuf + i);
    }
    else if(!memcmp(sReqCode, "bms102", 6) || !memcmp(sReqCode, "100002", 6)) /* �࿨����֧�� */
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�յ������� [%11.11s]",sBuf + i);    
        i += 11;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�յ������� [%11.11s]",sBuf + i);    
        i += 11;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�̻��� [%15.15s]",sBuf + i);
        i += 15;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ն˺� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����Ա�� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ [%25.25s]",sBuf + i);
        i += 25;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�����ʶ [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�����¼�� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�������ֶθ��� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%19.19s]",sBuf + i);
        i += 19;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%1.1s]",sBuf + i);
        i += 1;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ѽ�� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����֧����� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ۼ����ֶ� [%10.10s]",sBuf + i);
    }
    else if(!memcmp(sReqCode, "bms201", 6) || !memcmp(sReqCode, "200001", 6)) /* ����֧������ */
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%19.19s]",sBuf + i);
        i += 19;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%1.1s]",sBuf + i);
        i += 1;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ѽ�� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����֧����� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "֧�����ֶ� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ�������� [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ���𷽱�ʶ [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ������ˮ [%22.22s]",sBuf + i);
        i += 22;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ�������� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ����ʱ�� [%6.6s]",sBuf + i);
    }
    else if(!memcmp(sReqCode, "bms202", 6) || !memcmp(sReqCode, "200002", 6)) /* ����֧������ */
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�յ������� [%11.11s]",sBuf + i);
        i += 11;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�̻���� [%15.15s]",sBuf + i);
        i += 15;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ն˱�� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����Ա�� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%19.19s]",sBuf + i);
        i += 19;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%1.1s]",sBuf + i);
        i += 1;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ѽ�� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����֧����� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "֧�����ֶ� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ�������� [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ���𷽱�ʶ [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ������ˮ [%22.22s]",sBuf + i);
        i += 22;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ�������� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ����ʱ�� [%6.6s]",sBuf + i);
        i += 6;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ������ [%25.25s]",sBuf + i);
    }
    else if(!memcmp(sReqCode, "bms301", 6) || !memcmp(sReqCode, "300001", 6)) /* ����֧���������� */
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%19.19s]",sBuf + i);
        i += 19;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%1.1s]",sBuf + i);
        i += 1;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ѽ�� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����֧����� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "֧�����ֶ� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ�������� [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ���𷽱�ʶ [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ������ˮ [%22.22s]",sBuf + i);
        i += 22;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ�������� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ����ʱ�� [%6.6s]",sBuf + i);
    }
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Body\n\n"); 
}

void printRspBody(char* sBuf)
{
    char* gsLogFile="CommBP.log";
    char sReqCode[7] = {0};
    
    memcpy(sReqCode, sBuf+53, 6);
    
    int i=76;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Body");
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��ϵͳ��ʶ [%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��ϵͳʱ�� [%10.10s]",sBuf + i);
    i += 10;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��ϵͳ��ˮ�� [%12.12s]",sBuf + i);
    i += 12;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ڵ��������ʶ [%8.8s]",sBuf + i);
    i += 8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ɹ�ʧ�ܱ�־ [%2.2s]",sBuf + i);
    i += 2;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ӧ�� [%7.7s]",sBuf + i);
    i += 7;
    if(!memcmp(sReqCode, "bms005", 6) || !memcmp(sReqCode, "000005", 6)) /* �����ֲ�ѯ */
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ҳ�� [%4.4s]",sBuf + i);    
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ǰҳ�� [%4.4s]",sBuf + i);    
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%19.19s]",sBuf + i);
        i += 19;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��ϵͳ������ [%80.80s]",sBuf + i);
        i += 80;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%30.30s]",sBuf + i);
        i += 30;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�����ʶ [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�����¼�� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�������ֶθ��� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������������ [%20.20s]",sBuf + i);
        i += 20;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����״̬ [%1.1s]",sBuf + i);
        i += 1;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���ֵ���ʱ�� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ֵ [%10.10s]",sBuf + i);
    }
    else if(!memcmp(sReqCode, "bms102", 6) || !memcmp(sReqCode, "100002", 6)) /* �࿨����֧�� */
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ҳ�� [%4.4s]",sBuf + i);    
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ǰҳ�� [%4.4s]",sBuf + i);    
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�յ������� [%11.11s]",sBuf + i);    
        i += 11;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�յ������� [%11.11s]",sBuf + i);    
        i += 11;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�̻��� [%15.15s]",sBuf + i);
        i += 15;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ն˺� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����Ա�� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ [%25.25s]",sBuf + i);
        i += 25;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�����ʶ [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�����¼�� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ѭ�������ֶθ��� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%19.19s]",sBuf + i);
        i += 19;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%1.1s]",sBuf + i);
        i += 1;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ѽ�� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����֧����� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ۼ����ֶ� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ע [%20.20s]",sBuf + i);
    }
	else if(!memcmp(sReqCode, "bms201", 6) || !memcmp(sReqCode, "200001", 6)) /* ����֧������ */
	{
	    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%1.1s]",sBuf + i);
	}
    else if(!memcmp(sReqCode, "bms202", 6) || !memcmp(sReqCode, "200002", 6))  /* ����֧������ */
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�յ������� [%11.11s]",sBuf + i);
        i += 11;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�̻���� [%15.15s]",sBuf + i);
        i += 15;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ն˱�� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����Ա�� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%19.19s]",sBuf + i);
        i += 19;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%3.3s]",sBuf + i);
        i += 3;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���� [%3.3s]",sBuf + i);
        i += 3;
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%1.1s]",sBuf + i);
		i += 1;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ܳ������ [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����֧��������� [%9.9s]",sBuf + i);
        i += 9;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������ֶ� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������� [%10.10s]",sBuf + i);
        i += 10;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ע [%20.20s]",sBuf + i);
        i += 20;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ���𷽱�ʶ [%4.4s]",sBuf + i);
        i += 4;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ������ˮ [%22.22s]",sBuf + i);
        i += 22;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ�������� [%8.8s]",sBuf + i);
        i += 8;
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ����ʱ�� [%6.6s]",sBuf + i);
    }
	else if(!memcmp(sReqCode, "bms301", 6) || !memcmp(sReqCode, "300001", 6)) /* ����֧���������� */
	{
	    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� [%1.1s]",sBuf + i);
	}
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Body\n\n"); 
}
