#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/times.h>
#include <sys/wait.h>
#include <signal.h>
#include <bits/signum.h>
#include <sys/types.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <unistd.h>
#include <stropts.h>
#include <poll.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <math.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "ErrCode.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "IpcInt.h"
#include "TxnNum.h"

#define MAX_BUFSIZE 	8192
#define BUF_SIZE 1800
#define TRUE            1
#define FALSE           0

#define IS_NUMBER_CHAR(x)               ( x >= '0' && x <= '9' )

#define	COMM_TPDU_LEN_MAX	10
#define COMM_TERM_LEN_MAX	23	

#define SAMEnvCommLineCfgKey            "TL_COMM_LINE_CFG_KEY"
#define SAMEnvCommMsgLenFmt             "TL_COMM_MSG_LEN_FORMAT"
#define SAMEnvCommTpduHdrLen			"TL_COMM_TPDU_HDR_LEN"
#define SAMEnvCommTpduHdrVal			"TL_COMM_TPDU_HDR_VAL"
#define SAMEnvCommMode                  "TL_COMM_MODE"

typedef struct struct_combuf {
    char Text[MAX_BUFSIZE];
    int iTotal;
} struct_comblk;

struct_comblk ComBlock;

