/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: C003Comm.c			     									 */
/* DESCRIPTIONS: TCP/IP ȫ������Server/Client                                */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include "C003Comm.h"

#define NCMaxAddrL                      15
#define LCTrue                          1

#define C_TCP_MSG_LEN_IN_BIN(x)         (x == 'B')

int	lCPickParam();
int	C001CommInit (int , char **);
void vCQuit();
void vCFuneral();
void vCGoodPortPlus();
void vCKillAllSons();
void vCHandleChildDie();
int nCEstablishBind(unsigned int vnPortNum, void* vvpLocAddr, int* vhpSocketId);
int nCEstablishConnect(int viPortX);
void vCPortHandle(int viPortX);
void vCTcpSnd();
void vCTcpSndEcho();
void vCTcpRcv();
void vCTcpRcvTimeOut();

typedef struct {
    int					hSocketId;
    unsigned int		nPortNum;
    char				saLocAddr[NCMaxAddrL + 1];
	char				saRemAddr[NCMaxAddrL + 1];
} lpiListenPortInfDef;

pid_t					gpidtMainPid;
int						gnGoodPortN;
pid_t					gpidtFatherPid;
int						gnMaxPortN;
pid_t					gpidtaSonPid[NCMaxPortN];
int						gnSonN;
lpiListenPortInfDef		glpiaPort[NCMaxPortN];
int						ghDataSocket;
pid_t					gpidtSubPid;
int						gnLoopNeed;
struct sockaddr_in		gsaddrAccept;
char					gsTcpMsgLenType;
int						gnTcpMsgLenL;
int						gnTcpTpduHdrL;
int						gnTcpModeFullDuplex;
int						gnTcpModeServer;
short					gnTimeOver;
short					gnTimeOverRcv;

static char * id = "$Id: C003Comm.c,v 1.1.1.1 2011/08/19 10:55:51 ctedev Exp $";

int main( int argc, char **argv)
{
    int				liX;
    int				nReturnCode, llResult, status;
    int				lnLineNumber;
    int				lsckltAddrLen;
    char*			lspTmp;
	pid_t			lpid;

    gpidtMainPid = 0;
    gnGoodPortN = 0;


    /* connect to database */
    nReturnCode = DbsConnect ();
    if (nReturnCode)
    {
        printf("DbsConnect error %d\n", nReturnCode);
        return (nReturnCode);
    }

    nReturnCode = CommInit (argc, argv);
    if ( nReturnCode != 0 )
    {
        printf("CommInit error %d\n", nReturnCode);
        DbsDisconnect ();
        exit(-1);
    }
HtLog ("lgm.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__, "gsSrvId[%s]", gsSrvId);
    if((gpidtFatherPid = getpid()) == -1)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
        	"Call getpid(gpidtFatherPid) error %d", errno);
        DbsDisconnect ();
        exit(-2);
    } /* end of if */

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
		"Call getpid(gpidtFatherPid) %d", gpidtFatherPid);
    gpidtMainPid = gpidtFatherPid;

    gnTcpModeFullDuplex = NTrue;
	gnTcpModeServer = NTrue;
    if((lspTmp = getenv(SAMEnvCommMode)) != NULL)
	{
        if((*lspTmp == 'H') || (*lspTmp == 'h'))
            gnTcpModeFullDuplex = NFalse;
		*lspTmp++;
        if((*lspTmp == 'C') || (*lspTmp == 'c'))
            gnTcpModeServer = NFalse;
    } /* end of if */

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
		"gnTcpModeFullDuplex[%d] gnTcpModeServer[%d]",
		gnTcpModeFullDuplex, gnTcpModeServer);

    if((lspTmp = getenv(SAMEnvCommMsgLenFmt)) == NULL)
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"Call getenv(SAMEnvCommMsgLenFmt) error %d", errno);
		DbsDisconnect ();
        exit(-10);
    } /* end of if */

    gsTcpMsgLenType = *lspTmp++;
    if(((gnTcpMsgLenL = atoi(lspTmp)) < 0) ||
       (gnTcpMsgLenL > NCMaxTcpMsgLenL))
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"Call atoi(gnTcpMsgLenL) error %d", errno);
		DbsDisconnect ();
        exit(-11);
    } /* end of if */

    if((lspTmp = getenv(SAMEnvCommTpduHdrLen)) == NULL)
	{
	    DbsDisconnect ();
        exit(-10);
    } /* end of if */

    if((gnTcpTpduHdrL = atoi(lspTmp)) < 0) {
        DbsDisconnect ();
        exit(-11);
    } /* end of if */

    if((lspTmp = getenv(
                    "TL_COMM_TIME_OVER")) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "getenv TL_COMM_TIME_OVER error, %d", errno);
		DbsDisconnect ();
        exit(-6);
    } /* end of if */
    if(((gnTimeOver = atoi(
                            lspTmp)) < 0))
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "atoi(gnTimeOver) error, %d", errno);
		DbsDisconnect ();
        exit(-7);
    } /* end of if */
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "gnTimeOver[%d]", gnTimeOver);

    if((lspTmp = getenv(
                    "TL_COMM_TIME_OVER_RCV")) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "getenv TL_COMM_TIME_OVER_RCV error, %d", errno);
		DbsDisconnect ();
        exit(-6);
    } /* end of if */
    if(((gnTimeOverRcv = atoi(
                            lspTmp)) < 0))
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "atoi(gnTimeOverRcv) error, %d", errno);
		DbsDisconnect ();
        exit(-7);
    } /* end of if */
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "gnTimeOverRcv[%d]", gnTimeOverRcv);

    memset(gsLineIndex, 0, sizeof(gsLineIndex));
    strcpy (gsLineIndex, getenv(SAMEnvCommLineCfgKey));
    
	if(nReturnCode = lCPickParam())
	{
		DbsDisconnect ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"lCPickParam error [%d]", nReturnCode);
		exit(-12);
        return nReturnCode;
    } /* end of if */

	nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"LineStateChg DISCONNECT error, %d", nReturnCode);
		DbsDisconnect ();
		exit(-20);
	}


	DbsDisconnect ();

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
		"gnMaxPortN [%d]", gnMaxPortN);

    for(liX = 0; liX < gnMaxPortN; liX++)
        gpidtaSonPid[liX] = -1;
    gnSonN = 0;

    sigset(SIGTERM, vCFuneral);

    sigset(SIGUSR1, vCGoodPortPlus);

    for(liX = 0; liX < gnMaxPortN; liX++) {
        if((liX % 2 == 0 || gnTcpModeFullDuplex) &&
			!gnTcpModeServer)
            	continue;
        if(llResult = nCEstablishBind(
                         glpiaPort[liX].nPortNum,
                         &glpiaPort[liX].saLocAddr[0],
                         &glpiaPort[liX].hSocketId))
            exit(-16);
    } /* end of for */

    for(liX = 0; liX < gnMaxPortN; liX++) {
        if((liX % 2 == 0 || gnTcpModeFullDuplex) &&
			!gnTcpModeServer)
            	continue;
        if(listen(
              glpiaPort[liX].hSocketId,
              NCListenBlkLogNDft) == -1) {
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
            	"Call listen() error %d", errno);
            exit(-17);
        } /* end of if */
    } /* end of for */

    vCKillAllSons();
    sleep(1);

    for(liX = 0; liX < gnMaxPortN; liX++) {
       	if((gpidtMainPid = fork()) == -1) {
       		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
           		"Call fork() error %d", errno);
           	exit(-18);
       	} /* end of if */

       	if(gpidtMainPid == 0) {
           	vCPortHandle(liX);
           	exit(0);
       	}
       	else {
           	gpidtaSonPid[liX] = gpidtMainPid;
       		gnSonN++;
       	} /* end of if */
    } /* end of for */

	while(1)
	{
		lpid = wait(&status);
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"lpid=[%d] exit and status is [%d]", lpid, status );

		nReturnCode = DbsConnect ();
		if (nReturnCode)
		{
    		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"Connect DB nReturnCode[%d]", nReturnCode);
			exit(-19);
		}

		llResult = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
		if (llResult)
		{
		    DbsDisconnect ();
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg DISCONNECT error, %d", llResult);
			exit(-20);
		}

		nReturnCode = DbsDisconnect ();
		if (nReturnCode)
		{
    		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"DisConnect DB nReturnCode[%d]", nReturnCode);
			exit(-21);
		}

		for( liX=0; liX < gnMaxPortN; liX++ )
		{
			if( lpid == gpidtaSonPid[liX] )
			{
				if((gpidtMainPid = fork()) == -1)
				{
        			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"Call fork() error %d", errno);
					exit(-22);
				} /* end of if */
        		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
					"Main son fork() pid = %d", gpidtMainPid);

				if(gpidtMainPid == 0)
				{
					vCPortHandle(liX);
					exit(0);
				}
				else
					gpidtaSonPid[liX] = gpidtMainPid;
			}
		}
	}
} /* end of main */

int lCPickParam()
{
	int					lnLoop;
	Tbl_line_cfg_Def	tTblLineCfg;
	char				*lspTmp;

	gnMaxPortN = 0;

    memset(
       &tTblLineCfg,
       0,
       sizeof(tTblLineCfg));

    if((lspTmp = getenv(
                    SAMEnvCommLineCfgKey)) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"Call getenv(SAMEnvCommLineCfgKey, error %d", errno);
		return -1;
	}
    if((tTblLineCfg.usage_key = atoi(
                                      lspTmp)) < 0) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"Call atoi(tTblLineCfg.usage_key), error %d", errno);
		return -2;
	}

    memcpy(
       &tTblLineCfg.srv_id[0],
       &gsSrvId[0],
       SRV_ID_LEN);

    DbsLINECFG(
       DBS_CURSOR,
       &tTblLineCfg);

    if(DbsLINECFG(
          DBS_OPEN,
          &tTblLineCfg))
        return -3;

    while(DbsLINECFG(
             DBS_FETCH,
             &tTblLineCfg) == 0) {
        if(gnMaxPortN>=NCMaxPortN)
        {
        	DbsLINECFG(DBS_CLOSE,&tTblLineCfg);
        	return -4;
        }
		memset( &glpiaPort[gnMaxPortN].saLocAddr[0],
				0,
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saLocAddr[0],
				&tTblLineCfg.local_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saRemAddr[0],
				&tTblLineCfg.remote_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saRemAddr));
		CommonRTrim(glpiaPort[gnMaxPortN].saRemAddr);
		CommonLTrim(glpiaPort[gnMaxPortN].saRemAddr);
        glpiaPort[gnMaxPortN++].nPortNum = tTblLineCfg.out_sock_num;

		if(gnTcpModeFullDuplex)
			continue;

		memset( &glpiaPort[gnMaxPortN].saLocAddr[0],
				0,
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saLocAddr[0],
				&tTblLineCfg.local_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saRemAddr[0],
				&tTblLineCfg.remote_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saRemAddr));
		CommonRTrim(glpiaPort[gnMaxPortN].saRemAddr);
		CommonLTrim(glpiaPort[gnMaxPortN].saRemAddr);
        glpiaPort[gnMaxPortN++].nPortNum = tTblLineCfg.in_sock_num;
    } /* end of for */

    if(DbsLINECFG(
          DBS_CLOSE,
          &tTblLineCfg))
        return -5;

    return 0;
} /* end of lCPickParam */

void vCKillAllSons() {

    int                               liX;
    int                               lnResult;
    int                               lnSleepNeed = NFalse;

    if(lnResult = sigignore(
                     SIGCLD)) {
        exit(-18);
    } /* end of if */

    if(lnResult = sigignore(
                     SIGUSR1)) {
        exit(-19);
    } /* end of if */

    for(liX = 0; liX < gnMaxPortN; liX++) {
        if(gpidtaSonPid[liX] != -1) {
            kill(
               gpidtaSonPid[liX],
               SIGTERM);
            gpidtaSonPid[liX] = -1;
            lnSleepNeed = NTrue;
        } /* end of if */
    } /* end of for */
	/*
    if(lnSleepNeed)
        sleep(10);
	*/

    sigset(SIGCLD,vCHandleChildDie);

    sleep(1);

    sigset(SIGUSR1,vCGoodPortPlus);
} /* end of vCKillAllSons */

int nCEstablishBind(
       unsigned int	vnPortNum,
       void*			vvpLocAddr,
       int*				vhpSocketId)
{
    int					lhListenSocket;
    int					llOpt;
    struct linger		lslngrOpt;
    struct sockaddr_in	lsaddrinBind;
    int					lnRetryNeed;

    for(lnRetryNeed = NCRetryTimeDft; lnRetryNeed-- > 0;) {
        if((lhListenSocket = socket(
                                AF_INET,
                                SOCK_STREAM,
                                0)) == -1) {
            return -1;
        } /* end of if */

        llOpt = LCTrue;
        if(setsockopt(
              lhListenSocket,
              SOL_SOCKET,
              SO_KEEPALIVE,
              &llOpt,
              sizeof(llOpt))) {
            close(lhListenSocket);
            if(lnRetryNeed)
                continue;
            return -2;
        } /* end of if */

        lslngrOpt.l_onoff = LCTrue;
        lslngrOpt.l_linger = LCTrue;
        if(setsockopt(
              lhListenSocket,
              SOL_SOCKET,
              SO_LINGER,
              &lslngrOpt,
              sizeof(lslngrOpt))) {
            close(lhListenSocket);
            if(lnRetryNeed)
                continue;
            return -3;
        } /* end of if */

        llOpt = LCTrue;
        if(setsockopt(
              lhListenSocket,
              SOL_SOCKET,
              SO_REUSEADDR,
              &llOpt,
              sizeof(llOpt))) {
            close(lhListenSocket);
            if(lnRetryNeed)
                continue;
            return -4;
        } /* end of if */

        lsaddrinBind.sin_family = AF_INET;
        lsaddrinBind.sin_port = htons(vnPortNum);
        lsaddrinBind.sin_addr.s_addr = inet_addr(
                                          vvpLocAddr);
        if(bind(
              lhListenSocket,
              (struct sockaddr*)(&lsaddrinBind),
              sizeof(lsaddrinBind))) {
            close(lhListenSocket);
            if(lnRetryNeed) {
                sleep(
                   LCPauseDft);
                continue;
            } /* end of if */
            return -5;
        } /* end of if */
        *vhpSocketId = lhListenSocket;
        return 0;
    } /* end of for */
} /* end of nCEstablishBind */

void vCPortHandle(int viPortX)
{
    int		liX,llResult,nReturnCode;
    unsigned int		lsckltAddrLen;
	char	lsTmp[NCMaxAddrL + 2];
	char   sClientAddr[INET_ADDRSTRLEN+1];

    lsckltAddrLen = sizeof(gsaddrAccept);
	if(viPortX % 2 == 0 || gnTcpModeFullDuplex)
	{
		if(!gnTcpModeServer)
		{
       		if(nCEstablishConnect(viPortX))
			{
       			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"nCEstablishConnect viPortX[%d] error %d",
					viPortX, errno);
				vCQuit();
           		exit(-27);
       		} /* end of if */

		}
		else {
       		if((ghDataSocket = accept(
                              glpiaPort[viPortX].hSocketId,
                              (struct sockaddr *)&gsaddrAccept,
                              &lsckltAddrLen)) == -1) {
        			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"accept viPortX[%d] error %d", viPortX, errno);
					vCQuit();
            		exit(-22);
			} /* end of if */

			memset(lsTmp, 0, sizeof(lsTmp));
			memcpy(lsTmp,
				glpiaPort[viPortX].saRemAddr,
				sizeof(glpiaPort[viPortX].saRemAddr));

			CommonRTrim(lsTmp);
			
			memset(sClientAddr, 0, sizeof(sClientAddr));
		    inet_ntop(AF_INET, &gsaddrAccept.sin_addr, sClientAddr, sizeof(sClientAddr));

			if(strcmp(lsTmp, sClientAddr) != 0 &&
			   memcmp(lsTmp,"0.0.0.0",7) != 0 )
			{
				close(ghDataSocket);
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                	"Ӧ�úϷ�IP[%s]", lsTmp);
            	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                	"�յ��Ƿ�IP[%s]", sClientAddr);

				memset(gsErrMsg, 0, sizeof(gsErrMsg));
				sprintf(gsErrMsg, "�յ��Ƿ�IP[%s],Ӧ�úϷ�IP[%s]",
					lsTmp, sClientAddr);
				vCQuit();
            	exit(-22);
        	}
       		close(glpiaPort[viPortX].hSocketId);
		}
   	}
   	else {
       	if((ghDataSocket = accept(
                              glpiaPort[viPortX].hSocketId,
                              ( struct sockaddr *)&gsaddrAccept,
                              &lsckltAddrLen)) == -1) {
        		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"accept viPortX[%d] error %d", viPortX, errno);
				vCQuit();
            	exit(-22);
		} /* end of if */

		memset(lsTmp, 0, sizeof(lsTmp));
		memcpy(lsTmp,
			glpiaPort[viPortX].saRemAddr,
			sizeof(glpiaPort[viPortX].saRemAddr));

		CommonRTrim(lsTmp);

		if (strcmp(lsTmp, sClientAddr) != 0 &&
		    memcmp(lsTmp,"0.0.0.0",7) != 0 )
		{
			close(ghDataSocket);
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               	"Ӧ�úϷ�IP[%s]", lsTmp);
           	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
               	"�յ��Ƿ�IP[%s]", sClientAddr);

			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "�յ��Ƿ�IP[%s],Ӧ�úϷ�IP[%s]",
				lsTmp, sClientAddr);
			vCQuit();
           	exit(-22);
       	}
      	close(glpiaPort[viPortX].hSocketId);
	}

    if((gnTcpModeFullDuplex) &&
       ((gpidtSubPid = fork()) == -1)) {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
        	"Call fork() error %d", errno);
        exit(-24);
    } /* end of if */

	nReturnCode = DbsConnect ();
	if (nReturnCode)
	{
    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"Connect DB nReturnCode[%d]", nReturnCode);
		exit(-25);
	}

	llResult = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_CONNECT);
	if (llResult)
	{
	    DbsDisconnect ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg CONNECT error, %d", llResult);
		exit(-26);
	}

	nReturnCode = DbsDisconnect ();
	if (nReturnCode)
	{
    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DisConnect DB nReturnCode[%d]", nReturnCode);
		exit(-27);
	}


    if(((!gnTcpModeFullDuplex) &&
        (viPortX % 2 == 0)) ||
       ((gnTcpModeFullDuplex) &&
        (gpidtSubPid == 0)))
	{
        vCTcpRcv();
    }
    else
	{
        vCTcpSnd();
    } /* end of if */
} /* end of vCPortHandle */

int nCEstablishConnect(int viPortX)
{
    struct sockaddr_in		lsaddrinRemote;

    for(;;)
    {
        if((ghDataSocket = socket(
                              AF_INET,
                              SOCK_STREAM,
                              0)) == -1) {
			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket error ip[%s] port[%d]", 
			glpiaPort[viPortX].saRemAddr, glpiaPort[viPortX].nPortNum);	
			/*
			sprintf(gsErrMsg, "socket error %s ip[%s] port[%d]",
				strerror(errno), glpiaPort[viPortX].saRemAddr,
				glpiaPort[viPortX].nPortNum);*/

			sleep(3);
			continue;
        } /* end of if */

        memset( &lsaddrinRemote, 0, sizeof(lsaddrinRemote));
        lsaddrinRemote.sin_port = htons(glpiaPort[viPortX].nPortNum);
        lsaddrinRemote.sin_family = AF_INET;
        lsaddrinRemote.sin_addr.s_addr = inet_addr(
                                            &glpiaPort[viPortX].saRemAddr[0]);
        if(connect(
              ghDataSocket,
              (struct sockaddr*)(&lsaddrinRemote),
              sizeof(lsaddrinRemote))) {

			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			/*
			sprintf(gsErrMsg, "connect error %s ip[%s] port[%d]",
				strerror(errno), glpiaPort[viPortX].saRemAddr,
				glpiaPort[viPortX].nPortNum);*/
				
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "connect error ip[%s] port[%d]", 
			&glpiaPort[viPortX].saRemAddr[0], glpiaPort[viPortX].nPortNum);	

            close(ghDataSocket);
            sleep(3);
            continue;
        } /* end of if */

        break;
    } /* end of for */

    return 0;
} /* end of nCEstablishConnect */

void vCTcpSnd()
{
    char					sMsgInBuf[NCMaxMsgBufLen+1];
    int  					lnMsgInLen;
    char					sMsgOutBuf[NCMaxMsgBufLen+1];
    int 					lnMsgOutLen;
	char					sMsgLen[NCMaxTcpMsgLenL+1];
    int						nReturnCode;
    char					cmd[100];
    char					sLocalIp[20];
    char					sC002Port[6];
    int 					hSocketTmp;

    sigset(SIGALRM,vCTcpSndEcho);

    for(;;) {
        lnMsgInLen = NCMaxMsgBufLen;
		memset(sMsgInBuf, 0, sizeof(sMsgInBuf));
        alarm(gnTimeOver);
        nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK,
                            &lnMsgInLen, sMsgInBuf);
        if (nReturnCode)
        {
			alarm(0);
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"MsqRcv error, %d", errno);

				memset(gsErrMsg, 0, sizeof(gsErrMsg));
				sprintf(gsErrMsg, "MsqRcv error %d", errno);
                exit(-1);
            }
            else
            {
                continue;
            }
        }
		alarm(0);
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"MsqRcv ok len[%d]", lnMsgInLen);

		HtWriteLog(gsMsgFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
			sMsgInBuf, lnMsgInLen);

        lnMsgInLen = lnMsgInLen-(SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER);

        memset(&sMsgOutBuf[0],0,sizeof(sMsgOutBuf));
        if(sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER] == '\x2E')
        {
            sprintf(&sMsgOutBuf[0],"%04d",lnMsgInLen-46);
            memcpy(&sMsgOutBuf[4], &sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+46], lnMsgInLen-46);
            lnMsgOutLen = lnMsgInLen + 4 - 46;
        }
        else
        {
            sprintf(&sMsgOutBuf[0],"%04d",lnMsgInLen);
            memcpy(&sMsgOutBuf[4],&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER],lnMsgInLen);
            lnMsgOutLen = lnMsgInLen + 4;
        }
        
        if(nReturnCode = nCSocketSnd(
                                    ghDataSocket,
                                    &sMsgOutBuf[0],
                                    &lnMsgOutLen))
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"SocketSnd error, %d", errno);

			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "socket snd error %d", errno);

            exit(-3);
        }

        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"SocketSnd ok ,socket[%d] len[%d]", ghDataSocket,lnMsgOutLen);

       HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG,
            __FILE__,__LINE__, sMsgOutBuf, lnMsgOutLen);

    }
} /* end of vCTcpSnd */

void vCTcpRcv()
{
    int 	lnDataL;
    char	sMsgLen[NCMaxTcpMsgLenL+1];
    char	sMsgInBuf[NCMaxMsgBufLen + 1];
    int 	lnMsgInLen;
    char	sMsgOutBuf[NCMaxMsgBufLen + 1];
    int 	lnMsgOutLen;
    int		nReturnCode;
    int		llMsgL;
	int		gnTcpMsgLenL_T;
	char sCurrentTime[15];

	sigset(SIGALRM,vCTcpRcvTimeOut);

    for(;;) {
        lnDataL = gnTcpMsgLenL;
        memset(&sMsgLen[0],0,sizeof(sMsgLen));
        alarm(gnTimeOverRcv);
        if(nReturnCode = nCSocketRcv(
                                ghDataSocket,
                                &sMsgLen[0],
                                &lnDataL,
                                0))
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"nCSocketRcv socket rcv error, %d", errno);
			alarm(0);
			close(ghDataSocket);
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
			{
            	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"socket rcv error, %d", errno);

				memset(gsErrMsg, 0, sizeof(gsErrMsg));
				sprintf(gsErrMsg, "socket rcv error %d", errno);
			}
			else
			{
            	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
					"timeout socket rcv error, %d", errno);

				memset(gsErrMsg, 0, sizeof(gsErrMsg));
				sprintf(gsErrMsg, "timeout socket rcv error %d", errno);
			}
			exit(-1);
        }
		alarm(0);

        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"socket rcv ok [%d] len:[%d] buf:[%s]",
			nReturnCode, lnDataL, sMsgLen);
			
		if(lnDataL<=0)
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket rcv len=%d", lnDataL);
            sleep(1);
			vCQuit();
		}
		
		if( memcmp(&sMsgLen[0],"0000",4) == 0 ) 
		{
            continue;
        }
        
        memset(sMsgInBuf,0,sizeof(sMsgInBuf));
        lnMsgInLen = atoi(sMsgLen);
        
        if(nReturnCode = nCSocketRcv(
                            ghDataSocket,
                            &sMsgInBuf[0],
                            &lnMsgInLen,
                            0))
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"socket rcv error, %d", errno);

			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "socket rcv error %d", errno);

            exit(-3);
        }
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"socket rcv ok [%d] len:[%d]", nReturnCode, lnMsgInLen);

        HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG,
            __FILE__,__LINE__, sMsgInBuf, lnMsgInLen);
        
        memset(sMsgOutBuf, ' ', sizeof(sMsgOutBuf));
        memcpy(sMsgOutBuf, gsSrvId, SRV_ID_LEN);
        
        /* ��ȡ��ǰ���ձ���ʱ�� */
        CommonGetCurrentTime (sCurrentTime);
        memcpy(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN,
               sCurrentTime, FLD_TIME_STAMP_LEN);
               
        /* GF����ͷ��ո� */
       memset(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN,
               ' ', FLD_GF_HEADER);
        
        memcpy(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,
               sMsgInBuf, lnMsgInLen);
        lnMsgOutLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+lnMsgInLen;

        
		HtWriteLog(gsMsgFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,
			sMsgOutBuf, lnMsgOutLen);

        nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, lnMsgOutLen, sMsgOutBuf);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"MsqSnd ToSrvId[%s] error [%d][%d]",
				gsToSrvId, nReturnCode, errno);

			memset(gsErrMsg, 0, sizeof(gsErrMsg));
			sprintf(gsErrMsg, "MsqSnd To %s error %d", gsToSrvId, errno);

            sleep(1);
            continue;
        }
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"MsqSnd ToSrvId[%s] ok", gsToSrvId);
    } /* end of for */
} /* end of vCTcpRcv */

void vCHandleChildDie()
{
    pid_t                             lpidtSonPid;
    int                               llStatLoc;
    int                               liX;

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
    	"Begin wait son die, pid = %d", gpidtMainPid);

    if(gpidtMainPid == 0) {
        if((lpidtSonPid = wait(
                             &llStatLoc)) == -1) {
            exit(-37);
        } /* end of if */
        exit(0);
    }
    else {
        if(sigignore(
              SIGUSR1)) {
            exit(-38);
        } /* end of if */

        if(((lpidtSonPid = wait(
                              &llStatLoc)) == -1) &&
           (errno != ECHILD)) {
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
            	"Call wait(lpidtSonPid) error %d", errno);
            exit(-39);
        } /* end of if */

        vCKillAllSons();
        gnGoodPortN = 0;

        gnLoopNeed = NFalse;
    } /* end of if */
} /* end of vCHandleChildDie */

void vCFuneral() {

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		"Process begin to die pid = %d", gpidtMainPid);

	DbsConnect ();
	LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
	DbsDisconnect ();

    if(sigignore(
          SIGTERM)) {
        exit(-40);
    } /* end of if */

    if(sigignore(
          SIGCLD)) {
        exit(-41);
    } /* end of if */

    if(sigignore(
          SIGUSR1)) {
        exit(-42);
    } /* end of if */

    if(gpidtMainPid == 0) {
        if((gnTcpModeFullDuplex) &&
           (gpidtSubPid != 0)) {
            kill(
               gpidtSubPid,
               SIGTERM);
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
            	"Kill son pid = %d", gpidtMainPid);
        } /* end of if */
        exit(
           0);
    }
    else {
        vCKillAllSons();
        exit(0);
    } /* end of if */
} /* end of vCFuneral */

void vCGoodPortPlus()
{
    if(++gnGoodPortN == gnMaxPortN) {
        if(sighold(
              SIGCLD)) {
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
            	"Call sighold(SIGCLD) error %d", errno);
            exit(-43);
        } /* end of if */

        if(sighold(
              SIGUSR1)) {
            exit(-44);
        } /* end of if */

        if(sigrelse(
              SIGCLD)) {
            exit(-45);
        } /* end of if */

        if(sigrelse(
              SIGUSR1)) {
            exit(-46);
        } /* end of if */
    } /* end of if */
} /* end of vCGoodPortPlus */

int CommInit (int argc, char **argv)
{
    int             i;
    int             nReturnCode;
    long            lUsageKey;
    Tbl_srv_inf_Def tTblSrvInf;

    /* get server id, arg 1 */
    strcpy (gsSrvId, argv[1]);
    strcpy (gsSrvSeqId, argv[2]);
	strcpy(gsToSrvId, argv[3]);

    if (getenv(SRV_USAGE_KEY))
        lUsageKey=atoi (getenv(SRV_USAGE_KEY));
    else
        return -1;

    /* get log file name from tbl_srv_inf */
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nReturnCode)
    {
        return (nReturnCode);
    }

    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_id, gsSrvSeqId);
    sprintf (gsMsgFile, "%s.%s.msg", tTblSrvInf.srv_id, gsSrvSeqId);

    /* init msg queue */
    memset ((char *)gatSrvMsq, 0, SRV_MSQ_NUM_MAX * sizeof (T_SrvMsq));
    nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"MsqInit error, %d", nReturnCode);
        return (nReturnCode);
    }

	return 0;
}

void vCQuit()
{
    close(ghDataSocket);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "vCQuit");

    exit(-30);
}

int ConnectSocket(char *ip,int port)
{
	struct					sockaddr_in psckadd;
	int						sckcli;
	struct linger			Linger;
	int						on=1;

	memset((char *)(&psckadd),'0',sizeof(struct sockaddr_in));
	psckadd.sin_family            = AF_INET;
	psckadd.sin_addr.s_addr       = inet_addr(ip);
	psckadd.sin_port=htons((u_short)port);

	if((sckcli = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"ConnectSocket:can not open stream socket");
		return(-1);
	}

	if (connect(sckcli,(struct sockaddr *)(&psckadd),sizeof(struct sockaddr_in)) < 0)
	{
    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"ConnectSocket:cannot connect to server! svr_ip = [%s] port = [%d]",ip,port);
		CloseSocket(sckcli);
		return(-2);
   	}

	Linger.l_onoff = 1;
	Linger.l_linger = 0;
	if (setsockopt(sckcli,SOL_SOCKET,SO_LINGER,(char *)&Linger,sizeof(Linger)) != 0)
	{
    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"ConnectSocket:setsockopt linger!");
		CloseSocket(sckcli);
		return(-3);
	}

	if (setsockopt(sckcli, SOL_SOCKET, SO_OOBINLINE, (char *)&on, sizeof(on)))
	{
    	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"ConnectSocket:setsockopt SO_OOBINLINE!");
		CloseSocket(sckcli);
		return(-4);
	}
	return(sckcli);
}

int CloseSocket(int sockfd)
{
	shutdown(sockfd, 2);
	close(sockfd);
	return(0);
}

void vCTcpSndEcho()
{
	int		llResult;
	int		lnDataL;
	char	saMsg0[5];

	memset(saMsg0, '0', sizeof(saMsg0));

	lnDataL = 4;

    if(llResult = nCSocketSnd(ghDataSocket,saMsg0,&lnDataL))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCTcpSndEcho error, %d", errno);
		close(ghDataSocket);
		exit(-1);
    }
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "vCTcpSndEcho ok");
    return;
}

void vCTcpRcvTimeOut()
{
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "vCTcpRcvTimeOut ok");
    return;
}
