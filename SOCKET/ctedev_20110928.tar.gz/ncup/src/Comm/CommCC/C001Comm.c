/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: C001Comm.c                                                  */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*                                                                           */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Comm/CommCC/C001Comm.c,v 1.1.1.1 2011/08/19 10:55:50 ctedev Exp $";

#include "C001Comm.h"

#define NCMaxAddrL                      15
#define ECHOBUFLEN                      16
#define LCTrue                          1
#define NCMaxTcpTpduHdrL                30

#define C_TCP_MSG_LEN_IN_BIN(x)         (x == 'B')

int 	lCPickParam();
void  	vCHandleChildDie();
void  	vCPortHandleClient(short);
void  	vCPortHandleServer(short);
void 	vCTcpSndEcho();
int 	nCConnectSocket(unsigned short, char *);
void  	vCQuit();
int 	nCCreatSocket(unsigned short, short);
int 	nCConnectSocket(unsigned short, char *);
void  	vCKill();
void  	vCRestart(int);
void  	vCTcpSnd();
void  	vCTcpRcv(short);
void	vCTerminate();
void printGFHeaderMsg(char* sBuf);
void printMsg(char* sBuf);

typedef struct {
    int                                 hSocketId;
    unsigned short						nPortNum;
    char                               	saLocAddr[NCMaxAddrL + 1];
    char                               	saRemAddr[NCMaxAddrL + 1];
} lpiListenPortInfDef;

pid_t									gpidtMainPid;
short                                   gnGoodPortN;
int                                   	glRcvSrvId;
short                                   giRcvSrvX;
int                                   	glSndSrvId;
pid_t                                   gpidtFatherPid;
short                                   gnMaxPortN;
short                                   gnMaxHostN;
pid_t                                   gpidtaSonPid[NCMaxPortN];
short                                   gnSonN;
lpiListenPortInfDef                     glpiaPort[NCMaxPortN];
int										ghDataSocket;
pid_t                                   gpidtSubPid;
struct sockaddr_in						gsaddrAccept;
char									gsTcpMsgLenType;
short                                   gnTcpMsgLenL = 4;
short                                   gnTcpTpduHdrL;
short                                   gnTimeOver;
short									gnDoRestart;

char									gsSrvId[SRV_ID_LEN+1];
char									gsToSrvId[SRV_ID_LEN+1];
char									gsSrvSeq[SRV_SEQ_ID_LEN+1];
char									gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq								gatSrvMsq[SRV_MSQ_NUM_MAX];
Tbl_srv_inf_Def							tTblSrvInf;
char                                    gsLineIndex[2];

int main( int argc, char** argv) 
{
	/*
    short			liX,liXX;
	*/
    short			liX;
	int				nReturnCode;
	char			*lspTmp;
    gpidtMainPid = 0;
    gnGoodPortN = 0;
    printf("argc:%d -[%s]-[%s]-[%s]-[%s]\n",argc,argv[0],argv[1],argv[2],argv[3]);
	if(argc < 4)
	{
		printf("Usage:%s srvid seq tosrvid\n", argv[0]);
		exit(-1);
	}

	strcpy(gsSrvId, argv[1]);
	strcpy(gsSrvSeq, argv[2]);
	strcpy(gsToSrvId, argv[3]);

	/* connect to database */
	nReturnCode = DbsConnect ();
	if (nReturnCode)
	{
		printf("CommPCS nReturnCode[%d] LINE[%d]\n", nReturnCode, __LINE__);
		exit(-2);
	}

    /* get log file name from tbl_srv_inf */
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nReturnCode)
	{
		printf("CommPCS nReturnCode[%d] LINE[%d]\n", nReturnCode, __LINE__);
		DbsDisconnect ();
		exit(-2);
	}

    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_id, gsSrvSeq);

    /* init msg queue */
    memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
    nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d", nReturnCode);
		DbsDisconnect ();
		exit(-3);
    }

    if((gpidtFatherPid = getpid()) == -1) 
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "getpid error, %d", errno);
		DbsDisconnect ();
        exit(-4);
    } /* end of if */
    gpidtMainPid = gpidtFatherPid;

    memset(gsLineIndex, 0, sizeof(gsLineIndex));
    strcpy (gsLineIndex, getenv(SAMEnvCommLineCfgKey));
    
    if((nReturnCode = lCPickParam())) 
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "lCPickParam error, [%d][%d]", nReturnCode, errno);
		DbsDisconnect ();
        exit(-5);
    } /* end of if */

    if((lspTmp = getenv(
                    SAMEnvCommTimeOver)) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "getenv SAMEnvCommTimeOver error, %d", errno);
		DbsDisconnect ();
        exit(-6);
    } /* end of if */
    if(((gnTimeOver = atoi(
                            lspTmp)) < 0))
	{ 
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "atoi(gnTimeOver) error, %d", errno);
		DbsDisconnect ();
        exit(-7);
    } /* end of if */

    if(sigset(
          SIGCLD,
          vCRestart) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGCLD error, %d", errno);
		DbsDisconnect ();
        exit(-8);
    } /* end of if */

	if(sigset(
			SIGUSR2,
			vCQuit) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGUSR2 error, %d", errno);
		DbsDisconnect ();
		exit(-9);
	} /* end of if */

	if(sigset(
			SIGTERM,
			vCTerminate) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);
		DbsDisconnect ();
		exit(-10);
	} /* end of if */

    while( 1 ) {
    	for(liX = 0; liX < gnMaxPortN; liX++)
        	gpidtaSonPid[liX] = -1;
    	gnSonN = 0;

		gnDoRestart = 0;
		sighold(SIGCLD);

        for(liX = 0; liX < gnMaxPortN ; liX++) {
        	if((gpidtMainPid = fork()) == -1) {
                exit(-16);
            } /* end of if */

            if(gpidtMainPid == 0) 
			{
				if((liX % 2) == 0)
				{
					/***************************
					nReturnCode = DbsConnect ();
					if (nReturnCode)
					{
        				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"Child Connect DB nReturnCode[%d]", nReturnCode);
						exit(-2);
					}
					DbsDisconnect ();
					***************************/
					HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "lix, %d", liX);
					vCPortHandleServer(liX);
				}
				else
				{
					/*************************
					nReturnCode = DbsConnect ();
					if (nReturnCode)
					{
        				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"Child Connect DB nReturnCode[%d]", nReturnCode);
						exit(-2);
					}
					DbsDisconnect ();
					*************************/
					vCPortHandleClient(liX);
				}
            }
            else {
                gpidtaSonPid[liX] = gpidtMainPid;
                gnSonN++;
            } /* end of if */
            
            sleep (1);
        }  /* end of for */

		sigrelse(SIGCLD);

		while(!gnDoRestart) pause();
    } /* end of while */

	DbsDisconnect ();

    exit(-17);
} /* end of main */

int lCPickParam() 
{
	/*
	short				lnLoop;
	*/
	Tbl_line_cfg_Def	tTblLineCfg;
	char				*lspTmp;

	gnMaxPortN = 0; 

    memset(
       &tTblLineCfg,
       0,
       sizeof(tTblLineCfg));

    if((lspTmp = getenv(
                    SAMEnvCommLineCfgKey)) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call getenv(SAMEnvCommLineCfgKey, error %d", errno);
		return -1;
	}
    if((tTblLineCfg.usage_key = atoi(
                                      lspTmp)) < 0) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call atoi(tTblLineCfg.usage_key), error %d", errno);
		return -2;
	}

    memcpy(
       &tTblLineCfg.srv_id[0],
       &gsSrvId[0],
       SRV_ID_LEN);

    DbsLINECFG(
       DBS_CURSOR,
       &tTblLineCfg);

    if(DbsLINECFG(
          DBS_OPEN,
          &tTblLineCfg))
        return -3;

    while(DbsLINECFG(
             DBS_FETCH,
             &tTblLineCfg) == 0) {
		memset( &glpiaPort[gnMaxPortN].saLocAddr[0], 
				0, 
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saLocAddr[0], 
				&tTblLineCfg.local_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saRemAddr[0], 
				&tTblLineCfg.remote_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saRemAddr));

        glpiaPort[gnMaxPortN++].nPortNum = tTblLineCfg.in_sock_num; 
		memset( &glpiaPort[gnMaxPortN].saLocAddr[0], 
				0, 
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saLocAddr[0], 
				&tTblLineCfg.remote_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saRemAddr));
        glpiaPort[gnMaxPortN++].nPortNum = tTblLineCfg.out_sock_num; 
    } /* end of for */

    if(DbsLINECFG(
          DBS_CLOSE,
          &tTblLineCfg))
        return -4;

    return 0;
} /* end of lCPickParam */

void vCPortHandleClient(
        short                           viPortX) {

	/*
    short                               liX;
	*/
    int                               llResult;
    int                                lsckltAddrLen;

	if(sigset( SIGTERM, SIG_IGN) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);
		exit(-21);
	} /* end of if */

	if(sigset(
			SIGALRM,
			vCTcpSndEcho) == SIG_ERR) {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGALRM error, %d", errno);
		exit(-22);
	} /* end of if */

    lsckltAddrLen = sizeof(gsaddrAccept);
	while ((
		ghDataSocket =
			nCConnectSocket(glpiaPort[viPortX].nPortNum,
				glpiaPort[viPortX].saLocAddr)) < 0)
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "connect socket error, %d", errno);
		sleep(5);
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
			"connect socket[%d] ok", ghDataSocket);
HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "test11111111111111111");
	DbsConnect();
	llResult = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_CONNECT);
	if (llResult)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d", llResult);
	}
	DbsDisconnect();
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg ok");
	
    vCTcpSnd();
} /* end of vCPortHandle */

void vCPortHandleServer(
        short                           viPortX) {

	/*
    short                               liX;
    int                               llResult;
	*/
	int                               llResult;
    int                               lsckltAddrLen;

	if(sigset( SIGTERM, SIG_IGN) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);
		exit(-31);
	} /* end of if */
	
	if(sigset(
			SIGALRM,
			vCTcpSndEcho) == SIG_ERR) {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGALRM error, %d", errno);
		exit(-32);
	} /* end of if */

    lsckltAddrLen = sizeof(gsaddrAccept);
#if 0
	while (
		(ghDataSocket =
			nCCreatSocket(glpiaPort[viPortX].nPortNum,viPortX)) < 0)
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "listen socket error, %d", errno);
		sleep(5);
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
			"listen socket[%d] ok", ghDataSocket);
#endif

    while ((
		ghDataSocket =
			nCConnectSocket(glpiaPort[viPortX].nPortNum,
				glpiaPort[viPortX].saLocAddr)) < 0)
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "connect socket error, %d", errno);
		sleep(5);
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
			"connect socket[%d] ok", ghDataSocket);
HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "test11111111111111111");
	DbsConnect();
	llResult = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_CONNECT);
	if (llResult)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d", llResult);
	}
	DbsDisconnect();
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg ok");

	vCTcpRcv(viPortX);
} /* end of vCPortHandle */

void vCTcpSnd() 
{
    char                    sCommCtlHeader[16+1];
    char                    sTotalMsgLen[4+1];
	char					sMsgInBuf[NCMaxMsgBufLen + 1];
	int						lnMsgInLen;
	char					sMsgOutBuf[NCMaxMsgBufLen + 1];
	char                    sAscMsgOutBuf[NCMaxMsgBufLen + 1];
	short					lnMsgOutLen;
	short					nReturnCode;
	char                    sTxnNum[4+1];

    for(;;) {
		lnMsgInLen = NCMaxMsgBufLen;
        alarm(gnTimeOver);
        nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, &lnMsgInLen, sMsgInBuf);
        if (nReturnCode)
        {
            alarm(0);
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
            {
        		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"MsqRcv error, %d", errno);			
				DbsConnect();
				nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
				if (nReturnCode)
				{
					HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d", nReturnCode);
				}
				DbsDisconnect();
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg ok");
				vCQuit();
            }
            else
			{
                continue;
			}
        }
		alarm(0);
   		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "MsqRcv ok len[%d]", lnMsgInLen);

		/*  ����ͨ�ű��Ŀ�����Ϣ -- �����㷢����ͷ*/		
		lnMsgInLen = lnMsgInLen-(SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN);
		if(lnMsgInLen > 4096)
		{
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqRcv ,msg len error,  lnMsgInLen=[%d]", lnMsgInLen);
		    continue;
		}
				
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Msg Code send To Mainframe: [%6.6s]", &sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22]);
		
		memset(&sCommCtlHeader[0],' ',sizeof(sCommCtlHeader));
		memset(&sTotalMsgLen[0],' ',sizeof(sTotalMsgLen));
		
		sprintf(&sTotalMsgLen[0],"%04d", lnMsgInLen+12);
		memcpy(&sCommCtlHeader[0], &sTotalMsgLen[0], 4);/*���ĳ���*/
		memcpy(&sCommCtlHeader[4], "1", 1);/*У��λ, ֻ���ļ�������Ҫ����*/
		memcpy(&sCommCtlHeader[4+1], "    ", 4);/*crcУ��*/
		
		/*��������*/
		if(
		    !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "FL0010" ,6) || 
		    !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "FL0020" ,6) ||
		    !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "SYS910" ,6) ||
		    !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "SYS920" ,6))/*ǩ��ǩ��*/
		{
			memcpy(&sCommCtlHeader[4+1+4], "0", 1);/*ϵͳ����*/
		}else{
		    memcpy(&sCommCtlHeader[4+1+4], "1", 1);/*ҵ������*/
		}
		
		memcpy(&sCommCtlHeader[4+1+4+1], "000" ,3);/*Ӧ��������*/
		
		memset(&sMsgOutBuf[0], ' ', sizeof(sMsgOutBuf));
		
		memcpy(&sMsgOutBuf[0],&sCommCtlHeader[0],16);
		memcpy(&sMsgOutBuf[16],&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN], lnMsgInLen);
		lnMsgOutLen = lnMsgInLen+16;
		
		vAsc2Ebcdic(sAscMsgOutBuf,sMsgOutBuf,lnMsgOutLen);
		
		HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sMsgOutBuf, lnMsgOutLen);
						
		/*HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sAscMsgOutBuf, lnMsgOutLen);*/		
		
        if((nReturnCode = nCSocketSnd( 
									ghDataSocket, 
									&sAscMsgOutBuf[0], 
									&lnMsgOutLen)))
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"socket snd error, %d", errno);
HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "test11111111111111111");
			DbsConnect();
			nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
			if (nReturnCode)
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d", nReturnCode);
			}
			DbsDisconnect();
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg ok");
            exit(-29);
        }
        
        
        /* ��������ʹ�� */
        if(
		    !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "FL0010" ,6) || 
		    !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "FL0020" ,6) ||
		    !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "SYS910" ,6) ||
		    !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "SYS920" ,6))/*ǩ��ǩ��*/
		{
            printGFHeaderMsg(sMsgOutBuf+16);
            if(!memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "FL0010" ,6) ||
                !memcmp(&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "FL0020" ,6))
                printMngReqMsg(sMsgOutBuf+16+256);
        }else
        {
            printGFHeaderMsg(sMsgOutBuf+16);
            printMsg(sMsgOutBuf+16+256);
        }
        
        
       	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"socket[%d] snd ok len[%d]", ghDataSocket,lnMsgOutLen);
	    /*HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sMsgOutBuf, lnMsgOutLen);*/
    } /* end of for */
} /* end of vCTcpSnd */

void vCTcpRcv(
        short                           vnWaitTime) {

    short					lnDataL;
    char					lsaMsgLen[NCMaxTcpMsgLenL+1];
	char					sMsgInBuf[NCMaxMsgBufLen + 1];
	short					lnMsgInLen;
	char					sMsgOutBuf[NCMaxMsgBufLen + 1];
	short					lnMsgOutLen;
	int						nReturnCode;
	char                    sCurrentTime[15];
	char                    sAscMsgLen[NCMaxTcpMsgLenL+1];
	char                    sAscMsgInBuf[NCMaxMsgBufLen + 1];
    char                    sGfHeader[FLD_GF_HEADER+1];

    for(;;) {
        lnDataL = gnTcpMsgLenL;
		memset(&lsaMsgLen[0],0,sizeof(lsaMsgLen));
        if((nReturnCode = nCSocketRcv(
								ghDataSocket,
								&lsaMsgLen[0],
								&lnDataL,
								0))) 
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket rcv error, %d", errno);
            sleep(vnWaitTime);
			vCQuit();
        }
        
        vEbcdic2Asc(sAscMsgLen,lsaMsgLen,4);
        
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"socket rcv ok [%d] len:[%d] buf:[%s]", 
				nReturnCode, lnDataL, sAscMsgLen);

		if(lnDataL<=0)
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket rcv len=%d", lnDataL);
            sleep(vnWaitTime);
			vCQuit();
		}
        
		lnMsgInLen = atoi(sAscMsgLen);
		memset(sMsgInBuf,0,sizeof(sMsgInBuf));
        if((nReturnCode = nCSocketRcv(
							ghDataSocket,
							&sMsgInBuf[0],
							&lnMsgInLen,
							0))) 
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket rcv error, %d", errno);
            exit(-34);
        }
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"socket rcv ok [%d] len:[%d]", nReturnCode, lnMsgInLen);
		
		memset(sAscMsgInBuf, 0, sizeof(sAscMsgInBuf));				
		vEbcdic2Asc(sAscMsgInBuf,sMsgInBuf,lnMsgInLen);
		
		if(sAscMsgInBuf[5] == '9') 
		{
		    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "rev echo test");
		    HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sAscMsgInBuf, lnMsgInLen);
            continue;
        }  
        
		HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Msg Code from the Mainframe: [%6.6s]", &sAscMsgInBuf[12+22]);
		HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sAscMsgInBuf, lnMsgInLen);				                     
        
        /* ��ȡ��ǰ���ձ���ʱ�� */
        CommonGetCurrentTime (sCurrentTime);
        
        lnMsgInLen=lnMsgInLen-12; /*ȥ��ͨ�ſ��Ʊ���ͷ*/
        
		memset(sMsgOutBuf, ' ', sizeof(sMsgOutBuf));
		memcpy(sMsgOutBuf, gsSrvId, SRV_ID_LEN);
		memcpy(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN, sCurrentTime, FLD_TIME_STAMP_LEN);
		memcpy(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN, sAscMsgInBuf+12, lnMsgInLen);		        			
				
		lnMsgOutLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+lnMsgInLen;
		
		/* ��������ʹ�� */
        if(lnMsgOutLen < SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+523)
      	{
            printGFHeaderMsg(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN);
            if(!memcmp(&sMsgOutBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "FL0011" ,6) ||
                !memcmp(&sMsgOutBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+22], "FL0021" ,6))
                printMngRspMsg(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+256);
        }else
        {
            printGFHeaderMsg(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN);
            printMsg(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+256);
        }
		
        nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, lnMsgOutLen, sMsgOutBuf);
        if (nReturnCode)
        {
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"MsqSnd ToSrvId[%s] error [%d][%d]", 
					gsToSrvId, nReturnCode, errno);
			sleep(1);
            continue;
        }
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"MsqSnd ToSrvId[%s] ok", gsToSrvId);
    } /* end of for */
} /* end of vCTcpRcv */

int nCConnectSocket(unsigned short Port, char *Ip_addr)
{
	struct sockaddr_in   Sin;
	/*
	int   Socket_id, Flag, Error, RetryTimeSap = 2, nRetryFlag = 0;
	*/
	int   Socket_id, RetryTimeSap = 2, nRetryFlag = 0;

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Ip_addr, %s, Port %d", Ip_addr, Port);
	memset(&Sin, 0, sizeof(Sin));
	Sin.sin_port = htons(Port);
	Sin.sin_family = AF_INET;
	Sin.sin_addr.s_addr = inet_addr(Ip_addr);

	while(1)
	{
		while ((Socket_id = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket, %d", errno);
			if (nRetryFlag++ == RETRYNUM)
			{
				if ( RetryTimeSap<100) RetryTimeSap += 2;
				nRetryFlag = 0;
			}
			sleep(RetryTimeSap);
		}

		if (connect(Socket_id, (struct sockaddr *)&Sin, sizeof(Sin)) < 0)
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "connect error[%s][%d], %d",Ip_addr , Port, errno);
			close(Socket_id);
			if (errno == ECONNREFUSED)
			{
				sleep(5);
				continue;
			}
			sleep(30);
			continue;
		}

		break;
	}

	return(Socket_id);
}

int nCCreatSocket(unsigned short Port,short viPortX)
{
	int   RetryTimeSap = 2;
	int   Socket_id, nRetryFlag = 0;
	struct sockaddr_in   Client;
	int   Socket_id_new;
	int   Client_len= sizeof( Client);
	char   lsTmp[NCMaxAddrL + 2];
    int                               llOpt;
    struct linger					lslngrOpt;
    char   sClientAddr[INET_ADDRSTRLEN+1];
	/*
    struct sockaddr_in				lsaddrinBind;
	*/

	memset(&Client,0, sizeof(Client));
	Client.sin_port = htons(Port);
	Client.sin_family = AF_INET;
	Client.sin_addr.s_addr = inet_addr("0.0.0.0");

	while ((Socket_id = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
       	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"socket error, %d", errno);
		if (nRetryFlag++ == RETRYNUM)
		{
			if ( RetryTimeSap<100) RetryTimeSap += 2;
			nRetryFlag = 0;
		}
		sleep(RetryTimeSap);
	}
	RetryTimeSap = 2;
	nRetryFlag = 0;

	llOpt = LCTrue;
	if(setsockopt(
              Socket_id,
              SOL_SOCKET,
              SO_KEEPALIVE,
              &llOpt,
              sizeof(llOpt))) {
            close( Socket_id);
            return errno;
	} /* end of if */

	lslngrOpt.l_onoff = LCTrue;
	lslngrOpt.l_linger = LCTrue;
	if(setsockopt(
              Socket_id,
              SOL_SOCKET,
              SO_LINGER,
              &lslngrOpt,
              sizeof(lslngrOpt))) {
            close(Socket_id);
            return errno;
        } /* end of if */

        llOpt = LCTrue;
        if(setsockopt(
              Socket_id,
              SOL_SOCKET,
              SO_REUSEADDR,
              &llOpt,
              sizeof(llOpt))) {
            close(Socket_id);
            return errno;
        } /* end of if */

	while (bind(Socket_id, (struct sockaddr *)&Client, sizeof(Client)) < 0)
	{
		if (nRetryFlag++ == RETRYNUM)
		{
			if ( RetryTimeSap<100) RetryTimeSap += 2;
			nRetryFlag = 0;
		}
		sleep(RetryTimeSap);
	}

	listen(Socket_id, 5);

	Client_len = sizeof(Client);
	while(1)
	{
		Socket_id_new = accept(Socket_id, ( struct sockaddr *)&Client, &Client_len);
		if(Socket_id_new <= 0)
		{
       		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"accept socket id[%d] error, %d", Socket_id, errno);
			close(Socket_id);
			return(-1);
		}
		memset(lsTmp, 0, sizeof(lsTmp));
		memcpy(lsTmp,
			   glpiaPort[viPortX].saRemAddr,
			   sizeof(glpiaPort[viPortX].saRemAddr));

		CommonRTrim(lsTmp);
		
		/* add by wuzw inet_ntop-for linux64*/
		memset(sClientAddr, 0, sizeof(sClientAddr));
		inet_ntop(AF_INET, &Client.sin_addr, sClientAddr, sizeof(sClientAddr));
        /* add end */
        
		if(strcmp(lsTmp, sClientAddr) != 0)
		{
			close(Socket_id_new);
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"��ȷIP[%s]����", lsTmp);
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"���棺�յ��Ƿ�IP[%s]����", sClientAddr);
			sleep(1);
			continue;
		}

		break;
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,	"�յ�IP����OK %s,OK", sClientAddr); 
	close(Socket_id);
	return(Socket_id_new);
}

void vCQuit()
{
	close(ghDataSocket);

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCQuit");

	exit(-30);
}

void vCRestart(int iTmp)
{
	sigset(SIGCLD, SIG_IGN);
	close(ghDataSocket);

    /***************
	DbsDisconnect ();
    ***************/

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCRestart");

	vCKill();
	sleep(10);
	sigset(SIGCLD, vCRestart);
	gnDoRestart = 1;
}

void vCKill ()
{
	int   liX;
	int		nReturnCode;

	for(liX = 0; liX < gnMaxPortN; liX++)
	{
		if (gpidtaSonPid[liX] > 0)
			kill(gpidtaSonPid[liX], SIGUSR2);
	}
HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "test11111111111111111");
    DbsConnect();
	nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_RESET);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d", nReturnCode);
	}
	DbsDisconnect();
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg ok");
	
/* on AIX 5.2 (130.252.89.203), wait is blocked and never returns, so waitpid is used instead
	while(wait((int *)0) > 0)
*/
	sleep (2);
	while (waitpid( -1, NULL, WNOHANG) > 0)
	{
		;
	}
}

void vCTcpSndEcho() 
{
	int		llResult;
	short	lnDataL;
    char    sEchoTest[16+1] = {0};
    char    sEchoTestBCD[16+1];
    
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "vCTcpSndEcho Begin");
	
	lnDataL = ECHOBUFLEN;
	/* ���ÿ�ͨ�ű���ͷ�������� */
	memcpy(sEchoTest, "00121    9000   ", lnDataL);
	vAsc2Ebcdic(sEchoTestBCD, sEchoTest, lnDataL);
	
	HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sEchoTestBCD, 16);
	
    if((llResult = nCSocketSnd(ghDataSocket, sEchoTestBCD, &lnDataL)))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCTcpSndEcho error, %d", errno);
		close(ghDataSocket);
		exit(-1);
    }
    
    return;
}

void vCTerminate()
{
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCTerminate");
	sigset(SIGCLD, SIG_IGN);
	vCKill();
	exit (0);
}

/* ��������ʹ�� */
void printGFHeaderMsg(char* sBuf)
{
    char* gsLogFile="CommCC.out.log";
     
    
    int i=0;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "BEGIN GFHeader");
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������ȼ���[%2.2s]",sBuf + i);
    i += 2;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���ݱ��ĳ��ȣ�[%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ת��������[%1.1s]",sBuf + i);
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�汾�ţ�[%1.1s]",sBuf + i);
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ѻ��ʶ��[%1.1s]",sBuf + i);    
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ļ���ʶ��[%1.1s]",sBuf + i);
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ʶ��[%3.3s]",sBuf + i);
    i += 3;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ϸ�֣�[%1.1s]",sBuf + i);
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���ر�ţ�[%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ҵ��ϵͳ��[%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��������[%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����룺[%1.1s]",sBuf + i);
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ܰ�����[%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ţ�[%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����¼����[%3.3s]",sBuf + i);
    i += 3;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���ı�ʶ��[%1.1s]",sBuf + i);
    i += 1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����նˣ�[%10.10s]",sBuf + i);
    i += 10;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Դ���𷽱�ʶ��[%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Դ������ˮ��[%22.22s]",sBuf + i);
    i += 22;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Դ�������ڣ�[%8.8s]",sBuf + i);
    i += 8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Դ����ʱ�䣺[%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ˮ��[%10.10s]",sBuf + i);
    i += 10;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������ڣ�[%8.8s]",sBuf + i);
    i += 8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ʱ�䣺[%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ͳһ��Ա�ţ�[%10.10s]",sBuf + i);
    i += 10;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ʶλ��[%30.30s]",sBuf + i);
    i += 30;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������ڣ�[%8.8s]",sBuf + i);
    i += 8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ʱ�䣺[%6.6s]",sBuf + i);
    i += 6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ȷ���룺[%2.2s]",sBuf + i);
    i += 2;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ϣ���룺[%7.7s]",sBuf + i);
    i += 7;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���ͷ���ʶ��[%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���շ���ʶ��[%4.4s]",sBuf + i);
    i += 4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����λ��[%66.66s]",sBuf + i);
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "END GFHeader\n");
    
}

void printMsg(char* sBuf)
{
    char* gsLogFile="CommCC.out.log";
    
    int i = 0;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "BEGIN Msg");
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� ��[%4.4s]",sBuf + i);
    i+=4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� ��[%2.2s]",sBuf + i);
    i+=2;    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������Դ ��[%2.2s]",sBuf + i);
    i+=2;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���׿��ţ�����룬�Ҳ��ո� ��[%-19.19s]",sBuf + i);
    i+=19;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������룻 ��[%6.6s]",sBuf + i);
    i+=6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���׽� ��[%12.12s]",sBuf + i);
    i+=12;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ԭʼ�������� ��[%8.8s]",sBuf + i);
    i+=8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ԭʼ����ʱ�� ��[%6.6s]",sBuf + i);
    i+=6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ԭʼ���𷽸��ٺ� ��[%6.6s]",sBuf + i);
    i+=6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�м�ƽ̨�������� ��[%8.8s]",sBuf + i);
    i+=8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�м�ƽ̨����ʱ�� ��[%6.6s]",sBuf + i);
    i+=6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ƭ��Ч�� ��[%4.4s]",sBuf + i);
    i+=4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���������ģʽ ��[%3.3s]",sBuf + i);
    i+=3;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�յ��������룻 ��[%11.11s]",sBuf + i);
    i+=11;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ת�������룻 ��[%11.11s]",sBuf + i);
    i+=11;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ˮ�� ��[%12.12s]",sBuf + i);
    i+=12;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ȩ���� ��[%6.6s]",sBuf + i);
    i+=6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ӧ���� ��[%2.2s]",sBuf + i);
    i+=2;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���׷��� ��[%4.4s]",sBuf + i);
    i+=4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� ��[%6.6s]",sBuf + i);
    i+=6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�̻����� ��[%15.15s]",sBuf + i);
    i+=15;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�̻������ ��[%4.4s]",sBuf + i);
    i+=4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���׻��� ��[%3.3s]",sBuf + i);
    i+=3;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "PIN-BLOCK ��[%16.16s]",sBuf + i);
    i+=16;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "PIN BLOCK FORMAT ��[%2.2s]",sBuf + i);
    i+=2;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ŵ� ��[%-104.104s]",sBuf + i);
    i+=104;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ŵ���ʶ ��[%1.1s]",sBuf + i);
    i+=1;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ѣ���0��2λС��λ ��[%12.12s]",sBuf + i);
    i+=12;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ���ױ������� ��[%4.4s]",sBuf + i);
    i+=4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ���״������� ��[%6.6s]",sBuf + i);
    i+=6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ���׷������� ��[%8.8s]",sBuf + i);
    i+=8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ���׷���ʱ�� ��[%6.6s]",sBuf + i);
    i+=6;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ԭ������ˮ�� ��[%12.12s]",sBuf + i);
    i+=12;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ǰ����ˮ�� ��[%8.8s]",sBuf + i);
    i+=8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����1 ��[%28.28s]",sBuf + i);
    i+=28;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����2 ��[%28.28s]",sBuf + i);
    i+=28;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ֿ���֤������ ��[%18.18s]",sBuf + i);
    i+=18;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ֿ������� ��[%30.30s]",sBuf + i);
    i+=30;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������1 ��[%40.40s]",sBuf + i);
    i+=40;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������2 ��[%40.40s]",sBuf + i);
    i+=40;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "END Msg\n\n\n\n");
    
}

void printMngReqMsg(char* sBuf)
{
    char* gsLogFile="CommCC.out.log";
    
    int i = 0;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "BEGIN Msg");
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���𷽱�ʶ ��[%4.4s]",sBuf + i);
    i+=4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� ��[%8.8s]",sBuf + i);
    i+=8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ˮ ��[%22.22s]",sBuf + i);
    i+=22;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����Ա ��[%10.10s]",sBuf + i);
    i+=10;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ļ������� ��[%10.10s]",sBuf + i);
    i+=10;
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "END Msg\n\n\n\n");
    
}

void printMngRspMsg(char* sBuf)
{
    char* gsLogFile="CommCC.out.log";
    
    int i = 0;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "BEGIN Msg");
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "���𷽱�ʶ ��[%4.4s]",sBuf + i);
    i+=4;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�������� ��[%8.8s]",sBuf + i);
    i+=8;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "������ˮ ��[%22.22s]",sBuf + i);
    i+=22;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����Ա ��[%10.10s]",sBuf + i);
    i+=10;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�ļ������� ��[%10.10s]",sBuf + i);
    i+=10;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ӧ�� ��[%2.2s]",sBuf + i);
    i+=2;
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��Ӧ��ϸ��Ϣ ��[%80.80s]",sBuf + i);
    i+=80;
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "END Msg\n\n\n\n");
    
}
