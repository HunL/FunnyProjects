cd $FEHOME/src/Comm/ComCups1
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup2
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCups2
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommPCS
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComPosp
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommCC
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommCB
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommCon
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

