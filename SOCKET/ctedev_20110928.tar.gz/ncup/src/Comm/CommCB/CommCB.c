/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: CommEsb.c													 */
/* DESCRIPTIONS: The save and forward process server.                        */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-06  Chen Liang     Changed for NCUP                               */
/*****************************************************************************/
#include "CommCB.h"

char				gsSrvId[SRV_ID_LEN+1];
char				gsToSrvId[SRV_ID_LEN+1];
char				gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char				gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];

char				gsIpAddr[20];
int					gnPort;
int					gnSocketID;
int					gnTimeOut;
int					gnSysError = 0;
char                gsCommEsberr[20 + 1];
char                gsCommEsbNoMH[30 + 1];

static  int Timeout = 0;
jmp_buf Stackbuf;

void HandleExit (int n);
int CommInit(int argc, char **argv);

/* int		nMaxRspCodeMapN = 0, i; */
int     i;
int		nRcvHostLen;
char	saErrHostMsg[FLD_MISC_LEN+1];

/* static Tbl_rsp_code_map_Def tRspCodeMap[1500]; */

int main(int argc, char **argv)
{
	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	/*
	char	sIntMsgBuf[MSQ_MSG_SIZE_MAX];
	*/
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	char    sAscMsgOutBuf[MSQ_MSG_SIZE_MAX];		
    char    sEbcdMsgOutBuf[MSQ_MSG_SIZE_MAX];
	char	sSrcSrvId[SRV_ID_LEN+1];
	char	sTxnNum[FLD_TXN_NUM_LEN+1],sTxnNumErr[FLD_TXN_NUM_LEN+1];
	char	sRespCode[F039_LEN+1];
	char	sKeyRsp[KEY_RSP_LEN+1];
	int		nReturnCode;
	int 	nMsgInLen;
	/*
	int		nIntMsgLen;
	*/
	int		nMsgOutLen;
	int		nAcctLen;
	/*
	char	sHostRspCode[5],sRspCodeDsp[33];
	*/
	char	sHostRspCode[5];
	char	sUpTxnCode[5], sDownTxnCode[5];
	char	sUpAcct[21], sDownAcct[21];
	char    sTail[1+1];
	char    sCommCtlHeader[16+1];
	char    sTotalMsgLen[4+1];
	char    sCurrentTime[14+1] = {0};

	if(argc < 6)
	{
		printf("Usage:%s srvid seq tosrvid ip port\n", argv[0]);
		exit(-1);
	}

	nReturnCode = CommInit(argc, argv);
	if (nReturnCode)
	{
		printf("CommCB: CommInit error[%d]\n",nReturnCode);
		exit(-2);
	}

	if (sigset(SIGTERM, HandleExit) == SIG_ERR)
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "CommCB started");

	while (1)
	{
		memset(sMsgInBuf,0,sizeof(sMsgInBuf));
		nMsgInLen = MSQ_MSG_SIZE_MAX;
		sigrelse (SIGTERM);
		nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, 
								&nMsgInLen, sMsgInBuf);
		sighold (SIGTERM);
		if (nReturnCode)
		{
			if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"MsqRcv error, %d", nReturnCode);
				exit(-3);
			}
			else
				continue;
		}

		memset (sSrcSrvId, 0, sizeof (sSrcSrvId));
		memcpy (sSrcSrvId, sMsgInBuf, SRV_ID_LEN);

		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"received %d byte msg from %s", nMsgInLen, sSrcSrvId);
		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sMsgInBuf, nMsgInLen);
		
		/*  ���ӹ㷢ͨ�ű��Ŀ�����Ϣ */		
		nMsgInLen = nMsgInLen-(SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN);
		if(nMsgInLen > 4096)
		{
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqRcv ,msg len error,  nMsgInLen=[%d]", nMsgInLen);
		    continue;
		}
		
		memset(&sCommCtlHeader[0],' ',sizeof(sCommCtlHeader));
		memset(&sTotalMsgLen[0],' ',sizeof(sTotalMsgLen));
		
		sprintf(&sTotalMsgLen[0], "%04d", nMsgInLen+12);
		memcpy(&sCommCtlHeader[0], &sTotalMsgLen[0], 4);   /*���ĳ���*/
		memcpy(&sCommCtlHeader[4], "1", 1);                /*У��λ, ֻ���ļ�������Ҫ����*/
		memcpy(&sCommCtlHeader[4+1], "    ", 4);           /*crcУ��*/
		
		/*�������� -- 0- ϵͳ����*/
		memcpy(&sCommCtlHeader[4+1+4], "0", 1);
		
		/*Ӧ��������*/
		memcpy(&sCommCtlHeader[4+1+4+1], "000" ,3);
		
		memset(&sMsgOutBuf[0], ' ', sizeof(sMsgOutBuf));
		
		memcpy(&sMsgOutBuf[0],&sCommCtlHeader[0],16);
		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"nMsgInLen %d ", nMsgInLen);
		memcpy(&sMsgOutBuf[16], &sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN], nMsgInLen);
		nMsgOutLen = nMsgInLen+16;
		
		vAsc2Ebcdic(sEbcdMsgOutBuf, sMsgOutBuf, nMsgOutLen);
		
		HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sMsgOutBuf, nMsgOutLen);
						
		HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sEbcdMsgOutBuf, nMsgOutLen);	

		memset(&ComBlock, 0, sizeof(ComBlock));
		ComBlock.iTotal = nMsgOutLen;
		memcpy(ComBlock.Text, sEbcdMsgOutBuf, nMsgOutLen);     

		gnSysError = 0;

		gnSocketID = tcpOpen(gsIpAddr, gnPort, 1, 2);
		if ( gnSocketID < 0 )
		{
		     HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "tcpOpen IP: %s, PORT: %d, error %d, %s", 
							                gsIpAddr, gnPort, errno, strerror(errno));
		     gnSysError = -1;
		}
		else
		{
		     HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "tcpOpen ok %d", gnSocketID);
		     gnSysError = 0;
        }
		
		if(gnSysError == 0)
		{
			nReturnCode=WriteSock(gnSocketID, ComBlock.iTotal, ComBlock.Text); 
			if ( nReturnCode <= 0 )
			{				
				HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "WriteSock error %d, %s",  errno, strerror(errno));
				gnSysError = -2;
			}
			HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"write %d byte msg ok", nReturnCode);
	
			memset(&ComBlock, 0, sizeof(ComBlock));
			nReturnCode=ReadSock(gnSocketID, ComBlock.Text, gnTimeOut);
			if ( nReturnCode < 0 )
			{			   
				HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ReadSock error %d, %s", errno, strerror(errno));
				tcpClose(gnSocketID);
				continue;
			}
			
			memset(sMsgOutBuf, 0, sizeof(sMsgOutBuf));
			nMsgOutLen = nReturnCode;
			HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
				ComBlock.Text, nReturnCode);

			vEbcdic2Asc(sAscMsgOutBuf, ComBlock.Text, nMsgOutLen);	
			/* ��ʼ���ڲ�ͨѶ��Ϣ */			
			sprintf(sMsgOutBuf, "%4.4s%4.4s%016d", gsSrvId, gsToSrvId, getpid());
			/* ʱ��� */
			CommonGetCurrentTime(sCurrentTime);
			
        	memcpy(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN,
               sCurrentTime, FLD_TIME_STAMP_LEN);
               
			/*ȥ��ͨѶ��Ϣͷ*/
			memcpy(sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN, sAscMsgOutBuf+12, GFBUFLEN);	
	        nMsgOutLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN + GFBUFLEN;
	        
			tcpClose(gnSocketID);		
		}
		
		switch(gnSysError)
		{
			case -1:
				/* ����ʧ�ܴ���ͻ��� */
				break;
			case -2:
				/* ����ʧ�ܴ���ͻ��� */
				break;
			default:
				break;
		}
			
		nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, nMsgOutLen, sMsgOutBuf);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"MsqSnd to %s error, %d", gsToSrvId, nReturnCode);
			continue;
		}
		
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"send msg to %s", gsToSrvId);
		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sMsgOutBuf, nMsgOutLen);
	}
}

/*****************************************************************************/
/* FUNC:   int CommInit (int argc, char **argv)                            */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �������ݿ�, ����ȫ�ֱ���, ��ȡ���в���,                           */
/*         ��ʼ����Ϣ����                                                    */
/*****************************************************************************/
int CommInit (int argc, char **argv)
{
	/*
	int				i;
	*/
	int				nReturnCode;
	Tbl_srv_inf_Def	tTblSrvInf;
	/*
    char			*lspTmp;
	*/
	int				lUsageKey;

	/* get server id arg 1; server seq arg 2; to server id arg 3 */
	strcpy(gsSrvId, argv[1]);
	strcpy(gsSrvSeqId, argv[2]);
	strcpy(gsToSrvId, argv[3]);
	
	strcpy(gsIpAddr, argv[4]);
	
	/****************************
	if(!memcmp(gsSrvSeqId,"1",1))
	****************************/
	if (atoi(gsSrvSeqId) % 2 == 1)
	{
	      gnPort = atoi(argv[5]);
	      /*gnPort = atoi(argv[6]);*/
	}
	else
	{
	      gnPort = atoi(argv[6]);
	      /*gnPort = atoi(argv[5]);*/
    }

	/* connect to database */
    nReturnCode = DbsConnect ();
	if (nReturnCode) return (nReturnCode);
	
	
	/* get log file name from tbl_srv_inf */
	if (getenv(SRV_USAGE_KEY))
		lUsageKey=atoi (getenv(SRV_USAGE_KEY));
	else
		return -2;

	memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
	tTblSrvInf.usage_key = lUsageKey;
	memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
	nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
	if (nReturnCode)
		return (nReturnCode);

	CommonRTrim(tTblSrvInf.srv_name);
	/****************************************************************
	sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_name, gsSrvSeqId);
	*****************************************************************/
	sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_id, gsSrvSeqId);

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SVR: %s ID: %s IP: %s PORT1: %d ", 
					   gsSrvId, gsSrvSeqId, gsIpAddr, gnPort);
	/* init msg queue */
	memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
	nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d", nReturnCode);	  
		return (nReturnCode);
	}
       
	if (getenv("TL_COMM_TIMEOUT"))
		gnTimeOut = atoi (getenv("TL_COMM_TIMEOUT"));
	else
		return -1;
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"gnTimeOut %d", gnTimeOut);

	/* disconnect db */
	nReturnCode = DbsDisconnect ();
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"DbsDisconnect error, %d", nReturnCode);	  
	}
	return (0);
}

void HandleExit (int n)
{
	HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "CommCB exits");
	exit( 1 );
}

/*
 * Function Name:  IOTimeOut
 * Parameter 1  :  no         ������
 */
void IOTimeOut(int no )
{
  Timeout = 1;
  longjmp( Stackbuf, Timeout ); 
}


/*
 * Function Name: tcpOpen 
 * Parameter 1  : hostaddress  ��������IP��ַ
 * Parameter 2  : hostport     ���������˿ں� 
 * Parameter 3  : retrys       ������������
 */

int tcpOpen(char *sIpAddr, int nPort, int nRetrys, int nTimeOut)
{
	int    sock;
	struct sockaddr_in remote;

    bzero(&remote, sizeof(remote));
    remote.sin_family = AF_INET;
	remote.sin_addr.s_addr = inet_addr(sIpAddr);
    remote.sin_port = htons(nPort);

	HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ip %s port %d", sIpAddr, nPort);

	Timeout = 0;
    signal(SIGALRM, IOTimeOut);

    setjmp(Stackbuf);
    if (Timeout)
 	{
 		alarm(0);
 		return -1;
 	}

	while (nRetrys) 
	{
	    alarm(nTimeOut); 
	    HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "retrys %d", nRetrys);
		if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	    {
			alarm(0);
			if (nRetrys > 0) 
			{	
					nRetrys--;
					continue;
			}
		    return -2;
	    }
	
		HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "socket ok %d", sock);
	
	    if (connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0)
	    {
					alarm(0);
					tcpClose(sock);
					if (nRetrys > 0) 
					{	
						nRetrys--;
						continue;
					}
		      return -3;
	    }
		alarm(0);
	
	    return sock;
	} /* while */
    return -4;
}

/*
 * Function Name: tcpClose 
 * Parameter 1  : sock      Ҫ�رյ�socket�� 
 */
int tcpClose( sock )
int sock;
{
    	if ( fcntl( sock, F_SETFL, FNDELAY ) < 0 )
      		return( -1 );
    	if ( sock != 0 )
      		shutdown( sock, 2 );

    	close( sock );
    	return( 0 );
}

/*
 * Function Name:  ReadSock
 * Parameter 1  :  socketid   socket��     
 * Parameter 2  :  buffer     ���ܻ�����
 * Parameter 3  :  timeout    ��ʱʱ��    
 */
int ReadSock(socketid,buffer,timeout)
int socketid;
register char * buffer;
int  timeout;
{
	
	int num, nLen, I=0,nleft,nread;
	
	char tmp_buf[5], Buf_head[5];
	char tmp_Str[2000], sBody[1024];
	char sEbcdBuf[2000] = {0};
	
	Timeout = 0;
    signal(SIGALRM, IOTimeOut);
    alarm( timeout ); 

    setjmp( Stackbuf );
    if ( Timeout )
 	{
 		alarm( 0 );
 		return( -1 );
 	}
	
	memset( tmp_buf, 0x00, sizeof(tmp_buf) );

    num = read(socketid, tmp_buf, 4);
	if ( num == 0 )
	{
 		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "num = 0  ,read len error = %d", errno);
		alarm(0);
 		return (-1);
 	}
 	else  if ( num < 0 )
 	{
 		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "read len error = %d", errno);
		alarm(0);
 		return (-1);
 	}
	
	HtDebugString( gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, (char *)tmp_buf, (int) 4 ) ;
	
	/* ת�����ÿ����ĳ��� */
	vEbcdic2Asc(Buf_head, tmp_buf, 4);

	nLen = atoi(Buf_head);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
			"nLen = %d,BUF_SIZE[%d]", nLen,BUF_SIZE);

	if ( nLen == 0 || nLen > BUF_SIZE )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "len error = %d", nLen);
		alarm(0);
		return (-1);
	}
	else
		 HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "data len  = %d", nLen);

	nleft=nLen;
	while ( nleft > -1 )
	{
		nread = read(socketid, buffer, nleft);
		if (nread<0 && errno==EINTR) 
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"EINTR error");
			break;
		}
		else if (nread < 0)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"read socket error");
			alarm(0);
			return(-1);
		}
		else if ( nread == 0 ) 
			break;
		nleft -= nread;
		buffer += nread;
		if ( nleft <= -1 )
		   break ;
	}	
	alarm(0);
	
	return (nLen-nleft);
}

/*
 * Function Name:  WriteSock
 * Parameter 1  :  socketid   socket��     
 * Parameter 2  :  len        ���ͻ���������
 * Parameter 3  :  buffer     ���ͻ�����
 */
int WriteSock(socketid,len,buffer) 
int socketid;
int len;
char * buffer;
{
	int  num, iWritelen;

 	unsigned char Buf_head[5];

 	char saSendBuf[BUF_SIZE];


 	if (len == 0) 
 		return(0);

 	memset(saSendBuf,0,sizeof(saSendBuf));
 	/*
	sprintf(saSendBuf, "%04d", len-1);
	*/
	memcpy(saSendBuf, buffer, len);
    /*
	len = len + 4;
	*/

	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
		saSendBuf, len);

    iWritelen=0;
    for(;;)
    {
        while((num=write(socketid, &saSendBuf[iWritelen],
                            len-iWritelen))<=0)
        {
            if (errno == EINTR) 
            	continue;
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"write socket error");
                return(-1);
        }

        iWritelen+=num;
        if(iWritelen>=len) break;
    }
    return(iWritelen);
}
