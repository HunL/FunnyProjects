#include "TopSoapInc/TopSoap.h"
#include "TopSoapInc/TopHtLog.h"	/*����־*/
#include "xmlstruct.h"	
#include <string.h>

char sSoapServerTestLog[32] = "soap-server-test.log";

static char *sWebMethod = "jfscxftxn";

void vServerQuit();
int vQueryHandle();
char		gsSrvId[SRV_ID_LEN+1];
char		gsToSrvId[SRV_ID_LEN+1];
char		gsSrvSeq[SRV_SEQ_ID_LEN+1];
char        sCurrentTime[14+1];
T_SrvMsq	gatSrvMsq[SRV_MSQ_NUM_MAX];
Tbl_srv_inf_Def	tTblSrvInf;

#define COMI_MSG_WRITETO 60
#define COMI_MSG_READTO 60

msg_def MsgIn;
msg_def MsgOut;
int 	return_flag=0;
void   Rdmsg_to();
AllXmlnodeBuf  sPARallxmlnodebuf;
AllXmlnodeBuf  sCRTallxmlnodebuf;


int main(int argc, char **argv)
{
	int nReturnCode,nRet=0;
	pid_t	gpidtMainPid;
	sigset(SIGTERM, vServerQuit);
	  if(argc < 4)
    {
        printf("Usage:%s srvid seq tosrvid port\n", argv[0]);
        exit(-1);
    }

    strcpy(gsSrvId, argv[1]);
    strcpy(gsSrvSeq, argv[2]);
    strcpy(gsToSrvId, argv[3]);
	
    nRet = DbsConnect ();
    if (nRet)
    {
        printf("CommP nRet[%d] LINE[%d]\n", nRet, __LINE__);
        exit(-2);
    }
    /* init XML inf data add by tangbin begin*/
    memset(&sPARallxmlnodebuf,0,sizeof(AllXmlnodeBuf));
    HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "xmlIpcDftLoad ");
    nReturnCode = BribdgexmlInit(1,&sPARallxmlnodebuf);
    if (nReturnCode)
    {
		HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "xmlIpcDftLoad error, %d.", nReturnCode);
		DbsDisconnect ();
		return (nReturnCode);
    }
    /*init XML inf data add by tangbin end*/
    
    /* init XML inf data add by tangbin begin*/
    memset(&sCRTallxmlnodebuf,0,sizeof(AllXmlnodeBuf));
    nReturnCode = PacksendxmlInit(1,&sCRTallxmlnodebuf);
    if (nReturnCode)
    {
		HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "xmlIpcDftLoad error, %d.", nReturnCode);
		DbsDisconnect ();
		return (nReturnCode);
    }
    /*init XML inf data add by tangbin end*/
    
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nRet = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nRet)
    {
        printf("CommP nRet[%d] LINE[%d]\n", nRet, __LINE__);
        DbsDisconnect ();
        exit(-2);
    }

    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (sSoapServerTestLog, "%s.%s.log", tTblSrvInf.srv_id, gsSrvSeq);

    memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
    nRet = MsqInit (gsSrvId, gatSrvMsq);
    if (nRet)
    {
        HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error,%d", nRet);
        DbsDisconnect ();
        exit(-3);
    }

	nRet = DbsDisconnect ();
	if (nRet)
	{
		HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsDisconnect error, %d.", nRet);
	}
		
	/*����������*/
	if(TopSoapSServerStart(sWebMethod)){
		HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "SoapInit Failed");
		exit(-1);
	}
	/*�ȴ�һ���ͻ�������*/
	while(TopSoapSServerAccept()){
		if((gpidtMainPid = fork()) == -1) {
			TopSoapSServerCloseClient(); 
			continue;
		}  
		if(gpidtMainPid == 0){	/* Child Process*/
			HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "[1]CHILD PROCESS IS WORKING...");
			sighold(SIGTERM);
			if(vQueryHandle()){
				HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "vQueryHandle Failed");
			} else {
				HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "vQueryHandle Success");
			}
			TopSoapSServerCloseClient(); 
			sigrelse(SIGTERM);
			HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "CHILD PROCESS FINISHED...");
		} else{ /* Father Process	*/
			TopSoapSServerCloseClient(); 
		}
	}
	exit(0);	
}

void vServerQuit()
{
	TopSoapSServerStop();
}

int vQueryHandle()
{
	int		nMsgLen, nRetVal,nRet=0;
	char	sNetMsgBuf[BUF_SIZE];
	char	sOutMsgBuf[BUF_SIZE];
	char	sMsgType[17];
	long	nPid; 
	char sXmlOutBuf[4096];
	long nXMLOutLen;
	
	HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "vQueryHandle IS HANDLING...");
	TopSOAPENV soapEnv;
	char xpathBuf[128];
	char valueBuf[128];
	
	nPid = getpid();
    memset(&soapEnv,0x00,sizeof(TopSOAPENV));
	HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "CreateSoapEnv SUCCESSFULLY");
	if(TopSoapSServerResvMesg(&soapEnv)){
		HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "TopSoapSServerResvMesg Failed");
		return (-1);
	}             
	/*��XMLת��Ϊ����*/
	nMsgLen = strlen(soapEnv.reqxmlBuffer);
	nRet = parsexml(1, soapEnv.reqxmlBuffer, nMsgLen,
							sXmlOutBuf, &nXMLOutLen, sPARallxmlnodebuf);
	if (nRet)
	{
		HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"parsexml error [%d]", nRet);	
		return (-1);
	 }
			
	/*��XML���ķ���Bridge*/	
   	memset(&MsgOut,' ',sizeof(msg_def));
   	nMsgLen = nXMLOutLen;
 	memcpy(MsgOut.msg_buf, gsSrvId, SRV_ID_LEN);
 	/*memcpy(MsgOut.msg_buf+SRV_ID_LEN, gsToSrvId, SRV_ID_LEN);*/
	memset(sMsgType,0,sizeof(sMsgType));
	sprintf(sMsgType,"%016ld",nPid);
 	memcpy(MsgOut.msg_buf+SRV_ID_LEN*2, sMsgType, FLD_MSQ_TYPE_LEN);
 	CommonGetCurrentTime (sCurrentTime);
 	memcpy(MsgOut.msg_buf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN,sCurrentTime,FLD_TIME_STAMP_LEN);
 	memcpy(MsgOut.msg_buf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN,sXmlOutBuf+38,nXMLOutLen-38);
 	
			  
	nRet = MsqSnd (gsToSrvId, gatSrvMsq, 0, nMsgLen, MsgOut.msg_buf);
	if (nRet)
	{
		HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,	"MsqSnd ToSrvId[%s] error [%d][%d]",
				gsToSrvId, nRet, errno);
		return (-1);
	}

	HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "write msg to %s ok!", gsToSrvId);
	HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "begin receive msg from %s", gsSrvId);

   	return_flag=0;
   	sigset(SIGALRM, Rdmsg_to);
   	alarm(COMI_MSG_READTO);

	nMsgLen = 4096 ;
   	memset(&MsgIn,' ',sizeof(msg_def));  
   	   	 
	nRet = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, &nMsgLen, MsgIn.msg_buf);
	if (nRet || return_flag == 1)
	{
		HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,	"receive msg from %s error = %d", gsSrvId, nRet);
    	return -1;
	}
	alarm(0);

	HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "receive msg from %s len = %d", gsSrvId, nMsgLen);
	HtDebugString(sSoapServerTestLog, HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, MsgIn.msg_buf, nMsgLen);
		
	memset(sOutMsgBuf, 0, sizeof(sOutMsgBuf));
	/*nMsgLen = nMsgLen-SRV_ID_LEN*2-FLD_MSQ_TYPE_LEN-FLD_TIME_STAMP_LEN;
	sprintf(sOutMsgBuf,"%04d",nMsgLen);
	HtLog (sSoapServerTestLog, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,	"nMsgLen=[%04d]",nMsgLen);
    memcpy(sOutMsgBuf+4, &MsgIn.msg_buf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER], nMsgLen);
    nMsgLen += 4;
    memcpy(sOutMsgBuf, &MsgIn.msg_buf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN], nMsgLen);
    
    HtLog (sSoapServerTestLog, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,	"start write socket");
	HtDebugString(sSoapServerTestLog, HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, sOutMsgBuf, nMsgLen);
		
	HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "TopSoapSServerResvMesg SUCCESSFULLY");*/
	 
	 memset(sXmlOutBuf, ' ', sizeof(sXmlOutBuf));	 
    nRet = createxml(1,MsgIn.msg_buf,nMsgLen,sXmlOutBuf,&nXMLOutLen,sCRTallxmlnodebuf);
    if (nRet)
		{
			HtLog( sSoapServerTestLog, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"send %d byte msg from xml", nXMLOutLen);  
		   	return (-1);
		}
	HtDebugString (sSoapServerTestLog, HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, sXmlOutBuf, nXMLOutLen);
	
	HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "SoapServerResponseInit SUCCESSFULLY");
	/**************************************
	 * �������������ݽ��д�����
	 * ��������Ӧxml��
	 **************************************/
	 memset(&soapEnv,0x00,sizeof(TopSOAPENV));
     memcpy(&soapEnv.reqxmlBuffer,sXmlOutBuf,nXMLOutLen);

   	HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "SoapBodyAddElement[%s] SUCCESSFULLY", xpathBuf);
   		
   	soapEnv.httpStatus = 200;
   	sprintf(soapEnv.httpStatusDesc, "%s", "OK");
   	/*��ͻ��˷�����Ӧ����*/
   	if(TopSoapSServerSendMesg(&soapEnv)){
   		HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "TopSoapSServerSendMesg Failed");
	return (-1);	
   	}
   	HtLog(sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "TopSoapSServerSendMesg SUCCESSFULLY");
   	return 0;
}


void   Rdmsg_to()
{
	HtLog (sSoapServerTestLog, HT_LOG_MODE_ERROR, __FILE__,__LINE__,	"Read from message queue over time!");
	return_flag=1;
}
