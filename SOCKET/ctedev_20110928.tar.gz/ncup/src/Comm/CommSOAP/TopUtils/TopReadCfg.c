/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopCfg.h"
#include "HtLog.h"	/*����־*/

static char sTopCfgLogName[32] = "TopReadCfg.log";

static FILE *cfgFp = NULL;
static char sFullName[256];


char *_TopCfg_RTrim(char *sChars){
	int i = strlen(sChars) - 1;
	while(sChars[i] == ' ' || sChars[i] == '\n'){
		i--;
	}
	sChars[i+1] = '\0';	
	return sChars;
}
char *_TopCfg_LTrim(char *sChars){
	int i = 0;
	while(sChars[i] == ' ' || sChars[i] == '\r' || sChars[i] == '\n'){
		i++;
	}
	return sChars + i;
}

/***********************************************************
 * ����Ŀ¼
 ***********************************************************/
int _Top_MakeDir( char *psPatch)
{
    char lsaFileUpPatch[500];
    struct stat lstatBuf;
    int llResult, i , j;

    memset(lsaFileUpPatch, 0, sizeof(lsaFileUpPatch));
    HtStrcpy(lsaFileUpPatch, psPatch);
    j = strlen(lsaFileUpPatch);
    for(i=1; i<=j; i++)
    {
        if(lsaFileUpPatch[i] == '/' ||
           lsaFileUpPatch[i] == '\0')
        {
            lsaFileUpPatch[i] = 0;
            if(( llResult = stat(lsaFileUpPatch, &lstatBuf) ) != 0)
            {
                llResult = mkdir( lsaFileUpPatch, S_IRWXU|S_IRWXG|S_IRWXO );
                if(llResult != 0)
                {
                    return llResult;
                }
            }
            lsaFileUpPatch[i] = '/';
        }
    }
    return 0;
}

/***********************************************************
 * �����ļ�Ŀ¼��
 * (1)�������� TOPSOAP_CFG_PATH
 * (2)$HOME/etc/soapcfg ����Ŀ¼������,�򴴽�Ŀ¼
 ***********************************************************/
int OpenCfgFile(char *sFileName)
{
	memset(sFullName, 0x00, sizeof(sFullName));
	
	if(getenv (TOPSOAP_CFG_PATH)){
		HtStrcpy(sFullName, (char *)getenv(TOPSOAP_CFG_PATH));
	}
	if(strlen(sFullName) == 0) {
		HtStrcpy(sFullName, (char *)getenv("FEHOME"));
		HtStrcat(sFullName, "/etc/soapcfg");
		
		if(_Top_MakeDir(sFullName)){
			HtLog(sTopCfgLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call _Top_MakeDir[%s] Error", sFullName);
			return (-1);
		}
	}
	HtStrcat(sFullName, "/");
	HtStrcat(sFullName, sFileName);
	HtStrcat(sFullName, ".soap");
	cfgFp = fopen(sFullName, "r");
	if (cfgFp == NULL ){
		HtLog(sTopCfgLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Can't fOpen Cfg File[%s]", sFullName);
		return (errno);
	}
	return 0;
}
int CloseCfgFile()
{
	if(cfgFp != NULL)
		return fclose(cfgFp);
	return 0;
}

static int _GetCfgItem(char *sSectionName, char *sItemName, char *sItemValue)
{
	char sLine[256];
	char *pTmp = NULL;
	char *pTmpED = NULL;
	int  isFind = 0;
	
	if(cfgFp == NULL){
		return (-1);	
	}
	
	rewind(cfgFp);
	
	while(fgets(sLine, sizeof(sLine), cfgFp)){
		if(sLine[0] == '#'){
			continue;	
		}
		if(!isFind){
			pTmp = strstr(sLine, sSectionName);
			if(pTmp == NULL){
				continue;
			} else {
				/*���Ҵ˶��ж�Ӧitem��ֵ*/
				isFind = 1;
			}
		} else {
			pTmp = strstr(sLine, sItemName);
			if(pTmp == NULL){
				continue;
			} else {
				/*��ȡ�˶��ж�Ӧitem��ֵ*/
				pTmp += (strlen(sItemName) + 1);
				pTmpED = strstr(pTmp, "#");
				if(pTmpED != NULL){
					*pTmpED = '\0';
				}
				HtSprintf(sItemValue, "%s", _TopCfg_RTrim(pTmp));
				return 0;
			}
		}
	}
	HtLog(sTopCfgLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Cfg Item Can't be found[%s->%s->%s]", sFullName, sSectionName, sItemName);
	return (-1);
}


int GetHttpCfgItem(char *sItemName, char *sItemValue)
{
	return _GetCfgItem("[HTTP]", sItemName, sItemValue);
} 

int GetSoapRootCfgItem(char *sItemName, char *sItemValue)
{
	return _GetCfgItem("[SOAP_ROOT]", sItemName, sItemValue);
} 

int GetSoapEnvelopCfgItem(char *sItemName, char *sItemValue)
{
	return _GetCfgItem("[SOAP_ENVELOP]", sItemName, sItemValue);
}

int GetSoapHeaderCfgItem(char *sItemName, char *sItemValue)
{
	return _GetCfgItem("[SOAP_HEADER", sItemName, sItemValue);
}

int GetSoapBodyCfgItem(char *sItemName, char *sItemValue)
{
	return _GetCfgItem("[SOAP_BODY", sItemName, sItemValue);
}

int GetXmlCfgItem(char *sItemName, char *sItemValue)
{
	return _GetCfgItem("[XML]", sItemName, sItemValue);
} 

int GetVarietyCfgItem(char *sItemName, char *sItemValue)
{
	return _GetCfgItem("[VARIETY]", sItemName, sItemValue);
} 
