/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopCfg.h"
#include "TopSoapInc/TopHtLog.h"	/*����־*/

static char sTopCfgLogName[32];

static FILE *cfgFp = NULL;
static char sFullName[256];


char *_TopCfg_RTrim(char *sChars){
	int i = strlen(sChars) - 1;
	while(sChars[i] == ' ' || sChars[i] == '\n'){
		i--;
	}
	sChars[i+1] = '\0';	
	return sChars;
}

char *_TopCfg_LTrim(char *sChars){
	int i = 0;
	while(sChars[i] == ' ' || sChars[i] == '\r' || sChars[i] == '\n'){
		i++;
	}
	return sChars + i;
}

/***********************************************************
 * ����Ŀ¼
 ***********************************************************/
int Top_MakeDir( char *psPatch)
{
    char lsaFileUpPatch[500];
    struct stat lstatBuf;
    int llResult, i , j;

    memset(lsaFileUpPatch, 0, sizeof(lsaFileUpPatch));
    HtStrcpy(lsaFileUpPatch, psPatch);
    j = strlen(lsaFileUpPatch);
    for(i=1; i<=j; i++)
    {
        if(lsaFileUpPatch[i] == '/' ||
           lsaFileUpPatch[i] == '\0')
        {
            lsaFileUpPatch[i] = 0;
            if(( llResult = stat(lsaFileUpPatch, &lstatBuf) ) != 0)
            {
                llResult = mkdir( lsaFileUpPatch, S_IRWXU|S_IRWXG|S_IRWXO );
                if(llResult != 0)
                {
                    return llResult;
                }
            }
            lsaFileUpPatch[i] = '/';
        }
    }
    return 0;
}

/***********************************************************
 * �������ļ�
 ***********************************************************/
int Top_OpenCfgFile(char *sFilePath, char *sLogFile) {
	
	if(strlen(sFilePath) <= 0 || strlen(sLogFile) <= 0) {
		
		return (-1);	
	}
	memset(sFullName, 0x00, sizeof(sFullName));
	memset(sTopCfgLogName, 0x00, sizeof(sTopCfgLogName));
	
	HtStrcpy(sFullName, sFilePath);
	HtStrcpy(sTopCfgLogName, sLogFile);
	
	cfgFp = fopen(sFullName, "r");
	if (cfgFp == NULL ){
		Top_HtLog(sTopCfgLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Can't fOpen Cfg File[%s]", sFullName);
		return (errno);
	}
	return 0;
}

/***********************************************************
 * �ر������ļ�
 ***********************************************************/
int Top_CloseCfgFile()
{
	if(cfgFp != NULL)
		return fclose(cfgFp);
	return 0;
}

/***********************************************************
 * ��ȡ�����ļ���ĳ�����öε�ĳ���������ֵ
 ***********************************************************/
int Top_GetCfgItem(char *sSectionName, char *sItemName, char *sItemValue)
{
	char sLine[256];
	char *pTmp = NULL;
	char *pTmpED = NULL;
	int  isFind = 0;
	char *pTempP = NULL;
	char sTempBuf[256];
	
	if(cfgFp == NULL){
		return (-1);	
	}
	
	rewind(cfgFp);
	
	while(fgets(sLine, sizeof(sLine), cfgFp)){
		if(sLine[0] == '#'){
			continue;	
		}
		/*���ȥ���ո�*/
		pTmp = _TopCfg_LTrim(sLine);
/*
Top_HtLog(sTopCfgLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "line[%s]", pTmp);
*/

		if(!isFind){
			/*��ò�Ҫֱ��ȥ��section����,��һ��������һ�����öε������а�����һ�����öε�����ʱ�ͻ�������*/
			if(pTmp[0] == '[') {
				pTempP = pTmp+1;
				pTmpED =  strstr(pTempP, "]");
				if(pTmpED == NULL){
					Top_HtLog(sTopCfgLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
									"Section�����ý�������, Ӧ��Ϊ[section_name]!");
					return (-1);
				}
				pTempP = _TopCfg_LTrim(pTempP);

				memset(sTempBuf, 0x00, sizeof(sTempBuf));
				HtMemcpy(sTempBuf, pTempP, pTmpED - pTempP);
				_TopCfg_RTrim(sTempBuf);
/*
Top_HtLog(sTopCfgLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "FileSectionName[%s] vs UserInputName[%s]", sTempBuf, sSectionName);
*/
				if(strcmp(sTempBuf, sSectionName) == 0) {	
					/*���Ҵ˶��ж�Ӧitem��ֵ*/
					isFind = 1;
				}
			}
			continue;
		} else {
			/*�ж��Ƿ񵽴�����һ��Section��*/
			if(pTmp[0] == '[') {
				Top_HtLog(sTopCfgLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "��ǰSection[%s]���е��������Ѿ�����,��û���ҵ�������[%s]!", sSectionName, sItemName);
				return (-1);
			}
			
			pTmp = strstr(pTmp, sItemName);
			if(pTmp == NULL){
				continue;
			} else {
				/*��ȡ�˶��ж�Ӧitem��ֵ*/
				pTmp += (strlen(sItemName) + 1);
				pTmpED = strstr(pTmp, "#");
				if(pTmpED != NULL){
					*pTmpED = '\0';
				}
				HtSprintf(sItemValue, "%s", _TopCfg_RTrim(pTmp));
				return 0;
			}
		}
	}
	Top_HtLog(sTopCfgLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"Cfg Item Can't be found[%s->%s->%s]", sFullName, sSectionName, sItemName);
	return (-1);
}
