#include "TopSoapInc/TopEncoding.h"
#include "TopSoapInc/TopHtLog.h"

extern char gsLogFile[32];

/********************************************************************
 * ����ת������(������iconv)
 * Params:
 *     sToCode    - Ŀ�ı���
 *     sFromCode  - Դ����
 *     sOutPut    - �������
 *     lOutputLen - ������ݵ���󳤶�
 *     sInput     - ��������
 *     lInputLen  - �������ݵĳ���
 * Return:
 *     -1 if Fail
 *     number of conversions  if Success
 ********************************************************************/
int TopEncoding_Convert(char *sToCode, char *sFromCode, char *sOutPut, long lOutputLen, char *sInput, long lInputLen)
{
	iconv_t	convd;				/* conversion descriptor */
	size_t	inbytesleft;		/* num bytes left in input buffer */
	size_t	outbytesleft;		/* num bytes left in output buffer */
	size_t	ret_val;			/* number of conversions */
	
	/* Initiate conversion -- get conversion descriptor */
	if ((convd = iconv_open(sToCode, sFromCode)) == (iconv_t)-1) {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call iconv_open(%s->%s) Error!", sFromCode, sToCode);
		return (-1);
	}
	Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Call iconv_open(%s->%s)", sFromCode, sToCode);
	
	inbytesleft = (size_t)lInputLen;
	outbytesleft = (size_t)lOutputLen;
	Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "inbytesleft[%ld]", inbytesleft);
	Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "outbytesleft[%ld]", outbytesleft);

	ret_val = iconv(convd, &sInput, &inbytesleft, &sOutPut, &outbytesleft);

	Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Call iconv() End - [%d]", ret_val);
	Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "inbytesleft[%ld]", inbytesleft);
	Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "outbytesleft[%ld]", outbytesleft);
	
	/* iconv() returns the number of non-identical conversions performed.
	 * If the entire string in the input buffer is converted, the value pointed to by inbytesleft will be zero. 
	 * If the conversion stopped due to any reason, the value pointed to by inbytesleft will be non-zero and
	 * errno is set to indicate the condition.
	 */
	if(ret_val == -1) {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call iconv() Error!");
		if (errno == EINVAL) {
			/* Input conversion stopped due to an incomplete
			 * character or shift sequence at the end of the input buffer.
			 */
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Input conversion stopped due to an incomplete character or shift sequence at the end of the input buffer.");
		
		} else if (errno == EILSEQ) {
			/* Input conversion stopped due to an input byte that does not belong to the input codeset.
			*/
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Input conversion stopped due to an input byte that does not belong to the input codeset.");
		} else if (errno == E2BIG) {
			/* Input conversion stopped due to lack of space in the output buffer. 
			* inbytesleft has the number of bytes to be converted.
			*/
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Input conversion stopped due to lack of space in the output buffer.");
		} 
		return (-1);
	}
	
	/* end conversion & get rid of the conversion table */
	if (iconv_close(convd) == -1) {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call iconv_close() Error!");
		return (-1);
	}
	
	return ret_val;
}

/*UTF8->GB18030*/
int Top_UTF8ToGB18030(char *sOutputBuf, long lOutputLen, char *sInputBuf, long lInputLen)
{
	
	return TopEncoding_Convert(TOP_ENCODING_TYPE_GB18030, TOP_ENCODING_TYPE_UTF8, sOutputBuf, lOutputLen, sInputBuf, lInputLen);
	
}

/*GB18030->UTF8*/
int Top_GB18030ToUTF8(char *sOutputBuf, long lOutputLen, char *sInputBuf, long lInputLen)
{
	
	return TopEncoding_Convert(TOP_ENCODING_TYPE_UTF8, TOP_ENCODING_TYPE_GB18030, sOutputBuf, lOutputLen, sInputBuf, lInputLen);
	
}

int Top_UTF8InHex(char *sOutputBuf, long lOutputLen, char *sInputBuf, long lInputLen)
{
	int		i;
	char	sTemp[128];
	
	for(i = 0; i < lInputLen; i++) 
	{
		memset(sTemp, 0x00, sizeof(sTemp));
		HtSprintf( sTemp, "%02X", (unsigned	char)sInputBuf[i]);
		if( i * 2 > lOutputLen) {	
			Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Call Top_UTF8InHex : No Enough Space.");
			return (-1);
		}
		strncat( sOutputBuf, sTemp, 2);
	}
	
	return 0;
}
