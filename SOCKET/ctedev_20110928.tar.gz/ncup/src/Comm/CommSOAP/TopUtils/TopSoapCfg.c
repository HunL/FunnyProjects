/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopCfg.h"
#include "TopSoapInc/TopHtLog.h"	/*����־*/

static char sTopCfgLogName[32] = "TopSoapCfg.log";

static char sFullName[256];


/***********************************************************
 * �����ļ�Ŀ¼��
 * (1)�������� TOPSOAP_CFG_PATH
 * (2)$HOME/etc/soapcfg ����Ŀ¼������,�򴴽�Ŀ¼
 ***********************************************************/
int TopSoap_OpenCfgFile(char *sFileName)
{
	memset(sFullName, 0x00, sizeof(sFullName));
	
	if(getenv (TOPSOAP_CFG_PATH)){
		HtStrcpy(sFullName, (char *)getenv(TOPSOAP_CFG_PATH));
	}
	if(strlen(sFullName) == 0) {
		HtStrcpy(sFullName, (char *)getenv("FEHOME"));
		HtStrcat(sFullName, "/etc/soapcfg");
	}
	if(Top_MakeDir(sFullName)){
		Top_HtLog(sTopCfgLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call Top_MakeDir[%s] Error", sFullName);
		return (-1);
	}
	HtStrcat(sFullName, "/");
	HtStrcat(sFullName, sFileName);
	HtStrcat(sFullName, ".soap");
	
	return Top_OpenCfgFile(sFullName, sTopCfgLogName);
}


int GetHttpCfgItem(char *sItemName, char *sItemValue)
{
	return Top_GetCfgItem("HTTP", sItemName, sItemValue);
} 

int GetSoapRootCfgItem(char *sItemName, char *sItemValue)
{
	return Top_GetCfgItem("SOAP_ROOT", sItemName, sItemValue);
} 

int GetSoapEnvelopCfgItem(char *sItemName, char *sItemValue)
{
	return Top_GetCfgItem("SOAP_ENVELOP", sItemName, sItemValue);
}

int GetSoapHeaderCfgItem(char *sItemName, char *sItemValue)
{
	return Top_GetCfgItem("SOAP_HEADER", sItemName, sItemValue);
}

int GetSoapBodyCfgItem(char *sItemName, char *sItemValue)
{
	return Top_GetCfgItem("SOAP_BODY", sItemName, sItemValue);
}

int GetXmlCfgItem(char *sItemName, char *sItemValue)
{
	return Top_GetCfgItem("XML", sItemName, sItemValue);
} 

int GetVarietyCfgItem(char *sItemName, char *sItemValue)
{
	return Top_GetCfgItem("VARIETY", sItemName, sItemValue);
} 
