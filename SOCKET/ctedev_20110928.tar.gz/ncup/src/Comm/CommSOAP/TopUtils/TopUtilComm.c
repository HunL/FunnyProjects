/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *  ������ : ������                                                       *
 *  DATE   : 2009-11-12
 **************************************************************************/
#include "TopSoapInc/TopUtilComm.h"
#include "TopSoapInc/TopHtLog.h"    /*����־*/


#define TRANS_CHAR_SIZE 2

#define REPLACE_LEFT_FIRST  0	/*�滻 ����*/
#define REPLACE_RIGHT_FIRST 1	/*�滻 ����*/

/*Ϊ�˼�, strlen(sReplaceStr) <= strlen(sMatchStr)*/
int Top_ReplaceStr(char *sSrcBuf, int nBufSize, char *sMatchStr, char *sReplaceStr, int nLeftOrRight)
{
	int  iStringLen;
	char *FindPos = NULL;
	
	if(strlen(sReplaceStr) > strlen(sMatchStr)) {
		return (-1);
	}
	
	FindPos = strstr(sSrcBuf, sMatchStr);
	if( (!FindPos) || (!sMatchStr) )
		return 0;
		
	while( FindPos )
	{
		memset(FindPos, ' ', strlen(sMatchStr));
		if(nLeftOrRight == REPLACE_RIGHT_FIRST)
		{
			HtMemcpy(FindPos + strlen(sMatchStr) - strlen(sReplaceStr), sReplaceStr, strlen(sReplaceStr));
		} else {
			HtMemcpy(FindPos, sReplaceStr, strlen(sReplaceStr));
		}

		FindPos = strstr(sSrcBuf, sMatchStr);
	}
	
	return 0;
}

int Top_HttpReplaceStr(char *sStrBuf, int nBufSize)
{

	char* transTbl[TRANS_CHAR_SIZE][3] = 
		{
			{"&lt;", "<", 1},
	        {"&gt;", ">", 0}
	    };	    

	int i;	    

	for (i = 0; i < TRANS_CHAR_SIZE; i ++)
	{
		if(Top_ReplaceStr(sStrBuf, nBufSize, transTbl[i][0], transTbl[i][1], transTbl[i][2])) {
			return (-1);
		}
	}	    

	return 0;
}
