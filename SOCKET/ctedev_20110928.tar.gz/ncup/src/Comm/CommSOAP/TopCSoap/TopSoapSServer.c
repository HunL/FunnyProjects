/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopSoap.h"
#include "TopSoapInc/TopErrCode.h"
#include "TopSoapInc/TopXml.h"
#include "TopSoapInc/TopHtLog.h"	/*����־*/

char sTopSoapSServerLogName[32] = "TopSoapSServer.log";

static char sSrvWebMethodName[128];
static char sSrvWebMethodCfg[128];

int TopSoapSServerStart(char *sWebMethodName)
{
	memset(sSrvWebMethodName, 0x00, sizeof(sSrvWebMethodName));
	memset(sSrvWebMethodCfg, 0x00, sizeof(sSrvWebMethodCfg));
	HtSprintf(sSrvWebMethodName, "%s", sWebMethodName);
	HtSprintf(sSrvWebMethodCfg, "%s", sWebMethodName);
	HtStrcat(sSrvWebMethodCfg, ".ss");/*Single Server*/
	
	Top_HtLog(sTopSoapSServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSoap SServer is Starting...");	
	
	if(TopHttpServerStart(sSrvWebMethodCfg)){
		Top_HtLog(sTopSoapSServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSoap SServer Start Failed");		
		return (-1);
	}	
	Top_HtLog(sTopSoapSServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSoap SServer Start Successfully");	
	return 0;
}

void TopSoapSServerStop()
{
	TopHttpServerStop();
	Top_HtLog(sTopSoapSServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSoap SServer Stoped");	
}

void TopSoapSServerCloseClient()
{
	TopHttpServerCloseClient();
}
int TopSoapSServerAccept()
{
	return TopSocketServerAccept();
}

int TopSoapSServerResvMesg(TopSOAPENV *env)
{
	TopHttpRequest stHttpReq;
	char	*pTmpED = NULL;
	char	tmpBuf[128];
	
	if(TopHttpServerRecvClient(&stHttpReq)){
		Top_HtLog(sTopSoapSServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopHttpServerRecvClient Failed");	
		return (-1);
	}
	/*��TopHttpRequest������soap����Ҫ������*/
	HtSprintf(env->reqxmlBuffer ,stHttpReq.sReqBody);
		
	return 0;
}


int TopSoapSServerSendMesg(TopSOAPENV *env)
{
	
	TopHttpResponse stHttpRsp;
	int llResult;

	memset(&stHttpRsp, 0x00, sizeof(stHttpRsp));
	
	/*��soap���������װTopHttpResponse*/
	stHttpRsp.stRspHead.iHttpStatus = env->httpStatus;
	HtSprintf(stHttpRsp.stRspHead.sHttpStatusDesc, env->httpStatusDesc);

	HtSprintf(stHttpRsp.sRspBody, env->reqxmlBuffer);
	/*trace*/
	Top_HtLog(sTopSoapSServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "\n%s\n%s\n%s",
						"=====================Soap SServer Send Response Message B======================",
						env->reqxmlBuffer,
						"=====================Soap SServer Send Response Message E======================"
						);
	if(TopHttpServerSendClient(&stHttpRsp)){
		Top_HtLog(sTopSoapSServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSoapSServerSendMesg Failed");	
		return (-1);
	}
	return 0;
}

