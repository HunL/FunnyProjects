/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopSoap.h"
#include "TopSoapInc/TopErrCode.h"
#include "TopSoapInc/TopXml.h"
#include "TopSoapInc/TopHttp.h"
#include "TopSoapInc/TopHtLog.h"	/*����־*/

#define TRANS_CHAR_SIZE 2

static char sTopSoapHttpLogName[32] = "TopSoapExtend.log";

int Http_Replace(char *sHttpBuf)
{

	/*Do Something*/
    return 0;

}

int Http_Variety(char *sHttpBuf)
{

	/*Do Something*/
	return 0;

}

