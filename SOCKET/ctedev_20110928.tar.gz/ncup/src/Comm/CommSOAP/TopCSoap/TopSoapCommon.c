/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include <stdarg.h>
#include "TopSoapInc/TopSoap.h"
#include "TopSoapInc/TopErrCode.h"
#include "TopSoapInc/TopXml.h"
#include "TopSoapInc/TopHtLog.h"	/*����־*/

static char sWebSrvMethod[128];

static char sTopSoapLogName[32] = "TopSoap.log";

static int SoapBodyRootCfgInit(TopSOAPENV *env, char *ixmlNode, int iReqOrRsp);


void HtMemcpy(void *__restrict s1, const void *__restrict s2, size_t n)
{
    /* this HtMemcpy can not create any problem */
    memcpy(s1, s2, n);
}

char *HtStrcpy(char *__restrict s1, const char *__restrict s2)
{
    return strncpy( s1, s2, strlen(s2)+1);
}

char *HtStrcat(char *__restrict s1, const char *__restrict s2)
{
    return strncat( s1, s2, strlen(s2)+1);
}

int HtSprintf(char *__restrict s, const char *__restrict format, ...)
{
    va_list args;

    va_start(args, format);
    vsprintf(s, format, args);
    va_end(args);

    return 0;
}

