/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopSoap.h"
#include "TopSoapInc/TopErrCode.h"
#include "TopSoapInc/TopHtLog.h"	/*����־*/


static char sTopSoapClientLogName[32] = "TopSoapClient.log";

TopSOAPENV *SoapClientInit(char *sSoapCfgName)
{	
    TopSOAPENV *env = NULL;

    env = CreateSoapEnv();
	if (env == NULL)
    {
		Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopCreateSoapEnv Failed!");		
		return NULL;
	}

	if(SoapEnvInit(env, sSoapCfgName, TOP_SOAP_REQ_ELEMENT)){
		Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SoapEnvInit Failed!");	
		return NULL;
	}
	return env;
}

int SoapCall(TopSOAPENV *env, char *sSoapCfgName, int isAutoParseRsp)
{

	int	            respLen = 0;
	int	            cRet,nRet;
	char 	        *pTmpST = NULL;
	char 	        *pTmpED = NULL;
	char	        tmpBuf[128];
	TopHttpRequest	stHttpReq;
	TopHttpResponse	stHttpRsp;
	int             llResult;

    long            lBeginTime=0, lEndTime=0;   /** add by feng'an 20110228. **/
    struct tms      tTMS;                       /** add by feng'an 20110228. **/
	
	memset(&stHttpReq, 0x00, sizeof(stHttpReq));
	memset(&stHttpRsp, 0x00, sizeof(stHttpRsp));
	
	Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "SoapCall Start");	
	
	/* ����SOAP����ʵ�� --B */
	Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ExportXmlTree Start");	
	llResult = TOP_ExportXmlTree(env->reqxmlDoc, env->reqxmlBuffer, sizeof(env->reqxmlBuffer));
	if (llResult) 
    {
		Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Call TOP_ExportXmlTree() Error!");	
		return (-1);
	}
	Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ExportXmlTree End");	

	HtSprintf(stHttpReq.sReqBody, "%s", env->reqxmlBuffer);
	
	env->soapStatus = _SOAP_STATUS_SEND;
	
	/* SOAP BINDING httpv1.1 Э�� --B*/
	Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopHttpCall Start");	

    lBeginTime = times( &tTMS); /** add by feng'an 20110228. **/

	cRet = TopHttpCall(sSoapCfgName, &stHttpReq, &stHttpRsp);

    lEndTime = times( &tTMS); /** add by feng'an 20110228. **/
    HtLog (sTopSoapClientLogName, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, "TopHttpCall %s processed, used %ld ticks",
        sSoapCfgName, lEndTime - lBeginTime); /** add by feng'an 20110228. **/

	Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopHttpCall End[Ret=%d]", cRet);	
	if (cRet)
    {
        	Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopHttpCall() Failed ");	
        	return (-1);
    }
    env->soapStatus = _SOAP_STATUS_RECV;
    HtSprintf(env->respxmlBuffer, "%s", stHttpRsp.sRspBody);
       
	/*�ͻ�������*/
	Http_Replace(env->respxmlBuffer);
	Http_Variety(env->respxmlBuffer);

    /* ����SOAPӦ��ʵ�� --B*/
    env->httpStatus = stHttpRsp.stRspHead.iHttpStatus;
	HtSprintf(env->httpStatusDesc, "%s", stHttpRsp.stRspHead.sHttpStatusDesc);
	
	if (env->httpStatus == 200)
    {
		env->soapStatus = _SOAP_STATUS_SUCC;
	}
    else
    {
		env->soapStatus = _SOAP_STATUS_FAIL;
	}
	
	if (isAutoParseRsp && strlen(env->respxmlBuffer) > 0)
    {
		Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ImportXMLTree  Start");
	    if (TOP_ImportXMLTree(env->respxmlDoc, env->respxmlBuffer, strlen(env->respxmlBuffer)))
        {							
			Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_ImportXMLTree  error");
			return (-1);
		}
		Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ImportXMLTree  Success");

		/*TEST*/		
		TOP_PrintXmlTree(env->respxmlDoc);

		memset(env->respRootNS, 0x00, sizeof(env->respRootNS));
		memset(env->respEnvePath, 0x00, sizeof(env->respEnvePath));
		memset(env->respBodyPath, 0x00, sizeof(env->respBodyPath));
		memset(env->respFaultPath, 0x00, sizeof(env->respFaultPath));
		
		memset(tmpBuf, 0x00, sizeof(tmpBuf));
		HtSprintf(tmpBuf, "%s", env->respxmlDoc->root->name);
		pTmpED = strstr(tmpBuf, ":");
		if (pTmpED == NULL)
        {
			return (-1);	
		}
		
		HtMemcpy(env->respRootNS, tmpBuf, pTmpED - tmpBuf);
		HtSprintf(env->respEnvePath,"%s:Envelope", env->respRootNS);
		HtSprintf(env->respBodyPath,"%s/%s:Body", env->respEnvePath, env->respRootNS);
		
		memset(tmpBuf, 0x00, sizeof(tmpBuf));
		HtSprintf(tmpBuf,"<%s:Fault>",env->respRootNS);
		
		pTmpST = strstr(env->respxmlBuffer, tmpBuf);
		if (pTmpST != NULL)
        {
			env->soapStatus = _SOAP_STATUS_FAIL;
			HtSprintf(env->respFaultPath, "%s/%s:Fault", env->respBodyPath, env->respRootNS);
		}
	}
	Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "SoapCall End");	
	SoapTrace(env);
	return 0;
}


/** add by feng'an 20101217 begin. **/
/********************************
 ** ��ȡ�����ռ������
 ** flag: --- in 
 **    1-�����ĵ�Body�����ռ�
 **    2-��Ӧ���ĵ�Body�����ռ�
 ** sNameSpace: --- out
 **    ���������ռ�ֵ
 ** sSoapCfgName: --- in
 **    ���������
 *********************************/
int GetNameSpace(int flag, char* sNameSpace, char* sSoapCfgName)
{
    char sTempValue[128];
    char sWebSrvMethod[128];

    memset(sWebSrvMethod, 0x00, sizeof(sWebSrvMethod));
    sprintf(sWebSrvMethod, "%s", sSoapCfgName);

    if (TopSoap_OpenCfgFile(sWebSrvMethod))
    {
        Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSoap_OpenCfgFile  Failed");
        return -1;
    }

    if(flag == TOP_SOAP_REQ_NAME_SPACE)
    {
        if (GetVarietyCfgItem("REQ_NS", &sTempValue))
        {
            Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetVarietyCfgItem(REQ_NS)  Failed");
            Top_CloseCfgFile();
            return (-1);
        }

    }
    else if(flag == TOP_SOAP_RSP_NAME_SPACE)
    {
        if (GetVarietyCfgItem("RSP_NS", &sTempValue))
        {
            Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetVarietyCfgItem(REQ_NS)  Failed");
            Top_CloseCfgFile();
            return (-1);
        }
    }
    else
    {
        Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "err in GetNameSpace - invalid param(flag).");
        return (-1);
    }

    if(Top_CloseCfgFile()){
        Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Top_CloseCfgFile  Failed");
        return -1;
    }


    if(sTempValue[0] == 'Y')
    {
        HtMemcpy(sNameSpace, sTempValue+1, strlen(sTempValue)-1);
        strcat(sNameSpace, ":");
    }
    else if(sTempValue[0] == 'N')
    {
        Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "�������ռ�����ò�����.");
        sNameSpace[0] = '\0';
    }
    else
    {
        Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "err �������ռ�����ò��Ϸ�.");
        return -1;
    }

    return 0;
}
/** end of add by feng'an. **/

/****************add chunbo 20101227**����ֵ���ж�*******************/
/***
 * ��S I W(success      information, warm)
 * Ϊ�ɹ���������Ϊʧ��
 */
int   SoapTypeCheck(const char * sType)
{
    Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Type[%s]", sType);
    if (memcmp(sType, "S", 1) && memcmp(sType, "s", 1) &&
        memcmp(sType, "I", 1) && memcmp(sType, "i", 1) &&
        memcmp(sType, "W", 1) && memcmp(sType, "w", 1))
    {
        Top_HtLog(sTopSoapClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Type  ERRor[%s]", sType);
        return -1;
    }
    return 0;
}
/****************add chunbo 20101227**����ֵ���ж�***end****************/
