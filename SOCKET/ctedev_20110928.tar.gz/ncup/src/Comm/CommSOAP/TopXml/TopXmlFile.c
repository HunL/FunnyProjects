/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "TopSoapInc/TopXml.h"
#include "TopSoapInc/TopHtLog.h"

extern char gsLogFile[32];

/********************************************************************
 * ����XML�ļ�,������һ��XMLTREE
 ********************************************************************/
int TOP_LoadXmlFile(const char *sFileName, TOP_XML_TREE *pXmlTree)
{
	FILE *pXmlFile = NULL;
	char *pXmlContent = NULL;
	int llResult = 0;
	int fileSize = 0;

	/*���ļ�*/
	pXmlFile = fopen(sFileName, "r");
	if (pXmlFile == NULL)
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Call TOP_OpenFile() Error!");
		return (-1);
	}
	
	llResult = fseek(pXmlFile, 0L, SEEK_END);
	if (llResult)
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Call fseek() Error!");
		fclose(pXmlFile);
		return (-1);
	}

	fileSize = ftell(pXmlFile);
	if (fileSize < 0) 
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Call ftell() Error!");
		fclose(pXmlFile);
		return (-1);
	}

	/*�����ڴ�-�����ļ�����*/
	pXmlContent = (char *)malloc(fileSize + 1);
	if (pXmlContent == NULL) 
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Call malloc() Error!");
		fclose(pXmlFile);
		return (-1);
	}

	rewind(pXmlFile);
	
	memset(pXmlContent, 0x00, fileSize + 1);
	llResult = fread(pXmlContent, 1, fileSize, pXmlFile);
	if (llResult < fileSize)
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Call fread() Error! - Read Length less than File Length!");
		fclose(pXmlFile);
		free(pXmlContent);
		return (-1);
	}

	/*�ر��ļ�*/
	fclose(pXmlFile);

	llResult = TOP_ImportXMLTree(pXmlTree, pXmlContent, fileSize);
	if (llResult) 
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Call TOP_ImportXMLTree() Error!");
		free(pXmlContent);
		return (-1);
	}

	/*�ͷ��ڴ�*/
	free(pXmlContent);

	return 0;
}

/*�������Ե�ֵ�������Խڵ�*/
/*
TOP_XML_ATTRI *TOP_XmlSearchNsByHref(TOP_XML_NODE *pNode, char *pAttrValue)
*/
int TOP_XmlSearchNsByHref(TOP_XML_NODE *pNode, char *pAttrValue, char *sDestValue, int nDestLen)
{
	TOP_XML_NODE *pTempNode = NULL;
	TOP_XML_ATTRI *pTempAttr = NULL;
	int llResult = 0;

	pTempAttr = pNode->attri_list;
	while (pTempAttr) 
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Attibute[%X]-name[%s] value[%s].",pTempAttr,pTempAttr->name,pTempAttr->value);
		if (strcmp(pTempAttr->value, pAttrValue) == 0) 
        {
			snprintf(sDestValue, nDestLen, "%s", pTempAttr->name);
			return 0;
		}
		pTempAttr = pTempAttr->next;
	}
	
	pTempNode = pNode->child;
	while (pTempNode) 
    {
		llResult = TOP_XmlSearchNsByHref(pTempNode, pAttrValue, sDestValue, nDestLen);
		if (llResult == 0) 
        {
			return 0;
		}
	}
	
	pTempNode = pNode->next;
	while (pTempNode) 
    {
		llResult = TOP_XmlSearchNsByHref(pTempNode, pAttrValue, sDestValue, nDestLen);
		if (llResult == 0)
        {
			return 0;
		}
	}
	
	return (-1);
}

TOP_XML_NODE *TOP_XmlGetNodeByPathAttr(TOP_XML_TREE *pXmlTree, char *sNodePath, char *sAttrName, char *sAttrValue)
{

	char temp_buf[256];	
	char last_node[256];	
	char *pTempST = NULL, *pTempED = NULL;

    TOP_XML_NODE *pTempNode = NULL;
    TOP_XML_NODE *pTempSubNode = NULL;
    TOP_XML_ATTRI *pTempAttr = NULL;

	pTempST = sNodePath;

	Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"xpath[%s]",sNodePath);

    if ((pTempED = strrchr(pTempST,'/')) != NULL)
    {
		if (pTempED - pTempST ==  strlen(sNodePath)) 
        {
			*pTempED = '\0';
    		if ((pTempED = strrchr(pTempST,'/')) != NULL)
            {
				memset(last_node, 0x00, sizeof(last_node));
				snprintf(last_node, sizeof(last_node), "%s", pTempED + 1);
				*pTempED = '\0';
    		} 
            else 
            {
				Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"xpath[%s] doesnt include '\' .",sNodePath);
				return NULL;
			}
		}
        else
        {
			memset(last_node, 0x00, sizeof(last_node));
			snprintf(last_node, sizeof(last_node), "%s", pTempED + 1);
			*pTempED = '\0';
		}
    }
    else 
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"xpath[%s] doesnt include '\' .",sNodePath);
		return NULL;
	}

	Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"parent node xpath[%s]",sNodePath);
	Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"node name[%s]", last_node);

	pTempNode = TOP_GetXmlNode(pXmlTree, sNodePath);
	if (pTempNode == NULL) 
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Parent Node[%s] Not Exists.", sNodePath);
		return NULL;
	}
	pTempSubNode = pTempNode->child;
	while (pTempSubNode) 
    {
		if (strcmp(pTempSubNode->name, last_node) == 0) 
        {
			
			Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Node addr[%X]", pTempSubNode);
			pTempAttr = pTempSubNode->attri_list;
			while (pTempAttr) 
            {
				if(strcmp(pTempAttr->name, sAttrName) == 0 && strcmp(pTempAttr->value, sAttrValue) == 0)
				{
					Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Node Addr[%X]", pTempSubNode);
					Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Attri Name[%s] Value[%s]",pTempAttr->name,pTempAttr->value);
					Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Node Name[%s]", pTempSubNode->name);
					return pTempSubNode;
				}
				pTempAttr = pTempAttr->next;
			}
		}
		pTempSubNode = pTempSubNode->next;
	}

	return NULL;
}

TOP_XML_NODE *TOP_XmlGetChildNodeByAttr(TOP_XML_NODE *pParentTree, char *sNodeName, char *sAttrName, char *sAttrValue)
{
	char temp_buf[256];	
    TOP_XML_NODE *pTempNode = NULL;
    TOP_XML_ATTRI *pTempAttr = NULL;

	if(pParentTree == NULL) {
		return NULL;	
	}
	pTempNode = pParentTree->child;
	while (pTempNode) 
    {
		if (strcmp(pTempNode->name, sNodeName) == 0)
        {
			pTempAttr = pTempNode->attri_list;
			while (pTempAttr) 
            {
				if(strcmp(pTempAttr->name, sAttrName) == 0 && strcmp(pTempAttr->value, sAttrValue) == 0)
				{
					return pTempNode;
				}
				pTempAttr = pTempAttr->next;
			}
		}
		pTempNode = pTempNode->next;
	}

	return NULL;
}
