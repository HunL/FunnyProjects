/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "TopSoapInc/TopXml.h"
#include "TopSoapInc/TopHtLog.h"

/*���嵱ǰ����״̬*/
#define TOP_XML_IDLE            0	/*����״̬*/
#define TOP_XML_DEFINE          1	/*<?xml*/ 
#define TOP_XML_DEFINE_OTHER    2	/*��<?xml�������������ע��,����Ϊ��<!��ͷ*/ 


/*�ڴ���xml�ڵ������ DFA��״̬*/
#define TOP_XML_NODE_NAME       3	/*�ڴ���xml�ڵ������*/
#define TOP_XML_NODE_NAME_END   4	/*��ת״̬*/
#define TOP_XML_ATTR_NAME       5	/*�ڴ���xml�ڵ����������*/
#define TOP_XML_ATTR_NAME_END   6
#define TOP_XML_ATTR_VAL        7	/*�ڴ���xml�ڵ�����Ե�ֵ*/
#define TOP_XML_ATTR_VAL_END    8	/*��ת״̬*/
#define TOP_XML_NODE_HEAD_END   9	/*����xml�ڵ� ͷ�Ľ���<node_begin ... >*/
#define TOP_XML_NODE_VAL        10	/*����xml�ڵ��ֵ*/
#define TOP_XML_NODE_CDA_VAL    11	/*����xml�ڵ��<![CDATA[ֵ*/
#define TOP_XML_NODE_VAL_END    12	/*����xml�ڵ�Ľڵ�ֵ����  - 200909152313*/
#define TOP_XML_NODE_END        13	/*����xml�ڵ�Ľ���</node_end>*/
#define TOP_XML_NODE_END_1      14	/*����xml�ڵ�Ľ���</node_end>*/
#define TOP_XML_NODE_END_2      15	/*����xml�ڵ�Ľ���</node_end>*/
#define TOP_XML_NODE_END_JMP1   16
#define TOP_XML_NODE_END_JMP2   17
#define TOP_XML_NODE_END_JMP3   18
#define TOP_XML_NODE_END_JMP4   19

#define TOP_XML_COMMENT         20	/*ע�ͽ�(<!-- ... -->)*/
#define TOP_XML_DEF_ELEMENT     21	/*ʵ��������(<!ELEMENT ...>)*/
#define TOP_XML_DEF_DOCTYPE     22	/*�ĵ�������(<!DOCTYPE ...>)*/
#define TOP_XML_DEF_ENTITY      23	/*�ⲿʵ��������(<!ENTITY ...>*/
#define TOP_XML_DEF_NOTATION    24	/*�����ⲿ������(<!NOTATION ...>)*/

/*�����������͵ĺ궨�� - 200909152318*/
#define TOP_XML_ERROR_SUCC       0
#define TOP_XML_ERROR_UNCOMPLETE 1
#define TOP_XML_ERROR_UNVALID    2


#define TOP_HANDLE_NODE_IDLE    0
#define TOP_HANDLE_SUBNODE      1
#define TOP_HANDLE_NEXTNODE     2

#define TOP_FIRST_SUBNODE       0
#define TOP_NOT_FIRST_SUBNODE   1

#define TOP_FIRST_NODEATTR      0
#define TOP_NOT_FIRST_NODEATTR  1

#define NILL  '\x02'
/*����һЩ�ڵ�����*/
#define TOP_TT_ENT  "<"   			/*define normal entity tag*/
#define TOP_TT_XML  "<?xml"  		/*define xml root tag*/
#define TOP_TT_CMT  "<!--"			/*define comments tag*/
#define TOP_TT_ELE  "<!ELEMENT"		/*define data definition element tag*/
#define TOP_TT_CDA  "<![CDATA["		/*define fregment data envelope*/
#define TOP_TT_DOC  "<!DOCTYPE"		/*define xml dtd source*/
#define TOP_TT_EXT  "<!ENTITY"		/*define outside entity*/
#define TOP_TT_NOT  "<!NOTATION"	/*define notation tag*/

#define TOP_XML_VISION_STR    "version"   /*<?xml version='1.0'*/
#define TOP_XML_ENCODING_STR  "encoding"  /*<?xml version='1.0' encoding='GB2312'*/

#define TOP_XML_IGNORE_BLANK      0   /*�ڴ�������ֵʱ�����Կո�����������������ֵ�ɵ����Ż���˫���ż����м��ʱ��*/
#define TOP_XML_NOT_IGNORE_BLANK  1   /*�ڴ�������ֵʱ�������Կո�����TOP_XML_IGNORE_BLANK�������෴*/


/*��ӡxml��ʱ���ӽڵ�����Ŀո���*/
#define TOP_XML_PRINT_GAP_LEN 4

/*<?xml ... ?>��ģ��*/
#define TOP_XML_DEFINE_TEMPLETE "<?xml version=\"%s\" encoding=\"%s\" ?>"


#define _TOP_XML_BUF_SIZE 100*1024


/*����ո�ͬ���*/
static char BlankSign[] = {' ', '?', '\t', '\r', '\n', NILL};
/*
char gsLogFile[32] = "TopXml.log";
*/
extern char gsLogFile[32];

/*Խ��XML�����ڣ��� <?xml ...>*/
static char *_XMLSkipXML(char *szXML)
{
	char *token = szXML + strlen(TOP_TT_XML);
	while (*token != '>' && *token != '\0')
    {
		token ++;
    }
	if (*token == '>')
    {
		return token + 1; /*skip '<'*/
    }
	else
    {
		return token;
    }
}


/*�����ַ��Ƿ��ǿո��*/
static int _IsBlankSign(char ch)
{
	int i = 0;
	while (BlankSign[i] != NILL) 
    {
		if (ch == BlankSign[i])
			return 0;
		i++;
	}
	return -1;
}


/*����<?xml ... ?>������xml���İ汾�ͱ�����Ϣ*/
static int _HandleXmlDefineInf(TOP_XML_TREE *pXmlTree, char *sXmlDefineBuf, int bufLen)
{
	char *ptrDataST  = sXmlDefineBuf;
	char *ptrDataED  = NULL;
	
	pXmlTree->xmlVersion = _TOP_XML_VERSION_1_0;/*DEFAULT*/
	/*��ȡ����*/
	ptrDataED = strstr(sXmlDefineBuf, TOP_XML_ENCODING_STR);
	if (ptrDataED == NULL)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "_HandleXmlDefineInf : Unvalid <?xml Data");
		return (-1);	
	}
	ptrDataST = ptrDataED + strlen(TOP_XML_ENCODING_STR); 
	while ((ptrDataST < sXmlDefineBuf + bufLen) && 
		(_IsBlankSign(*ptrDataST) == 0 || *ptrDataST == '=' || *ptrDataST == '\'' || *ptrDataST == '\"'))
	{
		ptrDataST++;
	}

	if (ptrDataST == sXmlDefineBuf + bufLen)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "_HandleXmlDefineInf : Unvalid <?xml Data");
		return (-1);	
	}

	ptrDataED = ptrDataST;
	while ((ptrDataED < sXmlDefineBuf + bufLen) && _IsBlankSign(*ptrDataED) != 0 
			&& *ptrDataED != '?' && *ptrDataED != '\'' && *ptrDataED != '\"')
	{
		ptrDataED++;
	}

	if (ptrDataED == sXmlDefineBuf + bufLen)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "_HandleXmlDefineInf : Unvalid <?xml Data");
		return (-1);	
	}
	if (memcmp(ptrDataST, "UTF-8", ptrDataED - ptrDataST) == 0)
    {
		pXmlTree->xmlEncoding = _TOP_XML_ENCODEING_UTF8;
	} 
    else if (memcmp(ptrDataST, "GB2312", ptrDataED - ptrDataST) == 0)
    {
		pXmlTree->xmlEncoding = _TOP_XML_ENCODEING_GB2312;
	}
	return 0;
}
/*����һ���ڴ�*/
char *_MallocMemory(int size)
{
	return (char *)malloc(size);
}
/*�ͷ��ڴ�*/
void _FreeMemory(char *memHandle)
{
	free(memHandle);
}

/**********************************************************
 * 	����XML��
 * 	�����Ƽ��Ļ�ȡ��ʽ��������destroy��ʱ��ͬʱ���ͷ��ڴ�
 **********************************************************/
TOP_XML_TREE *TOP_InitXMLTree()
{
	TOP_XML_TREE *pTree = (TOP_XML_TREE *)_MallocMemory(sizeof(TOP_XML_TREE));
	if (pTree == NULL)
    {
		return NULL;	
	}
	pTree->xmlVersion  = _TOP_XML_VERSION_1_0;
	pTree->xmlEncoding = _TOP_XML_ENCODEING_UTF8;
	pTree->root = NULL;
	return  pTree;
}

/********************************************************************
 * 	���ٵ�ǰ����
 ********************************************************************/
void TOP_DestroyXmlNodeAttr(TOP_XML_ATTRI *pAttri)
{
	if (pAttri != NULL)
    {
		_FreeMemory((char *)pAttri);
	}
	pAttri = NULL;
}

/********************************************************************
 *	���ٵ�ǰ�ڵ�
 ********************************************************************/
void TOP_DestroyXmlNode(TOP_XML_NODE *pXmlNode)
{
	
	TOP_XML_ATTRI *pAttri = NULL;
	TOP_XML_ATTRI *pNextAttri = NULL;
	TOP_XML_NODE  *pTmpNode = NULL;
	TOP_XML_NODE  *pNextNode = NULL;
	
	if (pXmlNode == NULL) 
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"TOP_DestroyXmlNode : pointer of Node is NULL!");
		return;
	}
	pAttri = pXmlNode->attri_list;
    /*	�������� */
	while (pAttri != NULL) 
    {
		pNextAttri = pAttri->next;
		/*
		Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Destroy Attribute[%s] Of Node[%s]",pAttri->name,pXmlNode->name);
		*/
		TOP_DestroyXmlNodeAttr(pAttri);
		pAttri = pNextAttri;
	}
    /*	�����ӽڵ� */
	pTmpNode = pXmlNode->child;
	
	while (pTmpNode != NULL)
    {
		pNextNode = pTmpNode->next;
		/*
		Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Destroy ChildNode[%s] Of Node[%s]",pTmpNode->name,pXmlNode->name);
		*/
		TOP_DestroyXmlNode(pTmpNode);
		pTmpNode = pNextNode;
	}
	_FreeMemory((char *)pXmlNode->value);
	_FreeMemory((char *)pXmlNode);
	pXmlNode = NULL;

}

/********************************************************************
 *	����XML��
 ********************************************************************/
void TOP_DestroyXmlTree(TOP_XML_TREE *pXmlTree)
{
	Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Func : TOP_DestroyXmlTree Start..." );
	if (pXmlTree == NULL) 
    {
		Top_HtLog(gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"pXmlTree = NULL");
		return;
	}

    /* �������еĽڵ� */
	Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Destroy All Nodes Of Tree.");
	if (pXmlTree->root != NULL)
	{
		TOP_DestroyXmlNode(pXmlTree->root);
	}
    /* �������� */
	Top_HtLog(gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Destroy Tree Itself.");
	_FreeMemory((char *)pXmlTree);

}

/*�������ƴ����ڵ�*/
TOP_XML_NODE *TOP_CreateXmlNode(char *sNodeName, int nodeNameLen)
{
	TOP_XML_NODE *pXmlNode = NULL;
	
	pXmlNode = (TOP_XML_NODE *)_MallocMemory(sizeof(TOP_XML_NODE));
	if (pXmlNode == NULL)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "_MallocMemory(TOP_XML_NODE) Failed");
		return NULL;	
	}
	memset(pXmlNode, 0x00, sizeof(TOP_XML_NODE));
	HtMemcpy(pXmlNode->name, sNodeName, nodeNameLen);
	pXmlNode->value_type = TOP_XML_NODE_VALUE_TYPE_COMMON;
	/*
	memset(pXmlNode->value, 0x00, sizeof(pXmlNode->value));
	*/
	pXmlNode->value = NULL;
	pXmlNode->value_len = 0;
	pXmlNode->attri_list = NULL;
	pXmlNode->parent = NULL;
	pXmlNode->child = NULL;
	pXmlNode->pre = NULL;
	pXmlNode->next = NULL;
	
	return pXmlNode;
}

/***************************************************
 * Ϊ�ڵ����ýڵ�ֵ
 * Add By Brady.Lee @ 20091111
 * �޸Ĵ˺���-���ӽڵ�ֵ���� 2010-05-17
 ***************************************************/
int TOP_SetXmlNodeValue(TOP_XML_NODE *pXmlNode, int nNodeValueType, char *sNodeValue, int nNodeValueLen)
{
	if (nNodeValueType == TOP_XML_NODE_VALUE_TYPE_COMMON) 
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Xml Node Value Type - TOP_XML_NODE_VALUE_TYPE_COMMON");
	}
    else if(nNodeValueType == TOP_XML_NODE_VALUE_TYPE_CDATA)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Xml Node Value Type - TOP_XML_NODE_VALUE_TYPE_CDATA");
	} 
    else
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Undefined Xml Node Value Type[%d]!!!", nNodeValueType);
		return (-1);
	}

	pXmlNode->value_type = nNodeValueType;
	
	if ((pXmlNode->value == NULL) || (pXmlNode->value_len < nNodeValueLen + 1))
	{
		if(pXmlNode->value != NULL)
		{
			_FreeMemory((char *)pXmlNode->value);
			pXmlNode->value = NULL;
			pXmlNode->value_len = 0;
		}
		pXmlNode->value = _MallocMemory(nNodeValueLen + 1);
		if(pXmlNode->value == NULL)
		{
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "_MallocMemory for node value Failed");
			return (-1);
		}
		pXmlNode->value_len = nNodeValueLen + 1;
	}
	
	memset(pXmlNode->value, 0x00, pXmlNode->value_len);
	HtMemcpy(pXmlNode->value, sNodeValue, nNodeValueLen);
	
	return 0;
}

/*�������ƴ����ڵ�*/
TOP_XML_ATTRI *TOP_CreateXmlNodeAttr(char *sNodeAttrName, int attrNameLen)
{
	TOP_XML_ATTRI *pXmlNodeAttr = NULL;
	
	pXmlNodeAttr = (TOP_XML_ATTRI *)_MallocMemory(sizeof(TOP_XML_ATTRI));
	if(pXmlNodeAttr == NULL)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "_MallocMemory(TOP_XML_ATTRI) Failed");
		return NULL;	
	}
	memset(pXmlNodeAttr, 0x00, sizeof(TOP_XML_ATTRI));
	HtMemcpy(pXmlNodeAttr->name, sNodeAttrName, attrNameLen);
	pXmlNodeAttr->pre = NULL;
	pXmlNodeAttr->next = NULL;
	
	return pXmlNodeAttr;
}

/**********************************************************
 * 	�����ڴ���XML��ʽ���ַ��������XML TREE������
 **********************************************************/
int TOP_ImportXMLTree(TOP_XML_TREE *pXmlTree, char *xmlDataBuf, int xmlBufLen)
{
	
	char          *ptrXmlData = xmlDataBuf;
	char          *ptrDataST  = NULL;
	char          *ptrDataED  = NULL;
	int           i           = 0;
	char          *tmpChar    = NULL;
	int           preXmlStatus  = TOP_XML_IDLE;
	int           currXmlStatus = TOP_XML_IDLE;
	
	TOP_XML_ATTRI *pstNodePreAttr    = NULL;	/*��ǰ���Ե�ǰһ������*/
	TOP_XML_ATTRI *pstNodeAttr       = NULL;	/*��ǰ����*/
	
	TOP_XML_NODE  *pstParentNode     = NULL;	/*���ڵ�*/
	TOP_XML_NODE  *pstPreNode        = NULL;	/*ǰһ���ڵ�*/
	TOP_XML_NODE  *pstNode           = NULL;	/*��ǰ�ڵ�*/
	int           handle_node        = TOP_HANDLE_NODE_IDLE;
	int           first_subnode	     = TOP_FIRST_SUBNODE;
	int           first_attr         = TOP_FIRST_NODEATTR;
	
	int           attrIgnoreBlank    = TOP_XML_NOT_IGNORE_BLANK;/*Ĭ��Ϊ�����Կո�*/
	char          sTempBuf[1024];
	
	/*Added By Brady.Lee @ 20090913 ��ƥ��Ľڵ�����*/
	char          sMatchingNodeName[_TOP_XML_NODE_NAME_LEN + 1];
	
	Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Func: TOP_ImportXMLTree Start...");
	/*
	Top_HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, xmlDataBuf, xmlBufLen);
	Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "xmlDataBuf[Len:%d][Content:%s]", xmlBufLen, xmlDataBuf);
	*/
	memset(sMatchingNodeName, 0x00, sizeof(sMatchingNodeName));
	
	while (i < xmlBufLen && ptrXmlData[i] != '\0')
    {
		/*
		Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "xmlDataBuf[%d][%c]", i, ptrXmlData[i]);
		*/
		tmpChar = &ptrXmlData[i];
		switch (currXmlStatus)
        {
			case TOP_XML_IDLE: /*����״̬*/
				/*
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TOP_XML_IDLE"); 
				*/
				if (_IsBlankSign(*tmpChar) == 0)
                { /*�ǿհ׷�*/
					i++;
					continue;
				}
				if (*tmpChar == '<')
                {
					if (*(tmpChar+1) == '?')
                    {
						currXmlStatus = TOP_XML_DEFINE;	
					}
                    else if (*(tmpChar+1) == '!')
                    {/*����Ҫ��˵��*/
						i += 2; /*����<!֮��*/
						currXmlStatus = TOP_XML_DEFINE_OTHER;	
					}
                    else if (*(tmpChar+1) == '/')
                    { /*�ڵ����*/
						if (strlen(sMatchingNodeName) <= 0) 
                        {
							Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "XML DOCUMENT UNVALID!!!");
							memset(sTempBuf, 0x00, sizeof(sTempBuf));
							snprintf(sTempBuf, sizeof(sTempBuf), "%s", tmpChar);
							Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "%s", sTempBuf);
							return (-1);
						}
						currXmlStatus = TOP_XML_NODE_END;
						
					} 
                    else
                    {
						ptrDataST = NULL;
						ptrDataED = NULL;
						i++;
						currXmlStatus = TOP_XML_NODE_NAME;
					}
				}
                else 
                {
					if (pstNode != NULL && preXmlStatus == TOP_XML_COMMENT)
                    {
						/*Ϊ�ڵ�����--������ ע�ͺ���  ���Žڵ������*/
						ptrDataST = NULL;
						ptrDataED = NULL;
						currXmlStatus = TOP_XML_NODE_HEAD_END;
					}
                    else 
                    {
						/*ת�򱨴��ڵ�*/
						Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "XML DOCUMENT UNVALID!!!");
						memset(sTempBuf, 0x00, sizeof(sTempBuf));
						snprintf(sTempBuf, sizeof(sTempBuf), "%s", tmpChar);
						Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "%s", sTempBuf);
						return (-1);
					}
				}
				preXmlStatus = TOP_XML_IDLE;
				break;
			case TOP_XML_DEFINE:/*<?xml*/ 
				/*
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TOP_XML_DEFINE");
				*/
				
				ptrDataST = tmpChar;
				ptrDataED = _XMLSkipXML(ptrDataST);

				memset(sTempBuf, 0x00, sizeof(sTempBuf));
				HtMemcpy(sTempBuf, ptrDataST, ptrDataED - ptrDataST);

				/*
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Xml Define[%s]", sTempBuf);
				*/

				if (_HandleXmlDefineInf(pXmlTree, sTempBuf, ptrDataED - ptrDataST))
                {
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "_HandleXmlDefineInf Error");
					return (-1);
				}
				i += (ptrDataED - ptrDataST);

				currXmlStatus = TOP_XML_IDLE;
				ptrDataST = NULL;
				ptrDataED = NULL;
				preXmlStatus = TOP_XML_DEFINE;
				break;
			
			case TOP_XML_NODE_NAME:/*����xml�ڵ������ --- <��node name֮��û�пո�*/
				if (ptrDataST == NULL)
                {
					ptrDataST = tmpChar;
                }
				
				if (*tmpChar == '<') 
                {
					/*���ķǷ�--�ڵ������г���<*/
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "���ķǷ�--�ڵ������г���'<' !!!");
					return (-1);
				}
				
				/*�ǿհ׷�, ����/>*/
				if (_IsBlankSign(*tmpChar) == 0 || *tmpChar == '>' || (*tmpChar == '/' && *(tmpChar+1) =='>'))
				{ 
					Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ǰ��Match�Ľڵ�Ϊ [%s]", sMatchingNodeName);
					ptrDataED = tmpChar;
					
					/*Added By Brady.Lee @20090916*/
					if (ptrDataED - ptrDataST > _TOP_XML_NODE_NAME_LEN) 
                    {
						/*�ڵ����Ƶĳ��ȴ���Ԥ���õĳ���*/	
						Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ڵ����Ƶĳ���[%d]����Ԥ���õĳ���[%d]", ptrDataED-ptrDataST, _TOP_XML_NODE_NAME_LEN);
						return (-1);
					}
					memset(sMatchingNodeName, 0x00, sizeof(sMatchingNodeName));
					HtMemcpy(sMatchingNodeName, ptrDataST, ptrDataED - ptrDataST);
					/*Added End*/

					/*��ȡnode�����ƣ��������ڵ�*/
					pstNode = TOP_CreateXmlNode(ptrDataST, ptrDataED-ptrDataST);
					if (pstNode == NULL)
                    {
						Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_CreateXmlNode == NULL");
						return (-1);	
					}
					if (handle_node == TOP_HANDLE_NODE_IDLE)
                    {
						if (pstParentNode == NULL)
                        {/*ROOT*/
							pXmlTree->root = pstNode;
						} 
                        else 
                        {
							/*����root�ڵ�*/
							if (pstPreNode == NULL)
                            {
								pstParentNode->child = pstNode;
								pstNode->parent = pstParentNode;
								/*pstPreNode = pstNode;*/
							} 
                            else
                            {
								pstPreNode->next = pstNode;
								pstNode->pre = pstPreNode;
								pstNode->parent = pstParentNode;
							}
						}
					} 
                    else if (handle_node == TOP_HANDLE_SUBNODE)
                    {
						if (first_subnode == TOP_FIRST_SUBNODE)
                        {
							pstParentNode->child = pstNode;
							pstNode->parent = pstParentNode;
							pstPreNode = pstNode;
							first_subnode = TOP_NOT_FIRST_SUBNODE;
						}
                        else 
                        {
							pstPreNode->next = pstNode;
							pstNode->pre = pstPreNode;
							pstNode->parent = pstParentNode;
						}
					} 
                    else if (handle_node == TOP_HANDLE_NEXTNODE)
                    {
						pstPreNode->next = pstNode;
						pstNode->pre = pstPreNode;
						pstNode->parent = pstParentNode;
					}
					
					i++;

					if (_IsBlankSign(*tmpChar) != 0)
                    {/*���������£��϶�û������*/
						if (*tmpChar == '>')
                        {
							currXmlStatus = TOP_XML_NODE_HEAD_END;
						}
                        else
                        {
							/* sadfds />*/
							currXmlStatus = TOP_XML_NODE_END;
						}
					} 
                    else 
                    {
						currXmlStatus = TOP_XML_NODE_NAME_END;/*��ת״̬*/
					}
					ptrDataST = NULL;
					ptrDataED = NULL;
				} 
                else
                {
					if (ptrDataST == NULL)
                    {
						ptrDataST = tmpChar;
                    }
					i++;
				}
				preXmlStatus = TOP_XML_NODE_NAME;
				break;
			case TOP_XML_NODE_NAME_END:    /*��ת״̬*/
				/*
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TOP_XML_NODE_NAME_END");
				*/
				if (_IsBlankSign(*tmpChar) == 0)
                { /*�ǿհ׷�*/
					i++;
					continue;
				}
				if (*tmpChar == '>')
                {
					currXmlStatus = TOP_XML_NODE_HEAD_END;
				}
                else if (*tmpChar == '/' && *(tmpChar+1) == '>')
                {
					currXmlStatus = TOP_XML_NODE_END;
				}
                else
                {
					currXmlStatus = TOP_XML_ATTR_NAME;
				}
				preXmlStatus = TOP_XML_NODE_NAME_END;
				ptrDataST = NULL;
				ptrDataED = NULL;
				break;
			case TOP_XML_ATTR_NAME:/*�����˽ڵ����������*/
				if (ptrDataST == NULL)
                {
					ptrDataST = tmpChar;
                }
				
				if (*tmpChar == '<')
                {
					/*���ķǷ�--���������г���<*/
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "���ķǷ�--���������г��� '<' !!!");
					return (-1);
				}
				
				if (*tmpChar == '>') 
                {
					/*���ķǷ�--���������г���>*/
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "���ķǷ�--���������г��� '>' !!!");
					return (-1);
				}
				
				if (_IsBlankSign(*tmpChar) != 0 && *tmpChar != '=')
                { 
					i++;	
					continue;
				}
				/*��ȡ������*/	
				ptrDataED = tmpChar;
				
				/*Added By Brady.Lee @20090916*/
				if (ptrDataED-ptrDataST > _TOP_XML_ATTR_NAME_LEN) 
                {
					/*�������Ƶĳ��ȴ���Ԥ���õĳ���*/	
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�������Ƶĳ���[%d]����Ԥ���õĳ���[%d]", ptrDataED-ptrDataST, _TOP_XML_ATTR_NAME_LEN);
					return (-1);
				}
				/*Added End*/
				
				pstNodeAttr = TOP_CreateXmlNodeAttr(ptrDataST, ptrDataED - ptrDataST);
				if (first_attr == TOP_FIRST_NODEATTR)
                {
					pstNode->attri_list = pstNodeAttr;
					first_attr = TOP_NOT_FIRST_NODEATTR;
				}
                else
                {
					pstNodePreAttr->next = pstNodeAttr;
					pstNodeAttr->pre = pstNodePreAttr;
				}

				pstNodePreAttr = pstNodeAttr;
				ptrDataST = NULL;
				ptrDataED = NULL;
				currXmlStatus = TOP_XML_ATTR_NAME_END;
				preXmlStatus = TOP_XML_ATTR_NAME;
				break;
			case TOP_XML_ATTR_NAME_END:/*��ת״̬��������������ȡ��ɺ���ƺ���*/
				if (_IsBlankSign(*tmpChar) == 0 || *tmpChar == '=')
                { 		
					i++;
					continue;
				}
				ptrDataST = NULL;
				ptrDataED = NULL;
				currXmlStatus = TOP_XML_ATTR_VAL;
				preXmlStatus = TOP_XML_ATTR_NAME_END;
				break;
				
			case TOP_XML_ATTR_VAL:
				/*�����Ż�˫�����ڵĿո���������*/
				/*���˵������Ż���˫����*/
				if (ptrDataST == NULL)
                {
					if ((*tmpChar == '\'' && *(tmpChar+1) == '\'') || (*tmpChar == '"' && *(tmpChar+1) == '"'))
					{ 
						/*���Ե�ֵΪ��*/
                		ptrDataST = NULL;
						ptrDataED = NULL;
						attrIgnoreBlank == TOP_XML_NOT_IGNORE_BLANK;
						currXmlStatus = TOP_XML_ATTR_VAL_END;/*��ת״̬*/
						preXmlStatus = TOP_XML_ATTR_VAL;
						i+=2;	
						continue;
					} 

					if (tmpChar[0] == '\''  || tmpChar[0] == '"') 
                    {
						attrIgnoreBlank = TOP_XML_IGNORE_BLANK;/*���Կո�*/
						i++;	
						continue;
					}
					ptrDataST = tmpChar;
				}

				if (attrIgnoreBlank == TOP_XML_IGNORE_BLANK)
                {
					if (tmpChar[0] == '<' || tmpChar[0] == '>') 
                    {
						Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ֵ�г��� '<'or'>' !!!");
						return (-1);
					}

					if ((tmpChar[0] != '\'' && tmpChar[0] != '"'))
                    {
						i++;	
						continue;
					} 
				} 
                else if (attrIgnoreBlank == TOP_XML_NOT_IGNORE_BLANK)
                {
					if (tmpChar[0] == '<')
                    {
						Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ֵ�г��� '<' !!!");
						return (-1);
					}

					if (_IsBlankSign(*tmpChar) != 0)/*���ǿո�*/
					{
						if (tmpChar[0] == '>') 
                        {
							/*����ֵ����*/
							i--;
						}
                        else
                        {
							i++;	
							continue;
						}
					}
				}
				i++;
				/*��ȡ����ֵ*/	
				ptrDataED = tmpChar;
				if (ptrDataED - ptrDataST > _TOP_XML_ATTR_VALUE_LEN)
                {
					Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����ֵ�ĳ���[%d]���� Ԥ���趨�ĳ���[%d]!", ptrDataED - ptrDataST, _TOP_XML_ATTR_VALUE_LEN);
					return (-1);
				}
				HtMemcpy(pstNodeAttr->value, ptrDataST, ptrDataED - ptrDataST);
				/*
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 
						"Attribute(%s:%s) For Node[%s]", pstNodeAttr->name, pstNodeAttr->value, pstNode->name);
				*/
				ptrDataST = NULL;
				ptrDataED = NULL;
				attrIgnoreBlank == TOP_XML_NOT_IGNORE_BLANK;
				currXmlStatus = TOP_XML_ATTR_VAL_END;/*��ת״̬*/
				preXmlStatus = TOP_XML_ATTR_VAL;
				break;
			case TOP_XML_ATTR_VAL_END:/*��ת״̬*/
				/*
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TOP_XML_ATTR_VAL_END");
				*/
				if (_IsBlankSign(*tmpChar) == 0)
                {
					i++;
					continue;
				} 			
				/*
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "-------");
				*/
				if (*tmpChar == '>')
                {
					currXmlStatus = TOP_XML_NODE_HEAD_END;
					i++;
				}
                else if ( *tmpChar == '/' && *(tmpChar+1) == '>' )
                {
					/*�˽ڵ����*/
					currXmlStatus = TOP_XML_NODE_END;					
				}
                else 
                {
					currXmlStatus = TOP_XML_ATTR_NAME;
				}

				preXmlStatus = TOP_XML_ATTR_VAL_END;
				break;
			case TOP_XML_NODE_HEAD_END:
				if (_IsBlankSign(*tmpChar) == 0)
                {
					i++;
					continue;
				}

				first_attr = TOP_FIRST_NODEATTR;

				if (*tmpChar == '<')
                {
					if (*(tmpChar+1) == '/')
                    {/*�˽ڵ����*/
						currXmlStatus = TOP_XML_NODE_END;
					} 
                    else if (*(tmpChar+1) == '!')
                    {/*�ڵ����ݣ�������<!CDATA[��������*/
						i+=2;
						currXmlStatus = TOP_XML_DEFINE_OTHER;
					} 
                    else 
                    {
						/*�ӽڵ�---��������*/
						handle_node = TOP_HANDLE_SUBNODE;
						first_subnode = TOP_FIRST_SUBNODE;
						pstParentNode = pstNode;
						pstNode = NULL;
						pstPreNode = NULL;
						i++;
						currXmlStatus = TOP_XML_NODE_NAME;
					}
				}
                else
                {/*�ڵ�ֵ*/
					currXmlStatus = TOP_XML_NODE_VAL;
				}
				preXmlStatus = TOP_XML_NODE_HEAD_END;
				break;
				
			case TOP_XML_NODE_VAL:
				if (ptrDataST == NULL)
                {
					ptrDataST = tmpChar;
                }
									
				if (*tmpChar == '<') 
				{
					if (*(tmpChar+1) == '/')
                    {
						ptrDataED = tmpChar;
						pstNode->value_type = TOP_XML_NODE_VALUE_TYPE_COMMON;
						/*
						HtMemcpy(pstNode->value, ptrDataST, ptrDataED-ptrDataST);
						*/
						if (TOP_SetXmlNodeValue(pstNode, pstNode->value_type, ptrDataST, ptrDataED-ptrDataST)) 
						{
							Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TOP_SetXmlNodeValue() Failed!");
							return (-1);
						}
						ptrDataST = NULL;
						ptrDataED = NULL;
						currXmlStatus = TOP_XML_NODE_VAL_END;
					}
                    else 
                    {
						/*���ķǷ�--�ڵ�ֵ�г���<*/
						Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "���ķǷ�--�ڵ�ֵ�г���'<' !!!");
						return (-1);
					}
				}
                else 
                {
					i++;
					continue;				
				}
				preXmlStatus = TOP_XML_NODE_VAL;
				break;
			case TOP_XML_NODE_CDA_VAL:
				if (ptrDataST == NULL)
                {
					ptrDataST = tmpChar;
                }
				if (*tmpChar == ']' && *(tmpChar + 1) == ']' && *(tmpChar + 2) == '>')
				{
					ptrDataED = tmpChar;
					pstNode->value_type = TOP_XML_NODE_VALUE_TYPE_CDATA;
					/*
					HtMemcpy(pstNode->value, ptrDataST, ptrDataED-ptrDataST);
					*/
					if (TOP_SetXmlNodeValue(pstNode, pstNode->value_type, ptrDataST, ptrDataED-ptrDataST)) 
					{
						Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TOP_SetXmlNodeValue() Failed!");
						return (-1);
					}
					i += 3;/*����]]>*/
					ptrDataST = NULL;
					ptrDataED = NULL;
					currXmlStatus = TOP_XML_NODE_VAL_END;
				}
                else 
                {
					i++;
					continue;	
				}
				preXmlStatus = TOP_XML_NODE_CDA_VAL;
				break;
			
			/*�����ڵ�ֵ�Ľ���*/
			case TOP_XML_NODE_VAL_END:
				/*�����ո�*/
				if (_IsBlankSign(*tmpChar) == 0)
                {
					i++;
					continue;
				}
				/*Ӧ��Ϊ�ڵ����*/
				
				if (*tmpChar != '<')
                {
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DOCUMENT UNVALID(�ڵ�ֵ��Ȼ��Ϊ�ڵ�Ľ�����)");
					memset(sTempBuf, 0x00, sizeof(sTempBuf));
					snprintf(sTempBuf, sizeof(sTempBuf), "%s", tmpChar);
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "%s", sTempBuf);
					return (-1);
				}
				if (*(tmpChar + 1) != '/') 
                {
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DOCUMENT UNVALID(�ڵ�ֵ��Ȼ��Ϊ�ڵ�Ľ�����)");
					memset(sTempBuf, 0x00, sizeof(sTempBuf));
					snprintf(sTempBuf, sizeof(sTempBuf), "%s", tmpChar);
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "%s", sTempBuf);
					return (-1);
				}
				
				currXmlStatus = TOP_XML_NODE_END;
				preXmlStatus = TOP_XML_NODE_VAL_END;
				break;
			case TOP_XML_NODE_END:
				/*<node type='1' />*/
				if (*tmpChar == '/' && *(tmpChar+1) == '>')
				{
					currXmlStatus = TOP_XML_NODE_END_1;
				}
				/*<node type='1'></node>*/ 
				else if(*tmpChar == '<' && *(tmpChar+1) == '/')
				{
					i+=2;/* ����</ */
					currXmlStatus = TOP_XML_NODE_END_2;
				} 
				else 
				{
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DOCUMENT UNVALID�����ܳ��ִ�����,���������������¼�");
					memset(sTempBuf, 0x00, sizeof(sTempBuf));
					snprintf(sTempBuf, sizeof(sTempBuf), "%s", tmpChar);
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "%s", sTempBuf);
					return (-1);
				}
				ptrDataST = NULL;
				ptrDataED = NULL;
				preXmlStatus = TOP_XML_NODE_END;
				break;
			case  TOP_XML_NODE_END_1:
				/*ֱ�Ӱ�ǰһƥ��ڵ�����*/
				memset(sMatchingNodeName, 0x00, sizeof(sMatchingNodeName));
				
				if (pstNode->parent != NULL) 
                {
					snprintf(sMatchingNodeName, sizeof(sMatchingNodeName), "%s", pstNode->parent->name);
				}
				
				i+=2;/*����/>*/
				first_attr = TOP_FIRST_NODEATTR;
				ptrDataST = NULL;
				ptrDataED = NULL;
				currXmlStatus = TOP_XML_NODE_END_JMP1;
				preXmlStatus = TOP_XML_NODE_END_1;
				break;
			case  TOP_XML_NODE_END_2:
				if (_IsBlankSign(*tmpChar) == 0)
                {
					i++;
					continue;
				} 
				if (ptrDataST == NULL)
                {
					ptrDataST = tmpChar;
                }
					
				if (*tmpChar != '>')
				{
					i++;
					continue;
				} 
				ptrDataED = tmpChar;
				memset(sTempBuf, 0x00, sizeof(sTempBuf));
				HtMemcpy(sTempBuf, ptrDataST, ptrDataED-ptrDataST);
				if (memcmp(sMatchingNodeName, ptrDataST, ptrDataED-ptrDataST) != 0) 
				{
					/*��ƥ��*/
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "��ʼ[%s]�����[%s]��ƥ��", sMatchingNodeName, sTempBuf);
					return (-1);
				}
				
				memset(sMatchingNodeName, 0x00, sizeof(sMatchingNodeName));
				if (pstNode->parent != NULL) 
                {
					snprintf(sMatchingNodeName, sizeof(sMatchingNodeName), "%s",pstNode->parent->name);
				}
				
				i++; /*����>*/
				first_attr = TOP_FIRST_NODEATTR;
				ptrDataST = NULL;
				ptrDataED = NULL;
				currXmlStatus = TOP_XML_NODE_END_JMP1;
				preXmlStatus = TOP_XML_NODE_END_2;
				break;
			case TOP_XML_NODE_END_JMP1:/*��ת״̬,�ж��ϼ��ڵ��Ƿ����*/
				if (_IsBlankSign(*tmpChar) == 0)
                {
					i++;
					continue;
				} 
				if (*tmpChar == '<' && *(tmpChar+1) == '/')
                {/*�ϼ��ڵ����*/
					pstNode = pstNode->parent;
					pstParentNode = pstParentNode->parent;
					pstPreNode = pstNode;
					ptrDataST = NULL;
					ptrDataED = NULL;
					i+=2;
					currXmlStatus = TOP_XML_NODE_END_JMP2;
					
				} 
                else if (*tmpChar == '<' && *(tmpChar+1) == '!')
                {
					ptrDataST = NULL;
					ptrDataED = NULL;
					i+=2;
					currXmlStatus = TOP_XML_DEFINE_OTHER;
				} 
				else if (*tmpChar == '<')
                {/*������һ��ƽ���ڵ�*/
					handle_node = TOP_HANDLE_NEXTNODE;
					pstPreNode = pstNode;
					pstNode  = NULL;
					ptrDataST = NULL;
					ptrDataED = NULL;
					i++;
					currXmlStatus = TOP_XML_NODE_NAME;
				}
				else
                {
					/*��������*/
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "XML DOCUMENT UNVALID!�ڵ������������ͨ�ַ�");
					memset(sTempBuf, 0x00, sizeof(sTempBuf));
					snprintf(sTempBuf, sizeof(sTempBuf), "%s", tmpChar);
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "%s", sTempBuf);
					return (-1);
				}
				preXmlStatus = TOP_XML_NODE_END_JMP1;
				break;
			case TOP_XML_NODE_END_JMP2:/*��ת״̬������ϼ��ڵ��������ƺ���*/
				if (ptrDataST == NULL)
                {
					ptrDataST = tmpChar;
				}
				if (*tmpChar != '>')
                {
					i++;
					continue;
				} 
				ptrDataED = tmpChar;
				
				memset(sTempBuf, 0x00, sizeof(sTempBuf));
				HtMemcpy(sTempBuf, ptrDataST, ptrDataED-ptrDataST);
				if (memcmp(sMatchingNodeName, ptrDataST, ptrDataED-ptrDataST) != 0) 
				{
					/*��ƥ��*/
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "�ڵ㿪ʼ[%s]��ڵ����[%s]��ƥ��", sMatchingNodeName, sTempBuf);
					return (-1);
				}
				
				memset(sMatchingNodeName, 0x00, sizeof(sMatchingNodeName));
				if (pstNode->parent != NULL)
                {
					snprintf(sMatchingNodeName, sizeof(sMatchingNodeName), "%s",pstNode->parent->name);
				}
				
				i++;/*ָ��>����ַ�*/
				currXmlStatus = TOP_XML_NODE_END_JMP3;
				preXmlStatus = TOP_XML_NODE_END_JMP2;
				break;
				
			case TOP_XML_NODE_END_JMP3:/*��ת״̬������ϼ��ڵ��������ƺ���*/
				/*�ж��Ƿ�������������*/
				if (_IsBlankSign(*tmpChar) == 0)
                {
					i++;
					continue;
				} 
				if (*tmpChar == '<' && *(tmpChar+1) == '/')
                {/*�����ڵ���������*/
					pstNode = pstNode->parent;
					pstParentNode = pstParentNode->parent;
					pstPreNode = pstNode;
					ptrDataST = NULL;
					ptrDataED = NULL;
					i+=2;
					currXmlStatus = TOP_XML_NODE_END_JMP4;
					
				} 
                else
                {
					currXmlStatus = TOP_XML_IDLE;
				}

				preXmlStatus = TOP_XML_NODE_END_JMP3;
				break;
				
			case TOP_XML_NODE_END_JMP4:
				if (ptrDataST == NULL)
                {
					ptrDataST = tmpChar;
				}

				if (*tmpChar != '>')
                {
					i++;
					continue;
				} 
				
				ptrDataED = tmpChar;
				
				memset(sTempBuf, 0x00, sizeof(sTempBuf));
				HtMemcpy(sTempBuf, ptrDataST, ptrDataED-ptrDataST);
				if (memcmp(sMatchingNodeName, ptrDataST, ptrDataED-ptrDataST) != 0) 
				{
					/*��ƥ��*/
					Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ڵ㿪ʼ[%s]��ڵ����[%s]��ƥ��", sMatchingNodeName, sTempBuf);
					return (-1);
				}

				memset(sMatchingNodeName, 0x00, sizeof(sMatchingNodeName));
				if (pstNode->parent != NULL) 
                {
					snprintf(sMatchingNodeName, sizeof(sMatchingNodeName), "%s",pstNode->parent->name);
				}
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ƥ��Ľڵ�Ϊ[%s].", sMatchingNodeName);
				
				i++;/*ָ��>����ַ�*/
				
				currXmlStatus = TOP_XML_NODE_END_JMP3;
				preXmlStatus = TOP_XML_NODE_END_JMP4;
				break;
				
			case TOP_XML_DEFINE_OTHER:
				if (memcmp(tmpChar, "--", 2) == 0) 
				{
					/*ע�ͽ�(<!-- ... -->)*/
					i += 2;
					currXmlStatus = TOP_XML_COMMENT;
				} 
				else if(memcmp(tmpChar, "ELEMENT", 7) == 0) 
				{
					/*ʵ��������(<!ELEMENT ...>)*/
					i += 7;
					currXmlStatus = TOP_XML_DEF_ELEMENT;
				}
				else if(memcmp(tmpChar, "DOCTYPE", 7) == 0) 
				{
					/*�ĵ�������(<!DOCTYPE ...>)*/
					i += 7;
					currXmlStatus = TOP_XML_DEF_DOCTYPE;
				}
				else if(memcmp(tmpChar, "ENTITY", 6) == 0) 
				{
					/*�ⲿʵ��������(<!ENTITY ...>)*/
					i += 6;
					currXmlStatus = TOP_XML_DEF_ENTITY;
				}
				else if(memcmp(tmpChar, "NOTATION", 8) == 0) 
				{
					/*�����ⲿ������(<!NOTATION ...>)*/
					i += 8;
					currXmlStatus = TOP_XML_DEF_NOTATION;
				}
				else if(memcmp(tmpChar, "[CDATA[", 7) == 0) 
				{
					/*�ڵ�����(<![CDATA[ ...]]>)*/
					i += 7;
					currXmlStatus = TOP_XML_NODE_CDA_VAL;
				}
				else 
				{
					Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "XML DOCUMENT UNVALID!!! - ����ʶ�Ľڵ�[%20s]", tmpChar - 2);
					return (-1);
				}
				preXmlStatus = TOP_XML_DEFINE_OTHER;
				break;
			case TOP_XML_COMMENT:
				/*����ע��,���䲻������*/
				if (*tmpChar == '-' && *(tmpChar + 1) == '-' && *(tmpChar + 2) == '>')
				{
					i += 3;
					currXmlStatus = TOP_XML_IDLE;
				} 
                else 
                {
					i++;
					continue;
				}
				preXmlStatus = TOP_XML_COMMENT;
				break;
			case TOP_XML_DEF_ELEMENT:	/*ʵ��������(<!ELEMENT ...>)*/	
				/*��ʱ��������,���䲻������*/
				if (*tmpChar != '>')
                {
					i++;
					continue;
				}
				i++;
				currXmlStatus = TOP_XML_IDLE;
				preXmlStatus = TOP_XML_DEF_ELEMENT;
				break;
			case TOP_XML_DEF_DOCTYPE:	/*�ĵ�������(<!DOCTYPE ...>)*/
				/*��ʱ��������,���䲻������*/
				if (*tmpChar != '>')
                {
					i++;
					continue;
				}
				i++;
				currXmlStatus = TOP_XML_IDLE;
				preXmlStatus = TOP_XML_DEF_DOCTYPE;
				break;
			case TOP_XML_DEF_ENTITY:	/*�ⲿʵ��������(<!ENTITY ...>*/
				/*��ʱ��������,���䲻������*/
				if(*tmpChar != '>')
                {
					i++;
					continue;
				}
				i++;
				currXmlStatus = TOP_XML_IDLE;
				preXmlStatus = TOP_XML_DEF_ENTITY;
				break;
			case TOP_XML_DEF_NOTATION:	/*�����ⲿ������(<!NOTATION ...>)*/
				/*��ʱ��������,���䲻������*/
				if (*tmpChar != '>')
                {
					i++;
					continue;
				}
				i++;
				currXmlStatus = TOP_XML_IDLE;
				preXmlStatus = TOP_XML_DEF_NOTATION;
				break;
			default:
				Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "״̬[%d]������!!!", currXmlStatus);
				return (-1);
			
		}
	}
	
	/*�ж��Ƿ�������*/
	if (strlen(sMatchingNodeName) > 0) 
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "XML DOCUMENT UNCOMPLETED!!!");
		return (-1);
	}
	
	return 0;
}

static int _ExportXmlNode(TOP_XML_NODE *pXmlNode, char *xmlDataBuf, int xmlBufLen)
{
	char *pTempST = xmlDataBuf;
	char *pTempED = NULL;
	char tempBuf[_TOP_XML_BUF_SIZE];
	char tempBuf2[_TOP_XML_BUF_SIZE];
	int  lastLen = _TOP_XML_BUF_SIZE;
	int  xmlLastLen = xmlBufLen;

	TOP_XML_ATTRI *pstNodeAttr      = NULL;	
	
	if (pXmlNode == NULL)
    {
		return (0);	
	}
	/*Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ڵ�[ %s ]", pXmlNode->name);*/
	memset(tempBuf, 0x00, sizeof(tempBuf));
	snprintf(tempBuf, lastLen, "<%s", pXmlNode->name);
	lastLen -= (1 + strlen(pXmlNode->name));

	if ((pstNodeAttr = pXmlNode->attri_list) != NULL)
    {/*����*/
		do
        {
			memset(tempBuf2, 0x00, sizeof(tempBuf2));
			snprintf(tempBuf2, sizeof(tempBuf2), " %s='%s'", pstNodeAttr->name, pstNodeAttr->value);

			if (lastLen < strlen(tempBuf2)) 
            {
				Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
				return (-1);
			}
			strncat(tempBuf, tempBuf2, lastLen);
			lastLen -= strlen(tempBuf2);
			/*
			HtStrcat(tempBuf, " ");
			HtStrcat(tempBuf, pstNodeAttr->name);
			HtStrcat(tempBuf, "='");
			HtStrcat(tempBuf, pstNodeAttr->value);
			HtStrcat(tempBuf, "'");
			*/
			pstNodeAttr = pstNodeAttr->next;
		}
        while (pstNodeAttr != NULL);
	}
	if (lastLen < 1) 
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
		return (-1);
	}
	strncat(tempBuf, ">", lastLen);
	lastLen--;

	/*Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "�����ڵ�[ %s ]��Head [ %s ]", pXmlNode->name, tempBuf);*/

	if (xmlLastLen < (_TOP_XML_BUF_SIZE - lastLen)) 
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
		return (-1);
	}
	strncat(pTempST, tempBuf, xmlLastLen);
	xmlLastLen -= (_TOP_XML_BUF_SIZE - lastLen);
	
	memset(tempBuf, 0x00, sizeof(tempBuf));
	lastLen = _TOP_XML_BUF_SIZE;
	
	if (pXmlNode->child != NULL)
    {
		/*
		Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "����[%s]���ӽڵ�[%s]", pXmlNode->name, pXmlNode->child->name);
		*/
		if (_ExportXmlNode(pXmlNode->child, tempBuf, lastLen) ) 
        {
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call _ExportXmlNode() Error!");
			return (-1);	
		}
		/*Top_HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "[%s]�ӽڵ������[ %s ]", pXmlNode->name, tempBuf);*/
		
		if (xmlLastLen < strlen(tempBuf)) 
        {
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
			return (-1);	
		}
		strncat(pTempST, tempBuf, xmlLastLen);
		xmlLastLen -= strlen(tempBuf);
	} 
    else
    {
		/*<![CDATA[ ]]>*/
		if (pXmlNode->value_type == TOP_XML_NODE_VALUE_TYPE_CDATA) 
        {
			if (xmlLastLen < strlen(pXmlNode->value) + 12) 
            {
				Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
				return (-1);	
			}
			HtStrcat(pTempST, "<![CDATA[");
			HtStrcat(pTempST, pXmlNode->value);
			HtStrcat(pTempST, "]]>");
			xmlLastLen -= ( strlen(pXmlNode->value) + 12 );
		}
        else
        {
            if(pXmlNode->value != NULL)
            {
                if (xmlLastLen < strlen(pXmlNode->value)) 
                {
                    Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
                    return (-1);	
                }
                strncat(pTempST, pXmlNode->value, xmlLastLen);
                xmlLastLen -= strlen(pXmlNode->value);
            }
		}
	}

	memset(tempBuf, 0x00, sizeof(tempBuf));
	HtSprintf(tempBuf, "</%s>", pXmlNode->name);
	
	if (xmlLastLen < strlen(tempBuf)) 
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
		return (-1);	
	}
	strncat(pTempST, tempBuf, xmlLastLen);
	xmlLastLen -= strlen(tempBuf);
	
	memset(tempBuf, 0x00, sizeof(tempBuf));
	lastLen = _TOP_XML_BUF_SIZE;
	if (pXmlNode->next != NULL)
    {
		if (_ExportXmlNode(pXmlNode->next, tempBuf, lastLen)) 
        {
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call _ExportXmlNode() Error!");
			return (-1);	
		}
		if (xmlLastLen < strlen(tempBuf)) 
        {
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
			return (-1);	
		}

		strncat(pTempST, tempBuf, xmlLastLen);
		xmlLastLen -= strlen(tempBuf);
	} 
	return 0;
}

/**********************************************************
 * 	����XML TREE����������XML��ʽ���ַ�����
 **********************************************************/
int TOP_ExportXmlTree(TOP_XML_TREE *pXmlTree, char *xmlDataBuf, int nXmlBufLen)
{
	char tempBuf[128];
	char tempBuf2[1024];
	int  nLastLen = nXmlBufLen;
	char *pXmlDataBuf = xmlDataBuf;
	
	switch (pXmlTree->xmlEncoding)
    {
		case _TOP_XML_ENCODEING_UTF8:
			memset(tempBuf, 0x00, sizeof(tempBuf));
			HtSprintf(tempBuf, "UTF-8");
			break;
		case _TOP_XML_ENCODEING_GB2312:
			memset(tempBuf, 0x00, sizeof(tempBuf));
			HtSprintf(tempBuf, "GB2312");
			break;
		case _TOP_XML_ENCODEING_GB18030:
			memset(tempBuf, 0x00, sizeof(tempBuf));
			HtSprintf(tempBuf, "GB18030");
			break;
		default:
			memset(tempBuf, 0x00, sizeof(tempBuf));
			HtSprintf(tempBuf, "UNDEFINED");
			break;
	}
	memset(tempBuf2, 0x00, sizeof(tempBuf2));
	snprintf(tempBuf2, sizeof(tempBuf2), TOP_XML_DEFINE_TEMPLETE, "1.0", tempBuf);
	
	if (nLastLen < strlen(tempBuf2)) 
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopXml detects Buffer Overflow, Stop Operating.");
		return (-1);	
	}
	strncat(pXmlDataBuf, tempBuf2, nLastLen);
	pXmlDataBuf += strlen(tempBuf2);
	nLastLen -= strlen(tempBuf2);

	return _ExportXmlNode(pXmlTree->root, pXmlDataBuf, nLastLen);
}

/********************************************************************
 *	���ݽڵ�������ͬһ���ϲ�ѯ��Ӧ�ڵ�
 ********************************************************************/
static TOP_XML_NODE *_GetXmlNodeByName(TOP_XML_NODE *pStartXmlNode, char *sNodeName, int iNameLen)
{
	if (pStartXmlNode == NULL)
    {
		return NULL;	
	}
	if (memcmp(pStartXmlNode->name, sNodeName, iNameLen) == 0)
    {
		return pStartXmlNode;
	}
	
	if (pStartXmlNode->next != NULL)
    {
		return _GetXmlNodeByName(pStartXmlNode->next, sNodeName, iNameLen);
	}
    else
    {
		/*���ҽڵ�*/
		return NULL;
	}
} 


/********************************************************************
 * 	����xpath�ݹ���Ҷ�Ӧ�����Ľڵ�
 * 	sXpath --- /curNodeName/...
 ********************************************************************/
static TOP_XML_NODE *_GetXmlNodeByXpath(TOP_XML_NODE *pStartXmlNode, char *sXpath)
{
	char *pTempST = sXpath + 1;/*�ƶ���'/'֮��*/
	char *pTempED = NULL;
	int tokenLen = 0;/*xpath��һ�εĳ���*/
	TOP_XML_NODE *pTempNode = NULL;
	
	if ((pTempED = strchr(pTempST,'/')) == NULL)
    {
		/*��β*/
		pTempED = sXpath + strlen(sXpath);
		return _GetXmlNodeByName(pStartXmlNode, pTempST, pTempED-pTempST+1);
	}
    else
    {
		pTempNode = _GetXmlNodeByName(pStartXmlNode, pTempST, pTempED-pTempST);
		if (pTempNode == NULL)
        {
			return NULL;	
		}
		/*����xpath����һ��[�ݹ�]*/
		return _GetXmlNodeByXpath(pTempNode->child, pTempED);
	}
} 

/********************************************************************
 *	����xpath��ѯ��Ӧ�ڵ�(xpathΪ����·��,��/root/sub1/sub10/...)
 ********************************************************************/
TOP_XML_NODE *TOP_GetXmlNode(TOP_XML_TREE *pXmlTree, char *sNodePath)
{
	char *pTempST = sNodePath;
	char *pTempED = NULL;
	char *tempChar = NULL;
	int i= 0;
	
	if (pXmlTree->root == NULL)
    {
		return NULL;
	}
	return _GetXmlNodeByXpath(pXmlTree->root, sNodePath);
}

/********************************************************************
 *	����xpath��ѯ��Ӧ�ڵ��ֵ(xpathΪ����·��,��/root/sub1/sub10/...)
 ********************************************************************/
char *TOP_GetXmlNodeValue(TOP_XML_TREE *pXmlTree, char *sNodePath)
{
	TOP_XML_NODE *node = NULL;
	
	node = TOP_GetXmlNode(pXmlTree, sNodePath);
	if (node == NULL)
    {
		return NULL;	
	}
	return node->value;
}

/********************************************************************
 *	����xpath����������ѯ��Ӧ�ڵ�Ķ�Ӧ����
 * 	(xpathΪ����·��,��/root/sub1/sub10/...)
 ********************************************************************/
TOP_XML_ATTRI *TOP_GetXmlNodeAttr(TOP_XML_TREE *pXmlTree, char *sNodePath, char *sAttrName)
{
	TOP_XML_NODE  *node = NULL;
	TOP_XML_ATTRI *attr = NULL;
	
	node = TOP_GetXmlNode(pXmlTree, sNodePath);
	
	if (node == NULL)
    {
		return NULL;	
	}
	while ((attr = node->attri_list) != NULL)
    {
		if (strcmp(sAttrName, attr->name) == 0)
        {
			return attr;
        }
	}

	return NULL;
}

/********************************************************************
 *	����xpath����������ѯ��Ӧ�ڵ�Ķ�Ӧ���Ե�ֵ
 * 	(xpathΪ����·��,��/root/sub1/sub10/...)
 ********************************************************************/
int TOP_GetXmlNodeAttrValue(TOP_XML_TREE *pXmlTree, char *sNodePath, char *sAttrName, char *sAttrValue)
{
	TOP_XML_ATTRI *attr = NULL;
	
	attr = TOP_GetXmlNodeAttr(pXmlTree, sNodePath, sAttrName);
	if (attr == NULL)
    {
		return (-1);	
	}
	memset(sAttrValue, 0x00, sizeof(sAttrValue));
	HtSprintf(sAttrValue, "%s", attr->value);
	return 0;
}

/********************************************************************
 * 	����xpath��xml�������ӽڵ�
 * Ҫ��
 * 	[1]xpathΪ����·��,��/root/sub1/sub10/...,
 *		��ȷ��xpathд����/root/sub1/sub2  sub2��Ҫ���ӵĽڵ�
 *	[2]Ҫ���ӵĽڵ�ĸ��ڵ�������
 * 	
 ********************************************************************/
int TOP_AddXmlNode(TOP_XML_TREE *pXmlTree, char *sNodePath, char *sNodeValue)
{
	/*�ҵ���һ���ڵ�
	  ��Ҫ���ӽڵ�/root/sub/sub3, ��Ҫ���ҵ��ڵ�/root/sub
	 */
	TOP_XML_NODE  *node      = NULL;
	TOP_XML_NODE  *preNode   = NULL;
	TOP_XML_NODE  *nodeToAdd = NULL;
	char nodePathBuf[128];
	char *pTemp = NULL;
	int isAddRoot = 0;
	
	
	memset(nodePathBuf, 0x00, sizeof(nodePathBuf));
	HtSprintf(nodePathBuf, "%s", sNodePath);
	
	/*�ڽڵ�path���ҵ����һ��'/'���ֵ�λ��*/
	pTemp = strrchr(nodePathBuf, '/');
	
	if (pTemp == NULL)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "xpath[%s] not correct", sNodePath);
		return (-1);	
	}
	if (pTemp == nodePathBuf)
    {
		if (pXmlTree->root == NULL)
        {
			/*�� ����root�ڵ�*/
			isAddRoot = 1;
		} 
        else
        {
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ظ�����ROOT�ڵ�");
			return (-1);
		}
	}
	
	*pTemp = '\0';
	pTemp++;
	if (!isAddRoot)
    {
		node = TOP_GetXmlNode(pXmlTree, nodePathBuf);
		if (node == NULL)
        {/*���ڵ㲻����*/
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Parent Node [%s] not exist", nodePathBuf);
			return (-1);	
		} 
	}
	nodeToAdd = TOP_CreateXmlNode(pTemp, strlen(pTemp));
	if (nodeToAdd == NULL)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, " TOP_CreateXmlNode [%s] Failed", pTemp);
		return (-1);	
	}
	if (sNodeValue != NULL)
    {
		nodeToAdd->value_type = TOP_XML_NODE_VALUE_TYPE_COMMON;
		/*
		HtSprintf(nodeToAdd->value, "%s", sNodeValue);
		*/
		if(TOP_SetXmlNodeValue(nodeToAdd, nodeToAdd->value_type, sNodeValue, strlen(sNodeValue))) 
		{
			Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TOP_SetXmlNodeValue() Failed!");
			/*���ٿռ� added by brady.lee @ 2010-05-17*/
			TOP_DestroyXmlNode(nodeToAdd);
			return (-1);
		}
	}
	if (isAddRoot)
    {
		pXmlTree->root = nodeToAdd;
		nodeToAdd->parent = NULL;
		nodeToAdd->pre = NULL;
		nodeToAdd->next = NULL;
		nodeToAdd->child = NULL;
	}
    else
    {
		if (node->child != NULL)
        {
			node = node->child;
			do
            {
				preNode = node;
				node = node->next;
			}
            while (node != NULL);
	
			nodeToAdd->parent = preNode->parent;
			preNode->next = nodeToAdd;
			nodeToAdd->pre = preNode;
			nodeToAdd->next = NULL;
			nodeToAdd->child = NULL;
		
		}
        else 
        {
			node->child = nodeToAdd;
			nodeToAdd->parent = node;
			nodeToAdd->pre = NULL;
			nodeToAdd->next = NULL;
			nodeToAdd->child = NULL;
		}
	}
	return 0;
}

/********************************************************************
 * 	����xpath��xml�������ӽڵ������
 * Ҫ��
 * 	[1]xpathΪ����·��,��/root/sub1/sub10/...,
 *		��ȷ��xpathд����/root/sub1/sub2  sub2��Ҫ�������ԵĽڵ�
 *	[2]Ҫ�������ԵĽڵ�������
 * 	
 ********************************************************************/
int TOP_AddXmlNodeAttr(TOP_XML_TREE *pXmlTree, char *sNodePath, char *sAttrName, char *sAttrValue)
{
	TOP_XML_NODE  *node      = NULL;
	TOP_XML_ATTRI *attr      = NULL;
	TOP_XML_ATTRI *preAttr   = NULL;
	TOP_XML_ATTRI *attrToAdd = NULL;
	
	node = TOP_GetXmlNode(pXmlTree, sNodePath);
	if (node == NULL)
    {/*���ڵ㲻����*/
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Parent Node [%s] not exist", sNodePath);
		return (-1);	
	}
	attrToAdd = TOP_CreateXmlNodeAttr(sAttrName, strlen(sAttrName));
	HtSprintf(attrToAdd->value, "%s", sAttrValue);
	
	if (node->attri_list == NULL)
    {
		node->attri_list = attrToAdd;
		attrToAdd->pre = NULL;
		attrToAdd->next = NULL;
	} 
    else
    {
		attr = node->attri_list;
		do
        {
			preAttr = attr;
			attr = attr->next;
		} 
        while (attr != NULL);
		preAttr->next = attrToAdd;
		attrToAdd->pre = preAttr;
	}

	return 0;
}


/*�ݹ��ӡĳ�ڵ㱾������������ӽڵ�*/
void _PrintXmlNode(TOP_XML_NODE *pXmlNode, int level)
{
	char tempBuf[_TOP_XML_BUF_SIZE];
	char sTempBuf[128];
	char *pTemp = tempBuf;
	TOP_XML_ATTRI *pAttr = NULL;
	int i;
	
	if (pXmlNode == NULL)
    {
		return;	
	}
	memset(tempBuf, 0x00, sizeof(tempBuf));
	for (i = 0; i < level * TOP_XML_PRINT_GAP_LEN; i++)
    {
		tempBuf[i] = ' ';	
	}
	HtStrcat(tempBuf, "|--");
	HtStrcat(tempBuf, pXmlNode->name);
	memset(sTempBuf, 0x00, sizeof(sTempBuf));
	snprintf(sTempBuf, sizeof(sTempBuf), "%d", pXmlNode->value_type);
	HtStrcat(tempBuf, "[");
	HtStrcat(tempBuf, sTempBuf);
	HtStrcat(tempBuf, "]");
	HtStrcat(tempBuf, " {");
	if ((pAttr = pXmlNode->attri_list) != NULL)
    {
		do 
        {
			HtStrcat(tempBuf, pAttr->name);
			HtStrcat(tempBuf, "=");
			HtStrcat(tempBuf, pAttr->value);
			HtStrcat(tempBuf, ";");
			pAttr = pAttr->next;
		} 
        while (pAttr != NULL);
	}
	HtStrcat(tempBuf, "}");
	/*��ӡ�˽ڵ����Ϣ*/
/*	Top_HtLogOnlyData (gsLogFile, HT_LOG_MODE_NORMAL, "%s {%s}\n", tempBuf, pXmlNode->value);*mod chunbo 20110125 */
	Top_HtLogOnlyData (gsLogFile, HT_LOG_MODE_DEBUG, "%s {%s}\n", tempBuf, pXmlNode->value);
	
	if (pXmlNode->child != NULL)
    {/*�ݹ��ӽڵ�*/
		_PrintXmlNode(pXmlNode->child, level+1);
	}
	if (pXmlNode->next != NULL)
    {/*�ݹ����Ľڵ�*/
		_PrintXmlNode(pXmlNode->next, level);
	} 
}

void TOP_PrintXmlTree(TOP_XML_TREE *pXmlTree)
{
	if (pXmlTree == NULL)
    {
		return;	
	}
	/*Top_HtLogOnlyData (gsLogFile, HT_LOG_MODE_NORMAL, "===============PRINT XML TREE -B===========\n");
	Top_HtLogOnlyData (gsLogFile, HT_LOG_MODE_NORMAL, "VERSION     : [ 1.0 ] \n");*/
	Top_HtLogOnlyData (gsLogFile, HT_LOG_MODE_DEBUG, "===============PRINT XML TREE -B===========\n");
	Top_HtLogOnlyData (gsLogFile, HT_LOG_MODE_DEBUG, "VERSION     : [ 1.0 ] \n");
	
	switch (pXmlTree->xmlEncoding)
    {
		case _TOP_XML_ENCODEING_UTF8:
			/*Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_NORMAL, "ENCODING    : [ UTF-8 ] \n");*/
			Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_DEBUG, "ENCODING    : [ UTF-8 ] \n");
			break;
		case _TOP_XML_ENCODEING_GB2312:
			/*Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_NORMAL, "ENCODING    : [ GB2312 ] \n");*/
			Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_DEBUG, "ENCODING    : [ GB2312 ] \n");
			break;
		case _TOP_XML_ENCODEING_GB18030:
		    /*	Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_NORMAL, "ENCODING    : [ GB18030 ] \n");*/
			Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_DEBUG, "ENCODING    : [ GB18030 ] \n");
			break;
		default:
			/*Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_NORMAL, "ENCODING    : [ UNKOWN ] \n");*/
			Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_DEBUG, "ENCODING    : [ UNKOWN ] \n");
			break;
			
	}
	/*��ӡ���еĽڵ�*/
	_PrintXmlNode(pXmlTree->root, 0);
	
	/*Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_NORMAL, "===========PRINT XML TREE -E===============\n");*/
	Top_HtLogOnlyData(gsLogFile, HT_LOG_MODE_DEBUG, "===========PRINT XML TREE -E===============\n");
}

/********************************************************************
 *	����xpath��ӡ��ؽڵ������
 * 	(xpathΪ����·��,��/root/sub1/sub10/...)
 ********************************************************************/
void TOP_PrintSingleXmlNode(TOP_XML_TREE *pXmlTree, char *sNodePath)
{
	TOP_XML_NODE  *pXmlNode     = NULL;
	TOP_XML_ATTRI *pXmlNodeAttr = NULL;
	
	pXmlNode = TOP_GetXmlNode(pXmlTree, sNodePath);
	if (pXmlNode == NULL)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_PrintXmlNode Can't Find the Node[%s] ", sNodePath);
	}
	Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "==============TOP_PrintXmlNode[%s] -B==============", sNodePath);
	Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "NAME       : [%s] ", pXmlNode->name);
	Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "VALUE      : [%s] ", pXmlNode->value);
	
	if (pXmlNode->attri_list == NULL)
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ATTRIBUTES : [NONE]");
	} 
    else 
    {
		Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ATTRIBUTES : ");
		pXmlNodeAttr = pXmlNode->attri_list;
		do
        {
			Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[%s]:[%s]", pXmlNodeAttr->name, pXmlNodeAttr->value);	
			pXmlNodeAttr = pXmlNodeAttr->next;
		} 
        while (pXmlNodeAttr != NULL);
	}
	
	Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "PARENT : [%s] ", pXmlNode->parent == NULL ? "NONE" : "YES");
	Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "CHILDS : [%s] ", pXmlNode->child == NULL ? "NONE" : "YES");
	Top_HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "========TOP_PrintXmlNode[%s] -E=========", sNodePath);
}

/*******************************************************************
 * �����ڶ���ƽ̨�Ĳ�ѯ��Ӧ�ڵ������
 * ****************************************************************/
TOP_XML_ATTRI *TOP_GetSmsXmlNodeAttr(TOP_XML_TREE *pXmlTree, char *sNodePath, char *sAttrName)
{
    TOP_XML_NODE *node = NULL;
    TOP_XML_ATTRI *attr = NULL;

    node = TOP_GetXmlNode(pXmlTree, sNodePath);

    if(node == NULL)
    {
        return NULL;
    }
    do
    {
        attr = node->attri_list;
        if(strcmp(attr->value, sAttrName) == 0)
        {

            HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "return attr");
            return attr;
        }
        node = node->next;
    }while(node != NULL);
    return NULL;
}

/*******************************************************************
 * Ϊ����ƽ̨�����XML��ȡ����ֵ 
 *******************************************************************/
int TOP_GetSmsXmlNodeAttrValue(TOP_XML_TREE *pXmlTree, char *sNodePath, char *sAttrName, char *sAttrValue)
{
    TOP_XML_ATTRI *attr = NULL;

    attr = TOP_GetSmsXmlNodeAttr(pXmlTree, sNodePath, sAttrName);
    if(attr == NULL)
    {
        return -1;
    }
    while(attr != NULL)
    {
        if(strcmp(attr->name, "Value") == 0)
        {
            memset(sAttrValue, 0x00, sizeof(sAttrValue));
            HtSprintf(sAttrValue, "%s", attr->value);
            return 0;
        }
        attr = attr->next;
    }
    return -1;
}
