/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopErrCode.h"
#include "TopSoapInc/TopSocket.h"
#include "TopSoapInc/TopHtLog.h"


static char sTopSocketServerLogName[32] = "TopSocketServer.log";

static int 			servSockfd;			/*���������׽���*/ 
static struct sockaddr_in	tServSockAddr;			/*�������˵�ַ*/ 
static int			clientSockfd;			/*�ͻ����׽���*/
static struct sockaddr_in	tClntSockAddr;			/*�ͻ��˵�ַ*/
static int 			nSockAddrLen;

/**����������**/
int TopSocketServerStart(int srvPort, int srvListenNum)
{
	/*Create the socket*/
	if((servSockfd = socket(AF_INET,SOCK_STREAM,0))==-1)
	{
		Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket: CREATE SERVER SOCKET FAILED! [%s]",strerror(errno));
		glTopErrCode = LTOPErrSocketCreate;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", strerror(errno));
		return (-1);
	}
	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "CREATE SERVER SOCKET SUCCESSFULLY...");
	
	/*Initialize the tServSockAddr*/
	/*
	bzero(&tServSockAddr,sizeof(struct sockaddr_in));
	*/
	memset(&tServSockAddr, 0x00, sizeof(struct sockaddr_in));
	tServSockAddr.sin_family = AF_INET;
	tServSockAddr.sin_addr.s_addr =htonl(INADDR_ANY);
	tServSockAddr.sin_port = htons(srvPort);
	
	/*Bind the port*/
	if(bind(servSockfd,(struct sockaddr *)(&tServSockAddr),sizeof(struct sockaddr))==-1)
	{
		Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "bind: BIND PORT[%d] FAILED! [%s]", srvPort, strerror(errno));
		glTopErrCode = LTOPErrSocketBind;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", strerror(errno));
		return (-1);
	}
	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "SERVER BIND PORT[%d] Successfully... ", srvPort);
	
	/*Listen*/
	if(listen(servSockfd, srvListenNum)==-1)
	{
		Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "listen: SERVER LISTEN FAILED! [%s]",strerror(errno));
		glTopErrCode = LTOPErrSocketListen;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", strerror(errno));
		return (-1);
	}
	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "SERVER IS LISTENING... ! ");
	return 0;
}

/**�رշ�����**/
void TopSocketServerStop()
{
	if(servSockfd > 0){
		if(close(servSockfd) == 0){
			Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "SERVER CLOSE SUCCESSFULLY... ! ");
		} else {
			Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "SERVER CLOSE ERROR[%s] ! ", strerror(errno));	
		}
	}
	
}

/**�Ͽ���ͻ��˵�����**/
void TopSocketServerCloseClient()
{
	close(clientSockfd); 
}

/**���ܿͻ������ӣ���������������**/
int TopSocketServerAccept()
{
	nSockAddrLen = sizeof(struct sockaddr_in);
	
	/*
	while((clientSockfd = accept(servSockfd, (struct sockaddr *)(&tClntSockAddr), (socklen_t *)&nSockAddrLen)) == -1);
	*/
	while((clientSockfd = accept(servSockfd, (struct sockaddr *)(&tClntSockAddr), &nSockAddrLen)) == -1);
	
	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ACCEPT A CLIENT[%s]'s CONNECTION...", inet_ntoa(tClntSockAddr.sin_addr));
	
	return clientSockfd;
}

/**
Modified By Brady.Lee @ 20090925 
	�޸ĺ����ķ���ֵ:�ɹ����ؽ��յ��ĳ���;ʧ���򷵻�-1
**/
int TopSocketServerResvMesg(char *pReqMesgBuf, int iMesgLen)
{
	int llResult = 0;
	
	llResult = TopSocketRecvMesg(clientSockfd, pReqMesgBuf, iMesgLen);
	if(llResult < 0){
		Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "RECEIVE THE CLIENT[%s]'s REQUEST MESG FAILED!", inet_ntoa(tClntSockAddr.sin_addr));
		return (-1);	
	}
	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "RECEIVE THE CLIENT[%s]'s REQUEST MESG SUCCESSFULLY!\n%s", inet_ntoa(tClntSockAddr.sin_addr), pReqMesgBuf);
	return llResult;
}	

/**��ͻ��˷�����Ӧ����**/
int TopSocketServerSendMesg(char *pRspMesgBuf, int iMesgLen)
{

	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "===============================SERVER RSPONSE MESG - B===============================");
	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "\n%s\n", pRspMesgBuf);
	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "===============================SERVER RSPONSE MESG - E===============================");

    Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "-----------------need to send buf-----------------");
	Top_HtDebugString(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, pRspMesgBuf, iMesgLen);

	if(TopSocketSendMesg(clientSockfd, pRspMesgBuf, iMesgLen)){
		Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SERVER SEND MESG TO CLIENT[%s] FAILED ", inet_ntoa(tClntSockAddr.sin_addr));
		return (-1);
	}
	Top_HtLog(sTopSocketServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "SERVER SEND MESG TO CLIENT[%s] SUCCESSFULLY ", inet_ntoa(tClntSockAddr.sin_addr));
	return 0;
}

