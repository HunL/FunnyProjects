/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopErrCode.h"
#include "TopSoapInc/TopSocket.h"
#include "TopSoapInc/TopHtLog.h"

static char sTopSocketClientLogName[32] = "TopSocketClient.log";


static int 			clientSockfd;			/*�ͻ����׽���*/ 
static struct sockaddr_in	server_addr;			/*�������˵�ַ*/ 


/**���ͱ���**/
int TopSocketSendMesg(int socketfd, char *pMesgBuf, int iMesgLen)
{
	int	unsendLen,sendLen;
	char	*pBuf = pMesgBuf;
	
	unsendLen = iMesgLen;

	Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "-----------------send buf-----------------");
    Top_HtDebugString(sTopSocketClientLogName, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, pBuf, unsendLen); 

	do{
		if((sendLen = send(socketfd, pBuf, unsendLen, 0)) < 0)
		{
	   		Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "send request to server failed[ERROR: %s]",strerror(errno));
			glTopErrCode = LTOPErrSocketWrite;
			memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
			snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", strerror(errno));
			return (-1);
		}
		pBuf = pBuf + sendLen;
		unsendLen -= sendLen;
	}while(unsendLen > 0);

	return 0;
}

/**
���ձ���
Modified By Brady.Lee @ 20090925 
	�޸ĺ����ķ���ֵ:�ɹ����ؽ��յ��ĳ���;ʧ���򷵻�-1
**/
int TopSocketRecvMesg(int socketfd, char *pMesgBuf, int iMesgLen)
{
	int	    recvLen = 0; 
/*
	Top_HtLog(sTopSocketClientLogName,HT_LOG_MODE_DEBUG,__FILE__,__LINE__, "Require Recv Len[%d]", iMesgLen);
*/

	if((recvLen = recv(socketfd, pMesgBuf, iMesgLen, 0)) < 0)
	{
	    Top_HtLog(sTopSocketClientLogName,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"recv response from server failed[%s]",strerror(errno)); 
		glTopErrCode = LTOPErrSocketRead;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", strerror(errno));
		return (-1); 
	} 

   	Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "recvLen[%d]", recvLen );
    Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "-----------------recv buf-----------------");
    Top_HtDebugString(sTopSocketClientLogName, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, pMesgBuf, recvLen);

	return recvLen;	 
}


int TopSocketClientInit(char *sSvrIpAddr, int nSvrPort)
{
	int  llResult = 0;
	
	Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TopSocketClientInit Start...");
	
	/*��ʼ�� Server�� �ĵ�ַ��Ϣ*/ 
	/*
	bzero(&server_addr,sizeof(struct sockaddr_in)); 
	*/
	memset(&server_addr, 0x00, sizeof(struct sockaddr_in)); 
	server_addr.sin_family = AF_INET; 
	server_addr.sin_addr.s_addr = inet_addr(sSvrIpAddr);

	server_addr.sin_port = htons(nSvrPort); 
	Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[SrvIP  ][%s]", sSvrIpAddr);
	Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[SrvPort][%d]", nSvrPort);
	/*��ʼ��Client��*/ 
	if((clientSockfd = socket(AF_INET,SOCK_STREAM,0))==-1)
	{ 
		Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Socket Error[%s]", strerror(errno));
		glTopErrCode = LTOPErrSocketCreate;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", strerror(errno));

		return (-1); 
	} 
	Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientInit Success");
	
	return 0;
}


/**���ӵ�Server��**/ 
int TopSocketClientConnect()
{
	if(connect(clientSockfd,(struct sockaddr *)&server_addr,sizeof(struct sockaddr))==-1){ 
		Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Connect Error : %s ",strerror(errno));

		switch(errno) {
			case ECONNREFUSED:/*The attempt to connect was forcefully rejected*/
			case ENETUNREACH:/*The network is not reachable from this host*/
			case ETIMEDOUT:/*Connection establishment timed out without establishing a connection.*/
				glTopErrCode = LTOPErrSocketConnOut;
				memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
				snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", strerror(errno));
				break;
			default:
				glTopErrCode = LTOPErrSocketConnIn;
				memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
				snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", strerror(errno));
				break;
		}
		return (-1); 
	}
	Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Connect Success ");
	return 0;
}

int TopSocketClientSendMesg(char *pReqMesgBuf, int iMesgLen)
{
	if(TopSocketSendMesg(clientSockfd, pReqMesgBuf, iMesgLen)){
		Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CLIENT SEND REQUEST MESG FAILED!");
		return (-1);
	}
	Top_HtLog(sTopSocketClientLogName,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"CLIENT SEND REQUEST MESG SUCCSSFULLY...\n%s", pReqMesgBuf);
	return 0;
}

/**
Modified By Brady.Lee @ 20090925 
	�޸ĺ����ķ���ֵ:�ɹ����ؽ��յ��ĳ���;ʧ���򷵻�-1
**/
int TopSocketClientRecvMesg(char *pRspMesgBuf, int iMesgLen)
{
	int llResult = 0;
	/*
	Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TopSocketClientRecvMesg Begin ...");
	*/
	llResult = TopSocketRecvMesg(clientSockfd, pRspMesgBuf, iMesgLen);
	if(llResult < 0){
		Top_HtLog(sTopSocketClientLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CLIENT RESV RESPONSE MESG FAILED!");
		return (-1);
	}
	Top_HtLog(sTopSocketClientLogName,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"CLIENT RESV RESPONSE MESG SUCCSSFULLY...\n%s", pRspMesgBuf);
	return llResult;
}

/**�Ͽ���Server�˵�����**/ 
void TopSocketClientDisConnect()
{
	shutdown(clientSockfd,2);
	close(clientSockfd); 	
}
