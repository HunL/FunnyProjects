#include "TopSoapInc/TopXmlSocket.h"
#include "TopSoapInc/TopHtLog.h"

#include <ctype.h>

extern char sLogName[32];


/*�ж�һ���ַ����Ƿ�Ϊ����*/
int Top_IsDigitStr(char *sDigitStr, int nStrLen)
{
	int i = 0;
	
	for ( i = 0; i < nStrLen; i++) 
	{
		Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Char [%c]", sDigitStr[i]);
		if(isdigit(sDigitStr[i]) == 0) {
			/*����ĸ��Ϊ����*/
			Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "��ĸ[%c]��Ϊ����!", sDigitStr[i]);
			return (-1);
		}
	}
	return 0;
}


/************************************************************************
 * ����XmlSocket������ʵ��
 ************************************************************************/
int CreateXmlSocketEnv(TopXmlSocketEnv *socketEnv)
{
	memset(socketEnv, 0x00, sizeof(TopXmlSocketEnv));
	
	socketEnv->reqxmlDoc = TOP_InitXMLTree();
	if (socketEnv->reqxmlDoc == NULL)
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_InitXMLTree error");
		return (-1);
	}

	socketEnv->respxmlDoc = TOP_InitXMLTree();
	if (socketEnv->respxmlDoc == NULL)
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_InitXMLTree error");
		return (-1);
	}

	return 0;
}

/************************************************************************
 * ����XmlSocket������ʵ��
 ************************************************************************/
void DestoryXmlSocketEnv(TopXmlSocketEnv *socketEnv)
{

	if(socketEnv->reqxmlDoc != NULL)
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DestoryXmlSocketEnv-req[%x]", socketEnv->reqxmlDoc);
		TOP_DestroyXmlTree( socketEnv->reqxmlDoc );
	}
	if(socketEnv->respxmlDoc != NULL)
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DestoryXmlSocketEnv-resp[%x]", socketEnv->respxmlDoc);
		TOP_DestroyXmlTree( socketEnv->respxmlDoc );
	}
}

/************************************************************************
 * ��������XML Tree
 ************************************************************************/
int ClearXmlSocketReqEnv(TopXmlSocketEnv *pSocketEnv)
{
	if(pSocketEnv->reqxmlDoc != NULL)
		TOP_DestroyXmlTree( pSocketEnv->reqxmlDoc );
	pSocketEnv->reqxmlDoc = TOP_InitXMLTree();
	if (pSocketEnv->reqxmlDoc == NULL)
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_InitXMLTree error");
		return (-1);
	}
	return 0;
}

/************************************************************************
 * ������ӦXML Tree
 ************************************************************************/
int ClearXmlSocketRespEnv(TopXmlSocketEnv *pSocketEnv)
{
	if(pSocketEnv->respxmlDoc != NULL)
		TOP_DestroyXmlTree( pSocketEnv->respxmlDoc );
	pSocketEnv->respxmlDoc = TOP_InitXMLTree();
	if (pSocketEnv->respxmlDoc == NULL)
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_InitXMLTree error");
		return (-1);
	}
	return 0;
}

/************************************************************************
 * Ϊ����/��Ӧ�����ӽڵ�
 ************************************************************************/
int TXS_AddElement(TopXmlSocketEnv *env, char *sXmlPath, char *sNodeValue, int iReqOrRsp)
{
	TOP_XML_TREE *pXmlTree = NULL;
	
	if(iReqOrRsp == XML_SOCKET_IO_REQUEST){
		pXmlTree = env->reqxmlDoc;
	} else if(iReqOrRsp == XML_SOCKET_IO_RESPONSE){
		pXmlTree = env->respxmlDoc;
	} else {
		return (-1);	
	}
	if (TOP_AddXmlNode(pXmlTree, sXmlPath, sNodeValue)) {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_AddXmlNode [%s] error", sXmlPath);
		return (-1);	
	}	

	return 0;
}

/************************************************************************
 * Ϊ����/��Ӧ����ĳ���ڵ�����ֵ
 ************************************************************************/
int TXS_SetElementValue(TopXmlSocketEnv *env, char *sXmlPath, char *sElementValue, int iReqOrRsp)
{
	TOP_XML_TREE *pXmlTree = NULL;
	TOP_XML_NODE *pXmlNode = NULL;
	
	if(iReqOrRsp == XML_SOCKET_IO_REQUEST) {
		pXmlTree = env->reqxmlDoc;
	} else if(iReqOrRsp == XML_SOCKET_IO_RESPONSE) {
		pXmlTree = env->respxmlDoc;
	} else {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "iReqOrRsp  Wrong [%d] ", iReqOrRsp);
		return (-1);	
	}

	pXmlNode = TOP_GetXmlNode(pXmlTree, sXmlPath);
	if(pXmlNode == NULL) {
       	Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "Call TOP_GetXmlNode(%s) error", sXmlPath);
		return (-1);	
	}

	if(TOP_SetXmlNodeValue(pXmlNode, pXmlNode->value_type, sElementValue, strlen(sElementValue))) {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TOP_SetXmlNodeValue() Failed!");
		return (-1);
	}

	return 0;	
}

/************************************************************************
 * Ϊ����/��Ӧ����ĳ���ڵ���������
 ************************************************************************/
int TXS_AddElementAttr(TopXmlSocketEnv *env, char *sXmlPath, char *sAttrName, char *sAttrValue, int iReqOrRsp)
{
	TOP_XML_TREE *pXmlTree = NULL;
	
	if(iReqOrRsp == XML_SOCKET_IO_REQUEST){
		pXmlTree = env->reqxmlDoc;
	} else if(iReqOrRsp == XML_SOCKET_IO_RESPONSE){
		pXmlTree = env->respxmlDoc;
	} else {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "iReqOrRsp  Wrong [%d] ", iReqOrRsp);
		return (-1);	
	}
	if(TOP_AddXmlNodeAttr(pXmlTree, sXmlPath, sAttrName, sAttrValue)){
       	Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__,  "TOP_AddXmlNodeAttr [%s] [%s] error", sXmlPath, sAttrName);
		return (-1);	
	}	
	return 0;	
}

/************************************************************************
 * ��ȡ����/��Ӧ����ĳ���ڵ��ֵ
 ************************************************************************/
char *TXS_GetElement(TopXmlSocketEnv *env, char *sXmlPath, int iReqOrRsp)
{
	TOP_XML_TREE *pXmlTree = NULL;
	
	if(iReqOrRsp == XML_SOCKET_IO_REQUEST){
		pXmlTree = env->reqxmlDoc;
	} else if(iReqOrRsp == XML_SOCKET_IO_RESPONSE){
		pXmlTree = env->respxmlDoc;
	} else {
		return NULL;	
	}
	return TOP_GetXmlNodeValue(pXmlTree, sXmlPath);
}

/************************************************************************
 * ��ȡ����/��Ӧ���е�ĳ���ڵ�
 ************************************************************************/
TOP_XML_NODE *TXS_GetElementNode(TopXmlSocketEnv *env, char *sXmlPath, int iReqOrRsp)
{
	TOP_XML_TREE *pXmlTree = NULL;
	TOP_XML_NODE *pXmlNode = NULL;
	if(iReqOrRsp == XML_SOCKET_IO_REQUEST){
		pXmlTree = env->reqxmlDoc;
	} else if(iReqOrRsp == XML_SOCKET_IO_RESPONSE){
		pXmlTree = env->respxmlDoc;
	} else {
		return (-1);	
	}
	pXmlNode = TOP_GetXmlNode(pXmlTree, sXmlPath);
	if(pXmlNode == NULL){
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_GetXmlNode [%s] error", sXmlPath);
		return NULL;	
	}	
	return pXmlNode;
}

/************************************************************************
 * ��ȡ����/��Ӧ����ĳ���ڵ��ĳ�����Ե�ֵ
 ************************************************************************/
int TXS_GetElementAttr(TopXmlSocketEnv *env, char *sXmlPath, char *sAttrName, char *sAttrValue, int iReqOrRsp)
{
	TOP_XML_TREE *pXmlTree = NULL;
	
	if(iReqOrRsp == XML_SOCKET_IO_REQUEST){
		pXmlTree = env->reqxmlDoc;
	} else if(iReqOrRsp == XML_SOCKET_IO_RESPONSE){
		pXmlTree = env->respxmlDoc;
	} else {
		return (-1);	
	}
	if(TOP_GetXmlNodeAttrValue(pXmlTree, sXmlPath, sAttrName, sAttrValue)){
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_GetXmlNodeAttrValue [%s->%s] error", sXmlPath, sAttrName);
		return (-1);	
	}	
	return 0;
}

/************************************************************************
 * ��ӡ׷��TXS��������Ϣ
 ************************************************************************/
void TXS_EnvTrace(TopXmlSocketEnv *pSocketEnv)
{
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL , __FILE__,__LINE__, "reqxmlDoc     = [%d]" , pSocketEnv->reqxmlDoc );
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL , __FILE__,__LINE__, "respxmlDoc    = [%d]" , pSocketEnv->respxmlDoc );
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL , __FILE__,__LINE__, "reqxmlBuffer  = [%s]" , pSocketEnv->reqxmlBuffer );
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL , __FILE__,__LINE__, "respxmlBuffer = [%s]" , pSocketEnv->respxmlBuffer );
	return;
}
