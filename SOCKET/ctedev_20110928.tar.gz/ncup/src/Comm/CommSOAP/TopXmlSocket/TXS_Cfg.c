#include "TopSoapInc/TopXmlSocket.h"
#include "TopSoapInc/TopHtLog.h"

extern char sLogName[32];

static char sTxsCfgFilePath[512];

/************************************************************************
 * ��XmlSocket�����ļ�
 ************************************************************************/
int TXS_OpenCfgFile(char *sSocketAppName) 
{
	char sFullName[256];
	memset(sFullName, 0x00, sizeof(sFullName));
	
	if(getenv (TOPXMLSOCKET_CFG_PATH)){
		HtStrcpy(sFullName, (char *)getenv(TOPXMLSOCKET_CFG_PATH));
	}
	if(strlen(sFullName) == 0) {
		HtStrcpy(sFullName, (char *)getenv("HOME"));
		HtStrcat(sFullName, "/etc/xmlsocketcfg");
	}
	if(Top_MakeDir(sFullName)){
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call Top_MakeDir[%s] Error", sFullName);
		return (-1);
	}
	HtStrcat(sFullName, "/");
	HtStrcat(sFullName, sSocketAppName);
	HtStrcat(sFullName, ".cfg");

	Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Cfg File Path[%s]", sFullName);
	
	return Top_OpenCfgFile(sFullName, sLogName);
	
}

int TXS_GetCfgItem(char *sSocketAppName, char *sSectionName, char *sItemName, char *sItemValue)
{

    if(TXS_OpenCfgFile(sSocketAppName)){
        Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TXS_OpenCfgFile  Failed");
        return -1;
    }

    if( Top_GetCfgItem(sSectionName, sItemName, sItemValue) )
    {
        Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_GetCfgItem(listen_port)  Failed");
        Top_CloseCfgFile();
        return (-1);
    }

    if(Top_CloseCfgFile()){
        Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Top_CloseCfgFile  Failed");
        return -1;
    }

	return 0;

}

int TXS_GetSocketCfg(char *sSocketAppName, char *sItemName, char *sItemValue)
{

	return TXS_GetCfgItem(sSocketAppName, "SOCKET", sItemName, sItemValue);

}

int TXS_GetVarityCfg(char *sSocketAppName, char *sItemName, char *sItemValue)
{

	return TXS_GetCfgItem(sSocketAppName, "VARIETY", sItemName, sItemValue);

}
