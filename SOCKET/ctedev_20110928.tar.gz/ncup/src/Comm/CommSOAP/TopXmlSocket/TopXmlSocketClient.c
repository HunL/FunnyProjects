#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "TopSoapInc/TopXmlSocket.h"
#include "TopSoapInc/TopHtLog.h"

static char sSvrIp[50];
static int nSvrPort;

extern char sLogName[32];

/************************************************************************
 * TXS�ͻ��˳�ʼ��(ȡ�����ļ��е�����,��ʼ��TXS������)
 ************************************************************************/
int TopXmlSocketClientInit(TopXmlSocketEnv *socketEnv, char *sSocketAppName) 
{
	
	char valueBuf[512];

	memset(valueBuf, 0x00, sizeof(valueBuf));

	if( TXS_GetSocketCfg(sSocketAppName, "svr_ip", valueBuf) )
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TXS_GetSocketCfg(svr_ip)  Failed");
		return (-1);
	}
	memset(sSvrIp, 0x00, sizeof(sSvrIp));
	strncpy(sSvrIp, valueBuf, sizeof(sSvrIp));
	
	memset(valueBuf, 0x00, sizeof(valueBuf));
	if( TXS_GetSocketCfg(sSocketAppName, "svr_port", valueBuf) )
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TXS_GetSocketCfg(svr_port)  Failed");
		return (-1);
	}
	nSvrPort = atoi(valueBuf);
	
	if(TopSocketClientInit(sSvrIp, nSvrPort)) {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientInit(%s-%d)  Failed", sSvrIp, nSvrPort);
		return -1;	
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientInit(%s-%d)  Success", sSvrIp, nSvrPort);
	
	if(CreateXmlSocketEnv(socketEnv)) {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "CreateXmlSocketEnv()  Failed");
		TopSocketClientDisConnect();
		return -1;	
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "CreateXmlSocketEnv() Success");
	
	return 0;
	
}

/************************************************************************
 * TXS�ͻ��˵��÷���˷���
 ************************************************************************/
int TopXmlSocketCall(TopXmlSocketEnv *socketEnv) 
{
	int llResult = 0;
	long lMesgLen = 0;
	char sTempBuf2[128];
	char sTempBuf[TOPXMLSOCKET_MESG_LEN];

	/*���ӷ�����*/
	if(TopSocketClientConnect()){
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientConnect  Failed");
		return (-1);
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientConnect  Success");
	
	memset(socketEnv->reqxmlBuffer, '0', TOPXMLSOCKET_MESG_LEN_L);
	
	/*������XML Tree ת����������*/
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ExportXmlTree Start" );	
	llResult = TOP_ExportXmlTree(socketEnv->reqxmlDoc, socketEnv->reqxmlBuffer + TOPXMLSOCKET_MESG_LEN_L, sizeof(socketEnv->reqxmlBuffer) - TOPXMLSOCKET_MESG_LEN_L);
	if(llResult) {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TOP_ExportXmlTree() Error!");
		return (-1);
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ExportXmlTree End");	
	
	/*��䳤�� - Added @ 20090909*/
	lMesgLen = strlen(socketEnv->reqxmlBuffer) - TOPXMLSOCKET_MESG_LEN_L;
	memset(sTempBuf2, 0x00, sizeof(sTempBuf2));
	snprintf(sTempBuf2, sizeof(sTempBuf2), "%06ld", lMesgLen);
	HtMemcpy(socketEnv->reqxmlBuffer, sTempBuf2, TOPXMLSOCKET_MESG_LEN_L);
	
	
	/*�������ķ��͸�Server��*/
	if(TopSocketClientSendMesg(socketEnv->reqxmlBuffer, strlen(socketEnv->reqxmlBuffer))){
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientSendMesg  Failed");
		TopSocketClientDisConnect();
		return (-1);
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientSendMesg  Success");

	/*������Ӧ����*/
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientRecvMesg  Begin...");
	memset(socketEnv->respxmlBuffer, 0x00, sizeof(socketEnv->respxmlBuffer));
	llResult = TopSocketClientRecvMesg(socketEnv->respxmlBuffer, sizeof(socketEnv->respxmlBuffer));
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientRecvMesg  End[%d]", llResult);
	if(llResult < 0)
	{
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientRecvMesg  Failed");
		TopSocketClientDisConnect();
		return (-1);
	}
	/*
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientRecvMesg  Success[%s]", socketEnv->respxmlBuffer);
	*/

printf("TopSocketClientRecvMesg  Success[%s] \n", socketEnv->respxmlBuffer);

	/*�Ͽ�������*/
	TopSocketClientDisConnect();
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientDisConnect  Success");

	/*����Ӧ����ת������ӦXML Tree*/
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ImportXMLTree  Start");
	/*
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ImportXMLTree[%s]", socketEnv->respxmlBuffer);
	*/
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[%ld]", strlen(socketEnv->respxmlBuffer));
	memset(sTempBuf, 0x00, sizeof(sTempBuf));
	HtMemcpy(sTempBuf, socketEnv->respxmlBuffer, strlen(socketEnv->respxmlBuffer));

	memset(sTempBuf2, 0x00, sizeof(sTempBuf2));
	HtMemcpy(sTempBuf2, sTempBuf, TOPXMLSOCKET_MESG_LEN_L);
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "��ӦXML���ĵĳ���Ϊ[%s]", sTempBuf2);
	
	if( Top_IsDigitStr(sTempBuf2, TOPXMLSOCKET_MESG_LEN_L) )
	{
		/*��Ϊ����*/
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�����ĵ�ǰ%dλ[%s]��������! ", TOPXMLSOCKET_MESG_LEN_L, sTempBuf2);
		return (-1);
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "���ĳ��ȺϷ�!");

	llResult = TOP_ImportXMLTree(socketEnv->respxmlDoc, sTempBuf + TOPXMLSOCKET_MESG_LEN_L, strlen(sTempBuf) - TOPXMLSOCKET_MESG_LEN_L);
	if(llResult) {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TOP_ImportXMLTree Error!");
		return (-1);
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TOP_ImportXMLTree  Success");
	
	return 0;
}
