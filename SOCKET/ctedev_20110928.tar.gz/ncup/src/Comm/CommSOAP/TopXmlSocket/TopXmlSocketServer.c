#include "TopSoapInc/TopXmlSocket.h"
#include "TopSoapInc/TopHtLog.h"

static int  srvListenPort = 0;
static int  srvListenNum  = 0;

extern char sLogName[32];

static char sCfgFileName[512];
/*TXSS - TopXmlSocketSvr*/

/*********************************************************************************
 * �������Accept��, ����TopXmlSocketEnv, Ȼ���ô�ʵ��ȥ�н�������, 
 * ������Ӧ����Ҳ���������, �ڷ���˽���Ӧ���ݷ��͸��ͻ��˺�, ��Ҫ�ͷ�ʵ��.
 *********************************************************************************/


/************************************************************************
 * TXS���������(ȡ�����ļ��е�����,����SOCKET�����)
 ************************************************************************/
int TopXmlSocketSvrStart(char *sSocketAppName)
{
	char valueBuf[512];
	
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopXmlSocket Server is Starting...");	
	
	memset(sCfgFileName, 0x00, sizeof(sCfgFileName));
	
	HtStrcpy(sCfgFileName, sSocketAppName);
	HtStrcat(sCfgFileName, ".svr");

	memset(valueBuf, 0x00, sizeof(valueBuf));
	if( TXS_GetSocketCfg(sCfgFileName, "listen_port", valueBuf) )
    {
        Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TXS_GetSocketCfg(listen_port)  Failed");
        return (-1);
    }	
	srvListenPort = atoi(valueBuf);
    Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "listen_port[%d]", srvListenPort);
	
	memset(valueBuf, 0x00, sizeof(valueBuf));
	if( TXS_GetSocketCfg(sCfgFileName, "listen_num", valueBuf) )
    {
        Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TXS_GetSocketCfg(listen_num)  Failed");
        return (-1);
    }	
	srvListenNum = atoi(valueBuf);
    Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "listen_num[%d]", srvListenNum);
	
    Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TopSocketServerStart Start...");
	if(TopSocketServerStart(srvListenPort, srvListenNum)) {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketServerStart  Failed");
		return -1;	
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopXmlSocket Server Start Successfully");	

	return 0;
}

/************************************************************************
 * TXS����˹ر�
 ************************************************************************/
void TopXmlSocketSvrStop()
{
	TopSocketServerStop();
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopXmlSocket Server Stoped");	
}

/************************************************************************
 * TXS�����ACCEPTһ��TXS�ͻ��˵�����
 ************************************************************************/
int TopXmlSocketSvrAccept()
{
	return TopSocketServerAccept();
}

/************************************************************************
 * TXS����˽���TXS�ͻ���������
 ************************************************************************/
int TXSS_ResvMesg(TopXmlSocketEnv *env)
{
	long nMesgLen = 0;
	char sTempBuf[128];
	int  llResult = 0;
	
	Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Call TopSocketServerResvMesg Start...");
	/*����������*/
	llResult = TopSocketServerResvMesg(env->reqxmlBuffer, sizeof(env->reqxmlBuffer));

	if(llResult < 0) {
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketServerResvMesg Failed!");
		return (-1);	
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketServerResvMesg [%s]", env->reqxmlBuffer);
	
	memset(sTempBuf, 0x00, sizeof(sTempBuf));
	HtMemcpy(sTempBuf, env->reqxmlBuffer, TOPXMLSOCKET_MESG_LEN_L);
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "����XML���ĵĳ��� [%s]", sTempBuf);
	
	if( Top_IsDigitStr(sTempBuf, TOPXMLSOCKET_MESG_LEN_L) )
	{
		/*��Ϊ����*/
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�����ĵ�ǰ%dλ[%s]��������! ", TOPXMLSOCKET_MESG_LEN_L, sTempBuf);
		return (-1);
	} 
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "���ĳ��ȺϷ�!");
	
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Call TOP_ImportXMLTree Start...");
	/*�������Ľ�����XML Tree*/
	if(TOP_ImportXMLTree(env->reqxmlDoc, env->reqxmlBuffer + TOPXMLSOCKET_MESG_LEN_L, strlen(env->reqxmlBuffer) - TOPXMLSOCKET_MESG_LEN_L)){
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TOP_ImportXMLTree Failed");	
		return (-1);
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Call TOP_ImportXMLTree().");
	
	/*for Debug*/
	TOP_PrintXmlTree(env->reqxmlDoc);
	
	return 0;
}

/************************************************************************
 * TXS�������TXS�ͻ��˷�����Ӧ����
 ************************************************************************/
int TXSS_SendMesg(TopXmlSocketEnv *env)
{
	int llResult = 0;
	long lMesgLen = 0;
	char sTempBuf[128];
	char sSendMesg[TOPXMLSOCKET_MESG_LEN];

	/*for Debug*/
	TOP_PrintXmlTree(env->respxmlDoc);

Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,  "env->req  [%x]", env->reqxmlDoc);           
Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,  "env->resp [%x]", env->respxmlDoc);   

	memset(env->respxmlBuffer, '0', TOPXMLSOCKET_MESG_LEN_L);
	
	/*����ӦXML Treeת������Ӧ����*/
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Call TOP_ExportXmlTree Start...");	
	llResult = TOP_ExportXmlTree(env->respxmlDoc, env->respxmlBuffer + TOPXMLSOCKET_MESG_LEN_L, sizeof(env->respxmlBuffer) - TOPXMLSOCKET_MESG_LEN_L);
    if(llResult) {
        Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TOP_ExportXmlTree() Error!");
        return (-1);
    }
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Call TOP_ExportXmlTree(). ");	

Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,  "env->req  [%x]", env->reqxmlDoc);           
Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,  "env->resp [%x]", env->respxmlDoc);   
	
	/*��䳤�� - Added @ 20090909*/
	lMesgLen = strlen(env->respxmlBuffer) - TOPXMLSOCKET_MESG_LEN_L;
	memset(sTempBuf, 0x00, sizeof(sTempBuf));
	snprintf(sTempBuf, sizeof(sTempBuf), "%06ld", lMesgLen);
	HtMemcpy(env->respxmlBuffer, sTempBuf, TOPXMLSOCKET_MESG_LEN_L);
	
	/*������Ӧ����*/
	Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "strlen(resp) [%ld]", strlen(env->respxmlBuffer));	

	memset(sSendMesg, 0x00, sizeof(sSendMesg));
	HtMemcpy(sSendMesg, env->respxmlBuffer, strlen(env->respxmlBuffer));

	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Call TopSocketServerSendMesg Start...");	
	if(TopSocketServerSendMesg(sSendMesg, strlen(sSendMesg))){
		Top_HtLog(sLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketServerSendMesg Failed");	
		return (-2);
	}
	Top_HtLog(sLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Call TopSocketServerSendMesg().");	

Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,  "env->req  [%x]", env->reqxmlDoc);           
Top_HtLog(sLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,  "env->resp [%x]", env->respxmlDoc);   

	return 0;
}


int TXSS_GetVrietyCfg(char *sItemName, char *sItemValue)
{
	return TXS_GetVarityCfg(sCfgFileName, sItemName, sItemValue); 
}
