/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopErrCode.h"
#include "TopSoapInc/TopHttp.h"
#include "TopSoapInc/TopHtLog.h"

static char sTopHttpServerLogName[32] = "TopHttpServer.log";
static int  srvListenPort = 0;
static int  srvListenNum  = 0;

static char sTopServerCfgName[32];


extern char *_TopCfg_LTrim(char *sChars);


/*��ʼ������������Ӧͷ*/
int TopHttpServerHeadInit(TopHttpRspHead *pstHttpRspHead)
{
	char valueBuf[128];
	int headPairNum, i;
	char *pHeadPair = NULL;
	char headPairName[128];

	pstHttpRspHead->iRspHeadPairNum = 0;
	
	if(TopSoap_OpenCfgFile(sTopServerCfgName)){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSoap_OpenCfgFile  Failed");
		return -1;
	}
	
	memset(valueBuf, 0x00, sizeof(valueBuf));
    if(GetHttpCfgItem("header_count", valueBuf)){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetHttpCfgItem(header_count)  Failed");
		Top_CloseCfgFile();
		return (-1);
	}
	headPairNum = atoi(valueBuf);

	for(i = 0; (headPairNum >= 0) && (i < headPairNum); i++){

       		pHeadPair = NULL;
       		memset(valueBuf, 0x00, sizeof(valueBuf));
       		memset(headPairName, 0x00, sizeof(headPairName));
       		HtSprintf(headPairName, "header_%d", i+1);
       		if(GetHttpCfgItem(headPairName, valueBuf)){
				Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetHttpCfgItem(%s)  Failed", headPairName);
				Top_CloseCfgFile();
				return (-1);
			}
       		pHeadPair = strstr(valueBuf, "$$$");
       		if(pHeadPair == NULL){
       			Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SOAP_ENVELOP Item Cfg Error(%s = %s)", headPairName, valueBuf);
       			Top_CloseCfgFile();
       			return (-1);	
       		}
       		HtMemcpy(pstHttpRspHead->stRspHeadPairs[pstHttpRspHead->iRspHeadPairNum].Key, valueBuf, pHeadPair-valueBuf);
       		HtSprintf(pstHttpRspHead->stRspHeadPairs[pstHttpRspHead->iRspHeadPairNum].Value, "%s", pHeadPair + 3);
       		pstHttpRspHead->iRspHeadPairNum++;
	}
	if(Top_CloseCfgFile()){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Top_CloseCfgFile  Failed");
		return -1;	
	}
	return 0;
}

/*��װserver����Ӧ����*/
void PackHttpServerRspMesg(TopHttpResponse *pstHttpRsp, char *sHttpRspBuf)
{
	char *pRspBuf = sHttpRspBuf;
	char tmpBuf[128];
	int i;
	
	memset(pRspBuf, 0x00, sizeof(pRspBuf));

	HtSprintf(pRspBuf, "HTTP/1.1 %d %s\r\n", pstHttpRsp->stRspHead.iHttpStatus, pstHttpRsp->stRspHead.sHttpStatusDesc);

	for(i = 0; i < pstHttpRsp->stRspHead.iRspHeadPairNum; i++){
		memset(tmpBuf, 0x00, sizeof(tmpBuf));
		HtSprintf(tmpBuf, "%s:%s\r\n", pstHttpRsp->stRspHead.stRspHeadPairs[i].Key, pstHttpRsp->stRspHead.stRspHeadPairs[i].Value);	
		HtStrcat(pRspBuf, tmpBuf);
	}
	memset(tmpBuf, 0x00, sizeof(tmpBuf));
	HtSprintf(tmpBuf, "Content-Length:%d\r\n\r\n", strlen(pstHttpRsp->sRspBody));	
	HtStrcat(pRspBuf, tmpBuf);
	
	HtStrcat(pRspBuf, pstHttpRsp->sRspBody);
}


/*����http�ͻ��˷�������˵�������Ϣ*/
int ParseHttpReqMesg(char *sHttpReqBuf, TopHttpRequest *pstHttpReq)
{
	char *pTmpST = NULL;
	char *pTmpED = NULL;
	char reqHeadBuf[1024];
	char tempBuf[128];
	char *pReqBody = NULL;
	int  isChunked = 0;
	int  isHttpMethodPOST = 1;
	int  i, llResult;
	char sHttpChunkedMesg[4096];

	memset(pstHttpReq, 0x00, sizeof(TopHttpRequest));
	pstHttpReq->stReqHead.iReqHeadPairNum = 0;
	
	pTmpST = sHttpReqBuf;
	pTmpED = strstr(pTmpST, "\r\n\r\n");
	/*��Ӧ����*/
	pReqBody = pTmpED + 4;
	/*��Ӧͷ*/
	memset(reqHeadBuf, 0x00, sizeof(reqHeadBuf));
	HtMemcpy(reqHeadBuf, pTmpST, pTmpED-pTmpST);
	/*"POST /StockQuote HTTP/1.1"*/
	pTmpST = reqHeadBuf;
	pTmpST = _TopCfg_LTrim(pTmpST);
	pTmpED = strstr(pTmpST, " ");
	if(pTmpED == NULL){
		return (-1);	
	}
	memset(tempBuf, 0x00, sizeof(tempBuf));
	HtMemcpy(tempBuf, pTmpST, pTmpED-pTmpST);
	if(strcmp(tempBuf, "POST") != 0){
		isHttpMethodPOST = 0;
		/*��ʱ��֧�ַ�POST��ʽ*/
		return(-1);
	}
	
	/*��ȡ����·��*/
	pTmpST = _TopCfg_LTrim(pTmpED);
	pTmpED = strstr(pTmpST, " ");
	if(pTmpED == NULL){
		return (-1);	
	}
	HtMemcpy(pstHttpReq->stReqHead.stHttpUrl.HttpReqPath, pTmpST, pTmpED-pTmpST);
	
	/*��ȡHTTP�汾�ţ�����*/
	pTmpST = _TopCfg_LTrim(pTmpED);
	pTmpED = strstr(pTmpST, "\r\n");
	if(pTmpED == NULL){
		return (-1);	
	}

	/*��ʼ������ֵ��*/
	pTmpST = pTmpED + 2;
	pTmpST = _TopCfg_LTrim(pTmpED);

	while((pTmpED = strstr(pTmpST, "\r\n")) != NULL)
	{
		memset(tempBuf, 0x00, sizeof(tempBuf));
		HtMemcpy(tempBuf, pTmpST, pTmpED-pTmpST);
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "pair[%s]", tempBuf);
		pTmpST = pTmpED + 2;
		
		pTmpED = strstr(tempBuf, ":");
		if(pTmpED == NULL){
			return (-1);	
		}
		HtMemcpy(pstHttpReq->stReqHead.stReqHeadPairs[pstHttpReq->stReqHead.iReqHeadPairNum].Key, tempBuf, pTmpED-tempBuf);
		HtSprintf(pstHttpReq->stReqHead.stReqHeadPairs[pstHttpReq->stReqHead.iReqHeadPairNum].Value, "%s", _TopCfg_LTrim(pTmpED+1));
		pstHttpReq->stReqHead.iReqHeadPairNum++;
	}
	/*���ļ�ֵ��*/
	pTmpED = strstr(pTmpST, ":");
	if(pTmpED == NULL){
		return (-1);	
	}
	HtMemcpy(pstHttpReq->stReqHead.stReqHeadPairs[pstHttpReq->stReqHead.iReqHeadPairNum].Key, pTmpST, pTmpED-pTmpST);
	HtSprintf(pstHttpReq->stReqHead.stReqHeadPairs[pstHttpReq->stReqHead.iReqHeadPairNum].Value, "%s", _TopCfg_LTrim(pTmpED+1));
	pstHttpReq->stReqHead.iReqHeadPairNum++;
	
	for( i = 0; i < pstHttpReq->stReqHead.iReqHeadPairNum; i++) 
	{   
     Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Key [%s]", pstHttpReq->stReqHead.stReqHeadPairs[i].Key);
     Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Vlaue [%s]", pstHttpReq->stReqHead.stReqHeadPairs[i].Value);
        if(_XML_cmpStrIgCase(pstHttpReq->stReqHead.stReqHeadPairs[i].Key, "Transfer-Encoding") == 0
			&& _XML_cmpStrIgCase(pstHttpReq->stReqHead.stReqHeadPairs[i].Value, "chunked") == 0){
			isChunked = 1;	
		}
    }
	
	/*������Ӧ������*/
	if(isChunked){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Chunked Response Mesg");
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "strlen(pReqBody) = %d", strlen(pReqBody));
        if(strlen(pReqBody) <= 0) {
        	/*Receive Mesg Again*/
           Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Receive Chunked Req Mesg...");
            memset(sHttpChunkedMesg, 0x00, sizeof(sHttpChunkedMesg));
            llResult = TopSocketServerResvMesg(sHttpChunkedMesg, sizeof(sHttpChunkedMesg));
            Top_HtDebugString(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, sHttpChunkedMesg, strlen(sHttpChunkedMesg));

            if(llResult < 0){
                Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketServerResvMesg  Failed");
                TopHttpServerCloseClient();
                return (-1);
            }
            Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketServerResvMesg  Success");

            pReqBody = sHttpChunkedMesg;
        } 
		
		
		if(parseChunkedMesg(pReqBody, pstHttpReq->sReqBody)){
			Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "parseChunkedMesg Failed");
			return (-1);
		}
	} else {
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "NOT Chunked Response Mesg");
		HtSprintf(pstHttpReq->sReqBody, "%s", pReqBody);
	}
	
	return 0;
}

int TopHttpServerStart(char *sSoapCfgName)
{
	char valueBuf[128];
	
	Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "HTTP SERVER STARTING...");

	memset(sTopServerCfgName, 0x00, sizeof(sTopServerCfgName));
	HtSprintf(sTopServerCfgName, "%s", sSoapCfgName);
	
	if(TopSoap_OpenCfgFile(sTopServerCfgName)){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSoap_OpenCfgFile  Failed");
		return -1;
	}
	
	memset(valueBuf, 0x00, sizeof(valueBuf));
	if(GetHttpCfgItem("listen_port", valueBuf)){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetHttpCfgItem(listen_port)  Failed");
		Top_CloseCfgFile();
		return (-1);
	}
	srvListenPort = atoi(valueBuf);
	
	memset(valueBuf, 0x00, sizeof(valueBuf));
	if(GetHttpCfgItem("listen_num", valueBuf)){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetHttpCfgItem(listen_num)  Failed");
		Top_CloseCfgFile();
		return (-1);
	}
	srvListenNum = atoi(valueBuf);
	
	if(Top_CloseCfgFile()){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Top_CloseCfgFile  Failed");
		return -1;	
	}
	
	if(TopSocketServerStart(srvListenPort, srvListenNum)){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopHttpServerStart  Failed");
		return (-1);
	}
	Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "HTTP SERVER STARTED");
	return 0;
}

void TopHttpServerStop()
{
	TopSocketServerStop();
	Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "HTTP SERVER STOPED");
}

int TopHttpServerAccept()
{
	return TopSocketServerAccept();
}

void TopHttpServerCloseClient()
{
	TopSocketServerCloseClient();
}

int TopHttpServerRecvClient(TopHttpRequest *pstHttpClientReq)
{
	char sHttpReqMesg[4096];
	int  llResult = 0;
	
	memset(sHttpReqMesg, 0x00, sizeof(sHttpReqMesg));
	
	llResult = TopSocketServerResvMesg(sHttpReqMesg, sizeof(sHttpReqMesg));

	if(llResult < 0){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketServerResvMesg Failed!");
		return (-1);	
	}
	
	/*Trace*/
	Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "\n%s\n%s\n%s",
						"=====================Http Server Received Request Message B======================",
						sHttpReqMesg,
						"=====================Http Server Received Request Message E======================"
						);
	/*�����ͻ��˷�����������*/
	if(ParseHttpReqMesg(sHttpReqMesg, pstHttpClientReq)){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ParseHttpReqMesg Failed!");
		return (-1);	
	}
	
	/*trace*/
	HttpRequestTrace(pstHttpClientReq);
	
	return 0;
}

int TopHttpServerSendClient(TopHttpResponse *pstHttpClientRsp)
{
	char sHttpRspMesg[4096];
	memset(sHttpRspMesg, 0x00, sizeof(sHttpRspMesg));
	/*��ȡ�����ļ�����ʼ����Ӧͷ*/
	if(TopHttpServerHeadInit(&pstHttpClientRsp->stRspHead)){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopHttpServerHeadInit Failed!");
		return (-1);
	}
	/*��װ��Ӧ����*/
	PackHttpServerRspMesg(pstHttpClientRsp, sHttpRspMesg);
	/*������Ӧ����*/
	Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "\n%s\n%s\n%s",
						"=====================Http Server Send Response Message B======================",
						sHttpRspMesg,
						"=====================Http Server Send Response Message E======================"
						);
	if(TopSocketServerSendMesg(sHttpRspMesg, strlen(sHttpRspMesg))){
		Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketServerSendMesg Failed!");
		return (-1);	
	}
	Top_HtLog(sTopHttpServerLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketServerSendMesg Successfully!");
	return 0;
}

