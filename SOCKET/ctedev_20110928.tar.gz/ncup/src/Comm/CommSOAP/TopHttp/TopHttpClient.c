/**************************************************************************
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.           *
 *  All right reserved.                                                   *
 *                                                                        *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG       *
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT         *
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,      *
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF          *
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.                           *
 *                                                                        *
 *	������ : ������                                                       *
 **************************************************************************/
#include "TopSoapInc/TopErrCode.h"
#include "TopSoapInc/TopHttp.h"
#include "TopSoapInc/TopHtLog.h"

static char sHttpCliLogName[32] = "TopHttpClient.log";

extern char *_TopCfg_LTrim(char *sChars);


/* ֻ֧�� http://197.1.5.1:8080/axis2/services/Peprfe �ĸ�ʽ*/
int ParseTopUrl(TopUrl *url, char *urlstr)
{
	char stBuf[128];
	char *pTempST = NULL;
	char *pTempED = NULL;
	char *pUrlStr = urlstr;
	int  iHostEnd = 0;
	memset(url, 0x00, sizeof(TopUrl));
	
	url->HttpProtocol = PROTOCOL_HTTP;
	
	if((pTempST = strstr(pUrlStr, "://")) == NULL)
	{
		glTopErrCode = LTOPErrConfig;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", "The Uri Of WebService is Format-Invalid.");

		return (-1);	
	}
	pTempST += 3;
	if((pTempED = strstr(pTempST, ":")) == NULL)
	{
		url->HttpServPort = HTTP_SVR_DEFAULT_PORT;
		if((pTempED = strstr(pTempST, "/")) == NULL){
			/*˵��ֻ��ip*/
			HtSprintf(url->HttpServAddr, "%s", pTempST);
		} else {
			HtMemcpy(url->HttpServAddr, pTempST, pTempED-pTempST);
			HtSprintf(url->HttpReqPath, "%s", pTempED);
		}
	} 
	else 
	{
		HtMemcpy(url->HttpServAddr, pTempST, pTempED-pTempST);	
		pTempST = pTempED + 1;
		if((pTempED = strstr(pTempST, "/")) == NULL){
			url->HttpServPort = atoi(pTempST);
			HtSprintf(url->HttpReqPath, "%s", "/");
		} else {
			memset(stBuf, 0x00, sizeof(stBuf));
			HtMemcpy(stBuf, pTempST, pTempED-pTempST);	
			url->HttpServPort = atoi(stBuf);
			HtSprintf(url->HttpReqPath, "%s", pTempED);
		}
	}
	return 0;
}

int TopHttpClientHeadInit(TopHttpReqHead *pstHttpReqHead, char *sSoapCfgName)
{
	char valueBuf[128];
	int headPairNum, i;
	char *pHeadPair = NULL;
	char headPairName[128];

	memset(pstHttpReqHead, 0x00, sizeof(TopHttpReqHead));
	pstHttpReqHead->iReqHeadPairNum = 0;
	
	if(TopSoap_OpenCfgFile(sSoapCfgName))
	{
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSoap_OpenCfgFile  Failed");
		glTopErrCode = LTOPErrConfig;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", "Open Config File Error");
		return -1;
	}
	/*
	if(GetHttpCfgItem("method", valueBuf)){
		return (-1);	
	}
	*/
	pstHttpReqHead->iHttpMethod  = HTTP_REQUEST_POST;

	memset(valueBuf, 0x00, sizeof(valueBuf));
	if(GetHttpCfgItem("uri", valueBuf)){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetHttpCfgItem(uri)  Failed");
		Top_CloseCfgFile();

		glTopErrCode = LTOPErrConfig;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", "The Config Item uri NotExist");

		return (-1);	
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "CfgItem - uri : [%s]", valueBuf);
	if(ParseTopUrl(&pstHttpReqHead->stHttpUrl,valueBuf)){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ParseTopUrl  Failed");
		Top_CloseCfgFile();
		return (-1);
	}
	
	/*��ȡ�����ַ����ʽ������  -- Brady.Lee @ 20091014*/
	memset(valueBuf, 0x00, sizeof(valueBuf));
	if(GetHttpCfgItem("addr_type", valueBuf)){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetHttpCfgItem(addr_type)  Failed");
		Top_CloseCfgFile();
		glTopErrCode = LTOPErrConfig;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", "The Config Item addr_type NotExist");
		return (-1);	
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "CfgItem - addr_type : [%s]", valueBuf);
	if(_XML_cmpStrIgCase(valueBuf, HTTP_URI_ADDR_TYPE_IP) == 0) 
	{
		pstHttpReqHead->stHttpUrl.HttpServAddrType = TOP_HOST_ADDR_TYPE_IP;
		snprintf(pstHttpReqHead->stHttpUrl.HttpServIP, sizeof(pstHttpReqHead->stHttpUrl.HttpServIP), "%s", pstHttpReqHead->stHttpUrl.HttpServAddr);
	} 
	else if(_XML_cmpStrIgCase(valueBuf, HTTP_URI_ADDR_TYPE_DOMAIN) == 0) 
	{
		pstHttpReqHead->stHttpUrl.HttpServAddrType = TOP_HOST_ADDR_TYPE_DOMAIN;
		if( TopGetHostIpByDomain(pstHttpReqHead->stHttpUrl.HttpServAddr, pstHttpReqHead->stHttpUrl.HttpServIP, sizeof(pstHttpReqHead->stHttpUrl.HttpServIP) - 1) != 0) 
		{
			Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TopGetHostIpByDomain(%s) Failed!", pstHttpReqHead->stHttpUrl.HttpServAddr);
			Top_CloseCfgFile();
			return (-1);	
		}
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TopGetHostIpByDomain(). [%s]->[%s].", pstHttpReqHead->stHttpUrl.HttpServAddr, pstHttpReqHead->stHttpUrl.HttpServIP);
	} 
	else 
	{
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "������addr_type��ȡֵ(%s)���Ϸ�!", valueBuf);
		Top_CloseCfgFile();
		glTopErrCode = LTOPErrConfig;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", "Invalid Value For The Config Item addr_type");
		return (-1);	
	}

	memset(valueBuf, 0x00, sizeof(valueBuf));
    if(GetHttpCfgItem("header_count", valueBuf)){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetHttpCfgItem(header_count)  Failed");
		Top_CloseCfgFile();
		glTopErrCode = LTOPErrConfig;
		memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
		snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "%s", "The Config Item header_count NotExist");
		return (-1);
	}
	headPairNum = atoi(valueBuf);

	for(i = 0; (headPairNum >= 0) && (i < headPairNum); i++)
	{
       	pHeadPair = NULL;
       	memset(valueBuf, 0x00, sizeof(valueBuf));
       	memset(headPairName, 0x00, sizeof(headPairName));
       	HtSprintf(headPairName, "header_%d", i+1);
       	if(GetHttpCfgItem(headPairName, valueBuf)){
			Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetHttpCfgItem(%s)  Failed", headPairName);
			Top_CloseCfgFile();
			return (-1);
		}
       	pHeadPair = strstr(valueBuf, "$$$");
       	if(pHeadPair == NULL){
       		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SOAP_ENVELOP Item Cfg Error(%s = %s)", headPairName, valueBuf);
       		Top_CloseCfgFile();
			glTopErrCode = LTOPErrConfig;
			memset(gsTopErrMesg, 0x00, sizeof(gsTopErrMesg));
			snprintf(gsTopErrMesg, sizeof(gsTopErrMesg), "The Value Of The Config Item %s NotExist", headPairName);
       		return (-1);	
       	}
       	HtMemcpy(pstHttpReqHead->stReqHeadPairs[pstHttpReqHead->iReqHeadPairNum].Key, valueBuf, pHeadPair-valueBuf);
       	HtSprintf(pstHttpReqHead->stReqHeadPairs[pstHttpReqHead->iReqHeadPairNum].Value, "%s", pHeadPair + 3);
       	pstHttpReqHead->iReqHeadPairNum++;
	}

	if(Top_CloseCfgFile()){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Top_CloseCfgFile  Failed");
		return -1;	
	}
	return 0;
}

void HttpRequestTrace(TopHttpRequest *pstHttpReq)
{
	int i;
	
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "=================================Trace Http Request B=================================");
	if (pstHttpReq->stReqHead.iHttpMethod == HTTP_REQUEST_POST)
    {
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP METHOD  ] POST");
	}
	if (pstHttpReq->stReqHead.stHttpUrl.HttpProtocol == PROTOCOL_HTTP)
    {
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP PROTOCOL] HTTP/1.1");
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP PORT    ] %d", pstHttpReq->stReqHead.stHttpUrl.HttpServPort);
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP SrvIP   ] %s", pstHttpReq->stReqHead.stHttpUrl.HttpServAddr);
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP SrvPATH ] %s", pstHttpReq->stReqHead.stHttpUrl.HttpReqPath);
	
	for (i = 0; i < pstHttpReq->stReqHead.iReqHeadPairNum; i++)
    {   
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP PAIRS   ] %s -> %s", 
								pstHttpReq->stReqHead.stReqHeadPairs[i].Key,
								pstHttpReq->stReqHead.stReqHeadPairs[i].Value
								);
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "[HTTP REQ BODY] %s", pstHttpReq->sReqBody);
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "=================================Trace Http Request E=================================");
}

void HttpResponseTrace(TopHttpResponse *pstHttpRsp)
{
	int i;
	
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "=================================Trace Http Response B=================================");
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP Status       ] %d", pstHttpRsp->stRspHead.iHttpStatus);
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP StatusDESC   ] %s", pstHttpRsp->stRspHead.sHttpStatusDesc);
	
	for(i = 0; i < pstHttpRsp->stRspHead.iRspHeadPairNum; i++){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP PAIRS   ] %s -> %s", 
								pstHttpRsp->stRspHead.stRspHeadPairs[i].Key,
								pstHttpRsp->stRspHead.stRspHeadPairs[i].Value
								);
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "[HTTP REQ BODY] %s", pstHttpRsp->sRspBody);
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "=================================Trace Http Response E=================================");
}


void PackHttpReqMesg(TopHttpRequest *pstHttpReq, char *sHttpReqBuf)
{
	char *pReqBuf = sHttpReqBuf;
	char tmpBuf[512];
	int i;
	
	HtSprintf(pReqBuf, "POST %s HTTP/1.1\r\nHost:%s\r\n", pstHttpReq->stReqHead.stHttpUrl.HttpReqPath, pstHttpReq->stReqHead.stHttpUrl.HttpServAddr);

	for(i = 0; i < pstHttpReq->stReqHead.iReqHeadPairNum; i++){
		memset(tmpBuf, 0x00, sizeof(tmpBuf));
		HtSprintf(tmpBuf, "%s:%s\r\n", pstHttpReq->stReqHead.stReqHeadPairs[i].Key, pstHttpReq->stReqHead.stReqHeadPairs[i].Value);	
		HtStrcat(pReqBuf, tmpBuf);
	}
	memset(tmpBuf, 0x00, sizeof(tmpBuf));
	HtSprintf(tmpBuf, "Content-Length:%d\r\n\r\n", strlen(pstHttpReq->sReqBody));	
	HtStrcat(pReqBuf, tmpBuf);
	
	HtStrcat(pReqBuf, pstHttpReq->sReqBody);
}

/*16����תʮ����*/
int _XML_s16to10(char *s)
{
	int lRet;
	char *pch = NULL;
	char ch;
	
	lRet = 0;
	pch = s;
	
	while (*pch) {
		ch=*pch;
		if ((ch >= '0') && (ch <= '9')) ch -= '0'; 
		else if ((ch >= 'A') && (ch <= 'F')) ch -= '7'; 
		else if ((ch >= 'a') && (ch <= 'f')) ch -= 'W'; 
		
		lRet= (lRet << 4 ) + ch;
		pch ++;
	}
	
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "_XML_s16to10 : [%s]->[%d]", s, lRet);
	
	return lRet;
} 
/**���Դ�Сд�������ַ����Ƚ�,���ֻ�� ��� ���� �����**/
int _XML_cmpStrIgCase(char *s1, char *s2)
{
	int i;
	char *ps1 = s1;
	char *ps2 = s2;
	
	if (s1 == NULL && s2 == NULL)
		return (0);
	if (s1 == NULL || s2 == NULL)
		return (-1);
	if(strlen(ps1) != strlen(ps2)){
		return (-1);	
	}
	for (i = 0; i < strlen(ps1); i++){
		if (toupper(ps1[i]) != toupper(ps2[i]))
			return (-1);
	}
	return 0;
}

int parseChunkedMesg(char *sChunkedMesg, char *sRspBodyBuf, int lMaxLen)
{
	char *pTmpST = NULL;
	char *pTmpED = NULL;
	char *pTmpED2 = NULL;
	char sHttpChunkedMesg[HTTP_PRE_RECV_LENGTH+1];
	char tmpBuf[1024];
	int  chunkedSize = 0;
	char *pRspBody = sRspBodyBuf;
	int  llResult = 0;
	int  nBufLeftLen = lMaxLen;
    int  iTimes;
	pTmpST = sChunkedMesg;

Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nBufLeftLen=[%d]", nBufLeftLen);

	while(1) {
		
		pTmpED = strstr(pTmpST, "\r\n");
		
		if(pTmpED == NULL)
        {
			memset(tmpBuf, 0x00, sizeof(tmpBuf));
			HtMemcpy(tmpBuf, pTmpST, strlen(pTmpST));
			Top_HtLog(sHttpCliLogName,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Begin To Call TopSocketClientRecvMesg...");
			memset(sHttpChunkedMesg, 0x00, sizeof(sHttpChunkedMesg));
            llResult = TopSocketClientRecvMesg(sHttpChunkedMesg, HTTP_PRE_RECV_LENGTH);
            if(llResult < 0){
                Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientRecvMesg  Failed");
                return (-1);
            }
            Top_HtDebugString(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sHttpChunkedMesg, llResult);
		
			pTmpST = sHttpChunkedMesg;
			pTmpED = strstr(pTmpST, "\r\n");
			if(pTmpED == NULL)
            {
				return (-1);
			}
			HtMemcpy(tmpBuf + strlen(tmpBuf), pTmpST, pTmpED - pTmpST);
		}
        else
        {
			memset(tmpBuf, 0x00, sizeof(tmpBuf));
			if(pTmpED-pTmpST > sizeof(tmpBuf)) {
				Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Begin to Call _XML_s16to10...");
				return (-1);
			}
			HtMemcpy(tmpBuf, pTmpST, pTmpED-pTmpST);
			Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "chunked Len[%s]", tmpBuf);
		}
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Begin to Call _XML_s16to10...");
		chunkedSize = _XML_s16to10(tmpBuf); /*16����תʮ���� */
		
		if(chunkedSize == 0)
        {
			return 0;
		}
		
		pTmpST = pTmpED + 2;
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "chunkedSize[%d] , bufʣ��Len[%d]", chunkedSize, strlen(pTmpST));
		
		if(chunkedSize > strlen(pTmpST)) 
        {
			Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "branch 1: chunkedSize > bufʣ��Len");

			if(nBufLeftLen < strlen(pTmpST)) {
				Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Http BodyԤ����Buffer���Ȳ���!!");
				return (-1);
			}
			HtMemcpy(pRspBody, pTmpST, strlen(pTmpST));
			chunkedSize = chunkedSize - strlen(pTmpST);
			pRspBody = pRspBody + strlen(pTmpST);
			nBufLeftLen -= strlen(pTmpST);
			
            iTimes = 0;
			while(1) 
			{
				memset(sHttpChunkedMesg, 0x00, sizeof(sHttpChunkedMesg));
				Top_HtLog(sHttpCliLogName,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"chunkedSize [%d]!", chunkedSize);
				Top_HtLog(sHttpCliLogName,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"Begin To TopSocketClientRecvMesg...");
	            llResult = TopSocketClientRecvMesg(sHttpChunkedMesg, HTTP_PRE_RECV_LENGTH);

	            Top_HtLog(sHttpCliLogName,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Call TopSocketClientRecvMesg[%d]!",llResult);

	            if(llResult < 0)
                {
	                Top_HtLog(sHttpCliLogName,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"TopSocketClientRecvMesg Failed");
	                return (-1);
	            }
	            Top_HtDebugString(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sHttpChunkedMesg, llResult);
				
				if(llResult < chunkedSize) 
                {
					if(nBufLeftLen < strlen(pTmpST)) 
                    {
						Top_HtLog(sHttpCliLogName,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Http BodyԤ����Buffer���Ȳ���!!");
						return (-1);
					}
					HtMemcpy(pRspBody, sHttpChunkedMesg, llResult);
					chunkedSize -= llResult;
					pRspBody = pRspBody + llResult;
					nBufLeftLen -= llResult;
                    /**������10�� by xcl 20101011**/
                    iTimes ++;
                    if(iTimes > 10 )
                    {
					    Top_HtLog(sHttpCliLogName,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"���մ�������" );
					    return (-1);
                    }
                    /**xcl end**/

					continue;
				} 
				
				if(nBufLeftLen < chunkedSize)
                {
					Top_HtLog(sHttpCliLogName,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Http BodyԤ����Buffer���Ȳ���!!");
					return (-1);
				}
				HtMemcpy(pRspBody, sHttpChunkedMesg, chunkedSize);
				pTmpST = sHttpChunkedMesg + chunkedSize;
				pRspBody = pRspBody + chunkedSize;
				nBufLeftLen -= chunkedSize;
				break;
			}

		} else {
			Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "branch 2: chunkedSize <= bufʣ��Len");
			pTmpST = _TopCfg_LTrim(pTmpED);
			if(nBufLeftLen < strlen(pTmpST)) {
				Top_HtLog(sHttpCliLogName,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"Http BodyԤ����Buffer���Ȳ���!!");
				return (-1);
			}
			HtMemcpy(pRspBody, pTmpST, chunkedSize);
			pTmpST = pTmpST + chunkedSize;
			pRspBody = pRspBody + chunkedSize;
			nBufLeftLen -= chunkedSize;
		}
		
		pTmpST = _TopCfg_LTrim(pTmpST);

	}
	
	return 0;
}


int ParseRespMesg(char *sHttpRspBuf, TopHttpResponse *pstHttpRsp)
{
	char *pTmpST = NULL;
	char *pTmpED = NULL;
	char rspHeadBuf[1024];
	char tempBuf[128];
	char *pRspBody = NULL;
	int  isChunked = 0;
	
	int  i, llResult;
	char sHttpChunkedMesg[HTTP_PRE_RECV_LENGTH+1];
	
	int  nExistContentLen = 0;	/*���ر������Ƿ����Content-Length*/
	int  nRespBodyLen = 0;	/*ֻ�Է��ر��ķ�chunked����ʱ����*/
	
	pstHttpRsp->stRspHead.iRspHeadPairNum = 0;
	
	pTmpST = sHttpRspBuf;
	pTmpED = strstr(pTmpST, "\r\n\r\n");
	/*��Ӧ����*/
	pRspBody = pTmpED + 4;
	/*��Ӧͷ*/
	memset(rspHeadBuf, 0x00, sizeof(rspHeadBuf));
	HtMemcpy(rspHeadBuf, pTmpST, pTmpED-pTmpST);
	/*"HTTP/1.1 200 OK"*/
	pTmpST = rspHeadBuf;
	pTmpST = _TopCfg_LTrim(pTmpST);
	pTmpST += 8;
	pTmpST = _TopCfg_LTrim(pTmpST);
	pTmpED = strstr(pTmpST, " ");
	if(pTmpED == NULL){
		return (-1);	
	}
	memset(tempBuf, 0x00, sizeof(tempBuf));
	HtMemcpy(tempBuf, pTmpST, pTmpED-pTmpST);
	pstHttpRsp->stRspHead.iHttpStatus = atoi(tempBuf);
	pTmpST = _TopCfg_LTrim(pTmpED);
	pTmpED = strstr(pTmpST, "\r\n");
	if(pTmpED == NULL){
		return (-1);	
	}
	HtMemcpy(pstHttpRsp->stRspHead.sHttpStatusDesc, pTmpST, pTmpED-pTmpST);
	/*��ʼ������ֵ��*/
	pTmpST = pTmpED + 2;
	pTmpST = _TopCfg_LTrim(pTmpED);

	while((pTmpED = strstr(pTmpST, "\r\n")) != NULL){
		memset(tempBuf, 0x00, sizeof(tempBuf));
		HtMemcpy(tempBuf, pTmpST, pTmpED-pTmpST);
/*		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "pair[%s]", tempBuf);  */
		pTmpST = pTmpED + 2;
		
		pTmpED = strstr(tempBuf, ":");
		if(pTmpED == NULL){
			return (-1);	
		}
		HtMemcpy(pstHttpRsp->stRspHead.stRspHeadPairs[pstHttpRsp->stRspHead.iRspHeadPairNum].Key, tempBuf, pTmpED-tempBuf);
		HtSprintf(pstHttpRsp->stRspHead.stRspHeadPairs[pstHttpRsp->stRspHead.iRspHeadPairNum].Value,"%s",_TopCfg_LTrim(pTmpED+1));
		pstHttpRsp->stRspHead.iRspHeadPairNum++;
	}
	/*���ļ�ֵ��*/
	pTmpED = strstr(pTmpST, ":");
	if(pTmpED == NULL){
		return (-1);	
	}
	HtMemcpy(pstHttpRsp->stRspHead.stRspHeadPairs[pstHttpRsp->stRspHead.iRspHeadPairNum].Key, pTmpST, pTmpED-pTmpST);
	HtSprintf(pstHttpRsp->stRspHead.stRspHeadPairs[pstHttpRsp->stRspHead.iRspHeadPairNum].Value,"%s",_TopCfg_LTrim(pTmpED+1));
	pstHttpRsp->stRspHead.iRspHeadPairNum++;
	
	for( i = 0; i < pstHttpRsp->stRspHead.iRspHeadPairNum; i++) {   
Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Key [%s]", pstHttpRsp->stRspHead.stRspHeadPairs[i].Key);
Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Vlaue [%s]", pstHttpRsp->stRspHead.stRspHeadPairs[i].Value);
        if(_XML_cmpStrIgCase(pstHttpRsp->stRspHead.stRspHeadPairs[i].Key, "Transfer-Encoding") == 0
            &&  _XML_cmpStrIgCase(pstHttpRsp->stRspHead.stRspHeadPairs[i].Value, "chunked") == 0){
            isChunked = 1;    
        }
        if(_XML_cmpStrIgCase(pstHttpRsp->stRspHead.stRspHeadPairs[i].Key, "Content-Length") == 0){
			nExistContentLen = 1;
            nRespBodyLen = atoi(pstHttpRsp->stRspHead.stRspHeadPairs[i].Value);
        }
    }
	
	/*������Ӧ������*/
	if(isChunked){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Chunked Response Mesg");
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "strlen(pRspBody) = %d", strlen(pRspBody));
        if(strlen(pRspBody) <= 0) {
        	/*Receive Mesg Again*/
			Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Begin To Call TopSocketClientRecvMesg...");
            memset(sHttpChunkedMesg, 0x00, sizeof(sHttpChunkedMesg));
            llResult = TopSocketClientRecvMesg(sHttpChunkedMesg, HTTP_PRE_RECV_LENGTH);
            Top_HtDebugString(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sHttpChunkedMesg, llResult);

            if(llResult < 0){
                Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientRecvMesg  Failed");
                return (-1);
            }
            Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientRecvMesg  Success");

            pRspBody = sHttpChunkedMesg;
        } 
		/*����chunked����*/
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Begin to parseChunkedMesg...");
		if(parseChunkedMesg(pRspBody, pstHttpRsp->sRspBody, sizeof(pstHttpRsp->sRspBody))){
			Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "parseChunkedMesg Failed");
			return (-1);
		} else {
			return 0;
		}
	} else {
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "NOT Chunked Response Mesg");

		if(!nExistContentLen) {
        	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR,__FILE__,__LINE__,"��Ӧ���ĸ�ʽ����ȷ,û�б��ĳ���Content-Length!");
        	return (-1);
		}
		
		if(nRespBodyLen == 0) {
			return 0;
		}
        
		if(nRespBodyLen >= sizeof(pstHttpRsp->sRspBody)) {
        	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "��Ӧ���ĵĳ���[%d]��С��Ԥ�����BUF����[%d]", nRespBodyLen, sizeof(pstHttpRsp->sRspBody));
        	return (-1);
        }
		
		if(strlen(pRspBody) >= nRespBodyLen) {
			HtMemcpy(pstHttpRsp->sRspBody, pRspBody, nRespBodyLen);
			return 0;
		}
        
        HtMemcpy(pstHttpRsp->sRspBody, pRspBody, strlen(pRspBody));
        nRespBodyLen -= strlen(pRspBody);
        pRspBody = pstHttpRsp->sRspBody + strlen(pRspBody);
        
        while(1) {
        	/*Receive Mesg Again*/
        	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Begin To Call TopSocketClientRecvMesg...");
            memset(sHttpChunkedMesg, 0x00, sizeof(sHttpChunkedMesg));
            llResult = TopSocketClientRecvMesg(sHttpChunkedMesg, HTTP_PRE_RECV_LENGTH);
            Top_HtDebugString(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sHttpChunkedMesg, llResult);

            if(llResult < 0){
                Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientRecvMesg  Failed");
                return (-1);
            }
            Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientRecvMesg  Success");
            
            HtMemcpy(pRspBody, sHttpChunkedMesg, llResult);
            pRspBody += llResult;
            nRespBodyLen -= llResult;
            if(nRespBodyLen <= 0) {
            	break;
            }
            
        }
        
        return 0;
	}
	
	return 0;
}


int TopHttpCall(char *sSoapCfgName, TopHttpRequest *pstHttpReq, TopHttpResponse *pstHttpRsp)
{
	int  llResult;
	char sHttpReqMesg[HTTP_PRE_RECV_LENGTH+1];
	char sHttpRspMesg[HTTP_PRE_RECV_LENGTH+1];
	
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TopHttpCall(%s) Begin", sSoapCfgName);

	memset(sHttpReqMesg, 0x00, sizeof(sHttpReqMesg));
	memset(sHttpRspMesg, 0x00, sizeof(sHttpRspMesg));

	if(TopHttpClientHeadInit(&pstHttpReq->stReqHead, sSoapCfgName)){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call TopHttpClientHeadInit() Failed");
		return (-1);
	}

	HttpRequestTrace(pstHttpReq);

	PackHttpReqMesg(pstHttpReq, sHttpReqMesg);
	/*Trace
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "\n%s\n%s\n%s\n",
						"=====================Http Request Message B======================",
						sHttpReqMesg,
						"=====================Http Request Message E======================"
						);
	*/

	if(TopSocketClientInit(pstHttpReq->stReqHead.stHttpUrl.HttpServIP, pstHttpReq->stReqHead.stHttpUrl.HttpServPort)){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientInit  Failed");
		return (-1);
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientInit  Success");

	if(TopSocketClientConnect()){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientConnect  Failed");
		return (-1);
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientConnect  Success");

	if(TopSocketClientSendMesg(sHttpReqMesg, strlen(sHttpReqMesg))){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientSendMesg  Failed");
		TopSocketClientDisConnect();
		return (-1);
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientSendMesg  Success");

	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Begin To Call TopSocketClientRecvMesg...");
	memset(sHttpRspMesg, 0x00, sizeof(sHttpRspMesg));
	llResult = TopSocketClientRecvMesg(sHttpRspMesg, HTTP_PRE_RECV_LENGTH);
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "TopSocketClientRecvMesg  End[%d]", llResult);
	if(llResult < 0){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "TopSocketClientRecvMesg  Failed");
		TopSocketClientDisConnect();
		return (-1);
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "TopSocketClientRecvMesg  Success[%s]", sHttpRspMesg);
	
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ParseRespMesg  Begin...");

	if(ParseRespMesg(sHttpRspMesg, pstHttpRsp)){
		Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ParseRespMesg  Failed");
		TopSocketClientDisConnect();
		return (-1);
	}
	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ParseRespMesg  Success");

	HttpResponseTrace(pstHttpRsp);

	TopSocketClientDisConnect();

	return 0;
}


/**����������ȡIP**/ 
int TopGetHostIpByDomain(char *sSvrDomainName, char *sSvrIpAddr, int nIpLen)
{
    char   **pptr;
    struct hostent *hptr = NULL;
    char   str[32];
    const  char   *pNtopRet = NULL;

    if((hptr = gethostbyname(sSvrDomainName)) == NULL)
    {
    	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call gethostbyname(%s) Failed!", sSvrDomainName);
        return (-1);
    }

    switch(hptr->h_addrtype)
    {
        case AF_INET:
        case AF_INET6:
            pNtopRet = inet_ntop(hptr->h_addrtype, hptr->h_addr, sSvrIpAddr, nIpLen);
            if(pNtopRet == NULL) {
            	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call inet_ntop Error! errno=[%d]!", errno);
            	return (-1);
            }
        	break;
        default:
        	Top_HtLog(sHttpCliLogName, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "unknown address type[%d]!", hptr->h_addrtype);
            return (-1);
    }

    return 0;
}
