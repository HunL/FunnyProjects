/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: C001Comm.c                                                  */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*                                                                           */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Comm/CommPCS/C001Comm.c,v 1.1.1.1 2011/08/19 10:55:51 ctedev Exp $";

#include "C001Comm.h"

#define NCMaxAddrL                      15
#define LCTrue                          1
#define NCMaxTcpTpduHdrL                30

#define C_TCP_MSG_LEN_IN_BIN(x)         (x == 'B')

int 	lCPickParam();
void  	vCHandleChildDie();
void  	vCPortHandleClient(short);
void  	vCPortHandleServer(short);
void 	vCTcpSndEcho();
int 	nCConnectSocket(unsigned short, char *);
void  	vCQuit();
int 	nCCreatSocket(unsigned short, short);
int 	nCConnectSocket(unsigned short, char *);
void  	vCKill();
void  	vCRestart(int);
void  	vCTcpSnd();
void  	vCTcpRcv(short);
void	vCTerminate();

typedef struct {
    int                                 hSocketId;
    unsigned short						nPortNum;
    char                               	saLocAddr[NCMaxAddrL + 1];
    char                               	saRemAddr[NCMaxAddrL + 1];
} lpiListenPortInfDef;

pid_t									gpidtMainPid;
short                                   gnGoodPortN;
int                                   	glRcvSrvId;
short                                   giRcvSrvX;
int                                   	glSndSrvId;
pid_t                                   gpidtFatherPid;
short                                   gnMaxPortN;
short                                   gnMaxHostN;
pid_t                                   gpidtaSonPid[NCMaxPortN];
short                                   gnSonN;
lpiListenPortInfDef                     glpiaPort[NCMaxPortN];
int										ghDataSocket;
pid_t                                   gpidtSubPid;
struct sockaddr_in						gsaddrAccept;
char									gsTcpMsgLenType;
short                                   gnTcpMsgLenL = 4;
short                                   gnTcpTpduHdrL;
short                                   gnTimeOver;
short									gnDoRestart;

char									gsSrvId[SRV_ID_LEN+1];
char									gsToSrvId[SRV_ID_LEN+1];
char									gsSrvSeq[SRV_SEQ_ID_LEN+1];
char									gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq								gatSrvMsq[SRV_MSQ_NUM_MAX];
Tbl_srv_inf_Def							tTblSrvInf;
char                                    gsLineIndex[2];

int main( int argc, char** argv) 
{
	/*
    short			liX,liXX;
	*/
    short			liX;
	int				nReturnCode;
	char			*lspTmp;
    gpidtMainPid = 0;
    gnGoodPortN = 0;
  printf("argc:%d -[%s]-[%s]-[%s]-[%s]\n",argc,argv[0],argv[1],argv[2],argv[3]);
	if(argc < 4)
	{
		printf("Usage11:%s srvid seq tosrvid\n", argv[0]);
		exit(-1);
	}

	strcpy(gsSrvId, argv[1]);
	strcpy(gsSrvSeq, argv[2]);
	strcpy(gsToSrvId, argv[3]);

	/* connect to database */
	nReturnCode = DbsConnect ();
	if (nReturnCode)
	{
		printf("CommPCS nReturnCode[%d] LINE[%d]\n", nReturnCode, __LINE__);
		exit(-2);
	}

    /* get log file name from tbl_srv_inf */
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nReturnCode)
	{
		printf("CommPCS nReturnCode[%d] LINE[%d]\n", nReturnCode, __LINE__);
		DbsDisconnect ();
		exit(-2);
	}

    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_id, gsSrvSeq);

    /* init msg queue */
    memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
    nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d", nReturnCode);
		DbsDisconnect ();
		exit(-3);
    }

    if((gpidtFatherPid = getpid()) == -1) 
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "getpid error, %d", errno);
		DbsDisconnect ();
        exit(-4);
    } /* end of if */
    gpidtMainPid = gpidtFatherPid;

    memset(gsLineIndex, 0, sizeof(gsLineIndex));
    strcpy (gsLineIndex, getenv(SAMEnvCommLineCfgKey));
    
    if((nReturnCode = lCPickParam())) 
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "lCPickParam error, [%d][%d]", nReturnCode, errno);
		DbsDisconnect ();
        exit(-5);
    } /* end of if */

    if((lspTmp = getenv(
                    SAMEnvCommTimeOver)) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "getenv SAMEnvCommTimeOver error, %d", errno);
		DbsDisconnect ();
        exit(-6);
    } /* end of if */
    if(((gnTimeOver = atoi(
                            lspTmp)) < 0))
	{ 
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "atoi(gnTimeOver) error, %d", errno);
		DbsDisconnect ();
        exit(-7);
    } /* end of if */

    if(sigset(
          SIGCLD,
          vCRestart) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGCLD error, %d", errno);
		DbsDisconnect ();
        exit(-8);
    } /* end of if */

	if(sigset(
			SIGUSR2,
			vCQuit) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGUSR2 error, %d", errno);
		DbsDisconnect ();
		exit(-9);
	} /* end of if */

	if(sigset(
			SIGTERM,
			vCTerminate) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);
		DbsDisconnect ();
		exit(-10);
	} /* end of if */

    while( 1 ) {
    	for(liX = 0; liX < gnMaxPortN; liX++)
        	gpidtaSonPid[liX] = -1;
    	gnSonN = 0;

		gnDoRestart = 0;
		sighold(SIGCLD);

        for(liX = 0; liX < gnMaxPortN ; liX++) {
        	if((gpidtMainPid = fork()) == -1) {
                exit(-16);
            } /* end of if */

            if(gpidtMainPid == 0) 
			{
				if((liX % 2) == 0)
				{
					/***************************
					nReturnCode = DbsConnect ();
					if (nReturnCode)
					{
        				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"Child Connect DB nReturnCode[%d]", nReturnCode);
						exit(-2);
					}
					DbsDisconnect ();
					***************************/
					vCPortHandleServer(liX);
				}
				else
				{
					/*************************
					nReturnCode = DbsConnect ();
					if (nReturnCode)
					{
        				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"Child Connect DB nReturnCode[%d]", nReturnCode);
						exit(-2);
					}
					DbsDisconnect ();
					*************************/
					vCPortHandleClient(liX);
				}
            }
            else {
                gpidtaSonPid[liX] = gpidtMainPid;
                gnSonN++;
            } /* end of if */
            
            sleep (1);
        }  /* end of for */

		sigrelse(SIGCLD);

		while(!gnDoRestart) pause();
    } /* end of while */

	DbsDisconnect ();

    exit(-17);
} /* end of main */

int lCPickParam() 
{
	/*
	short				lnLoop;
	*/
	Tbl_line_cfg_Def	tTblLineCfg;
	char				*lspTmp;

	gnMaxPortN = 0; 

    memset(
       &tTblLineCfg,
       0,
       sizeof(tTblLineCfg));

    if((lspTmp = getenv(
                    SAMEnvCommLineCfgKey)) == NULL) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call getenv(SAMEnvCommLineCfgKey, error %d", errno);
		return -1;
	}
    if((tTblLineCfg.usage_key = atoi(
                                      lspTmp)) < 0) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Call atoi(tTblLineCfg.usage_key), error %d", errno);
		return -2;
	}

    memcpy(
       &tTblLineCfg.srv_id[0],
       &gsSrvId[0],
       SRV_ID_LEN);

    DbsLINECFG(
       DBS_CURSOR,
       &tTblLineCfg);

    if(DbsLINECFG(
          DBS_OPEN,
          &tTblLineCfg))
        return -3;

    while(DbsLINECFG(
             DBS_FETCH,
             &tTblLineCfg) == 0) {
		memset( &glpiaPort[gnMaxPortN].saLocAddr[0], 
				0, 
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saLocAddr[0], 
				&tTblLineCfg.local_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saRemAddr[0], 
				&tTblLineCfg.remote_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saRemAddr));

        glpiaPort[gnMaxPortN++].nPortNum = tTblLineCfg.in_sock_num; 
		memset( &glpiaPort[gnMaxPortN].saLocAddr[0], 
				0, 
				sizeof(glpiaPort[gnMaxPortN].saLocAddr));
        memcpy( &glpiaPort[gnMaxPortN].saLocAddr[0], 
				&tTblLineCfg.remote_addr[0],
				sizeof(glpiaPort[gnMaxPortN].saRemAddr));
        glpiaPort[gnMaxPortN++].nPortNum = tTblLineCfg.out_sock_num; 
    } /* end of for */

    if(DbsLINECFG(
          DBS_CLOSE,
          &tTblLineCfg))
        return -4;

    return 0;
} /* end of lCPickParam */

void vCPortHandleClient(
        short                           viPortX) {

	/*
    short                               liX;
	*/
    int                               llResult;
    int                                lsckltAddrLen;

	if(sigset( SIGTERM, SIG_IGN) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);
		exit(-21);
	} /* end of if */

	if(sigset(
			SIGALRM,
			vCTcpSndEcho) == SIG_ERR) {
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGALRM error, %d", errno);
		exit(-22);
	} /* end of if */

    lsckltAddrLen = sizeof(gsaddrAccept);
	while ((
		ghDataSocket =
			nCConnectSocket(glpiaPort[viPortX].nPortNum,
				glpiaPort[viPortX].saLocAddr)) < 0)
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "connect socket error, %d", errno);
		sleep(5);
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
			"connect ip[%s],port[%d] ok socket[%d] ",glpiaPort[viPortX].saLocAddr, 
			glpiaPort[viPortX].nPortNum, ghDataSocket);
			
	DbsConnect();
	llResult = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_CONNECT);
	if (llResult)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d, gsLineIndex[%2.2s]", llResult, gsLineIndex);
	}
	DbsDisconnect();
	
    vCTcpSnd();
} /* end of vCPortHandle */

void vCPortHandleServer(short  viPortX) 
{
    int                               lsckltAddrLen;

	if(sigset( SIGTERM, SIG_IGN) == SIG_ERR) {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);
		exit(-31);
	} /* end of if */

    lsckltAddrLen = sizeof(gsaddrAccept);

	while (
		(ghDataSocket =
			nCCreatSocket(glpiaPort[viPortX].nPortNum,viPortX)) < 0)
	{
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nCEstablishBind  error, %d,ret %d, %s", errno, ghDataSocket,strerror(errno));
		sleep(5);
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
			"listen socket[%d] ok", ghDataSocket);

	vCTcpRcv(viPortX);
} /* end of vCPortHandle */

void vCTcpSnd() 
{
	char					sMsgInBuf[NCMaxMsgBufLen + 1];
	int						lnMsgInLen;
	char					sMsgOutBuf[NCMaxMsgBufLen + 1];
	short					lnMsgOutLen;
	short					nReturnCode;
	char                    sTxnNum[4+1];

    for(;;) {
		lnMsgInLen = NCMaxMsgBufLen;
        /*alarm(gnTimeOver);*/
        nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, 
							&lnMsgInLen, sMsgInBuf);
        if (nReturnCode)
        {
            /*alarm(0);*/
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
            {
        		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"MsqRcv error, %d", errno);
				DbsConnect();
				nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
				if (nReturnCode)
				{
					HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d", nReturnCode);
				}
				DbsDisconnect();
				vCQuit();
            }
            else
			{
                continue;
			}
        }
		/*alarm(0);*/
   		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"MsqRcv ok len[%d]", lnMsgInLen);

		lnMsgInLen = lnMsgInLen-(SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+FLD_TXN_NUM_LEN);
		if(lnMsgInLen > 1024)
		{
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqRcv ,msg len error,  lnMsgInLen=[%d]", lnMsgInLen);
		    continue;
		}
		memset(&sMsgOutBuf[0],' ',sizeof(sMsgOutBuf));
		/*sprintf(&sMsgOutBuf[0],"%04d",lnMsgInLen);*/
		memcpy(&sMsgOutBuf[0], "1284", 4);
		memcpy(&sMsgOutBuf[4],&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN],FLD_GF_HEADER);
		memcpy(&sMsgOutBuf[260],&sMsgInBuf[SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+FLD_TXN_NUM_LEN],lnMsgInLen);
		lnMsgOutLen = 4+256+1024;
        if((nReturnCode = nCSocketSnd( 
									ghDataSocket, 
									&sMsgOutBuf[0], 
									&lnMsgOutLen)))
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"socket snd error, %d", errno);
			DbsConnect();
			nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_DISCONNECT);
			if (nReturnCode)
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d", nReturnCode);
			}
			DbsDisconnect();
            exit(-29);
        }
       	HtLog ("Snd.1701.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"socket[%d] snd ok len[%d]", ghDataSocket,lnMsgOutLen);
	    HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sMsgOutBuf, lnMsgOutLen);
    } /* end of for */
} /* end of vCTcpSnd */

void vCTcpRcv(
        short                           vnWaitTime) {

    short					lnDataL;
    char					lsaMsgLen[NCMaxTcpMsgLenL+1];
	char					sMsgInBuf[NCMaxMsgBufLen + 1];
	short					lnMsgInLen;
	char					sMsgOutBuf[NCMaxMsgBufLen + 1];
	short					lnMsgOutLen;
	int						nReturnCode;
	char                    sCurrentTime[15];
	char                    sTxnNum[4+1];
	char                    sRspCode[2+1];

    for(;;) {
        lnDataL = gnTcpMsgLenL;
		memset(&lsaMsgLen[0],0,sizeof(lsaMsgLen));
        if((nReturnCode = nCSocketRcv(
								ghDataSocket,
								&lsaMsgLen[0],
								&lnDataL,
								0))) 
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket[%d]rcv error, %d, [%s]",ghDataSocket, errno, strerror(errno));
            sleep(vnWaitTime);
			vCQuit();
        }
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"socket rcv ok [%d] len:[%d] buf:[%s]", 
				nReturnCode, lnDataL, lsaMsgLen);

		if(lnDataL<=0)
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket rcv len=%d", lnDataL);
            sleep(vnWaitTime);
			vCQuit();
		}

        /*if( memcmp(&lsaMsgLen[0],"0000",4) == 0 ) 
		{
            continue;
        }*/

		lnMsgInLen = atoi(lsaMsgLen)-4;
		memset(sMsgInBuf,0,sizeof(sMsgInBuf));
        if((nReturnCode = nCSocketRcv(
							ghDataSocket,
							&sMsgInBuf[0],
							&lnMsgInLen,
							0))) 
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket rcv error, %d", errno);
            exit(-34);
        }
		HtLog ("Rcv.1701.log", HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"socket rcv ok [%d] len:[%d]", nReturnCode, lnMsgInLen);
		HtDebugString(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, sMsgInBuf, lnMsgInLen);
				
        if( memcmp(&sMsgInBuf[0],"ECS         ZZZZZZZZ",20) == 0 ) 
		{
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "echo test");
            continue;
        }
        
        /* ��ȡ��ǰ���ձ���ʱ�� */
        CommonGetCurrentTime (sCurrentTime);
        
		memset(sMsgOutBuf, ' ', sizeof(sMsgOutBuf));
		memcpy(sMsgOutBuf, gsSrvId, SRV_ID_LEN);
		memcpy(
		        sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN, 
		        sCurrentTime, FLD_TIME_STAMP_LEN);
		memcpy(
				sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN,
				sMsgInBuf, FLD_GF_HEADER);
				
        memset(sTxnNum, 0, sizeof(sTxnNum));
        memset(sRspCode, 0, sizeof(sRspCode));
        memcpy(sTxnNum, sMsgInBuf+FLD_GF_HEADER+56, 4);
        memcpy(sRspCode, sMsgInBuf+FLD_GF_HEADER+190, 2);
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "rsp txnnum, [%s]", sTxnNum);
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "sRspCode, [%s]", sRspCode);
        
#if 0
        /* test */
        /*if(memcmp(sTxnNum, "5366", 4) == 0)
            continue;*/
        if(memcmp(sTxnNum, "1394", 4) == 0)
            memcpy(sMsgInBuf+FLD_GF_HEADER+190, "01", 2);
        /* test */
#endif
        
        memcpy(
				sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,
				sTxnNum, 4);
		memcpy(
				sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+FLD_TXN_NUM_LEN,
				sMsgInBuf+FLD_GF_HEADER, (lnMsgInLen-FLD_GF_HEADER));
		lnMsgOutLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+lnMsgInLen;

        /*nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, lnMsgOutLen, sMsgOutBuf);*/
        nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, 840, sMsgOutBuf);
        if (nReturnCode)
        {
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"MsqSnd ToSrvId[%s] error [%d][%d]", 
					gsToSrvId, nReturnCode, errno);
			sleep(1);
            continue;
        }
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
				"MsqSnd ToSrvId[%s] ok", gsToSrvId);
    } /* end of for */
} /* end of vCTcpRcv */

int nCConnectSocket(unsigned short Port, char *Ip_addr)
{
	struct sockaddr_in   Sin;
	/*
	int   Socket_id, Flag, Error, RetryTimeSap = 2, nRetryFlag = 0;
	*/
	int   Socket_id, RetryTimeSap = 2, nRetryFlag = 0;

	memset(&Sin, 0, sizeof(Sin));
	Sin.sin_port = htons(Port);
	Sin.sin_family = AF_INET;
	Sin.sin_addr.s_addr = inet_addr(Ip_addr);

	while(1)
	{
		while ((Socket_id = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "socket, %d", errno);
			if (nRetryFlag++ == RETRYNUM)
			{
				if ( RetryTimeSap<100) RetryTimeSap += 2;
				nRetryFlag = 0;
			}
			sleep(RetryTimeSap);
		}

		if (connect(Socket_id, (struct sockaddr *)&Sin, sizeof(Sin)) < 0)
		{
        	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "connect error[%s][%d], %d",Ip_addr , Port, errno);
			close(Socket_id);
			if (errno == ECONNREFUSED)
			{
				sleep(5);
				continue;
			}
			sleep(30);
			continue;
		}

		break;
	}

	return(Socket_id);
}

int nCCreatSocket(unsigned short Port,short viPortX)
{
	int   RetryTimeSap = 2;
	int   Socket_id, nRetryFlag = 0;
	struct sockaddr_in   Client;
	int   Socket_id_new;
	int   Client_len= sizeof( Client);
	char   lsTmp[NCMaxAddrL + 2];
    int                               llOpt;
    struct linger					lslngrOpt;
    char   sClientAddr[INET_ADDRSTRLEN+1];
	/*
    struct sockaddr_in				lsaddrinBind;
	*/

	memset(&Client,0, sizeof(Client));
	Client.sin_port = htons(Port);
	Client.sin_family = AF_INET;
	Client.sin_addr.s_addr = inet_addr("0.0.0.0");

	while ((Socket_id = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
       	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"socket error, %d", errno);
		if (nRetryFlag++ == RETRYNUM)
		{
			if ( RetryTimeSap<100) RetryTimeSap += 2;
			nRetryFlag = 0;
		}
		sleep(RetryTimeSap);
	}
	RetryTimeSap = 2;
	nRetryFlag = 0;

	llOpt = LCTrue;
	if(setsockopt(
              Socket_id,
              SOL_SOCKET,
              SO_KEEPALIVE,
              &llOpt,
              sizeof(llOpt))) {
            close( Socket_id);
            return errno;
	} /* end of if */

	lslngrOpt.l_onoff = LCTrue;
	lslngrOpt.l_linger = LCTrue;
	if(setsockopt(
              Socket_id,
              SOL_SOCKET,
              SO_LINGER,
              &lslngrOpt,
              sizeof(lslngrOpt))) {
            close(Socket_id);
            return errno;
        } /* end of if */

        llOpt = LCTrue;
        if(setsockopt(
              Socket_id,
              SOL_SOCKET,
              SO_REUSEADDR,
              &llOpt,
              sizeof(llOpt))) {
            close(Socket_id);
            return errno;
        } /* end of if */

	while (bind(Socket_id, (struct sockaddr *)&Client, sizeof(Client)) < 0)
	{
		if (nRetryFlag++ == RETRYNUM)
		{
			if ( RetryTimeSap<100) RetryTimeSap += 2;
			nRetryFlag = 0;
		}
		sleep(RetryTimeSap);
	}

	listen(Socket_id, 5);

	Client_len = sizeof(Client);
	while(1)
	{
		Socket_id_new = accept(Socket_id, ( struct sockaddr *)&Client, &Client_len);
		if(Socket_id_new <= 0)
		{
       		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"accept socket id[%d] error, %d", Socket_id, errno);
			close(Socket_id);
			return(-1);
		}
		
		/* ����HA���ͻ�������������boot��ַ����server��ַ, saRemAddr��ΪsaLocAddr */
		memset(lsTmp, 0, sizeof(lsTmp));
		memcpy(lsTmp,
			   glpiaPort[viPortX].saLocAddr,
			   sizeof(glpiaPort[viPortX].saLocAddr));

		CommonRTrim(lsTmp);
		
		/* add by wuzw inet_ntop-for linux64*/
		memset(sClientAddr, 0, sizeof(sClientAddr));
		inet_ntop(AF_INET, &Client.sin_addr, sClientAddr, sizeof(sClientAddr));
        /* add end */
                
		if(strcmp(lsTmp, sClientAddr) != 0 && 
		   memcmp(lsTmp, "0.0.0.0", 7) != 0)
		{
			close(Socket_id_new);
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"��ȷIP[%s]����", lsTmp);
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"���棺�յ��Ƿ�IP[%s]����", sClientAddr);
			sleep(1);
			continue;
		}

		break;
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,	"�յ�IP����OK %s,OK", sClientAddr); 
	
	close(Socket_id);
	return(Socket_id_new);
}

void vCQuit()
{
	close(ghDataSocket);

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCQuit");

	exit(-30);
}

void vCRestart(int iTmp)
{
	sigset(SIGCLD, SIG_IGN);
	close(ghDataSocket);

    /***************
	DbsDisconnect ();
    ***************/

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCRestart");

	vCKill();
	sleep(10);
	sigset(SIGCLD, vCRestart);
	gnDoRestart = 1;
}

void vCKill ()
{
	int   liX;
	int		nReturnCode;

	for(liX = 0; liX < gnMaxPortN; liX++)
	{
		if (gpidtaSonPid[liX] > 0)
			kill(gpidtaSonPid[liX], SIGUSR2);
	}

    DbsConnect();
	nReturnCode = LineStateChg (gsSrvId, gsLineIndex, LINE_STATE_RESET);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "LineStateChg error, %d", nReturnCode);
	}
	DbsDisconnect();
	
/* on AIX 5.2 (130.252.89.203), wait is blocked and never returns, so waitpid is used instead
	while(wait((int *)0) > 0)
*/
	sleep (1);
	while (waitpid( -1, NULL, WNOHANG) > 0)
	{
		;
	}
}

void vCTcpSndEcho() 
{
	int		llResult;
	short	lnDataL = 4;

	HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "vCTcpSndEcho Begin");
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ghDataSocket, %d", ghDataSocket);
    if((llResult = nCSocketSnd(ghDataSocket,"0000",&lnDataL)))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCTcpSndEcho error, %d", errno);
		close(ghDataSocket);
		exit(-1);
    }
    return;
}

void vCTerminate()
{
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "vCTerminate");
	sigset(SIGCLD, SIG_IGN);
	vCKill();
	exit (0);
}

