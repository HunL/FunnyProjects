/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: C800RcvSnd.c                                                */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*                                                                           */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Comm/ComCup/C800RcvSnd.c,v 1.1.1.1.4.1 2011/08/28 13:21:47 ctedev Exp $";

#include <stdlib.h>
#include <errno.h>

#define SACEnvCommTimeout               "TL_COMM_TIMEOUT"

#define LCMaxTimeout                    20
#define LCTcpRcvFlg                     0
#define LCTcpSndFlg                     0


#define NCRcvFlgReturnAfterData         1

short nCSocketRcv(
         int                            vhDataSocket,
         void*                          vvpTcpData,
         short*                         vnpExpDataL,
         short                          vnRcvFlg) {

    short                               lnDataL;
    short                               lnTotalDataL;
    char*                              lspTcpData;

    lspTcpData = vvpTcpData;

    lnTotalDataL = 0;
    while(*vnpExpDataL > lnTotalDataL) {
        if((lnDataL = recv(
                         vhDataSocket,
                         lspTcpData,
                         *vnpExpDataL - lnTotalDataL,
                         LCTcpRcvFlg)) <= 0) {
            *vnpExpDataL = lnTotalDataL;
            return errno;
        } /* end of if */
        lnTotalDataL += lnDataL;
        lspTcpData += lnDataL;
        if(vnRcvFlg & NCRcvFlgReturnAfterData) {
            *vnpExpDataL = lnTotalDataL;
            return 0;
        } /* end of if */
    } /* end of while */
    return 0;
} /* end of nCSocketRcv */

short nCSocketSnd(
         int                            vhDataSocket,
         void*                          vvpTcpData,
         short*                         vnpExpDataL) {

    short                               lnDataL;
    short                               lnTotalDataL;
    char*                               lspTcpData;
    static
    unsigned int                        llTimeout = LCMaxTimeout + 1;
    char*                              lspTmp;
    int                               llTmp;

    if(llTimeout > LCMaxTimeout) {
        llTimeout = 0;
        if((lspTmp = getenv(
                        SACEnvCommTimeout)) != NULL) {
            if(((llTmp = atoi(
                            lspTmp)) < 0) ||
               (llTmp > LCMaxTimeout)) {
                llTmp = 0;
            } /* end of if */
            llTimeout = llTmp;
        } /* end of if */
    } /* end of if */

    lspTcpData = vvpTcpData;

    lnTotalDataL = 0;
    alarm(
       llTimeout);

    while(*vnpExpDataL > lnTotalDataL) {
        if((lnDataL = send(
                         vhDataSocket,
                         lspTcpData,
                         *vnpExpDataL - lnTotalDataL,
                         LCTcpSndFlg)) <=0) {
            *vnpExpDataL = lnTotalDataL;
            alarm(
               0);
            return errno;
        } /* end of if */
        lnTotalDataL += lnDataL;
        lspTcpData += lnDataL;
    } /* end of while */
    alarm(
       0);
    return 0;
} /* end of nCSocketSnd */
