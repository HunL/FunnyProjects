#ifndef TL_HDR_FILE_C800RCVSND
#define TL_HDR_FILE_C800RCVSND

#include <errno.h>
#include <stdlib.h>

#define SACEnvCommTimeout               "TL_COMM_TIME_OUT"

#define LCMaxTimeout                    20
#define LCTcpRcvFlg                     0
#define LCTcpSndFlg                     0

#define NCRcvFlgReturnAfterData         1

#endif /* TL_HDR_FILE_C800RCVSND */
