#include "C800RcvSnd.h"

static char * id = "$Id: C800RcvSnd.c,v 1.1.1.1 2011/08/19 10:55:51 ctedev Exp $";

int nCSocketRcv(
         int                            vhDataSocket,
         void*                          vvpTcpData,
         int*                         vnpExpDataL,
         int                          vnRcvFlg) {

    int                               lnDataL;
    int                               lnTotalDataL;
    char*                              lspTcpData;

    lspTcpData = vvpTcpData;
    lnTotalDataL = 0;
    while(*vnpExpDataL > lnTotalDataL) {
        if((lnDataL = recv(
                         vhDataSocket,
                         lspTcpData,
                         *vnpExpDataL - lnTotalDataL,
                         LCTcpRcvFlg)) <= 0) {
            *vnpExpDataL = lnTotalDataL;
            return -1;
        } /* end of if */
        lnTotalDataL += lnDataL;
        lspTcpData += lnDataL;
        if(vnRcvFlg & NCRcvFlgReturnAfterData) {
            *vnpExpDataL = lnTotalDataL;
            return 0;
        } /* end of if */
    } /* end of while */
    return 0;
} /* end of nCSocketRcv */

int nCSocketSnd(
         int                            vhDataSocket,
         void*                          vvpTcpData,
         int*                         vnpExpDataL) {

    int                               lnDataL;
    int                               lnTotalDataL;
    char*                               lspTcpData;
    static
    unsigned int                        llTimeout = LCMaxTimeout + 1;
    char*                              lspTmp;
    int                               llTmp;

    if(llTimeout > LCMaxTimeout) {
        llTimeout = 0;
        if((lspTmp = getenv(
                        SACEnvCommTimeout)) != NULL) {
            if(((llTmp = atoi(
                            lspTmp)) < 0) ||
               (llTmp > LCMaxTimeout)) {
                llTmp = 0;
            } /* end of if */
            llTimeout = llTmp;
        } /* end of if */
    } /* end of if */

    lspTcpData = vvpTcpData;

    lnTotalDataL = 0;
    alarm(
       llTimeout);
    while(*vnpExpDataL > lnTotalDataL) {
        if((lnDataL = send(
                         vhDataSocket,
                         lspTcpData,
                         *vnpExpDataL - lnTotalDataL,
                         LCTcpSndFlg)) <=0) {
            *vnpExpDataL = lnTotalDataL;
            alarm(0);
            return -1;
        } /* end of if */
        lnTotalDataL += lnDataL;
        lspTcpData += lnDataL;
    } /* end of while */
    alarm(0);
    return 0;
} /* end of nCSocketSnd */
