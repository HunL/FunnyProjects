/*****************************************************************************/
/*				NCUP -- Shanghai Huateng Software System Inc.			  */
/*****************************************************************************/
/* PROGRAM NAME: CommEsb.c													 */
/* DESCRIPTIONS: The save and forward process server.						*/
/*****************************************************************************/
/*							 MODIFICATION LOG							  */
/* DATE		PROGRAMMER	 DESCRIPTION									*/
/* 2005-04-06  Chen Liang	 Changed for NCUP							   */
/*****************************************************************************/
#include "CommTest.h"

char				gsSrvId[SRV_ID_LEN+1];
char				gsToSrvId[SRV_ID_LEN+1];
char				gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char				gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];

char				gsIpAddr[20];
int					gnPort[2];
int					gnSocketID;
int					gnTimeOut;
int					gnSysError = 0;
char				gsCommEsberr[20 + 1];
char				gsCommEsbNoMH[30 + 1];

static  int Timeout = 0;
jmp_buf Stackbuf;

void HandleExit (int n);
int CommInit(int argc, char **argv);

/* int		nMaxRspCodeMapN = 0, i; */
int   i;
int		nRcvHostLen;
char	saErrHostMsg[FLD_MISC_LEN+1];

/* static Tbl_rsp_code_map_Def tRspCodeMap[1500]; */

int main(int argc, char **argv)
{
	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgTmpBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	char	sSrcSrvId[SRV_ID_LEN+1];
	char	sTimeStamp[FLD_TIME_STAMP_LEN+1],sGfHeader[FLD_GF_HEADER+1];
	int		nReturnCode;
	int 	nMsgInLen;
	int 	nMsgTmpLen;
	int		nMsgOutLen;
	int		nAcctLen;
	int     nLen;
	char	sHostRspCode[5];
	char	sUpTxnCode[5], sDownTxnCode[5];
	char	sUpAcct[21], sDownAcct[21];
	char	sTail[1+1];
	char    sTxnNum[4+1];

	if(argc < 6)
	{
		printf("Usage:%s srvid seq tosrvid ip port\n", argv[0]);
		exit(-1);
	}

	nReturnCode = CommInit(argc, argv);
	if (nReturnCode)
	{
		printf("CommEsb: CommInit error[%d]\n",nReturnCode);
		exit(-2);
	}

	if (sigset(SIGTERM, HandleExit) == SIG_ERR)
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d", errno);

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "CommEsb started");

	while (1)
	{
		memset(sMsgInBuf,0,sizeof(sMsgInBuf));
		nMsgInLen = MSQ_MSG_SIZE_MAX;
		sigrelse (SIGTERM);
		nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, 
								&nMsgInLen, sMsgInBuf);
		sighold (SIGTERM);
		if (nReturnCode)
		{
			if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"MsqRcv error, %d", nReturnCode);
				exit(-3);
			}
			else
				continue;
		}

		memset (sSrcSrvId, 0, sizeof (sSrcSrvId));
		memcpy (sSrcSrvId, sMsgInBuf, SRV_ID_LEN);

		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"received %d byte msg from %s", nMsgInLen, sSrcSrvId);
		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sMsgInBuf, nMsgInLen);

		memset(sTimeStamp,0,sizeof(sTimeStamp));
		memcpy(sTimeStamp,sMsgInBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN,FLD_TIME_STAMP_LEN);
		memset(sGfHeader,0,sizeof(sGfHeader));
		memcpy(sGfHeader,sMsgInBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN,FLD_GF_HEADER);
		memset(sTxnNum,0,sizeof(sTxnNum));
		memcpy(sTxnNum,sMsgInBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER, 4);
		
	/*	return 0;*/
		if(memcmp(sTxnNum, "1363", 4) == 0)
		    return 0;
		    
		sTxnNum[3] ++;
		
		nMsgTmpLen = nMsgInLen-SRV_ID_LEN*2-FLD_MSQ_TYPE_LEN-FLD_TIME_STAMP_LEN-FLD_GF_HEADER;
		
		memset(sMsgTmpBuf,0,sizeof(sMsgTmpBuf));
		memcpy(sMsgTmpBuf,sMsgInBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER,nMsgTmpLen);

		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTimeStamp[%s]", sTimeStamp );
		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sGfHeader[%s]", sGfHeader );
		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sMsgTmpBuf[%s]", sMsgTmpBuf );
		
/*****************************************************************************************************/
		memset(	sMsgOutBuf, ' ', sizeof(sMsgOutBuf));
		memcpy(	sMsgOutBuf, gsSrvId, SRV_ID_LEN);
		/*memcpy(	sMsgOutBuf+SRV_ID_LEN, gsToSrvId, SRV_ID_LEN);*/
		/*memset(	sMsgOutBuf+SRV_ID_LEN*2, ' ', FLD_MSQ_TYPE_LEN);*/
		
		memset(sTimeStamp, 0, sizeof(sTimeStamp));
		CommonGetCurrentTime(sTimeStamp);
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN, sTimeStamp, FLD_TIME_STAMP_LEN);
		
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN, sGfHeader, FLD_GF_HEADER);
		nMsgOutLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER;
		memcpy(	sMsgOutBuf+SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER, sTxnNum, 4);
		nMsgOutLen += 4;
		
		
/*************����Ϊƴ����Ӧ���ĸ�ʽ*****************/

        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nMsgOutLen, 42);
        nMsgOutLen += 42;
        /* �������� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "20110808", 8);
        nMsgOutLen += 8;
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nMsgOutLen, 6);
        nMsgOutLen += 6;
        /* ������ */
        memcpy(	sMsgOutBuf+nMsgOutLen, sTxnNum, 4);
        nMsgOutLen += 4;
        memcpy(	sMsgOutBuf+nMsgOutLen, "  ", 2);
        nMsgOutLen += 2;
        
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nMsgOutLen, 47);
        nMsgOutLen += 47;
        /* ��̨��� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "       ", 7);
        nMsgOutLen += 7;
        /* ���׿��� */
        nLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+4+116;
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nLen, 19);
        nMsgOutLen += 19;
        /* �ʻ���� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "0000059999.99", 13);
        nMsgOutLen += 13;
        /* ������� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "0000029999.99", 13);
        nMsgOutLen += 13;
        /* δ���۴��� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "   ", 3);
        nMsgOutLen += 3;
        /* ������� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "             ", 13);
        nMsgOutLen += 13;
        /* δ����ת�� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "             ", 13);
        nMsgOutLen += 13;
        /* ��Ӧ�� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "00  ", 4);
        nMsgOutLen += 4;
        /* ���ʺ� */
        nLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+4+135;
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nLen, 19);
        nMsgOutLen += 19;
        /* RTV.REF.NUMBER */
        nLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+4+323;
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nLen, 12);
        nMsgOutLen += 12;
        /* MAC */
        memcpy(	sMsgOutBuf+nMsgOutLen, "        ", 8);
        nMsgOutLen += 8;
        /* FILLER */
        memcpy(	sMsgOutBuf+nMsgOutLen, "0000", 4);
        nMsgOutLen += 4;
        /* ת���˺� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "9558990000000000002", 19);
        nMsgOutLen += 19;
        /* ���׻��� */
        nLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+4+289;
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nLen, 3);
        nMsgOutLen += 3;
        /* PROCESS CODE */
        nLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+4+292;
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nLen, 6);
        nMsgOutLen += 6;
        /* BATCH NUMBER */
        nLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+4+298;
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nLen, 5);
        nMsgOutLen += 5;
        /* ���ױ��� */
        memcpy(	sMsgOutBuf+nMsgOutLen, "000", 3);
        nMsgOutLen += 3;
        /* ԭRTV.REF.NO. */
        memcpy(	sMsgOutBuf+nMsgOutLen, "            ", 12);
        nMsgOutLen += 12;
        /* IC�������� */
        memset(	sMsgOutBuf+nMsgOutLen, ' ', 255);
        nMsgOutLen += 255;
        /* �������� */
        nLen = SRV_ID_LEN*2+FLD_MSQ_TYPE_LEN+FLD_TIME_STAMP_LEN+FLD_GF_HEADER+4+651;
        memcpy(	sMsgOutBuf+nMsgOutLen, sMsgInBuf+nLen, 2);
        nMsgOutLen += 2;

		HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"send %d byte msg to %s", nMsgOutLen, gsToSrvId);
		nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, nMsgOutLen, sMsgOutBuf);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"MsqSnd to %s error, %d", gsToSrvId, nReturnCode);
			continue;
		}
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"sMsgTmpBuf[%s]", sMsgTmpBuf);
		
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"send msg to %s", gsToSrvId);
		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,sMsgOutBuf, nMsgOutLen);
	}
}

/*****************************************************************************/
/* FUNC:   int CommInit (int argc, char **argv)							*/
/* INPUT:  argc: ��������													*/
/*		 argv: ����														*/
/* OUTPUT: ��																*/
/* RETURN: 0: �ɹ�, ����: ʧ��											   */
/* DESC:   �������ݿ�, ����ȫ�ֱ���, ��ȡ���в���,						   */
/*		 ��ʼ����Ϣ����													*/
/*****************************************************************************/
int CommInit (int argc, char **argv)
{
	/*
	int				i;
	*/
	int				nReturnCode;
	Tbl_srv_inf_Def	tTblSrvInf;
	/*
	char			*lspTmp;
	*/
	int				lUsageKey;

	/* get server id arg 1; server seq arg 2; to server id arg 3 */
	strcpy(gsSrvId, argv[1]);
	strcpy(gsSrvSeqId, argv[2]);
	strcpy(gsToSrvId, argv[3]);

	strcpy(gsIpAddr, argv[4]);
	
	/****************************
	if(!memcmp(gsSrvSeqId,"1",1))
	****************************/
	if (atoi(gsSrvSeqId) % 2 == 1)
	{
		  gnPort[0] = atoi(argv[5]);
		  gnPort[1] = atoi(argv[6]);
	}
	else
	{
		  gnPort[0] = atoi(argv[6]);
		  gnPort[1] = atoi(argv[5]);
	}

	/* connect to database */
	nReturnCode = DbsConnect ();
	if (nReturnCode) return (nReturnCode);
	
	
	/* get log file name from tbl_srv_inf */
	if (getenv(SRV_USAGE_KEY))
		lUsageKey=atoi (getenv(SRV_USAGE_KEY));
	else
		return -2;

	memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
	tTblSrvInf.usage_key = lUsageKey;
	memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
	nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
	if (nReturnCode)
		return (nReturnCode);

	CommonRTrim(tTblSrvInf.srv_name);
	/****************************************************************
	sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_name, gsSrvSeqId);
	*****************************************************************/
	sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_name, gsSrvSeqId);
	memset(gsCommEsberr , 0 , sizeof(gsCommEsberr));
	strcpy (gsCommEsberr, "EHostCom.log");

	/**add by xcl 20080326**/
	memset(gsCommEsbNoMH,0, sizeof(gsCommEsbNoMH));
	strcpy (gsCommEsbNoMH, "EHostNoMatch.log" );
	/**end**/

	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SVR: %s ID: %s IP: %s PORT1: %d PORT2: %d", 
					   gsSrvId, gsSrvSeqId, gsIpAddr, gnPort[0], gnPort[1]);
	HtLog (gsCommEsberr, -1, __FILE__,__LINE__, "SVR: %s ID: %s IP: %s PORT1: %d PORT2: %d", 
					   gsSrvId, gsSrvSeqId, gsIpAddr, gnPort[0], gnPort[1]);
	/* init msg queue */
	memset ((char *)gatSrvMsq, 0, sizeof (gatSrvMsq));
	nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d", nReturnCode);	  
		return (nReturnCode);
	}

	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"dbuser = %s",getenv(SADBSUserPwdFile) ) ;
	   
	if (getenv("TL_COMM_TIMEOUT"))
		gnTimeOut = atoi (getenv("TL_COMM_TIMEOUT"));
	else
		return -1;
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,"gnTimeOut %d", gnTimeOut);

	/* disconnect db */
	nReturnCode = DbsDisconnect ();
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"DbsDisconnect error, %d", nReturnCode);	  
	}

	return (0);
}

void HandleExit (int n)
{
	HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "CommEsb exits");
	exit( 1 );
}

/*
 * Function Name:  IOTimeOut
 * Parameter 1  :  no		 ������
 */
void IOTimeOut(int no )
{
  Timeout = 1;
  longjmp( Stackbuf, Timeout ); 
}


/*
 * Function Name: tcpOpen 
 * Parameter 1  : hostaddress  ��������IP��ַ
 * Parameter 2  : hostport	 ���������˿ں� 
 * Parameter 3  : retrys	   ������������
 */

int tcpOpen(char *sIpAddr, int nPort, int nRetrys, int nTimeOut)
{
	int	sock;
	struct sockaddr_in remote;

  bzero(&remote, sizeof(remote));
  remote.sin_family = AF_INET;
	remote.sin_addr.s_addr = inet_addr(sIpAddr);
  remote.sin_port = htons(nPort);

	HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "ip %s port %d", sIpAddr, nPort);

	Timeout = 0;
  signal(SIGALRM, IOTimeOut);

  setjmp(Stackbuf);
  if (Timeout)
 	{
 		alarm(0);
 		return -1;
 	}

	while (nRetrys) 
	{
		alarm(nTimeOut); 
			HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "retrys %d", nRetrys);
			if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
					alarm(0);
					if (nRetrys > 0) 
					{	
							nRetrys--;
							continue;
					}
			  return -2;
		}
	
			HtLog(gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "socket ok %d", sock);
	
		if (connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0)
		{
					alarm(0);
					tcpClose(sock);
					if (nRetrys > 0) 
					{	
						nRetrys--;
						continue;
					}
			  return -3;
		}
			alarm(0);
	
		return sock;
	} /* while */
	return -4;
}

/*
 * Function Name: tcpClose 
 * Parameter 1  : sock	  Ҫ�رյ�socket�� 
 */
int tcpClose( sock )
int sock;
{
		if ( fcntl( sock, F_SETFL, FNDELAY ) < 0 )
	  		return( -1 );
		if ( sock != 0 )
	  		shutdown( sock, 2 );

		close( sock );
		return( 0 );
}

/*
 * Function Name:  ReadSock
 * Parameter 1  :  socketid   socket��	 
 * Parameter 2  :  buffer	 ���ܻ�����
 * Parameter 3  :  timeout	��ʱʱ��	
 */
int ReadSock(socketid,buffer,timeout)
int socketid;
register char * buffer;
int  timeout;
{
	
	int num, nLen, I=0,nleft,nread;
	
	char tmp_buf[5], Buf_head[5];
	char tmp_Str[2000], sBody[1024];
	
	Timeout = 0;
	signal(SIGALRM, IOTimeOut);
	alarm( timeout ); 

	setjmp( Stackbuf );
	if ( Timeout )
 	{
 		alarm( 0 );
 		return( -1 );
 	}
	
	memset( tmp_buf, 0x00, sizeof(tmp_buf) );

	num = read(socketid, tmp_buf, 4);
	if ( num == 0 )
	{
 		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "num = 0  ,read len error = %d", errno);
		alarm(0);
 		return (-1);
 	}
 	else  if ( num < 0 )
 	{
 		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "read len error = %d", errno);
		alarm(0);
 		return (-1);
 	}
	else
	   HtDebugString( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, (char *)tmp_buf, (int) 4 ) ;

	memset(Buf_head, 0, sizeof(Buf_head));
	memcpy(Buf_head, tmp_buf, 4);
	nLen = atoi(Buf_head);
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"nLen = %d,BUF_SIZE[%d]", nLen,BUF_SIZE);

	if ( nLen == 0 || nLen > BUF_SIZE )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "len error = %d", nLen);
		alarm(0);
		return (-1);
	}
	else
		 HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "data len  = %d", nLen);

	nleft=nLen;
	while ( nleft > -1 )
	{
		/* add read "FF" */
		nread = read(socketid, buffer, nleft+1);
		if (nread<0 && errno==EINTR) 
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"EINTR error");
			break;
		}
		if (nread < 0)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"read socket error");
			alarm(0);
			return(-1);
		}
		if ( nread == 0 ) break;
		nleft -= nread;
		buffer += nread;
		if ( nleft <= -1 )
		   break ;
	}

	alarm(0);
	return (nLen-nleft);

}

/*
 * Function Name:  WriteSock
 * Parameter 1  :  socketid   socket��	 
 * Parameter 2  :  len		���ͻ���������
 * Parameter 3  :  buffer	 ���ͻ�����
 */
int WriteSock(socketid,len,buffer) 
int socketid;
int len;
char * buffer;
{
	int  num, iWritelen;

 	unsigned char Buf_head[5];

 	char saSendBuf[BUF_SIZE];


 	if (len == 0) return(0);

 	memset(saSendBuf,0,sizeof(saSendBuf));
	sprintf(saSendBuf, "%04d", len-1);
	memcpy(saSendBuf+4,buffer,len);

	len = len + 4;

	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__,
		saSendBuf, len);

	iWritelen=0;
	for(;;)
		{
				while((num=write(socketid,&saSendBuf[iWritelen],
								len-iWritelen))<=0)
				{
						if (errno == EINTR) continue;
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"write socket error");
						return(-1);
				}

				iWritelen+=num;
				if(iWritelen>=len) break;
		}
		return(iWritelen);
}
