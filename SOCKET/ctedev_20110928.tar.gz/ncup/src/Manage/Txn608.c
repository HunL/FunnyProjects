/****************************************************************
 *	�� �� ��: Txn608.c 
 *	��    ��: ��Կ����,����,�������� 
 *	�����Ա: fucl 
 *	���ʱ��: 2011/04/25
 *	��    ע: ���״���:6083 6084
 * 	Copyright (c) 2011 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn608.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6083(T_IpcIntMngDef *ptIpcIntMng)
{
	char       sCurrentTime[15];
	int        nReturnCode;
	char       sData[999];

	CommonGetCurrentTime (sCurrentTime);
	memcpy(ptIpcIntMng->sSysSeqNum, ptIpcIntMng->sSysTraceAuditNum, F011_LEN);
	/* �����¼ */
	DbsBegin ();
	nReturnCode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsManagerIn DBS_INSERT error, %d,database error[%d]", errno , nReturnCode);
		DbsRollback();
		return nReturnCode;
	}
	DbsCommit();


	/* ��Կ���� */
	nReturnCode = MngCustChangeKey(ptIpcIntMng);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MngCustChangeKey error, %d.",nReturnCode);

		memcpy(ptIpcIntMng->sMsgDestId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);
		ptIpcIntMng->sTxnNum[3]++;
		ptIpcIntMng->sMsgType[2]++;
		memcpy(ptIpcIntMng->sRespCode, F039_MAC_FAIL, F039_LEN);

		return 0;
	}

	memcpy(ptIpcIntMng->sMsgDestId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);

	ptIpcIntMng->sTxnNum[3]++;
	ptIpcIntMng->sMsgType[2]++;
	memcpy(ptIpcIntMng->sRespCode, "00", F039_LEN);

	/* ����MAC���˺���Ϊ���������ཻ��ר�� */
	nReturnCode = MngCustGenerateMAC (ptIpcIntMng);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MngCustGenerateMAC error, %d.", nReturnCode);
		return -1;
	}

	return 0;
}
