/****************************************************************
 *	�� �� ��: Txn605.c 
 *	��    ��: ���н���,����,��������
 *	�����Ա: ���� 
 *	���ʱ��: 2005/04/20
 *	��    ע: ���״���:6053 6054
 * 	Copyright (c) 2005 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn605.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6053(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     nReturncode;
	
	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6053 success  begin ");

	CommonGetCurrentTime (sCurrentTime);
        
    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();

      /* Ŀ��ID */
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN);
	
	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6053 success  end ");
	
	return 0;
}

int Txn6054(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     nReturncode;
	char			sDestId[F032_VAL_LEN+1];
	char			sSrcId[F032_VAL_LEN+1];
        
    HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6054 begin ");    
        
	CommonGetCurrentTime (sCurrentTime);

    /*�������ݿ�*/
    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_UPDATE,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();

    nReturncode = nSetSlmtDate((char *)getenv(CS_SC_CODE),ptIpcIntMng->sDateSettlmt);
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nSetStlmDate nReturnCode %d", nReturncode);
	
	memcpy(sDestId, ptIpcIntMng->sHeaderBuf+6, F032_VAL_LEN);
	memcpy(sSrcId, ptIpcIntMng->sHeaderBuf+6+F032_VAL_LEN, F032_VAL_LEN);
	memcpy(ptIpcIntMng->sHeaderBuf+6, sSrcId, F032_VAL_LEN);
	memcpy(ptIpcIntMng->sHeaderBuf+6+F032_VAL_LEN, sDestId, F032_VAL_LEN);
	
	   /* ԴID + Ŀ��ID */
	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);   
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUP, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMisc, ptIpcIntMng->sRespCode, F039_LEN);
	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6054 success  end ");
	
	return 0;
}
