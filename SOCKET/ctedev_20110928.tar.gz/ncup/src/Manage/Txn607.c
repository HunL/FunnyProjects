/****************************************************************
 *	�� �� ��: Txn607.c 
 *	��    ��: ��������PIN��Կ 
 *	�����Ա: fucl
 *	���ʱ��: 2011/04/28
 *	��    ע: ���״���:6071 6072
 * 	Copyright (c) 2011 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn607.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6071(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;
	char    sOrgTxnNum[4+1] = {0};
	char    sOrgSrcId[4+1] = {0};
	
	/* ��Ӧ�����̨�ɹ� */
	memcpy(sOrgSrcId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	memcpy(sOrgTxnNum, ptIpcIntMng->sTxnNum, FLD_TXN_NUM_LEN);
	memcpy(ptIpcIntMng->sTxnNum, "6072", FLD_TXN_NUM_LEN);
	if(memcmp(ptIpcIntMng->sSecurityRelatedInfo, "20", 2) == 0)
	    memcpy(ptIpcIntMng->sMiscFlag, "6073", 4);
	else if(memcmp(ptIpcIntMng->sSecurityRelatedInfo, "16", 2) == 0)
	    memcpy(ptIpcIntMng->sMiscFlag, "6074", 4);
	memcpy(ptIpcIntMng->sRespCode, "A1", F039_LEN);
	nReturncode = MsqSnd (SRV_ID_PACKSEND, gatSrvMsq, 0, sizeof(T_IpcIntMngDef), (char *)ptIpcIntMng);
	if (nReturncode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqSnd error, %d.", nReturncode);
		return -1;
	}
	
	memcpy(ptIpcIntMng->sTxnNum, sOrgTxnNum, FLD_TXN_NUM_LEN);
	memcpy(ptIpcIntMng->sMsgSrcId, sOrgSrcId, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUP, SRV_ID_LEN);
	memset(ptIpcIntMng->sRespCode, ' ', F039_LEN);

	CommonGetCurrentTime (sCurrentTime);
		
	/*memcpy (ptIpcIntMng->sTransmsnDateTime, sCurrentTime+4, F007_LEN);*/
	memcpy (ptIpcIntMng->sSysSeqNum, ptIpcIntMng->sTransmsnDateTime+4, F011_LEN);
	memcpy (ptIpcIntMng->sSysTraceAuditNum, ptIpcIntMng->sTransmsnDateTime+4, F011_LEN);
	/*װ������*/
	memcpy (ptIpcIntMng->sFwdInstIdCodeLen, "08", F033_LEN_LEN);
	memcpy (ptIpcIntMng->sFwdInstIdCode, BANK_INST_ID, 8);
	memcpy (ptIpcIntMng->sNetwkMgmtInfoCode, "101", 3);
	/*ptIpcIntMng->cF053Ind = 'Y';
	memcpy (ptIpcIntMng->sSecurityRelatedInfo, ptIpcIntMng->sAddtnlDataPrivate+8, 16);*/
	/*HeaderBuf*/
	memset(&ptIpcIntMng->sHeaderBuf[0], 0x2e,1);//ͷ1��ͷ����
	memset(&ptIpcIntMng->sHeaderBuf[1], 0x01,1);//ͷ2���汾��ʶ
	memset(&ptIpcIntMng->sHeaderBuf[2],'0',4);//ͷ3���������ĳ���
	memcpy(&ptIpcIntMng->sHeaderBuf[6],CUP_INST_ID,8);//ͷ4��Ŀ��ID
	memcpy(&ptIpcIntMng->sHeaderBuf[14],"   ",3);
	memcpy(&ptIpcIntMng->sHeaderBuf[17],ptIpcIntMng->sFwdInstIdCode,8);//ͷ5��ԴID
	memcpy(&ptIpcIntMng->sHeaderBuf[25],"   ",3);
	memset(&ptIpcIntMng->sHeaderBuf[28],0x00,4);//ͷ6������ʹ�ã�24bit����ͷ7��1bit��
	memset(&ptIpcIntMng->sHeaderBuf[32],'0',8);//ͷ8��������Ϣ
	memset(&ptIpcIntMng->sHeaderBuf[40],0x00,1);//ͷ9���û���Ϣ
	memset(&ptIpcIntMng->sHeaderBuf[41],'0',5);//ͷ10���ܾ���
	/*HeaderBuf over*/
	
	DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d, sTransmsnDateTime[%10.10s] sSysTraceAuditNum[%6.6s]", 
		        errno, ptIpcIntMng->sTransmsnDateTime, ptIpcIntMng->sSysTraceAuditNum);
		return nReturncode;
	}
	DbsCommit ();
	
	return 0;
}

int Txn6072(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;
	
	CommonGetCurrentTime (sCurrentTime);

    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_UPDATE,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();

	if(nReturncode = DbsManagerIn(DBS_SELECT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_SELECT error, %d", errno);
		return nReturncode;
	}		

	/*memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CON, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMisc, ptIpcIntMng->sRespCode, F039_LEN);*/

	return 0;
}
