/****************************************************************
*	�� �� ��: Manage.c 
*	��	 ��: �����ཻ�״���ģ��(����) 
*	�����Ա: ���� 
*	���ʱ��: 2005/04/20
*	��	 ע: ��̨����
*	Copyright (c) 2005 by Huateng Corp. All rights reserved.
*****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Manage.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";

#include "Manage.h"
#include "MngTxn.h"


int main( int argc, char **argv )
{
	char	sSrcSrvId[SRV_ID_LEN+1];
	char	sTxnNum[FLD_TXN_NUM_LEN+1];
	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	char	sIntMsgBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	int 	nMsgInLen;
	int 	nIntMsgLen;
	int 	nMsgOutLen;
	int		nReturnCode, i;
	int			nLineStat;
	char	 *pos;
	char	 sTmp1[4+1];
	long	lBeginTime, lEndTime;
	struct tms	tTMS;
	static	int srvlodflag =1;
	static Tbl_srv_inf_Def	sTblSrvInf[MAXSRVINF];
	char    sLineIndex[2] = {0};


	T_IpcIntMngDef	tIpcIntMng;

	if(argc < 3)
	{
		printf("Usage:%s srvid seq\n", argv[0]);
		exit(-1);
	}

	nReturnCode = InitManage(argc, argv);
	if ( nReturnCode != 0 )
	{
		printf("InitManage:%d\n", nReturnCode);
		exit(-1);
	}

	if (sigset(SIGTERM, HandleExit) == SIG_ERR)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"sigset SIGTERM error, %d", errno);
		exit(-2);
	}
	
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "srvlodflag1--%d",srvlodflag);
	if(srvlodflag)
	{
		 memset ((char *)sTblSrvInf, 0, sizeof (sTblSrvInf));
		nReturnCode = DbsSrvInfLoad(sTblSrvInf);
		if (nReturnCode)
		{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsSrvInfLoad error, %d.", nReturnCode);
				DbsDisconnect ();
				return (nReturnCode);
		}
		srvlodflag = 0;
	}
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "srvlodflag2--%d",srvlodflag);
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Manage started");

	lBeginTime = 0; 
	lEndTime = 0; 
	while ( 1 )
	{
		memset (sMsgInBuf, 0, sizeof(sMsgInBuf) );
		nMsgInLen = MSQ_MSG_SIZE_MAX;
		sigrelse (SIGTERM);
		nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, 
							&nMsgInLen, sMsgInBuf);
		sighold (SIGTERM);
		if (nReturnCode)
		{
			if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"MsqRcv error, %d", nReturnCode);
				exit(-1);
			}
			else
				continue;
		}

		lBeginTime = times( &tTMS);

		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 
					sMsgInBuf, nMsgInLen);
			
			HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
				"MsqRcv msg len[%d]", nMsgInLen);

			/* uncompress msg */
			if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
			{
				/* uncompress msg */
				/* sMsgInBuf, nMsgInLen -> sIntMsgInBuf, nIntMsgInLen */
				memset(sIntMsgBuf,0,sizeof(sIntMsgBuf));
				UnCompressbuf(sMsgInBuf, nMsgInLen, sIntMsgBuf, &nIntMsgLen);
				memset(sMsgInBuf,0,sizeof(sMsgInBuf));
				nMsgInLen = nIntMsgLen;
				memcpy (sMsgInBuf, sIntMsgBuf, nIntMsgLen);
			}
/*
		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, 
					sMsgInBuf, nMsgInLen);*/
					
		/* process msg according to msg source */
		memset(	&tIpcIntMng, 0, sizeof(T_IpcIntMngDef));
		
		memcpy(&tIpcIntMng,sMsgInBuf,sizeof(tIpcIntMng));				
											
		for( i = 0; i < MAXTXNS; i++ )
		{
			if( memcmp( tIpcIntMng.sTxnNum, Txns[i].caTxnNum, 4 ) == 0 )
			{
				break;
			}
		}
		
		/*�������ݿ��Ƿ�״̬�ļ�� add 20110718		*/
        nReturnCode = -1;
        nReturnCode = DbReconnectTest();       
        if(nReturnCode != 0)
        {
		 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DataBase status is error ,Discard this message, nReturnCode=[%d]", nReturnCode);    	       
		 	continue;
		} /*  added end */
		else
		{			 
			if( i == MAXTXNS )
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
						"not find txn[%4.4s] define", tIpcIntMng.sTxnNum );
			}
			else
			{
				HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, 
						"Handle Txn[%s][%s]", Txns[i].caTxnNum, Txns[i].caTxnDsp);
				nReturnCode = Txns[i].pfTxnFun(&tIpcIntMng);
			}
	
			if(nReturnCode)
			{
				HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
						"Handle Txn %d error", nReturnCode);
				continue;
			}
		}
					 
		HtIpcMng(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, 
					"IPCMNG", &tIpcIntMng);
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tIpcIntMng.sMsgDestId--%4.4s",tIpcIntMng.sMsgDestId);
		HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tIpcIntMng.sFwdInstIdCode--%8.8s",tIpcIntMng.sFwdInstIdCode);
		
		/* ���践��ǰ�˵Ľ��ף��ӵ� */
		if(memcmp(tIpcIntMng.sTxnNum , "6072", 4) == 0 ||
		    memcmp(tIpcIntMng.sTxnNum , "6206", 4) == 0 ||
		    memcmp(tIpcIntMng.sTxnNum , "6216", 4) == 0)
		{
		    HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
						"Txn [%4.4s] not need to continue, discard this msg.", tIpcIntMng.sTxnNum);
            continue;
		}
		
#if 0
		i = 0;
		if (memcmp(tIpcIntMng.sMsgDestId,"16",2)==0 && memcmp(tIpcIntMng.sMsgSrcId,"1901",4)==0 && memcmp(tIpcIntMng.sTxnNum,"6431",4))
		{
				memset(sTmp1,0,sizeof(sTmp1));
					memcpy(sTmp1,tIpcIntMng.sFwdInstIdCode+4,SRV_ID_LEN);
			for (i = 0; i < MAXSRVINF; i++)
			{
						 pos = NULL;
			/*if(!memcmp (sTblSrvInf[i].srv_dsp,ptIpcIntTxn->sFwdInstIdCode+4, SRV_ID_LEN))
			{					
				 memcpy(ptIpcIntTxn->sMsgDestId,sTblSrvInf[i].srv_id,SRV_ID_LEN);
				 break;
			}*/
						 pos = strstr(sTblSrvInf[i].srv_dsp,sTmp1);
						 if ( pos != NULL)
						 {
								memcpy(tIpcIntMng.sMsgDestId,sTblSrvInf[i].srv_id,SRV_ID_LEN);
								break;
						 }
						 
			}

			HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tIpcIntMng.sMsgDestId--%4.4s",tIpcIntMng.sMsgDestId);
			if(i == MAXSRVINF && memcmp(tIpcIntMng.sMsgSrcId,"1901",4)==0)
			{
					 HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, " not find sMsgDestId");
					 memcpy(tIpcIntMng.sMsgDestId, "1901", SRV_ID_LEN);
					 tIpcIntMng.sTxnNum[3]++;
					 memcpy(tIpcIntMng.sRespCode,"96", F039_LEN);
			} 
		}
#endif

		/***********************
		* ��ⷢ��Ŀ����·״̬
		************************/
		if ((memcmp(tIpcIntMng.sMsgDestId,"16",2)==0 && memcmp(tIpcIntMng.sMsgSrcId, SRV_ID_COMM_CON, 4)==0) ||
		    (memcmp(tIpcIntMng.sMsgDestId, SRV_ID_COMM_CC, 4)==0 && memcmp(tIpcIntMng.sMsgSrcId, SRV_ID_COMM_CON, 4)==0) ||
		    (memcmp(tIpcIntMng.sMsgDestId, SRV_ID_COMM_ZK, 4)==0 && memcmp(tIpcIntMng.sMsgSrcId, SRV_ID_COMM_CON, 4)==0) ||
		    (memcmp(tIpcIntMng.sMsgDestId, SRV_ID_COMM_CUPS, 4)==0 && memcmp(tIpcIntMng.sMsgSrcId, SRV_ID_COMM_CUP, 4)==0))
		{
		    strcpy (sLineIndex, getenv(SRV_USAGE_KEY));
			nReturnCode = LineStateCheck (tIpcIntMng.sMsgDestId, sLineIndex, &nLineStat);
			if (nReturnCode || (nReturnCode == 0 && nLineStat != LINE_STATE_CONNECT))
			{
				HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"LineStateCheck return %d, line state %d.", nReturnCode, nLineStat);
				 /* linestate not normal , discard this msg . by lgm */
				 /*
				 if(memcmp(tIpcIntMng.sMsgSrcId, SRV_ID_COMM_CUP, 4) == 0)
				    memcpy(tIpcIntMng.sMsgDestId, SRV_ID_COMM_CUP, SRV_ID_LEN);
				 else
				    memcpy(tIpcIntMng.sMsgDestId, SRV_ID_COMM_CON, SRV_ID_LEN);
				 tIpcIntMng.sTxnNum[3]++;
				 memcpy(tIpcIntMng.sRespCode,"96", F039_LEN);
				 */
				 continue;
			}
		}

		memset (sMsgOutBuf, 0, sizeof(sMsgOutBuf));
		nMsgOutLen = sizeof(T_IpcIntMngDef);
		memcpy (sMsgOutBuf, (char *)&tIpcIntMng, nMsgOutLen); 
					 
		/* compress msg */
		if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
		{
			/* compress msg */
			/* sMsgOutBuf, nMsgOutLen -> sIntMsgBuf, nIntMsgLen */
			memset(sIntMsgBuf,0,sizeof(sIntMsgBuf));
			Compressbuf(sMsgOutBuf, nMsgOutLen, sIntMsgBuf, &nIntMsgLen);
			memset(sMsgOutBuf,0,sizeof(sMsgOutBuf));
			nMsgOutLen = nIntMsgLen;
			memcpy (sMsgOutBuf, sIntMsgBuf, nIntMsgLen);
		}

		HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, 
					sMsgOutBuf, nMsgOutLen);

			/* send msg */
			
		nReturnCode = MsqSnd (gsToSrvId, gatSrvMsq, 0, nMsgOutLen, sMsgOutBuf);
		if (nReturnCode)
		{
			HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
						"MsqSnd to %s error, %d", gsToSrvId, nReturnCode);
			continue;
		}

			HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
				"Txn handle in %s ok", gsToSrvId);
		lEndTime = times( &tTMS);
	}
}

/*****************************************************************************/
/* FUNC:	int InitManage (short argc, char **argv );								*/
/* INPUT:	argc: ��������																	 */
/*			argv: ����																			*/
/* OUTPUT: NULL																					*/
/* RETURN: 0: �ɹ�, ����: ʧ��																*/
/* DESC:	��ʼ��ϵͳ��̬����,����,������Ϣ��											*/
/*****************************************************************************/
int InitManage(short argc, char **argv)
{
	int				i;
	int				nReturnCode;
	long				lUsageKey;
	Tbl_srv_inf_Def	tTblSrvInf;
	

	strcpy (gsSrvId, argv[1]);
	strcpy (gsSrvSeqId, argv[2]);
	strcpy (gsToSrvId, SRV_ID_PACKSEND);
	if (getenv (MSG_COMPRESS_FLAG))
		strcpy (gsParamMsgCompressFlag, getenv (MSG_COMPRESS_FLAG));
	else
		strcpy (gsParamMsgCompressFlag, FLAG_NO);

	if (getenv(SRV_USAGE_KEY))
		lUsageKey=atoi (getenv(SRV_USAGE_KEY));
	else
		return -1;

	/* connect to database */
	 nReturnCode = DbsConnect ();
	if (nReturnCode)
		return (nReturnCode);
	
	/* get log file name from tbl_srv_inf */
	memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
	tTblSrvInf.usage_key = lUsageKey;
	memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
	nReturnCode = DbsSRVINF(DBS_SELECT, &tTblSrvInf);
	if (nReturnCode)
		return (nReturnCode);

	CommonRTrim(tTblSrvInf.srv_name);
	sprintf (gsLogFile, "%s.%s.log", tTblSrvInf.srv_name, gsSrvSeqId);

	/* init msg queue */
	memset ((char *)gatSrvMsq, 0, SRV_MSQ_NUM_MAX * sizeof (T_SrvMsq));
	nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
	if (nReturnCode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"MsqInit error, %d", nReturnCode);		
		return (nReturnCode);
	}
	DbsTxnInfLoad (&gnTxnInfNum, gatTxnInf);
	
	return 0;	
}

void HandleExit (int n)
{
	HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Manage exits");
	exit( 1 );
}


/*����---SrvInf	for �ط�����·��*/
int DbsSrvInfLoad ( Tbl_srv_inf_Def *vtpTblSrvInf)
{
	
	 Tbl_srv_inf_Def	stTblSrvInfTmp;
	 int i=0;
	 int llResult;
	memset(&stTblSrvInfTmp,0x00,sizeof(Tbl_srv_inf_Def));
	
	if(llResult = DbsSRVINF( DBS_CURSOR, &stTblSrvInfTmp))
	{
	 return llResult;
	}
	 if(llResult = DbsSRVINF( DBS_OPEN, &stTblSrvInfTmp))
	{
	 return llResult;
	}
	while(DbsSRVINF( DBS_FETCH, &stTblSrvInfTmp) == 0	&& i< MAXSRVINF) 
	{
		memcpy(vtpTblSrvInf,&stTblSrvInfTmp,sizeof(Tbl_srv_inf_Def));
		vtpTblSrvInf++;
		i++;
	} 
	if(llResult=DbsSRVINF( DBS_CLOSE, &stTblSrvInfTmp))
	{
	 return llResult;
	}
	return 0;
	
}
