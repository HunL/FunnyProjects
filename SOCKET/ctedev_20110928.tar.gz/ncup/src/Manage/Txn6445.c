/****************************************************************
 *	�� �� ��: Txn6445.c 
 *	��    ��: ��������������ܿص���Կ��������
 *	�����Ա: lgm
 *	���ʱ��: 2011/07/05
 *	��    ע: ���״���:6445 6446
 * 	Copyright (c) 2011 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn6445.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"


int Txn6445(T_IpcIntMngDef *ptIpcIntMng)
{
	int					nReturncode;
	char				sCurrentTime[15];

	HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Txn6445 begin ");

	/* Ŀ��ID */
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_ZK, SRV_ID_LEN);
	/*memset(ptIpcIntMng->sMsqType, ' ', FLD_MSQ_TYPE_LEN);*/
	
	/*��¼���ݿ�*/
	memset(sCurrentTime,0x00,sizeof(sCurrentTime));
	CommonGetCurrentTime (sCurrentTime);
	
	memcpy (ptIpcIntMng->sSysSeqNum, sCurrentTime+8, F011_LEN);
    memcpy (ptIpcIntMng->sSysTraceAuditNum, sCurrentTime+8, F011_LEN);
    memcpy (ptIpcIntMng->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
    memcpy (ptIpcIntMng->sMiscFlag, sCurrentTime, 14);
	    
	DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();
	
	HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Txn6445 success end ");

	return 0;
}

int Txn6446(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;
	HSMOprDef		tHsmOpr={0};
	char    sKeyLen[3], sChkLen[3];
	
	HtLog(gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Txn6446 begin ");
	
	memset(sCurrentTime, 0x00, sizeof(sCurrentTime));
	CommonGetCurrentTime (sCurrentTime);
	
	/*������ZAK/ZPK��ZMKתΪLMK����*/
	HtLog (gsLogFile,HT_LOG_MODE_DEBUG,__FILE__,__LINE__,"ptIpcIntMng->sAddtnlDataPrivate[%116.116s]", ptIpcIntMng->sAddtnlDataPrivate);
	
	memset(sKeyLen, 0, sizeof(sKeyLen));
	memset(sChkLen, 0, sizeof(sChkLen));
	memcpy(sKeyLen, ptIpcIntMng->sAddtnlDataPrivate, 2);
	memcpy(sChkLen, ptIpcIntMng->sAddtnlDataPrivate+2+48+48, 2);
	if(atoi(sKeyLen) <= 0 || atoi(sChkLen) <= 0)
	{
	    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "get Key Len or ChkVal Len error, sKeyLen[%2.2s] sChkLen[%2.2s].", sKeyLen, sChkLen);
		return -1;
	}
	
	if(memcmp(ptIpcIntMng->sProcessingCode, "ECH001", 6) == 0)
	{
	    if(atoi(sKeyLen) == 16)
	    {
	        memcpy(&tHsmOpr.saEncWay[0], "20", 2);
	        memset(ptIpcIntMng->sAddtnlDataPrivate+2+16, '0', 16);
	    }
	    else
	        memcpy(&tHsmOpr.saEncWay[0], "26", 2);
	}
	else if(memcmp(ptIpcIntMng->sProcessingCode, "ECH002", 6) == 0)
	{
	    memcpy(&tHsmOpr.saEncWay[0], "16", 2);
	    
	}
	/* KEY */
	Str2Hex(ptIpcIntMng->sAddtnlDataPrivate+2+48, &tHsmOpr.saEnc[0], atoi(sKeyLen));
	/* CHK Val */
	Str2Hex(ptIpcIntMng->sAddtnlDataPrivate+2+48+48+2, &tHsmOpr.saEnc[20], atoi(sChkLen));
	    
	tHsmOpr.saOprType = HSM_CHANGEKEY;
	tHsmOpr.saRout[0] = 'Y';
	memcpy(&tHsmOpr.saRout[1],"0007",4);  /*�ܿ�*/
    
	nReturncode = nEncOpr(&tHsmOpr);
	if (nReturncode != HSM_SUCCESS)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nEncOpr %c error.", tHsmOpr.saOprType);
		return -1;
	}

    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_UPDATE, ptIpcIntMng, sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();

	if(nReturncode = DbsManagerIn(DBS_SELECT, ptIpcIntMng, sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_SELECT error, %d", errno);
		return nReturncode;
	}
	
	/* Ŀ��ID */
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CON, SRV_ID_LEN);
		
	return 0;
}
