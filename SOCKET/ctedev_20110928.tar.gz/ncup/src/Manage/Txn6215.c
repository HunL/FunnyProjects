/****************************************************************
 *	�� �� ��: Txn6215.c 
 *	��    ��: �����������������ͳһ�����·�ZPK����
 *	�����Ա: fucl
 *	���ʱ��: 2011/05/03
 *	��    ע: ���״���:6215 6216
 * 	Copyright (c) 2011 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn6215.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6215(T_IpcIntMngDef *ptIpcIntMng)
{
	int					nReturncode;
	char				sCurrentTime[15];
	HSMOprDef		tHsmOpr={0};
	char    sOrgTxnNum[4+1] = {0};
	char    sOrgSrcId[4+1] = {0};

	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6215 begin ");
    
    /* ��Ӧ�����̨�ɹ� */
    memcpy(sOrgSrcId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	memcpy(sOrgTxnNum, ptIpcIntMng->sTxnNum, FLD_TXN_NUM_LEN);
	memcpy(ptIpcIntMng->sTxnNum, "6216", FLD_TXN_NUM_LEN);
	memcpy(ptIpcIntMng->sMiscFlag, ptIpcIntMng->sTxnNum, 4);
	memcpy(ptIpcIntMng->sRespCode, "A1", F039_LEN);
	nReturncode = MsqSnd (SRV_ID_PACKSEND, gatSrvMsq, 0, sizeof(T_IpcIntMngDef), (char *)ptIpcIntMng);
	if (nReturncode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqSnd error, %d.", nReturncode);
		return -1;
	}
	
	memcpy(ptIpcIntMng->sTxnNum, sOrgTxnNum, FLD_TXN_NUM_LEN);
	memcpy(ptIpcIntMng->sMsgSrcId, sOrgSrcId, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN);
	memset(ptIpcIntMng->sRespCode, ' ', F039_LEN);
	
	memset(sCurrentTime,0x00,sizeof(sCurrentTime));
	CommonGetCurrentTime (sCurrentTime);
	
		/*2011��5��13��  Ԭ�� ���� 7�� �����Բ���*/	
	memcpy (ptIpcIntMng->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
	
	memcpy (ptIpcIntMng->sSysSeqNum, sCurrentTime+8, F011_LEN);
	memcpy (ptIpcIntMng->sSysTraceAuditNum, sCurrentTime+8, F011_LEN);
	ptIpcIntMng->cF100Ind = 'Y';
	memcpy (ptIpcIntMng->sRcvgInstIdCodeLen, "08", F100_LEN_LEN);
	memcpy (ptIpcIntMng->sRcvgInstIdCode, BANK_INST_ID, 8);
	ptIpcIntMng->cF053Ind = 'Y';
	
	/* �����ܻ���ȡ������Կ */
	tHsmOpr.saOprType = HSM_GENZPK;
	memcpy(tHsmOpr.saRout, "Y", 1);
	memcpy(tHsmOpr.saRout+1,"0002", 4);

	nReturncode = nEncOpr(&tHsmOpr);
	if (nReturncode != 0)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_GENZPK nEncOpr error nReturncode[%d] ", nReturncode);
		memcpy(ptIpcIntMng->sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}

	/*F048*/
	ptIpcIntMng->cF048Ind = 'Y';
	memcpy(ptIpcIntMng->sAddtnlDataPrivateLen, "018", 3);
	memcpy(ptIpcIntMng->sAddtnlDataPrivate, "NK", 2);
	Str2Hex(tHsmOpr.saZPK, ptIpcIntMng->sAddtnlDataPrivate+2, 32);

	/*F096*/
	memset(ptIpcIntMng->sMsgSecurityCode,'0', F096_LEN);
	
	/*���� saZPKLMK */
	memcpy(ptIpcIntMng->sMiscFlag, tHsmOpr.saZPKLMK, 32);
	
	/*���� PINKEY ����ֵ */
	ptIpcIntMng->cF064 = 'Y';
	memcpy(ptIpcIntMng->sMAC064, tHsmOpr.saZPKChkV, 8);
	
	/* ����ZPKLMK */
	memset(&tHsmOpr,0,sizeof(tHsmOpr));
	memcpy(tHsmOpr.saRout, "Y", 1);
	memcpy(tHsmOpr.saRout+1,"0002", 4);
	memcpy(tHsmOpr.saZPKLMK, ptIpcIntMng->sMiscFlag, 32);
	tHsmOpr.saOprType = HSM_CHANGEZPK;
	nReturncode = nEncOpr(&tHsmOpr);
	if (nReturncode != 0)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_CHANGEZPK nEncOpr error nReturncode[%d] ", nReturncode);
		memcpy(ptIpcIntMng->sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}

	memset(&tHsmOpr,0,sizeof(tHsmOpr));
	/* prepare MAC block */
	nReturncode = GenMacBlock ((T_IpcIntTxnDef*)ptIpcIntMng, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
	if (nReturncode != HSM_SUCCESS)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GenMacBlock error, %d.", nReturncode);
		return -1;
	}
	tHsmOpr.saOprType=HSM_GENMACWITHKEY;
	memcpy(tHsmOpr.saEnc,&ptIpcIntMng->sAddtnlDataPrivate[2], 16);
	memcpy(tHsmOpr.saEncWay,ptIpcIntMng->sSecurityRelatedInfo,F053_LEN);
	memcpy(tHsmOpr.saRout,"Y",1);
	memcpy(tHsmOpr.saRout+1,"0002",HSM_INDEX_LEN);
	
	if(nReturncode = nEncOpr(&tHsmOpr))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"HSM_GENMAC nEncOpr error nReturncode[%d] ", nReturncode);
		return nReturncode;
	}
	ptIpcIntMng->cF128Ind = 'Y';
	memset(ptIpcIntMng->sMAC128,0,F128_LEN);
	Str2Hex(&tHsmOpr.saEnc[16], ptIpcIntMng->sMAC128, 8);
	Str2Hex(ptIpcIntMng->sMAC064, ptIpcIntMng->sMAC128+4, 8);
	
	/*HeaderBuf*/	
	memset(&ptIpcIntMng->sHeaderBuf[0], 0x2e,1);//ͷ1��ͷ����
	memset(&ptIpcIntMng->sHeaderBuf[1], 0x01,1);//ͷ2���汾��ʶ
	memset(&ptIpcIntMng->sHeaderBuf[2],'0',4);//ͷ3���������ĳ���
	memcpy(&ptIpcIntMng->sHeaderBuf[6],ptIpcIntMng->sRcvgInstIdCode,8);//ͷ4��Ŀ��ID
	memcpy(&ptIpcIntMng->sHeaderBuf[14],"   ",3);
	memcpy(&ptIpcIntMng->sHeaderBuf[17],CUP_INST_ID,8);//ͷ5��ԴID
	memcpy(&ptIpcIntMng->sHeaderBuf[25],"   ",3);
	memset(&ptIpcIntMng->sHeaderBuf[28],0x00,4);//ͷ6������ʹ�ã�24bit����ͷ7��1bit��
	memset(&ptIpcIntMng->sHeaderBuf[32],'0',8);//ͷ8��������Ϣ
	memset(&ptIpcIntMng->sHeaderBuf[40],0x00,1);//ͷ9���û���Ϣ
	memset(&ptIpcIntMng->sHeaderBuf[41],'0',5);//ͷ10���ܾ���
	/*HeaderBuf over*/
	
	/* �ָ�ATMC��F007
	sprintf(ptIpcIntMng->sTransmsnDateTime, "%4.4s%6.6s", ptIpcIntMng->sDateLocalTrans, ptIpcIntMng->sTimeLocalTrans);*/

	/* Ŀ��ID */
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN);

	/*��¼���ݿ�*/
	DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();
	
	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6215 success end ");

	return 0;
}

int Txn6216(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;
	HSMOprDef		tHsmOpr={0};
	
	memset(sCurrentTime,0x00,sizeof(sCurrentTime));
	CommonGetCurrentTime (sCurrentTime);

    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_UPDATE,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();	

	if(nReturncode = DbsManagerIn(DBS_SELECT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_SELECT error, %d", errno);
		return nReturncode;
	}		

#if 0
	if(memcmp(ptIpcIntMng->sRespCode, F039_SUCCESS, F039_LEN) == 0)
	{
		/* ����ZPKLMK */
		tHsmOpr.saOprType = HSM_CHANGEZPK;
		memcpy(tHsmOpr.saZPKLMK, ptIpcIntMng->sMiscFlag, 32);
		nReturncode = nEncOpr(&tHsmOpr);
		if (nReturncode != 0)
		{
			HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_CHANGEZPK nEncOpr error nReturncode[%d] ", nReturncode);
			memcpy(ptIpcIntMng->sRespCode, F039_MAL_FUNCTION, F039_LEN);
			return -1;
		}
	}

	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CON, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMisc, ptIpcIntMng->sRespCode, F039_LEN);
#endif
		
	return 0;
}
