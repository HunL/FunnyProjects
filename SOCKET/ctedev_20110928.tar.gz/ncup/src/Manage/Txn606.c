/****************************************************************
 *	�� �� ��: Txn606.c 
 *	��    ��: �������,����,�������� 
 *	�����Ա: ���� 
 *	���ʱ��: 2005/04/20
 *	��    ע: ���״���:6061 6062
 * 	Copyright (c) 2005 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn606.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6061(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     nReturncode;    
	
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN);        

	CommonGetCurrentTime (sCurrentTime);
        
	memcpy (ptIpcIntMng->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
	memcpy (ptIpcIntMng->sSysSeqNum, sCurrentTime+8, F011_LEN);
	memcpy (ptIpcIntMng->sSysTraceAuditNum, sCurrentTime+8, F011_LEN);

	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;
	}
	return 0;
}

int Txn6062(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;
	
	CommonGetCurrentTime (sCurrentTime);

	if(nReturncode = DbsManagerIn(DBS_UPDATE,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}        

	if(nReturncode = DbsManagerIn(DBS_SELECT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_SELECT error, %d", errno);
		return nReturncode;
	}        

	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CON, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMisc, ptIpcIntMng->sRespCode, F039_LEN);
        
	return 0;
}
