/****************************************************************
 *	�� �� ��: Txn6075.c 
 *	��    ��: ����ͳһ����������Կ
 *	�����Ա: 
 *	���ʱ��: 2011/05/05
 *	��    ע: ���״���:6075 6076
 * 	Copyright (c) 2011 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn6075.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

#define POS_DEST_ID 6

int Txn6075(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;
	char    sDestId[F032_VAL_LEN+1];
	char    sSrcId[F032_VAL_LEN+1];
	HSMOprDef		tHsmOpr={0};
	
    memset(sCurrentTime,0x00,sizeof(sCurrentTime));
	CommonGetCurrentTime (sCurrentTime);
	
	memcpy(ptIpcIntMng->sMsgDestId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);
	ptIpcIntMng->sTxnNum[3]++;
	memcpy(ptIpcIntMng->sRespCode, "00", F039_LEN);
	
	/* ��������ͷԴID��Ŀ��ID�û� */
	memcpy(sDestId, ptIpcIntMng->sHeaderBuf+POS_DEST_ID, F032_VAL_LEN);
	memcpy(sSrcId, ptIpcIntMng->sHeaderBuf+POS_DEST_ID+F032_VAL_LEN, F032_VAL_LEN);
	memcpy(ptIpcIntMng->sHeaderBuf+POS_DEST_ID, sSrcId, F032_VAL_LEN);
	memcpy(ptIpcIntMng->sHeaderBuf+POS_DEST_ID+F032_VAL_LEN, sDestId, F032_VAL_LEN);
	
	nReturncode = MsqSnd (SRV_ID_PACKSEND, gatSrvMsq, 0, sizeof(T_IpcIntMngDef), (char *)ptIpcIntMng);
	if (nReturncode)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqSnd error, %d.", nReturncode);
		return -1;
	}
	
	DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();
	
	/* ����ͳһ������Կ����Ӧ�������ܻ�����PIK��MAK��������ķ�������ͳһ���� */
	ptIpcIntMng->cF100Ind = 'Y';
	memcpy (ptIpcIntMng->sRcvgInstIdCodeLen, ptIpcIntMng->sFwdInstIdCodeLen, F033_LEN_LEN);
	memcpy (ptIpcIntMng->sRcvgInstIdCode, ptIpcIntMng->sFwdInstIdCode, F033_VAL_LEN);
	
	memset(ptIpcIntMng->sFwdInstIdCodeLen, ' ', F033_LEN_LEN);
	memset(ptIpcIntMng->sFwdInstIdCode, ' ', F033_VAL_LEN);
	memset(ptIpcIntMng->sRespCode, ' ', F039_LEN);
	
	memcpy(ptIpcIntMng->sMsgType, "0800", 4);
	
	if(memcmp(ptIpcIntMng->sSecurityRelatedInfo, "26", 2) == 0)
	    memcpy(ptIpcIntMng->sTxnNum, "6205", 4);
	else if(memcmp(ptIpcIntMng->sSecurityRelatedInfo, "16", 2) == 0)
	    memcpy(ptIpcIntMng->sTxnNum, "6215", 4);
    
	memcpy (ptIpcIntMng->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
	memcpy (ptIpcIntMng->sSysSeqNum, sCurrentTime+8, F011_LEN);
	memcpy (ptIpcIntMng->sSysTraceAuditNum, sCurrentTime+8, F011_LEN);
	memcpy (ptIpcIntMng->sNetwkMgmtInfoCode, "101", 3);
	
	if(memcmp(ptIpcIntMng->sSecurityRelatedInfo, "26", 2) == 0)
	{
	    /* �����ܻ���ȡZAK */
	    tHsmOpr.saOprType = HSM_GENZAK;
	    memcpy(tHsmOpr.saRout, "Y", 1);
	    memcpy(tHsmOpr.saRout+1,"0002", 4);
	    nReturncode = nEncOpr(&tHsmOpr);
	    if (nReturncode != 0)
	    {
	    	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_GENZAK nEncOpr error nReturncode[%d] ", nReturncode);
	    	return -1;
	    }
        
	    /*F096*/
	    Str2Hex(tHsmOpr.saZAK, ptIpcIntMng->sMsgSecurityCode, 32);
	    
	    /* F128 */
	    ptIpcIntMng->cF128Ind = 'Y';
	    memset(ptIpcIntMng->sMAC128,0,F128_LEN);
	    Str2Hex(tHsmOpr.saZAKChkV, ptIpcIntMng->sMAC128+4, 8);
	    
	    /* ����ZAKLMK */
	    tHsmOpr.saOprType = HSM_CHANGEZAK;
	    nReturncode = nEncOpr(&tHsmOpr);
	    if (nReturncode != 0)
	    {
	    	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_CHANGEZAK nEncOpr error nReturncode[%d] ", nReturncode);
	    	return -1;
	    }
	}
	else if(memcmp(ptIpcIntMng->sSecurityRelatedInfo, "16", 2) == 0)
	{
	    /* �����ܻ���ȡ������Կ */
	    tHsmOpr.saOprType = HSM_GENZPK;
	    memcpy(tHsmOpr.saRout, "Y", 1);
	    memcpy(tHsmOpr.saRout+1,"0002", 4);
	    nReturncode = nEncOpr(&tHsmOpr);
	    if (nReturncode != 0)
	    {
	    	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_GENZPK nEncOpr error nReturncode[%d] ", nReturncode);
	    	return -1;
	    }
        
	    /*F048*/
	    ptIpcIntMng->cF048Ind = 'Y';
	    memcpy(ptIpcIntMng->sAddtnlDataPrivateLen, "018", 3);
	    memcpy(ptIpcIntMng->sAddtnlDataPrivate, "NK", 2);
	    Str2Hex(tHsmOpr.saZPK, ptIpcIntMng->sAddtnlDataPrivate+2, 32);
        
	    /*F096*/
	    memset(ptIpcIntMng->sMsgSecurityCode,'0', F096_LEN);
	    
	    /* F128 */
	    ptIpcIntMng->cF128Ind = 'Y';
	    memset(ptIpcIntMng->sMAC128,0,F128_LEN);
	    Str2Hex(tHsmOpr.saZPKChkV, ptIpcIntMng->sMAC128+4, 8);
	    
	    /* ����ZPKLMK */
		tHsmOpr.saOprType = HSM_CHANGEZPK;
		nReturncode = nEncOpr(&tHsmOpr);
		if (nReturncode != 0)
		{
			HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_CHANGEZPK nEncOpr error nReturncode[%d] ", nReturncode);
			return -1;
		}
	}
	
	/* prepare MAC block */
	memset(&tHsmOpr,0,sizeof(tHsmOpr));
	nReturncode = GenMacBlock ((T_IpcIntTxnDef*)ptIpcIntMng, tHsmOpr.saMacBlockLen, tHsmOpr.saMacBlock);
	if (nReturncode != HSM_SUCCESS)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GenMacBlock error, %d.", nReturncode);
		return -1;
	}
	
	if(memcmp(ptIpcIntMng->sSecurityRelatedInfo, "26", 2) == 0)
	{
	    tHsmOpr.saOprType=HSM_GENMAC;
	    memcpy(tHsmOpr.saRout,"Y",1);
	    memcpy(tHsmOpr.saRout+1,"0002",HSM_INDEX_LEN);
    }
    else
    {
        tHsmOpr.saOprType=HSM_GENMACWITHKEY;
	    memcpy(tHsmOpr.saEnc,&ptIpcIntMng->sAddtnlDataPrivate[2], 16);
	    memcpy(tHsmOpr.saEncWay,ptIpcIntMng->sSecurityRelatedInfo,F053_LEN);
	    memcpy(tHsmOpr.saRout,"Y",1);
	    memcpy(tHsmOpr.saRout+1,"0002",HSM_INDEX_LEN);
    }
	if(nReturncode = nEncOpr(&tHsmOpr))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"HSM_GENMAC nEncOpr error nReturncode[%d] ", nReturncode);
		return nReturncode;
	}
	ptIpcIntMng->cF128Ind = 'Y';
	Str2Hex(&tHsmOpr.saEnc[16], ptIpcIntMng->sMAC128, 8);
	
	/*��¼���ݿ�*/
	DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;         
	}
	DbsCommit ();
	
	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6075 success end ");
	
	return 0;
}

int Txn6076(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;
	
	CommonGetCurrentTime (sCurrentTime);

    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_UPDATE,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();

	return 0;
}
