/****************************************************************
 *	�� �� ��: Txn601.c 
 *	��    ��: ���ӿ���֪ͨ,����,�������� 
 *	�����Ա: ���� 
 *	���ʱ��: 2005/04/20
 *	��    ע: ���״���: 6013 6014
 * 	Copyright (c) 2005 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn601.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6013(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     Returncode;

	CommonGetCurrentTime (sCurrentTime);

	if(Returncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"DbsManagerIn error, %d", errno);
		return Returncode;
	}
	        
	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN);
	ptIpcIntMng->sTxnNum[3]++;
	memcpy(ptIpcIntMng->sRespCode, "00", F039_LEN);
	return 0;
}
