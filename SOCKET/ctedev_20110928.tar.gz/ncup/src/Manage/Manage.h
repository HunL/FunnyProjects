#ifndef __MANAGE_H
#define __MANAGE_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <math.h>
#include <errno.h>
#include <string.h>
#include <memory.h>
#include <signal.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "MsqOpr.h"
#include "ToOpr.h"
#include "HtLog.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "TxnNum.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "EncOpr.h"
#include "unionAPI.h"
#include "LineStat.h"

char				gsSrvId[SRV_ID_LEN+1];
char				gsToSrvId[SRV_ID_LEN+1];
char				gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char				gsLogFile[LOG_NAME_LEN_MAX];
char				gsParamMsgCompressFlag[2];
Tbl_txn_inf_Def		gatTxnInf[TXN_INF_NUM_MAX];
T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];
int					gnTxnInfNum;

int InitManage (short, char **);
void HandleExit (int);


#endif
