/****************************************************************
 *	�� �� ��: Txn6435.c 
 *	��    ��: �����ÿ�ϵͳ�����ϴ�֪ͨ����,˫�� 
 *	�����Ա: ���� 
 *	���ʱ��: 2005/04/20
 *	��    ע: ���״���:6141 6142 6143 6144
 * 	Copyright (c) 2005 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn6435.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6435(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     nReturncode;
	
	memcpy(ptIpcIntMng->sMsgDestId, "1702", SRV_ID_LEN);
	/*memset(ptIpcIntMng->sMsqType, ' ', FLD_MSQ_TYPE_LEN);*/

	CommonGetCurrentTime (sCurrentTime);
	
	memcpy (ptIpcIntMng->sSysSeqNum, sCurrentTime+8, F011_LEN);
	memcpy (ptIpcIntMng->sSysTraceAuditNum, sCurrentTime+8, F011_LEN);
    memcpy (ptIpcIntMng->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
	memcpy (ptIpcIntMng->sMiscFlag, sCurrentTime, 14);
			   
	DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();

	return 0;
}

int Txn6436(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;
	
	CommonGetCurrentTime (sCurrentTime);
	
	HtLog( "Txn6436.log", HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "ptIpcIntMng->sTransmsnDateTime,%s\n ptIpcIntMng->sSysTraceAuditNum,%s", 
	ptIpcIntMng->sTransmsnDateTime, ptIpcIntMng->sSysTraceAuditNum);
	
	DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_UPDATE,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();      

	if(nReturncode = DbsManagerIn(DBS_SELECT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_SELECT error, %d", errno);
		return nReturncode;
	}        
	 
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CON, 4);
	memcpy(ptIpcIntMng->sMiscFlag, "6436", 4);
	 
	return 0;
}

