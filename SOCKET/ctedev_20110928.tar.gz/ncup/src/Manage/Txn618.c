/****************************************************************
 *	�� �� ��: Txn618.c 
 *	��    ��: POS��������,����,��������
 *	�����Ա: ���� 
 *	���ʱ��: 2005/04/20
 *	��    ע: ���״���: 6183 6184
 * 	Copyright (c) 2005 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn618.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6183(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     nReturncode;        
	char    sMacBlock[HSM_MAC_BLOCK_LEN_MAX];
	char    sTemp[20];
	char    *sMacPoint;
	char    sKeyIndex[HSM_INDEX_LEN+1];
	int     sMacBlockLen=0;
	int     sMacTmp;
	int     n66p;
	HSMOprDef  lhsmOpr;
	
	sMacPoint=sMacBlock;
	memset(sMacBlock,' ',sizeof(sMacBlock));
	memcpy(sMacPoint,ptIpcIntMng->sMsgType,F000_MSG_TYPE_LEN);
	sMacPoint+=F000_MSG_TYPE_LEN+1;
	memcpy(sMacPoint,ptIpcIntMng->sTransmsnDateTime,F007_LEN);
	sMacPoint+=F007_LEN+1;	           
	memcpy(sMacPoint,ptIpcIntMng->sSysTraceAuditNum,F011_LEN);	
	sMacPoint+=F011_LEN+1;
	n66p=sMacPoint-sMacBlock;
	sMacPoint+=2;		
	memcpy(sMacPoint,ptIpcIntMng->sCreditsProcesFeeAmt,F082_LEN);	
	sMacPoint+=F082_LEN+1;	
	memcpy(sMacPoint,ptIpcIntMng->sDebitsProcesFeeAmt,F084_LEN);
	sMacPoint+=F084_LEN+1;	
	memcpy(sMacPoint,ptIpcIntMng->sCreditsAmt,F086_LEN);
	sMacPoint+=F086_LEN+1;
	memcpy(sMacPoint,ptIpcIntMng->sCreditsRevsalAmt,F087_LEN);
	sMacPoint+=F087_LEN+1;
	memcpy(sMacPoint,ptIpcIntMng->sDebitsAmt,F088_LEN);
	sMacPoint+=F088_LEN+1;
	memcpy(sMacPoint,ptIpcIntMng->sDebitsRevsalAmt,F089_LEN);
	sMacPoint+=F089_LEN+1;
	memcpy(sMacPoint,ptIpcIntMng->sAmtNetSettlmt,F097_LEN);
	sMacPoint+=F097_LEN;
	sMacBlockLen=sMacPoint-sMacBlock;
	
	memset(&lhsmOpr,0,sizeof(lhsmOpr));
	lhsmOpr.saOprType=HSM_VERIFYMAC;
	memcpy(lhsmOpr.saRout,"Y",1);
	if (getenv (HSM_INDEX_CUP))
		strcpy (sKeyIndex, getenv (HSM_INDEX_CUP));
	else
		return -1;
	
	memcpy(lhsmOpr.saRout+1,sKeyIndex,HSM_INDEX_LEN);
	memcpy(lhsmOpr.saMacBlock,sMacBlock,sMacBlockLen);
	memset(sTemp,0,20);
	sprintf(sTemp,"%03d",sMacBlockLen);
	memcpy(lhsmOpr.saMacBlockLen,sTemp,HSM_MAC_BLOCK_LEN_LEN);
	memcpy(&lhsmOpr.saEnc[16],ptIpcIntMng->sMAC128,F128_LEN);
	
	if(nReturncode=nEncOpr(&lhsmOpr))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"nEncOpr to %s error", gsToSrvId);
		return nReturncode;
	}
	
	CommonGetCurrentTime (sCurrentTime);
	if(nReturncode = DbsBegin())
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsBegin to %s error", gsToSrvId);
		return nReturncode;
	}

	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DbsManagerIn to %s error", gsToSrvId);
		return nReturncode;         
	}       

	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUP, SRV_ID_LEN);
	ptIpcIntMng->sTxnNum[3]++;
	ptIpcIntMng->sMsgType[2]++;
	
	sMacPoint=sMacBlock;        
	memset(sMacPoint, ' ', F000_MSG_TYPE_LEN);
	memcpy(sMacPoint, ptIpcIntMng->sMsgType, F000_MSG_TYPE_LEN);   
	memset(ptIpcIntMng->sSettlmtCode,0,F066_LEN);
	memcpy(ptIpcIntMng->sSettlmtCode,"1",F066_LEN);
	memcpy(&sMacBlock[n66p],"1",F066_LEN);
	
	memset(&lhsmOpr,0,sizeof(lhsmOpr));
	lhsmOpr.saOprType=HSM_GENMAC;
	memcpy(lhsmOpr.saRout,"Y",1);
	memcpy(lhsmOpr.saRout+1,sKeyIndex,HSM_INDEX_LEN);
	memcpy(lhsmOpr.saMacBlock,sMacBlock,sMacBlockLen);
	memset(sTemp,0,20);
	sprintf(sTemp,"%03d",sMacBlockLen);
	memcpy(lhsmOpr.saMacBlockLen,sTemp,HSM_MAC_BLOCK_LEN_LEN);
	
	if(nReturncode = nEncOpr(&lhsmOpr))
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"nEncOpr to %s error", gsToSrvId);
		return nReturncode;
	}
        
	memset(ptIpcIntMng->sMAC128,0,F128_LEN);
	memcpy(ptIpcIntMng->sMAC128,&lhsmOpr.saEnc[16],F128_LEN);
	return 0;
}
