/****************************************************************
 *	�� �� ��: Txn6225.c 
 *	��    ��: POSP��������ù�����Կ����
 *	�����Ա: fucl
 *	���ʱ��: 2011/05/03
 *	��    ע: ���״���:6225 6226
 * 	Copyright (c) 2011 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn6225.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6225(T_IpcIntMngDef *ptIpcIntMng)
{
	int					i,nReturncode;
	char				sCurrentTime[15];
	HSMOprDef		tHsmOpr={0};

	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6225 begin ");
	
	/**************************
	 �����ܻ���ȡ������ԿZAK 
	 **************************/
	memset(&tHsmOpr,0,sizeof(tHsmOpr));
	tHsmOpr.saOprType = HSM_GENZAK;
	memcpy(tHsmOpr.saRout, "Y", 1);
	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "src_id [%4.4s]", ptIpcIntMng->sMsgSrcId);
	if(memcmp(ptIpcIntMng->sMsgSrcId, SRV_ID_COMM_P, 4) == 0)
	    memcpy(tHsmOpr.saRout+1,"0005", 4);
	else if(memcmp(ptIpcIntMng->sMsgSrcId, SRV_ID_COMM_MZ, 4) == 0)
	    memcpy(tHsmOpr.saRout+1,"0008", 4);
	nReturncode = nEncOpr(&tHsmOpr);
	if (nReturncode != 0)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_GENZAK nEncOpr error nReturncode[%d] ", nReturncode);
		memcpy(ptIpcIntMng->sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}
	/* ����ZAKLMK */
	tHsmOpr.saOprType = HSM_CHANGEZAK;
	nReturncode = nEncOpr(&tHsmOpr);
	if (nReturncode != 0)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_CHANGEZAK nEncOpr error nReturncode[%d] ", nReturncode);
		memcpy(ptIpcIntMng->sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}
	
	
	/**************************
	 �����ܻ���ȡ������ԿZPK 
	 **************************/
	tHsmOpr.saOprType = HSM_GENZPK;
	memcpy(tHsmOpr.saRout, "Y", 1);
	if(memcmp(ptIpcIntMng->sMsgSrcId, SRV_ID_COMM_P, 4) == 0)
	    memcpy(tHsmOpr.saRout+1,"0005", 4);
	else if(memcmp(ptIpcIntMng->sMsgSrcId, SRV_ID_COMM_MZ, 4) == 0)
	    memcpy(tHsmOpr.saRout+1,"0008", 4);
	nReturncode = nEncOpr(&tHsmOpr);
	if (nReturncode != 0)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_GENZPK nEncOpr error nReturncode[%d] ", nReturncode);
		memcpy(ptIpcIntMng->sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}
	
	/* ����ZPKLMK */
	tHsmOpr.saOprType = HSM_CHANGEZPK;
	nReturncode = nEncOpr(&tHsmOpr);
	if (nReturncode != 0)
	{
		HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "HSM_CHANGEZPK nEncOpr error nReturncode[%d] ", nReturncode);
		memcpy(ptIpcIntMng->sRespCode, F039_MAL_FUNCTION, F039_LEN);
		return -1;
	}
	
	/*F048*/
	i = 0;
	ptIpcIntMng->cF048Ind = 'Y';
	memcpy(ptIpcIntMng->sAddtnlDataPrivateLen, "036", 3);
	Str2Hex(tHsmOpr.saZAK, ptIpcIntMng->sAddtnlDataPrivate+i, 16);
	i += 8;
	memcpy(ptIpcIntMng->sAddtnlDataPrivate+i, tHsmOpr.saZAKChkV, 6);
	i += 6;
	
	Str2Hex(tHsmOpr.saZPK, ptIpcIntMng->sAddtnlDataPrivate+i, 32);
	i += 16;
	memcpy(ptIpcIntMng->sAddtnlDataPrivate+i, tHsmOpr.saZPKChkV, 6);
	
	/*HeaderBuf*/	
	memset(&ptIpcIntMng->sHeaderBuf[0], 0x2e,1);//ͷ1��ͷ����
	memset(&ptIpcIntMng->sHeaderBuf[1], 0x01,1);//ͷ2���汾��ʶ
	memset(&ptIpcIntMng->sHeaderBuf[2],'0',4);//ͷ3���������ĳ���
	memcpy(&ptIpcIntMng->sHeaderBuf[6],ptIpcIntMng->sRcvgInstIdCode,8);//ͷ4��Ŀ��ID
	memcpy(&ptIpcIntMng->sHeaderBuf[14],"   ",3);
	memcpy(&ptIpcIntMng->sHeaderBuf[17],CUP_INST_ID,8);//ͷ5��ԴID
	memcpy(&ptIpcIntMng->sHeaderBuf[25],"   ",3);
	memset(&ptIpcIntMng->sHeaderBuf[28],0x00,4);//ͷ6������ʹ�ã�24bit����ͷ7��1bit��
	memset(&ptIpcIntMng->sHeaderBuf[32],'0',8);//ͷ8��������Ϣ
	memset(&ptIpcIntMng->sHeaderBuf[40],0x00,1);//ͷ9���û���Ϣ
	memset(&ptIpcIntMng->sHeaderBuf[41],'0',5);//ͷ10���ܾ���
	/*HeaderBuf over*/
	
	/* �ָ�ATMC��F007
	sprintf(ptIpcIntMng->sTransmsnDateTime, "%4.4s%6.6s", ptIpcIntMng->sDateLocalTrans, ptIpcIntMng->sTimeLocalTrans);*/

	/* Ŀ��ID */
	/*memcpy(ptIpcIntMng->sMsgDestId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);*/
	if(memcmp(ptIpcIntMng->sMsgSrcId, SRV_ID_COMM_P, 4) == 0)
	    memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_P, 4);/*POSP*/
	else if(memcmp(ptIpcIntMng->sMsgSrcId, SRV_ID_COMM_MZ, 4) == 0)
	    memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_MZ, 4);
	
	/* �ı佻���� */
	ptIpcIntMng->sTxnNum[3]++;

	memcpy(ptIpcIntMng->sRespCode, F039_SUCCESS, F039_LEN);

	/*��¼���ݿ�*/
	memset(sCurrentTime,0x00,sizeof(sCurrentTime));
	CommonGetCurrentTime (sCurrentTime);
	memcpy (ptIpcIntMng->sSysSeqNum, sCurrentTime+8, F011_LEN);
	
	DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;         
	}
	DbsCommit ();
	
	HtLog(gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Txn6225 success  end ");

	return 0;
}
