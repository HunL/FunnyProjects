/****************************************************************
 *	�� �� ��: Txn631.c 
 *	��    ��: ����̨��������
 *	�����Ա: ���� 
 *	���ʱ��: 2005/04/20
 *	��    ע: ���״���:6311
 * 	Copyright (c) 2005 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn631.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6311(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sPwd[17],sNewPwd[17];
	char    sFileName[128];
	FILE    *fp;
	int		i;

	memcpy(ptIpcIntMng->sMsgDestId, ptIpcIntMng->sMsgSrcId, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	ptIpcIntMng->sTxnNum[3]++;
	memcpy(ptIpcIntMng->sRespCode, "00", F039_LEN);

	memset(sPwd,0,sizeof(sPwd));
	memset(sNewPwd,0,sizeof(sNewPwd));
	memset(sFileName,0,sizeof(sFileName));
	memset(sFileName,0,sizeof(sFileName));
	
	sprintf(sFileName, "%s/etc/pwd.dat", getenv("FEHOME"));
	fp = fopen (sFileName, "r");
	if(fp == NULL)
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"open file[%s] error", sFileName);
		return -1;
	}
	if( fgets (sPwd, 16, fp) == NULL )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
				"read from file[%s] error", sFileName);
		return -2;
	}
	
	for(i=0;i<strlen(sPwd);i++) sNewPwd[i] = sPwd[i] + '1';

	sprintf(ptIpcIntMng->sAddtnlDataPrivateLen, "%03ld", strlen(sNewPwd));
	strcpy(ptIpcIntMng->sAddtnlDataPrivate, sNewPwd);

	return 0;
}
