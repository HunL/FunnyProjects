/****************************************************************
 *	�� �� ��: Txn6433.c 
 *	��    ��: �����ÿ�ϵͳ����ǩ�˴���,˫�� 
 *	�����Ա: ���� 
 *	���ʱ��: 2005/04/20
 *	��    ע: ���״���:6141 6142 6143 6144
 * 	Copyright (c) 2005 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn6433.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6433(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     nReturncode;
	
    memcpy(ptIpcIntMng->sMsgDestId, "1902", SRV_ID_LEN);
	/*memcpy(ptIpcIntMng->sMsgDestId, "1720", SRV_ID_LEN); /*�������*/
	/*memset(ptIpcIntMng->sMsqType, ' ', FLD_MSQ_TYPE_LEN);*/

	CommonGetCurrentTime (sCurrentTime);
        
	memcpy (ptIpcIntMng->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
	memcpy (ptIpcIntMng->sSysSeqNum, sCurrentTime+8, F011_LEN);
	memcpy (ptIpcIntMng->sSysTraceAuditNum, sCurrentTime+8, F011_LEN);
	memcpy(ptIpcIntMng->sTimeLocalTrans, sCurrentTime+8, F012_LEN);
    memcpy(ptIpcIntMng->sDateLocalTrans, sCurrentTime+4, F013_LEN);
	
	/*װ������*/
	
	ptIpcIntMng->cF048Ind = 'Y';
	memset(ptIpcIntMng->sAddtnlDataPrivate, ' ', 256);

    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();

	return 0;
}

int Txn6434(T_IpcIntMngDef *ptIpcIntMng)
{
	char	sCurrentTime[15];
	int		nReturncode;

	
	CommonGetCurrentTime (sCurrentTime);

	/*memcpy(ptIpcIntMng->sTransmsnDateTime,ptIpcIntMng->sDateLocalTrans,4);
	memcpy(ptIpcIntMng->sTransmsnDateTime+4,ptIpcIntMng->sTimeLocalTrans,6);*/
	
	if(!memcmp(ptIpcIntMng->sGfHeader+173,"01",2) )
        {
            memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
            memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CON, SRV_ID_LEN);
            memcpy(ptIpcIntMng->sRespCode, "00", F039_LEN);
            memcpy(ptIpcIntMng->sMisc, ptIpcIntMng->sRespCode, F039_LEN);
        }
    else if (!memcmp(ptIpcIntMng->sGfHeader+173,"00",2))
    	{
            memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
            memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CON, SRV_ID_LEN);
            memcpy(ptIpcIntMng->sRespCode, "-1", F039_LEN);
            memcpy(ptIpcIntMng->sMisc, ptIpcIntMng->sRespCode, F039_LEN);
    	}
	
    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_UPDATE,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}   
    DbsCommit ();

	if(nReturncode = DbsManagerIn(DBS_SELECT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_SELECT error, %d", errno);
		return nReturncode;
	}
	
	memcpy(ptIpcIntMng->sMiscFlag, "6434", 4);
	 
	return 0;
}

