/****************************************************************
 *	�� �� ��: Txn612.c 
 *	��    ��: ����ǩ��,����,�������� 
 *	�����Ա: ���� 
 *	���ʱ��: 2005/04/20
 *	��    ע: ���״���:6121 6122 
 * 	Copyright (c) 2005 by Huateng Co. All rights reserved.
 *****************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/Manage/Txn612.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";
#include "Manage.h"

int Txn6121(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     nReturncode;

	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUP, SRV_ID_LEN);

	CommonGetCurrentTime (sCurrentTime);
#if 0
	memcpy (ptIpcIntMng->sTransmsnDateTime, sCurrentTime+4, F007_LEN);
	memcpy (ptIpcIntMng->sSysSeqNum, sCurrentTime+8, F011_LEN);
	memcpy (ptIpcIntMng->sSysTraceAuditNum, sCurrentTime+8, F011_LEN);
  /*װ������*/
  sprintf(ptIpcIntMng->sAcqInstIdCodeLen,"%2.2d",8);	
	memcpy (ptIpcIntMng->sAcqInstIdCode, ptIpcIntMng->sAddtnlDataPrivate, 8);
	sprintf(ptIpcIntMng->sFwdInstIdCodeLen,"%2.2d",8);
//	memcpy (ptIpcIntMng->sFwdInstIdCode, ptIpcIntMng->sAddtnlDataPrivate, 8);
   	/*memcpy (ptIpcIntMng->sFwdInstIdCode, ptIpcIntMng->sAddtnlDataPrivate, 8);*/
	/* 2011��4��28�� Ԭ�� ���� ���� 03060000*/
	memcpy(ptIpcIntMng->sFwdInstIdCode,BANK_INST_ID,8);
	memcpy (ptIpcIntMng->sNetwkMgmtInfoCode, "002", 3);
		ptIpcIntMng->cF100Ind = 'Y';
	sprintf(ptIpcIntMng->sRcvgInstIdCodeLen,"%2.2d",8);
	memcpy (ptIpcIntMng->sRcvgInstIdCode, ptIpcIntMng->sAddtnlDataPrivate, 8);
		/*HeaderBuf*/
	memset(&ptIpcIntMng->sHeaderBuf[0], 0x2e,1);//ͷ1��ͷ����
	memset(&ptIpcIntMng->sHeaderBuf[1], 0x01,1);//ͷ2���汾��ʶ
	memset(&ptIpcIntMng->sHeaderBuf[2],'0',4);//ͷ3���������ĳ���
	memcpy(&ptIpcIntMng->sHeaderBuf[6],CUP_INST_ID,8);//ͷ4��Ŀ��ID
	memcpy(&ptIpcIntMng->sHeaderBuf[14],"   ",3);
	memcpy(&ptIpcIntMng->sHeaderBuf[17],ptIpcIntMng->sFwdInstIdCode,8);//ͷ5��ԴID
	memcpy(&ptIpcIntMng->sHeaderBuf[25],"   ",3);//ͷ5��ԴID
	memset(&ptIpcIntMng->sHeaderBuf[28],0x00,4);//ͷ6������ʹ�ã�24bit����ͷ7��1bit��
	memset(&ptIpcIntMng->sHeaderBuf[32],'0',8);//ͷ8��������Ϣ
	memset(&ptIpcIntMng->sHeaderBuf[40],0x00,1);//ͷ9���û���Ϣ
	memset(&ptIpcIntMng->sHeaderBuf[41],'0',5);//ͷ10���ܾ���
 /*HeaderBuf over*/
#endif

    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_INSERT,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsManagerIn DBS_INSERT error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();
	
	return 0;
}

int Txn6122(T_IpcIntMngDef *ptIpcIntMng)
{
	char    sCurrentTime[15];
	int     nReturncode;
	
	CommonGetCurrentTime (sCurrentTime);

    DbsBegin ();
	if(nReturncode = DbsManagerIn(DBS_UPDATE,ptIpcIntMng,sCurrentTime))
	{
	    DbsRollback ();
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsManagerIn DBS_UPDATE error, %d", errno);
		return nReturncode;
	}
	DbsCommit ();   

	if(nReturncode = DbsManagerIn(DBS_SELECT,ptIpcIntMng,sCurrentTime))
	{
		HtLog (gsLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"DbsManagerIn DBS_SELECT error, %d", errno);
		return nReturncode;
	}  

	memcpy(ptIpcIntMng->sMsgSrcId, SRV_ID_MANAGE, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMsgDestId, SRV_ID_COMM_CUPS, SRV_ID_LEN);
	memcpy(ptIpcIntMng->sMisc, ptIpcIntMng->sRespCode, F039_LEN);
        
	return 0;
}
