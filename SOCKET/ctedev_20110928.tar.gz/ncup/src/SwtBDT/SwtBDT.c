/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Switch.c                                                    */
/* DESCRIPTIONS:                                                             */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char *Id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBDT/SwtBDT.c,v 1.1.1.1 2011/08/19 10:56:06 ctedev Exp $";

#include "SwtBDT.h"
#include "SwtBdtTxn.h"

int main( int argc, char **argv )
{
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    char            sIntMsgBuf[MSQ_MSG_SIZE_MAX];
    char            sTxnType[FLD_TXN_NUM_LEN+1];
    int             i;
    int             nTxnType;
    int             nReturnCode;
    int             nMsgLen;
    int             nIntMsgLen;
    int             nIndex;
    long            lBeginTime, lEndTime;
    T_IpcIntTxnDef    tIpcIntTxn;
    struct tms        tTMS;

    nReturnCode = SwitchInit( argc, argv);
    if ( nReturnCode != 0 )
    {
        printf("Switch: SwitchInit error %d\n", nReturnCode);
        return;
    }

    if (sigset(SIGTERM, HandleExit) == SIG_ERR)
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sigset SIGTERM error, %d.", errno);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Switch started.");

    lBeginTime = 0;
    lEndTime = 0;

    while(1)
    {
        /* ����Ϣ�����л�ȡ��Ϣ */
        memset (sMsgBuf, 0, sizeof(sMsgBuf) );
        sigrelse (SIGTERM);
        nMsgLen = MSQ_MSG_SIZE_MAX;
        nReturnCode = MsqRcv (gsSrvId, gatSrvMsq, 0, MSQ_RCV_MODE_BLOCK, &nMsgLen, sMsgBuf);
        sighold (SIGTERM);
        if (nReturnCode)
        {
            if (nReturnCode != ERR_CODE_MSQ_BASE + EINTR)
            {
                HtLog( gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqRcv error, %d.", nReturnCode);
                return;
            }
            else
                continue;
        }

        lBeginTime = times( &tTMS);
        /* uncompress msg */
        if (!strcmp (gsParamMsgCompressFlag, FLAG_YES))
        {
            /* uncompress msg */
            /* sMsgBuf, nMsgLen -> sIntMsgBuf, nIntMsgLen */
            UnCompressbuf(sMsgBuf, nMsgLen, sIntMsgBuf, &nIntMsgLen);

            nMsgLen = nIntMsgLen;
            memcpy (sMsgBuf, sIntMsgBuf, nIntMsgLen);
        }

        HtLog( gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "%s", LINE_SEPARATOR);
        HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,    __LINE__, sMsgBuf, nMsgLen);

        /* process msg according to msg source */
        memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
        memcpy (sMsgSrcId, sMsgBuf, SRV_ID_LEN);

        if (!memcmp (sMsgSrcId, SRV_ID_TOCTL, SRV_ID_LEN))
            nReturnCode = HandleTimeOut (sMsgBuf);
        else
        {
            memcpy ((char *)&tIpcIntTxn, sMsgBuf, sizeof (tIpcIntTxn));
            
            /* Save front SSN in sTermSSN */
            memcpy (tIpcIntTxn.sTermSSN, tIpcIntTxn.sSysTraceAuditNum, F011_LEN);
            memcpy (tIpcIntTxn.sOpenInst, gsSrvId, 4);
           
			if (!memcmp(sMsgSrcId, SRV_ID_COMM_P, 2) || !memcmp(sMsgSrcId, "1603", SRV_ID_LEN))
			{
				GMTInit(&tIpcIntTxn,nMsgLen);
			}            

       	    if(tIpcIntTxn.sTxnNum[INDEX_TXN_NUM_REQ_RSP] == TXN_NUM_BDT_REQ)
			{
					nReturnCode = GetTxnInfoIndex( tIpcIntTxn.sMsgSrcId, tIpcIntTxn.sTxnNum, &nIndex );
			}
			else
			{
					nReturnCode = 0;
			}                  
                 
            if ( nReturnCode != 0 )
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GetTxnInfoIndex error.");
                return -1;
            }
            memcpy( tIpcIntTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );/*add by fucl*/

            for( i = 0; i < MAXTXNS; i++ )
            {
                if( memcmp( tIpcIntTxn.sTxnNum, gaTxns[i].caTxnNum, FLD_TXN_NUM_LEN ) == 0 )
                {
                    if (memcmp( gaTxns[i].caMsgSrcId, MSG_SRC_ID_ANY, SRV_ID_LEN ) == 0 )
                    {
                        break;
                    }
                    else
                    {
                        if (memcmp( tIpcIntTxn.sMsgSrcId, gaTxns[i].caMsgSrcId, SRV_ID_LEN ) == 0 )
                        {
                            break;
                        }
                    }
                }
            }
            
            /*�������ݿ��Ƿ�״̬�ļ�� add 20110718*/		
            nReturnCode = -1;
            nReturnCode = DbReconnectTest();
            if(nReturnCode != 0)
            {
			 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 	"\n  TXN: %4.4s\n  F002: %19.19s\n  F004: %12.12s\n  F007: %10.10s\n F011: %6.6s\n", 
			 	gatTxnInf[nIndex].txn_num, tIpcIntTxn.sPrimaryAcctNum, tIpcIntTxn.sAmtTrans, 	tIpcIntTxn.sTransmsnDateTime, tIpcIntTxn.sSysTraceAuditNum);    
			 	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DataBase status is error ,Discard this message, nReturnCode=[%d]", nReturnCode);    	       
		    } /*  added end */
		    else
            {
                if( i == MAXTXNS )
                {
                    nReturnCode = SwtCustHandleTransaction(&tIpcIntTxn, nIndex);
                }
                else
                {
                    nReturnCode = gaTxns[i].pfTxnFun(&tIpcIntTxn, nIndex);
                }
            }

            lEndTime = times( &tTMS);
            HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "Txn %s processed, used %ld ticks  i is %d",
                    gaTxns[i].caTxnNum, lEndTime - lBeginTime, i);
        }

    }

}
/*****************************************************************************/
/* FUNC:   int SwitchInit ( );                                               */
/* INPUT:  argc: ��������                                                    */
/*         argv: ����                                                        */
/* OUTPUT: NULL                                                              */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ʼ��ϵͳ��̬����,����,������Ϣ��                                */
/*****************************************************************************/
int SwitchInit (short argc, char **argv)
{
    int                i;
    int                nReturnCode;
    long            lUsageKey;
    Tbl_srv_inf_Def    tTblSrvInf;

    /* get server id, arg 1 */
    strcpy (gsSrvId, argv[1]);
    strcpy (gsSrvSeqId, argv[2]);
    /* get parameter, compress flag */
    if (getenv(MSG_COMPRESS_FLAG))
    {
        strcpy (gsParamMsgCompressFlag, getenv(MSG_COMPRESS_FLAG));
    }
    else
        strcpy (gsParamMsgCompressFlag, FLAG_NO);

    if (getenv(SRV_USAGE_KEY))
        lUsageKey=atoi (getenv(SRV_USAGE_KEY));
    else
        return -1;
    
    if (getenv(MAC_FLAG))
        strcpy(gsMacFlag, getenv(MAC_FLAG));
    else
        return -1;
        
    /* connect to database */
    nReturnCode = DbsConnect ();
    if (nReturnCode)
        return (nReturnCode);

    /* get log file name from tbl_srv_inf */
    memset ((char *)&tTblSrvInf, 0x00, sizeof (tTblSrvInf));
    tTblSrvInf.usage_key = lUsageKey;
    memcpy (tTblSrvInf.srv_id, gsSrvId, SRV_ID_LEN);
    nReturnCode = DbsSRVINF (DBS_SELECT, &tTblSrvInf);
    if (nReturnCode)
    {
        DbsDisconnect ();
        return (nReturnCode);
    }
    CommonRTrim(tTblSrvInf.srv_name);
    sprintf (gsLogFile, "%s.%s.log", gsSrvId, gsSrvSeqId);

    /* init msg queue */
    memset ((char *)gatSrvMsq, 0, SRV_MSQ_NUM_MAX * sizeof (T_SrvMsq));
    nReturnCode = MsqInit (gsSrvId, gatSrvMsq);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "MsqInit error, %d.", nReturnCode);
        DbsDisconnect ();
        return (nReturnCode);
    }
    /* ��ʼ��������Ϣ�� */
    memset( (char *)gatTxnInf, 0, sizeof(gatTxnInf) );
    gnTxnInfNum = TXN_INF_NUM_MAX;
    nReturnCode = DbsTxnInfLoad (&gnTxnInfNum, gatTxnInf);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxnInfLoad error, %d.", nReturnCode);
        DbsDisconnect ();
        return (nReturnCode);
    }

    return 0;
}

/*****************************************************************************/
/* FUNC:   int GetTxnInfoIndex                                               */
/* INPUT:  ���״���                                                          */
/* OUTPUT: ��Ӧ��gatTblTxnInf�ṹ������, δ�ҵ�ʱֵΪ-1                      */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���״�����db_txn_inf�ṹ������                                  */
/*****************************************************************************/
int GetTxnInfoIndex( char *sMsgSrcId, char *sTxnNum, int *nIndex )
{
    char    sFuncName[] = "GetTxnInfoIndex";
    int        i;
    
          	

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    *nIndex = -1;
    for( i = 0; i < gnTxnInfNum; i++ )
    {
        if (!memcmp(gatTxnInf[i].msg_src_id, sMsgSrcId, SRV_ID_LEN) &&
                !memcmp(gatTxnInf[i].txn_num, sTxnNum, FLD_TXN_NUM_LEN) )
        {
            *nIndex = i;
            break;
        }
    }

    if( i == gnTxnInfNum )
    {
        HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", sTxnNum, sMsgSrcId);
    }

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end  index is %d.", sFuncName, i);
    
   
    
    
    return 0;
}

void HandleExit (int n)
{
    DbsDisconnect ();
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Switch exits.");
    exit( 1 );
}

void showIpc(T_IpcIntTxnDef *InIpc)
{
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgSrcId:\t%.4s", InIpc->sMsgSrcId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgDestId:\t%.4s", InIpc->sMsgDestId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsqType:\t%.16s", InIpc->sMsqType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvTxnNum:\t%.1s", InIpc->sConvTxnNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSysSeqNum:\t%.6s", InIpc->sSysSeqNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransType:\t%.1s", InIpc->sTransType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransState:\t%.1s", InIpc->sTransState);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostDate:\t%.8s", InIpc->sHostDate);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostSSN:\t%.12s", InIpc->sHostSSN);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTermSSN:\t%.12s", InIpc->sTermSSN);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyRsp:\t%.32s", InIpc->sKeyRsp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyRevsal:\t%.32s", InIpc->sKeyRevsal);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sKeyCancel:\t%.32s", InIpc->sKeyCancel);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHeaderBuf:\t%.46s", InIpc->sHeaderBuf);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTxnNum:\t%.4s", InIpc->sTxnNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransCode:\t%.3s", InIpc->sTransCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgType:\t%.4s", InIpc->sMsgType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF002Ind:\t%c", InIpc->cF002Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPrimaryAcctNumLen:\t%.2s", InIpc->sPrimaryAcctNumLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPrimaryAcctNum:\t%.19s", InIpc->sPrimaryAcctNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sProcessingCode:\t%.6s", InIpc->sProcessingCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtTrans:\t%.12s", InIpc->sAmtTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtSettlmt:\t%.12s", InIpc->sAmtSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtCdhldrBil:\t%.12s", InIpc->sAmtCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransmsnDateTime:\t%.10s", InIpc->sTransmsnDateTime);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvRateSettlmt:\t%.8s", InIpc->sConvRateSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sConvRateCdhldrBil:\t%.8s", InIpc->sConvRateCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSysTraceAuditNum:\t%.6s", InIpc->sSysTraceAuditNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTimeLocalTrans:\t%.6s", InIpc->sTimeLocalTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateLocalTrans:\t%.4s", InIpc->sDateLocalTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF014Ind:\t%c", InIpc->cF014Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateExpr:\t%.4s", InIpc->sDateExpr);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateSettlmt:\t%.4s", InIpc->sDateSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sDateConv:\t%.4s", InIpc->sDateConv);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMchntType:\t%.4s", InIpc->sMchntType);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstCntryCode:\t%.3s", InIpc->sAcqInstCntryCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosEntryModeCode:\t%.3s", InIpc->sPosEntryModeCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardSeqId:\t%.3s", InIpc->sCardSeqId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosCondCode:\t%.2s", InIpc->sPosCondCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF026Ind:\t%c", InIpc->cF026Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPosPinCaptrCode:\t%.2s", InIpc->sPosPinCaptrCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF028Ind:\t%c", InIpc->cF028Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAmtTransFee:\t%.9s", InIpc->sAmtTransFee);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstIdCodeLen:\t%.2s", InIpc->sAcqInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstIdCode:\t%.11s", InIpc->sAcqInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwdInstIdCodeLen:\t%.2s", InIpc->sFwdInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFwdInstIdCode:\t%.11s", InIpc->sFwdInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF035Ind:\t%c", InIpc->cF035Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack2DataLen:\t%.2s", InIpc->sTrack2DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack2Data:\t%.37s", InIpc->sTrack2Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF036Ind:\t%c", InIpc->cF036Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack3DataLen:\t%.3s", InIpc->sTrack3DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack3Data:\t%.104s", InIpc->sTrack3Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRetrivlRefNum:\t%.12s", InIpc->sRetrivlRefNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF038Ind:\t%c", InIpc->cF038Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAuthrIdResp:\t%.6s", InIpc->sAuthrIdResp);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRespCode:\t%.2s", InIpc->sRespCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrTermnlId:\t%.8s", InIpc->sCardAccptrTermnlId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrId:\t%.15s", InIpc->sCardAccptrId);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCardAccptrNameLoc:\t%.40s", InIpc->sCardAccptrNameLoc);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF044Ind:\t%c", InIpc->cF044Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlRespCodeLen:\t%.2s", InIpc->sAddtnlRespCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlRespCode:\t%.25s", InIpc->sAddtnlRespCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack1DataLen:\t%.2s", InIpc->sTrack1DataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTrack1Data:\t%.79s", InIpc->sTrack1Data);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataPrivateLen:\t%.3s", InIpc->sAddtnlDataPrivateLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataPrivate:\t%.512s", InIpc->sAddtnlDataPrivate);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeTrans:\t%.3s", InIpc->sCurrcyCodeTrans);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeSettlmt:\t%.3s", InIpc->sCurrcyCodeSettlmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sCurrcyCodeCdhldrBil:\t%.3s", InIpc->sCurrcyCodeCdhldrBil);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF052Ind:\t%c", InIpc->cF052Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sPinData:\t%.8s", InIpc->sPinData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF053Ind:\t%c", InIpc->cF053Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSecRelatdCtrlInfo:\t%.16s", InIpc->sSecRelatdCtrlInfo);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF054Ind:\t%c", InIpc->cF054Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlAmtLen:\t%.3s", InIpc->sAddtnlAmtLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlAmt:\t%.120s", InIpc->sAddtnlAmt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlDataLen:\t%.3s", InIpc->sAddtnlDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAddtnlData:\t%.100s", InIpc->sAddtnlData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFldReservedLen:\t%.3s", InIpc->sFldReservedLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFldReserved:\t%.30s", InIpc->sFldReserved);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sChAuthInfoLen:\t%.3s", InIpc->sChAuthInfoLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sChAuthInfo:\t%.200s", InIpc->sChAuthInfo);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF062Ind:\t%c", InIpc->cF062Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSwitchingDataLen:\t%.3s", InIpc->sSwitchingDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sSwitchingData:\t%.200s", InIpc->sSwitchingData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFinaclNetDataLen:\t%.3s", InIpc->sFinaclNetDataLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sFinaclNetData:\t%.200s", InIpc->sFinaclNetData);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sOrigDataElemts:\t%.42s", InIpc->sOrigDataElemts);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sReplacementAmts:\t%.42s", InIpc->sReplacementAmts);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMsgSecurityCode:\t%.8s", InIpc->sMsgSecurityCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRcvgInstIdCodeLen:\t%.2s", InIpc->sRcvgInstIdCodeLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sRcvgInstIdCode:\t%.11s", InIpc->sRcvgInstIdCode);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF102Ind:\t%c", InIpc->cF102Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId1Len:\t%.2s", InIpc->sAcctId1Len);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId1:\t%.28s", InIpc->sAcctId1);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF103Ind:\t%c", InIpc->cF103Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId2Len:\t%.2s", InIpc->sAcctId2Len);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcctId2:\t%.28s", InIpc->sAcctId2);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF104Ind:\t%c", InIpc->cF104Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransDescrptLen:\t%.3s", InIpc->sTransDescrptLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTransDescrpt:\t%.100s", InIpc->sTransDescrpt);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF121Ind:\t%c", InIpc->cF121Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sNationalSwResvedLen:\t%.3s", InIpc->sNationalSwResvedLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sNationalSwResved:\t%.100s", InIpc->sNationalSwResved);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF122Ind:\t%c", InIpc->cF122Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstResvdLen:\t%.3s", InIpc->sAcqInstResvdLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sAcqInstResvd:\t%.100s", InIpc->sAcqInstResvd);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF123Ind:\t%c", InIpc->cF123Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sIssrInstResvdLen:\t%.3s", InIpc->sIssrInstResvdLen);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sIssrInstResvd:\t%.100s", InIpc->sIssrInstResvd);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF064Ind:\t%c", InIpc->cF064Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMAC064:\t%.8s", InIpc->sMAC064);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "cF128Ind:\t%c", InIpc->cF128Ind);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMAC128:\t%.8s", InIpc->sMAC128);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostTransFee1:\t%.12s", InIpc->sHostTransFee1);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sHostTransFee2:\t%.12s", InIpc->sHostTransFee2);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sTlrNum:\t%.8s", InIpc->sTlrNum);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sOpenInst:\t%.15s", InIpc->sOpenInst);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sStlmInst:\t%.15s", InIpc->sStlmInst);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMiscFlag:\t%.32s", InIpc->sMiscFlag);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "sMisc:\t%.128s", InIpc->sMisc);
    HtLog ("InIpc.log", 1, __FILE__,__LINE__, "===========================================================\n" );
}
/*****************************************************************************/
/* FUNC:   int GMTInit(T_IpcIntTxnDef *pIpcIntTxn,int nMsgLen)         */
/* INPUT:  pIpcIntTxn: ����������Ϣ, ��ʽ���ڲ���IPC�ṹ                   */
/*         nMsgLen: ��Ϣ����                                                */
/* OUTPUT: pIpcIntTxn: ��ʼ�������ֵ                                       */
/*                          												 */
/* RETURN: 0: �ɹ�, ����: ʧ��                                              */
/* DESC:   ��ʼ���ɹ���ͨ���׸������ֵ               */
/*                                               							 */
/*****************************************************************************/
int GMTInit (T_IpcIntTxnDef *pIpcIntTxn, int nMsgLen)
{
	char   sTemp[50];
	char   sF11Code[20];
	char  sTransAmt[12 + 1];
	char  sTxnNum[4 + 1];
	int   nReturn;
	int i = 0;
	int nLen=0;

	memset(sTemp,0,sizeof(sTemp));
	memset(sTxnNum,0,sizeof(sTxnNum) );
	
	nReturn = 0;
	
	memcpy(sTxnNum,pIpcIntTxn->sTxnNum,4);
	
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
							"GMTInit Begin:");
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
					"sTxnNum[%s].",sTxnNum);
					
			
						
	switch(sTxnNum[INDEX_TXN_NUM_REQ_RSP])
	{
		case TXN_NUM_BDT_REQ:
			/*HeaderBuf*/
			pIpcIntTxn->sConvTxnNum[0] = 'N';
			memset(&pIpcIntTxn->sHeaderBuf[0], 0x2e,1);//ͷ1��ͷ����
			memset(&pIpcIntTxn->sHeaderBuf[1], 0x01,1);//ͷ2���汾��ʶ
			memset(&pIpcIntTxn->sHeaderBuf[2],'0',4);//ͷ3���������ĳ���
			memcpy(&pIpcIntTxn->sHeaderBuf[6],CUP_INST_ID,8);//ͷ4��Ŀ��ID
			memcpy(&pIpcIntTxn->sHeaderBuf[14],"   ",3);
	
			memset(&pIpcIntTxn->sHeaderBuf[28],0x00,4);//ͷ6������ʹ�ã�24bit����ͷ7��8bit��
			memset(&pIpcIntTxn->sHeaderBuf[32],'0',8);//ͷ8��������Ϣ
			memset(&pIpcIntTxn->sHeaderBuf[40],0x00,1);//ͷ9���û���Ϣ
			memset(&pIpcIntTxn->sHeaderBuf[41],'0',5);//ͷ10���ܾ���
			/*HeaderBuf over*/
			
			//TransType
			if(memcmp(pIpcIntTxn->sMsgSrcId, SRV_ID_COMM_P, 2) == 0)
			    memcpy(pIpcIntTxn->sTransType, TRANS_TYPE_POS, FLD_TRANS_TYPE_LEN);
			else if(memcmp(pIpcIntTxn->sMsgSrcId, "1603", 4) == 0)
			    memcpy(pIpcIntTxn->sTransType, TRANS_TYPE_ATM, FLD_TRANS_TYPE_LEN);
						
			memcpy(&pIpcIntTxn->sHeaderBuf[17],pIpcIntTxn->sAcqInstIdCode,11);//ͷ5��ԴID
			break;
		default:
			break;
	}
	
	HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,	__LINE__, 
				(char *)pIpcIntTxn, nMsgLen);
	HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "GMTInit End."); 
	
	 
	
	
	return 0;	
}
