/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: CancelRevsal.c                                              */
/* DESCRIPTIONS: handle cancel reversal req its rsp                          */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-04-30  YU TONG        Initialize                                     */
/*****************************************************************************/
static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBDT/TCCancelRevsalBDT.c,v 1.1.1.1.4.6 2011/09/23 02:54:35 ctedev Exp $";

#include "SwtBDT.h"

int TCHandleBDTCancelRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
    char            sFuncName[] = "TCHandleBDTCancelRevsalReq";
    char            sRespCode[F039_LEN+1];
    char            sTxnNum[FLD_TXN_NUM_LEN+1];
    int             nReturnCode;
    int             i;
    int             nRevsalIndex;
    T_SwtToReqDef    tSwtToReq;
    Tbl_txn_Def        tTxn, tOrigTxn, tOrigCancelTxn;
    Tbl_ic_txn_Def  tIcTxn;
    T_IpcIntTxnDef    tSendIpcIntTxn, tSendIpcIntTxn1;
    char            sCurrentDate[14+1];
    char            sF055Len[F055_LEN_LEN+1] = {0};
    
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    if (nIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sMsgSrcId);

        return -1;
    }
    
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    /*CommonGetCurrentTime(sCurrentDate);*/
    /***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex);
    memcpy(sCurrentDate, gsTimeCurTs, 14);
    memcpy(ptIpcIntTxn->sMiscFlag, sCurrentDate, 14);

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %12.12s\n  orig data elem: %42.42s\n",
            gatTxnInf[nIndex].txn_num, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
            ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, ptIpcIntTxn->sTermSSN,
            ptIpcIntTxn->sOrigDataElemts);

    /* ����ǰ��F007,F011��sMisc */
    memcpy(ptIpcIntTxn->sMisc,ptIpcIntTxn->sTransmsnDateTime,F007_LEN);
    memcpy(ptIpcIntTxn->sMisc+F007_LEN,ptIpcIntTxn->sSysTraceAuditNum,F011_LEN);
            

    /*******************
     * �жϸý����Ƿ�֧��
     ********************/
    if ( memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /*����15��*/
		ptIpcIntTxn->cF015Ind = 'Y';
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        /* clear F038 */
        ptIpcIntTxn->cF038Ind = FLAG_NO_C;
        /* clear F090 */
        memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
        
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);    /* by gjch */
        
        HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
		    
        return -1;
    }

#if 0
    /***************
     * ������ˮ��
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
    tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
    memcpy (tSwtToReq.sTxnDate, ptIpcIntTxn->sTransmsnDateTime, F007_LEN );

    nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
    if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "ToCtrlReq error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */
        return -1;
    }
    /* save ssn in ipc */
    memcpy (ptIpcIntTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
    memcpy(ptIpcIntTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);
#endif

    memcpy (ptIpcIntTxn->sSysSeqNum, ptIpcIntTxn->sSysTraceAuditNum, F011_LEN);
    
    /* ��key_rsp, key_revsal��ֵ */
    nReturnCode = SetKeyRevsal (ptIpcIntTxn);
    nReturnCode = SetKeyRsp (ptIpcIntTxn);

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Discard this Transation", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        return -1;
    }

    /***************
     * У��MAC
     ****************/
    if(gsMacFlag[0] == FLAG_YES_C)
    {
        nReturnCode = VerifyMAC (ptIpcIntTxn );
        if (nReturnCode != 0 )
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "VerifyMAC error, %d. Reject this transaction with %s.", nReturnCode, F039_MAC_FAIL);
        
            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, F039_MAC_FAIL, F039_LEN );
            /*����15��*/
	    	ptIpcIntTxn->cF015Ind = 'Y';
            memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            /* clear F038 */
            ptIpcIntTxn->cF038Ind = FLAG_NO_C;
            /* clear F090 */
            memset (ptIpcIntTxn->sOrigDataElemts, ' ', F090_LEN);
            
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
            
            HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
        
            /* save this txn in Db */
            DbsBegin ();
            memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
            nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
            DbsCommit ();
        
            return -1;
        }
    }

    /***************
     * �������׵������жϴ���
     ****************/
    memset ((char *)&tOrigCancelTxn, 0, sizeof (tOrigCancelTxn));
    memcpy ((char *)&tOrigCancelTxn, (char *)&tTxn, sizeof (tTxn));
    
    tOrigCancelTxn.txn_num[INDEX_TXN_NUM_TYPE] --;
    
    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
			"DbsTxn select22  txn_num=%4.4s,key_revsal=%32.32s.",
			tOrigCancelTxn.txn_num, tOrigCancelTxn.key_revsal);

    nReturnCode = DbsTxn (DBS_SELECT22, &tOrigCancelTxn );
    if(!nReturnCode)
    {
        /* save original fe ssn in revsal_ssn */
		memcpy (tTxn.revsal_ssn, tOrigCancelTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
	}

    /* �Գ�ʱ�����Ľ�����Դ�������ΪSwitch, ʹ��ԭʼ���׵Ľ�����Դ�� */
    memcpy (tTxn.msg_src_id, tOrigCancelTxn.msg_src_id, SRV_ID_LEN);

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn insert error, %d.", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

        return -1;
    }
    DbsCommit ();
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");

    DbsBegin ();
    /***************
     * �������ݿ�ԭʼ�������׼�¼
     ****************/
    memset (tOrigCancelTxn.revsal_flag, REV_CAN_FLAG_HAD, 1);
    memcpy (tOrigCancelTxn.revsal_ssn, tTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
    nReturnCode = DbsTxn (DBS_UPDATE2, &tOrigCancelTxn );
    if( nReturnCode != 0 )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn update orig cancel txn error, %d. continue this txn,", nReturnCode);
        /* do not send response for this failure, wait for resend of this reversal */

    }
    else
    {
        /***************
         * �������ݿ�ԭʼ���׼�¼
         ****************/
        memset ((char *)&tOrigTxn, 0, sizeof (tOrigTxn));
        memcpy ((char *)&tOrigTxn, (char *)&tOrigCancelTxn, sizeof (tTxn));
        tOrigTxn.txn_num[INDEX_TXN_NUM_TYPE] = tOrigTxn.txn_num[INDEX_TXN_NUM_TYPE] - 2;
        memset (tOrigTxn.cancel_flag, REV_CAN_FLAG_NORMAL, 1);
        memcpy (tOrigTxn.cancel_ssn, tOrigCancelTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN);
        nReturnCode = DbsTxn (DBS_UPDATE3, &tOrigTxn );
        if( nReturnCode != 0 )
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsTxn update orig txn error, %d. continue this txn.", nReturnCode);
            /* do not send response for this failure, wait for resend of this reversal */
        
        }
    }
    DbsCommit ();
    
    memcpy ((char *)&tSendIpcIntTxn, (char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn));

    /***********************
     *  ת��������
     ************************/
    /* send reversal to dest 1 */
    memcpy ((char *)&tSendIpcIntTxn1, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
    memcpy( tSendIpcIntTxn1.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );

    nReturnCode = SendMsg (&tSendIpcIntTxn1, &tTxn, &tOrigCancelTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d. Discard this transaction.", nReturnCode);
        return -1;
    }

    HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

#if 0
    nReturnCode = InsertSafMsg (&tSendIpcIntTxn1, &tTxn, gatTxnInf[nIndex].saf_count1);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
    }

    if (gatTxnInf[nIndex].msg_dest2[0] != ' ' &&
            gatTxnInf[nIndex].msg_dest2[0] != 0x00 &&
            gatTxnInf[nIndex].rsp_type[0] != RSP_TYPE_NO_ACCOUNT &&
            memcmp (tOrigCancelTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN) &&
            memcmp (tOrigCancelTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN) )
    {
        /* send reversal to dest 2 */
        memcpy ((char *)&tSendIpcIntTxn1, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
        memcpy( tSendIpcIntTxn1.sMsgDestId, gatTxnInf[nIndex].msg_dest2, SRV_ID_LEN );

        nReturnCode = SendMsg (&tSendIpcIntTxn1, &tTxn, &tOrigCancelTxn);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendMsg error, %d.", nReturnCode);
        }

        HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

        nReturnCode = InsertSafMsg (&tSendIpcIntTxn1, &tTxn, gatTxnInf[nIndex].saf_count2);
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
        }
    }
#endif

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);
    
    return 0;
}

int TCHandleBDTCancelRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
    char            sFuncName[] = "TCHandleBDTCancelRevsalRsp";
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sRspCode[F039_LEN+1];
    int                nReturnCode;
    int                nTxnSelOpr;
    int                nReqIndex;
    Tbl_txn_Def        tTxn, tOrigTxn;
    Tbl_ic_txn_Def  tIcTxn;
    T_IpcIntTxnDef    tSendIpcIntTxn, tSendIpcInt2;
    Tbl_saf_msg_Def    tSafMsg;
    char            sF055Len[F055_LEN_LEN+1] = {0};
    int     iMacResult;

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    SetToTime(-1);
    
    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
    memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  host SSN: %12.12s\n  response code: %2.2s",
            ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
            ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans,
            ptIpcIntTxn->sSysTraceAuditNum, ptIpcIntTxn->sHostSSN, ptIpcIntTxn->sRespCode);

    /***************
     * У��MAC
     ****************/
     iMacResult = 0;
    if(gsMacFlag[0] == FLAG_YES_C)
    {
         /* �����������A0��discard���ף���У��MAC */
        if(memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) != 0 &&
            memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0)
        {
            nReturnCode = VerifyMAC (ptIpcIntTxn );
            if (nReturnCode != 0 )
            {
                iMacResult = 1;
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "VerifyMAC error, %d. Discard this message.", nReturnCode);
                return -1;
            }
        }
    }
    

    /****************************
     * ����tbl_txn�еĽ��׼�¼
     ****************************/
    nReturnCode = SetKeyRsp (ptIpcIntTxn);

    /* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
    memset ((char *)&tTxn, 0, sizeof (tTxn));
    memcpy (tTxn.key_rsp, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
    memcpy (tTxn.txn_num, ptIpcIntTxn->sTxnNum, FLD_TXN_NUM_LEN);
    tTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
    /* �����ݿ��в���ԭ������ */
    nReturnCode = DbsTxn (DBS_SELECT21, &tTxn);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn select error, %d. Discard this message.", nReturnCode);
        return -1;
    }


    /* save F039 */
    memset (sRspCode, 0, sizeof(sRspCode));
    memcpy (sRspCode, tTxn.resp_code, F039_LEN);

    /***********************
     * ���ҽ���������gatTxnInf�е�����
     ************************/
    nReturnCode = GetTxnInfoIndex (tTxn.msg_src_id, tTxn.txn_num, &nReqIndex );
    if (nReturnCode || nReqIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
        return -1;
    }

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
        return -1;
    }

    /* set trans state */
    switch (gatTxnInf[nReqIndex].rsp_type[0])
    {
        case RSP_TYPE_NO_ACCOUNT:
            if (IsRspSuccess (ptIpcIntTxn->sRespCode))
                memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
            else
                memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_CUPS, FLD_TRANS_STATE_LEN);
            break;
        case RSP_TYPE_RSP_BEFORE_ACCOUNT:
        case RSP_TYPE_RSP_AFTER_ACCOUNT:
            if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
            {
                /* trans_state save CUPS's response, won't be changed at host response */
                if (IsRspSuccess (ptIpcIntTxn->sRespCode))
                    memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                else
                    memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_CUPS, FLD_TRANS_STATE_LEN);
                /* resp_code save host F039, not CUP F039 */
                memcpy (tTxn.resp_code, sRspCode, F039_LEN);
            }
            break;
        default:
            break;
    }

    /* ��tTxn���浽tSendIpcIntTxn, ������Ӧ����ʹ�� */
    nReturnCode = MoveTxn2Ipc (&tTxn, &tSendIpcIntTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
            "MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    
    /* ת����Ӧ�������15��ʹ�÷�����Ӧ���е�15�� */
    if (ptIpcIntTxn->cF015Ind == FLAG_YES_C)
    {
        tSendIpcIntTxn.cF015Ind = FLAG_YES_C;
        memcpy (tSendIpcIntTxn.sDateSettlmt, ptIpcIntTxn->sDateSettlmt, F015_LEN);
    }
    
    /* ת����Ӧ�������23��ʹ�÷�����Ӧ���е�23�� */
    if (ptIpcIntTxn->cF023Ind == FLAG_YES_C)
    {
        tSendIpcIntTxn.cF023Ind = FLAG_YES_C;
        memcpy (tSendIpcIntTxn.sCardSeqId, ptIpcIntTxn->sCardSeqId, F023_LEN);
    }
    
    /* ת����Ӧ�������55��ʹ�÷�����Ӧ���е�55�� */
    if (ptIpcIntTxn->cICDataInd == FLAG_YES_C)
    {
        memset(sF055Len, 0, sizeof(sF055Len));
        tSendIpcIntTxn.cICDataInd = FLAG_YES_C;
        memcpy (tSendIpcIntTxn.sICDataLen, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
        memcpy (sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
        memcpy (tSendIpcIntTxn.sICData, ptIpcIntTxn->sICData, atoi(sF055Len));
    }
    
    if(iMacResult)
	{
	    memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
	    memcpy (tTxn.resp_code, F039_MAC_FAIL, 2);
	}
	
    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn update error, %d. continue this message.", nReturnCode);
    }
    else
        DbsCommit ();
    
    if(iMacResult)
	    return -1;
	    
    if(gsMacFlag[0] == FLAG_YES_C)
    {
        /* ��������A0����������ͳһ96 */
        if(memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) == 0)
        {
          HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "CUP return [%2.2s], respone 96", ptIpcIntTxn->sRespCode);
          memcpy(tSendIpcIntTxn.sRespCode, "96", F039_LEN);
        }
    }
    
    /***********************
    * ת��Ӧ��
    ************************/
    /* �ͻ���Ŀ��IPC�������� */
    memcpy ((char *)&tSendIpcInt2, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));

    /* ����Ӧ���״��� */
    memcpy( tSendIpcInt2.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN );

    /* ����Ӧ��SrvId */

    /*memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );*/
    memcpy( tSendIpcInt2.sMsgDestId, tTxn.msg_src_id, SRV_ID_LEN );

    /* ����Ӧ�� msg type */
    tSendIpcInt2.sMsgType[2]++;

    HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,  __LINE__, (char*)&tSendIpcInt2, sizeof(tSendIpcInt2));

    nReturnCode = SendMsg (&tSendIpcInt2, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
            "SendMsg error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    
    HtLog ("monitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "R %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
		    
    HtLog(  gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}
