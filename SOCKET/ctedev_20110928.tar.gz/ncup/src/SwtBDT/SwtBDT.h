#ifndef __SWITCH_H
#define __SWITCH_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <math.h>
#include <errno.h>
#include <string.h>
#include <memory.h>
#include <ctype.h> 
#include <signal.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "MsqOpr.h"
#include "ToOpr.h"
#include "HtLog.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "TxnNum.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "EncOpr.h"
#include "LineStat.h"
#include "CstDbsTbl.h"
/*#include "XFT.h"*/

#define MSG_SRC_ID_ANY      "9999"
/* tbl_card_inf��¼��, ֻ�������п� */
#define CARD_INF_NUM_MAX		100

#define LINE_SEPARATOR "============================================="

#define SWT_USE_RSP_38	"SWT_USE_RSP_38"

/* global variables */
char				gsSrvId[SRV_ID_LEN+1];
char				gsSrvSeqId[SRV_SEQ_ID_LEN+1];
char				gsLogFile[LOG_NAME_LEN_MAX];
int					gnTxnInfNum;
Tbl_txn_inf_Def		gatTxnInf[TXN_INF_NUM_MAX];
T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];
int					gnCardInfNum;
Tbl_card_inf_Def	gatCardInf[CARD_INF_NUM_MAX];

char				gsParamMsgCompressFlag[2];
char                gsMacFlag[2];

typedef struct
{
    char    caTxnNum[FLD_TXN_NUM_LEN+1];
    char    caMsgSrcId[SRV_ID_LEN+1];
    int     (*pfTxnFun)(T_IpcIntTxnDef *, int );
    char    caTxnDsp[50];
} TXNFUN;

extern TXNFUN gaTxns[MAXTXNS];

/* internal functions */
int SwitchInit (short argc, char **argv);
int GetTxnInfoIndex( char *sMsgSrcId, char *sTxnNum, int *nIndex );
void HandleExit (int n);
void showIpc(T_IpcIntTxnDef *InIpc);

int MoveIpc2Txn (T_IpcIntTxnDef *pIpcIntTxn, Tbl_txn_Def *ptTxn );
int MoveTxn2Ipc (Tbl_txn_Def *ptTxn, T_IpcIntTxnDef *ptIpcIntTxn );
int InsertSafMsg (T_IpcIntTxnDef *ptSendIpcIntTxn, Tbl_txn_Def *ptTxn, char *sCount);
int SendRsp (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn);
int SendMsg (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptTxn, Tbl_txn_Def *ptOrigTxn);
int SwtTxnSelOprForCancel (T_IpcIntTxnDef *ptIpcIntTxn, int *pnTxnSelOpr);
int SwtTxnSelOprForRsp (T_IpcIntTxnDef *ptIpcIntTxn, int *pnTxnSelOpr);
int CheckRevsalTxn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode);
int CheckCancelTxn (T_IpcIntTxnDef *ptIpcIntTxn, Tbl_txn_Def *ptOrigTxn, char *sRespCode);
int SetKeyRsp (T_IpcIntTxnDef *ptIpcIntTxn);
int SetKeyRevsal (T_IpcIntTxnDef *ptIpcIntTxn);
int SetKeyCancel (T_IpcIntTxnDef *ptIpcIntTxn);
int brgGetRouteByCardNO(char * sCardNo);
int GMTInit (T_IpcIntTxnDef *pIpcIntTxn, int nMsgLen);
int InitialEFTP (char *sMsgOutBuf,int nMsgOutBufLen);
int InitialN303 (char *sMsgOutBuf,T_IpcIntTxnDef* ptIpcIntTxn,int nMsgOutBufLen);
int InitialN304 (char *sMsgOutBuf,T_IpcIntTxnDef* ptIpcIntTxn,int nMsgOutBufLen);
int InitialN302 (char *sMsgOutBuf,T_IpcIntTxnDef* ptIpcIntTxn,int nMsgOutBufLen);
int InitialN213 (char *sMsgOutBuf,T_IpcIntTxnDef* ptIpcIntTxn,int nMsgOutBufLen);

int VerifyMAC (T_IpcIntTxnDef *ptIpcIntTxn );

int HandleBDTNormalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TCHandleBDTNormalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBNormalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBNormalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDTRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TCHandleBDTRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDTRevsalGReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBRevsalGReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDTCancelReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TCHandleBDTCancelReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBCancelReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBCancelReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDTCancelRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TCHandleBDTCancelRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBCancelRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBCancelRevsalReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int HandleBDTNormalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TCHandleBDTNormalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBNormalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBNormalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDTRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TCHandleBDTRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDTRevsalGRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBRevsalGRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBRevsalGRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDTCancelRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TCHandleBDTCancelRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBCancelRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBCancelRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDTCancelRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int TCHandleBDTCancelRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTDBCancelRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleBDBCancelRevsalRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn1011 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1012 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1013 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1014 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1015 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1016 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2011 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2012 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2013 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2014 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2015 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2016 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3011 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3012 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3013 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3014 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3015 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3016 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4011 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4012 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4013 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4014 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4015 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4016 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn1091 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1092 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1093 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1094 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1095 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1096 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2091 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2092 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2093 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2094 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2095 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2096 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3091 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3092 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3093 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3094 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3095 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3096 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4091 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4092 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4093 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4094 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4095 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4096 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn2083 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2084 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2085 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2086 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2143 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2144 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn1191 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1192 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2191 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2192 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1193 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1194 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2193 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2194 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn5151 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5152 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5153 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5154 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5161 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5162 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn7013 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn7014 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn1183 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1184 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1185 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn1205 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1206 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1105 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1106 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3105 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3106 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5155 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5156 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2105 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2106 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4105 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4106 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn1215 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1216 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1225 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1226 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1235 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1236 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2225 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2226 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2235 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2236 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn1255 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1256 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1265 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn1266 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2265 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn2266 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3265 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn3266 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4265 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn4266 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5265 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5266 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );

int Txn5181 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int Txn5182 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleNoticeReq (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleNoticeRsp (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex );
int HandleTimeOut (char *sMsgBuf );

#endif
