/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Normal.c                                                    */
/* DESCRIPTIONS: handle normal req from CUP and its rsp from host            */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2005-03-29  DONG TIEJUN    Initialize                                     */
/*****************************************************************************/
static char * id = "@(#)$Header: /home/ctepub/cvs/dev/ncup/src/SwtBDT/Txn1011.c,v 1.1.1.1.4.1 2011/09/23 02:54:35 ctedev Exp $";

#include "SwtBDT.h"

int Txn1011 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
    char            sFuncName[] = "Txn1011";
    char            sRespCode[F039_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    char            transCode[4+1];
    int             nReturnCode;
    int             nLineStat;
    int             nMsgLen;
    int             nTxnSelOpr;
    T_SwtToReqDef   tSwtToReq;
    Tbl_txn_Def     tTxn;
    Tbl_ic_txn_Def  tIcTxn;
    T_IpcIntTxnDef  tSendIpcIntTxn; 
    char            sCurrentDate[14+1];
    
    
    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);

    if (nIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn num %4.4s from server %4.4s not configed in tbl_txn_inf.", ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sMsgSrcId);
        return -1;
    }
    
    memset(sCurrentDate,0,sizeof(sCurrentDate));
    /*CommonGetCurrentTime(sCurrentDate);*/
    /***********************************************************
    * set time out time add by tangb for double Machine ToCtl->Tom
    *************************************************************/
    SetToTime(nIndex);
    memcpy(sCurrentDate, gsTimeCurTs, 14);

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN (from txn initiator): %12.12s\n",
            gatTxnInf[nIndex].txn_num, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
            ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans, ptIpcIntTxn->sTermSSN);

     /*  2011��4��19��  Ԭ�� ����ǰ��F007,F011 ��sMisc  Start*/      

    /* ����ǰ��F007,F011��sMisc */
     memcpy(ptIpcIntTxn->sMisc,ptIpcIntTxn->sTransmsnDateTime,F007_LEN);
     memcpy(ptIpcIntTxn->sMisc+F007_LEN,ptIpcIntTxn->sSysTraceAuditNum,F011_LEN);
     /* F007ʹ��ϵͳ��ǰʱ�� */
     memcpy(ptIpcIntTxn->sMiscFlag, sCurrentDate, 14);
     memcpy(ptIpcIntTxn->sTransmsnDateTime, sCurrentDate+4, F007_LEN);
     
     /*END*/



    /*******************
     * �жϸý����Ƿ�֧��
     ********************/
    if (memcmp (gatTxnInf[nIndex].support_flag, FLAG_YES, 1) )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "Transaction not supported. Reject this transaction with %s.", F039_NOT_SUPPORT);
        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_NOT_SUPPORT, F039_LEN );
        /*����15��*/
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        /*  by gjch
            nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);
            */
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        
        HtLog ("bdtmonitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
		    
        return -1;
    }
    
    /***************
     * ������ˮ��
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nIndex].msg_to );
    if (tSwtToReq.nToCtlTime > 0)
        tSwtToReq.nTransCode = TOCTL_NORMAL_FIRST;
    else
        tSwtToReq.nTransCode = TOCTL_REVERSAL_FIRST;
    memcpy (tSwtToReq.sTxnDate, ptIpcIntTxn->sTransmsnDateTime, F007_LEN);

    nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
    if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "ToCtrlReq error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /*����15��*/
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        /* by gjch
           nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);
           */
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        return -1;
    }
    /* save ssn in ipc */
    memcpy (ptIpcIntTxn->sSysSeqNum, tSwtToReq.sSysSeqNum, F011_LEN);
    memcpy(ptIpcIntTxn->sSysTraceAuditNum, tSwtToReq.sSysSeqNum, F011_LEN);

    /* ��key_rsp, key_revsal, key_cancel��ֵ */
    nReturnCode = SetKeyRsp (ptIpcIntTxn);
    nReturnCode = SetKeyRevsal (ptIpcIntTxn);
    nReturnCode = SetKeyCancel (ptIpcIntTxn);

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);

        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /*����15��*/
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        /* by gjch
           nReturnCode = SendMsg (ptIpcIntTxn, NULL, NULL);
           */
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        return -1;
    }

#if 0
    /***************
     * У��MAC
     ****************/
    nReturnCode = VerifyMAC (ptIpcIntTxn );
    if (nReturnCode != 0 )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "VerifyMAC error, %d. Reject this transaction with %s.", nReturnCode, F039_MAC_FAIL);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_MAC_FAIL, F039_LEN );
        /*����15��*/
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }
#endif

    /***************
     * ת��PIN
     ****************/
    if (gatTxnInf[nIndex].pin_flag[0] == FLAG_YES_C)
    {
        nReturnCode = TransferPin (ptIpcIntTxn );
        if (nReturnCode)
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "TransferPin error, %d. Reject this transaction with %s.", nReturnCode, F039_PIN_ERROR);
            /* �����ʱ���� */
            tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, F039_PIN_ERROR, F039_LEN );
            /*����15��*/
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
            
            HtLog ("bdtmonitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);

            /* save this txn in Db */
            DbsBegin ();
            memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
            memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
            nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
            if (nReturnCode)
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
            DbsCommit ();

            return -1;
        }
    }

    /*******************
     * �����ͻ����ļ��
     ********************/
    nReturnCode = SwtCustCheckTxn (ptIpcIntTxn, sRespCode);
    if (nReturnCode || memcmp (sRespCode, F039_SUCCESS, F039_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustCheckTxn error, %d. Reject this transaction with %2.2s.", nReturnCode, sRespCode);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, sRespCode, F039_LEN );
        /*����15��*/
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        
        HtLog ("bdtmonitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }
    
    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Reject this transaction with %2.2s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        if(ptIpcIntTxn->sRespCode[0] == ' ' || ptIpcIntTxn->sRespCode[0] == 0)
			memcpy(ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN);
        /*����15��*/
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        
        HtLog ("bdtmonitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);

        /* save this txn in Db */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
        if (nReturnCode)
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert error, %d.", nReturnCode);
        DbsCommit ();

        return -1;
    }

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsTxn (DBS_INSERT, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn insert error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_DUPL_TXN, F039_LEN );
        /*����15��*/
        memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        
        HtLog ("bdtmonitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
        
        return -1;
    }
    
    /***************
	* ��¼IC���������ݿ�
	****************/
	if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    nReturnCode = MoveTxn2IcTxn(&tTxn, ptIpcIntTxn, &tIcTxn);
	    nReturnCode = DbsIcTxn (DBS_INSERT, &tIcTxn);
	    if (nReturnCode )
	    {
	    	DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsIcTxn insert error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
            /* �����ʱ���� */
            tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
            
            /* ����Ӧ���״��� */
            memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
            /* ����Ӧ��SrvId */
            memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
            /* ���Ĵ���Ӧ���� */
            memcpy( ptIpcIntTxn->sRespCode, F039_DUPL_TXN, F039_LEN );
            /*����15��*/
            memcpy(ptIpcIntTxn->sDateSettlmt,sCurrentDate+4,F015_LEN);
            /* ����Ӧ�� msg type */
            ptIpcIntTxn->sMsgType[2]++;
            nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
            
            HtLog ("bdtmonitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);
            
            return -1;
	    }
	}
    DbsCommit ();

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Insert transaction into database.");

    /***********************
     *  �ͻ���Ŀ��IPC��������
     ************************/
    memcpy ((char *)&tSendIpcIntTxn, (char *)ptIpcIntTxn, sizeof (*ptIpcIntTxn));
    memcpy( tSendIpcIntTxn.sMsgDestId, gatTxnInf[nIndex].msg_dest1, SRV_ID_LEN );
    /* use FE ssn in F011 */
    memcpy (tSendIpcIntTxn.sSysTraceAuditNum, ptIpcIntTxn->sSysSeqNum, F011_LEN);

    nReturnCode = SendMsg (&tSendIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SendMsg error, %d. Reject this transaction with %s.", nReturnCode, F039_MAL_FUNCTION);
        /* �����ʱ���� */
        tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
        nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);

        /* ����Ӧ���״��� */
        memcpy( ptIpcIntTxn->sTxnNum, gatTxnInf[nIndex].rsp_txn_num, FLD_TXN_NUM_LEN );
        /* ����Ӧ��SrvId */
        memcpy( ptIpcIntTxn->sMsgDestId, gatTxnInf[nIndex].rsp_dest_srv_id, SRV_ID_LEN );
        /* ���Ĵ���Ӧ���� */
        memcpy( ptIpcIntTxn->sRespCode, F039_MAL_FUNCTION, F039_LEN );
        /* ����Ӧ�� msg type */
        ptIpcIntTxn->sMsgType[2]++;
        nReturnCode = SendMsg (ptIpcIntTxn, &tTxn, NULL);
        
        HtLog ("bdtmonitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "L %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
		    ptIpcIntTxn->sTransmsnDateTime, ptIpcIntTxn->sSysTraceAuditNum,
		    ptIpcIntTxn->sAcqInstIdCode,
		    ptIpcIntTxn->sCardAccptrId, ptIpcIntTxn->sRespCode);

        /* �޸�tbl_txn��resp_code */
        DbsBegin ();
        memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_FE, FLD_TRANS_STATE_LEN);
        memcpy (tTxn.resp_code, ptIpcIntTxn->sRespCode, F039_LEN);
        nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
        if (nReturnCode)
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxn insert1 error, %d.", nReturnCode);
        }
        DbsCommit ();

        return -1;
    }

    HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction sent to %s.", gatTxnInf[nIndex].msg_dest1);

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}

int Txn1012 (T_IpcIntTxnDef *ptIpcIntTxn, int nIndex )
{
    char            sFuncName[] = "Txn1012";
    char            sMsgSrcId[SRV_ID_LEN+1];
    char            sMsgBuf[MSQ_MSG_SIZE_MAX];
    int                nReturnCode;
    int                nLineStat;
    int                nTxnSelOpr;
    int                nMsgLen;
    int                nSendRevsalFlag;
    int                nSendRspFlag;
    int                nSendAccountFlag;
    int                nReqIndex;
    T_SwtToReqDef    tSwtToReq;
    Tbl_txn_Def        tTxn;
    Tbl_ic_txn_Def  tIcTxn;
    T_IpcIntTxnDef    tSendIpcIntTxn, tSendIpcInt2;
	char            sF055Len[F055_LEN_LEN+1] = {0};
	char            sCurrentTime[15];

    HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s begin.", sFuncName);
    
    memset(sCurrentTime,0,sizeof(sCurrentTime));
    SetToTime(-1);
	memcpy(sCurrentTime, gsTimeCurTs, 14);
	
    	/* ת��Ӧ���� */    
	nReturnCode = SwtCustTransferRspCode(ptIpcIntTxn);
	if (nReturnCode != 0 )
	{
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
			"transfer RSPCODE error, %d", nReturnCode);
    memcpy(ptIpcIntTxn->sRespCode,"01",F039_LEN);	
	}

    /* ����־�м�¼�ý��׵Ĺؼ���Ϣ */
    memset (sMsgSrcId, 0, sizeof (sMsgSrcId));
    memcpy (sMsgSrcId, ptIpcIntTxn->sMsgSrcId, SRV_ID_LEN);

    HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__,
            "TXN: %4.4s\n  PAN: %19.19s\n  amount: %12.12s\n  date: %4.4s\n  time: %6.6s\n  SSN: %6.6s\n  host SSN: %12.12s\n  response code: %2.2s",
            ptIpcIntTxn->sTxnNum, ptIpcIntTxn->sPrimaryAcctNum, ptIpcIntTxn->sAmtTrans,
            ptIpcIntTxn->sDateLocalTrans, ptIpcIntTxn->sTimeLocalTrans,
            ptIpcIntTxn->sSysTraceAuditNum, ptIpcIntTxn->sHostSSN, ptIpcIntTxn->sRespCode);


    /***************
     * У��MAC
     ****************/
    /* �����������A0��discard���ף���У��MAC */
    if(memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) != 0 &&
        memcmp(ptIpcIntTxn->sMsgSrcId, SRV_ID_COMM_CUP, SRV_ID_LEN) == 0)
    {
        nReturnCode = VerifyMAC (ptIpcIntTxn );
        if (nReturnCode != 0 )
        {
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "VerifyMAC error, %d. Discard this message.", nReturnCode);
            return -1;
        }
    }
	

    /****************************
     * ����tbl_txn�еĽ��׼�¼
     ****************************/
    nReturnCode = SetKeyRsp (ptIpcIntTxn);

    /* ����ѯ������ʹ�õ������Ƶ�tTxn�� */
    memset ((char *)&tTxn, 0, sizeof (tTxn));
    memcpy (tTxn.key_rsp, ptIpcIntTxn->sKeyRsp, KEY_RSP_LEN);
    memcpy (tTxn.txn_num, ptIpcIntTxn->sTxnNum, FLD_TXN_NUM_LEN);
    tTxn.txn_num[INDEX_TXN_NUM_REQ_RSP] --;
    /* �����ݿ��в���ԭ������ */
    /* DBS_SELECT21: txn_num, key_rsp */
    nReturnCode = DbsTxn (DBS_SELECT21, &tTxn);
    if (nReturnCode)
    {
        tTxn.key_rsp[KEY_RSP_LEN] = 0;
        tTxn.txn_num[FLD_TXN_NUM_LEN] = 0;
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn select error, %d. txn_num=%s,key_rsp=%s. Discard this message.", nReturnCode,tTxn.txn_num,tTxn.key_rsp);
        return -1;
    }

    /***********************
     * ���ҽ���������gatTxnInf�е�����
     ************************/
    nReturnCode = GetTxnInfoIndex (tTxn.msg_src_id, tTxn.txn_num, &nReqIndex );
    if (nReturnCode || nReqIndex < 0)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "GetTxnInfoIndex error %d, nIndex %d. Discard this message.", nReturnCode, nReqIndex);
        return -1;
    }

    /***********************
     * ���ô����쳣ʱ�Ƿ�Ҫ���ͳ���
     ************************/
    switch (gatTxnInf[nReqIndex].rsp_type[0])
    {
        case RSP_TYPE_NO_ACCOUNT:
            if (IsRspSuccess (ptIpcIntTxn->sRespCode) )
                nSendRevsalFlag = 1;
            else
                nSendRevsalFlag = 0;
            break;
        case RSP_TYPE_RSP_BEFORE_ACCOUNT:
            if (IsRspSuccess (ptIpcIntTxn->sRespCode) && !memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
                nSendRevsalFlag = 1;
            else
                nSendRevsalFlag = 0;
            break;
        case RSP_TYPE_RSP_AFTER_ACCOUNT:
            if (IsRspSuccess (ptIpcIntTxn->sRespCode) )
                nSendRevsalFlag = 1;
            else
                nSendRevsalFlag = 0;
            break;
        default:
            break;
    }

    /***********************
     * ��֯��¼���ݿ��¼�ṹ
     ************************/
    nReturnCode = MoveIpc2Txn (ptIpcIntTxn, &tTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveIpc2Txn error, %d. Discard this message.", nReturnCode);
        return -1;
    }
    /* save auth id in F038 */
    if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
        memcpy (tTxn.authr_id_resp, tTxn.authr_id_r, F038_LEN);

    /*********************
     * �ͻ������ݿ��¼�ṹ
     **********************/
    nReturnCode = SwtCustBeforeTblTxnOpr (ptIpcIntTxn, &tTxn, NULL);
    if (nReturnCode)
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "SwtCustBeforeTblTxnOpr error, %d. Discard this message.", nReturnCode);  
        return -1;
    }

    /* ��tTxn���浽tSendIpcIntTxn, ������Ӧ����ʹ�� */


    nReturnCode = MoveTxn2Ipc (&tTxn, &tSendIpcIntTxn);
    if( nReturnCode )
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "MoveTxn2Ipc error, %d. Discard this message.", nReturnCode);
        return -1;
    }

	/* ת����Ӧ�������55��ʹ�÷�����Ӧ���е�55�� */
	if (ptIpcIntTxn->cICDataInd == FLAG_YES_C)
	{
		memset(sF055Len, 0, sizeof(sF055Len));
		tSendIpcIntTxn.cICDataInd = FLAG_YES_C;
		memcpy (tSendIpcIntTxn.sICDataLen, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
		memcpy (sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
		memcpy (tSendIpcIntTxn.sICData, ptIpcIntTxn->sICData, atoi(sF055Len));
	}

#if 0
    /***************
     * ��齻���Ƿ�ʱ
     ****************/
    memset ((char *)&tSwtToReq, 0, sizeof(tSwtToReq) );
    tSwtToReq.nTransCode = TOCTL_NORMAL_SECOND;
    tSwtToReq.nToCtlTime = atoi (gatTxnInf[nReqIndex].msg_to );
    memcpy (tSwtToReq.sTxnDate, tTxn.trans_date_time, F007_LEN);
    memcpy (tSwtToReq.sSysSeqNum, tTxn.sys_seq_num, FLD_SYS_SEQ_NUM_LEN );
    tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;

    /* ���ȼ����ٻ�ǰ��Ӧ������, ���յ������ɹ�Ӧ��ʱ���ⳬʱ, �յ���������Ӧ����ٽⳬʱ */
    switch (gatTxnInf[nReqIndex].rsp_type[0])
    {
        case RSP_TYPE_NO_ACCOUNT:
        case RSP_TYPE_RSP_BEFORE_ACCOUNT:
            nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
            if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "ToCtrlReq error, %d. Discard this message.", nReturnCode);
                return -1;
            }

            break;
        case RSP_TYPE_RSP_AFTER_ACCOUNT:
            if (memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) ||
                    !IsRspSuccess (ptIpcIntTxn->sRespCode))
            {
                nReturnCode = ToCtrlReq (gsSrvId, gsSrvSeqId, gatSrvMsq, &tSwtToReq, ptIpcIntTxn);
                if (nReturnCode || tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_OK)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                            "ToCtrlReq error, %d. Discard this message.", nReturnCode);
                    return -1;
                }
            }
            else
            {
                if (!memcmp (tTxn.trans_state, TRANS_STATE_NO_RSP, FLD_TRANS_STATE_LEN))
                    tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO;
                else
                    tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_HAD_TO;
            }

            break;
        default:
            break;
    }
#endif

    /***********************************************************
    *  ��齻���Ƿ�ʱ add by tangb for double Machine ToCtl->Tom
    *************************************************************/
	if (!memcmp(tTxn.trans_state, TRANS_STATE_TIME_OUT, FLD_TRANS_STATE_LEN))
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_HAD_TO;
    else
       tSwtToReq.nReplyCode = TOCTL_REPLY_CODE_NOT_TO; 
       
    /* set trans state if reply is not time out */
    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_NOT_TO)
    {
        if (IsRspSuccess (ptIpcIntTxn->sRespCode))
        {
            switch (gatTxnInf[nReqIndex].rsp_type[0])
            {
                case RSP_TYPE_NO_ACCOUNT:
                    memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    break;
                case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                    if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
                        memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    break;
                case RSP_TYPE_RSP_AFTER_ACCOUNT:
                    if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
                        memcpy (tTxn.trans_state, TRANS_STATE_NO_ACCT_RSP, FLD_TRANS_STATE_LEN);
                    else
                        memcpy (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN);
                    break;
                default:
                    break;
            }
        }
        else
        {
            if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
                memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_CUPS, FLD_TRANS_STATE_LEN);
            else
                memcpy (tTxn.trans_state, TRANS_STATE_REJ_BY_HOST, FLD_TRANS_STATE_LEN);
        }
    }

    DbsBegin ();

    /***************
     * ��¼���ݿ�
     ****************/
    nReturnCode = DbsTxn (DBS_UPDATE1, &tTxn);
    if (nReturnCode )
    {
        DbsRollback ();
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "DbsTxn update error, %d. Discard this message.", nReturnCode);

        /* send reversal on success reply */
        if (nSendRevsalFlag)
        {
            nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
            }
        }
        return -1;
    }

    /* ��Ԥ��Ȩ����, ��������Ϣ��¼����Ȩ����, ����Ȩ����ʱ���� */
    /* ���׳ɹ�ʱ, ������Ȩ��, ����, ����ģʽ��2ʱ�յ�����Ӧ��ʱ��������Ȩ�� */
    /*�������ԣ����ر�����Ȩʱ��ֻ��¼һ�Σ�*/
    /*if ( memcmp( ptIpcIntTxn->sFwdInstIdCode, ptIpcIntTxn->sRcvgInstIdCode, 10 ) != 0 )*/
    if (!memcmp (tTxn.trans_state, TRANS_STATE_SUCC, FLD_TRANS_STATE_LEN) &&
            (gatTxnInf[nReqIndex].rsp_type[0] != RSP_TYPE_RSP_BEFORE_ACCOUNT ||
             memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) == 0 ))
    {
		memcpy(tTxn.amt_return,tTxn.amt_trans,12);
        nReturnCode = DbsAuth (DBS_INSERT, &tTxn);
        if (nReturnCode )
        {
            DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsAuth insert error, %d. Discard this message.", nReturnCode);

            /* send reversal on success reply */
            if (nSendRevsalFlag)
            {
                nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if (nReturnCode)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
            }
            return -1;
        }
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "DbsAuth DBS_INSERT ok.");
    }
    
    /***************
	* ����IC���ű�
	****************/
	if(ptIpcIntTxn->sICData[0] != ' ' && ptIpcIntTxn->sICData[0] != 0x00)
	{
	    memset((char *)&tIcTxn, 0, sizeof(tIcTxn));
	    /*CommonGetCurrentTime(sCurrentTime);*/
	    memcpy (sF055Len, ptIpcIntTxn->sICDataLen, F055_LEN_LEN);
	    sprintf(sF055Len, "%03d", atoi(sF055Len)*2);
	    memcpy(tIcTxn.rsp_iclen, sF055Len, F055_LEN_LEN);
	    Hex2Str(ptIpcIntTxn->sICData, tIcTxn.rsp_icdata, atoi(sF055Len)/2);
	    memcpy(tIcTxn.update_time, sCurrentTime, 14);
	    memcpy(tIcTxn.key_rsp, tTxn.key_rsp, KEY_RSP_LEN);
	    
	    nReturnCode = DbsIcTxn (DBS_UPDATE, &tIcTxn);
	    if (nReturnCode )
	    {
	    	DbsRollback ();
            HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                    "DbsIcTxn update error, %d. Discard this message.", nReturnCode);
            
            /* send reversal on success reply */
            if (nSendRevsalFlag)
            {
                nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                if (nReturnCode)
                {
                    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                }
            }
            
            return -1;
	    }
	}

    DbsCommit ();
    
    /*2011��5��14�� Ԭ�� ����*/
      	if(!memcmp(ptIpcIntTxn->sRespCode, "A0", F039_LEN) && 
	    !memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
    {
        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                "CUP return [%2.2s], respone 96", ptIpcIntTxn->sRespCode);
        memcpy(tSendIpcIntTxn.sRespCode, "96", F039_LEN);
    }
        /*2011��5��14�� Ԭ�� ����*/

    if (tSwtToReq.nReplyCode == TOCTL_REPLY_CODE_HAD_TO)
    {
        /* ��ʱӦ�� */
        /* send reversal on late success reply */
        HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Received late response.");
        if (nSendRevsalFlag)
        {
            nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_LATE_RSP);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
            }
            HtLog (gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Reversal for late successful response sent out.");
        }
    }
    else
    {
        /* Ӧ��δ��ʱ */
        /* �Ƿ�ת��Ӧ�� */
        nSendRspFlag = 0;
        switch (gatTxnInf[nReqIndex].rsp_type[0])
        {
            case RSP_TYPE_NO_ACCOUNT:
                nSendRspFlag = 1;
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN))
                    nSendRspFlag = 1;
                else
                    nSendRspFlag = 0;
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) &&
                        IsRspSuccess (ptIpcIntTxn->sRespCode))
                    nSendRspFlag = 0;
                else
                    nSendRspFlag = 1;
                break;
            default:
                break;
        }

        if (nSendRspFlag)
        {
            /***********************
             *  �ͻ���Ŀ��IPC��������
             ************************/

            memcpy ((char *)&tSendIpcInt2, (char *)&tSendIpcIntTxn, sizeof (tSendIpcIntTxn));

            /* ����Ӧ���״��� */
            memcpy( tSendIpcInt2.sTxnNum, gatTxnInf[nReqIndex].rsp_txn_num, FLD_TXN_NUM_LEN );

            /* ����Ӧ��SrvId */
            memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].rsp_dest_srv_id, SRV_ID_LEN );

            /* ����Ӧ�� msg type */
            tSendIpcInt2.sMsgType[2]++;

            HtDebugString (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,  __LINE__, (char*)&tSendIpcInt2, sizeof(tSendIpcInt2));

            nReturnCode = SendMsg (&tSendIpcInt2, &tTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);

                /* send reversal on success reply */
                if (nSendRevsalFlag)
                {
                    nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                    if (nReturnCode)
                    {
                        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                    }
                }

                return -1;
            }

            HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reply sent out.");
            
            HtLog ("bdtmonitor.log", HT_LOG_MODE_ERROR, __FILE__,__LINE__,
		    "R %4.4s %19.19s %12.12s %10.10s %6.6s %8.8s %15.15s %2.2s",
		    tSendIpcInt2.sTxnNum, tSendIpcInt2.sPrimaryAcctNum, tSendIpcInt2.sAmtTrans,
		    tSendIpcInt2.sTransmsnDateTime, tSendIpcInt2.sSysTraceAuditNum,
		    tSendIpcInt2.sAcqInstIdCode,
		    tSendIpcInt2.sCardAccptrId, tSendIpcInt2.sRespCode);
        }

        /* �Ƿ񷢼��� */
        nSendAccountFlag = 0;
        switch (gatTxnInf[nReqIndex].rsp_type[0])
        {
            case RSP_TYPE_NO_ACCOUNT:
                nSendAccountFlag = 0;
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) &&
                        IsRspSuccess (ptIpcIntTxn->sRespCode))
                    nSendAccountFlag = 1;
                else
                    nSendAccountFlag = 0;
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) &&
                        IsRspSuccess (ptIpcIntTxn->sRespCode))
                    nSendAccountFlag = 1;
                else
                    nSendAccountFlag = 0;
                break;
            default:
                break;
        }

        if (nSendAccountFlag)
        {
            /* ����Ӧ��SrvId */
            memcpy ((char *)&tSendIpcInt2, &tSendIpcIntTxn, sizeof (tSendIpcIntTxn));
            memcpy( tSendIpcInt2.sMsgDestId, gatTxnInf[nReqIndex].msg_dest2, SRV_ID_LEN );
            /* clear F038 */
            tSendIpcInt2.cF038Ind = FLAG_NO_C;
            /* clear F039 */
            memset (tSendIpcInt2.sRespCode, ' ', F039_LEN);

            nReturnCode = SendMsg (&tSendIpcInt2, &tTxn, NULL);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendMsg error, %d. Discard this message.", nReturnCode);

                /* send reversal on success reply */
                if (nSendRevsalFlag)
                {
                    nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
                    if (nReturnCode)
                    {
                        HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "SendRevsalOnError error, %d.", nReturnCode);
                    }
                }

                return -1;
            }

            HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction account request sent out.");

            nReturnCode = InsertSafMsg (&tSendIpcInt2, &tTxn, gatTxnInf[nReqIndex].saf_count2);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, "InsertSafMsg error, %d.", nReturnCode);
            }
        }

        /* �Ƿ���Ҫ��ʧ�ܵļ���Ӧ�����������ͳ��� */
        nSendRevsalFlag = 0;
        switch (gatTxnInf[nReqIndex].rsp_type[0])
        {
            case RSP_TYPE_NO_ACCOUNT:
                nSendRevsalFlag = 0;
                break;
            case RSP_TYPE_RSP_BEFORE_ACCOUNT:
                nSendRevsalFlag = 0;
                break;
            case RSP_TYPE_RSP_AFTER_ACCOUNT:
                if (!memcmp (sMsgSrcId, SRV_ID_COMM_CUP, SRV_CUP_ID_LEN) || IsRspSuccess (ptIpcIntTxn->sRespCode))
                    nSendRevsalFlag = 0;
                else
                    nSendRevsalFlag = 1;
                break;
            default:
                break;
        }

        if (nSendRevsalFlag)
        {
            nReturnCode = SendRevsalOnError (&tSendIpcIntTxn, nReqIndex, REASON_CODE_SEND_ERR);
            if (nReturnCode)
            {
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                        "SendRevsalOnError error, %d. Discard this message.", nReturnCode);
                return -1;
            }
            HtLog(    gsLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "Transaction reversal request sent out.");
        }

    }

    HtLog(    gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "%s end.", sFuncName);

    return 0;
}
