/*****************************************************************************/
/*                TOPLINK+ -- Shanghai Huateng Software System Inc.          */
/*****************************************************************************/
/* PROGRAM NAME: MngTxn.c			     									 */
/* DESCRIPTIONS: CUP - ��Կ����                                              */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
#include "MngTxn.h"

#define DEF_TL_COMM_TIME_OUT 15
#define DEF_TL_COMM_INT      180

char				gsLogFile[LOG_NAME_LEN_MAX];
T_SrvMsq			gatSrvMsq[SRV_MSQ_NUM_MAX];

int					gnCommTpduL = 0;
char				gsCommTpdu[COMM_TPDU_LEN_MAX+1];
char				gsCommTerm[COMM_TERM_LEN_MAX+1];

char				gsIpAddr[25+1];
int					gnPort;

int					gnSocketID;
int					gnTimeOut;
int                 gnCommInt;
int					gnSysError = 0;

void HandleExit (int n);
void tcpTimeOut();
char * AllTrim(char *str)
{
    int len,i;
    for(i=0,len=strlen(str);(i<len)&&(str[i]==0x20);str[len]='\0',i=0,len--)
        for(i=0;i<len;i++)
            str[i]=str[i+1];
    for(len;(len>0)&&(str[len-1]==0x20);--len)
        str[len-1]='\0';
    return(str);
}

static char * id = "$Id: MngTxn.c,v 1.1.1.1 2011/08/19 10:55:52 ctedev Exp $";

int main(short	argc, char **argv)
{
	char	sMsgInBuf[MSQ_MSG_SIZE_MAX];
	char	sIntMsgBuf[MSQ_MSG_SIZE_MAX];
	char	sMsgOutBuf[MSQ_MSG_SIZE_MAX];
	char	sSrcSrvId[SRV_ID_LEN+1];
	int		nReturnCode;
	int 	nMsgInLen;
	int		nIntMsgLen;
	int		nMsgOutLen;
	char	sHostRspCode[5],sRspCodeDsp[33];
	char	sTrack2L[3],sTrack2V[38];
	char	sPanL[3],sPanV[20];
	char	sTxnAmt[13],sTxnAmtT[13];
	char    sCurrentTime[15];
	char						sCurrentDate[10+1];
	char    sArgBuf1[128] = {0};
	char    sArgBuf2[128] = {0};


	if (argc == 2)
    {
    	strcpy(sArgBuf1, argv[1]);
    }
    else if (argc == 3)
    {
    	strcpy(sArgBuf1, argv[1]);
    	strcpy(sArgBuf2, argv[2]);
    }
    else
    {
    	printf("Usage:%s <ORG> <TXN TYPE> \n", argv[0]);
		printf("[CUP] :%s <CUP> <RPK>\n",argv[0]);
		printf("[CUP] :%s <CUP> <RAK>\n",argv[0]);
		printf("[CUP] :%s <CUP> <SON>\n",argv[0]);
		printf("[CUP] :%s <CUP> <SOF>\n",argv[0]);
		printf("[CUP] :%s <CUP> <ECH>\n",argv[0]);
		exit(-1);
    }

    memset(gsIpAddr, 0x00, sizeof(gsIpAddr));
    strcpy(gsIpAddr, (char *)getenv("THIS_IP_ADDR"));
    AllTrim(gsIpAddr);
	gnPort = 19011;
	
	printf("Connect to = %s ,at port = %d!\n", gsIpAddr, gnPort);

	gnTimeOut = DEF_TL_COMM_TIME_OUT;
    gnCommInt = DEF_TL_COMM_INT;

    putenv("LOG_FILE_PATH=$FEHOME/log");
    strcpy (gsLogFile, "MngTxn.log");

	while (1)
	{
	    /* ��EchoTest���� */
      
          
	    nMsgOutLen = 0;
	    memset(&ComBlock, 0, sizeof(ComBlock));
        ComBlock.iTotal = 0;
      

        memset(sCurrentTime,0,sizeof(sCurrentTime));
        memset(sCurrentDate,0,sizeof(sCurrentDate));
        CommonGetCurrentTime(sCurrentTime);
    
        memcpy(sCurrentDate,sCurrentTime+4,10);
        
        printf("sCurrentDate = %s \n",sCurrentDate);

        /*   ���� ǩ�� ����  Ԭ�� 2011��4��26��     */        
        if (argc == 3)
        {
	        if (memcmp(sArgBuf2,"SON",3) == 0)
	        {
	        	  // memcpy (ComBlock.Text,"6111042611110803060000",22);
	            memcpy (ComBlock.Text,"6111",4);
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf2,"SOF",3) == 0)
	        {   
	            memcpy (ComBlock.Text,"6121",4);
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf1,"CUP",3) == 0 && memcmp(sArgBuf2,"ECH",3) == 0)
	        {
	            memcpy (ComBlock.Text,"6131",4);
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf1,"CUPS",4) == 0 && memcmp(sArgBuf2,"ECH",3) == 0)
	        {
	            memcpy (ComBlock.Text,"6135",4);
	            ComBlock.iTotal +=4;
			}
	        else if (memcmp(sArgBuf1,"CUP",4) == 0 && memcmp(sArgBuf2,"RAK",3) == 0)
	        {
	            memcpy (ComBlock.Text,"6073",4);
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf1,"CUP",4) == 0 && memcmp(sArgBuf2,"RPK",3) == 0)
	        {
	            memcpy (ComBlock.Text,"6074",4);
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf1,"CUPS",4) == 0 && memcmp(sArgBuf2,"RAK",3) == 0)
	        {
	            memcpy (ComBlock.Text,"6205",4);
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf1,"CUPS",4) == 0 && memcmp(sArgBuf2,"RPK",3) == 0)
	        {
	            memcpy (ComBlock.Text,"6215",4);
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf1,"CCP1",4) == 0 && memcmp(sArgBuf2,"RPK",3) == 0)
	        {
	            memcpy (ComBlock.Text,"CCP1",4);/*����ת������CCP1->6235*/
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf1,"ZK",2) == 0 && memcmp(sArgBuf2,"RAK",3) == 0)
	        {
	            memcpy (ComBlock.Text,"ZK10",4);
	            ComBlock.iTotal +=4;
	        }
	        else if (memcmp(sArgBuf1,"ZK",2) == 0 && memcmp(sArgBuf2,"RPK",3) == 0)
	        {
	            memcpy (ComBlock.Text,"ZK20",4);
	            ComBlock.iTotal +=4;
	        }
	    }
        else if (memcmp(sArgBuf1,"CCB1",4) == 0 )
        {
            memcpy (ComBlock.Text,"CCB1",4);/*����ת������CCB1->6431*/
            ComBlock.iTotal +=4;
        }
        else if (memcmp(sArgBuf1,"CCB3",4) == 0 )
        {
            memcpy (ComBlock.Text,"CCB3",4);/*����ת������CCB3->6433*/
            ComBlock.iTotal +=4;
        }
        else if (memcmp(sArgBuf1,"CCF1",4) == 0 )
        {
            memcpy (ComBlock.Text,"CCF1",4);/*����ת������CCF1->6435*/
            ComBlock.iTotal +=4;
        }
        else if (memcmp(sArgBuf1,"CCF3",4) == 0 )
        {
            memcpy (ComBlock.Text,"CCF3",4);/*����ת������CCF3->6437*/
            ComBlock.iTotal +=4;
        }
        else
        {
        	printf("��������\n");
        	exit(-1);
        }
        
        
        memcpy (ComBlock.Text+4, sCurrentDate, 10);
        ComBlock.iTotal +=10;
 
		gnSysError = 0;

		sigset(SIGALRM, tcpTimeOut);
		alarm(gnTimeOut);
		
		gnSocketID=tcpOpen(gsIpAddr,gnPort,2);
		
		printf("gnSocketID = %d \n",gnSocketID);
		
		if ( gnSocketID < 0 )
		{
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "tcpOpen error %d", gnSocketID);
			alarm(0);
			gnSysError = -1;
		}
		else
		{
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "tcpOpen ok SocketID = %d", gnSocketID);
		}
			
		printf("gnSysError = %d!\n", gnSysError);
		
		if(gnSysError == 0)
		{
			printf("WriteSock Text %s iTotal %d!\n", ComBlock.Text, ComBlock.iTotal);
			nReturnCode=WriteSock(gnSocketID,ComBlock.iTotal,ComBlock.Text);
			if ( nReturnCode < 0 )
			{
			    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "WriteSock error %d", nReturnCode);
				alarm(0);
				tcpClose(gnSocketID);
				gnSysError = -2;
			}
		}

		if(gnSysError == 0)
		{
			memset(&ComBlock, 0, sizeof(ComBlock));
			nReturnCode=ReadSock(gnSocketID,ComBlock.Text);
			if ( nReturnCode < 0 )
			{
                HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ReadSock error %d", nReturnCode);
				alarm(0);
				tcpClose(gnSocketID);
				break;
			}
			ComBlock.iTotal = nReturnCode;
			HtLog (gsLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "[%-50.50s]",ComBlock.Text);
			tcpClose(gnSocketID);
		}
		alarm(0);
		HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "End");
        break ;
	}
	
    return 0;
}


/*
 * Function Name: tcpOpen
 * Parameter 1  : hostaddress  ��������IP��ַ
 * Parameter 2  : hostport     ���������˿ں�
 * Parameter 3  : retrys       ������������
 */

int tcpOpen (hostaddress,hostport,retrys)
char *hostaddress;
int  hostport;
int  retrys;
{
	struct sockaddr_in remote;
	int  sock;

    bzero(&remote, sizeof(remote));
    remote.sin_family = AF_INET;
	remote.sin_addr.s_addr = inet_addr(hostaddress);
    remote.sin_port = htons(hostport);


	while (retrys)
	{
			if ( (sock = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
       	{
			if ( retrys > 0)
			{
				retrys--;
				continue;
			}
        	return(-2);
       	}


     	if ( connect(sock, (struct sockaddr *)&remote, sizeof(remote)) < 0 )
       	{
			tcpClose(sock);
			if ( retrys > 0)
			{
				retrys--;
				continue;
			}
        	return(-3);
       	}

     	return(sock);
	} /* while */

	return(-4);
}

/*
 * Function Name: tcpClose
 * Parameter 1  : sock      Ҫ�رյ�socket��
 */
int tcpClose( sock )
int sock;
{
	if ( fcntl( sock, F_SETFL, FNDELAY ) < 0 )
		return( -1 );
	if ( sock != 0 )
		shutdown( sock, 2 );

	close( sock );
	return( 0 );
}

/*
 * Function Name:  tcpTimeOut
 */
void tcpTimeOut()
{
}

/*
 * Function Name:  ReadSock
 * Parameter 1  :  socketid   socket��
 * Parameter 2  :  buffer     ���ܻ�����
 */
int ReadSock(socketid,buffer)
int socketid;
register char * buffer;
{
	int num, nLen, I=0,nleft,nread;
 	unsigned char tmp_buf[5];
 	char tmp_Str[2000], sBody[1024], Buf_head[5];

   	num = read(socketid, tmp_buf, 4);
 	if ( num <= 0 )
 	{
 	    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "read len error = %d", errno);
 		return (-1);
 	}

 	memset(Buf_head, 0, sizeof(Buf_head));
 	memcpy(Buf_head, tmp_buf, 4);

	nLen = atoi(Buf_head);

	if ( nLen == 0 || nLen > BUF_SIZE )
	{
	    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "len error = %d", nLen);
		return (-1);
	}

	nleft=nLen;
	while ( nleft > 0 )
	{
		nread = read(socketid, buffer, nleft);
		if (nread < 0)
		{
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "read socket error");
			return(-1);
		}
		if ( nread == 0 ) break;
		nleft -= nread;
		buffer += nread;

	}
	return (nLen-nleft);
}

/*
 * Function Name:  WriteSock
 * Parameter 1  :  socketid   socket��
 * Parameter 2  :  len        ���ͻ���������
 * Parameter 3  :  buffer     ���ͻ�����
 */
int WriteSock(socketid,len,buffer)
int socketid;
int len;
char * buffer;
{
	int  num, iWritelen;
 	unsigned char Buf_head[5];
 	char saSendBuf[BUF_SIZE];

 	if (len == 0) return(0);

 	memset(saSendBuf,0,sizeof(saSendBuf));

  sprintf(saSendBuf, "%04d", len);

  memcpy(saSendBuf+4,buffer,len);
	len = len + 4;


  iWritelen=0;
	for(;;)
	{
		while((num=write(socketid,&saSendBuf[iWritelen],
				len-iWritelen))<=0)
		{
		    HtLog (gsLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "write socket error");
			return(-1);
		}

		iWritelen+=num;
		if(iWritelen>=len) break;
	}
	return(iWritelen);
}
