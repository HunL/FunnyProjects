cd $FEHOME/src/Common 
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Dbs
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/CstDbs
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Quota
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Convert 
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Cust 
make clean all
if [ $? -ne 0 ];then
  exit 1
fi
cd $FEHOME/src/xml
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Bridge
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SwtBDT
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SwtTDB
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SwtNEW
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

#cd $FEHOME/src/Manage
#make clean all
#if [ $? -ne 0 ];then
#  exit 1
#fi

cd $FEHOME/src/PackSend
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/SavFwd
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/ToCtl
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Dumpmsg
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Daemon
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup01
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup02
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup03
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup04
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup05
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup06
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup07
make clean all
if [ $? -ne 0 ];then
  exit 1
fi


cd $FEHOME/src/Comm/ComCup08
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup09
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup10
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComCup11
make clean all
if [ $? -ne 0 ];then
  exit 1
fi
cd $FEHOME/src/Comm/ComPhp01
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/ComPhp02
make clean all
if [ $? -ne 0 ];then
  exit 1
fi
cd $FEHOME/src/Comm/CommAtmp
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommCon
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommEftp
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommPosp
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommEsbCli
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommEsbWS
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/CommEsbSrv
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/Comm/Tool
make clean all
if [ $? -ne 0 ];then
  exit 1
fi

cd $FEHOME/src/monitor
make clean all
if [ $? -ne 0 ];then
  exit 1
fi
