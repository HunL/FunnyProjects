
#ifndef __SRV_DEF_H
#define __SRV_DEF_H

#define SRV_ID_LEN		4
#define SRV_CUP_ID_LEN	2	
#define SRV_SEQ_ID_LEN	2

#define SRV_ID_BRIDGE		"1001"
#define SRV_ID_SWITCH		"1101"
#define SRV_ID_SWTBDT		"1102"
#define SRV_ID_SWTEMU		"1103"
#define SRV_ID_SWTOLD		"1104"
#define SRV_ID_SWTNEW		"1105"
#define SRV_ID_SWTCDM		"1106"
#define SRV_ID_MANAGE		"1201"
#define SRV_ID_PACKSEND		"1301"
#define SRV_ID_SAVFWD		"1401"
#define SRV_ID_TOCTL		"1501"

#define SRV_ID_COMM_CUP		"1601"
#define SRV_ID_COMM_CUPS    "1611"
#define SRV_ID_COMM_ZK      "1613"
#define SRV_ID_COMM_HOST	"1701"
#define SRV_ID_COMM_CC   	"1702"
#define SRV_ID_COMM_P		"1801"
#define SRV_ID_COMM_MZ		"1811"
#define SRV_ID_COMM_CON		"1901"
#define SRV_ID_HBSVR		"2001"

#define OLD_SYS             0
#define NEW_SYS             2
#define TRANS_SYS           1 
#define NOTACC_SYS          8

#endif
