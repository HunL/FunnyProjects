#include <stdlib.h>
#include <math.h>
typedef struct
{
    double      oper_rslt;
	double      operand1;
    char        operator1[2];
	double      operand2;
    char        operator2[2];
    double      operand3;
} Operator;

typedef struct
{
	char        disc_cd[6];
	int         num;
	Operator    opr[20];
} FeeAlgo;

FeeAlgo sFeeAlgos[50];
/***********del by sunyd@20110322*
#define  CaclStep(result, operand1, operator1, operand2, operator2, operand3) \
{ \
    switch (operator1) { \
    case '*': \
        result = floor(operand1 * operand2 + 0.50001); \
        break; \
    case '/': \
        result = floor(operand1 / operand2 + 0.50001); \
        break; \
    case '+': \
        result = operand1 + operand2; \
        break; \
    case '-': \
        result = operand1 - operand2; \
        break; \
    case '>': \
        if (operand1 > operand2) \
            result = operand2; \
        break; \
    case '<': \
        if (operand1 < operand2) \
            result = operand2; \
        break; \
    case '=': \
        result = operand1; \
        break; \
    } \
    switch (operator2) { \
    case '*': \
        result = floor(result * operand3 + 0.50001); \
        break; \
    case '/': \
        result = floor(result / operand3 + 0.50001); \
        break; \
    case '+': \
        result = result + operand3; \
        break; \
    case '-': \
        result = result - operand3; \
        break; \
    case '>': \
        if (result > operand3) \
            result = operand3; \
        break; \
    case '<': \
        if (result < operand3) \
            result = operand3; \
        break; \
    case '=': \
        result = operand3; \
        break; \
    } \
}

***********del by sunyd@20110322 */
