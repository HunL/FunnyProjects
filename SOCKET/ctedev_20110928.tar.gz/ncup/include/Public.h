/*****************************************************************************/
/*                              TOPLINK 2.0                                  */
/* Copyright (c) 2005 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/

#ifndef __PUBLIC_H
#define __PUBLIC

#define MIN(a,b) ((a>b)?(b):(a))
#define TRACEFILE "trace.log"

#define ISSPACE(x)      (x == ' ')
#define ISALPHA(x)      ((x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z'))
#define ISNUMBER(x)     (x >= '0' && x <= '9')
#define FLDNONEXIST(x)  (x != SIndFull)

#endif
