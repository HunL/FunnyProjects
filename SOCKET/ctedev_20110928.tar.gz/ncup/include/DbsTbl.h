#ifndef _DBS_TBL_H
#define _DBS_TBL_H

typedef struct
{
	long	usage_key;
	long	bmp_index;
	char	bmp_val[33];
} Tbl_bmp_inf_Def;

typedef struct
{
	 char	  card_sta[19+1]    ;  
   char 	card_end[19+1]    ;   
   char 	mcht_cd[15+1]     ;  
   double min_amt         ;  
   double max_amt         ;  
} TBL_union_card_Def;

typedef struct
{
	long	card_index;
	char	card_name[41];
	char	cb_code[12];
	long	card_id_track;
	long	card_id_offset;
	char	card_id[17];
	long	pan_track;
	long	pan_offset;
	long	pan_len;
	long	usage_key;
	char	used_flag[2];
	char	card_type[3];
} Tbl_card_inf_Def;

typedef struct
{
	char	srv_id[5];
	char	buf_chg_type[2];
	long	usage_key;
} Tbl_conv_type_Def;

typedef struct
{
	long	usage_key;
	long	txn_num;
	long	con_index;
	long	fld_index;
	long	begin_byte_pos;
	long	format_chg_need;
	char	val[36];
} Tbl_con_inf_Def;

typedef struct
{
	long	usage_key;
	long	fld_index;
	long	len_len;
	long	data_max_len;
	long	len_exp_val;
	long	ind_sym;
	long	data_format;
	long	len_char_set;
	long	data_char_set;
} Tbl_fld_inf_Def;

typedef struct
{
	long	usage_key;
	long	ipc_index;
	char	ipc_val[300+1];
} Tbl_ipc_inf_Def;

typedef struct
{
	char	srv_id[5];
	char	line_index[3];
	char	line_state[3];
	char	line_max[3];
	char	line_dsp[65];
} Tbl_line_inf_Def;

typedef struct {
    long        usage_key;
    char        srv_id[5];
    short       line_index;
    char        local_addr[16];
    char        remote_addr[16];
    long       in_sock_num;
    long       out_sock_num;
} Tbl_line_cfg_Def;

typedef struct
{
	char	inst_date[9];
	char	sys_seq_num[7];
	char	inst_time[7];
	char	msg_src_id[5];
	char	txn_num[5];
	char	trans_code[4];
	char	host_date[9];
	char	host_ssn[13];
	char	header_buf[47];
	char	msg_type[5];
	char	processing_code[7];
	char	trans_date_time[11];
	char	cup_ssn[13];
	char	time_local_trans[7];
	char	date_local_trans[5];
	char	date_settlmt[5];
	char	acq_inst_id_code[12];
	char	fwd_inst_id_code[12];
	char	resp_code[3];
	char	addtnl_data_len[4];
	char	addtnl_data[513];
	char	currcy_code_stlm[4];
	char	stlm_code[2];
	char	netwk_mgmt_code[4];
	char	crd_num[11];
	char	crd_revsal_num[11];
	char	dbt_num[11];
	char	dbt_revsal_num[11];
	char	xfer_num[11];
	char	xfer_revsal_num[11];
	char	inqury_num[11];
	char	authr_num[11];
	char	crd_proces_fee[13];
	char	dbt_proces_fee[13];
	char	crd_amt[17];
	char	crd_revsal_amt[17];
	char	dbt_amt[17];
	char	dbt_revsal_amt[17];
	char	amt_net_stlm[18];
	char	stlm_inst_id_len[3];
	char	stlm_inst_id[12];
	char	rcvg_code_len[3];
	char	rcvg_code[12];
	char	msq_type[17];
	char	misc_flag[33];
	char	misc_1[129];
} Tbl_manager_info_Def;

typedef struct
{
	long	usage_key;
	long	txn_num;
	long	ipc_index;
	long	bmp_index;
	long	mand_bmp_index;
	char	msg_type[5];
	char	txn_code[4];
} Tbl_msg_inf_Def;

typedef struct
{
	char	msq_int_id[3];
	char	msq_key[17];
	char	msq_type[9];
} Tbl_msq_inf_Def;

typedef struct
{
	char	txn_num[5];
	char	msg_src_id[5];
	char	msg_to_id[5];
	char	check_card_flag[2];
} Tbl_route_inf_Def;

typedef struct
{
	char	src_id[5];
	char	dest_id[5];
	char	src_rsp_code[9];
	char	dest_rsp_code[9];
	char	rsp_code_dsp[65];
} Tbl_rsp_code_map_Def;

typedef struct
{
	char    api_name[5];
	char	src_rsp_code[9];
	char	dest_rsp_code[9];
	char	rsp_code_dsp[65];
} Tbl_rsp_code_map_new_Def;

typedef struct
{
	char    inst_date[9];
	char	inst_time[7];
	char	msg_src_id[5];
	char	txn_num[5];
	char	sys_seq_num[7];
	char	msg_dest_srv_id[5];
	char	send_count[3];
	char	center_stlm_date[9];
	char	host_stlm_date[9];
	char	msg_len[5];
	char	msg_ipc1[3073];
	char	msg_ipc2[3073];
} Tbl_saf_msg_Def;

typedef struct
{
    long    usage_key;
	char	srv_id[5];
	char	srv_name[9];
	char	msq_int_id[3];
	char	srv_num[3];
	char	relate_srv_id[513];
	char	srv_dsp[65];
} Tbl_srv_inf_Def;

typedef struct
{
    long    usage_key;
	char	srv_id[5];
	char	param_usage[2];
	char	param_index[3];
	char	param_data[65];
	char	param_dsp[65];
} Tbl_srv_param_Def;

typedef struct
{
	char	ssn_type[2];
	char	ssn_value[7];
	char	ssn_min[7];
	char	ssn_max[7];
	char	buf_count[4];
} Tbl_ssn_Def;

typedef struct
{
	char	srv_id[5];
	char	param_id[5];
	char	param_name[33];
	char	param_data[257];
	char	param_dsp[257];
} Tbl_sys_param_Def;

typedef struct 
{
    char    inst_date[9];
    char    inst_time[7];
    char    txn_num[5];
    char    stlm_date[9];
    char    trans_type[2];
    char    trans_state[2];
    char    sys_seq_num[7];
	char    term_ssn[13];
    char    int_con_id[33];
    char    pay_item_id[33];
	char    fee_pay_item_id[33];
    char    key_host[33];
    char    lock_id[13];
    char    card_no[20];
    char    acct_no[36];
    char    amt_trans[13];
    char    fee_trans[14];
	char    addtnl_amt[13];
    char    acct_inst[12];
    char    resp_code[3];
    char    revsal_flag[2];
    char    revsal_ssn[33];
	char    key_revsal[33];
    char    cancel_flag[2];
    char    cancel_ssn[33];
	char    key_cancel[33];
	char    postinglockitem[13];
    char    misc[129];
} Tbl_dm_txn_Def;


typedef struct
{
	char	inst_date[9];
	char	sys_seq_num[7];
	char	inst_time[7];
	char	msg_src_id[5];
	char	txn_num[5];
	char	trans_code[4];
	char	trans_type[2];
	char	trans_state[2];
	char	revsal_flag[2];
	char	revsal_ssn[7];
	char	cancel_flag[2];
	char	cancel_ssn[7];
	char	host_date[9];
	char	host_ssn[13];
	char	term_ssn[13];
	char	key_rsp[33];
	char	key_revsal[33];
	char	key_cancel[33];
	char	header_buf[47];
	char	gf_header[257];
	char	msg_type[5];
	char	pan_len[3];
	char	pan[20];
	char	processing_code[7];
	char	amt_trans[13];
	char	amt_settlmt[13];
	char	amt_cdhldr_bil[13];
	char	trans_date_time[11];
	char	conv_rate_stlm[9];
	char	conv_rate_cdhldr[9];
	char	cup_ssn[7];
	char	time_local_trans[7];
	char	date_local_trans[5];
	char	date_settlmt[5];
	char	date_conv[5];
	char	mchnt_type[5];
	char	acq_cntry_code[4];
	char	pos_entry_mode[4];
	char	pos_cond_code[3];
	char	pos_pin_cap_code[3];
	char	amt_trans_fee[10];
	char	acq_inst_id_code[12];
	char	fwd_inst_id_code[12];
	char	card_material[3];
	char	retrivl_ref[13];
	char	authr_id_resp[7];
	char	resp_code[3];
	char	card_accp_term_id[9];
	char	card_accp_id[16];
	char	card_accp_name[41];
	char	addrsp_data_len[3];
	char	addrsp_data[26];
	char	addint_data_len [4];
	char	addint_data[256];
	char	addtnl_data_len[4];
	char	addtnl_data[513];
	char	currcy_code_trans[4];
	char	currcy_code_stlm[4];
	char	currcy_code_chldr[4];
	char	ic_data_len[4];
	char	ic_data[256];
	char	addtnl_amt_len[4];
	char	addtnl_amt[41];
	char	fld_reserved_len[4];
	char	fld_reserved[31];
	char	ch_auth_info_len[4];
	char	ch_auth_info[201];
	char	switch_data_len[4];
	char	switch_data[201];
	char	orig_data_elemts[43];
	char	replacement_amts[43];
	char	rcvg_code_len[3];
	char	rcvg_code[12];
	char	acct_id1_len[3];
	char	acct_id1[29];
	char	acct_id2_len[3];
	char	acct_id2[29];
	char	trans_descrpt_len[4];
	char	trans_descrpt[101];
	char	cup_swresved_len[4];
	char	cup_swresved[101];
	char	acq_swresved_len[4];
	char	acq_swresved[101];
	char	iss_swresved_len[4];
	char	iss_swresved[101];
	char	host_trans_fee1[13];
	char	host_trans_fee2[13];
	char	tlr_num[9];
	char	open_inst[16];
	char	stlm_inst[16];
	char	batch_flag[2];
	char	batch_date[9];
	char	msq_type[17];
	char	amt_return[13];
	char	authr_id_r[7];
	char	misc_flag[33];
	char	misc_1[129];
	char	misc_2[129];
	char	req_buf[513];
	char	rsp_buf[513];
	char	req_node[21];
	char	rsp_node[21];
	char	update_time[15];
} Tbl_txn_Def;

typedef struct
{
	char	inst_date[9];
	char	sys_seq_num[7];
	char	inst_time[7];
	char	msg_src_id[5];
	char	txn_num[5];
	char	trans_code[4];
	char	trans_type[2];
	char	trans_state[2];
	char	revsal_flag[2];
	char	revsal_ssn[7];
	char	cancel_flag[2];
	char	cancel_ssn[7];
	char	host_date[9];
	char	host_ssn[13];
	char	term_ssn[13];
	char	key_rsp[33];
	char	key_revsal[33];
	char	key_cancel[33];
	char	header_buf[47];
	char	gf_header[257];
	char	msg_type[5];
	char	pan_len[3];
	char	pan[20];
	char	processing_code[7];
	char	amt_trans[13];
	char	amt_settlmt[13];
	char	amt_cdhldr_bil[13];
	char	trans_date_time[11];
	char	conv_rate_stlm[9];
	char	conv_rate_cdhldr[9];
	char	cup_ssn[7];
	char	time_local_trans[7];
	char	date_local_trans[5];
	char	date_settlmt[5];
	char	date_conv[5];
	char	mchnt_type[5];
	char	acq_cntry_code[4];
	char	pos_entry_mode[4];
	char	pos_cond_code[3];
	char	pos_pin_cap_code[3];
	char	amt_trans_fee[10];
	char	acq_inst_id_code[12];
	char	fwd_inst_id_code[12];
	char	card_material[3];
	char	retrivl_ref[13];
	char	authr_id_resp[7];
	char	resp_code[3];
	char	card_accp_term_id[9];
	char	card_accp_id[16];
	char	card_accp_name[41];
	char	addrsp_data_len[3];
	char	addrsp_data[26];
	char	addint_data_len [4];
	char	addint_data[256];
	char	addtnl_data_len[4];
	char	addtnl_data[513];
	char	currcy_code_trans[4];
	char	currcy_code_stlm[4];
	char	currcy_code_chldr[4];
	char	ic_data_len[4];
	char	ic_data[256];
	char	addtnl_amt_len[4];
	char	addtnl_amt[41];
	char	fld_reserved_len[4];
	char	fld_reserved[31];
	char	ch_auth_info_len[4];
	char	ch_auth_info[201];
	char	switch_data_len[4];
	char	switch_data[201];
	char	orig_data_elemts[43];
	char	replacement_amts[43];
	char	rcvg_code_len[3];
	char	rcvg_code[12];
	char	acct_id1_len[3];
	char	acct_id1[29];
	char	acct_id2_len[3];
	char	acct_id2[29];
	char	trans_descrpt_len[4];
	char	trans_descrpt[101];
	char	cup_swresved_len[4];
	char	cup_swresved[101];
	char	acq_swresved_len[4];
	char	acq_swresved[101];
	char	iss_swresved_len[4];
	char	iss_swresved[101];
	char	host_trans_fee1[13];
	char	host_trans_fee2[13];
	char	tlr_num[9];
	char	open_inst[16];
	char	stlm_inst[16];
	char	batch_flag[2];
	char	batch_date[9];
	char	msq_type[17];
	char	amt_return[13];
	char	authr_id_r[7];
	char	misc_flag[33];
	char	misc_1[129];
	char	misc_2[129];
	char	req_buf[513];
	char	rsp_buf[513];
	char	req_node[21];
	char	rsp_node[21];
	char	update_time[15];
} Tbl_txn_his_Def;

typedef struct
{
	char	txn_num[5];
	char	msg_src_id[5];
	char	support_flag[2];
	char	rsp_type[2];
	char	msg_to[4];
	char	to_txn_num[5];
	char	msg_dest1[5];
	char	saf_count1[3];
	char	msg_dest2[5];
	char	saf_count2[3];
	char	rsp_dest_srv_id[5];
	char	rsp_txn_num[5];
	char	pin_flag[2];
	char	misc_flag[9];
	char	txn_dsp[129];
} Tbl_txn_inf_Def;

typedef struct
{
	char	srv_id[5];
	char	param_id[5];
	char	param_name[33];
	char	param_data[257];
	char	param_dsp[257];
} Tbl_usr_param_Def;

typedef struct
{
	short	usage_key;
	short	buf_chg_index;
	short	sour_buf_index;
	short	dest_buf_index;
	char	buf_dsp[257];
} Tbl_buf_chg_Def;

typedef struct 
{
	char	key_index[3];
	char	hsm_index[5];
	char	bmk[33];
	char	pinkey1[33];
	char	mackey1[33];
	char	pinkey2[33];
	char	mackey2[33];
} Tbl_key_param_Def;

typedef struct
{
	short	usage_key;
	short	buf_dsp_index;
	short	pos_index;
	short	fld_index;
	short	fld_id;
	short	fld_offset;
} Tbl_buf_dsp_Def;

typedef struct
{
	short	usage_key;
	short	buf_dsp_index;
	char	buf_dsp[257];
} Tbl_buf_dsp_dsp_Def;

typedef struct
{
	short	usage_key;
	short	fld_id;
	short	fld_l;
	short	fld_type;
	char	fld_dsp[257];
} Tbl_fld_dsp_Def;

typedef struct
{
	short	usage_key;
	short	buf_chg_index;
	short	sour_fld_index;
	short	dest_fld_index;
} Tbl_fld_tsf_Def;

typedef struct
{
	short	usage_key;
	char	comp_key[11];
	short	comp_key_len;
	short	ipc_dft_index;
	short	buf_dsp_index;
	char	txn_num[5];
	char	ipc_dft[257];
} Tbl_ipc_dft_dsp_Def;

typedef struct
{
	short	usage_key;
	short	ipc_dft_index;
	short	pos_index;
	short	fld_index;
	short	fld_len;
	char	fld_val[601];
} Tbl_ipc_dft_Def;

typedef struct
{
	char	srv_id[5];
	char	msq_type[17];
	char	creation_time[15];
} Tbl_dumpmsg_Def;

typedef struct 
{
	char	record_id[9];
	char	status[2];
	char	cups_status[2];
	char	cups_stlm_date[5];
	char	l_cups_stlm_date[5];
	char	rec_updt_time[15];
} Tbl_sys_stat_Def;

typedef struct
{
	char    inst_no[3];
	char    city_code[5];
	char    prov_code[3];
	char    dist_code[4];
	char    term_no[5];
	char    inst_name[65];
	char    acq_inst_id_code[12];
	char    ctrl_date[33];
	double  tran_fee;
	double	ctrl_amt;
} Tbl_frn_ctl_Def;
typedef struct
{
	char	card_bin[10];
	char	card_type[3];
	char	branch_code[11];
}Tbl_card_bin;

typedef struct 
{
	char	sa_card_no[20];
	char	sa_limit_amt[13];
	char	sa_action[2];
} Tbl_ctl_card_inf_Def;

typedef struct 
{
	char	sa_mer_no[16];
	char	sa_limit_amt[13];
	char	sa_action[2];
} Tbl_ctl_mcht_inf_Def;

typedef struct 
{
	char	sa_branch_code[9+1];
	char	sa_model_kind[3];
	char	sa_be_use[2];
	char	sa_action[2];
	char	sa_limit_num[9];
	char	sa_limit_amount[13];
} Tbl_risk_inf_Def;

typedef struct
{
	char	sa_step_key[49];
	char	sa_tpcs_key[49];
	char	sa_txn_card[20];
	char	sa_expr_date[5];
	char	sa_mcht_no[16];
	char	sa_term_no[9];
	char	sa_txn_num[5];
	char	sa_txn_date[9];
	char	sa_txn_time[7];
	char	sa_txn_amt[13];
	char	sa_msg_src_id[5];
	char	sa_msg_dest_id[5];
	char	sa_rsp_code[3];
	char	sa_clc_flag[2];
	char	sa_clc_rsn1[51];
	char	sa_clc_rsn2[51];
	char	sa_note_txt[51];
	char	sa_open_inst[4];
	char	sa_stlm_inst[9+1];
	char	sa_updt_time[15];
	char	sa_inst_time[15];
} Tbl_clc_mon_Def;

typedef struct 
{
	long	l_usage_key;
	char	sa_fc_auth_rsp_code[4];
	char	sa_app_m2[2];
	char	sa_app_m4[2];
} Tbl_auth_rsp_info_Def;

typedef struct
{
	char	sa_txn_card[20];
	char	sa_mcht_no[16];
	char	sa_txn_date[9];
	char	sa_ins_flag[2];
	char	sa_txn_amt[13];
	char	sa_txn_num[9];
} Tbl_txn_sts_Def;

/* ����Ҫ */
typedef struct
{
	char     disc_cd[5+1];
	int      index_num ;
	long     min_fee;
	long     max_fee;
	long     floor_mount;
	long	upper_mount;
	int		flag;
	long	fee_value;
	char	rec_upd_usr_id[10+1];
	char    rec_upd_ts[14+1];
	char	rec_crt_ts[14+1];
	char    stxn_num[4+1];
} Tbl_his_disc_algo_Def;

typedef struct
{
	char	MCHNT_CD[16];
	char  ACQ_INS_ID_CD [14];
	char	SIGN_INS_ID_CD[14];
	char	PRINT_INS_ID_CD[14];
	char	AREA_CD [5];
	char  CONN_MD [2];
	char  MCHNT_MNG_MD[2];
	char  MCHNT_ST[2];
	char  MCHNT_GRP[5];
	char  MCHNT_TP[5];
	char  MCHNT_NM[61];
	char  MCHNT_CN_ABBR[41];
	char  MCHNT_EN_NM[61];
	char  MCHNT_EN_ABBR[21];
	char  DEAL_LOCA_NM[101];
	char  MCHNT_ATTR[21];
	char  EXP_ID[31];
	char  MCHNT_GROUP_FLAG[2];
	char  MCHNT_GROUP_ID[9];
	char  PASSWORD[9];
	long  POS_NUM;
	long  POS_INUSE_NUM;
	long  MIS_NUM;
	char  MCHT_FORIN_FLG[2];
	char  FOR_MCHNT_GRP[5];
	char  FOR_MCHNT_TP[5];
	char  FOR_CITY_NM_EN[61];
	char  DEAL_LOCA_NM_EN[101];
	char  FOR_CARD_USE_IN[11];
	char  FOR_CARD_RST_IN[11];
	char  FOR_CARD_RECOURSE_IN[11];
	long  FOR_SIGN_LMT_AT;
	char  DIV_MCHNT_TP[5];
	long  DIV_SINGL_LMT_AMT;
	char  MCHNT_FUNT_IN[20];
	long  PRESS_TERM_NUM;
	long  PER_COM_LMT_AMT;
	long  PER_GOLD_LMT_AMT;
	long  CMP_COM_LMT_AMT;
	long  CMP_GOLD_LMT_AMT;
	long  SINGL_LMT_AMT;
	long  DAY_LMT_AMT;
	long  MONTH_LMT_AMT;
	long  YEAR_LMT_AMT;
	char  DISC_ALGO_IN[2];
	long  DISC_RATE;
	char  DISC_CD[6];
	char  DISC_CRT_TS[9];
	char  DISC_ALT_TS[9];
	char  SETTLE_ACCT_IN[2];
	char  SETTLE_ACCT_ATTR[2];
	char  SETTLE_ACCT[31];
	char  SETTLE_ACCT_NM[61];
	char  SETTLE_BANK_CD[14];
	char  SETTLE_BANK_NM[61];
	char  EXCHANGE_INS_CD[11];
	char  EXCHANGE_CD[7];
	char  ETPS_ATTR[5];
	char  ETPS_CD[21];
	char  ARTIF[20];
	char  RESERVE1[26];
	char  RESERVE2[26];
	char  RESERVE3[26];
	char  RESERVE4[51];
	char  RESERVE5[51];
	char  RESERVE6[51];
}  Tbl_inf_mcht_inf_Def;

typedef struct
{
	char  		mcht_cd	[  16];
	char  		term_id	[   9];
	char  		term_id_id	[  16];
	char  		term_sta	[   2];
	char  		term_sign_sta	[   2];
	char  		chk_sta	[   2];
	char  		term_mcc	[   5];
	char  		term_factory	[   2];
	char  		term_mach_tp	[   2];
	char  		term_ver	[   3];
	char  		term_single_limit	[  13];
	char  		term_tp	[   3];
	char  		param_down_sign	[   2];
	char  		param1_down_sign	[   2];
	char  		ic_down_sign	[   2];
	char  		key_down_sign	[   2];
	char  		prop_tp	[   3];
	char  		prop_ins_nm	[  81];
	char  		support_ic	[   2];
	char  		psam_id	[   9];
	char  		term_place	[   2];
	char  		dial_tp	[   2];
	char  		term_ins	[  12];
	char  		term_ver_tp	[   3];
	char  		term_batch_nm	[   7];
	char  		term_stlm_dt	[   9];
	char  		term_para	[ 257];
	char  		term_para_1	[ 257];
	char            term_para_2     [ 257];
    char  		bind_tel	[  15];
	char  		term_addr	[ 351];
	char  		opr_nm	[  21];
	char  		cont_tel	[  21];
	char  		equip_inv_id	[  14];
	char  		equip_inv_nm	[  51];
	char  		run_main_id_1	[  14];
	char  		run_main_nm_1	[  51];
	char  		run_main_id_2	[  14];
	char  		run_main_nm_2	[  51];
	char  		oth_svr_id	[  14];
	char  		oth_svr_nm	[  51];
	char  		rec_opr_id	[   2];
	char  		rec_upd_opr	[  11];
	char		rec_crt_ts	[ 27];
	char		rec_upd_ts	[ 27];
}tbl_term_def;

typedef struct
{
	char terminal_code 		[8+1];	                            
  char brno 			        [9+1];               /*ATM�кţ��������룩*/               
  char unit_code 		[9+1];           /*Ӫҵ��λ����*/                      
  char depart_code 		[4+1];         /*���Ŵ���*/                          
  char net_code		[9+1];             /*֧�кţ�Ӫҵ���㣩*/                
  char cup_organ		[8+1];              /*����������*/ 
  char term_st          [1+1];
  char tlrno 			[8+1];                  /*��Ա��*/                         
  char fetch_cash_max[12+1];      /*һ�����ȡ����     */                        
  char fetch_cash_min[12+1];      /*һ����Сȡ����     */                      
  char virement_max[12+1];          /*һ�����ת�ʽ��     */                  
  char ic_circle_max[12+1];         /*IC��һ�����Ȧ���     */           
  char ic_circle_min[12+1];       /*IC��һ����СȦ���     */          
  char circleget_max[12+1];        /*IC��һ�����Ȧȡ��     */           
  char saving_max[12+1];        /*һ���������     */          
  char connt_cm[1+1];        /*ֱ��D-����I��־*/                                   
  char txn_inf         [8+1];               /*������Ϣ*/                   
  char status 			[1+1];                  /*ATM״̬*/                                       
  char batch_number 		[14+1];              /*ATM����*/                                        
  char ip_address 		[15+1];             /*ATM����IP��ַ*/                
  char inport       [5+1];                /*ATM�˿ں�*/
  char cash_account [22+1];                /*�ֽ��ʺ�*/                                   
}Tbl_atm_stat_Def;

typedef struct
{
	char		MCHT_CD     [16]    ;   /* �̻��� */
    char		TXN_NUM     [5]     ;   /* ���״��� */
    char		CARD_TYPE   [3]     ;   /* ���� 00 ��� 01 ���� 02 ���п�*/
    char		CHANNEL     [2]     ;   /* �޶��־ 0-�ض� 1-Ĭ�� */
    char		DAY_NUM     [6]     ;  	/* ���ս��ױ������� */
    double 	DAY_AMT      		; 	/* �����ۼƽ������ */
    double 	DAY_SINGLE   		; 	/* ���յ��ʽ������ */
    char		MON_NUM     [6]	 ;   /* ���½��ױ������� */
    double 	MON_AMT      		; 	/* �����ۼƽ������ */
    char		RESERVED    [31]  ;
    char	    REC_CRT_TS  [27]         ;     /* ����ʱ��� */
    char		REC_UPD_TS  [27]          ;      /* �޸�ʱ��� */
}  Cst_mcht_fee_inf_Def;

typedef struct
{
	char	ORGID               [11+1]     	;	
	char	TRANSID             [4+1]      	;	
	char	USINGFLG            [1+1]      	;	
	char	CARD_TYPE    		[2+1]     	;	/* ���� 00 ��� 01 ���� 02 ���п�*/ 	
	char	DAY_NUM      		[5+1]     	;	/* ���ս��ױ������� */              	
	double 	DAY_AMT      		;	/* �����ۼƽ������ */              
	double 	DAY_SINGLE   		;	/* ���յ��ʽ������ */              
	char	MON_NUM      		[5+1]     	;	/* ���½��ױ������� */              	
	double	MON_AMT      		;	/* �����ۼƽ������ */              
	char	RESERVED     		[30+1]      	;	                                    
	char	REC_CRT_TS          [26+1]    	;	/* ����ʱ��� */                    
	char	REC_UPD_TS          [26+1]    	;	/* �޸�ʱ��� */                    
}  Tbl_org_quota_cfg_NEW;

typedef struct 
{
	  char	mcht_cd[16]         ;   /* �̻��� */
    char 	term_id[9]         ;    /* �ն˺� */
    char 	txn_num[5]       ;      /* ���״��� */
    char    card_tp[3];
    char 	month[3]         ;      /* �·� */
    char 	day[3]         ;  	    /* ���� */
    char  m_count[6]    ;         /* ���ۼƱ��� */
    char  d_count[6]    ;         /* ���ۼƱ��� */
    double 		m_total      ; 	    /* ���ۼƽ�� */
    double 		d_total   ; 	      /* ���ۼƽ�� */
}  CST_MERTRANS_CNT_DEF;

typedef struct 
{
   char brh_id [10+1];
   char cup_brh_id [128+1];
   char brh_level [1+1];
   char brh_sta [1+1];
   char up_brh_id [10+1];
   char resv2[128 + 1];
}TBL_brh_info_Def;

typedef struct
{
	char owner[12];
	char key[21];
	char type[3];
	char value[201];
	char desce [61];
	char reserve [65];
}CST_sys_param_def;
typedef struct
{
	char merchno[16];
	char accno[41];
	char accname[61];
	char accbankno[16];
	char qcname[91];
	char reserve1[51];
	char reserve2[101];
}Cst_merchaccount_book_Def;

typedef struct  
{
    char subserial[21];   /*ǰ����ˮ��*/
    char mchnt_cd[16];
    char mem_nm[61];
    char mem_nm_en[61];
    char sex[2];
    char birth[21];
    char pan[20];
    char pantp[3];
    char cardTp[2];
    char cardNo[51];
    char cstNo[51];
    char cardOrg[5];
    char cardAddr[101];
    char brhNo[31];
    char bankAddrno[21];
    char opr[11];
    char contactPhone[21];
    char contactTel[21];
    char contactAddr[61];
    char company[61];
    char postCode[21];
    char cstManager[11];
    char oprTp[2];
    char acctTp[2];
    char srvLevel[3];
    char rserve[101];
}Cst_Mem_CardInfo_Def;

typedef struct  
{
	char	MCHNT_TP[5];
	char  MCHNT_TP_GRP [5];
}TBl_inf_mcht_tp_Def;

typedef struct
{
	char	key_rsp[33];
	char	key_revsal[33];
	char	key_cancel[33];
	char	txn_num[5];
	char	pan[20];
	char	amt_trans[13];
	char	trans_date_time[11];
	char    req_iclen[4];
	char    req_icdata[511];
	char    rsp_iclen[4];
	char    rsp_icdata[511];
	char	insert_time[15];
	char	update_time[15];
} Tbl_ic_txn_Def;

/* �ڿ�BIN��Ϣ�� */
typedef struct
{
  char    ins_id_cd[12];
  char    acc1_offset[3];
  char    acc1_len[3];
  char    acc1_tnum[2];
  char    acc2_offset[3];
  char    acc2_len[3];
  char    acc2_tnum[2];
  char    bin_offset[3];
  char    bin_len[3];
  char    bin_sta_no[31];
  char    bin_end_no[31];
  char    bin_tnum[2];
  char    card_tp[3];
} Tbl_bank_bin_inf_Def;

typedef struct
{
	char	area_id[11];
	char	country_code[4];
	char	inter_flag[2];
	char	zone_brh_id[11];
	char	use_flag[2];
	char    zone_name[51];
	char    remark[101];
	char    update_time[15];
	char    opr_id[21];
} Tbl_cup_area_Def;

typedef struct
{
	char	inst_date[8+1];
	char	sys_seq_num[6+1];
	char	inst_time[6+1];
	char	msg_src_id[4+1];
	char	txn_num[4+1];
	char	trans_code[3+1];
	char	trans_chnl[4+1];
	char	trans_state[1+1];
	char	revsal_flag[1+1];
	char	revsal_ssn[6+1];
	char	cancel_flag[1+1];
	char	cancel_ssn[6+1];
	char    fw_trans_id[4+1];
    char    fw_trans_date[8+1];
    char    fw_trans_time[6+1];
    char    fw_trans_ssn[22+1];
    char    mid_time[10+1];
    char    mid_ssn[12+1];
    char    mid_tag[8+1];
	char	key_rsp[32+1];
	char	key_revsal[32+1];
	char	key_cancel[32+1];
	char	bp_header[80+1];
	char    msg_type[4+1];
	char	pan_len[2+1];
	char	pan[19+1];
	char	processing_code[6+1];
	char	amt_trans[12+1];
	char	point_trans[12+1];
	char	trans_date_time[10+1];
	char	time_local_trans[6+1];
	char	date_local_trans[4+1];
	char	date_settlmt[8+1];
	char	mchnt_type[4+1];
	char	pos_entry_mode[3+1];
	char	pos_cond_code[2+1];
	char	pos_pin_cap_code[2+1];
	char	acq_inst_id_code[11+1];
	char	fwd_inst_id_code[11+1];
	char	retrivl_ref[12+1];
	char	authr_id_resp[6+1];
	char	resp_code[2+1];
	char	resp_desp[7+1];
	char	card_accp_term_id[8+1];
	char	card_accp_id[15+1];
	char	card_accp_name[40+1];
	char	currcy_code_trans[3+1];
	char	addtnl_amt_len[3+1];
	char	addtnl_amt[40+1];
	char	fld_reserved_len[3+1];
	char	fld_reserved[30+1];
	char	switch_data_len[3+1];
	char	switch_data[200+1];
	char	acq_swresved_len[3+1];
	char	acq_swresved[100+1];
    char    tom_flag_1[2+1];
    char    tom_flag_2[26+1];
    char	msq_type[16+1];
    char    amt_return[12+1];
    char    authr_id_r[6+1];
    char    order_id[18+1];
    char    bp_type[3+1];
    char    consume_type[1+1];
	char	misc_flag[32+1];
	char	misc_1[128+1];
	char	misc_2[128+1];
	char	loop_req[512+1];
	char	loop_rsp[512+1];
	char	req_node[21+1];
	char	rsp_node[21+1];
	char    update_time[14+1];
} Tbl_bonus_txn_Def;

typedef struct
{
	char	sii_mcht_no[16];
	char	sii_mcht_name[41];
	char	sii_use_flag[2];
	char	crt_opr_id[13];
	char	crt_datetime[15];
	char    upd_opr_id[13];
	char    upd_datetime[15];
	char    reserve1[33];
	char    reserve2[33];
} Tbl_society_insure_info_Def;

int gnMaxRspCodeMapLen;
Tbl_rsp_code_map_Def tRspCodeMap[500];

Tbl_cup_area_Def gatCupArea[500];
int gnMaxCupAreaLen;

#endif
