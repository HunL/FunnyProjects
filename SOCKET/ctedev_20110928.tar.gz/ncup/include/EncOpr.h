#ifndef __ENC_OPR_H
#define __ENC_OPR_H

/* define for nEncOpr return code */
#define HSM_SUCCESS                 0
#define HSM_FAIL                    -1

/* define for saOprType */
#define HSM_TEST				'0'
#define HSM_GENMAC				'1'
#define HSM_VERIFYMAC			'2'
#define HSM_VERIFYMACWITHKEY	'3'
#define HSM_GENMACWITHKEY		'4'
#define HSM_TRANSPIN			'5'
#define HSM_CHANGEKEY			'6'

#define HSM_GENZPK				'7'
#define HSM_GENTMK				'8'
#define HSM_GENTWK				'9'

#define HSM_VERIFYMACWITHKEY4POS	'a'
#define HSM_GENMACWITHKEY4POS		'b'

#define HSM_CHANGEZPK			'c'
#define HSM_CHANGEZAK			'd'
#define HSM_GENZAK			'e'
#define HSM_CVTPINKEY		'f'
#define HSM_VERIFYARQC		'g'
#define HSM_GENSCRIPTMAC		'h'
#define HSM_CVTMACKEY		'i'
#define HSM_TRANSPIN4ZK			'j'

#define	HSM_MAC_BLOCK_LEN_LEN	3
#define HSM_MAC_BLOCK_LEN_MAX	512


/*-----------Atm--------------------*/
#define HSM_INDEX_LEN           4
#define HSM_VERTMMACWITHATM     '1'
#define HSM_GENTMMACWITHATM		'2'
#define HSM_CHANGETMKEYWITHATM  '3'
#define HSM_DISPANTRACKWITHATM	'4'
#define HSM_NEWMACKEYWITHATM    '5'
#define HSM_NEWPINKEYWITHATM	'6'
#define HSM_GENTMWKWITHATM      '7'

typedef struct 
{
	char	saOprType;
	char	saEncWay[16];
	char	saCardNo[21];
	char	saRout[10];
	char	saEnc[24];
	char	saMacBlockLen[3];
	char	saMacBlock[512];
	char	saRspCode[2];

	char	saZAK[32];
	char	saZAKLMK[32];
	char	saZAKChkV[8];

	char	saZPK[32];
	char	saZPKLMK[32];
	char	saZPKChkV[8];

	char	saTMK[32];
	char	saTMKLMK[32];
	char	saTMKChkV[8];

	char	saPIK[32];
	char	saPIKLMK[32];
	char	saPIKChkV[8];

	char	saMAK[32];
	char	saMAKLMK[32];
	char	saMAKChkV[8];

	char	saTRK[32];
	char	saTRKLMK[32];
	char	saTRKChkV[8];
}HSMOprDef;

typedef struct
{
	long	nMsgType;
	HSMOprDef	hsmOpr;
}HSMMsgInDef;

typedef struct {
    int  nPinKeyLen;          /* PIN��Կ���� */
    char sLmkPinKey[32];      /* ���ܻ�����Կ���ܺ����Կ */
    char sZmkPinKey[32];      /* �������ܼ��ܺ����Կ */
    char sPinKeyChkValue[16]; /* PIN��ԿУ��ֵ */
    int  nMacKeyLen;
    char sLmkMacKey[32];
    char sZmkMacKey[32];
    char sMacKeyChkValue[16];
    int  nTrkKeyLen;
    char sLmkTrkKey[32];
    char sZmkTrkKey[32];
    char sTrkKeyChkValue[16];
    char sPosBmk[40];
} T_Atm_WorkKey;

int nEncOpr(HSMOprDef *hsmOpr);

#endif
