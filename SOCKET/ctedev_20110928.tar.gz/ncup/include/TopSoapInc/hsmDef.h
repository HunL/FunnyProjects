#ifndef __HSM_DEF_H
#define __HSM_DEF_H


typedef struct _HSM_COMMON_RSP
{
	char sSequence[25+1];
	char sErrCode[3+1];
	char sErrMsg[128+1];
	char sRstBuf[64+1];
}HSM_COMMON_RSP;

/**/
typedef struct _HSM_CVN_VERIFY_REQ
{
    char sAppID[5];
	char sSerialIn[25];
	char sPAN[20];
	char sExpireDate[5];
	char sServiceCode[4];
	char sMagTrack[100];
	char sTrackNo[2];
	char sCvkType[4];
	char sCvv2[4];
	
}HSM_CVV_VERIFY_REQ;

typedef struct _HSM_PVV_VERIFY_REQ
{
    char          sAppID[5];
	char          sKeyIndex[15];
	char          sSerialIn[25];
	char          sPVKI[2];
	char          sPINBlock[17];
	char          sPAN[20];
	char          sPvvformat[2];
	char          sPvktype[5];

}HSM_PVV_VERIFY_REQ;


typedef struct _HSM_GEN_MAC_REQ
{
    char sAppID[5];
	char sKeyIndex[15];
	char sTak[6];
	char sSerialIn[25];
	char sFormat[2];
	char sMsglen[5];
	char sMessage[1024];

}HSM_GEN_MAC_REQ;

typedef struct _HSM_WK_UPDATE_REQ
{
    char sAppID[5];
	char sKeyIndex[15];
	char sSerialIn[25];
	char keytype[2];
	char keyschema[2];
	char key[64];
	char keycheckvalue[32];
} HSM_WK_UPDATE;


#define SOAP_LOG_MODE_NORMAL         "soapHSM.log" , HT_LOG_MODE_NORMAL ,  __FILE__,__LINE__
#define SOAP_LOG_MODE_ERROR          "soapHSM.log" , HT_LOG_MODE_ERROR  ,  __FILE__,__LINE__
#define SOAP_LOG_MODE_DEBUG          "soapHSM.log" , HT_LOG_MODE_DEBUG  ,  __FILE__,__LINE__

typedef struct _RESULT
{
	char sErrMsg[4];
	char sSerialOut[21];
	char sRstBuf[64];
	char sRstBuf1[64];
}HSMRESULT;


typedef struct _PINTrans
{
    char sAppID[5];
	char sKeyIndex[26];
	char sTpk[33];
	char sAppID2[5];
	char sKeyIndex2[5];
	char sTpk2[33];
	char sSerialIn[21];
	char sPinblock[17];
	char sPAN[17];

}PINTRANS;


typedef struct _MACGen
{
    char sAppID[5];
	char sKeyIndex[5];
	char sTak[33];
	char sSerialIn[25];
	char sFormat[2];
	char sMsglength[5];
	char sMessage[1024];

}MACGEN;

typedef struct _MACVerify
{
    char sAppID[5];
	char sKeyIndex[27];
	char sTak[33];
	char sSerialIn[25];
	char sFormat[2];
	char sMsglength[5];
	char sMessage[1024];
	char sMACCode[17];

}MACVERIFY;

typedef struct _CVNVerify
{
    char sAppID[5];
	char sSerialIn[25];
	char sPAN[20];
	char sExpireDate[5];
	char sServiceCode[4];
	char smagtrack[100];
	char strackno[2];
	char scvktype[4];
	char scvv2[4];

}CVNVERIFY;

typedef struct _PVVVerify
{
    char sAppID[5];
	char sKeyIndex[6];
	char sSerialIn[25];
	char sPVKI[2];
	char sPINBlock[17];
	char sPAN[17];
	char sPvvformat[2];
	char sPvktype[5];

}PVVVERIFY;

typedef struct _KEYChange
{
	char sAppID[5];
    char sKeyIndex[6];
    char sSerialIn[25];
    char sPinkey[33];
    char sPinkeycheckvalue[33];
    char sMackey[49];
    char sMackeycheckvalue[33];
    char sEncrykey[33];
    char sEncrykeycheckvalue[33];
    char szmk[33];
    char szmkcheckvalue[33];
}KEYCHANGE;

typedef struct _KEYGet
{
    char sAppID[5];
    char sKeyIndex[48];
    char sSerialIn[25];
    char sFlag[2];
}KEYGET;

#endif
