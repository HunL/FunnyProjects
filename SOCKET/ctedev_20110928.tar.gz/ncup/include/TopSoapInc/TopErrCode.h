#ifndef _TOP_ERROR_CODE_H
#define _TOP_ERROR_CODE_H


/*�����붨��*/
#define LTOPErrSocketCreate		10		/*Create Socket Error*/

#define LTOPErrSocketConnOut	21		/*Socket Connect Error*/
#define LTOPErrSocketConnIn		22		/*Socket Connect Error*/

#define LTOPErrSocketRead		31		/*Socket Read(recv) Error*/
#define LTOPErrSocketWrite		32		/*Socket Write(send) Error*/

#define LTOPErrSocketBind		44		/*Socket Bind Error*/
#define LTOPErrSocketListen		45		/*Socket Listen Error*/
#define LTOPErrSocketClose		46		/*Socket Close Error*/

#define LTOPErrConfig			51		/*Config Error*/

#define LTOPErrXmlInvaild		61		/*Xml Doc Invalid*/


int glTopErrCode;
char gsTopErrMesg[1024];


/*�˺� �����ж��Ƿ���ҪDUMP*/
#define SOAP_ERROR_DUMP()              (glTopErrCode != 0)


#endif
