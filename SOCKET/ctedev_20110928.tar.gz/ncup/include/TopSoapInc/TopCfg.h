#ifndef __TOP_SOAP_CFG_H
#define __TOP_SOAP_CFG_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/shm.h>
#include <sys/stat.h>


#define TOPSOAP_CFG_PATH "TOPSOAP_CFG_PATH"



/*Cfg Handle*/
int Top_MakeDir( char *psPatch);
int Top_OpenCfgFile(char *sFilePath, char *sLogFile);
int Top_CloseCfgFile();
int Top_GetCfgItem(char *sSectionName, char *sItemName, char *sItemValue);

int TopSoap_OpenCfgFile(char *sFileName);
int GetHttpCfgItem(char *sItemName, char *sItemValue);
int GetSoapRootCfgItem(char *sItemName, char *sItemValue);
int GetSoapEnvelopCfgItem(char *sItemName, char *sItemValue);
int GetSoapHeaderCfgItem(char *sItemName, char *sItemValue);
int GetSoapBodyCfgItem(char *sItemName, char *sItemValue);
int GetXmlCfgItem(char *sItemName, char *sItemValue);
int GetVarietyCfgItem(char *sItemName, char *sItemValue);

#endif

