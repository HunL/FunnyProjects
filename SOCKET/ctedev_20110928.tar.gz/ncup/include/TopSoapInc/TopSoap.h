#ifndef __TOP_SOAP_H
#define __TOP_SOAP_H

#include <stdio.h> 
#include <stdlib.h> 
#include <errno.h> 
#include <string.h> 
#include <sys/types.h> 
#include <netinet/in.h> 
#include <sys/socket.h> 
#include <sys/wait.h> 
#include <sys/select.h>
#include <signal.h>
#include <sys/file.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <time.h>
#include <sys/times.h>
#include <sys/timeb.h>
#include <netdb.h>
#include <sys/ioctl.h>

#include "SrvDef.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "ErrCode.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "IpcInt.h"

#include "TopSoapInc/TopXml.h"
#include "TopSoapInc/TopHttp.h"
#include "TopSoapInc/TopUtilComm.h"
#include "TopSoapInc/TopErrCode.h"

#define  _SOAP_STATUS_INIT    9
#define  _SOAP_STATUS_SEND    8
#define  _SOAP_STATUS_RECV    7
#define  _SOAP_STATUS_SUCC    0
#define  _SOAP_STATUS_FAIL    -1

#define XMLNS_NAM_MAX_LENGTH    50
#define XMLNS_VAL_MAX_LENGTH    512
#define XMLNM_MAX_LENGTH        128


#define TOP_SOAP_REQ_ELEMENT 0
#define TOP_SOAP_RSP_ELEMENT 1

#define TOP_SOAP_REQ_NAME_SPACE 0
#define TOP_SOAP_RSP_NAME_SPACE 1 

#define TOP_SOAP_REQ_BODY 		1
#define TOP_SOAP_REQ_NO_BODY	0

#define TOP_SOAP_AUTO_PARSE	1		/*�Զ�������Ӧ����*/
#define TOP_SOAP_MANUAL_PARSE	0	/*�ֹ�������Ӧ����*/

/*typedef struct _top_soapenv_tag
{
	char			serviceName[128];
	char			serviceAddr[URL_MAX_PATH_LEN];
	TOP_XML_TREE	*reqxmlDoc;
	TOP_XML_TREE	*respxmlDoc;
	char			reqRootNS[128];
	char			reqEnvePath[128];
	char			reqHeadPath[128];
	char			reqBodyPath[128];
	char			respRootNS[128];
	char			respEnvePath[128];
	char			respHeadPath[128];
	char			respBodyPath[128];
	char			respFaultPath[128];
	char			reqxmlBuffer[REQUEST_BODY_LEN];
	char			respxmlBuffer[RESPONSE_BODY_LEN];
	int				httpStatus;
	char			httpStatusDesc[256];
	int				soapStatus;
}TopSOAPENV;*/

typedef struct _top_soapenv_tag
{
	char			serviceName[128];
	char			serviceAddr[URL_MAX_PATH_LEN];
	char			reqxmlBuffer[REQUEST_BODY_LEN];
	int				httpStatus;
	char			httpStatusDesc[256];
	int				soapStatus;
}TopSOAPENV;

#define BUF_SIZE 4096 

typedef  struct tag_msg_def 
{
  long msg_type;
  short msg_src;
  char msg_buf[BUF_SIZE];
} msg_def;


int SoapEnvInit(TopSOAPENV *env, char *sSoapCfgName, int iReqOrRsp);


/*******************************************************
 * ����һ���ڵ�
 *******************************************************/
int SoapBodyAddElement(TopSOAPENV *env, char *sXmlPath, char *sNodeValue, int isBodyRoot, int iReqOrRsp);

/*******************************************************
 * ���ýڵ��ֵ
 *******************************************************/
int SoapBodySetElementValue(TopSOAPENV *env, char *sXmlPath, char *sNodeValue, int iReqOrRsp);

/*******************************************************
 * ���ýڵ������
 *******************************************************/
int SoapBodySetElementAttr(TopSOAPENV *env, char *sXmlPath, char *sAttrName, char *sAttrValue, int iReqOrRsp);

/*******************************************************
 * ��ȡһ���ڵ��ֵ
 *******************************************************/
char *SoapBodyGetElement(TopSOAPENV *env, char *sXmlPath, int iReqOrRsp);

/*******************************************************
 * ��ȡһ���ڵ������
 *******************************************************/
int SoapBodyGetElementAttr(TopSOAPENV *env, char *sXmlPath, char *sAttrName, char *sAttrValue, int iReqOrRsp);

/*******************************************************
 * ��ȡһ���ڵ�
 *******************************************************/
int SoapBodyGetEleNode(TopSOAPENV *env, char *sXmlPath, TOP_XML_NODE **pEleNode, int iReqOrRsp);

/*******************************************************
 *��ȡ�ͻ�����������
 *******************************************************/
int SoapGetVarietyCfg(char *sItemName, char *sItemValue);

/* רΪ������ͬ���ڵ����20091005     ��֧�ִ�����ڵ���BODY�ڵ� */
TOP_XML_NODE *SoapBodyAddElement_R(TopSOAPENV *env, char *sXmlPath, char *sNodeValue, int iReqOrRsp);

/* רΪ������ͬ���ڵ����20091005 --  �����ӽڵ�     ��֧�ִ�����ڵ���BODY�ڵ� */
TOP_XML_NODE *SoapBodyAddChildElement(TOP_XML_NODE *pParentNode, char *sNodeName, char *sNodeValue, int iReqOrRsp);

/*******************************************************
 * ��ʼ��
 *******************************************************/
/*mod by brady.lee @ 2010-08-31
int CreateSoapEnv(TopSOAPENV *env);
*/
TopSOAPENV *CreateSoapEnv();

/*******************************************************
 * ����
 *******************************************************/
void SoapDestory(TopSOAPENV *env);

/*******************************************************
 * ׷��
 *******************************************************/
void SoapTrace(TopSOAPENV * soap);


/*************************************************************************************************
 *                                            SOAP CLIENT                                        *
 *************************************************************************************************/
/*******************************************************
 * �ͻ��˳�ʼ��
 *******************************************************/
/*mod by brady.lee @ 2010-08-31
int SoapClientInit(TopSOAPENV *env, char *sSoapCfgName);
*/
TopSOAPENV *SoapClientInit(char *sSoapCfgName);

/*******************************************************
 * �ͻ��˵���WebService
 *******************************************************/
int SoapCall(TopSOAPENV *env, char *sSoapCfgName, int isAutoParseRsp);


/*************************************************************************************************
 *                                        SOAP SINGLE SERVER                                     *
 *************************************************************************************************/

/*******************************************************
 * START UP THE SOAP SINGLE SERVER
 *******************************************************/
int TopSoapSServerStart(char *sWebMethodName);

/*******************************************************
 * SHUT DOWN THE SOAP SINGLE SERVER
 *******************************************************/
void TopSoapSServerStop();

/*******************************************************
 * �Ͽ��ͻ��˵�����
 *******************************************************/
void TopSoapSServerCloseClient();

/*******************************************************
 * ���ܿͻ��˵�����
 *******************************************************/
int TopSoapSServerAccept();

/*******************************************************
 * �ӿͻ��˽���������
 *******************************************************/
int TopSoapSServerResvMesg(TopSOAPENV *env);

/*******************************************************
 * ��ʼ����Ӧ����
 *******************************************************/
int SoapServerResponseInit(TopSOAPENV *env);

/*******************************************************
 * ��ͻ��˷�����Ӧ����
 *******************************************************/
int TopSoapSServerSendMesg(TopSOAPENV *env);


int Http_Replace(char *sHttpBuf);
int Http_Variety(char *sHttpBuf);

#endif /* __TOP_SOAP_H */
