#ifndef __TOP_UTIL_COMMON_H
#define __TOP_UTIL_COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>


/*****************************************************************
 * �ַ����滻 
 * Ϊ�˼�, Ҫ��strlen(sReplaceStr) <= strlen(sMatchStr)
 *****************************************************************/
int Top_ReplaceStr(char *sSrcBuf, int nBufSize, char *sMatchStr, char *sReplaceStr, int nLeftOrRight);


/*****************************************************************
 * Http�滻���û�
 *****************************************************************/
int Top_HttpReplaceStr(char *sStrBuf, int nBufSize);


#endif
