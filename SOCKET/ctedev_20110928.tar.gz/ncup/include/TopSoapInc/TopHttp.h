#ifndef __TOP_HTTP_COMMON_H
#define __TOP_HTTP_COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "TopSoapInc/TopSocket.h"
#include "TopSoapInc/TopCfg.h"


#define URL_MAX_HOST_LEN    		128
#define URL_MAX_PATH_LEN    		128
#define PAIR_KEY_LEN        		128
#define PAIR_VALUE_LEN      		128
#define REQUEST_BODY_LEN    		4096
#define RESPONSE_MAX_DESC_SIZE 		1024
#define RESPONSE_BODY_LEN   		4096
#define HTTP_HEAD_PAIR_NUM  		20

/*ÿ��recv�ĳ���*/
#define HTTP_PRE_RECV_LENGTH		4096

#define HTTP_REQUEST_POST  			1
#define PROTOCOL_HTTP      			1

#define HTTP_URI_ADDR_TYPE_IP 		"IP"
#define HTTP_URI_ADDR_TYPE_DOMAIN	"DOMAIN"

/*�����������Ĭ�϶˿�*/
#define HTTP_SVR_DEFAULT_PORT		80

/**
  The URL object. A representation of an URL like: [protocol]://[host]:[port]/[context]
*/
typedef struct _TOP_URL
{
	int			HttpProtocol;
	int			HttpServAddrType;				/*200901014--����ֵ��TopSocket.h�ж���*/
	char		HttpServAddr[URL_MAX_HOST_LEN];
	char		HttpServIP[URL_MAX_HOST_LEN];	/*200901014 - ���uri��host��ip��ַ(�����Ǵ�����ת��������)*/
	int			HttpServPort;
	char		HttpReqPath[URL_MAX_PATH_LEN];
} TopUrl;

/*��ֵ��*/
typedef struct _TOP_KEY_VALUE_PAIR
{
	char 			Key[PAIR_KEY_LEN];
	char 			Value[PAIR_VALUE_LEN];
} TopKeyValuePair;

typedef struct _TOP_HTTP_REQ_HEAD
{
	int			iHttpMethod;
	TopUrl			stHttpUrl;
	TopKeyValuePair		stReqHeadPairs[10];
	int 			iReqHeadPairNum;
} TopHttpReqHead;


typedef struct _TOP_HTTP_REQUEST
{
	TopHttpReqHead		stReqHead;
	char			sReqBody[REQUEST_BODY_LEN];
}TopHttpRequest;

typedef struct _TOP_HTTP_RSP_HEAD
{
	int			iHttpStatus;
	char			sHttpStatusDesc[RESPONSE_MAX_DESC_SIZE];
	TopKeyValuePair		stRspHeadPairs[10];
	int 			iRspHeadPairNum;
} TopHttpRspHead;

typedef struct _TOP_HTTP_RESPONSE
{
	TopHttpRspHead		stRspHead;
	char			sRspBody[RESPONSE_BODY_LEN];
} TopHttpResponse;




/********************************************Http Client********************************************/

/**************************************************************
 * ������������ȡIP��ַ
 **************************************************************/
int TopGetHostIpByDomain(char *sSvrDomainName, char *sSvrIpAddr, int nIpLen);


/**************************************************************
 * �ͻ�����������������󣬲�������Ӧ����
 **************************************************************/
int TopHttpCall(char *sSoapCfgName, TopHttpRequest *pstHttpReq, TopHttpResponse *pstHttpRsp);



/********************************************Http Server********************************************/

/**************************************************************
 * ����HTTP������
 **************************************************************/
int TopHttpServerStart(char *sSoapCfgName);

/**************************************************************
 * �ر�HTTP������
 **************************************************************/
void TopHttpServerStop();

/**************************************************************
 * ����һ��HTTP�ͻ��ˣ�����sockfd
 **************************************************************/
int TopHttpServerAccept();

/**************************************************************
 * �ӿͻ��˽���������
 **************************************************************/
int TopHttpServerRecvClient(TopHttpRequest *pstHttpClientReq);

/**************************************************************
 * ��ͻ��˷�����Ӧ����
 **************************************************************/
int TopHttpServerSendClient(TopHttpResponse *pstHttpClientRsp);

void TopHttpServerCloseClient();

/*Http Trace ׷��*/
void HttpRequestTrace(TopHttpRequest *pstHttpReq);
void HttpResponseTrace(TopHttpResponse *pstHttpRsp);


#endif
