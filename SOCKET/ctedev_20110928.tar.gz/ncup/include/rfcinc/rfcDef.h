#ifndef __RFCDEF_H
#define __RFCDEF_H


/********************************
***********������Ϣͷ************
*********************************/
typedef struct _RETURN
{
    char TYPE[2];
    char ID[21];
    char NUMBER[4];
    char MESSAGE[221];

}RETURN;


#endif
