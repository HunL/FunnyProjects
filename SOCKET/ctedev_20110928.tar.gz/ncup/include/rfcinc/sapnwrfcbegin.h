#include <stdlib.h>
#include <stdio.h>
#include "sapnwrfc.h"
#define RFC_FALSE -1
#define RFC_TRUE 1
RFC_CONNECTION_HANDLE connection;
RFC_ERROR_INFO errorInfo;
RFC_TRANSACTION_HANDLE transaction_handle;
RFC_TID tid;

void errorHandling(RFC_RC rc, SAP_UC description[], RFC_ERROR_INFO* errorInfo, RFC_CONNECTION_HANDLE connection);
int IRFC_OPEN();
int IRFC_CLOSE();
int IRFC_INIT_TRANSACTION();
int IRFC_SUBMIT();
int  IRFC_ROLLBACK();
