#ifndef __DMDEF_H
#define __DMDEF_H

#include <stdlib.h>
#include <stdio.h>
#include "sapnwrfc.h"
#include "rfcDef.h"


#define TBL_LINE  10



/********************
******PI*********
*********************/

/****PIADDON****/
typedef struct _PIADDON
{
	char SERVICE_CODE[21];
	char REF_PAY_NO[33];
	char POSTING_DATE[9];
	char SAFE_TRAN_CODE_S[11];
	char SAFE_TRAN_CODE_R[11];
	char SAFE_APP_CODE[31];
	char AGENT_TYPE[7];
	char AGENT_ID[61];
	char AGENT_NAME[61];
	char SYS_INDICATOR[11];
	char ACCOUNT[36];
	char CARD_NO[26];
	char TELLER_ID[13];
}PIADDON;
	
/***PAYMENTITEMS****/
typedef struct _PAYMENTITEMS
{
    char ITEM_NUMBER[9];             /*��ʱPI��*/
    char BANK_COUNTRY[4];            /*�������ڹ�����*/
    char BANK_CODE[16];              /*������*/
    char ACCOUNT_NUMBER[36];         /*�˺�*/
    char TRANS_CURRENCY[6];          /*���ױ���*/
    double AMOUNT_TRANS_CURRENCY;    /*���׽��*/
    char PAYMENT_MEDIUM[5];          /*����*/
    char TRNSTYPE[7];                /*TT��*/
	char ISCRED[2];
}PAYMENTITEMS;

/***********POSTEDITEMS*****/
typedef struct _POSTEDITEMS
{
    char ITEM_NUMBER[9];             /*��ʱPI��*/
    char ITEM_POSITION_NUMBER[4];    /*Temporary Number of the Payment Item Position*/
    char INTERNAL_ACCOUNT_ID[33];    /*�˺��ڲ�ID*/
    char INTERNAL_ITEM_ID[33];       /*PI�ڲ�ID*/
    char POSITION_NUMBER[4];         /*position number*/
    char DATE_POST[9];               /*��������*/
    char DATE_VALUE[9];              /*��Ϣ��*/
    char VALUE_DATE_TIME[7];         /*��Ϣʱ��*/
    char ACCOUNT_CURRENCY[6];        /*���ױ���*/
    char ACCOUNT_CURRENCY_ISO[4];    /*���ױ���*/
    double AMOUNT_ACCOUNT_CURRENCY;  /*���׽��*/
}POSTEDITEMS;

/******CHECKLOGPERITEM*********/
typedef struct _CHECKLOGPERITEM
{
    char TYPE[2];                   /*S,I,A,E*/
    char ID[21];                    /*��Ϣ�飬 ����138*/
    char NUMBER[4];                 /*��Ϣ˳���*/
}CHECKLOGPERITEM;
    
/***��������ṹ***/
typedef struct _DM_PI_SAVE_REQ
{
	PIADDON      stPiaddon;
    PAYMENTITEMS stPaymentitems;
}DM_PI_SAVE_REQ;

/***����Ӧ��ṹ***/
typedef struct _DM_PI_SAVE_RSP
{
    RETURN       stRet;
    POSTEDITEMS  stPosteditems;
    CHECKLOGPERITEM stCheckLogPerItem;
}DM_PI_SAVE_RSP;

/***ȡ�������ṹ***/
typedef struct _DM_PI_WITHDRAW_REQ
{
	PIADDON      stPiaddon;
    PAYMENTITEMS stPaymentitems;
}DM_PI_WITHDRAW_REQ;

/***ȡ���Ӧ��ṹ***/
typedef struct _DM_PI_WITHDRAW_RSP
{
    RETURN       stRet;
    POSTEDITEMS  stPosteditems;
    CHECKLOGPERITEM stCheckLogPerItem;
}DM_PI_WITHDRAW_RSP;

/*** PI ���� ***/
typedef struct _DM_PI_COMMON_REQ
{
	PIADDON      stPiaddon;
    PAYMENTITEMS stPaymentitems;
}DM_PI_COMMON_REQ;

/*** PI Ӧ��  ***/
typedef struct _DM_PI_COMMON_RSP
{
    RETURN       stRet;
    POSTEDITEMS  stPosteditems;
    CHECKLOGPERITEM stCheckLogPerItem;
}DM_PI_COMMON_RSP;

/***Ԥ��Ȩ��ɵ�����ṹ***/
typedef struct _DM_PI_AUTHCOMP_REQ
{
	PIADDON      stPiaddon;
    PAYMENTITEMS stPaymentitems;
	char         POSTINGLOCKITEM[13];
	char         FLGALL[2];
}DM_PI_AUTH_COMP_REQ;

/***Ԥ��Ȩ��ɵ�Ӧ��ṹ***/
typedef struct _DM_PI_AUTHCOMP_RSP
{
    RETURN       stRet;
    POSTEDITEMS  stPosteditems;
    CHECKLOGPERITEM stCheckLogPerItem;
}DM_PI_AUTH_COMP_RSP;


/****************************
*********  PO **************
***************************/

/*PAYMENTORDERHEADERIN*****/
typedef struct _PAYMENTORDERHEADERIN
{
    char MEDIUM[5]; /* ����*/
}PAYMENTORDERHEADERIN;

/**PAYMENTORDERSENDERITEMIN*/
typedef struct _PAYMENTORDERSENDERITEMIN
{
    char TRNSTYPE[7];         /*�����TT*/
    char TCUR[6];             /*����*/
    double T_AMOUNT;          /*�����*/
    char BANK_COUNTRY[4];     /*�������ڹ�����*/
    char BANK_CODE[16];       /*������*/
    char ACCOUNT_NUMBER[36];  /*������˺�*/
}PAYMENTORDERSENDERITEMIN;

/*PAYMENTORDERRECEIVEITEMSIN*/
typedef struct _PAYMENTORDERRECEIVERITEMSIN
{
    char TRNSTYPE[7];         /*�տ���TT*/
    char PAYMETHOD[5];        /*����*/
    char TCUR[6];             /*����*/
    double T_AMOUNT;          /*�տ���*/
    char BANK_COUNTRY[4];     /*�������ڹ�����*/
    char BANK_CODE[16];       /*������*/
    char ACCOUNT_NUMBER[36];  /*�տ����˺�*/
}PAYMENTORDERRECEIVERITEMSIN;

/**PAYMENTORDERSENDERITEMOUT**/
typedef struct _PAYMENTORDERSENDERITEMOUT
{
    char INTERNAL_ACCOUNT_ID[33];     /*�ڲ���ͬ��*/
    char ITEM_ID[33];                 /*PI��*/
}PAYMENTORDERSENDERITEMOUT;

/**����PO������ṹ**/
typedef struct _DM_PO_CREATE_REQ
{
    PAYMENTORDERHEADERIN stPOHeaderIn;
    PAYMENTORDERSENDERITEMIN stPOSenderitemIn;
    PAYMENTORDERRECEIVERITEMSIN stPOReceiveritemsIn;
}DM_PO_CREATE_REQ;

/*����PO��Ӧ��ṹ*/
typedef struct _DM_PO_CREATE_RSP
{
    RETURN stRet;
    PAYMENTORDERSENDERITEMOUT stPOSenderitemOut;
    char PAYMENTAREA[5];
    char PAYMENTORDERNUMBER[13];
}DM_PO_CREATE_RSP;

/********pi ����*******/
/*PI����������ṹ*/
typedef struct _DM_PI_CANCEL_REQ
{
    char INTERNALACCOUNTID[33];
    char ITEMID[33];
	char BUSINESS_PROCESS_TYPE_CODE[7];
	char BUSINESS_PROCESS_ID[37];
}DM_PI_CANCEL_REQ;

/***REVERSEPAYMENTITEM***PI������*/
typedef struct _REVERSEPAYMENTITEM
{
    char INTERNAL_ACCOUNT_ID[33];
    char INTERNAL_ITEM_ID[33];
}REVERSEPAYMENTITEM;

/*PI������Ӧ��ṹ*/
typedef struct _DM_PI_CANCEL_RSP
{
    RETURN stRet;
    REVERSEPAYMENTITEM stReversePI;
}DM_PI_CANCEL_RSP;    
     
/*PO����������ṹ*/
typedef struct _DM_PO_CANCEL_REQ
{
    char PAYMENTAREA[5];
    char PAYMENTORDERNUMBER[13];
}DM_PO_CANCEL_REQ;

/*PO������Ӧ��ṹ*/
typedef struct _DM_PO_CANCEL_RSP
{
    RETURN stRet;
}DM_PO_CANCEL_RSP;


/******************************
**********DM����***************
******************************/
/*********DOCCREATE***********/
typedef struct _DOCCREATE
{
    /***���ݽӿ�v1.8,ֻ��ACCOUNT_NUMBER,BANK_COUNTRY, BANK_CODE,EVENT_TYPE����Ϊ������**/
    char     INTERNAL_ACCOUNT_ID[33];
    char     ACCOUNT_NUMBER[36];
    char     BANK_COUNTRY[4];
    char     BANK_COUNTRY_ISO[3];
    char     BANK_CODE[16];
    char     ACCOUNT_CURRENCY[6];
    char     ACCOUNT_CURRENCY_ISO[4];
    char     ACCOUNT_USAGE[21];
    char     IBAN[35];
    char     ACCOUNTPOOLID[21];
    char     EVENT_TYPE[7];
    char     STATE[3];
    char     FLG_PARTNER_LOCK[2];
    char     PARTNER[11];
    char     SCHEDULED_START[9];
    char     SCHED_ACTIV_TO[9];
    char     FLG_WITHOUT_FEE[2];
    char     INTERNAL_ACCOUNT_ID_FEE[33];
    char     ACCOUNT_NUMBER_FEE[36];
    char     BANK_COUNTRY_FEE[4];
    char     BANK_COUNTRY_FEE_ISO[3];
    char     BANK_CODE_FEE[16];
    char     ACCOUNT_CURRENCY_FEE[6];
    char     ACCOUNT_CURRENCY_FEE_ISO[4];
    char     ACCOUNT_USAGE_FEE[21];
    char     IBAN_FEE[35];
    char     INITIATOR[11];
    char     REF_ANY1[21];
    char     REF_ANY2[21];
    char     FLG_WO_FEE_CARD[2];
    char     FLG_MIGRATION[2];
    char     HYOBJ_MACATG[7];
    char     HYOBJ_MATYPE[7];
    char     HYOBJ_MAID[17];
    char     FIRST_DATE[9];
    char     FIRST_TIME[7];
    char     FIRST_TEXT[51];
}DOCCREATE;

typedef struct _EXTENSIONIN
{
    char     STRUCTURE[31];
    char     VALUEPART1[241];
    char     VALUEPART2[241];
    char     VALUEPART3[241];
    char     VALUEPART4[241];     
}EXTENSIONIN;

typedef struct _ACCOUNTFEATURELOCK
{
    char     ACCOUNT_NUMBER[36];
    char     BANK_COUNTRY[4];
    char     BANK_COUNTRY_ISO[3];
    char     BANK_CODE[16];
    char     ACCOUNT_CURRENCY[6];
    char     ACCOUNT_CURRENCY_ISO[4];
    char     ACCOUNT_USAGE[21];
    char     IBAN[35];
    char     INTERNAL_ACCOUNT_ID[33];
    char     LOCK_ID[5];    
}ACCOUNTFEATURELOCK;

typedef struct _TRANSACTIONTYPELOCKS
{
    char    INTERNAL_ACCOUNT_ID[33];
    char    LOCK_ID[5];    
    double  LOCK_AMOUNT_FROM;
    double  LOCK_AMOUNT_TO;
    char    CURRENCY[6];
    char    CURRENCY_ISO[4];
    char    ACCOUNT_NUMBER[36];
    char    BANK_COUNTRY[4];
    char    BANK_COUNTRY_ISO[3];
    char    BANK_CODE[16];
    char    ACCOUNT_CURRENCY[6];
    char    ACCOUNT_CURRENCY_ISO[4];
    char    ACCOUNT_USAGE[21];
    char    IBAN[35];
}TRANSACTIONTYPELOCKS;

typedef struct _CARDLOCKS
{
    char    INTERNAL_CARD_ID[33];
    char    CARD_APPL[7];
    char    CARD_TYPE[7];
    char    CARD_NO[26];
    char    CARD_NO_ADD[5];
    char    VALID_TO_DATE[9];
    char    ACCOUNT_NUMBER[36];
    char    BANKLAND[4];
    char    BANKLAND_ISO[3];
    char    BANKKEY[16];
    char    ACCOUNT_CURRENCY[6];
    char    ACCOUNT_CURRENCY_ISO[4];
    char    ACCOUNT_USAGE[21];
    char    IBAN[35];
}CARDLOCKS;

typedef struct _CARDFEATURELOCKS
{
    char   INTERNAL_CARD_ID[33];
    char   CARD_TYPE[7];
    char   CARD_NO[26];
    char   CARD_NO_ADD[5];
    char   VALID_TO_DATE[9];
    char   ACCOUNT_NO[36];
    char   BANK_COUNTRY[4];
    char   BANK_COUNTRY_ISO[3];
    char   BANK_CODE[16];
    char   ACCOUNT_CURRENCY[6];
    char   ACCOUNT_CURRENCY_ISO[4];
    char   ACCOUNT_USAGE[21];
    char   IBAN[35];
    char   LOCKID[5];
}CARDFEATURELOCKS;

typedef struct _PRENOTE
{
    /***����DM�ӿ�v1.8��ֻ��PRENOTE_TYPE��AMOUNT��CURRENCYΪ���������Ϊ�����*/
    char    CONTRACT_INT[33];
    char    PRENOTE_TYPE[4];
    double    AMOUNT;
    char    CURRENCY[6];
    char    CURRENCY_ISO[4];
}PRENOTE;

typedef struct _PRENOTES
{
    char    INTERNAL_ACCOUNT_ID[33];
    char    PRENOTE_TYPE[4];
    double  AMOUNT;
    char    CURRENCY[6];
    char    CURRENCY_ISO[4];
    char    VERSNO[4];
    char    PRENOTE[41];
    char    ACCOUNT_NUMBER[36];
    char    BANK_COUNTRY[4];
    char    BANK_CODE[16];
}PRENOTES;

/***��������ṹ***/
typedef struct _DMACCTLOCKREQ
{
     DOCCREATE stDocCrt;
     char      PROCESSEXTENSION;
     PRENOTES  stPret; 
}DMACCTLOCKREQ;

/***������Ӧ�ṹ***/
typedef struct _DMACCTLOCKRSP
{
    char                   POSTINGLOCKITEM[13];
    char                   FLGCRITICALNOREACHED[2];
    EXTENSIONIN            stExtSion[TBL_LINE];
    EXTENSIONIN            stOutExtSion[TBL_LINE];
    RETURN                 stRet;
    ACCOUNTFEATURELOCK     stAcctLck[TBL_LINE];
    TRANSACTIONTYPELOCKS   stTranLck[TBL_LINE];
    CARDLOCKS              stCardLck[TBL_LINE];
    CARDFEATURELOCKS       stCardFeLck[TBL_LINE];
}DMACCTLOCKRSP;

/**********�޸Ľ������***************/
typedef struct _DOCCHANGE
{
    /**ֻ��STATEΪ������*/
    char      STATE[3];
    char      SCHEDULED_START[9];
    char      SCHED_ACTIV_TO[9];
    char      FLG_WITHOUT_FEE[2];
    char      INTERNAL_ACCOUNT_ID_FEE[33];
    char      ACCOUNT_NUMBER_FEE[36];
    char      BANK_COUNTRY_FEE[4];
    char      BANK_COUNTRY_FEE_ISO[3];
    char      BANK_CODE_FEE[16];
    char      ACCOUNT_CURRENCY_FEE[6];
    char      ACCOUNT_CURRENCY_FEE_ISO[4];
    char      ACCOUNT_USAGE_FEE[21];
    char      IBAN_FEE[35];
    char      REF_ANY1[21];
    char      REF_ANY2[21];
    char      FLG_WO_FEE_CARD[2];
    char      FLG_PARTNER_LOCK[2];
    char      FIRST_DATE[9];
    char      FIRST_TIME[7];
    char      FIRST_TEXT[51];
}DOCCHANGE;

typedef struct _DOCUMENT
{
    char      DOCNR[13];
    char      DOC_CATEGORY[5];
    char      INTERNAL_ACCOUNT_ID[33];
    char      ACCOUNT_NUMBER[36];
    char      BANK_COUNTRY[4];
    char      BANK_COUNTRY_ISO[3];
    char      BANK_CODE[16];
    char      EVENT_TYPE[7];
    char      ACCOUNT_CURRENCY[6];
    char      ACCOUNT_CURRENCY_ISO[4];
    char      ACCOUNT_USAGE[21];
    char      IBAN[35];
    char      ACCOUNTPOOLID[21];
    char      STATE[3];
    char      FLG_PARTNER_LOCK[2];
    char      PARTNER[11];
    char      CLOSING_ACTION[2];
    char      USER_CREATE[13];
    char      USER_CHANGE[13];
    char      TSTAMP_CREATE[22];
    char      TSTAMP_CHANGE[22];
    char      SCHEDULED_START[9];
    char      SCHED_ACTIV_TO[9];
    char      WF_START_DATE[9];
    char      CARD_LOCK_TYPE[2];
    char      FLG_PFORM_ACTIVE[2];
    char      FLG_FEE_CHARGED[2];
    char      FLG_WITHOUT_FEE[2];
    char      FLG_ACTIVE[2];
    char      INTERNAL_ACCOUNT_ID_FEE[33];
    char      ACCOUNT_NUMBER_FEE[36];
    char      BANK_COUNTRY_FEE[4];
    char      BANK_COUNTRY_FEE_ISO[3];
    char      BANK_CODE_FEE[16];
    char      ACCOUNT_CURRENCY_FEE[6];
    char      ACCOUNT_CURRENCYFEE_ISO[4];
    char      ACCOUNT_USAGE_FEE[21];
    char      IBAN_FEE[35];
    char      WORKITEM[13];
    char      WF_STATE[2];
    char      FLAG_CLOSE_AUTO[2];
    char      UPD_MODE[2];
    char      INITIATOR[11];
    char      REF_ANY1[21];
    char      REF_ANY2[21];
    char      FLG_WO_FEE_CARD[2];
    char      FLG_MIGRATION[2];
    char      CARD_LOCK_MODE[2];
    char      BUPA_LOCK_TYPE[2];
    char      ACCT_LOCK_TYPE[2];
    char      ARCHIVE_STATUS[2];
    char      ARCHIVE_FLUD[9];
    char      HYOBJ_MACATG[7];
    char      HYOBJ_MATYPE[7];
    char      HYOBJ_MAID[17];
    char      FIRST_DATE[9];
    char      FIRST_TIME[7];
    char      FIRST_TEXT[51];
}DOCUMENT;

typedef struct _EXTRANSACTIONTYPELOCKS
{
    char      LOCK_ID[5];
    double    LOCK_AMOUNT_FROM;
    double    LOCK_AMOUNT_TO;
    char      FLG_FIX[2];
    char      FLG_AMOUNT[2];
    char      CURRENCY[6];
    char      CURRENCY_ISO[3];
    char      ACCOUNT_NUMBER[36];
    char      BANK_COUNTRY[4];
    char      BANK_COUNTRY_ISO[3];
    char      BANK_CODE[16];
    char      ACCOUNT_CURRENCY[6];
    char      ACCOUNT_CURRENCY_ISO[4];
    char      ACCOUNT_USAGE[21];
    char      IBAN[35];
    char      INTERNAL_ACCOUNT_ID[33];
    char      UPD_MODE[2];    
}EXTRANSACTIONTYPELOCKS;


typedef struct _EXPRENOTES
{
    char     INTERNAL_ACCOUNT_ID[33];
    char     PRENOTE_TYPE[4];
    double   AMOUNT;
    char     CURRENCY[6];
    char     CURRENCY_ISO[4];
    char     VERSNO[4];
    char     PRENOTE[41];
    char     ACCOUNT_NUMBER[36];
    char     BANK_COUNTRY[4];
    char     BANK_COUNTRY_ISO[3];
    char     BANK_CODE[16];
    char     ACCOUNT_CURRENCY[6];
    char     ACCOUNT_CURRENCY_ISO[4];
    char     ACCOUNT_USAGE[21];
    char     IBAN[35];
    char     UPD_MODE[2];    
}EXPRENOTES;


/*�ⶳ������ṹ*/
typedef struct _DMACCTUNLOCKREQ
{
       char           POSTINGLOCKITEM[13];    /*Lock��*/
       char           DOCUMENTSTATE[3];       /*��״̬*/

}DMACCTUNLOCKREQ;

/*�ⶳ����Ӧ�ṹ*/
typedef struct _DMACCTUNLOCKRSP
{
    DOCUMENT                 stDoc;
    TRANSACTIONTYPELOCKS     stTranLck;
    PRENOTES                 stPret; 
    RETURN                   stRet;       
}DMACCTUNLOCKRSP;

/*�޸Ķ�������ṹ*/
typedef struct 
{
    char        POSTINGLOCKITEM[13];
    DOCCHANGE    stDocChg;
    PRENOTE    stPre;
}DM_ACCT_LOCK_CHG_REQ;

/*�޸Ķ�����Ӧ�ṹ*/
typedef struct 
{
    RETURN                    stRet;
    DOCUMENT                stDoc;
    EXTRANSACTIONTYPELOCKS    stExtranTypeLck;
    EXPRENOTES                stExPreNote;
}DM_ACCT_LOCK_CHG_RSP;

/*��ѯ�˻�������Ϣ������ṹ*/
typedef struct 
{
    char    POSTINGLOCKITEM[13];/*������*/
    
}DM_LOCK_QUERY_REQ;

/*��ѯ�˻�������Ϣ����Ӧ�ṹ*/
typedef struct 
{
    RETURN                   stRet;    
    DOCUMENT                 stDoc;
    TRANSACTIONTYPELOCKS     stTranLck;
    PRENOTES                 stPret; 
    
}DM_LOCK_QUERY_RSP;


/*******************************
 ******** ��ѯ���**************
 *****************************/
typedef struct _ACCOUNTIDENT
{
    char ACCOUNT_NUMBER[36];
    char BANK_COUNTRY[4];
    char BANK_CODE[16];
}ACCOUNTIDENT;

typedef struct _E_ACCT_KEY_FIGURES
{
    char    CN_CURRENCY[6];
    double  BALANCE;
    double  AVLB_AMOUNT;
}E_ACCT_KEY_FIGURES;

typedef struct _DM_ACCT_BALANCE_REQ
{
    ACCOUNTIDENT stAcctIdent;
}DM_ACCT_BALANCE_REQ;

typedef struct _DM_ACCT_BALANCE_RSP
{
    E_ACCT_KEY_FIGURES stAcctKeyFig;
    RETURN             stRet;
}DM_ACCT_BALANCE_RSP;

/**��ѯ���***/
int DM_ACCT_BALANCE(DM_ACCT_BALANCE_REQ *stDMAcctBalanceReq, DM_ACCT_BALANCE_RSP *stDMAcctBalanceRsp);

/**����DMϵͳ**/
int DM_CONNECT();

/**�Ͽ�DMϵͳ**/
int DM_DISCONNECT();

/**�����ύ**/
int DM_COMMIT();

/**����ع�**/
int DM_ROLLBACK();

/**DM �ʻ�����**/
int DM_ACCT_LOCK(DMACCTLOCKREQ *pstAcctLockReq, DMACCTLOCKRSP *pstAcctLockRsp );

/**DM �ʻ��ⶳ**/
int DM_ACCT_UNLOCK(DMACCTUNLOCKREQ *pstAcctUnLockReq, DMACCTUNLOCKRSP *pstAcctUnLockRsp );

/**DM �ʻ����� �޸�**/
int DM_ACCT_LOCK_CHG(DM_ACCT_LOCK_CHG_REQ *pLockChgReq,DM_ACCT_LOCK_CHG_RSP *pLockChgRsp);

/**DM �˻�������Ϣ��ѯ **/
int DM_ACCT_LOCK_DETAIL(DM_LOCK_QUERY_REQ *pLockDetailReq, DM_LOCK_QUERY_RSP *pLockDetailRsp );

/*
 *FUNCTION: DM_PI_SAVE
 *
 *    ���ܣ� 
 *           ���
 *    ������
 *            stPi_save_req   : ָ�� ��������ṹ ��ָ��
 *            stPi_save_rsp   : ָ�� ����Ӧ��ṹ ��ָ��
 *    ����ֵ��
 *          0  - success
 *         RETURN �е�MESSAGE NUMBER  - failure
 */
 
int DM_PI_SAVE( DM_PI_SAVE_REQ *stPi_save_req, DM_PI_SAVE_RSP *stPi_save_rsp);

/*
 * FUNCTION DM_PI_WITHDRAW
 *     ����:  ȡ��
 *
 *     ����:   
 *            stPi_withdraw_req   : ָ�� ȡ�������ṹ ��ָ��
 *            stPi_withdraw_rsp   : ָ�� ȡ���Ӧ��ṹ ��ָ�� 
 *    ����ֵ��
 *          0  - success
 *         RETURN �е�MESSAGE NUMBER  - failure
 *
 */
int DM_PI_WITHDRAW(DM_PI_WITHDRAW_REQ *stPi_withdraw_req, DM_PI_WITHDRAW_RSP *stPi_withdraw_rsp);

/*
 *FUNCTION : DM_PO_CREATE
 *
 *    ���� ����PAYMENT ORDER��PO�� ��׼ת��
 *    
 *    ������
 *         stPO_create_req :ָ�� ����PO������ṹ ��ָ��
 *         stPO_create_rsp :ָ�� ����PO��Ӧ��ṹ ��ָ��
 *    ����ֵ
 *         0  - success
 *     MESSAGE NUMBER - failure
 */
int DM_PO_CREATE(DM_PO_CREATE_REQ *stPO_create_req, DM_PO_CREATE_RSP *stPO_create_rsp);

/*FUNCTION DM_PI_CANCEL
 *      ���ܣ�����PI (PI����)
 *
 *      ����
 *            stDM_PI_cancel_req :ָ�� pi����������ṹDM_PI_CANCEL_REQ ��ָ��
 *            stDM_PI_cancel_rsp :ָ�� pi������Ӧ��ṹDM_PI_CANCEL_RSP ��ָ��
 *      ����ֵ
 * 
 *         0  - success
 *     MESSAGE NUMBER  - failure
 */
int DM_PI_CANCEL(DM_PI_CANCEL_REQ *stDM_PI_cancel_req, DM_PI_CANCEL_RSP *stDM_PI_cancel_rsp);

/*FUNCTION DM_PO_CANCEL
 *      ���ܣ�����PO(po����)
 *   
 *      ����
 *             stDM_PO_cancel_req : ָ�� struct DM_PO_CANCEL_REQ ��ָ��
 *             stDM_PO_cancel_rsp : ָ�� struct DM_PO_CANCEL_RSP ��ָ��  
 *      ����ֵ
 * 
 *         0  - success
 *     MESSAGE NUMBER  - failure
 */
int DM_PO_CANCEL( DM_PO_CANCEL_REQ *stDM_PO_cancel, DM_PO_CANCEL_RSP *stDM_PO_cancel_rsp);

#endif
