#ifndef SAPNWRFC_H
#define SAPNWRFC_H

#include <stdlib.h>
#include <stdio.h>
#ifndef SAPTYPE_H
#include "sapucx.h"
#endif /* SAPTYPE_H */
#include "sapuc.h"

#ifndef DECL_EXP
#   if defined(SAPonLIN) && defined(GCC_HIDDEN_VISIBILITY)
#     define DECL_EXP __attribute__((visibility("default")))
#   else
#     define DECL_EXP
#   endif
#endif /* DECL_EXP */

#ifndef SAP_API
#ifdef SAPonNT 
#     define SAP_API _stdcall
#else
#     define SAP_API
#endif /* SAPonNT */ 
#endif /* SAP_API */



#ifdef SAPonNT
#pragma warning (disable : 4267)  // disable warning: conversion from 'size_t' to 'const unsigned int'
#endif


typedef enum _RFCTYPE
{
  RFCTYPE_CHAR   = 0,		/* 1-byte or multibyte character, fixed size, blank padded */
  RFCTYPE_DATE   = 1,		/* date ( YYYYYMMDD ) */
  RFCTYPE_BCD    = 2,		/* packed number, any length between 1 and 16 bytes */
  RFCTYPE_TIME   = 3,		/* time (HHMMSS)  */
  RFCTYPE_BYTE   = 4,		/* raw data, binary, fixed length, zero padded.*/
  RFCTYPE_TABLE   = 5,		/* internal table */
  RFCTYPE_NUM    = 6,		/* digits, fixed size, leading '0' padded. */
  RFCTYPE_FLOAT  = 7,		/* floating point, double precission */
  RFCTYPE_INT    = 8,		/* 4-byte integer */
  RFCTYPE_INT2   = 9,		/* 2-byte integer, obsolete, not directly supported by ABAP/4 */
  RFCTYPE_INT1   = 10,		/* 1-byte integer, obsolete, not directly supported by ABAP/4 */
  RFCTYPE_NULL  = 14,		/* not supported data type. */
  RFCTYPE_STRUCTURE = 17,	/* ABAP structure */

  RFCTYPE_DECF16  = 23, /* RFCTYPE_WIRE_OBJECT = 23, / * object on the wire, internal use only  */
  RFCTYPE_DECF34  = 24, /* RFCTYPE_BLOB = 24,        / * binary large object, address must point to a RFC_BLOB structure */

  RFCTYPE_XMLDATA = 28,     /* variable-length, zero terminated string representing ABAP data with hierarchical structure (so-called TYPE2) as XML */
  RFCTYPE_STRING = 29,      /* variable-length, zero terminated string */
  RFCTYPE_XSTRING = 30,     /* variable-length raw string, length in bytes */

  _RFCTYPE_max_value      /* the max. value of RFCTYPEs */
}RFCTYPE;

/* enum RFC_RC, RFC return codes */
typedef enum _RFC_RC
{
    RFC_OK,					/* Everything O.K. Used by every function */
    RFC_COMMUNICATION_FAILURE,	/* Error in Network & Communication layer */
    RFC_LOGON_FAILURE,			/* Unable to logon to SAP system. Invalid password, user locked, etc */
    RFC_ABAP_RUNTIME_FAILURE,		/* SAP system runtime error (SYSTEM_FAILURE): Shortdump on the backend side */
    RFC_ABAP_MESSAGE,			/* The called function module raised an E-, A- or X-Message */
    RFC_ABAP_EXCEPTION,			/* The called function module raised an Exception (RAISE or MESSAGE ... RAISING) */
    RFC_CLOSED,				/* Connection closed by the other side */
    RFC_CANCELED,				/* An RFC connection has been canceled by the backend system */
    RFC_TIMEOUT,				/* Time out*/
    RFC_MEMORY_INSUFFICIENT,		/* Memory insufficient */
    RFC_VERSION_MISMATCH,		/* Version mismatch */
    RFC_INVALID_PROTOCOL,		/* The received data has an unsupported format */
    RFC_SERIALIZATION_FAILURE,		/* A problem while serializing or deserializing RFM parameters */
    RFC_INVALID_HANDLE,			/* An invalid handle was passed to an API call */
    RFC_RETRY,				/* RfcListenAndDispatch did not receive an RFC request during the timeout period */
    RFC_EXTERNAL_FAILURE,		/* Error in external custom code. (E.g in the function handlers or tRFC handlers.) Results in SYSTEM_FAILURE*/
    RFC_EXECUTED,				/* Inbound tRFC Call already executed (needs to be returned from RFC_ON_CHECK_TRANSACTION in case the TID is already known) */
    RFC_NOT_FOUND,			/* Function or structure definition not found (Metadata API) */
    RFC_NOT_SUPPORTED,			/* The operation is not supported on that handle */
    RFC_ILLEGAL_STATE,			/* The operation is not supported on that handle at the current point of time (e.g trying a callback on a server handle, while not in a call) */
    RFC_INVALID_PARAMETER,		/* An invalid parameter was passed to an API call, (e.g invalid name, type or length) */
    RFC_CODEPAGE_CONVERSION_FAILURE,/* Codepage conversion error */
    RFC_CONVERSION_FAILURE,		/* Error while converting a parameter to the correct data type */
    RFC_BUFFER_TOO_SMALL,		/* The given buffer was to small to hold the entire parameter. Data has been truncated. */
    RFC_TABLE_MOVE_BOF,			/* Trying to move the current position before the first row of the table */
    RFC_TABLE_MOVE_EOF,			/* Trying to move the current position after the last row of the table */
	RFC_UNKNOWN_ERROR			/* "Something" went wrong, but I don't know what... */
}RFC_RC;

typedef enum _RFC_ERROR_GROUP
{
    OK,                         /* OK */
	ABAP_APPLICATION_FAILURE,	/* ABAP Exception raised in ABAP function modules */
	ABAP_RUNTIME_FAILURE,		/* ABAP Message raised in ABAP function modules or in ABAP runtime of the backend (e.g Kernel) */
    LOGON_FAILURE,              /* Error message raised when logon fails */ 
	COMMUNICATION_FAILURE,		/* Problems with the network connection (or backend broke down and killed the connection) */
	EXTERNAL_RUNTIME_FAILURE,	/* Problems in the RFC runtime of the external program (i.e "this" library) */
	EXTERNAL_APPLICATION_FAILURE	/* Problems in the external program (e.g in the external server implementation) */
}RFC_ERROR_GROUP;

/* @struct RFC_ATTRIBUTES |
  * structure returned by <f RfcGetConnectionAttributes> describing
  * some information about this RFC connection.
  */
typedef struct _RFC_ATTRIBUTES
{
    SAP_UC dest[64+1];              /* RFC destination              */
    SAP_UC host[100+1];             /* Own host name                */
    SAP_UC partnerHost[100+1];     /* Partner host name            */
    SAP_UC sysNumber[2+1];             /* R/3 system number            */
    SAP_UC sysId[8+1];              /* R/3 system name              */
    SAP_UC client[3+1];             /* Client                       */
    SAP_UC user[12+1];              /* User                         */
    SAP_UC language[2+1];           /* Language                     */
    SAP_UC trace[1+1];                   /* ON/OFF: 'X'/' '              */
    SAP_UC isoLanguage[2+1];       /* 2-byte ISO-Language          */
    SAP_UC codepage[4+1];           /* Own code page                */
    SAP_UC partnerCodepage[4+1];   /* Partner code page            */
    SAP_UC rfcRole[1+1];           /* C/S: RFC Client / RFC Server */
    SAP_UC type[1+1];                    /* 2/3/E/R: R/2,R/3,Ext,Reg.Ext */
    SAP_UC partnerType[1+1];            /* 2/3/E/R: R/2,R/3,Ext,Reg.Ext */
    SAP_UC rel[4+1];               /* My system release            */
    SAP_UC partnerRel[4+1];        /* Partner system release       */
    SAP_UC kernelRel[4+1];         /* Partner kernel release       */
    SAP_UC cpicConvId[8 + 1];      /* CPI-C Conversation ID        */
    SAP_UC passwordState[1+1];     /* state of the password, not used */
    SAP_UC ownCodepagePcs[4+1];    /* Own codepage in partner's 
                                         *        point of view.          
                                         *        Differs from own_codepage 
                                         *        field only if UNICODE and 
                                         *        pcs flag are used 
                                         *        (see <f RfcOpenConnection>).
                                         *        Elsewhere this field is 
                                         *        identical to the 
                                         *        own_codepage field.
                                         */
    SAP_UC pcs[1+1];                /* Partner's Char Size (valid only in Unicode systems) 
                                         * 1/2:  Non Unicode/Unicode
                                         * This information is only valid after a succesfull call to the target system.
                                         */
    SAP_UC realPartnerCodepage[4+1];   /* Partner's real code page.
                                         * This information is valid only after a succesfull call
                                         */
    SAP_UC progName[128+1];          /* Name of the calling program
                                         */
    SAP_UC reserved[72];           /* reserved                       */
}RFC_ATTRIBUTES, *P_RFC_ATTRIBUTES;


/* RFC scalar data type mappings */
typedef SAP_UC         RFC_CHAR;     /* characters, RFCTYPE_CHAR        */
typedef RFC_CHAR       RFC_NUM;      /* digits, RFCTYPE_NUM          *//*SAPUNICODEOK_CHARTYPE*/
typedef SAP_RAW        RFC_BYTE;     /* raw data, RFCTYPE_BYTE       */   
typedef SAP_RAW        RFC_BCD;      /* packed numbers, RFCTYPE_BCD    *//*SAPUNICODEOK_CHARTYPE*/
typedef unsigned char  RFC_INT1;     /* 1 byte integer, RFCTYPE_INT1 */
typedef short          RFC_INT2;     /* 2 byte integer, RFCTYPE_INT2 */
typedef int			   RFC_INT;		 /* 2 byte integer, RFCTYPE_INT */
typedef double         RFC_FLOAT;    /* floating point, RFCTYPE_FLOAT*/
typedef RFC_CHAR       RFC_DATE[8];  /* date, RFCTYPE_DATE (YYYYMMDD)*/
typedef RFC_CHAR       RFC_TIME[6];  /* time, RFCTYPE_TIME (HHMMSS)  */
typedef DecFloat16     RFC_DECF16;   /* IEEE 754r decimal floating point 8 bytes  */
typedef DecFloat34     RFC_DECF34;   /* IEEE 754r decimal floating point 16 bytes  */


typedef RFC_CHAR RFC_ABAP_NAME[30+1]; /* name of abap function, function parameter or field in a structure. (\0 terminated) */
typedef RFC_CHAR RFC_PARAMETER_DEFVALUE[30+1]; /* default value of a function module parameter. (\0 terminated) */
typedef RFC_CHAR RFC_PARAMETER_TEXT[79+1]; /* parameter description for a function module parameter. (\0 terminated) */

typedef struct _RFC_TYPE_DESC_HANDLE {void* handle;} *RFC_TYPE_DESC_HANDLE;
typedef struct _RFC_FUNCTION_DESC_HANDLE {void* handle;} *RFC_FUNCTION_DESC_HANDLE;

typedef struct RFC_DATA_CONTAINER {void* handle;} *DATA_CONTAINER_HANDLE;
typedef DATA_CONTAINER_HANDLE RFC_STRUCTURE_HANDLE;
typedef DATA_CONTAINER_HANDLE RFC_FUNCTION_HANDLE;
typedef DATA_CONTAINER_HANDLE RFC_TABLE_HANDLE;

typedef struct _RFC_CONNECTION_HANDLE {void* handle;} *RFC_CONNECTION_HANDLE;
typedef RFC_CONNECTION_HANDLE RFC_HANDLE;
typedef struct _RFC_TRANSACTION_HANDLE {void* handle;} *RFC_TRANSACTION_HANDLE;

typedef struct _RFC_CONNECTION_PARAMETER
{
    const SAP_UC * name;
    const SAP_UC * value;
}RFC_CONNECTION_PARAMETER,*P_RFC_CONNECTION_PARAMETER;

typedef struct _RFC_FIELD_DESC
{
	RFC_ABAP_NAME	name;	/* field name, null terminated string */
	RFCTYPE		type;			/* field type */
    /*SAPUNICODEOK_MIXEDLEN*/
	unsigned	nucLength;		/* field length in bytes in a 1-byte-per-SAP_CHAR system */
    /*SAPUNICODEOK_MIXEDLEN*/
	unsigned	nucOffset;		/* field offset in bytes in a 1-byte-per-SAP_CHAR system */
    /*SAPUNICODEOK_MIXEDLEN*/
	unsigned	ucLength;		/* field length in bytes in a 2-byte-per-SAP_CHAR system */
    /*SAPUNICODEOK_MIXEDLEN*/
	unsigned	ucOffset;		/* field offset in bytes in a 2-byte-per-SAP_CHAR system */
	unsigned    decimals;
	RFC_TYPE_DESC_HANDLE typeDescHandle;             /* pointer to a RFC_STRUCTURE_DESC structure for the nestesd sub-type if the type field is RFCTYPE_STRUCTURE or RFCTYPE_TABLE */
    void* extendedDescription;
}RFC_FIELD_DESC,*P_RFC_FIELD_DESC;

typedef enum _RFC_DIRECTION
{
	RFC_IMPORT   = 0x01,                    /* import parameter, this is corresponding to ABAP IMPORTING parameter */
	RFC_EXPORT   = 0x02,                    /* export parameter, this is corresponding to ABAP EXPORTING parameter */
	RFC_CHANGING = RFC_IMPORT | RFC_EXPORT, /* import and export parameter, this is corresponding to ABAP CHANGING parameter */
	RFC_TABLES    = 0x04 | RFC_CHANGING      /* table parameter, this is corresponding to ABAP TABLES parameter */
}RFC_DIRECTION;

typedef struct _RFC_PARAMETER_DESC
{
	RFC_ABAP_NAME	name;			/* parameter name, null terminated string*/
	RFCTYPE		type;			   /* parameter type */
	RFC_DIRECTION direction;	/* if the parameter is a input, output or bi-directinal parameter */ 
	unsigned	nucLength;		/* parameter length in bytes in a 1-byte-per-SAP_CHAR system */	
	unsigned	ucLength;		/* parameter length in bytes in a 2-byte-per-SAP_CHAR system */
	unsigned    decimals;
	RFC_TYPE_DESC_HANDLE typeDescHandle;
    RFC_PARAMETER_DEFVALUE defaultValue;
	RFC_PARAMETER_TEXT parameterText;  /* null terminated string */
	RFC_BYTE     optional;             /* 1 is optional */
    void* extendedDescription;
}RFC_PARAMETER_DESC,*P_RFC_PARAMETER_DESC;

typedef struct _RFC_EXCEPTION_DESC
{
    SAP_UC key[128];                /* error key */
    SAP_UC message[512];            /* error message */
} RFC_EXCEPTION_DESC, *P__RFC_EXCEPTION_DESC;


#define RFC_TID_LN 24
typedef SAP_UC RFC_TID[RFC_TID_LN+1];

typedef struct _RFC_ERROR_INFO
{
    RFC_RC code;                    /* error code, should be the same as the API returns if the API has the return type of RFC_RC */
    RFC_ERROR_GROUP group;          /* error group */
    SAP_UC key[128];                /* error key */
    SAP_UC message[512];            /* error message */
    SAP_UC abapMsgClass[20+1];      /* ABAP message ID , or class */
    SAP_UC abapMsgType[1+1];        /* ABAP message type, e.g. 'E', 'A' or 'X' */
    RFC_NUM abapMsgNumber[3 + 1];   /* ABAP message number */
    SAP_UC abapMsgV1[50+1];         /* ABAP message details field 1, corresponds to SY-MSGV1 */ 
    SAP_UC abapMsgV2[50+1];         /* ABAP message details field 2, corresponds to SY-MSGV2 */ 
    SAP_UC abapMsgV3[50+1];         /* ABAP message details field 3, corresponds to SY-MSGV3 */ 
    SAP_UC abapMsgV4[50+1];         /* ABAP message details field 4, corresponds to SY-MSGV4 */ 
}RFC_ERROR_INFO;


#ifdef __cplusplus
extern "C"
{
#endif
	typedef RFC_RC (SAP_API* RFC_SERVER_FUNCTION)(RFC_CONNECTION_HANDLE rfcHandle, RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo);
	typedef RFC_RC (SAP_API* RFC_ON_CHECK_TRANSACTION)(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const *tid);
	typedef RFC_RC (SAP_API* RFC_ON_COMMIT_TRANSACTION)(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const *tid);
	typedef RFC_RC (SAP_API* RFC_ON_ROLLBACK_TRANSACTION)(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const *tid);
	typedef RFC_RC (SAP_API* RFC_ON_CONFIRM_TRANSACTION)(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const *tid);
	typedef RFC_RC (SAP_API* RFC_FUNC_DESC_CALLBACK)(SAP_UC const *functionName, RFC_ATTRIBUTES rfcAttributes, RFC_FUNCTION_DESC_HANDLE *funcDescHandle);

    /*************************************************************************/
    /*                                                                       */
    /*  General API & Utilities                                              */
    /*                                                                       */
    /*************************************************************************/
	DECL_EXP RFC_RC SAP_API RfcInit();
	DECL_EXP const SAP_UC* SAP_API RfcGetVersion(unsigned* majorVersion, unsigned* minorVersion, unsigned* patchLevel);

    /*************************************************************************/
    /*                                                                       */
    /*  Connection related API                                               */
    /*                                                                       */
    /*************************************************************************/

	/* Opens a client connection to an SAP System. The connectionParams may contain the following name-value pairs:
	 * client, user, passwd, lang, trace
	 * and additionally one of
	 * 1. Direct application server logon: ashost, sysnr.
	 * 2. Logon with load balancing: mshost, msserv, sysid, group.
	 *    msserv is only needed, if the service of the message server is
	 *    not defined as sapms<SYSID> in /etc/services.
	 *
	 * When logging on with SNC, user & passwd are to be replaced by
	 * snc_mode (0/1), snc_qop, snc_myname, snc_partnername, snc_lib
	 *
	 * When logging on with SSO Ticket, you can use mysapsso instead of
	 * user&passwd or mysapsso2 instead of passwd.
	 *
	 * Alternatively the connection parameters can be defined in the config file
	 * sapnwrfc.ini. In this case you just pass the parameter dest=... and the
	 * user credentials into RfcOpenConnection.
	 *
	 * If the logon was ok, RfcOpenConnection returns a client connection handle, which can be used in RfcInvoke.
	 * Otherwise the return value is NULL and errorInfo contains a detailed error description.
	 * errorInfo->code will be one of:
	 * RFC_INVALID_PARAMETER		One of the connectionParams was invalid
	 * RFC_COMMUNICATION_FAILURE		Something is wrong with the network or network settings
	 * RFC_LOGON_FAILURE			Invalid user/password/ticket/certificate
	 * RFC_ABAP_RUNTIME_FAILURE		Something is wrong with the R/3 backend
	 * RFC_MEMORY_INSUFFICIENT		A malloc failed when trying to allocate a temporary buffer
	 *
	 */
	DECL_EXP RFC_CONNECTION_HANDLE SAP_API RfcOpenConnection (RFC_CONNECTION_PARAMETER const * connectionParams, unsigned paramCount, RFC_ERROR_INFO* errorInfo);

	/* Registers a server connection at an SAP gateway. The connectionParams may contain the following name-value pairs:
	 * gwhost, gwserv, program_id, trace, and the parameters for SNC communication.
	 * Program_id corresponds to an RFC destination of type "T" in registration mode.
	 *
	 * If the connection registration was ok, RfcRegisterServer returns a server connection handle, which can be used in RfcListenAndDispatch.
	 * Otherwise the return value is NULL and errorInfo contains information similar to the RfcOpenConnection case.
	 */
	DECL_EXP RFC_CONNECTION_HANDLE SAP_API RfcRegisterServer (RFC_CONNECTION_PARAMETER const * connectionParams, unsigned paramCount, RFC_ERROR_INFO* errorInfo);

	/* This API needs to be called, if the server program is to be started by the R/3 application server.
	 * (RFC destination of type "T" in startup mode.)
	 * argc and argv are the inputs of the mainU function. The R/3 application server passes the correct command line to
	 * the program, when starting it up, so you only need to forwards these two parameters to RfcStartServer.
	 * connectionParams is optional and is only needed, if you want to add additional logon parameters to the
	 * ones coming from the command line, e.g for activating trace.
	 *
	 * Like RfcRegisterServer the function returns a server connection handle that can be used in RfcListenAndDispatch.
	 * The mechanism of this kind of RFC destination thus works as follows:
	 * 1. The R/3 application server opens a telnet connection to the host, where your server program is located, and
	 *    starts the program with the necessary logon parameters. (Or creates a child process, if the startup
	 *    method is "Start on application server".)
	 * 2. Your server program calls RfcStartServer, which opens an RFC connection back to the R/3 system.
	 * 3. The R/3 system then makes the function call over that RFC connection.
	 *
	 * The main differences "startup mode" compared to the "registration mode" are:
	 * Advantage: no logon parameters need to be maintained in the server program. (Unless you want to open
	 * an additional client connection for looking up function module metadata (RFC_FUNCTION_DESC_HANDLEs) in the
	 * R/3 DDIC.) 
	 * Disadvantage: every single function call creates a new process and a telnet connection in addition to
	 * the actual RFC connection.
	 */
	DECL_EXP RFC_CONNECTION_HANDLE SAP_API RfcStartServer (int argc, SAP_UC **argv, RFC_CONNECTION_PARAMETER const * connectionParams, unsigned paramCount, RFC_ERROR_INFO* errorInfo);
   
	/* Can be used to close client connections as well as server connections, when they are no longer needed.
	 */
	DECL_EXP RFC_RC SAP_API RfcCloseConnection (RFC_CONNECTION_HANDLE rfcHandle, RFC_ERROR_INFO* errorInfo);

	/* Reset the SAP server context ("user/session context") associated with the passed client connection.
	 */
	DECL_EXP RFC_RC SAP_API RfcResetServerContext(RFC_CONNECTION_HANDLE rfcHandle, RFC_ERROR_INFO* errorInfo);

	/* Ping the remote communication partner through the passed connection handle.
	 */
	DECL_EXP RFC_RC SAP_API RfcPing(RFC_CONNECTION_HANDLE rfcHandle, RFC_ERROR_INFO* errorInfo);

	/* Returns details about the current client or server connection. See documentation of RFC_ATTRIBUTES.
	 */
	DECL_EXP RFC_RC SAP_API RfcGetConnectionAttributes(RFC_CONNECTION_HANDLE rfcHandle, RFC_ATTRIBUTES *attr, RFC_ERROR_INFO* errorInfo);

	/* Gets partner's SSO ticket, if any. Can be used only with a server connection. 
	 */
	DECL_EXP RFC_RC SAP_API RfcGetPartnerSSOTicket(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC *ssoTicket, unsigned *length, RFC_ERROR_INFO* errorInfo);

	/* Gets partner's SNC name, if any. 
	 */
	DECL_EXP RFC_RC SAP_API RfcGetPartnerSNCName(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC *sncName, unsigned length, RFC_ERROR_INFO* errorInfo);

	/* Gets partner's SNC key, if any. 
	 */
	DECL_EXP RFC_RC SAP_API RfcGetPartnerSNCKey(RFC_CONNECTION_HANDLE rfcHandle, SAP_RAW *sncKey, unsigned *length, RFC_ERROR_INFO* errorInfo);

	/* Converts SNC name to SNC key. 
	 */
	DECL_EXP RFC_RC SAP_API RfcSNCNameToKey(SAP_UC const *sncLib, SAP_UC const *sncName, SAP_RAW *sncKey, unsigned *keyLength, RFC_ERROR_INFO* errorInfo);

	/* Converts SNC key to SNC name. 
	 */
	DECL_EXP RFC_RC SAP_API RfcSNCKeyToName(SAP_UC const *sncLib, SAP_RAW const *sncKey, unsigned keyLength ,SAP_UC *sncName, unsigned nameLength, RFC_ERROR_INFO* errorInfo);

	/* Listens on a server connection handle and waits for incoming RFC calls from the R/3 system.
	 * The mechanism for dispatching incoming function calls works as follows:
	 * First RfcListenAndDispatch checks, whether for the current combination of R/3 SystemID and function
	 * module name a callback function has been installed via RfcInstallServerFunction. If not, it checks,
	 * whether a global callback function has been installed via RfcInstallGenericServerFunction.
	 * If a callback function has been found, the RFC call will be dispatched to that function for processing,
	 * and RfcListenAndDispatch returns the return code of the callback function.
	 * Otherwise RfcListenAndDispatch returns a SYSTEM_FAILURE to the R/3 backend and the return code
	 * RFC_NOT_FOUND to the caller.
	 *
	 * In general the return codes of RfcListenAndDispatch have the following meaning:
	 * RFC_OK			A function call was processed successfully.
	 * RFC_RETRY		No function call came in within the specified timeout period. ("timeout" is given in seconds.)
	 * RFC_ABAP_EXCEPTION	A function call was processed and ended with a defined ABAP Exception, which has
	 *				been returned to the backend.
	 * In the above three cases "rfcHandle" is still open and can be used to listen for the next request.
	 *
	 * RFC_ABAP_MESSAGE	A function call was started to be processed, but was aborted with an ABAP A- or E-Message.
					The message parameters have been returned to the backend (and can be evaluated there via
					the sy-msgid, sy-msgtype, sy-msgno, sy-msgv1, ..., sy-msgv4 parameters).
	 * RFC_ABAP_RUNTIME_FAILURE	A function call was started to be processed, but was aborted with a "Rabax",
	 *				which has been returned to the backend.
	 * RFC_COMMUNICATION_FAILURE	The connection broke down while processing the function call. No response
	 *				has been sent to the backend.
	 * In these three cases the connection has been closed, so the "rfcHandle" needs to be refreshed via RfcRegisterServer.
	 *
	 * RFC_INVALID_HANDLE	"rfcHandle" is invalid or points to a connection that has already been closed.
	 */
	DECL_EXP RFC_RC SAP_API RfcListenAndDispatch (RFC_CONNECTION_HANDLE rfcHandle, int timeout, RFC_ERROR_INFO* errorInfo);

	/* Executes a function module in the backend system. The return codes have the following meaning:
	 * RFC_OK			The function call was executed successfully.
	 * RFC_ABAP_EXCEPTION	The function call was executed and ended with a defined ABAP Exception. The key of the
	 *				exception can be obtained from errorInfo->key.
	 * In the above two cases "rfcHandle" is still open and can be used to execute further function call.
	 *
	 * RFC_ABAP_MESSAGE	The function call was started to be processed, but was aborted with an ABAP Message.
					The message parameters can be obtained from errorInfo->abapMsgClass, errorInfo->abapMsgType,
					errorInfo->abapMsgNumber, errorInfo->abapMsgV1, ..., errorInfo->abapMsgV4.
	 * RFC_ABAP_RUNTIME_FAILURE	The function call was started to be processed, but was aborted with a SYSTEM_FAILURE
	 *				(e.g division by zero, unhandled exception, etc in the backend system).
	 *				Details can be obtained from errorInfo->message.
	 * RFC_COMMUNICATION_FAILURE	The connection broke down while processing the function call.
	 *				Details can be obtained from errorInfo->message.
	 * In these three cases the connection has been closed, so the "rfcHandle" needs to be refreshed via RfcOpenConnection.
	 *
	 * RFC_INVALID_HANDLE	"rfcHandle" is invalid or points to a connection that has already been closed.
	 */
	DECL_EXP RFC_RC SAP_API RfcInvoke (RFC_CONNECTION_HANDLE rfcHandle, RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo);

    /*************************************************************************/
    /*                                                                       */
    /*  Transaction (tRFC & qRFC) API                                        */
    /*                                                                       */
    /*************************************************************************/

	/* Retrieves a unique 24-digit transaction ID from the backend.
	 */
	DECL_EXP RFC_RC SAP_API RfcGetTransactionID (RFC_CONNECTION_HANDLE rfcHandle, RFC_TID tid, RFC_ERROR_INFO* errorInfo);

	/* Creates a container for executing a (multi-step) transactional call.
	 * If queueName is NULL, tRFC will be used, otherwise qRFC.
	 */
	DECL_EXP RFC_TRANSACTION_HANDLE SAP_API RfcCreateTransaction(RFC_CONNECTION_HANDLE rfcHandle, RFC_TID tid, SAP_UC const *queueName, RFC_ERROR_INFO* errorInfo);

	/* Adds a function module call to a transaction. Can be used multiple times on one tHandle.
	 */
	DECL_EXP RFC_RC SAP_API RfcInvokeInTransaction (RFC_TRANSACTION_HANDLE tHandle, RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo);

	/* Executes all function modules in the backend system, that have accumulated in the transaction so far.
	 * This step can be repeated until it finally succeeds (RFC_OK). The transaction handling in the backend
	 * system protects against duplicates.
	 */
	DECL_EXP RFC_RC SAP_API RfcSubmitTransaction(RFC_TRANSACTION_HANDLE tHandle, RFC_ERROR_INFO* errorInfo);

	/* After RfcSubmitTransaction has finally succeeded, call RfcConfirmTransaction to clean up the
	 * transaction handling table in the backend.
	 * Attention: after this call the backend is no longer protected against this TID. So another
	 * RfcSubmitTransaction would result in a duplicate.
	 */
	DECL_EXP RFC_RC SAP_API RfcConfirmTransaction(RFC_TRANSACTION_HANDLE tHandle, RFC_ERROR_INFO* errorInfo);

	/* Releases the memory of the transaction container.
	 */
	DECL_EXP RFC_RC SAP_API RfcDestroyTransaction(RFC_TRANSACTION_HANDLE tHandle, RFC_ERROR_INFO* errorInfo);


    /*************************************************************************/
    /*                                                                       */
    /*  Installation of Callback Functions for RFC Server                    */
    /*                                                                       */
    /*************************************************************************/

	/* Installs a callback function of type RFC_SERVER_FUNCTION, which will be triggered when a request for the function
	 * module corresponding to funcDescHandle comes in from the R/3 system corresponding to sysId.
	 * The main inputs of RFC_SERVER_FUNCTION are as follows:
	 * RFC_CONNECTION_HANDLE		A connection handle, which can be used to query logon information about
	 *						the current (backend) user or to make callbacks into the backend.
	 * RFC_FUNCTION_HANDLE			A data container that represents the current function call. Read the importing
	 *						parameters, which came from the backend, from this container via the RfcGetX functions and
	 *						write the exporting parameters, which are to be returned to the backend, into this container
	 *						using the RfcSetX functions.
	 *						The memory of that container is automatically released by the RFC Runtime after the
	 *						RFC_SERVER_FUNCTION returns.
	 * RFC_ERROR_INFO*			If you want to return an ABAP Exception or ABAP Message to the backend, fill the
	 *						parameters of that container and return RFC_ABAP_EXCEPTION or RFC_ABAP_MESSAGE from
	 *						your RFC_SERVER_FUNCTION implementation.
	 *						If you want to return a SYSTEM_FAILURE to the backend, fill the message parameter of
	 *						this container and return RFC_EXTERNAL_FAILURE from your RFC_SERVER_FUNCTION implementation.
	 * If your RFC_SERVER_FUNCTION implementation processed the function call successfully, you should return RFC_OK.
	 *
	 * If you pass NULL as "sysId", the serverFunction will be used for calls from any backend system.
	 */
	DECL_EXP RFC_RC SAP_API RfcInstallServerFunction(SAP_UC const *sysId, RFC_FUNCTION_DESC_HANDLE funcDescHandle,RFC_SERVER_FUNCTION serverFunction, RFC_ERROR_INFO* errorInfo);

	/* Installs a generic callback function of type RFC_SERVER_FUNCTION. This callback will be called by the
	 * RFC Runtime, whenever a combination of R/3 System ID & function module name comes in, for which no
	 * matching callback function has been installed via RfcInstallServerFunction.
	 * In addition to the handler function you need to provide a second callback function: RFC_FUNC_DESC_CALLBACK.
	 * This callback will be called to obtain a RFC_FUNCTION_DESC_HANDLE for the current function module from you.
	 * So this function either needs to return hardcoded meta data or needs to be able to perform a DDIC lookup
	 * using a valid client connection and RfcGetFunctionDesc
	 */
    DECL_EXP RFC_RC SAP_API RfcInstallGenericServerFunction(RFC_SERVER_FUNCTION serverFunction, RFC_FUNC_DESC_CALLBACK funcDescProvider, RFC_ERROR_INFO* errorInfo);

	/* Installs the necessary callback function for being able to process incoming tRFC/qRFC calls.
	 * 1. The RFC_ON_CHECK_TRANSACTION function is called when a local transaction is starting. Since a transactional 
	 *    RFC call can be issued many times by the client system, the function is responsible for storing the transaction ID
	 *    in permanent storage. The return value should be one of the following:
	 *    RFC_OK       -- Transaction ID stored, transaction can be started.
	 *    RFC_EXECUTED -- This transaction has already been processed successfully in an earlier attempt. Skip the execution now.
	 *    RFC_EXTERNAL_FAILURE  -- Currently unable to access my permanent storage. Raise an exception in the sending system, so
	 *                    that the sending system will try to resend the transaction at a later time.
	 * 2. The next step will be the execution of the RFC_SERVER_FUNCTION for that particular function module.
	 * 3. Depending on the result of the RFC_SERVER_FUNCTION implementation, next one of RFC_ON_COMMIT_TRANSACTION
	 *    or RFC_ON_ROLLBACK_TRANSACTION is called. Do a COMMIT WORK or ROLLBACK WORK here, so that the changes, which
	 *    the RFC_SERVER_FUNCTION made, are now either persisted or rolled back.
	 * 4. In the end RFC_ON_CONFIRM_TRANSACTION will be called. All information stored about that transaction can now be
	 *    discarded by the server, as it no longer needs to protect itself against duplicates.
	 *    In general this function can be used to delete the transaction ID from permanent storage.
	 *
	 * If you pass NULL as "sysId", the transaction handlers will be used for tRFC calls from any backend system.
	 */
	DECL_EXP RFC_RC SAP_API RfcInstallTransactionHandlers (SAP_UC const *sysId, RFC_ON_CHECK_TRANSACTION onCheckFunction,
                                              RFC_ON_COMMIT_TRANSACTION onCommitFunction, RFC_ON_ROLLBACK_TRANSACTION onRollbackFunction,
                                              RFC_ON_CONFIRM_TRANSACTION onConfirmFunction, RFC_ERROR_INFO* errorInfo);


    /*************************************************************************/
    /*                                                                       */
    /*  Data container API (Function objects, structure & tables)            */
    /*                                                                       */
    /*************************************************************************/

	/* Creates a data container that can be used to execute function calls in the backend via RfcInvoke.
	 * The importing parameters can be set using the RfcSetX functions. After the RfcInvoke call returned
	 * successfully, the exporting parameters can be read from this data container via the RfcGetX functions.
	 */
    DECL_EXP RFC_FUNCTION_HANDLE SAP_API RfcCreateFunction(RFC_FUNCTION_DESC_HANDLE funcDescHandle, RFC_ERROR_INFO* errorInfo);

	/* Releases all memory used by the data container.
	 * Be careful: if you have obtained a handle to a structure or table parameter of that function module
	 * (RFC_STRUCTURE_HANDLE or RFC_TABLE_HANDLE), that handle will be invalid afterwards, as that memory
	 * has been released as well!
	 */
	DECL_EXP RFC_RC SAP_API RfcDestroyFunction(RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* errorInfo);

	/* Allows to deactivate certain parameters in the function module interface.
	 * This is particularly useful for BAPIs which have many large tables, in which you are not interested.
	 * Deactivate those and leave only those tables active, in which you are interested. This reduces
	 * network traffic considerably.
	 */
    DECL_EXP RFC_RC SAP_API RfcSetParameterActive(RFC_FUNCTION_HANDLE funcHandle, SAP_UC const* paramName, int isActive, RFC_ERROR_INFO* info);

	/* Query if a parameter is active. 
	 */
    DECL_EXP RFC_RC SAP_API RfcIsParameterActive(RFC_FUNCTION_HANDLE funcHandle, SAP_UC const* paramName, int *isActive, RFC_ERROR_INFO* info);

	/* API for allocating, cloning and releasing structures.
	 */
	DECL_EXP RFC_STRUCTURE_HANDLE SAP_API RfcCreateStructure(RFC_TYPE_DESC_HANDLE typeDescHandle, RFC_ERROR_INFO* errorInfo);
    DECL_EXP RFC_STRUCTURE_HANDLE SAP_API RfcCloneStructure(RFC_STRUCTURE_HANDLE srcStructureHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcDestroyStructure(RFC_STRUCTURE_HANDLE structHandle, RFC_ERROR_INFO* errorInfo);

	/* API for allocating, cloning and releasing tables.
	 * Be careful: if you still have a reference to a certain table line (an RFC_STRUCTURE_HANDLE you got
	 * from RfcGetCurrentRow/RfcAppendNewRow/RfcInsertNewRow), this handle will be invalid after RfcDestroyTable!
	 */
	DECL_EXP RFC_TABLE_HANDLE SAP_API RfcCreateTable(RFC_TYPE_DESC_HANDLE typeDescHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_TABLE_HANDLE SAP_API RfcCloneTable(RFC_TABLE_HANDLE srcTableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcDestroyTable(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);

	/* API for navigating through a table, reading lines and inserting new lines.
	 * Should be self-explanatory.
	 */
	DECL_EXP RFC_STRUCTURE_HANDLE SAP_API RfcGetCurrentRow(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_STRUCTURE_HANDLE SAP_API RfcAppendNewRow(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_STRUCTURE_HANDLE SAP_API RfcInsertNewRow(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcAppendRow(RFC_TABLE_HANDLE tableHandle, RFC_STRUCTURE_HANDLE structHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcInsertRow(RFC_TABLE_HANDLE tableHandle, RFC_STRUCTURE_HANDLE structHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcDeleteCurrentRow(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcDeleteAllRows(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcMoveToFirstRow(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcMoveToLastRow(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcMoveToNextRow(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcMoveToPreviousRow(RFC_TABLE_HANDLE tableHandle, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcMoveTo(RFC_TABLE_HANDLE tableHandle, unsigned index, RFC_ERROR_INFO* errorInfo);
	DECL_EXP RFC_RC SAP_API RfcGetRowCount(RFC_TABLE_HANDLE tableHandle, unsigned* rowCount, RFC_ERROR_INFO* errorInfo);


    /*************************************************************************
     *
     *  API for accessing the fields of a data container
     *
	 * API for reading the exporting parameters of an RFC_FUNCTION_HANDLE in the client case,
	 * the importing parameters of an RFC_FUNCTION_HANDLE in the server case
	 * and the fields of an RFC_STRUCTURE_HANDLE or RFC_TABLE_HANDLE.
     *************************************************************************/

    /* Returns the value of the specified field as char array.               */
    /* The charBuffer will be filled by string representation. The remaining */
    /* places in the buffer will be filled with trailing spaces. In case the */
    /* buffer is too small, the function will return RFC_BUFFER_TOO_SMALL.   */
    /* The result will not be zero-terminated.                               */
    /* Supported field types:                                                */
    /* RFCTYPE_CHAR                                                          */
    /* RFCTYPE_STRING                                                        */
    /* RFCTYPE_NUM                                                           */
    /* RFCTYPE_DATE                                                          */
    /* RFCTYPE_TIME                                                          */
    /* RFCTYPE_INTx                                                          */
    /* RFCTYPE_FLOAT                                                         */
    /* RFCTYPE_BCD                                                           */
    /* RFCTYPE_DECFxx                                                        */
    /* RFCTYPE_BYTE                                                          */
    /* RFCTYPE_XSTRING                                                       */
    /* Note: If the target field has type BYTE or XSTRING, the bytes will be */
    /* converted to a hex encoded string representation.                     */
	DECL_EXP RFC_RC SAP_API RfcGetChars    (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_CHAR *charBuffer, unsigned bufferLength, RFC_ERROR_INFO* info);

    /* Returns the value of the specified field as num-char array.           */
    /* The charBuffer will be filled by string representation. The remaining */
    /* places in the buffer will be filled with leading zero digits. In case */
    /* the buffer is too small, the function will return                     */
    /* RFC_BUFFER_TOO_SMALL.                                                 */
    /* Supported field types:                                                */
    /* RFCTYPE_CHAR                                                          */
    /* RFCTYPE_STRING                                                        */
    /* RFCTYPE_NUM                                                           */
    /* RFCTYPE_DATE                                                          */
    /* RFCTYPE_TIME                                                          */
    /* RFCTYPE_INTx                                                          */
	DECL_EXP RFC_RC SAP_API RfcGetNum      (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_NUM *charBuffer, unsigned bufferLength, RFC_ERROR_INFO* info);

    /* Supported type is RFCTYPE_DATE only                                   */
	DECL_EXP RFC_RC SAP_API RfcGetDate     (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_DATE emptyDate, RFC_ERROR_INFO* info);

    /* Supported type is RFCTYPE_TIME only                                   */
	DECL_EXP RFC_RC SAP_API RfcGetTime     (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_TIME emptyTime, RFC_ERROR_INFO* info);

    /* Returns the value of the specified field as null-terminated string.   */
    /* The charBuffer will be filled by string representation. In case the   */
    /* buffer is too small, e.g. no place for string termination,            */
    /* the function will return RFC_BUFFER_TOO_SMALL. stringLength contains  */
    /* the number of written characters, or the required number of characters*/
	/* in case RFC_BUFFER_TOO_SMALL was thrown.                              */
	/* The result will be zero-terminated.                                   */
    /* Supported field types:                                                */
    /* RFCTYPE_CHAR                                                          */
    /* RFCTYPE_STRING                                                        */
    /* RFCTYPE_NUM                                                           */
    /* RFCTYPE_DATE                                                          */
    /* RFCTYPE_TIME                                                          */
    /* RFCTYPE_INTx                                                          */
    /* RFCTYPE_FLOAT                                                         */
    /* RFCTYPE_BCD                                                           */
    /* RFCTYPE_DECFxx                                                        */
    /* RFCTYPE_BYTE                                                          */
    /* RFCTYPE_XSTRING                                                       */
    /* Note: If the target field has type BYTE or XSTRING, the bytes will be */
    /* converted to a hex encoded string representation.                     */
	DECL_EXP RFC_RC SAP_API RfcGetString   (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, SAP_UC *stringBuffer, unsigned bufferLength, unsigned* stringLength, RFC_ERROR_INFO* info);

    /* Returns the value of the specified field as byte array.               */
    /* In case the buffer is too small, the function will return             */
    /* RFC_BUFFER_TOO_SMALL. In case the buffer is longer than the field,    */
    /* it will be filled with 0x00 values.                                   */
    /* Supported field types:                                                */
    /* RFCTYPE_BYTE                                                          */
    /* RFCTYPE_XSTRING                                                       */
    /* RFCTYPE_CHAR                                                          */
    /* RFCTYPE_NUM                                                           */
    /* RFCTYPE_DATE                                                          */
    /* RFCTYPE_TIME                                                          */
    /* RFCTYPE_INTx                                                          */
    /* RFCTYPE_FLOAT                                                         */
    /* RFCTYPE_BCD                                                           */
    /* RFCTYPE_DECFxx                                                        */
	DECL_EXP RFC_RC SAP_API RfcGetBytes    (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, SAP_RAW *byteBuffer, unsigned bufferLength, RFC_ERROR_INFO* info);

    /* Returns the value of the specified field as byte array.               */
    /* In case the buffer is too small, the function will return             */
    /* RFC_BUFFER_TOO_SMALL. xstringLength contains the number of written    */
    /* bytes, or the required number of bytes in case RFC_BUFFER_TOO_SMALL   */
	/* was thrown.                                                           */
    /* The remaining buffer won't be set and can contain random values.      */
    /* Supported field types:                                                */
    /* RFCTYPE_BYTE                                                          */
    /* RFCTYPE_XSTRING                                                       */
    /* RFCTYPE_CHAR                                                          */
    /* RFCTYPE_NUM                                                           */
    /* RFCTYPE_DATE                                                          */
    /* RFCTYPE_TIME                                                          */
    /* RFCTYPE_INTx                                                          */
    /* RFCTYPE_FLOAT                                                         */
    /* RFCTYPE_BCD                                                           */
    /* RFCTYPE_DECFxx                                                        */
	DECL_EXP RFC_RC SAP_API RfcGetXString  (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, SAP_RAW *byteBuffer, unsigned bufferLength, unsigned* xstringLength, RFC_ERROR_INFO* info);

    /* Returns the value of the specified field as RFC_INT.                  */
    /* Note: if the field is of type RFCTYPE_BYTE, this function interpretes */
    /* the bytes in big-endian byte order when converting them to int.       */
    /* Supported field types:                                                */
    /* RFCTYPE_INT                                                           */
    /* RFCTYPE_INT2                                                          */
    /* RFCTYPE_INT1                                                          */
    /* RFCTYPE_BYTE     are treated as big endian sequence of an int         */
    /* RFCTYPE_XSTRING  are treated as big endian sequence of an int         */
    /* RFCTYPE_CHAR                                                          */
    /* RFCTYPE_NUM                                                           */
	DECL_EXP RFC_RC SAP_API RfcGetInt      (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_INT  *value, RFC_ERROR_INFO* info);

    /* Supported field types:                                                */
    /* RFCTYPE_INT                                                           */
    /* RFCTYPE_INT2                                                          */
    /* RFCTYPE_INT1                                                          */
    /* RFCTYPE_BYTE     are treated as big endian sequence of an int         */
    /* RFCTYPE_XSTRING  are treated as big endian sequence of an int         */
	DECL_EXP RFC_RC SAP_API RfcGetInt1     (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_INT1 *value, RFC_ERROR_INFO* info);

    /* Supported field types:                                                */
    /* RFCTYPE_INT                                                           */
    /* RFCTYPE_INT2                                                          */
    /* RFCTYPE_INT1                                                          */
    /* RFCTYPE_BYTE     are treated as big endian sequence of an int         */
    /* RFCTYPE_XSTRING  are treated as big endian sequence of an int         */
	DECL_EXP RFC_RC SAP_API RfcGetInt2     (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_INT2 *value, RFC_ERROR_INFO* info);

    /* Supported field types: */
    /* RFCTYPE_FLOAT          */
    /* RFCTYPE_BCD          */
	DECL_EXP RFC_RC SAP_API RfcGetFloat    (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_FLOAT *value, RFC_ERROR_INFO* info);

    /* Supported field types: */
    /* RFCTYPE_DECF16         */
    /* RFCTYPE_DECF34         */
    /* RFCTYPE_FLOAT          */
    /* RFCTYPE_BCD            */
    /* RFCTYPE_INT            */
    /* RFCTYPE_INT2           */
    /* RFCTYPE_INT1           */
    /* RFCTYPE_CHAR           */
    /* RFCTYPE_BYTE           */
	DECL_EXP RFC_RC SAP_API RfcGetDecF16   (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_DECF16 *value, RFC_ERROR_INFO* info);

    /* Supported field types: */
    /* RFCTYPE_DECF16         */
    /* RFCTYPE_DECF34         */
    /* RFCTYPE_FLOAT          */
    /* RFCTYPE_BCD            */
    /* RFCTYPE_INT            */
    /* RFCTYPE_INT2           */
    /* RFCTYPE_INT1           */
    /* RFCTYPE_CHAR           */
    /* RFCTYPE_BYTE           */
	DECL_EXP RFC_RC SAP_API RfcGetDecF34   (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_DECF34 *value, RFC_ERROR_INFO* info);

    /* Supported type is RFCTYPE_STRUCTURE only                              */
	DECL_EXP RFC_RC SAP_API RfcGetStructure(DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_STRUCTURE_HANDLE* structHandle, RFC_ERROR_INFO* info);

    /* Supported type is RFCTYPE_TTABLE only                                 */
	DECL_EXP RFC_RC SAP_API RfcGetTable    (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, RFC_TABLE_HANDLE* tableHandle, RFC_ERROR_INFO* info);

	/* Returns the length of the value of a STRING or XSTRING parameter, so an appropriately sized
	 * buffer can be allocated before reading the value.
	 */
	DECL_EXP RFC_RC SAP_API RfcGetStringLength(DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, unsigned* stringLength, RFC_ERROR_INFO* info);



	/*************************************************************************
	 *
	 * API for setting the importing parameters of an RFC_FUNCTION_HANDLE in the client case,
	 * the exporting parameters of an RFC_FUNCTION_HANDLE in the server case
	 * and the subfields of an RFC_STRUCTURE_HANDLE or RFC_TABLE_HANDLE.
	 *
	 *************************************************************************/

    /* Sets the given char value (charValue/valueLength) into the field.     */
    /* Supported field types:                                                */
    /* RFCTYPE_CHAR                                                          */
    /* RFCTYPE_STRING                                                        */
    /* RFCTYPE_NUM                                                           */
    /* RFCTYPE_DATE                                                          */
    /* RFCTYPE_TIME                                                          */
    /* RFCTYPE_INTx                                                          */
    /* RFCTYPE_FLOAT                                                         */
    /* RFCTYPE_BCD                                                           */
    /* RFCTYPE_DECFxx                                                        */
    /* RFCTYPE_BYTE                                                          */
    /* RFCTYPE_XSTRING                                                       */
    /* Note: If the target field has type BYTE or XSTRING, the char value    */
    /* will be treated as hex encoded string representation of the bytes.    */
	DECL_EXP RFC_RC SAP_API RfcSetChars    (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_CHAR *charValue, unsigned valueLength, RFC_ERROR_INFO* info);
	DECL_EXP RFC_RC SAP_API RfcSetNum      (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_NUM *charValue, unsigned valueLength, RFC_ERROR_INFO* info);
	DECL_EXP RFC_RC SAP_API RfcSetString   (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const SAP_UC *stringValue, unsigned valueLength, RFC_ERROR_INFO* info);

    /* Supported type is RFCTYPE_DATE only                                   */
	DECL_EXP RFC_RC SAP_API RfcSetDate     (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_DATE date, RFC_ERROR_INFO* info);

    /* Supported type is RFCTYPE_TIME only                                   */
	DECL_EXP RFC_RC SAP_API RfcSetTime     (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_TIME time, RFC_ERROR_INFO* info);


    /* Sets the given byte value (byteValue/valueLength) into the field.     */
    /* Supported field types:                                                */
    /* RFCTYPE_BYTE                                                          */
    /* RFCTYPE_XSTRING                                                       */
    /* RFCTYPE_CHAR                                                          */
    /* RFCTYPE_STRING                                                        */
    /* RFCTYPE_INTx                                                          */
    /* RFCTYPE_FLOAT                                                         */
    /* RFCTYPE_BCD                                                           */
    /* RFCTYPE_DECFxx                                                        */
    /* Note: If the target field has type CHAR or STRING the byte value      */ 
    /* will be stored as a hex representation of the bytes.                  */
    /* Note: If the target field has number type, the byte value will be     */ 
    /* assigned only if the given length fits to the field length.           */
	DECL_EXP RFC_RC SAP_API RfcSetBytes    (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const SAP_RAW *byteValue, unsigned valueLength, RFC_ERROR_INFO* info);
	DECL_EXP RFC_RC SAP_API RfcSetXString  (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const SAP_RAW *byteValue, unsigned valueLength, RFC_ERROR_INFO* info);

	DECL_EXP RFC_RC SAP_API RfcSetInt      (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_INT  value, RFC_ERROR_INFO* info);
	DECL_EXP RFC_RC SAP_API RfcSetInt1     (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_INT1 value, RFC_ERROR_INFO* info);
	DECL_EXP RFC_RC SAP_API RfcSetInt2     (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_INT2 value, RFC_ERROR_INFO* info);

	/* Supported field types: */
    /* RFCTYPE_FLOAT          */
    /* RFCTYPE_BCD            */
    /* RFCTYPE_CHAR           */
    /* RFCTYPE_STRING         */
    /* RFCTYPE_NUM            */
    /* RFCTYPE_DECF16         */
    /* RFCTYPE_DECF34         */
	DECL_EXP RFC_RC SAP_API RfcSetFloat    (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_FLOAT value, RFC_ERROR_INFO* info);

	/* Supported field types: */
    /* RFCTYPE_DECF16         */
    /* RFCTYPE_DECF34         */
    /* RFCTYPE_FLOAT          */
    /* RFCTYPE_BCD            */
    /* RFCTYPE_INT            */
    /* RFCTYPE_INT2           */
    /* RFCTYPE_INT1           */
    /* RFCTYPE_CHAR           */
    /* RFCTYPE_NUM            */
    /* RFCTYPE_STRING         */
    /* RFCTYPE_BYTE           */
	DECL_EXP RFC_RC SAP_API RfcSetDecF16   (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_DECF16 value, RFC_ERROR_INFO* info);

	/* Supported field types: */
    /* RFCTYPE_DECF16         */
    /* RFCTYPE_DECF34         */
    /* RFCTYPE_FLOAT          */
    /* RFCTYPE_BCD            */
    /* RFCTYPE_INT            */
    /* RFCTYPE_INT2           */
    /* RFCTYPE_INT1           */
    /* RFCTYPE_CHAR           */
    /* RFCTYPE_NUM            */
    /* RFCTYPE_STRING         */
    /* RFCTYPE_BYTE           */
	DECL_EXP RFC_RC SAP_API RfcSetDecF34   (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_DECF34 value, RFC_ERROR_INFO* info);

	/* Supported type is RFCTYPE_STRUCTURE only                              */
	DECL_EXP RFC_RC SAP_API RfcSetStructure(DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_STRUCTURE_HANDLE value, RFC_ERROR_INFO* info);

	/* Supported type is RFCTYPE_TABLE only                                  */
	DECL_EXP RFC_RC SAP_API RfcSetTable    (DATA_CONTAINER_HANDLE dataHandle, SAP_UC const* name, const RFC_TABLE_HANDLE value, RFC_ERROR_INFO* info);

	/* Returns the meta data description for the current function module.
	 */
    DECL_EXP RFC_FUNCTION_DESC_HANDLE SAP_API RfcDescribeFunction(RFC_FUNCTION_HANDLE funcHandle, RFC_ERROR_INFO* info);
    
	/* Returns the meta data descriptions of a structure or table (RFC_STRUCTURE_HANDLE or RFC_TABLE_HANDLE).
	 */
    DECL_EXP RFC_TYPE_DESC_HANDLE SAP_API RfcDescribeType(DATA_CONTAINER_HANDLE dataHandle, RFC_ERROR_INFO* info);


    /*************************************************************************/
    /*                                                                       */
    /*  Metadata and Repository API                                          */
    /*                                                                       */
    /*************************************************************************/
	
    /* 1. Repository API */
    /*
     * Returns the function description that is valid for the system to which rfcHandle points to.
     * If the function description is already in the repository cache for that system ID, it will be 
	 * returned immediately (from the cache), otherwise it will be looked up in the system's DDIC using
	 * the rfcHandle. The result from the DDIC lookup will then be placed in the cache.
	 * The RFC Runtime maintains a cache for every R/3 System ID, as the meta data could be different
	 * from R/3 release to R/3 release.
     * This is the main API that should be used.
     */
	DECL_EXP RFC_FUNCTION_DESC_HANDLE SAP_API RfcGetFunctionDesc(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const * funcName, RFC_ERROR_INFO* info);

    /*
     * Returns a cached function description. 
     * If repositoryID is NULL, the "default storage" is used.
     * This API should be used with care and is only for special scenarios, for example:
	 * 1. You know for sure, that a function description has already been cached via RfcGetFunctionDesc(),
	 *    and don't want to open an extra rfcHandle that will never be used.
	 *    In this case simply use the SAP System ID as the repositoryID.
	 * 2. You have created a hard-coded repository via RfcAddFunctionDesc(), which contains functions
	 *    that do not exist in the backend's DDIC.
     */
	DECL_EXP RFC_FUNCTION_DESC_HANDLE SAP_API RfcGetCachedFunctionDesc(SAP_UC const * repositoryID, SAP_UC const * funcName, RFC_ERROR_INFO* info);

    /*
     * Adds a function description to the cache of the specified repository. 
     * If repositoryID is NULL, the "default storage" is used.
     * This API should be used with care and is only for special scenarios.
     */
	DECL_EXP RFC_RC SAP_API RfcAddFunctionDesc(SAP_UC const * repositoryID, RFC_FUNCTION_DESC_HANDLE funcHandle, RFC_ERROR_INFO* info);

    /*
     * The RfcXXXTypeDesc() functions are analogous to the RfcXXXFunctionDesc() functions. 
     */
	DECL_EXP RFC_TYPE_DESC_HANDLE SAP_API RfcGetTypeDesc(RFC_CONNECTION_HANDLE rfcHandle, SAP_UC const * typeName, RFC_ERROR_INFO* info);
	DECL_EXP RFC_TYPE_DESC_HANDLE SAP_API RfcGetCachedTypeDesc(SAP_UC const * repositoryID, SAP_UC const * typeName, RFC_ERROR_INFO* info);
	DECL_EXP RFC_RC SAP_API RfcAddTypeDesc(SAP_UC const * repositoryID, RFC_TYPE_DESC_HANDLE typeHandle, RFC_ERROR_INFO* info);

    /* 2. Metadata API */
    /* 2.1. Metadata API for structure descriptions */
    /*
     * Creates an empty type description with the given name and returns
     * a new RFC_TYPE_DESC_HANDLE.
     * This handle can then be used with the RfcAddTypeField and RfcSetTypeLength API. 
     */
    DECL_EXP RFC_TYPE_DESC_HANDLE SAP_API RfcCreateTypeDesc(SAP_UC const* name, RFC_ERROR_INFO* info);

    /*
     * Add a new field to the type description.
     * After the handle was used, any modifications are forbidden.
     */
    DECL_EXP RFC_RC SAP_API RfcAddTypeField(RFC_TYPE_DESC_HANDLE typeHandle, const RFC_FIELD_DESC* fieldDescr, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcSetTypeLength(RFC_TYPE_DESC_HANDLE typeHandle, unsigned nucByteLength, unsigned ucByteLength, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetTypeName(RFC_TYPE_DESC_HANDLE typeHandle, RFC_ABAP_NAME bufferForName, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetFieldCount(RFC_TYPE_DESC_HANDLE typeHandle, unsigned* count, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetFieldDescByIndex(RFC_TYPE_DESC_HANDLE typeHandle, unsigned index, RFC_FIELD_DESC* fieldDescr, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetFieldDescByName(RFC_TYPE_DESC_HANDLE typeHandle, SAP_UC const* name, RFC_FIELD_DESC* fieldDescr, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetTypeLength(RFC_TYPE_DESC_HANDLE typeHandle, unsigned* nucByteLength, unsigned* ucByteLength, RFC_ERROR_INFO* info);

    /*
     * Deletes the type description and releases the allocated resources.
     * Only descriptions, which are not stored in a repository cache and not used by the application, can be deleted.
     * Deleting a cached description will cause an error, and deleting a description that is still in use, will lead
     * to a crash.
     */
	DECL_EXP RFC_RC SAP_API RfcDestroyTypeDesc(RFC_TYPE_DESC_HANDLE typeHandle, RFC_ERROR_INFO *info);


    /* 2.2. Metadata API for function descriptions */
    /*
     * Creates an empty function description with the given name and returns
     * a new RFC_FUNCTION_DESC_HANDLE.
     * This handle can then be used with the RfcAddParameter API. 
     */
    DECL_EXP RFC_FUNCTION_DESC_HANDLE SAP_API RfcCreateFunctionDesc(SAP_UC const* name, RFC_ERROR_INFO* info);

    DECL_EXP RFC_RC SAP_API RfcGetFunctionName(RFC_FUNCTION_DESC_HANDLE funcHandle, RFC_ABAP_NAME bufferForName, RFC_ERROR_INFO* info);

	/*
     * Adds a new parameter to the function description.
     * After the handle was used, any modifications are forbidden.
     */
    DECL_EXP RFC_RC SAP_API RfcAddParameter(RFC_FUNCTION_DESC_HANDLE funcHandle, const RFC_PARAMETER_DESC* paramDescr, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetParameterCount(RFC_FUNCTION_DESC_HANDLE funcHandle, unsigned* count, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetParameterDescByIndex(RFC_FUNCTION_DESC_HANDLE funcHandle, unsigned index, RFC_PARAMETER_DESC* paramDesc, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetParameterDescByName(RFC_FUNCTION_DESC_HANDLE funcHandle, SAP_UC const* name, RFC_PARAMETER_DESC* paramDesc, RFC_ERROR_INFO* info);

	/*
     * Adds a new parameter to the function description.
     * After the handle was used, any modifications are forbidden.
     */
    DECL_EXP RFC_RC SAP_API RfcAddException(RFC_FUNCTION_DESC_HANDLE funcHandle, const RFC_EXCEPTION_DESC* excDesc, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetExceptionCount(RFC_FUNCTION_DESC_HANDLE funcHandle, unsigned* count, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetExceptionDescByIndex(RFC_FUNCTION_DESC_HANDLE funcHandle, unsigned index, RFC_EXCEPTION_DESC* excDesc, RFC_ERROR_INFO* info);
    DECL_EXP RFC_RC SAP_API RfcGetExceptionDescByName(RFC_FUNCTION_DESC_HANDLE funcHandle, SAP_UC const* name, RFC_EXCEPTION_DESC* excDesc, RFC_ERROR_INFO* info);

	DECL_EXP RFC_RC SAP_API RfcEnableBASXML(RFC_FUNCTION_DESC_HANDLE funcHandle, RFC_ERROR_INFO* info);
    /*isAble == 0 is able, isAble != 0 is not able */
    DECL_EXP RFC_RC SAP_API RfcIsBASXMLSupported(RFC_FUNCTION_DESC_HANDLE funcHandle, int* isAble, RFC_ERROR_INFO* info);


    /*
     * Deletes the function description and releases the allocated resources.
     * Only descriptions, which are not stored in a repository cache and not used by the application, can be deleted.
     * Deleting a cached description will cause an error, and deleting a description that is still in use, will lead
     * to a crash.
     */
	DECL_EXP RFC_RC SAP_API RfcDestroyFunctionDesc(RFC_FUNCTION_DESC_HANDLE funcHandle, RFC_ERROR_INFO *info);
    
    DECL_EXP RFC_RC SAP_API RfcUTF8ToSAPUC(const RFC_BYTE *utf8, unsigned utf8Length,  SAP_UC *sapuc,  unsigned *sapucSize, unsigned *resultLength, RFC_ERROR_INFO *info);
    DECL_EXP RFC_RC SAP_API RfcSAPUCToUTF8(const SAP_UC *sapuc,  unsigned sapucLength, RFC_BYTE *utf8, unsigned *utf8Size,  unsigned *resultLength, RFC_ERROR_INFO *info);

    /* Helper functions */
    /* They return a pointer to static memory, so don't try to free that! */
    DECL_EXP const SAP_UC* SAP_API RfcGetRcAsString(RFC_RC rc);
    DECL_EXP const SAP_UC* SAP_API RfcGetTypeAsString(RFCTYPE type);
    DECL_EXP const SAP_UC* SAP_API RfcGetDirectionAsString(RFC_DIRECTION direction);

#ifdef __cplusplus
}
#endif /*cplusplus*/

#endif
