/*****************************************************************************/
/*                              TOPLINK 2.0                                  */
/* Copyright (c) 2005 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/

#ifndef __LINE_STATE_H
#define __LINE_STATE_H

/* define for nLineStat */
#define LINE_STATE_CONNECT		1
#define LINE_STATE_DISCONNECT	2
#define LINE_STATE_RESET		3

/*****************************************************************************/
/* FUNC:   int LineStateChg (char *sSrvId, int nLineStat);                   */
/* INPUT:  sSrvId: server id                                                 */
/*         nLineState: ͨѶ��·״̬,                                         */
/*                     LINE_STATE_CONNECT, LINE_STATE_DISCONNECT             */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   �޸�server id��Ӧ����·��״̬, ��tbl_line_inf                     */
/*         ��һ��������, line_state��1; ��һ������, line_state��1            */
/*         ע: ֻ�ڽ����µķ�������ʱ���ô˺���, ��������ӿɲ����          */
/*****************************************************************************/
int LineStateChg(char *sSrvId, char *sLineIndex, int nLineStat);

/*****************************************************************************/
/* FUNC:   int LineStateCheck (char *sSrvId, int *pnLineStat);               */
/* INPUT:  sSrvId: server id                                                 */
/* OUTPUT: nLineState: ͨѶ��·״̬,                                         */
/*                     LINE_STATE_CONNECT, LINE_STATE_DISCONNECT             */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���server id��Ӧ����·��״̬, ��tbl_line_inf                     */
/*****************************************************************************/
int LineStateCheck(char *sSrvId, char *sLineIndex, int *pnLineStat);

#endif
