/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:db.h
 *
 *  Edit History:
 *
 *     2009/01/04 -gendb
 */

#ifndef _TBL_INF_MCHNT_INF_DEF_H
#define _TBL_INF_MCHNT_INF_DEF_H
/*   Default values for table tbl_mcht_inf.    */
#define	MCHNT_CD_DEF "               "            
#define	ACQ_INS_ID_CD_DEF "             "      
#define	SIGN_INS_ID_CD_DEF "             "      
#define	PRINT_INS_ID_CD_DEF "             "     
#define	AREA_CD_DEF "    "             
#define	CONN_MD_DEF " "              
#define	MCHNT_MNG_MD_DEF " "         
#define	MCHNT_ST_DEF " "             
#define	MCHNT_GRP_DEF "    "            
#define	MCHNT_TP_DEF "    "             
#define	MCHNT_NM_DEF "                                                            "            
#define	MCHNT_CN_ABBR_DEF "                                        "       
#define	MCHNT_EN_NM_DEF "                                                            "         
#define	MCHNT_EN_ABBR_DEF "                    "       
#define	DEAL_LOCA_NM_DEF "                                                                                                    "       
#define	MCHNT_ATTR_DEF "                    "          
#define	EXP_ID_DEF "                              "              
#define	MCHNT_GROUP_FLAG_DEF " "     
#define	MCHNT_GROUP_ID_DEF "        "       
#define	PASSWORD_DEF "        "             
#define	POS_NUM_DEF 0                 
#define	POS_INUSE_NUM_DEF 0           
#define	MIS_NUM_DEF 0                 
#define	MCHT_FORIN_FLG_DEF " "       
#define	FOR_MCHNT_GRP_DEF "    "        
#define	FOR_MCHNT_TP_DEF "    "         
#define	FOR_CITY_NM_EN_DEF "                                                            "      
#define	DEAL_LOCA_NM_EN_DEF "                                                                                                    "    
#define	FOR_CARD_USE_IN_DEF "          "     
#define	FOR_CARD_RST_IN_DEF "          "     
#define	FOR_CARD_RECOURSE_IN_DEF "          "
#define	FOR_SIGN_LMT_AT_DEF 0         
#define	DIV_MCHNT_TP_DEF "    "         
#define	DIV_SINGL_LMT_AMT_DEF 0       
#define	MCHNT_FUNT_IN_DEF "                   "       
#define	PRESS_TERM_NUM_DEF 0          
#define	PER_COM_LMT_AMT_DEF 0         
#define	PER_GOLD_LMT_AMT_DEF 0        
#define	CMP_COM_LMT_AMT_DEF 0        
#define	CMP_GOLD_LMT_AMT_DEF 0        
#define	SINGL_LMT_AMT_DEF 0           
#define	DAY_LMT_AMT_DEF 0             
#define	MONTH_LMT_AMT_DEF 0         
#define	YEAR_LMT_AMT_DEF 0            
#define	DISC_ALGO_IN_DEF " "         
#define	DISC_RATE_DEF 0               
#define	DISC_CD_DEF "     "              
#define	DISC_CRT_TS_DEF "        "          
#define	DISC_ALT_TS_DEF "        "          
#define	SETTLE_ACCT_IN_DEF " "       
#define	SETTLE_ACCT_ATTR_DEF " "     
#define	SETTLE_ACCT_DEF "                              "         
#define	SETTLE_ACCT_NM_DEF "                                                            "      
#define	SETTLE_BANK_CD_DEF "             "      
#define	SETTLE_BANK_NM_DEF "                                                            "      
#define	EXCHANGE_INS_CD_DEF "          "     
#define	EXCHANGE_CD_DEF "      "          
#define	ETPS_ATTR_DEF "    "            
#define	ETPS_CD_DEF "                    "             
#define	ARTIF_DEF "                   "               
#define	ARTIF_CERTIF_TP_DEF "  "
#define 	ARTIF_CERTIF_NO_DEF "                              "
#define 	MCHT_BUS_LIC_NO_DEF "                    "
#define  MCHT_REG_DEADLINE_DEF "        "
#define  MCHT_ENT_NO_DEF "                    "
#define  MCHT_REG_FUND_DEF "            "
#define  MCHT_RISK_RANK_DEF "  "
#define  REG_ADDR_DEF "                                                            "
#define  CONTACT_PERSON_DEF "                    "
#define  PHONE_DEF "                                        "
#define  FAX_NO_DEF "                    "
#define  EMAIL_DEF "                                        "
#define  ZIP_CD_DEF "      "
#define  ADDR_DEF "                                                            "
#define  APPLY_DT_DEF "        "
#define  ENABLE_DT_DEF "        "
#define  MCHNT_MANAGER_NM_DEF "                                        "
#define  MCHNT_MANAGER_CD_DEF "                    "
#define  PROTOCAL_ID_DEF "                    "
#define  LOAD_BATCH_NO_DEF "      "
#define  PRE_AUD_NM_DEF "                                        "
#define  CONFIRM_NM_DEF "                                        "
#define  DESCR_DEF "                                                                                                                                                                                                        "
#define  RESERVE1_DEF "                         "
#define  RESERVE2_DEF "                         "
#define  RESERVE3_DEF "                         "
#define  RESERVE4_DEF "                                                  "
#define  RESERVE5_DEF "                                                  "
#define  RESERVE6_DEF "                                                  "
#define  REC_ST_DEF " "
#define  LAST_OPER_IN_DEF " "
#define  REC_UPD_USR_ID_DEF "          "
#define  REC_UPD_TS_DEF "              "
#define  REC_CRT_TS_DEF "              "

#endif
