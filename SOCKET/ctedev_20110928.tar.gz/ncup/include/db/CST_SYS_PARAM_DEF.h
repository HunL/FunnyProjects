/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:db.h
 *
 *  Edit History:
 *
 *     2008/12/17 -gendb
 */

#ifndef _CST_SYS_PARAM_DEF_H
#define _CST_SYS_PARAM_DEF_H
/*   Default values for table cst_sys_param.    */
#define	owner_DEF "           "
#define	key_DEF "                    "
#define	type_DEF "  "
#define	value_DEF "                                                                                                                                                                                                        "
#define	desc_DEF "                                                            "
#define	reserve_DEF "                                                                "
#endif

