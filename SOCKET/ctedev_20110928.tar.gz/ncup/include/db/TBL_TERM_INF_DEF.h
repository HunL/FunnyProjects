/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:db.h
 *
 *  Edit History:
 *
 *     2009/01/07 -gendb
 */

#ifndef _TBL_TERM_INF_DEF_H
#define _TBL_TERM_INF_DEF_H
/*   Default values for table tbl_term_inf.    */
#define	mcht_cd_DEF	"               "
#define	term_id_DEF	"        "
#define	term_id_id_DEF	"               "
#define	term_sta_DEF	" "
#define	term_sign_sta_DEF	" "
#define	chk_sta_DEF	" "
#define	term_mcc_DEF	"    "
#define	term_factory_DEF	" "
#define	term_mach_tp_DEF	" "
#define	term_ver_DEF	"  "
#define	term_single_limit_DEF	"            "
#define	term_tp_DEF	"  "
#define	param_down_sign_DEF	" "
#define	param1_down_sign_DEF	" "
#define	ic_down_sign_DEF	" "
#define	key_down_sign_DEF	" "
#define	prop_tp_DEF	"  "
#define	prop_ins_nm_DEF	" "
#define	support_ic_DEF	" "
#define	psam_id_DEF	"        "
#define	term_place_DEF	" "
#define	dial_tp_DEF	" "
#define	term_ins_DEF	"           "
#define	term_ver_tp_DEF	"  "
#define	term_batch_nm_DEF	"      "
#define	term_stlm_dt_DEF	"        "
#define	term_para_DEF	" "
#define	term_para_1_DEF	" "
#define	term_para_2_DEF	" "
#define	bind_tel_DEF	"              "
#define	term_addr_DEF	" "
#define	opr_nm_DEF	"                    "
#define	cont_tel_DEF	"                    "
#define	equip_inv_id_DEF	" "
#define	equip_inv_nm_DEF	" "
#define	run_main_id_1_DEF	" "
#define	run_main_nm_1_DEF	" "
#define	run_main_id_2_DEF	" "
#define	run_main_nm_2_DEF	" "
#define	oth_svr_id_DEF	" "
#define	oth_svr_nm_DEF	" "
#define	rec_opr_id_DEF	" "
#define	rec_upd_opr_DEF	"          "
#define	rec_crt_ts_DEF	"2008-12-06-01.22.04.968000"
#define	rec_upd_ts_DEF	"2008-12-06-01.22.04.968000"

#endif
