// Author:	Wolfgang Wang
// Date:	2001/8/30

// Modification History
// 2002/3/6, Add a declaration of function UnionReceiveFromSocketUntilLen

// 2002/2/18, ��UnionTCPIPServer�����ˡ�2.x��ǰ�汾��������������2.x�汾����������������������Ϊһ������ָ�롣
// Ҫʹ��2.x�Ժ�İ汾��������ͷ�ļ����򣬱��붨��꣺_UnionSocket_2_x_

#ifndef _UnionSocket
#define _UnionSocket

int UnionCloseSocket(int SocketID);
int UnionCreateSocketClient(char *ip,int port);
int UnionSendToSocket(int SocketID,unsigned char *Buf,unsigned int SizeOfBuf);
int UnionReceiveFromSocket(int SocketID,unsigned char *Buf,unsigned int LenOfBuf);
int UnionReceiveFromSocketUntilLen(int SocketID,unsigned char *Buf,unsigned int LenOfBuf); // Added By Wolfgang Wang, 2002/3/6

int UnionNewTCPIPConnection(int scksvr);
int UnionInitializeTCPIPServer(int port);

#ifdef _UnionSocket_3_x_
int UnionTCPIPServer(int port,char *ServerName,int (*UnionTCPIPTaskServer)(),int (*UnionTaskActionBeforeExit)());
#else
#ifdef _UnionSocket_2_x_
int UnionTCPIPServer(int port,char *ServerName,int (*UnionTCPIPTaskServer)());
#else
int UnionTCPIPServer(int port,char *ServerName);
#endif
#endif

#define UnionErrOffsetOfSocketMdl			-10500
#define UnionErrNullIPAddressPassed			UnionErrOffsetOfSocketMdl - 1
#define	UnionErrMinusSocketPortPassed			UnionErrOffsetOfSocketMdl - 2
#define UnionErrCallingSocket				UnionErrOffsetOfSocketMdl - 3
#define UnionErrCallingConnect				UnionErrOffsetOfSocketMdl - 4
#define UnionErrCallingSetsockopt			UnionErrOffsetOfSocketMdl - 5
#define UnionErrCallingBind				UnionErrOffsetOfSocketMdl - 6
#define UnionErrCallingListen				UnionErrOffsetOfSocketMdl - 7
#define UnionErrCallingAccept				UnionErrOffsetOfSocketMdl - 8
#define UnionErrCallingMalloc				UnionErrOffsetOfSocketMdl - 9
#define UnionErrCallingSend				UnionErrOffsetOfSocketMdl - 10
#define UnionErrCallingRecv				UnionErrOffsetOfSocketMdl - 11

#endif
