//	Author:		Wolfgang Wang
//	Copyright:	Union Tech. Guangzhou
//	Date:		2006/7/26

#ifndef _commWithEsscSvr_
#define _commWithEsscSvr_

void UnionReleaseCommWithHsmSvr();

int UnionCommWithHsmSvrForThread(char *serviceCode,char *reqStr,int lenOfReqStr,char *resStr,int sizeOfResStr);

#endif
