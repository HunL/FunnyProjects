/*****************************************************************************/
/*                              TOPLINK 2.0                                  */
/* Copyright (c) 2005 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/

#ifndef __HB_ERR_CODE_H
#define __HB_ERR_CODE_H

#include "ErrCode.h"

/* HSM */
#define ERR_CODE_HB_VMAC        ERR_CODE_HB_BASE + 1001
#define ERR_CODE_HB_TPIN        ERR_CODE_HB_BASE + 1002
#define ERR_CODE_HB_VCVV        ERR_CODE_HB_BASE + 1003


/* RFC */
#define ERR_CODE_HB_RFCCNT      ERR_CODE_HB_BASE + 2001
#define ERR_CODE_HB_RFCCALL     ERR_CODE_HB_BASE + 2002

/* DM */
#define ERR_CODE_HB_DMCARDCHK   ERR_CODE_HB_BASE + 3001
#define ERR_CODE_HB_PI          ERR_CODE_HB_BASE + 3002
#define ERR_CODE_HB_DMCMT       ERR_CODE_HB_BASE + 3003
#define ERR_CODE_HB_PRENCRT     ERR_CODE_HB_BASE + 3004
#define ERR_CODE_HB_PRENDEL     ERR_CODE_HB_BASE + 3005
#define ERR_CODE_HB_REVSAL      ERR_CODE_HB_BASE + 3006
#define ERR_CODE_HB_ACLOCK      ERR_CODE_HB_BASE + 3007
#define ERR_CODE_HB_BPCHK       ERR_CODE_HB_BASE + 3008
#define ERR_CODE_HB_BALANCE     ERR_CODE_HB_BASE + 3009
#define ERR_CODE_HB_INV_AMT     ERR_CODE_HB_BASE + 3010

/* DB */
#define ERR_CODE_HB_DMTXN_INST  ERR_CODE_HB_BASE + 4001
#define ERR_CODE_HB_DMTXN_UPD   ERR_CODE_HB_BASE + 4002
#define ERR_CODE_HB_DMTXN_GET   ERR_CODE_HB_BASE + 4003
#define ERR_CODE_HB_TRCOD_GET   ERR_CODE_HB_BASE + 4004

/* TXN */
#define ERR_CODE_HB_CHK_AMT     ERR_CODE_HB_BASE + 5001 
#define ERR_CODE_HB_CHK_STATE   ERR_CODE_HB_BASE + 5002
#define ERR_CODE_HB_CHK_FLAG    ERR_CODE_HB_BASE + 5003
#define ERR_CODE_HB_CHK_PAN     ERR_CODE_HB_BASE + 5004
#define ERR_CODE_HB_CHK_RTND    ERR_CODE_HB_BASE + 5011

#endif
