/*
 *  Copyright 2007, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *
 *    ����: ����ͷ�ļ���������ȫ�ֱ���
 *  Edit History:
 *
 *    2007/12/01
 */

#ifndef _HBCOMMON_H_
#define _HBCOMMON_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include "SrvDef.h"
#include "MsqOpr.h"
#include "IpcInt.h"
#include "HtLog.h"


#define MAX_TXN_NUM                30

/*************************************************************
 *  GLOBAL USED                                              *
 *************************************************************/
extern char         gsHBLogFile[LOG_NAME_LEN_MAX];
extern char         gsTxnType[2];
extern char         gsRvslFlg[2];
extern char         gsPINFlg;
extern char         gsTRCFlg;
extern char         gsSrvSeqId[SRV_SEQ_ID_LEN+1];
extern char         gsSrvId[SRV_ID_LEN+1];
extern char         gsTxnChnl[10];

extern char         gsBankCode[16];
extern char         gsBankCountry[4];
extern char         gsCmbcCode[20];

/*************************************************************
* Define Service function prototype:                         *
* _DEFINE_SERVICE( EXAMPLE_SERVICE_NAME, ptpinfoExample )    *
*************************************************************/
#define _DEFINE_SERVICE(ServiceName, pTpIpc, sMiscOrg) \
        int ServiceName(T_IpcIntTxnDef* pTpIpc, char *sMiscOrg)

/*************************************************************
 *  HTLOG USED                                               *
 *************************************************************/
#define HB_LOG_MODE_NORMAL         gsHBLogFile , HT_LOG_MODE_NORMAL ,  __FILE__,__LINE__
#define HB_LOG_MODE_ERROR          gsHBLogFile , HT_LOG_MODE_ERROR  ,  __FILE__,__LINE__
#define HB_LOG_MODE_DEBUG          gsHBLogFile , HT_LOG_MODE_DEBUG  ,  __FILE__,__LINE__



/*************************************************************
 *  DM USED                                               *
 *************************************************************/
#define DM_ACCOUNT_NO_LEN             35
#define DM_SERVER_CODE_LEN            20
#define DM_TRANS_TYPE_LEN             6
#define DM_FEE_LEN                    13
#define DM_BALANCE_LEN                15
#define DM_LOCKITEM_LEN               12
#define DM_OPEN_INST_LEN              4
#define BP_CUST_ID_LEN                10 
#define BP_NAME_LEN                   40 
#define BP_ID_TYPE_LEN                6 
#define BP_ID_NUMBER_LEN              60 
#define BP_PROD_ID_LEN                10
#define BP_SIGN_SEQ_LEN               17

/* ZCDM TRANS CHANNEL DEFINE */
#define ZCDM_TRANS_CHNL_CUP_ATM       "1301"
#define ZCDM_TRANS_CHNL_CUP_POS       "1302"
#define ZCDM_TRANS_CHNL_CUP_BNK       "1303"
#define ZCDM_TRANS_CHNL_XBANK         "1001"
/* ZCDM TRANS BRANCH DEFINE */
#define ZCDM_TRANS_BRH                "1001"
/* ZCDM TRANS TELLER DEFINE */
#define ZCDM_TRANS_TLR                "1000000000"

/* ZCDM TRANS TYPE DEFINE */
#define ZCDM_TRANS_TYPE_QUR           "0"
#define ZCDM_TRANS_TYPE_SAV           "1"
#define ZCDM_TRANS_TYPE_WDW           "2"
#define ZCDM_TRANS_TYPE_TIN           "3"
#define ZCDM_TRANS_TYPE_TOU           "4"
#define ZCDM_TRANS_TYPE_COS           "5"
#define ZCDM_TRANS_TYPE_DIS           "6"
#define ZCDM_TRANS_TYPE_RTN           "7"
#define ZCDM_TRANS_TYPE_PAU           "A"
#define ZCDM_TRANS_TYPE_PDS           "B"
#define ZCDM_TRANS_TYPE_PCP           "C"
#define ZCDM_TRANS_TYPE_PCD           "D"

#define CMBC_BANK_CODE                "0305"
#define ZCDM_TRANS_CURR_RMB           "RMB"
#define ZCDM_TRANS_COUNTRY            "CN"
#define ZCDM_TRANS_BANKCODE           "C001"
#define ZCDM_EVENT_TYPE               "038809"

/* ZCDM DEDUCE MODE DEFINE */
#define ZCDM_DEDUCE_MODE_NO           "0"
#define ZCDM_DEDUCE_MODE_YES          "1"
#define ZCDM_DEDUCE_MODE_BACK         "2"

/* ZCDM REVERSAL FLAG DEFINE */
#define ZCDM_REVERSAL_FLAG_NO         "N"
#define ZCDM_REVERSAL_FLAG_YES        "Y"

/* ZCDM GET BALANCE DEFINE */
#define ZCDM_GET_BALANCE_NO           "N"
#define ZCDM_GET_BALANCE_YES          "Y"


/* DM_ACCOUNT_UNLOCK */
#define DM_ACCT_DOC_STATE_SCH         "01"
#define DM_ACCT_DOC_STATE_ACT         "02"
#define DM_ACCT_DOC_STATE_INA         "03"
#define DM_ACCT_DOC_STATE_CLS         "04"
#define DM_ACCT_PRONOTE_TYPE          "809"


#endif
