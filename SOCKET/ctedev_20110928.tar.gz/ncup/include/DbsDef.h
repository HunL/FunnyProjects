#ifndef _DBS_DEF_H
#define _DBS_DEF_H

#ifdef _DB_ORA
#define DBS_NOTFOUND		1403
#endif
#ifdef _DB_INFX
#define DBS_NOTFOUND		100
#endif
#ifdef _DB_DB2
#define DBS_NOTFOUND		100
#endif

#ifdef _DB_DB2
#define DB_NEED_RECONNECT(sqlcode)  sqlcode == -1032 || sqlcode == -1024 || \
                                    sqlcode == -1224 || sqlcode == -1822 || \
                                    sqlcode == -30081 || sqlcode == -30082
#else
#define DB_NEED_RECONNECT(sqlcode) 0
#endif

#define DBS_IND_NULL		-1

/* tbl_srv_param.param_usage value */
#define SRV_PARAM_USAGE_NAME	"0"
#define SRV_PARAM_USAGE_ENV		"1"
#define SRV_PARAM_USAGE_ARG		"2"

/* server env MSG_COMPRESS_FLAG value */
#define FLAG_YES				"Y"
#define FLAG_NO					"N"
#define FLAG_YES_C				'Y'
#define FLAG_NO_C				'N'

/* tbl_card_inf.used_flag */
#define CARD_USED_FLAG_ON		"1"
#define CARD_USED_FLAG_OFF		"0"

/* tbl_txn_inf.rsp_type value */
#define RSP_TYPE_NO_ACCOUNT			'1'
#define RSP_TYPE_RSP_BEFORE_ACCOUNT	'2'
#define RSP_TYPE_RSP_AFTER_ACCOUNT	'3'

/* tbl_txn_inf records num max */
#define TXN_INF_NUM_MAX	500
#define UNION_CARD_NUM  500

/* tbl_bank_bin_inf records num max */
#define CARD_BIN_NUM_MAX_0	2000	/* ���п�BIN */
#define CARD_BIN_NUM_MAX_1	3000	/* ���п�BIN */

/* database user/password */
#define SADBSUserPwdFile "TL_HAHA_FILE"

/* dbs operation defines for first argument in dbs function */
#define DBS_INIT       0
#define DBS_SELECT     1
#define DBS_LOCK       2
#define DBS_UPDATE     3
#define DBS_DELETE     4
#define DBS_INSERT     5
#define DBS_INSERT2    6

#define DBS_CURSOR     11
#define DBS_OPEN       12
#define DBS_CLOSE      13
#define DBS_FETCH      14

#define DBS_SELECT1    20
#define DBS_LOCK1      21
#define DBS_UPDATE1    22
#define DBS_DELETE1	   30
#define DBS_SELECT2    23
#define DBS_LOCK2      24
#define DBS_UPDATE2    25
#define DBS_SELECT3    26
#define DBS_LOCK3      27
#define DBS_UPDATE3    28

#define DBS_SELECT4    31
#define DBS_UPDATE4    29
#define DBS_UPDATE5    30
#define DBS_UPDATE6    50 
#define DBS_UPDATE8    33
#define DBS_UPDATE9    34
#define DBS_UPDATE10    35
#define DBS_SELECT5    36

#define DBS_CRTSELECT   38
#define DBS_PARSELECT   39
#define DBS_CURSOR1     40
#define DBS_OPEN1     41
#define DBS_FETCH1     42
#define DBS_CLOSE1    43
#define DBS_CURSOR2     44
#define DBS_OPEN2     45
#define DBS_FETCH2     46
#define DBS_CLOSE2     47
#define DBS_UPDATE11   48
#define DBS_UPDATE12   49
#define DBS_UPDATE13   51
#define DBS_UPDATE14   52

/*�Ÿ�ͨר��*/
#define DBS_SELECT6    37
/* DBS_SELECT21: key_rsp, txn_num */
#define DBS_SELECT21   121
/* DBS_SELECT22: key_revsal, txn_num */
#define DBS_SELECT22   122
/* DBS_SELECT28: key_revsal, txn_num, inst_date */
#define DBS_SELECT28   131
/* DBS_SELECT23: key_cancel, txn_num */
#define DBS_SELECT23   123
/* DBS_SELECT27: key_cancel, txn_num, inst_date */
#define DBS_SELECT27   130
/* DBS_SELECT24: key_revsal */
#define DBS_SELECT24   124
/* DBS_SELECT25: in tbl_txn_his, key_cancel, txn_num */
#define DBS_SELECT25   125
#define DBS_SELECT26   126
/* DBS_SELECT29: in tbl_auth,����ƽ̨Ԥ��Ȩ�ֹ�����ר��*/
#define DBS_SELECT29   132
#define DBS_GET_NEXT_VAL	31

/* Dbs functions */
int DbsConnect ();
int DbsBegin ();
int DbsCommit ();
int DbsRollback ();
int DbsDisconnect ();
int test ();
#endif

