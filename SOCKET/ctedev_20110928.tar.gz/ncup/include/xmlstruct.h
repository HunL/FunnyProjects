#ifndef __XML_H
#define __XML_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <memory.h>
#include <signal.h>
#include <ctype.h>
#include <errno.h>

#include "SrvDef.h"
#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "TxnNum.h"
#include "ErrCode.h"
#include "IpcInt.h"
#include "MsqOpr.h"
#include "HtLog.h"
#include "CvtOpr.h"


#define xmlNMMaxNodeDspN   50
#define xmlNMMaxBufDspN   200

#endif

typedef struct 
{
  long l_usage_key ;       
  long i_buf_dsp_index;    
  long i_node_index ;    
  long father_node_id ;
  char sp_node_name[21] ;  
  long i_leaf_type ;       
  long i_fld_index ;       
  long i_repeat_or;        
  long i_attribute_num ;   
  char sp_attribute_name1[40+1];
  char sp_attribute_test1[60+1];
  char sp_attribute_name2[40+1];
  char sp_attribute_test2[60+1];
  char sp_attribute_name3[40+1];
  char sp_attribute_test3[60+1];
  long i_hold1_usr ;          
  char sp_hold2_usr[50+1];
}tbl_xml_values;


typedef struct 
 {
      long   usage_key ;
      char comp_key[2];
      long   xml_index ;
      long  buf_index;
      char txn_number[11];
      char xml_dsp[257];
  }xml_trans_dsp;
  
  
typedef struct {
  	char                              nodepath[100];
    int                               nFldL;
    int                               nFldType;
    int                               nOffset;
    long                              l_usage_key ;       
    long                              i_buf_dsp_index;    
    long                              i_node_index ;    
    long                              father_node_id ;
    char                              father_node_name[21];
    char                              sp_node_name[21] ;  
    long                              i_leaf_type ;       
    long                              i_fld_index ;       
    long                              i_repeat_or;        
    long                              i_attribute_num ;   
    char                              sp_attribute_name1[40+1];
    char                              sp_attribute_test1[60+1];
    char                              sp_attribute_name2[40+1];
    char                              sp_attribute_test2[60+1];
    char                              sp_attribute_name3[40+1];
    char                              sp_attribute_test3[60+1];
    long                              i_hold1_usr ;          
    char                              sp_hold2_usr[50+1];
} XmlnodeINF;

typedef struct {
    int                                 nFldN;
    int                                 usage_key ;
    char                                txncode[11];
    long                                bufid;
    XmlnodeINF                          stxmlnodeinf[xmlNMMaxNodeDspN];
} XmlnodeBuf;

typedef struct {
    int                                 nBufN;
    char                                compkey[2];
    XmlnodeBuf                          stxmlnodebuf[xmlNMMaxBufDspN];
} AllXmlnodeBuf;

int createxml(int nSavKey,char *IPCrcvmsgbuf,int iXMLinlen,char *sXmlOutBuf,int *iXMLoutlen,AllXmlnodeBuf sCRTallxmlnodebuf);
int parsexml(int nSavKey,char *XMLrevmsgbuf,int iXMLinlen,char *IPCsendmsgbuf,int *iXMLoutlen,AllXmlnodeBuf sPARallxmlnodebuf);
int BribdgexmlInit (int  nBufChgKey, AllXmlnodeBuf *vtpallxmlnodebuf);
int PacksendxmlInit (int  nBufChgKey, AllXmlnodeBuf *vtpallxmlnodebuf);
