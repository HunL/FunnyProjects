#ifndef _CST_DBS_TBL_H
#define _CST_DBS_TBL_H

typedef struct
{
	char	ssn_type[2];
	int		ssn_seqno;
	char	tlr_no[9];
	char	ssn_value[5];
	char	ssn_min[5];
	char	ssn_max[5];
	int		buf_count;
} CST_Tbl_t_ssn_Def;

typedef struct
{
	char	city_code[5];
	int		comp_len_1;
	int		begin_pos_1;
	char	branch_code[3];
	int		comp_len_2;
	int		begin_pos_2;
	char	dsp[33];
} CST_Tbl_bank_zone_Def;

typedef struct
{
	char loc_code[5];	
} CST_Tbl_bank_LOC_Def;

typedef struct {
	char param_1[1];
	char sp1;
	char param_2[1];
	char sp2;
} T_InstTxnParamVal;

typedef struct {
    char    bran_code[11];
    char    type_cd[5];
    char    card_id[20];
    char    ext_user_id_cd[3];
    char    ext_user_id[41];
	char    third_user_id_cd[3];
    char    third_user_id[41];
    char    sub_key1_cd[5];
    char    sub_key2_cd[9];
    char    sub_key3_cd[21];
    char    sub_key4_cd[21];
    char    static1[2];
    char    static2[2];
    char    misc_tx[257];
    char    misc_tx2[513];
} TBL_Cst_Commpay_Sig;

/**add by xichanglun 20081205**/
typedef struct {
	char	branch_code[10+1];
	char	card_bin[8+1];
	char	card_val_flg[1+1];
	char	channel_no[2+1];
	char	txn_code[4+1];
	char	city_flag[1+1];
	char	country_flag[1+1];
	char	fee_flag[1+1];
	char	mchnt_type[4+1];
	double	min_txn_amt;
	double	max_txn_amt;
	double	fee_amt;
	double	cup_fee_amt;
	double	fee_rate;
	double	min_amt;
	double	max_amt;
	int	free_cnt;
	char	misc[125+1];
} TBL_Cst_fee_rate;

typedef struct {
	char    branch_code[10+1];
	char	use_flag[1+1];
	char	channel_no[2+1];
	char	txn_code[4+1];
	char	city_flag[1+1];
	char	country_flag[1+1];
	char	fee_flag[1+1];
	double	fee_amt;
	double	fee_rate;
	double	min_amt;
	double	max_amt;
	int  	free_cnt;
	char	misc[125+1];
} TBL_Cst_branch_fee_inf;

typedef struct {
	char    card_bin[8+1];
	char	use_flag[1+1];
	char	channel_no[2+1];
	char	txn_code[4+1];
	char	city_flag[1+1];
	char	country_flag[1+1];
	char	fee_flag[1+1];
	double	fee_amt;
	double	fee_rate;
	double	min_amt;
	double	max_amt;
	int  	free_cnt;
	char	misc[125+1];
} TBL_Cst_bin_fee_inf;

typedef struct {
	char    branch_code[10+1];
	char    card_bin[12+1];
	char    use_flag[1+1];
	char    channel_no[2+1];
	char    txn_code[4+1];
	char    city_flag[1+1];
	char    country_flag[1+1];
	char    fee_flag[1+1];
	double  fee_amt;
	double  fee_rate;
	double  min_amt;
	double  max_amt;
	long     free_cnt;
	char    misc[125+1];
} TBL_Cst_fee_inf;

typedef struct {
	char issue_card_inst[4+1];
	int  comp_len;
	int  begin_pos;
	char branch_code[8+1];
	char dsp[32+1];
} TBL_Cst_Card_Branch;

/**add end**/

typedef struct {
	char        disc_cd[6];
	long        step_no;
	double      oper_rslt;
	double      operand1;
    char        operator1[2];
	double      operand2;
	char        operator2[2];
	double      operand3;
    char        rec_upd_usr_id[11];
	char        rec_upd_ts[15];
    char        rec_crt_ts[15];
	char		stxn_num[5];
} TBL_inf_disc_algo; 

typedef struct
{
	char	mcht_id[16];
	long	mcht_status;
	char	sa_limit_amt[13];
	char	sa_action[2];
	char	mcc[5];
	char	tcc[2];
	char	mcht_eng_addr[61];
	long	vis_act_flg;
	char	vis_mcht_id[16];
	long	mst_act_flg;
	char	mst_mcht_id[16];
	long	amx_act_flg;
	char	amx_mcht_id[16];
	long	dnr_act_flg;
	char	dnr_mcht_id[16];
	long	jcb_act_flg;
	char	jcb_mcht_id[16];
} Cst_mcht_supp_Def;
#endif
