/*****************************************************************************/
/*                              TOPLINK 2.0                                  */
/* Copyright (c) 2005 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/
#ifndef __BPIPC_INT_H
#define __BPIPC_INT_H

/* length of ISO8583 fields */
#define F000_MSG_TYPE_LEN        4

#define F002_LEN_LEN            2
#define F002_VAL_LEN            19
#define F003_LEN                6
#define F004_LEN                12
#define F007_LEN                10
#define F011_LEN                6
#define F012_LEN                6
#define F013_LEN                4
#define F014_LEN                4
#define F015_LEN                4
#define F018_LEN                4
#define F022_LEN                3
#define F025_LEN                2
#define F026_LEN                2
#define F032_LEN_LEN            2
#define F032_VAL_LEN            11
#define F033_LEN_LEN            2
#define F033_VAL_LEN            11
#define F035_LEN_LEN            2
#define F035_VAL_LEN            37
#define F036_LEN_LEN            3
#define F036_VAL_LEN            104
#define F037_LEN                12
#define F038_LEN                6
#define F039_LEN                2
#define F041_LEN                8
#define F042_LEN                15
#define F043_LEN                40
#define F049_LEN                3
#define F052_LEN                8
#define F053_LEN                16
#define F054_LEN_LEN            3
#define F054_VAL_LEN            120
#define F054_VAL_DB_LEN         40
#define F060_LEN_LEN            3
#define F060_VAL_LEN            30
#define F062_LEN_LEN            3
#define F062_VAL_LEN            200
#define F090_LEN                42
#define F099_LEN_LEN            2
#define F099_VAL_LEN            11
#define F122_LEN_LEN            3
#define F122_VAL_LEN            100
#define F064_LEN                8
#define F128_LEN                8


/* define field length other than ISO8583 fields */
#define SRV_ID_LEN                4
#define FLD_FLAG_LEN            1
#define FLD_TXN_NUM_LEN            4
#define FLD_TXN_CODE_LEN        3
#define FLD_SYS_SEQ_NUM_LEN        6
#define FLD_TRANS_CHNL_LEN        4
#define FLD_TRANS_STATE_LEN        1
#define FLD_FW_TRANS_ID_LEN        4
#define FLD_FW_TRANS_DATE_LEN        8
#define FLD_FW_TRANS_TIME_LEN        6
#define FLD_FW_TRANS_SSN_LEN        22
#define FLD_MID_TIME_LEN        10
#define FLD_MID_SSN_LEN         12
#define FLD_MID_TAG_LEN         8
#define FLD_MSQ_TYPE_LEN        16
#define FLD_TIME_STAMP_LEN      14      /*add By Metals Young, 2011-04-06*/
#define FLD_BP_HEADER           80     /*add By Metals Young, 2011-04-06*/
#define FLD_MISC_FLAG_LEN        32
#define FLD_MISC_LEN            128
#define FLD_ORDER_ID_LEN        18
#define FLD_BP_TYPE_LEN         3
#define FLD_CONSUME_TYPE_LEN    1
#define FLD_RESP_DESP_LEN    7
#define FLD_LOOP_LEN        512
#define KEY_RSP_LEN                32
#define KEY_REVSAL_LEN            32
#define KEY_CANCEL_LEN            32

/* define transaction status values */
/* ��������������ԭ���������� */
#define TRANS_STATE_REJ_BY_BP    "2"
#define TRANS_STATE_NO_BP_RSP    "9"

typedef struct {
    char    sMsgSrcId[SRV_ID_LEN];                                     /*1*/  
    char    sMsgDestId[SRV_ID_LEN];                                    /*2     */
    char    sMsqType[FLD_MSQ_TYPE_LEN];                                /*3     */
    char    sTimeStamp[FLD_TIME_STAMP_LEN];                            /*add by Metals Young, 2011-04-06*/
    char    sBpHeader[FLD_BP_HEADER];                                  /*add by Metals Young, 2011-04-06*/
    char    sSysSeqNum[FLD_SYS_SEQ_NUM_LEN];                           /*5     */
    char    sTransChnl[FLD_TRANS_CHNL_LEN];                            /*6     */
    char    sTransState[FLD_TRANS_STATE_LEN];                          /*7   */
    char    sFwTransId[FLD_FW_TRANS_ID_LEN];
    char    sFwTransDate[FLD_FW_TRANS_DATE_LEN];                                /*10    */
    char    sFwTransTime[FLD_FW_TRANS_TIME_LEN];                                /*10    */
    char    sFwTransSsn[FLD_FW_TRANS_SSN_LEN];                                /*10    */
    char    sMidTime[FLD_MID_TIME_LEN];
    char    sMidSsn[FLD_MID_SSN_LEN];
    char    sMidTag[FLD_MID_TAG_LEN];
    char    sKeyRsp[KEY_RSP_LEN];                                      /*11  */
    char    sKeyRevsal[KEY_REVSAL_LEN];                                /*12    */
    char    sKeyCancel[KEY_CANCEL_LEN];                                /*13    */
    char    sTxnNum[FLD_TXN_NUM_LEN];                                  /*15  */
    char    sTransCode[FLD_TXN_CODE_LEN];                              /*16  */
    char    sMsgType[F000_MSG_TYPE_LEN];                               /*17 */
    char    cF002Ind;                                                  /*18  */
    char    sPrimaryAcctNumLen[F002_LEN_LEN];                          /*19  */
    char    sPrimaryAcctNum[F002_VAL_LEN];                             /*20   */
    char    sProcessingCode[F003_LEN];                                 /*21   */
    char    sAmtTrans[F004_LEN];                                       /*22 */
    char    sTransmsnDateTime[F007_LEN];                               /*25 */
    char    sSysTraceAuditNum[F011_LEN];                               /*28 */
    char    sTimeLocalTrans[F012_LEN];                                 /*29   */
    char    sDateLocalTrans[F013_LEN];                                 /*30   */
    char    cF014Ind;                                                  /*31  */
    char    sDateExpr[F014_LEN];                                       /*32 */
    char    cF015Ind;
    char    sDateSettlmt[F015_LEN];                                    /*33    */
    char    sMchntType[F018_LEN];                                      /*35  */
    char    sPosEntryModeCode[F022_LEN];                               /*37 */
    char    sPosCondCode[F025_LEN];                                    /*39    */
    char    cF026Ind;                                                  /*40  */
    char    sPosPinCaptrCode[F026_LEN];                                /*41    */
    char    sAcqInstIdCodeLen[F032_LEN_LEN];                           /*44 */
    char    sAcqInstIdCode[F032_VAL_LEN];                              /*45  */
    char    sFwdInstIdCodeLen[F033_LEN_LEN];                           /*46 */
    char    sFwdInstIdCode[F033_VAL_LEN];                              /*47  */
    char    cF035Ind;                                                  /*48  */
    char    sTrack2DataLen[F035_LEN_LEN];                              /*49  */
    char    sTrack2Data[F035_VAL_LEN];                                 /*50   */
    char    cF036Ind;                                                  /*51  */
    char    sTrack3DataLen[F036_LEN_LEN];                              /*52  */
    char    sTrack3Data[F036_VAL_LEN];                                 /*53   */
    char    sRetrivlRefNum[F037_LEN];                                  /*54  */
    char    cF038Ind;                                                  /*55  */
    char    sAuthrIdResp[F038_LEN];                                    /*56    */
    char    sRespCode[F039_LEN];                                       /*57 */
    char    sCardAccptrTermnlId[F041_LEN];                             /*58   */
    char    sCardAccptrId[F042_LEN];                                   /*59 */
    char    sCardAccptrNameLoc[F043_LEN];                              /*60  */
    char    sCurrcyCodeTrans[F049_LEN];                                /*68    */
    char    cF052Ind;                                                  /*71  */
    char    sPinData[F052_LEN];                                        /*72    */
    char    cF053Ind;                                                  /*73  */
    char    sSecRelatdCtrlInfo[F053_LEN];                              /*74  */
    char    cF054Ind;                                                  /*75 */
    char    sAddtnlAmtLen[F054_LEN_LEN];                               /*76 */
    char    sAddtnlAmt[F054_VAL_LEN];                                  /*77  */
    char    sFldReservedLen[F060_LEN_LEN];                             /*80   */
    char    sFldReserved[F060_VAL_LEN];                                /*81  */
    char    cF062Ind;                                                  /*84  */
    char    sSwitchingDataLen[F062_LEN_LEN];                           /*85 */
    char    sSwitchingData[F062_VAL_LEN];                              /*86 */
    char    sOrigDataElemts[F090_LEN];
    char    cF122Ind;                                                  /*106 */
    char    sAcqInstResvdLen[F122_LEN_LEN];                            /*107   */
    char    sAcqInstResvd[F122_VAL_LEN];                               /*108*/
    char    cF064Ind ;                                                 /*112  */
    char    sMAC064[F064_LEN];                                         /*113  */
    char    cF128Ind ;                                                 /*114  */
    char    sMAC128[F128_LEN];                                         /*115  */
    char    sOrderId[FLD_ORDER_ID_LEN];
    char    sBpType[FLD_BP_TYPE_LEN];
    char    sConsumeType[FLD_CONSUME_TYPE_LEN];
    char    sRespDesp[FLD_RESP_DESP_LEN];
    char    sMiscFlag[FLD_MISC_FLAG_LEN];                              /*121 */
    char    sMisc1[FLD_MISC_LEN];                                       /*122*/
    char    sMisc2[FLD_MISC_LEN];
    char    sLoopReq[FLD_LOOP_LEN];
    char    sLoopRsp[FLD_LOOP_LEN];
} T_IpcIntBonusDef;

typedef struct {
    char    sTotLen[4];
    char    sVerNo[1];
    char    sToEnc[1];
    char    sCommCode[6];
    char    sCommType[1];
    char    sRcvId[4];
    char    sSndId[4];
    char    sSndSn[22];
    char    sSndDate[8];
    char    sSndTime[6];
    char    sTradeCode[6];
    char    sErrCode[2];
    char    sErrMsg[7];
    char    sReserved1[8];
} T_BpHeaderDef;

 int                 gnTimeOutFlag;
 char                gsTimeOutTs[27];
 char                gsTimeCurTs[15];

#endif
