#ifndef 	_XML_H
#define 	_XML_H

static void XmlSetError(char *pcFmt, ...);


mxml_node_t* XmlInit();


void XmlFree(mxml_node_t *pRoot);


void XmlSaveError(const char * psMessage);


mxml_node_t* XmlLoadString(char *psData);


mxml_node_t* XmlLoadFile(FILE *fp);


int XmlSaveString(mxml_node_t *pRoot, char *psData, int nSize);

mxml_node_t* FindNode(mxml_node_t* pRoot, char* name);

mxml_node_t* FindNode1Arrt(mxml_node_t* pRoot, char* name, char* arrt, char* value);

mxml_node_t* XmlAddList1Arrt(mxml_node_t *pNode, char *pNodeName, char *pNodeValue,char *pAttrName, char *pAttrValue);

mxml_node_t* XmlAddList(mxml_node_t *pNode, char *pNodeName, char *pAttrName, char *pAttrValue);

mxml_node_t* XmlAddListValue(mxml_node_t *pNode, char *pNodeName, char *pValue);


mxml_node_t* XmlAddIntList(mxml_node_t *pNode, char *pNodeName, char *pAttrName, char *nAttrValue);


int XmlSaveFile(mxml_node_t *pRoot, FILE *fp);


char * XmlError();




mxml_node_t* FindNodeArrt_next(mxml_node_t* pRoot, char* name, char* arrt, char* value);

int XmlElementCmp(mxml_node_t * pRoot, char * nodeName1, char * arrtName1, char * nodeName2, char * arrtName2);


int XmlGet(void* tree, char* pArrtName, char* pData, int nMaxSize);


int XmlSet(void* tree, char* pArrtName, char* pData);

#endif
