#ifndef _DBS_XML_H_
#define _DBS_XML_H_

#include "DbsDef.h"

typedef struct {
    long        usage_key;
    char        xml_version[4+1];
    char        xml_encoding[10+1];
    char        root_node[30+1];
    char        public_node[30+1];
    char        txn_node[30+1];
    char        insert_time[14+1];
} Tbl_xml_form_Def;


typedef struct {
    long        usage_key;
    char        txn_num[4+1];
    char        sp_dsp[250+1];
} Tbl_xml_dsp_Dsp;


typedef struct {
    long        usage_key;
    long        xml_index;
    long        i_chg_index;
    long        pos_index;
    char        option_flag[1+1];
    char        node_flag[1+1];
    char        recordsetname[30+1];
    char        recid[2+1];
    char        tag_name[20+1];
    long        max_len;
    char        tag_desc[30+1];
} Tbl_xml_Dsp;

typedef struct {
    long        usage_key;
    long        src_xml_index;
    long        src_chg_index;
    char        src_tag_name[20+1];
    char        src_tag_desc[30+1];
    long        dest_xml_index;
    long        dest_chg_index;
    char        dest_tag_name[20+1];
    char        dest_tag_desc[30+1];
    char        option_flag[1+1];
    long        max_len;
} Tbl_xml_Rule;

typedef struct {
    long        usage_key;
    long        convert_index;
    long        convert_flag;
    long        src_index;
    long        dest_index;
} Tbl_xml_Tsf;

typedef struct
{
	char  service_id[20+1]  ;
    char  trans_code[4+1]     ;
    char  dsp[256+1]        ;
} Tbl_txn_code_map_Def;


#define XML_RULE_OUT_TO_IN    1000
#define XML_RULE_IN_TO_OUT    2000
#define XML_REQ_INDEX            1
#define XML_RSP_INDEX            2
#define TXN_CODE_NUM_MAX        40
#define XML_DSP_MAX           2500
#define XML_RULE_MAX          2500
#define REQBUF_LENTH_MAX     10000
#define RSPBUF_LENTH_MAX     10000

#endif




