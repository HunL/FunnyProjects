#ifndef __PPCDDEF_H
#define __PPCDDEF_H

#define SOAP_LOG_MODE_NORMAL         "soapPPCD.log" , HT_LOG_MODE_NORMAL ,  __FILE__,__LINE__
#define SOAP_LOG_MODE_ERROR          "soapPPCD.log" , HT_LOG_MODE_ERROR  ,  __FILE__,__LINE__
#define SOAP_LOG_MODE_DEBUG          "soapPPCD.log" , HT_LOG_MODE_DEBUG  ,  __FILE__,__LINE__

#define PPCD_CARD_TYPE_LEN    1
#define PPCD_CARD_NUM_LEN     19
#define PPCD_ACCT_NUM_LEN     35
#define PPCD_PARTY_ID_LEN     30
#define PPCD_AREA_NUM_LEN     20
#define PPCD_FLOW_ID_LEN      55
#define PPCD_RET_CODE_LEN     10 
#define PPCD_RET_MSG_LEN      255
#define PPCD_BILL_SUM_LEN     20
#define PPCD_CURR_LEN         10
#define PPCD_AMT_LEN          20
#define PPCD_TRANS_DATE_LEN   20
#define PPCD_TRANS_TIME_LEN   20
#define PPCD_SYS_SERCH_NUM_LEN 55
#define PPCD_ORG_ID_LEN       20
#define PPCD_FLAG_LEN         1


/* ��ѯ���Ľṹ */
typedef struct _POS_BALANCE_REQ
{
    char cardType[PPCD_CARD_TYPE_LEN + 1];
    char cardNumber[PPCD_CARD_NUM_LEN + 1];
    char partyId[PPCD_PARTY_ID_LEN + 1];
    char areaNum[PPCD_AREA_NUM_LEN + 1];
    char flowId[PPCD_FLOW_ID_LEN + 1];
}POS_BALANCE_REQ;

typedef struct _POS_BALANCE_RSP
{
    char retCode[PPCD_RET_CODE_LEN + 1];
    char retMsg[PPCD_RET_MSG_LEN + 1];
    char billSum[PPCD_BILL_SUM_LEN +1];
}POS_BALANCE_RSP;


/* ���ѵĽṹ */
typedef struct _POS_PAYMENT_REQ
{
    char cardType[PPCD_CARD_TYPE_LEN + 1];
    char cardNumber[PPCD_CARD_NUM_LEN + 1];
    char accountNum[PPCD_ACCT_NUM_LEN + 1];
    char partyId[PPCD_PARTY_ID_LEN + 1];
    char areaNum[PPCD_AREA_NUM_LEN + 1];
    char flowId[PPCD_FLOW_ID_LEN + 1];
    char currency[PPCD_CURR_LEN + 1];
    char amount[PPCD_AMT_LEN + 1];
    char transDate[PPCD_TRANS_DATE_LEN + 1];
}POS_PAYMENT_REQ;

typedef struct _POS_PAYMENT_RSP
{
    char retCode[PPCD_RET_CODE_LEN + 1];
    char retMsg[PPCD_RET_MSG_LEN + 1];
    char billSum[PPCD_BILL_SUM_LEN + 1];
    char sysSearchsNum[PPCD_SYS_SERCH_NUM_LEN + 1];
    char orgId[PPCD_ORG_ID_LEN + 1];
    char flag[PPCD_FLAG_LEN + 1];
}POS_PAYMENT_RSP; 


/* �˻��Ľṹ */
typedef struct _POS_WITHDRAW_REQ
{
    char cardType[PPCD_CARD_TYPE_LEN + 1];
    char cardNumber[PPCD_CARD_NUM_LEN + 1];
    char accountNum[PPCD_ACCT_NUM_LEN + 1];
    char partyId[PPCD_PARTY_ID_LEN + 1];
    char areaNum[PPCD_AREA_NUM_LEN + 1];
    char flowId[PPCD_FLOW_ID_LEN + 1];
    char amount[PPCD_AMT_LEN + 1];
    char transDate[PPCD_TRANS_DATE_LEN + 1];
}POS_WITHDRAW_REQ;

typedef struct _POS_WITHDRAW_RSP
{
    char retCode[PPCD_RET_CODE_LEN + 1];
    char retMsg[PPCD_RET_MSG_LEN + 1];
    char billSum[PPCD_BILL_SUM_LEN + 1];
    char sysSearchsNum[PPCD_SYS_SERCH_NUM_LEN + 1];
    char orgId[PPCD_ORG_ID_LEN + 1];
}POS_WITHDRAW_RSP; 


/* ���������Ľṹ */
/*typedef struct _POS_ROLLBACK_REQ
{
    char cardType[PPCD_CARD_TYPE_LEN + 1];
    char cardNumber[PPCD_CARD_NUM_LEN + 1];
    char accountNum[PPCD_ACCT_NUM_LEN + 1];
    char partyId[PPCD_PARTY_ID_LEN + 1];
    char areaNum[PPCD_AREA_NUM_LEN + 1];
    char flowId[PPCD_FLOW_ID_LEN + 1];
    char oldFlowId[PPCD_FLOW_ID_LEN + 1];
    char amount[PPCD_AMT_LEN + 1];
    char transDate[PPCD_TRANS_DATE_LEN + 1];
}POS_ROLLBACK_REQ;

typedef struct _POS_ROLLBACK_RSP
{
    char retCode[PPCD_RET_CODE_LEN + 1];
    char retMsg[PPCD_RET_MSG_LEN + 1];
}POS_ROLLBACK_RSP;
*/

/* ��ѯ������Ϣ�ṹ */
typedef struct _POS_TRANS_CHECK_REQ
{
    /* ���� */
    char cardNumber[PPCD_CARD_NUM_LEN + 1];
    char oldFlowId[PPCD_FLOW_ID_LEN + 1];
    char transDate[PPCD_TRANS_DATE_LEN + 1];
}POS_TRANS_CHECK_REQ;

typedef struct _POS_TRANS_CHECK_RSP
{
    char transDate[PPCD_TRANS_DATE_LEN + 1];
    char retCode[PPCD_RET_CODE_LEN + 1];
    char retMsg[PPCD_RET_MSG_LEN + 1];
    char transTime[PPCD_TRANS_TIME_LEN + 1];
    char amount[PPCD_AMT_LEN + 1];
}POS_TRANS_CHECK_RSP;

/* ��������ṹ */
typedef struct _POS_REJECTED_REQ
{
    char cardType[PPCD_CARD_TYPE_LEN + 1];
    char cardNumber[PPCD_CARD_NUM_LEN + 1];
    char accountNum[PPCD_ACCT_NUM_LEN + 1];
    char partyId[PPCD_PARTY_ID_LEN + 1]; 
	char areaNum[PPCD_AREA_NUM_LEN + 1];
    char amount[PPCD_AMT_LEN + 1];
    char transDate[PPCD_TRANS_DATE_LEN + 1];
    char oldFlowId[PPCD_FLOW_ID_LEN + 1]; 
    char flowId[PPCD_FLOW_ID_LEN + 1];
}POS_REJECTED_REQ;

/* ����Ӧ��ṹ */
typedef struct _POS_REJECTED_RSP
{
    char retCode[PPCD_RET_CODE_LEN + 1];
    char retMsg[PPCD_RET_MSG_LEN + 1];
}POS_REJECTED_RSP;

/* ��������ṹ */
typedef struct _POS_ROLLBACK_REQ
{
   char transDate[PPCD_TRANS_DATE_LEN + 1]; 
   char oldFlowId[PPCD_FLOW_ID_LEN + 1];
   char flowId[PPCD_FLOW_ID_LEN + 1];
}POS_ROLLBACK_REQ;

/* ����Ӧ��ṹ */
typedef struct _POS_ROLLBACK_RSP
{
    char retCode[PPCD_RET_CODE_LEN + 1];
    char retMsg[PPCD_RET_MSG_LEN + 1];
}POS_ROLLBACK_RSP;

int PPCDPosBalance(POS_BALANCE_REQ *, POS_BALANCE_RSP *);
int PPCDPosPayment(POS_PAYMENT_REQ *, POS_PAYMENT_RSP *);
int PPCDPosWithdraw(POS_WITHDRAW_REQ *, POS_WITHDRAW_RSP *);
//int PPCDPosRollBack(POS_ROLLBACK_REQ *, POS_ROLLBACK_RSP *);
int PPCDPosTransCheck(POS_TRANS_CHECK_REQ *, POS_TRANS_CHECK_RSP *);
int PPCDPosRejected(POS_REJECTED_REQ *, POS_REJECTED_RSP *);
int PPCDPosRollBack(POS_ROLLBACK_REQ *, POS_ROLLBACK_RSP *);

#endif
