/*****************************************************************************/
/*                              TOPLINK 2.0                                  */
/* Copyright (c) 2005 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/

#ifndef __ON_MON_H
#define __ON_MON_H

#define ON_MON_TURN_MODE             "MONITOR_TURN_YES_NO"
#define ON_MON_TURN_OFF              0
#define ON_MON_TURN_ON               1

#define ON_MON_MODE_ERROR            1
#define ON_MON_MODE_NORMAL           2

#define ON_MON_MSQ_NUM_MAX           "MONITOR_MSQ_NUM_MAX"
#define ON_MON_MSQ_NUM_MAX_DEFAULT   30

#define ON_MON_MSQ_KEY               "MONITOR_MSQ_KEY"

typedef struct
{
    char    sMonType[1 + 1];
    char    sMonLevel[1 + 1];
    char    sMonDate[14 + 1];
} T_Monitor;

#endif
