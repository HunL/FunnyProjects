#ifndef _TLV_API_H
#define _TLV_API_H

typedef struct _tlv_buf_t {
	int  size;
	char *data;
} tlv_buf_t;

typedef struct _tlv_data_t {
	tlv_buf_t tag;
	tlv_buf_t val;
} tlv_data_t;

int parse_tlv_data(char *buf, char *tag, char *src, int size);

int parse_tlv_data_tmplt(char *buf, char *tag, char *tmplt, char *src, int size);

int count_tlv_substring(char *src, int size);

int unpack_tlv_data(tlv_data_t **dst, char *src, int size);

int pack_tlv_data(char *buf, char *tag, char *src, int size);

#endif


