#ifndef __COMMON_H
#define __COMMON_H




/*****************************************************************************/
/* FUNC:   void CommonGetCurrentDate (char *sCurrentDate);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentDate   -- the string of current date                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system date with the format (YYYYMMDD).                   */
/*         NULL is added at the end.                                         */
/*****************************************************************************/
void  CommonGetCurrentDate(char *sCurrentDate);

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentTime (char *sCurrentTime);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentTime   -- the string of current time                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system time with the format (YYYYMMDDhhmmss).             */
/*         NULL is added at the end.                                         */
/*****************************************************************************/
void CommonGetCurrentTime(char *sCurrentTime);



#endif

