/*****************************************************************************/
/*                              TOPLINK 2.0                                  */
/* Copyright (c) 2005 Shanghai Huateng Software Systems Co., Ltd.            */
/* All Rights Reserved                                                       */
/*****************************************************************************/
#ifndef __IPC_INT_H
#define __IPC_INT_H

/* length of Header fields */
#define HEADER_BUF_LEN                46

/* length of ISO8583 fields */
#define F000_MSG_TYPE_LEN        4

#define F002_LEN_LEN            2
#define F002_VAL_LEN            19
#define F003_LEN                6
#define F004_LEN                12
#define F005_LEN                12
#define F006_LEN                12
#define F007_LEN                10
#define F009_LEN                8
#define F010_LEN                8
#define F011_LEN                6
#define F012_LEN                6
#define F013_LEN                4
#define F014_LEN                4
#define F015_LEN                4
#define F016_LEN                4
#define F018_LEN                4
#define F019_LEN                3
#define F020_LEN                3
#define F021_LEN                3
#define F022_LEN                3
#define F023_LEN                3
#define F024_LEN                3
#define F025_LEN                2
#define F026_LEN                2
#define F028_LEN                9
#define F032_LEN_LEN            2
#define F032_VAL_LEN            11
#define F033_LEN_LEN            2
#define F033_VAL_LEN            11
#define F035_LEN_LEN            2
#define F035_VAL_LEN            37
#define F036_LEN_LEN            3
#define F036_VAL_LEN            104
#define F037_LEN                12
#define F038_LEN                6
#define F039_LEN                2
#define F041_LEN                8
#define F042_LEN                15
#define F043_LEN                40
#define F044_LEN_LEN            2
#define F044_VAL_LEN            25
#define F045_LEN_LEN            2
#define F045_VAL_LEN            79
#define F046_LEN_LEN             3   /*add by tangbin 090709*/
#define F046_VAL_LEN            255   /*add by tangbin 090709*/
#define F048_LEN_LEN            3
#define F048_VAL_LEN            512
#define F049_LEN                3
#define F050_LEN                3
#define F051_LEN                3
#define F052_LEN                8
#define F053_LEN                16
#define F054_LEN_LEN            3
#define F054_VAL_LEN            120
#define F054_VAL_DB_LEN         40
#define F055_LEN_LEN			3
#define F055_LEN				255
#define F057_LEN_LEN            3
#define F057_VAL_LEN            100
#define F058_LEN_LEN            3
#define F058_VAL_LEN            100
#define F059_LEN_LEN            3
#define F059_VAL_LEN            600
#define F060_LEN_LEN            3
#define F060_VAL_LEN            30
#define F061_LEN_LEN            3
#define F061_VAL_LEN            200
#define F062_LEN_LEN            3
#define F062_VAL_LEN            200
#define F063_LEN_LEN            3
#define F063_VAL_LEN            200
#define F066_LEN                1
#define F068_LEN                3
#define F069_LEN                3
#define F070_LEN                3
#define F074_LEN                10
#define F075_LEN                10
#define F076_LEN                10
#define F077_LEN                10
#define F078_LEN                10
#define F079_LEN                10
#define F080_LEN                10
#define F081_LEN                10
#define F082_LEN                12
#define F083_LEN                12
#define F084_LEN                12
#define F085_LEN                12
#define F086_LEN                16
#define F087_LEN                16
#define F088_LEN                16
#define F089_LEN                16
#define F090_LEN                42
#define F093_LEN                5
#define F094_LEN                7
#define F095_LEN                42
#define F096_LEN                8
#define F097_LEN                17
#define F099_LEN_LEN            2
#define F099_VAL_LEN            11
#define F100_LEN_LEN            2
#define F100_VAL_LEN            11
#define F102_LEN_LEN            2
#define F102_VAL_LEN            28
#define F103_LEN_LEN            2
#define F103_VAL_LEN            28
#define F104_LEN_LEN            3
#define F104_VAL_LEN            100
#define F112_LEN_LEN            3
#define F112_VAL_LEN            248
#define F121_LEN_LEN            3
#define F121_VAL_LEN            100
#define F122_LEN_LEN            3
#define F122_VAL_LEN            100
#define F123_LEN_LEN            3
#define F123_VAL_LEN            100
#define F125_LEN                8
#define F126_LEN_LEN            3
#define F126_VAL_LEN            50
#define F064_LEN                8
#define F128_LEN                8

/* define field indicator value */
#define FLD_IND_VAL_Y            'Y'
#define FLD_IND_VAL_N            'N'

/* define sub field in Field 60 */
#define CHANNEL_TYPE_UNK        "00"
#define CHANNEL_TYPE_ATM        "01"
#define CHANNEL_TYPE_CDM        "02"
#define CHANNEL_TYPE_POS        "03"
#define CHANNEL_TYPE_EDC        "04"
#define CHANNEL_TYPE_SELF        "05"
#define CHANNEL_TYPE_CNT        "06"
#define CHANNEL_TYPE_INTNT        "07"
#define CHANNEL_TYPE_WIRELESS    "08"
#define CHANNEL_TYPE_TLPH        "09"
#define CHANNEL_TYPE_LOAD        "10"
#define CHANNEL_TYPE_MOB_POS    "11"
/***20060919***/
#define CHANNEL_TYPE_MOB_NMG    "13"

#define	BANK_INST_ID 	"03060000"
#define	CUP_INST_ID     "00010000"
#define	DFT_BANK_ID     "999900"

typedef struct {
    char    sF060MsgRsnCode[4];
    char    sF060Reserved1[1];
    char    sF060TermCap[1];
    char    sF060ChipCond[1];
    char    sF060Reserved4[1];
    char    sF060ChannelType[2];
    char    sF060Reserved7[1];
    char    sF060ChipAuthRelia[1];
    char    sF060ElecComm[2];
    char    sF060Reserved[16];
} T_F060Def;

/* define field length other than ISO8583 fields */
#define SRV_ID_LEN                4
#define FLD_FLAG_LEN            1
#define FLD_TXN_NUM_LEN            4
#define FLD_TXN_CODE_LEN        3
#define FLD_SYS_SEQ_NUM_LEN        6
#define FLD_TRANS_TYPE_LEN        1
#define FLD_TRANS_STATE_LEN        1
#define FLD_HOST_DATE_LEN        8
#define FLD_HOST_SSN_LEN        12
#define FLD_TERM_SSN_LEN        12
#define FLD_HOST_TRANS_FEE_LEN    12
#define FLD_TLR_NUM_LEN            8
#define FLD_INST_LEN            15
#define FLD_MSQ_TYPE_LEN        16
#define FLD_TIME_STAMP_LEN      14      /*add By Metals Young, 2011-04-06*/
#define FLD_GF_HEADER           256     /*add By Metals Young, 2011-04-06*/
#define FLD_MISC_FLAG_LEN        32
#define FLD_MISC_LEN            128
#define KEY_RSP_LEN                32
#define KEY_REVSAL_LEN            32
#define KEY_CANCEL_LEN            32

/* define transaction status values */
#define TRANS_TYPE_ATM            "A"
#define TRANS_TYPE_POS            "P"
#define TRANS_TYPE_GM            "G"
#define TRANS_TYPE_NET            "N"
#define TRANS_TYPE_OTHER        "O"
#define TRANS_TYPE_ERR_NOTICE    "E"

#define TRANS_STATE_NO_RSP        "0"
#define TRANS_STATE_SUCC        "1"
#define TRANS_STATE_REJ_BY_CUPS    "2"
#define TRANS_STATE_TIME_OUT    "3"
#define TRANS_STATE_REJ_BY_HOST    "4"
#define TRANS_STATE_REJ_PIN_MAC    "5"
#define TRANS_STATE_REJ_BY_FE    "6"
#define TRANS_STATE_NO_ACCT_RSP    "7"
#define TRANS_STATE_ACCT_TO        "8"
#define TRANS_STATE_HAD_RETURN        "R" 

#define TRANS_STATE_AUTH_COMP    "9" /* only used in tbl_auth */
#define TRANS_STATE_AUTH_ADD    "A" /* only used in tbl_auth */

#define TRANS_STATE_NO_RSP_C        '0'
#define TRANS_STATE_SUCC_C            '1'
#define TRANS_STATE_REJ_BY_CUPS_C    '2'
#define TRANS_STATE_TIME_OUT_C        '3'
#define TRANS_STATE_REJ_BY_HOST_C    '4'
#define TRANS_STATE_REJ_PIN_MAC_C    '5'
#define TRANS_STATE_REJ_BY_FE_C        '6'
#define TRANS_STATE_NO_ACCT_RSP_C    '7'
#define TRANS_STATE_ACCT_TO_C        '8'
#define TRANS_STATE_AUTH_COMP_C        '9' /* only used in tbl_auth */

/* tbl_txn.revsal_flag, tbl_txn.cancel_flag */
#define REV_CAN_FLAG_NULL          '-'
#define REV_CAN_FLAG_NORMAL        '0'
#define REV_CAN_FLAG_HAD           '1'
#define REV_CAN_FLAG_PTH           '2'
#define REV_CAN_FLAG_FINISH        '3'

#define TRANS_CODE_REVSAL        'C'
#define MSG_TYPE_REVSAL            "0420"

#define MSG_TYPE_CONFIRM        "0220"

/* define default value for F014 */
#define F014_DEFAULT            "0000"

/* define for F022 */
#define INDEX_F022_PIN            2
#define F022_WITH_PIN            '1'
#define F022_WITH_OUT_PIN        '2'

#define INDEX_F022_TRC            1
#define F022_WITH_TRC            '2'
#define F022_WITH_OUT_TRC        '1'

/* actual len for F032, F033, F100 */
#define INST_ID_LEN                8
/* CUP inst id */
#define CS_SC_CODE                "CS_SC_CODE"

/* define F039 value used in Switch */
#define F039_SUCCESS             "00"
#define F039_CVN_ERROR           "05"
#define F039_PARTIAL_APPROVED    "10"
#define F039_VIP_APPROVED        "11"
#define F039_INVALID_TXN         "12"
#define F039_INVALID_AMT         "13"
#define F039_INVALID_PAN         "14"
#define F039_APPROVED_UPD_T3     "16"
#define F039_SUSP_MALFUNC        "22"
#define F039_ORIG_TXN_NOT_FOUND  "25"
#define F039_NOT_SUPPORT         "40"
#define F039_BALAN_NOT_ENOUGH    "51"
#define F039_PIN_NOT_PAS         "55"
#define F039_INCORRECT_AMT       "64"
#define F039_LIMIT_AMT           "61"
#define F039_PAS_OVER            "75"
#define F039_INST_ERROR          "92"
#define F039_DUPL_TXN            "94"
#define F039_MAL_FUNCTION        "96"
#define F039_TIME_OUT            "98"
#define F039_PIN_ERROR           "99"
#define F039_MAC_FAIL            "A0"
#define F039_SUCC_FAULT_2        "A2"
#define F039_SUCC_FAULT_4        "A4"
#define F039_SUCC_FAULT_5        "A5"
#define F039_SUCC_FAULT_6        "A6"
#define F039_NO_SEND             "66"

/* define len len for F057 data */
#define F057_DATA_FM_LEN        2
#define F057_DATA_FM_TA            "TA"

/* reason code in F060 */
#define REASON_CODE_LATE_RSP    "4006"
#define REASON_CODE_SEND_ERR    "4013"
#define REASON_CODE_TIME_OUT    "4021"

#define IsRspSuccess(x)         (!memcmp(x, F039_SUCCESS, F039_LEN) || !memcmp(x, F039_PARTIAL_APPROVED, F039_LEN) || !memcmp(x, F039_VIP_APPROVED, F039_LEN) || !memcmp(x, F039_APPROVED_UPD_T3, F039_LEN) || !memcmp(x, F039_SUCC_FAULT_2, F039_LEN) || !memcmp(x, F039_SUCC_FAULT_4, F039_LEN) || !memcmp(x, F039_SUCC_FAULT_5, F039_LEN) || !memcmp(x, F039_SUCC_FAULT_6, F039_LEN) )

/* IPC for transaction and management message */
/* excluding field:
    F066
    F070
    F074
    F075
    F076
    F077
    F078
    F079
    F080
    F081
    F082
    F084
    F086
    F087
    F088
    F089
    F097
    F099
*/
typedef struct {
    char    sMsgSrcId[SRV_ID_LEN];                                     /*1*/  
    char    sMsgDestId[SRV_ID_LEN];                                    /*2     */
    char    sMsqType[FLD_MSQ_TYPE_LEN];                                /*3     */
    char    sTimeStamp[FLD_TIME_STAMP_LEN];                            /*add by Metals Young, 2011-04-06*/
    char    sGfHeader[FLD_GF_HEADER];                                  /*add by Metals Young, 2011-04-06*/
    char    sConvTxnNum[FLD_FLAG_LEN];                                 /*4    */
    char    sSysSeqNum[FLD_SYS_SEQ_NUM_LEN];                           /*5     */
    char    sTransType[FLD_TRANS_TYPE_LEN];                            /*6     */
    char    sTransState[FLD_TRANS_STATE_LEN];                          /*7   */
    char    sHostDate[FLD_HOST_DATE_LEN];                              /*8   */
    char    sHostSSN[FLD_HOST_SSN_LEN];                                /*9     */
    char    sTermSSN[FLD_TERM_SSN_LEN];                                /*10    */
    char    sKeyRsp[KEY_RSP_LEN];                                      /*11  */
    char    sKeyRevsal[KEY_REVSAL_LEN];                                /*12    */
    char    sKeyCancel[KEY_CANCEL_LEN];                                /*13    */
    char    sHeaderBuf[HEADER_BUF_LEN];                                /*14    */
    char    sTxnNum[FLD_TXN_NUM_LEN];                                  /*15  */
    char    sTransCode[FLD_TXN_CODE_LEN];                              /*16  */
    char    sMsgType[F000_MSG_TYPE_LEN];                               /*17 */
    char    cF002Ind;                                                  /*18  */
    char    sPrimaryAcctNumLen[F002_LEN_LEN];                          /*19  */
    char    sPrimaryAcctNum[F002_VAL_LEN];                             /*20   */
    char    sProcessingCode[F003_LEN];                                 /*21   */
    char    sAmtTrans[F004_LEN];                                       /*22 */
    char    sAmtSettlmt[F005_LEN];                                     /*23   */
    char    sAmtCdhldrBil[F006_LEN];                                   /*24 */
    char    sTransmsnDateTime[F007_LEN];                               /*25 */
    char    sConvRateSettlmt[F009_LEN];                                /*26    */
    char    sConvRateCdhldrBil[F010_LEN];                              /*27  */
    char    sSysTraceAuditNum[F011_LEN];                               /*28 */
    char    sTimeLocalTrans[F012_LEN];                                 /*29   */
    char    sDateLocalTrans[F013_LEN];                                 /*30   */
    char    cF014Ind;                                                  /*31  */
    char    sDateExpr[F014_LEN];                                       /*32 */
    char    cF015Ind;
    char    sDateSettlmt[F015_LEN];                                    /*33    */
    char    sDateConv[F016_LEN];                                       /*34 */
    char    sMchntType[F018_LEN];                                      /*35  */
    char    cF019Ind;
    char    sAcqInstCntryCode[F019_LEN];                               /*36 */
    char    sF020Val[F020_LEN];                                        /*add by Metals Young, 2011-04-06*/
    char    sF021Val[F021_LEN];                                        /*add by Metals Young, 2011-04-06*/
    char    sPosEntryModeCode[F022_LEN];                               /*37 */
    char    cF023Ind;
    char    sCardSeqId[F023_LEN];                                      /*38  */
    char    sF024Val[F024_LEN];                                        /*add By Metals Young, 2011-04-06*/
    char    sPosCondCode[F025_LEN];                                    /*39    */
    char    cF026Ind;                                                  /*40  */
    char    sPosPinCaptrCode[F026_LEN];                                /*41    */
    char    cF028Ind;                                                  /*42  */
    char    sAmtTransFee[F028_LEN];                                    /*43    */
    char    sAcqInstIdCodeLen[F032_LEN_LEN];                           /*44 */
    char    sAcqInstIdCode[F032_VAL_LEN];                              /*45  */
    char    sFwdInstIdCodeLen[F033_LEN_LEN];                           /*46 */
    char    sFwdInstIdCode[F033_VAL_LEN];                              /*47  */
    char    cF035Ind;                                                  /*48  */
    char    sTrack2DataLen[F035_LEN_LEN];                              /*49  */
    char    sTrack2Data[F035_VAL_LEN];                                 /*50   */
    char    cF036Ind;                                                  /*51  */
    char    sTrack3DataLen[F036_LEN_LEN];                              /*52  */
    char    sTrack3Data[F036_VAL_LEN];                                 /*53   */
    char    sRetrivlRefNum[F037_LEN];                                  /*54  */
    char    cF038Ind;                                                  /*55  */
    char    sAuthrIdResp[F038_LEN];                                    /*56    */
    char    sRespCode[F039_LEN];                                       /*57 */
    char    sCardAccptrTermnlId[F041_LEN];                             /*58   */
    char    sCardAccptrId[F042_LEN];                                   /*59 */
    char    sCardAccptrNameLoc[F043_LEN];                              /*60  */
    char    cF044Ind;                                                  /*61  */
    char    sAddtnlRespCodeLen[F044_LEN_LEN];                          /*62  */
    char    sAddtnlRespCode[F044_VAL_LEN];                             /*63   */
    char    sTrack1DataLen[F045_LEN_LEN];                              /*64  */
    char    sTrack1Data[F045_VAL_LEN];                                 /*65 */
    char    cF046Ind;
    char    sF046Len[F046_LEN_LEN];
    char    sF046Value[F046_VAL_LEN];
    char    cF048Ind;
    char    sAddtnlDataPrivateLen[F048_LEN_LEN];                       /*66 */
    char    sAddtnlDataPrivate[F048_VAL_LEN];                          /*67  */
    char    sCurrcyCodeTrans[F049_LEN];                                /*68    */
    char    sCurrcyCodeSettlmt[F050_LEN];                              /*69  */
    char    sCurrcyCodeCdhldrBil[F051_LEN];                            /*70    */
    char    cF052Ind;                                                  /*71  */
    char    sPinData[F052_LEN];                                        /*72    */
    char    cF053Ind;                                                  /*73  */
    char    sSecRelatdCtrlInfo[F053_LEN];                              /*74  */
    char    cF054Ind;                                                  /*75 */
    char    sAddtnlAmtLen[F054_LEN_LEN];                               /*76 */
    char    sAddtnlAmt[F054_VAL_LEN];                                  /*77  */
	char    cICDataInd;
	char    sICDataLen[F055_LEN_LEN];
	char    sICData[F055_LEN];
    char    sAddtnlDataLen[F057_LEN_LEN];                              /*78  */
    char    sAddtnlData[F057_VAL_LEN];                                 /*79 */
    char    cF058Ind;                                                  /*add by Metals Young, 2011-04-06*/                     
    char    sF058Len[F058_LEN_LEN];                                    /*add by Metals Young, 2011-04-06*/
    char    sF058Val[F058_VAL_LEN];                                    /*add by Metals Young, 2011-04-06*/
    char    cF059Ind;                                                  /*add by Metals Young, 2011-04-06*/ 
    char    sF059Len[F059_LEN_LEN];                                    /*add by Metals Young, 2011-04-06*/
    char    sF059Val[F059_VAL_LEN];                                    /*add by Metals Young, 2011-04-06*/
    char    sFldReservedLen[F060_LEN_LEN];                             /*80   */
    char    sFldReserved[F060_VAL_LEN];                                /*81  */
    char    cF061Ind; 
    char    sChAuthInfoLen[F061_LEN_LEN];                              /*82  */
    char    sChAuthInfo[F061_VAL_LEN];                                 /*83   */
    char    cF062Ind;                                                  /*84  */
    char    sSwitchingDataLen[F062_LEN_LEN];                           /*85 */
    char    sSwitchingData[F062_VAL_LEN];                              /*86 */
    char    cF063Ind; 
    char    sFinaclNetDataLen[F063_LEN_LEN];                           /*87 */
    char    sFinaclNetData[F063_VAL_LEN];                              /*88 */
    char    sF066Val[F066_LEN];                                        /*add by Metals Young, 2011-04-06*/
    char    sF068Val[F068_LEN];                                        /*add by Metals Young, 2011-04-06*/
    char    sF069Val[F069_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sNetwkMgmtInfoCode[F070_LEN];
	char    sF074Val[F074_LEN];                                        /*add by Metals Young, 2011-04-06*/                                        
	char    sF075Val[F075_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF076Val[F076_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF077Val[F077_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF078Val[F078_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF079Val[F079_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF080Val[F080_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF081Val[F081_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF082Val[F082_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF083Val[F083_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF084Val[F084_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF085Val[F085_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF086Val[F086_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF087Val[F087_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF088Val[F088_LEN];                                        /*add by Metals Young, 2011-04-06*/
	char    sF089Val[F089_LEN];                                        /*add by Metals Young, 2011-04-06*/
    char    sOrigDataElemts[F090_LEN];                                 /*89   */
    char    sF093Val[F093_LEN];                                        /*add by Metals Young, 2011-04-06*/    
    char    sF094Val[F094_LEN];                                        /*add by Metals Young, 2011-04-06*/
    char    sReplacementAmts[F095_LEN];                                /*90    */
    char    sMsgSecurityCode[F096_LEN];                                /*91 */
    char    sF097Val[F097_LEN];                                        /*add by Metals Young, 2011-04-06*/                  
    char    cF100Ind; 
    char    sRcvgInstIdCodeLen[F100_LEN_LEN];                          /*92  */
    char    sRcvgInstIdCode[F100_VAL_LEN];                             /*93   */
    char    cF102Ind;                                                  /*94  */
    char    sAcctId1Len[F102_LEN_LEN];                                 /*95   */
    char    sAcctId1[F102_VAL_LEN];                                    /*96    */
    char    cF103Ind;                                                  /*97  */
    char    sAcctId2Len[F103_LEN_LEN];                                 /*98   */
    char    sAcctId2[F103_VAL_LEN];                                    /*99    */
    char    cF104Ind;                                                  /*100 */
    char    sTransDescrptLen[F104_LEN_LEN];                            /*101   */
    char    sTransDescrpt[F104_VAL_LEN];                               /*102*/
    char    sF112Len[F112_LEN_LEN];                                    /*add by Metals Young, 2011-04-06*/ 
    char    sF112Val[F112_VAL_LEN];                                    /*add by Metals Young, 2011-04-06*/            
    char    cF121Ind;                                                  /*103 */
    char    sNationalSwResvedLen[F121_LEN_LEN];                        /*104   */
    char    sNationalSwResved[F121_VAL_LEN];                           /*105*/
    char    cF122Ind;                                                  /*106 */
    char    sAcqInstResvdLen[F122_LEN_LEN];                            /*107   */
    char    sAcqInstResvd[F122_VAL_LEN];                               /*108*/
    char    cF123Ind;                                                  /*109 */
    char    sIssrInstResvdLen[F123_LEN_LEN];                           /*110*/
    char    sIssrInstResvd[F123_VAL_LEN];                              /*111 */
    char    sF125Val[F125_LEN];                                        /*add by Metals Young, 2011-04-06*/     
    char    sF126Len[F126_LEN_LEN];                                    /*add by Metals Young, 2011-04-06*/ 
    char    sF126Val[F126_VAL_LEN];                                    /*add by Metals Young, 2011-04-06*/ 
    char    cF064Ind ;                                                 /*112  */
    char    sMAC064[F064_LEN];                                         /*113  */
    char    cF128Ind ;                                                 /*114  */
    char    sMAC128[F128_LEN];                                         /*115  */
    char    sHostTransFee1[FLD_HOST_TRANS_FEE_LEN];                    /*116   */
    char    sHostTransFee2[FLD_HOST_TRANS_FEE_LEN];                    /*117   */
    char    sTlrNum[FLD_TLR_NUM_LEN];                                  /*118 */
    char    sOpenInst[FLD_INST_LEN];                                   /*119*/
    char    sStlmInst[FLD_INST_LEN];                                   /*120*/
    char    sMiscFlag[FLD_MISC_FLAG_LEN];                              /*121 */
    char    sMisc[FLD_MISC_LEN];                                       /*122*/
} T_IpcIntTxnDef;                                                             

/* excluding field:
    RevsalFlag, SSN
    CancelFlag, SSN
    sTermSSN
    F002 F004 F005 F006 F009 F014 F016 F018 F019 F022 F023 F025 F026 F028
    F035 F036 F038 F041 F042 F043 F044 F045 F049 F051 F052 F053 F054 F057
    F059 F060 F061 F062 F063 F090 F095 F102 F103 F104 F121 F122 F123
    sHostTransFee
    sCardType
    sBranchNum
    sBatchFlag
    sBatchDate
*/
typedef struct {
    char    sMsgSrcId[SRV_ID_LEN];
    char    sMsgDestId[SRV_ID_LEN];
    char    sMsqType[FLD_MSQ_TYPE_LEN];
    char    sTimeStamp[FLD_TIME_STAMP_LEN];                            /*add by Metals Young, 2011-04-06*/
    char    sGfHeader[FLD_GF_HEADER];                                  /*add by Metals Young, 2011-04-06*/
    char    cConvTxnNum;
    char    sSysSeqNum[FLD_SYS_SEQ_NUM_LEN];
    char    sTransType[FLD_TRANS_TYPE_LEN];
    char    sTransState[FLD_TRANS_STATE_LEN];
    char    sHostDate[FLD_HOST_DATE_LEN];
    char    sHostSSN[FLD_HOST_SSN_LEN];
    char    sTermSSN[FLD_TERM_SSN_LEN];
    char    sKeyRsp[KEY_RSP_LEN];
    char    sKeyRevsal[KEY_REVSAL_LEN];
    char    sKeyCancel[KEY_CANCEL_LEN];
    char    sHeaderBuf[HEADER_BUF_LEN];
    char    sTxnNum[FLD_TXN_NUM_LEN];
    char    sTransCode[FLD_TXN_CODE_LEN];
    char    sMsgType[F000_MSG_TYPE_LEN];
    char    sProcessingCode[F003_LEN];
    char    sTransmsnDateTime[F007_LEN];
    char    sSysTraceAuditNum[F011_LEN];
    char    sTimeLocalTrans[F012_LEN];
    char    sDateLocalTrans[F013_LEN];
	char    cF015Ind;
    char    sDateSettlmt[F015_LEN];
    char    sAcqInstIdCodeLen[F032_LEN_LEN];
    char    sAcqInstIdCode[F032_VAL_LEN];
    char    sFwdInstIdCodeLen[F033_LEN_LEN];
    char    sFwdInstIdCode[F033_VAL_LEN];
    char    sRespCode[F039_LEN];
    char    sCardAccptrTermnlId[F041_LEN];                           
    char    sCardAccptrId[F042_LEN]; 
	char    cF048Ind;
    char    sAddtnlDataPrivateLen[F048_LEN_LEN];
    char    sAddtnlDataPrivate[F048_VAL_LEN];
    char    sCurrcyCodeSettlmt[F050_LEN];
    char    cF053Ind;
    char    sSecurityRelatedInfo[F053_LEN];
    char    sSettlmtCode[F066_LEN];
    char    sNetwkMgmtInfoCode[F070_LEN];
    char    sCreditsNum[F074_LEN];
    char    sCreditsRevsalNum[F075_LEN];
    char    sDebitsNum[F076_LEN];
    char    sDebitsRevsalNum[F077_LEN];
    char    sTransferNum[F078_LEN];
    char    sTransferRevsalNum[F079_LEN];
    char    sInquryNum[F080_LEN];
    char    sAuthrNum[F081_LEN];
    char    sCreditsProcesFeeAmt[F082_LEN];
    char    sDebitsProcesFeeAmt[F084_LEN];
    char    sCreditsAmt[F086_LEN];
    char    sCreditsRevsalAmt[F087_LEN];
    char    sDebitsAmt[F088_LEN];
    char    sDebitsRevsalAmt[F089_LEN];
    char    sMsgSecurityCode[F096_LEN];
    char    sAmtNetSettlmt[F097_LEN];
    char    sSettlmtInstIdCodeLen[F099_LEN_LEN];
    char    sSettlmtInstIdCode[F099_VAL_LEN];
	char    cF100Ind;
    char    sRcvgInstIdCodeLen[F100_LEN_LEN];
    char    sRcvgInstIdCode[F100_VAL_LEN];
    char    cF064;
    char    sMAC064[F064_LEN];
    char    cF128Ind ;
    char    sMAC128[F128_LEN];
    char    sMiscFlag[FLD_MISC_FLAG_LEN];
    char    sMisc[FLD_MISC_LEN];
} T_IpcIntMngDef;

typedef struct
{
    char    sRunPri[2];  /*�������ȼ�*/
    char    sFwNum[1];    /*ת������*/
    char    sVerNo[1];   /*�汾��*/
    char    sToEnc[1]; /*��Ѻ��ʶ*/
    char    sChnlId[3];  /*������ʶ*/
    char    sChnlSeg1[1]; /*����ϸ��1*/
    char    sChnlSeg2[1]; /*����ϸ��2*/
    char    sNetgateNo[4];/*���ر��*/
    char    sBusSys[4];   /*ҵ��ϵͳ*/
    char    sLanId[4];   /*���𷽱�ʶ*/
    char    sSndId[4];   /*���ͷ���ʶ*/
    char    sRcvId1[4];   /*���շ���ʶ1*/
    char    sRcvId2[4];   /*���շ���ʶ2*/
    char    sTxnLanChnl[3];/*���׷�������*/
    char    sUniTeller[10];/*ͳһ��Ա��*/
}GFHEADER_CFG;
GFHEADER_CFG GFHeaderCfg_CC;
GFHEADER_CFG GFHeaderCfg_ZK;
 int                 gnTimeOutFlag;
 char                gsTimeOutTs[27];
 char                gsTimeCurTs[15];

#endif
