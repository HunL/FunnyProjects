#ifndef _BFTRANS_H_
#define _BFTRANS_H_

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/timeb.h>
#include <time.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/times.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <fcntl.h>
#include <stdarg.h>
#include <signal.h>
#include <sys/wait.h>
#include <dirent.h>
#include <setjmp.h>

#include "funtrace.h"

#define   FILE_PORT  7999

#define   N_FILE_NAME_LEN       256
#define   N_CMD_LEN             256
#define   N_MAX_DATA_LEN        2048
#define   N_HEAD_LEN            4
#define   N_TRANS_CODE_LEN      4
#define   N_FILELEN_LEN         12

#define   N_DATE_LEN            8
#define   N_BRH_ID_LEN          9
#define   N_FILE_TYPE_LEN       1
#define   N_FILE_TYPE_DTL_LEN   4
#define   N_TRANS_STA_LEN       1

#define   N_TRANS_FLAG_LEN     1
#define   N_COMPRESS_FLAG_LEN  1
#define   N_DEL_FILE_FLAG_LEN  1
#define   N_REMOTE_IP_LEN     20
#define   N_REMOTE_PORT_LEN    6
#define   N_ERR_DSP_LEN       128

#define   TRANS_EXEC_COMMAND        "7000"
#define   TRANS_FILE_HEAD           "8000"
#define   TRANS_FILE_DATA           "8001"
#define   TRANS_FILE_TAIL           "8002"
#define   TRANS_DIR_NAME            "8003"
#define   TRANS_DIR_NAME_COMPLETE   "8004"
#define   TRANS_FILE_NAME           "8005"
#define   TRANS_COMMAND             "9000"
#define   TRANS_COMMAND_EXIT        "9001"
#define   TRANS_COMMAND_LOGIN       "9002"


#define   TRANS_FILE_COMPRESS   "0"
#define   TRANS_FILE_UNCOMPRESS "1"

#define   TRANS_FILE_PUT       "0"
#define   TRANS_FILE_GET       "1"

#define   DEL_FILE_FLG_NO      "0"
#define   DEL_FILE_FLG_YES     "1"

int  giTraceLevel;
char gsLogPath[500];       /* ��¼��־�ļ�·�� */

#define   BLOG_MODE_ERR        0,__FILE__,__LINE__
#define   BLOG_MODE_NOR        1,__FILE__,__LINE__
#define   BLOG_MODE_BUG        2,__FILE__,__LINE__



/*�ļ�ͷ�ṹ*/
typedef struct{
    char   sRemoteIP[N_REMOTE_IP_LEN + 1];
    char   sRemotePort[N_REMOTE_PORT_LEN + 1];
    char   sLocalFileName[N_FILE_NAME_LEN + 1];
    char   sRemoteFileName[N_FILE_NAME_LEN + 1];
    char   sCompressFlag[N_COMPRESS_FLAG_LEN + 1];     /* �����־ 0--PUT FILE 1--GET FILE */
    char   sTransFlag[N_TRANS_FLAG_LEN + 1];           /* �����־ 0--PUT FILE 1--GET FILE */
    char   sDelFileFlag[N_DEL_FILE_FLAG_LEN + 1];      /* ɾ���ļ���־ */
}IPCBfTransList;

typedef struct{
    char   sTransCode[N_TRANS_CODE_LEN + 1];
    char   sLocalFileName[N_FILE_NAME_LEN + 1];
    char   sRemoteFileName[N_FILE_NAME_LEN + 1];
    char   sCompressFlag[N_COMPRESS_FLAG_LEN + 1];       /* �����־ 0--PUT FILE 1--GET FILE */
    char   sTransFlag[N_TRANS_FLAG_LEN + 1];             /* �����־ 0--PUT FILE 1--GET FILE */
    char   sDelFileFlag[N_DEL_FILE_FLAG_LEN + 1];        /* ɾ���ļ���־ */
}IPCBfTransHead;
 

typedef struct{
    char   sTransCode[N_TRANS_CODE_LEN + 1];
    char   sFileLen[N_FILELEN_LEN + 1];
}IPCBfTransTail;

typedef struct {
    char  sCommandResult[N_TRANS_CODE_LEN + 1];
	char  sCommandErrDsp[N_ERR_DSP_LEN  + 1];
}IPCBfTransCommand;

#endif
