/*****************************************************************************/
/*                 Shanghai Huateng Software System Inc.                     */
/*****************************************************************************/
/* PROGRAM NAME: SwtLogProc.h                                                */
/* DESCRIPTIONS: The save and forward process server.                        */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
/*    ͷ�ļ�                                
 *                                                                           
 *  Edit History:                                                            
 *    2009/02/04 create by  wei_chunzi                                      
 */

#ifndef _BATCH_H
#define _BATCH_H

#define LOG_NAME_LEN_MAX                32

#define  CLEAR_FLAG_Y      '0'
#define  CLEAR_FLAG_N      '1'
#define  CLEAR_TBL_ONL     '0'
#define  CLEAR_TBL_BKE     '1'
#define  CLEAR_TBL_HIS     '2'

#define  TRANS_FLAG_Y      '0'
#define  TRANS_FLAG_N      '1'


#endif
