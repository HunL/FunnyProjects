
#ifndef __SRV_DEF_H
#define __SRV_DEF_H

#define SRV_ID_LEN		4
#define SRV_SEQ_ID_LEN	2

#define SRV_ID_BRIDGE		"1001"
#define SRV_ID_SWITCH		"1101"
#define SRV_ID_MANAGE		"1201"
#define SRV_ID_PACKSEND		"1301"
#define SRV_ID_SAVFWD		"1401"
#define SRV_ID_TOCTL		"1501"

#define SRV_ID_COMM_CUP		"1601"
#define SRV_ID_COMM_HOST	"1701"

typedef struct {
    long    processid;
    char    processname[20];
    int     status;
    int     ticks;
	int		useflag;
}STATUS_NCUP;

#endif
