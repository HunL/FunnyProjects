#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/times.h>

#ifdef _DB_ORA
#define DBS_NOTFOUND        1403
#endif
#ifdef _DB_INFX
#define DBS_NOTFOUND        100
#endif
#ifdef _DB_DB2
#define DBS_NOTFOUND        100
#endif

int                                    glSysError;

/*begin of TbFileTrans.h*/
typedef struct {
    char                               inter_brh_code[11];
    char                               sa_file_name[41];
    char							   sa_file_date[9];
    char                               sa_stlm_inst_id[12];
    char                               sa_file_flg[2];
    char                               sa_file_type[2];
    char                               sa_file_stat[2];
    char                               sa_compress_flg[2];
	char   			                   sa_trace_log[61];
	char                               sa_file_length[11];
} tbl_file_trans_def;
/*end of TbFileTrans.h*/

/*begin of TblAllUse.h*/
#define NTblCur1                        11
#define NTblOpen1                       21
#define NTblFetch1                      31
#define NTblSelect1                     41
#define NTblInsert1                     51
#define NTblUpdate1                     61
#define NTblDelete1                     71
#define NTblClose1                      81
#define NTblConnect1                    91
#define NTblDisconnect1                 101
#define NTblCur2                        12
#define NTblCur3                        179
#define NTblOpen2                       22
#define NTblOpen3                       180
#define NTblFetch2                      32
#define NTblFetch3                      181
#define NTblSelect2                     42
#define NTblInsert2                     52
#define NTblInsert3                     53
#define NTblUpdate2                     62
#define NTblUpdate3                     222
#define NTblUpdate4                     444
#define NTblDelete2                     72
#define NTblClose2                      82
#define NTblClose3                      182
#define NTblConnect2                    92
#define NTblDisconnect2                 102
/*end of TblAllUse.h*/

/*begin of UsrErr.h TblAllUse.h*/
#define LUsrErrNull                     0
#define LUsrErrMEncInit                 578
#define LUsrErrMMsqInit                 541
#define LUsrErrMNumOut                  507
#define LUsrErrMConnectDb               502
#define LUsrErrMEncOpr                  561
#define LUsrErrEBuildEncKey			    219
#define LUsrErrQTblLineInfOpr           625
#define LUsrErrQTblFileTransOpr         663
#define LSqlErrorUnknownOpr             2
/*end of UsrErr.h TblAllUse.h*/

