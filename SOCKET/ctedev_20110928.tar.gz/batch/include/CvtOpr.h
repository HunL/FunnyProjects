#ifndef __CVT_OPR_H
#define __CVT_OPR_H
  
#include "Convert.h"

/* tbl_conv_type record num max */
#define CONV_TYPE_NUM_MAX	5

/* tbl_conv_type.buf_chg_type */
#define CONV_CHG_TYPE_CUST	'0'
#define CONV_CHG_TYPE_8583	'1'

#define CVT_USAGE_TRANS_RULE_NUM_MAX	3
typedef struct{
	long			usage_key;
	TransRuleInfDef	tTransRule;
} T_UsageTransRuleDef;

/*****************************************************************************/
/* FUNC:   int CvtInit (Tbl_conv_type_Def *ptConvType,                       */
/*                      T_UsageTransRuleDef *ptUsageTransRule );             */
/* INPUT:  ��                                                                */
/* OUTPUT: ptConvType: tbl_conv_type��¼                                     */
/*         ptUsageTransRule: ���usage_key��ISO8583ת������                  */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ʽת���ĳ�ʼ������, ��ת��������ص��ڴ���                      */
/*****************************************************************************/
int CvtInit (Tbl_conv_type_Def *ptConvType, T_UsageTransRuleDef *ptUsageTransRule );


#endif
