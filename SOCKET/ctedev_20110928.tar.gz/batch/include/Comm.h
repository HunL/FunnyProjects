#ifndef _COMM_H_
#define _COMM_H_


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define  MAX_PROCCOUNT    20
#define  TCPMSGLEN         4
#define  DEFAULT_RETRYNUM  3
#define  SRV_ID_LEN        4

#define MSG_LEN_BIN(x) (x == 'B')
#define MSG_LEN_HEX(x) (x == 'H')
#define IS_NUMBER(x) (x >= '0' && x <= '9')


int  giTimeOutSnd;
int  giTimeOutRcv;

char gsSrvId[4+1];


struct  sockaddr_in Client;
char gsRmtCltAddr[26+1];
int  giLocPort;
char gsRmtSvrAddr[26+1];
int  giRmtPort;

int  giTcpMsgLen;
int  giTcpTpduHdrL;
char gsTcpMsgLenType[4+1];
char gsChkSvrNet[5+1];
char gsChkIpAddr[5+1];

int  giMaxChdNum;


#endif
