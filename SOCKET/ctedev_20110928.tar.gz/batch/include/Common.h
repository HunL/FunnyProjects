#ifndef __COMMON_H
#define __COMMON_H

#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/times.h>
#include <sys/wait.h>
#include <fcntl.h>

#include "SrvParam.h"
#include "DbsDef.h"
#include "DbsTbl.h"
#include "HtLog.h"


#define F002_VAL_LEN            19
#define BUF_SIZE                1800

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentDate (char *sCurrentDate);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentDate   -- the string of current date                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system date with the format (YYYYMMDD).                   */
/*         NULL is added at the end.                                         */
/*****************************************************************************/
void  CommonGetCurrentDate(char *sCurrentDate);

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentTime (char *sCurrentTime);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentTime   -- the string of current time                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system time with the format (YYYYMMDDhhmmss).             */
/*         NULL is added at the end.                                         */
/*****************************************************************************/
void CommonGetCurrentTime(char *sCurrentTime);

char                gsSrvId[SRV_ID_LEN+1];
char                gsLogFile[LOG_NAME_LEN_MAX];

#define BT_FILE_PATH_LEN  256
#define BT_FILE_NAME_LEN  64
#define BT_ITEM_VALUE_LEN 64
#define BT_MAXLINE        1024

#define BT_CRET_XM        "0"
#define BT_DEBT_XM        "1"

#endif

