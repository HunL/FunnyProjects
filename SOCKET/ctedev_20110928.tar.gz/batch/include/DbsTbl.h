#ifndef _DBS_TBL_H
#define _DBS_TBL_H

typedef struct 
{    
	char    brh_no[10+1];    
    char    settlmt_date[8+1];    
	char    txn_cd[6+1];    
    int     txn_nm;
    double  txn_amt;
    double  txn_fee;
    char    resv1[128+1];
    char    resv2[128+1];
    char    resv3[128+1];
} bth_mzsb_txn_stat_def;

typedef struct
{
    int    usage_key;
    int    buf_chg_index;
    int    sour_buf_index;
    int    dest_buf_index;
    char    buf_dsp[257];
} Tbl_buf_chg_Def;

typedef struct
{
	char txn_type[3+1];
	char txn_num[4+1];
	char curr_sta[2+1];
	char next_sta[2+1];
	char not_sta[2+1];
	char bt_flag[1+1];
}tbl_sta_ctl_def;
typedef struct
{
	char status[2+1];
	char next_sta[2+1];
}tbl_nas_sta_chg_def;

typedef struct
{
    int    usage_key;
    int    buf_dsp_index;
    int    pos_index;
    int    fld_index;
    int    fld_id;
    int    fld_offset;
} Tbl_buf_dsp_Def;

typedef struct
{
    int    usage_key;
    int    buf_dsp_index;
    char    buf_dsp[257];
} Tbl_buf_dsp_dsp_Def;

typedef struct
{
    int    usage_key;
    int    fld_id;
    int    fld_l;
    int    fld_type;
    char    fld_dsp[257];
} Tbl_fld_dsp_Def;

typedef struct
{
    int    usage_key;
    int    buf_chg_index;
    int    sour_fld_index;
    int    dest_fld_index;
} Tbl_fld_tsf_Def;

typedef struct
{
    int    usage_key;
    char    comp_key[11];
    int    comp_key_len;
    int    ipc_dft_index;
    int    buf_dsp_index;
    char    txn_num[5];
    char    ipc_dft[257];
} Tbl_ipc_dft_dsp_Def;

typedef struct
{
    int    usage_key;
    int    ipc_dft_index;
    int    pos_index;
    int    fld_index;
    int    fld_len;
    char    fld_val[601];
} Tbl_ipc_dft_Def;

typedef struct
{
    long    usage_key;
    long    txn_num;
    long    con_index;
    long    fld_index;
    long    begin_byte_pos;
    long    format_chg_need;
    char    val[36];
} Tbl_con_inf_Def;

typedef struct
{
    char    srv_id[5];
    char    buf_chg_type[2];
    int    usage_key;
} Tbl_conv_type_Def;

typedef struct
{
    int    usage_key;
    int    fld_index;
    int    len_len;
    int    data_max_len;
    int    len_exp_val;
    int    ind_sym;
    int    data_format;
    int    len_char_set;
    int    data_char_set;
} Tbl_fld_inf_Def;

typedef struct
{
    int    usage_key;
    int    ipc_index;
    char    ipc_val[201];
} Tbl_ipc_inf_Def;

typedef struct
{
    int    usage_key;
    int    txn_num;
    int    ipc_index;
    int    bmp_index;
    int    mand_bmp_index;
    char    msg_type[5];
    char    txn_code[4];
} Tbl_msg_inf_Def;

typedef struct
{
    int    usage_key;
    int    bmp_index;
    char    bmp_val[33];
} Tbl_bmp_inf_Def;

typedef struct
{
    char    date_settlmt[8+1];
    char    key_cup[48+1];
    char    flag_result[1+1];
    char    txn_type[3+1];
    char    txn_num[4+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    cup_ssn[6+1];
    char    trans_date_time[10+1];
    char    pan[19+1];
    char    amt_trans[12+1];
    char    replacement_amts[12+1];
    char    amt_trans_fee[12+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    retrivl_ref[12+1];
    char    pos_cond_code[2+1];
    char    authr_id_resp[6+1];
    char    rcvg_code[11+1];
    char    orig_cup_ssn[6+1];
    char    resp_code[2+1];
    char    pos_entry_mode[3+1];
    char    fee_credit[12+1];
    char    fee_debit[12+1];
    char    fee_xfer[12+1];
    char    flag_sd[1+1];
    char    fee_cdhr[12+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[19+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[19+1];
    char    card_seq_num[3+1];
    char    term_cap[1+1];
    char    chip_cond[1+1];
    char    orig_date_time[10+1];
    char    issuer_code[11+1];
    char    flag_domestic[1+1];
    char    channel_type[2+1];
    char    reserved_cup[32+1];
    char    misc_flag[8+1];
} Tbl_cup_txn_Def;

typedef struct
{
    char     date_settlmt[8+1];
    char     key_cup[48+1];
    char     key_host[48+1];
    char     txn_num[4+1];
    char     acq_inst_id_code[11+1];
    char     fwd_inst_id_code[11+1];
    char     cup_ssn[6+1];
    char     trans_date_time[10+1];
    char     sys_seq_num[6+1];
    char     host_date[8+1];
    char     host_ssn[12+1];
    char     term_ssn[12+1];
    char     pan[19+1];
    char     amt_trans[12+1];
    char     card_accp_id[16];
    char     processing_code[7];
    char     trans_code[4];
    char     flag_result[2];
    char     Channel_num[3]; 
    char    flag_domestic[2];
    char    orig_data_elemts[43];
    char    card_accp_term_id[9];
    char    authr_id_resp[7];
    char    pos_cond_code[3];
    char    revsal_flag[2];
    char    amt_trans_fee[10];
    char    acct_id1[20];
    char    acct_id2[20];
} Tbl_fe_txn_Def;

typedef struct
{ 
	char	inter_brh_code[10+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    trans_date_time[10+1];
    char    cup_ssn[22+1];
    char	mchnt_cd[15+1];
    char	term_id[8+1];
    char	pan[19+1];
    double	amt_trans;
    char	ccy[2+1];
    char	date_settlmt[8+1];
    char	inner_code[12+1];
	char	acct_bno[6+1];
    char	flag_result[1+1];
    int     seq_num;
} Tbl_host_txn_Def;

typedef struct
{ 
    char    inter_brh_code[10+1];
    char    key_host[48+1];
    char    date_settlmt[8+1];
    char    term_ssn[12+1];
    char    txn_date[8+1];
    char    txn_time[6+1];
    char    txn_seq_no[12+1];
    char    misn_index[7+1];
    char    host_date[8+1];
    char    host_ssn[12+1];
    char    txn_num[4+1];
    char    pan[19+1];
    char    inner_pan[20+1];
    char    channel_num[2+1];
    char    cash_io_flag[1+1];
    char    in_out_flag[1+1];
    char    curr_code[3+1];
    char    c_t_flag[1+1];
    char    trans_amt[12+1];
    char    auth_resp_code[6+1];
    char    fwd_inst_id_code[11+1];
    char    card_acpt_term_id[11+1];
    char    msg_type[4+1];
    char    txn_type[6+1];
    char    orig_txn_date[8+1];
    char    orig_txn_ssn[12+1];
    char    orig_host_date[8+1];
    char    orig_host_ssn[12+1];
    char    state[1+1];
    char    flag_result[1+1];
    int    seq_num;
} bth_host_cc_def;

typedef struct
{
    int		index_no;
    char    file_type[8+1];
    char    comp_key[10+1];
    char    pattern_val[64+1];
} Tbl_txn_file_ptn_Def;
/*
typedef struct
{
    char    file_type[8+1];
	int 	pattern_id;
    char    comp_key[10+1];
    char    pattern_val[64+1];
} Tbl_txn_file_ptn_Def;
*/

typedef struct
{
    char    inter_brh_code[10+1];
    char    date_settlmt_8[8+1];
    char    key_cup[48+1];
    char    key_host[48+1];
    char    flag_result[1+1];
    char    flag_domestic[1+1];
    char    channel_num[2+1];
    char    flag_err[1+1];
    char    inst_date[8+1];
    char    sys_seq_num[6+1];
    char    inst_time[6+1];
    char    msg_src_id[4+1];
    char    txn_num[4+1];
    char    trans_code[3+1];
    char    trans_type[1+1];
    char    trans_state[1+1];
    char    revsal_flag[1+1];
    char    revsal_ssn[6+1];
    char    cancel_flag[1+1];
    char    cancel_ssn[6+1];
    char    host_date[8+1];
    char    host_ssn[12+1];
    char    term_ssn[12+1];
    char    key_rsp[32+1];
    char    key_revsal[32+1];
    char    key_cancel[32+1];
    char    header_buf[46+1];
    char    msg_type[4+1];
    char    pan_len[2+1];
    char    pan[19+1];
    char    processing_code[6+1];
    char    amt_trans[12+1];
    char    amt_settlmt[12+1];
    char    amt_cdhldr_bil[12+1];
    char    trans_date_time[10+1];
    char    conv_rate_stlm[8+1];
    char    conv_rate_cdhldr[8+1];
    char    cup_ssn[6+1];
    char    time_local_trans[6+1];
    char    date_local_trans[4+1];
	char    date_expr[4+1];
    char    date_settlmt[4+1];
    char    date_conv[4+1];
    char    mchnt_type[4+1];
    char    acq_cntry_code[3+1];
    char    pos_entry_mode[3+1];
    char    pos_cond_code[2+1];
    char    pos_pin_cap_code[2+1];
    char    amt_trans_fee[9+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    retrivl_ref[12+1];
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    card_accp_name[40+1];
    char    currcy_code_trans[3+1];
    char    currcy_code_stlm[3+1];
    char    currcy_code_chldr[3+1];
    char    fld_reserved_len[3+1];
    char    fld_reserved[30+1];
    char    orig_data_elemts[42+1];
    char    replacement_amts[42+1];
    char    rcvg_code_len[2+1];
    char    rcvg_code[11+1];
    char    acct_id1_len[2+1];
    char    acct_id1[28+1];
    char    acct_id2_len[2+1];
    char    acct_id2[28+1];
    char    host_trans_fee1[12+1];
    char    host_trans_fee2[12+1];
    char    tlr_num[8+1];
    char    open_inst[15+1];
    char    stlm_inst[15+1];
    char    batch_flag[1+1];
    char    batch_date[8+1];
    char    msq_type[16+1];
    char    amt_return[12+1];
    char    authr_id_r[6+1];
    char    misc_flag[32+1];
    char    misc_1[128+1];
    char    misc_2[128+1];

} Tbl_gc_txn_Def;
typedef struct 
{
    char    inter_brh_code[10+1];
    char    date_settlmt_8[8+1];
    char    cup_line_no[5+1];
    char    key_cup[48+1];
    char    key_host[48+1];
    char    flag_result[1+1];
    char    flag_domestic[1+1];
    char    channel_num[2+1];
    char    flag_err[1+1];
    char    inst_date[8+1];
    char    sys_seq_num[6+1];
    char    inst_time[6+1];
    char    msg_src_id[4+1];
    char    txn_num[4+1];
    char    trans_code[3+1];
    char    trans_type[1+1];
    char    trans_state[1+1];
    char    revsal_flag[1+1];
    char    revsal_ssn[6+1];
    char    cancel_flag[1+1];
    char    cancel_ssn[6+1];
    char    host_date[8+1];
    char    host_ssn[12+1];
    char    term_ssn[12+1];
    char    key_rsp[32+1];
    char    key_revsal[32+1];
    char    key_cancel[32+1];
    char    header_buf[46+1];
    char    sub_header_buf[14+1];
    char    msg_type[4+1];
    char    pan_len[2+1];
    char    pan[19+1];
    char    processing_code[6+1];
    char    amt_trans[12+1];
    char    amt_settlmt[12+1];
    char    amt_cdhldr_bil[12+1];
    char    trans_date_time[10+1];
    char    conv_rate_stlm[8+1];
    char    conv_rate_cdhldr[8+1];
    char    cup_ssn[6+1];
    char    time_local_trans[6+1];
    char    date_local_trans[4+1];
    char    date_settlmt[4+1];
    char    date_conv[4+1];
    char    mchnt_type[4+1];
    char    acq_cntry_code[3+1];
    char    pos_entry_mode[3+1];
    char    pos_cond_code[2+1];
    char    pos_pin_cap_code[2+1];
    char    amt_trans_fee[9+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    retrivl_ref[12+1];
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    card_accp_name[40+1];
    char    addtnl_data_len[3+1];
    char    addtnl_data[512+1];
    char    currcy_code_trans[3+1];
    char    currcy_code_stlm[3+1];
    char    currcy_code_chldr[3+1];
    char    fld_reserved_len[3+1];
    char    fld_reserved[30+1];
    char    orig_data_elemts[42+1];
    char    replacement_amts[42+1];
    char    rcvg_code_len[2+1];
    char    rcvg_code[11+1];
    char    acct_id1_len[2+1];
    char    acct_id1[28+1];
    char    acct_id2_len[2+1];
    char    acct_id2[28+1];
    char    host_trans_fee1[12+1];
    char    host_trans_fee2[12+1];
    char    tlr_num[8+1];
    char    open_inst[15+1];
    char    stlm_inst[15+1];
    char    batch_flag[1+1];
    char    batch_date[8+1];
    char    msq_type[16+1];
    char    amt_return[12+1];
    char    authr_id_r[6+1];
    char    misc_flag[32+1];
    char    misc_1[128+1];
    char    misc_2[128+1];
    char    acq_swresved[100+1];

}tbl_txn_def;
/*******LiQian*********/
typedef struct
{
    char  trans_type[3+1+2];
    char  term_teller_id[8+1+2];
    char  pan[19+1+2];
    char  trans_amt[15+1+2];
    char  trans_date[8+1+2];
    char  trans_time[8+1+2];
    char  term_ssn[4+8+1+2];
    char  host_ssn[12+1+2];
    char  cup_ssn[12+1+2];
    char  batch_id[4+1+2];
    char  stlm_result[1+1+2];
    char  cup_stlm_date[4+1+2];
    char  flag[1+1+2];
    int  seq_num;    
}Tbl_atmp_txn_Def;
/****2008-11-27*******/

/* add by jxz 090331*/
typedef struct
{
    char  trans_type[3+1+2];
    char  bt_bb_flag[1+1+2];
    char  term_teller_id[8+1+2];
    char  pan[19+1+2];
    char  trans_amt[15+1+2];
    char  trans_date[8+1+2];
    char  trans_time[8+1+2];
    char  term_ssn[4+8+1+2];
    char  host_ssn[12+1+2];
    char  cup_ssn[12+1+2];
    char  batch_id[4+1+2];
    char  stlm_result[1+1+2];
    char  cup_stlm_date[4+1+2];
    char  flag[1+1+2];
    int  seq_num;    
}Tbl_posp_txn_Def1;
/*end of add by jxz*/

typedef struct
{
	char  		key_host[ 48+1 ];
	char  		pri_key	[  48+1];
	char  		orig_key	[  48+1];
	char  		del_key	[  48+1];
	char  		related_key	[  48+1];
	char  		local_settle_in	[   2];
	char  		settle_dt	[   9];
	char  		iss_in	[   2];
	char  		msg_tp	[   5];
	char  		pri_acct_no	[  33];
	char  		proc_cd	[   7];
	char  		trans_at	[  13];
	char  		sys_tra_no	[   7];
	char  		card_expired_date	[   9];
	char  		transmsn_dt_tm	[  15];
	char  		mchnt_tp	[   5];
	char  		pos_entry_md_cd	[   4];
	char  		card_seq_num	[   4];
	char  		pos_cond_cd	[   3];
	char  		pos_pin_cap_cd	[   3];
	char  		acq_ins_id_cd	[  14];
	char  		retri_ref_no	[  13];
	char  		auth_id_resp_cd	[   7];
	char  		resp_cd	[   3];
	char  		term_id	[   9];
	char  		mchnt_cd	[  16];
	char  		rcv_ins_id_cd	[  14];
	char  		term_seq_num	[   5];
	char  		fee_amt	[  13];
	char  		curr_cd	[   4];
	char  		acct_balance	[  13];
	char  		auth_sum_amt	[  13];
	char  		msg_type_id	[   3];
	char  		batch_num	[   7];
	char  		orig_trans_batch	[   7];
	char  		orig_pos_seq_num	[   7];
	char  		orig_trans_date	[   9];
	char  		orig_auth_md	[   3];
	char  		orig_auth_ins	[  14];
	char  		oper_id_cd	[   9];
	char  		trans_chnl	[   3];
	char  		in_bt_flag[  2];
	char  		trans_date[  9];
	char  		reserve_pan	[ 33];
	char  		flag_result[ 1+1];
    int        seq_num;
}Tbl_posp_txn_Def;

typedef struct
{
    char  trans_type[4+1];
	char  term_teller_id[8+1];
    char  pan[28+1];
    char  trans_amt[15+1];
    char  trans_date[8+1];
    char  trans_time[8+1];
    char  term_ssn[4+8+1];
	char  cup_ssn[12+1];
    char  host_ssn[12+1];
	char  batch_id[4+1];
	char  cup_stlm_date[4+1];
	char  acq_inst_id_code[11+1];
	char  card_accp_id[15+1];
	char  term_cd[8+1];
	char  trans_fee[12+1];
    char  bt_bb_flag[1+1];
	char  ruz_amt[12+1];
	char  ruz_pan[28+1];
	char  ruz_state[1+1];
	char  ruz_type[2+1];
    char  stlm_result[1+1];
    char  flag[1+1];
    int  seq_num; 
}Tbl_eposp_txn_Def;

typedef struct 
{
	char    inter_brh_code[10+1];
	char    settle_dt[8+1];
	char    msg_tp[4+1];
	char    proc_cd[6+1];
	char    pos_cd[2+1];
	char    trans_chnl[2+1];
	char    mchnt_type[4+1];
	char    mchnt_cd[15+1];
	char    term_cd[8+1];
	char    trans_sn_type[1+1];
	char    trans_disc[12+1];
	char    trans_type[4+1];
	char    teller_cd[8+1];
	char    card_no[35+1];
	char    trans_amt[15+1];
	char    trans_date[8+1];
	char    trans_time[8+1];
	char    term_ssn[12+1];
	char    host_ssn[12+1];
	char    cups_ssn[12+1];
	char    batch_no[4+1];
	char    result_flag[1+1];
	char    cups_settle_dt[8+1];
	char    brh_id[11+1];
	char    bt_flag[1+1];
	char    reserve1[25+1];
	char    reserve2[25+1];
	char    reserve3[25+1];
	char    reserve4[50+1];
	char    reserve5[50+1];
	char    reserve6[50+1];
	char    rec_crt_ts[14+1];
	int    seq_num;
}Tbl_eposp_flow_Def;

typedef struct {
    int        usage_key;
    char        srv_id[5];
    int       line_index;
    char        local_addr[16];
    char        remote_addr[16]; 
    int       in_sock_num;
    int       out_sock_num;
} Tbl_line_cfg_Def;

typedef struct {
    char    txn_cd[8+1];
    char    cur_sta[2+1];
    char    next_sta[2+1];
    char    del_flg[1+1];
    char    cur_sta_desc[128+1];
    char    next_sta_desc[128+1];
    char    org_sta_bsi[256+1];
    char    aft_sta_bsi[256+1];
    char    misc_tx0[128+1];
    char    misc_tx1[128+1];
    char    last_upd_opr_id[10+1];
    char    last_upd_txn_cd[10+1];
    char    last_upd_tm[14+1];
} Tbl_sta_chg_cfg_Def;

typedef struct
{
    char    vire_flag[2+1];
    char    currnt_flag[1+1];
    int    seq_no;
    int    grp_no;
    char    key_cup[48+1];
    char    adj_key_cup[48+1];
    char    orig_key_cup[48+1];
    char    operate[10+1];
    char    status[2+1];
    double    amt;
    char    file_name[256+1];
    char    cre_file_name[256+1];
    char    opr_no[10+1];
    char    crt_time[14+1];
    char    misc[100+1];
    char    b_t_flag[1+1];
    char    manage_inst[4+1];
    char    trans_date_time[10+1];
    char    cup_ssn[6+1];
    char    adj_cup_ssn[6+1];
    char    orig_cup_ssn[6+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    term_ssn[12+1];
    char    inst_date[8+1];
    char    inst_time[6+1];
    char    host_ssn[12+1];
    char    host_date[8+1];
    char    date_settlmt[8+1];
    char    gc_txn_num[4+1];
    char    txn_num[4+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    pos_cond_code[2+1];
    char    channel_num[2+1];
    char    orig_data_ssn[6+1];
    char    orig_data_time[10+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    orig_host_date[8+1];
    char    orig_host_ssn[12+1];
    char    pan[19+1];
    double    amt_trans;
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    host_recode[7+1];
    double    fee_credit;
    double    fee_debit;
    double    fee_cdhr;
    double    fee_inst;
    double    fee_logo;
    char    pos_entry_mode[3+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    card_accp_addr[40+1];
    char    retrivl_ref[12+1];
    char    rcvg_code[11+1];
    char    issuer_code[11+1];
    char    deal_flg[2+1];
    char    tran_flg[1+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[28+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[28+1];
    char    currcy_code_trans[3+1];
    char    currcy_code_stlm[3+1];
    double    amt_settlmt;
    char    conv_rate_stlm[8+1];
    char    date_conv[8+1];
    char    flag_domestic[1+1];
    char    flag_city[1+1];
    char    area_code[4+1];
    char    inst_no[11+1];
    char    bank_flag[6+1];
    char    flag_result[1+1];
    char    fwd_rcv_in[1+1];
    int     err_flag;
    char    sys_seq_num[6+1];
    char    cup_batch_id[10+1];
    char    audit_batch_id[10+1];
    char    affirm_date[8+1];
    char    audit_date[8+1];
    char    cup_date[8+1];
    char    err_state[1+1];
    char    host_batch_id[10+1];
    char    fld_reserved[30+1];
}Tbl_err_misn_Def;

typedef struct
{
	char    inter_brh_code[10+1];
    char    pri_key[42+1];
    char    orig_key[42+1];
    char    related_key[42+1];
    char    iss_acq_in[1+1];
    char    local_settle_in[1+1];
    char    fill_disc_in[1+1];
    char    err_trans_id[3+1];
    char    settle_dt[8+1];
    char    msg_tp[4+1];
    char    pri_acct_no[21+1];
    char    proc_cd[6+1];
    char    trans_at[12+1];
    char    transmsn_dt_tm[10+1];
    char    sys_tra_no[6+1];
    char    mchnt_tp[4+1];
    char    pos_entry_md_cd[3+1];
    char    card_seq_num[3+1];
    char    pos_cond_cd[3+1];
    char    acq_ins_id_cd[13+1];
    char    fwd_ins_id_cd[13+1];
    char    retri_ref_no[12+1];
    char    auth_id_resp_cd[6+1];
    char    resp_cd[2+1];
    char    term_id[8+1];
    char    mchnt_cd[15+1];
    char    rsn_cd[4+1];
    char    term_entry_cap[1+1];
    char    chip_cond_cd[1+1];
    char    trans_chnl[2+1];
    char    rcv_ins_id_cd[13+1];
    char    iss_ins_id_cd[13+1];
    char    tfr_out_ins_id_cd[13+1];
    char    tfr_out_acct_id[21+1];
    char    tfr_in_ins_id_cd[13+1];
    char    tfr_in_acct_id[21+1];
    char    orig_settle_dt[8+1];
    char    orig_trans_at[12+1];
    char    orig_transmsn_dt_tm[10+1];
    char    orig_sys_tra_no[6+1];
    char    orig_retri_ref_no[12+1];
    char    debt_disc_at[12+1];
    char    cret_disc_at[12+1];
    char    swt_disc_at[12+1];
    char    cust_cups_disc_at[12+1];
    char    cust_gold_disc_at[12+1];
    char    debt_fee_at[12+1];
    char    cret_fee_at[12+1];
    char    gold_iss_ins_id_cd[13+1];
    char    sms_dms_conv_in[1+1];
    char    dom_ext_in[1+1];
    char    err_zone_in[1+1];
    char    cross_dist_in[1+1];
    char    reserve[30+1];
    char    reserve1[30+1];
    char    reserve2[60+1];
    char    reserve3[100+1];
	int		seq_num;
}Tbl_dat_cups_flow_Def;

typedef struct
{
	char    inter_brh_code[10+1];
	char	pri_key[42+1];
	char	orig_key[42+1];
	char	related_key[42+1];
	char	iss_acq_in[1+1];
	char	local_settle_in[1+1];
	char	settle_dt[8+1];
    char    flow_ins_id_cd[13+1];
	char	acq_first_br_cd[13+1];
	char	iss_first_br_cd[13+1];
	char	is_cups_in[1+1];
	char	debt_cret_in[2+1];
	char	card_media[1+1];
	char	cross_dist_in[1+1];
	char	mchnt_tp[4+1];
	char	acq_second_br_cd[13+1];
	char	iss_second_br_cd[13+1];
	char	acq_ins_id_cd[13+1];
	char	fwd_ins_id_cd[13+1];
	char	iss_ins_id_cd[13+1];
	char	rcv_ins_id_cd[13+1];
	char	sheet_ins_id_cd[13+1];
	char	msg_tp[4+1];
	char	proc_cd[6+1];
	char	pos_cond_cd[2+1];
	char	trans_chnl[2+1];
	char	sys_tra_no[6+1];
	char	transmsn_dt_tm[10+1];
	char	pri_acct_no[19+1];
	char	tfr_out_acct_id[28+1];
	char	tfr_in_acct_id[28+1];
	char	orig_data_elem[42+1];
	char	term_id[8+1];
	char	mchnt_cd[15+1];
	char	retri_ref_no[12+1];
	char	trans_at[12+1];
	char	acq_disc_at[12+1];
	char	iss_disc_at[12+1];
	char	brand_at[12+1];
	char	rsv1[12+1];
	char	weigh_at[12+1];
	char	rsv2[100+1];
	char	cust_gold_disc_at[12+1];
	char	gold_iss_ins_id_cd[13+1];
	char	reserve[30+1];
	char	reserve1[30+1];
	char	reserve2[60+1];
	char	reserve3[100+1];
	int		seq_num;
}Tbl_cup_logofee_Def;

typedef struct
{
    char    tbl_name[60+1];
    char    part_name[60+1];
    char    tbl_spc_name[60+1];
    int     tbl_interval_days;
    int    tbl_opr_flag;
}Tbl_part_inf_Def;

typedef struct
{
	int        sTblOprFlag;
	char       sObjectName[60+1];
	char       sParam_1[60+1];
	char       sParam_2[60+1];
	char       sParam_3[60+1];
	char       sParam_4[60+1];
}Tbl_opr_inf_Def;

typedef struct {
	char  		inst_date	[   9];
	char  		sys_seq_num	[   7];
	char  		inst_time	[   7];
	char  		msg_src_id	[   5];
	char  		txn_num	[   5];
	char  		trans_code	[   4];
	char  		trans_type	[   2];
	char  		trans_state	[   2];
	char  		revsal_flag	[   2];
	char  		revsal_ssn	[   7];
	char  		cancel_flag	[   2];
	char  		cancel_ssn	[   7];
	char  		host_date	[   9];
	char  		host_ssn	[  13];
	char  		term_ssn	[  13];
	char  		key_rsp	[  33];
	char  		key_revsal	[  33];
	char  		key_cancel	[  33];
	char  		header_buf	[  47];
	char  		msg_type	[   5];
	char  		pan_len	[   3];
	char  		pan	[  20];
	char  		processing_code	[   7];
	char  		amt_trans	[  13];
	char  		amt_settlmt	[  13];
	char  		amt_cdhldr_bil	[  13];
	char  		trans_date_time	[  11];
	char  		conv_rate_stlm	[   9];
	char  		conv_rate_cdhldr	[   9];
	char  		cup_ssn	[   7];
	char  		time_local_trans	[   7];
	char  		date_local_trans	[   5];
	char  		date_settlmt	[   5];
	char  		date_conv	[   5];
	char  		mchnt_type	[   5];
	char  		acq_cntry_code	[   4];
	char  		pos_entry_mode	[   4];
	char  		pos_cond_code	[   3];
	char  		pos_pin_cap_code	[   3];
	char  		amt_trans_fee	[  10];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		track_2_data_len	[   3];
	char  		track_2_data	[  38];
	char  		track_3_data_len	[   4];
	char  		track_3_data	[ 105];
	char  		retrivl_ref	[  13];
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_name	[  41];
	char  		addtnl_data_len	[   4];
	char  		addtnl_data	[ 513];
	char  		track_1_data_len	[   3];
	char  		track_1_data	[  80];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	char  		currcy_code_chldr	[   4];
	char  		addtnl_amt_len	[   4];
	char  		addtnl_amt	[  41];
	char  		fld_reserved_len	[   4];
	char  		fld_reserved	[  31];
	char  		ch_auth_info_len	[   4];
	char  		ch_auth_info	[ 201];
	char  		switch_data_len	[   4];
	char  		switch_data	[ 201];
	char  		orig_data_elemts	[  43];
	char  		replacement_amts	[  43];
	char  		rcvg_code_len	[   3];
	char  		rcvg_code	[  12];
	char  		acct_id1_len	[   3];
	char  		acct_id1	[  29];
	char  		acct_id2_len	[   3];
	char  		acct_id2	[  29];
	char  		trans_descrpt_len	[   4];
	char  		trans_descrpt	[ 101];
	char  		cup_swresved_len	[   4];
	char  		cup_swresved	[ 101];
	char  		host_trans_fee1	[  13];
	char  		host_trans_fee2	[  13];
	char  		tlr_num	[   9];
	char  		open_inst	[  16];
	char  		stlm_inst	[  16];
	char  		batch_flag	[   2];
	char  		batch_date	[   9];
	char  		msq_type	[  17];
	char  		amt_return	[  13];
	char  		authr_id_r	[   7];
	char  		misc_flag	[  33];
	char  		misc_1	[ 129];
	char  		misc_2	[ 129];
} tbl_txn_his_def;

typedef struct {
	char		inter_brh_code[11];
	char  		vire_flag	[   3];
	char  		currnt_flag	[   2];
	int		seq_no;
	int		grp_no;
	char  		key_cup	[  49];
	char  		adj_key_cup	[  49];
	char  		orig_key_cup	[  49];
	char  		operate	[  11];
	char  		status	[   3];
	double		amt;
	char  		file_name	[ 257];
	char  		cre_file_name	[ 257];
	char  		opr_no	[  11];
	char  		crt_time	[  15];
	char  		misc	[ 101];
	char  		b_t_flag	[   2];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		adj_cup_ssn	[   7];
	char  		orig_cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		fwd_rcv_in	[   2];
	int  		err_flag;
	char  		sys_seq_num	[   7];
	char  		cup_batch_id	[  11];
	char  		audit_batch_id	[  11];
	char  		affirm_date	[   9];
	char  		audit_date	[   9];
	char  		cup_date	[   9];
	char  		err_state	[   2];
	char  		host_batch_id	[  11];
	char  		fld_reserved	[  31];
	int        seq_num;
} tbl_err_misn_tmp_def;

/********lxj*********/
/*����֧����ˮ����*/

typedef struct
{
    char inst_date[15+1];            //��������
    char inst_time[6+1];            //����ʱ��
    char trans_id[80+1];            //ǰ̨��ˮ��
    char service_code[20+1];        //�������
    char business_inst[4+1];        //Ӫҵ���� 
    char open_inst[4+1];            //�������
    char card_no[19+1];             //���׿���
    char pan[35+1];                 //DM�˺�
    char txn_num[4+1];              //�ڲ�������
    char mchnt_id[15+1];            //�̻�ID
    char mchnt_name[40+1];          //�̻�����
    char mchnt_type[4+1];           //MCC��
    char accp_pay_flag[10+1];           //Ӧ��Ӧ����ʾ
    char channel[10+1];                 //ͨ��
    char sys_ssn[32+1];                 //ϵͳ��ˮ��/ ���� ��Ӧ��Ӧ�����ң�
    char trans_state[1+1];          //����״̬
    char card_accp_term_id[8+1];    //�ն˺�
    char curr_code_trans[3+1];      //���ױ���
    char amt_trans[12+1];           //���׽��
    char trans_type[8+1];           //��������
    char chnnl_no[2+1];             //��������
    char cust_id[10+1];             //�ͻ���
    char acct_id1[35+1];            //�ͻ��ʺ�
    char acct_id2[35+1];            //�Է��˺� 
    char acct_name[128+1];               //�Է����� 
    char trans_descrpt[50+1];       //��ע 
} Tbl_pay_txn_Def;



typedef struct {
    char        inner_brh_id    [   5];
    char        tlsq    [  13];
    char        trdt    [   9];
    char        vino    [   3];
    char        trcd    [   5];
    char        item    [   6];
    char        cyno    [   3];
    char        acno    [  33];
    char        sbsq    [  13];
    char        caty    [   2];
    char        cuac    [  33];
    char        acnm    [  65];
    char        amcd    [   2];
    double      tram;
    double      acbl;
    char        smcd    [  23];
    char        act_check_stu   [   2];
    char        reserve1    [  26];
    char        reserve2    [  26];
    char        reserve3    [  26];
    char        reserve4    [  51];
    char        reserve5    [  51];
    char        reserve6    [  51];
    char        rec_crt_ts  [  15];
} tbl_log_xft_actche_host_log_def;

extern int DbsTBL_LOG_XFT_ACTCHE_HOST_LOG(int ifunc,tbl_log_xft_actche_host_log_def *pTBL_LOG_XFT_ACTCHE_HOST_LOG );

typedef struct {
    char        inner_brh_id    [   5];
    char        settle_dt   [   9];
    char        key_cup [  28];
    char        msg_tp  [   5];
    char        proc_cd [   7];
    char        pos_cd  [   3];
    char        acq_ins_id_cd   [  12];
    char        fwd_ins_id_cd   [  12];
    char        sys_tra_aud_num [   7];
    char        trans_date_time [  11];
    char        out_settle_act  [  36];
    char        in_settle_act   [  36];
    char        trans_amt   [  13];
    char        trans_disc  [  10];
    char        term_cd [  16];
    char        card_acceptor_id_cd [  16];
    char        act_check_stu   [   2];
    char        reserve1    [  26];
    char        reserve2    [  26];
    char        reserve3    [  26];
    char        reserve4    [  51];
    char        reserve5    [  51];
    char        reserve6    [  51];
    char        rec_crt_ts  [  15];
} tbl_log_xft_actche_cups_log_def;

extern int DbsTBL_LOG_XFT_ACTCHE_CUPS_LOG(int ifunc,tbl_log_xft_actche_cups_log_def *pTBL_LOG_XFT_ACTCHE_CUPS_LOG );

typedef struct {
    char        inner_brh_id    [   5];
    char        settle_dt   [   9];
    char        key_cup [  28];
    char        msg_tp  [   5];
    char        proc_cd [   7];
    char        pos_cd  [   3];
    char        acq_ins_id_cd   [  12];
    char        fwd_ins_id_cd   [  12];
    char        sys_tra_aud_num [   7];
    char        trans_date_time [  11];
    char        out_settle_act  [  36];
    char        in_settle_act   [  36];
    char        trans_amt   [  13];
    char        act_in_amt  [  13];
    char        trans_disc  [  10];
    char        term_cd [   9];
    char        term_phone  [  21];
    char        card_acceptor_id_cd [  16];
    char        in_host_seq [  13];
    char        act_check_host_stu  [   2];
    char        act_check_cups_stu  [   2];
    char        reserve1    [  26];
    char        reserve2    [  26];
    char        reserve3    [  26];
    char        reserve4    [  51];
    char        reserve5    [  51];
    char        reserve6    [  51];
    char        rec_crt_ts  [  15];
} tbl_log_xft_actche_front_log_def;

extern int DbsTBL_LOG_XFT_ACTCHE_FRONT_LOG(int ifunc,tbl_log_xft_actche_front_log_def *pTBL_LOG_XFT_ACTCHE_FRONT_LOG );

typedef struct {
    char        inner_brh_id    [   5];
    char        settle_dt   [   9];
    char        key_cup [  28];
    char        msg_tp  [   5];
    char        proc_cd [   7];
    char        pos_cd  [   3];
    char        acq_ins_id_cd   [  12];
    char        fwd_ins_id_cd   [  12];
    char        sys_tra_aud_num [   7];
    char        trans_date_time [  11];
    char        out_settle_act  [  36];
    char        in_settle_act   [  36];
    char        trans_amt   [  13];
    char        act_in_amt  [  13];
    char        trans_disc  [  10];
    char        term_cd [  16];
    char        term_phone  [  21];
    char        card_acceptor_id_cd [  16];
    char        in_host_seq [  13];
    char        tlsq    [  13];
    char        trdt    [   9];
    char        vino    [   3];
    char        trcd    [   5];
    char        item    [   6];
    char        cyno    [   3];
    char        acno    [  33];
    char        sbsq    [  13];
    char        caty    [   2];
    char        cuac    [  33];
    char        acnm    [  65];
    char        amcd    [   2];
    double      tram;
    double      acbl;
    char        smcd    [  23];
    char        act_check_stu   [   2];
    char        freeze_seq      [  13];
    char        freeze_amt      [  13];
    char        reserve1    [  26];
    char        reserve2    [  26];
    char        reserve3    [  26];
    char        reserve4    [  51];
    char        reserve5    [  51];
    char        reserve6    [  51];
    char        rec_crt_ts  [  15];
} tbl_log_xft_actche_result_log_def;

extern int DbsTBL_LOG_XFT_ACTCHE_RESULT_LOG(int ifunc,tbl_log_xft_actche_result_log_def *pTBL_LOG_XFT_ACTCHE_RESULT_LOG );

typedef struct {
    char        inner_brh_id    [   5];
    char        settle_dt   [   9];
    char        key_cup [  28];
    char        msg_tp  [   5];
    char        proc_cd [   7];
    char        pos_cd  [   3];
    char        acq_ins_id_cd   [  12];
    char        fwd_ins_id_cd   [  12];
    char        sys_tra_aud_num [   7];
    char        trans_date_time [  11];
    char        out_settle_act  [  36];
    char        in_settle_act   [  36];
    char        trans_amt   [  13];
    char        act_in_amt  [  13];
    char        trans_disc  [  10];
    char        term_cd [  16];
    char        term_phone  [  21];
    char        card_acceptor_id_cd [  16];
    char        in_host_seq [  13];
    char        tlsq    [  13];
    char        trdt    [   9];
    char        vino    [   3];
    char        trcd    [   5];
    char        item    [   6];
    char        cyno    [   3];
    char        acno    [  33];
    char        sbsq    [  13];
    char        caty    [   2];
    char        cuac    [  33];
    char        acnm    [  65];
    char        amcd    [   2];
    double      tram;
    double      acbl;
    char        smcd    [  23];
    char        act_check_stu   [   2];
    char        freeze_seq      [  13];
    char        freeze_amt      [  13];
    char        reserve1    [  26];
    char        reserve2    [  26];
    char        reserve3    [  26];
    char        reserve4    [  51];
    char        reserve5    [  51];
    char        reserve6    [  51];
    char        rec_crt_ts  [  15];
} tbl_log_xft_actche_result_tmp_def;

extern int DbsTBL_LOG_XFT_ACTCHE_RESULT_TMP(int ifunc,tbl_log_xft_actche_result_tmp_def *pTBL_LOG_XFT_ACTCHE_RESULT_TMP );

typedef struct {
	char	MCHNT_CD[15+1];
	char	ACQ_INS_ID_CD[13+1];
	char	DPM_ID[10+1];
	char	ORG3_ID[11+1];
	char	ORG3_MAN_NAME[30+1];
	char	BANK_PLACE[60+1];
	char	AREANET[20+1];
	char	MCHNT_GRP[4+1];
	char	MCHNT_TP[4+1];
	char	MCHNT_ATTR[20+1];
	char	APPLY_TP[1+1];
	char	MCHT_STATUS[1+1];
	char	SIGN_INS_ID_CD[13+1];
	char	PRINT_INS_ID_CD[13+1];
	char	AREA_CD[4+1];
	char	CONN_MD[1+1];
	char	MCHNT_MNG_MD[1+1];
	char	MCHNT_ST[1+1];
	char	MCHNT_NM[60+1];
	char	MCHNT_CN_ABBR[40+1];
	char	MCHNT_EN_NM[60+1];
	char	MCHNT_EN_ABBR[20+1];
	char	DEAL_LOCA_NM[100+1];
	char	DEAL_LOCA_NM_EN[100+1];
	long	POS_NUM;
	long	POS_INUSE_NUM;
	char	ETPS_ATTR[4+1];
	char	ETPS_CD[20+1];
	char	ARTIF[20+1];
	char	ARTIF_CERTIF_TP[2+1];
	char	ARTIF_CERTIF_NO[30+1];
	char	MCHT_ENT_NO[20+1];
	char	MCHT_BUS_LIC_NO[20+1];
	char	MCHT_REG_DEADLINE[8+1];
	char	MCHT_REG_FUND[12+1];
	char	REG_ADDR[60+1];
	char	REG_NO[12+1];
	char	MCHT_RISK_RANK[2+1];
	char	CONTACT_PERSON[30+1];
	char	PHONE[40+1];
	char	FAX_NO[20+1];
	char	MOBIL[15+1];
	char	EMAIL[40+1];
	char	ZIP_CD[6+1];
	char	ADDR[60+1];
	char	USEFUL_LIFE[30+1];
	char	APPLY_NO[40+1];
	char	APPLY_DT[8+1];
	char	ENABLE_DT[8+1];
	char	MCHNT_MANAGER_NM[40+1];
	char	MCHNT_MANAGER_CD[20+1];
	char	PROTOCAL_ID[20+1];
	char	LOAD_BATCH_NO[6+1];
	char	PRE_AUD_NM[40+1];
	char	CONFIRM_NM[40+1];
	char	DESCR[200+1];
	char	MCHNT_FUNT_IN[20+1];
	long	RET_RATE;
	char	RET_RATE_CODE[10+1];
	char	DISC_ALGO_IN[1+1];
	long	DISC_RATE;
	char	DISC_CD;
	char	DISC_CRT_TS[8+1];
	char	DISC_ALT_TS[8+1];
	char	CLEAN_AMT_IN[1+1];
	char	FIRST_DISC_DATE[8+1];
	char	IS_SUPPORT_CREDIT[1+1];
	char	IN_ACCT_MODE[1+1];
	char	IN_ACCT_CHANNEL[2+1];
	char	SETTLE_CYCLE[4+1];
	char	SETTLE_ACCT_PRO_TP[2+1];
	char	SETTLE_ACCT_IN[1+1];
	char	SETTLE_ACCT_ATTR[1+1];
	char	SETTLE_ACCT[30+1];
	char	SETTLE_ACCT_NM[60+1];
	char	SETTLE_BANK_CD[13+1];
	char	SETTLE_BANK_NM[60+1];
	char	BACK_IN[1+1];
	char	BACK_SETTLE_DT[8+1];
	char	BACK_ACC_IN[1+1];
	char	BACK_RATE[8+1];
	char	BACK_ACC_NO[32+1];
	char	BACK_ACC_NM[60+1];
	char	BACK_BANK_NM[60+1];
	char	BACK_BANK_NO[13+1];
	char	EXCHANGE_INS_CD[10+1];
	char	EXCHANGE_CD[6+1];
	char	EXP_ID[30+1];
	char	MCHNT_GROUP_FLAG[1+1];
	char	MCHNT_GROUP_ID[8+1];
	char	PASSWORD[8+1];
	long	MIS_NUM;
	char	FOR_CITY_NM_EN[60+1];
	char	MCHT_FORIN_FLG[1+1];
	char	FOR_MCHNT_GRP[4+1];
	char	FOR_MCHNT_TP[4+1];
	char	FOR_CARD_USE_IN[10+1];
	char	FOR_CARD_RST_IN[10+1];
	char	FOR_CARD_RECOURSE_IN[10+1];
	char	FOR_SIGN_LMT_AT[8+1];
	char	DIV_MCHNT_TP[4+1];
	char	DIV_SINGL_LMT_AMT[8+1];
	char	PRESS_TERM_NUM[4+1];
	long	PER_COM_LMT_AMT;
	long	PER_GOLD_LMT_AMT;
	long	CMP_COM_LMT_AMT;
	long	CMP_GOLD_LMT_AMT;
	long	SINGL_LMT_AMT;
	long	DAY_LMT_AMT;
	long	MONTH_LMT_AMT;
	long	YEAR_LMT_AMT;
	char	RESERVE1[25+1];
	char	RESERVE2[25+1];
	char	RESERVE3[25+1];
	char	RESERVE4[50+1];
	char	RESERVE5[50+1];
	char	RESERVE6[50+1];
	char	REC_ST[1+1];
	char	LAST_OPER_IN[1+1];
	char	REC_UPD_USR_ID[10+1];
	char	REC_UPD_TS[14+1];
	char	REC_CRT_TS[14+1];
} tbl_inf_mchnt_inf_def; 


typedef struct {
        char            batch_no        [  33];
        char            mdl_id  [  21];
        char            file_name       [  51];
        char            rslt_file_name  [  51];
        char            status  [   3];
        char            rslt_status     [   3];
        char            busi_type       [   4];
        char            oprt_mode       [   2];
        char            total_amt       [  29];
        char            total_cnt       [  11];
        char            succ_cnt        [  11];
        char            fail_cnt        [  11];
        char            debt_amt        [  29];
        char            cret_amt        [  29];
        char            debt_cnt        [  11];
        char            cret_cnt        [  11];
        char            rqst_date       [   9];
        char            oprt_date       [   9];
        char            pi_eod  [   2];
        char            time_bgn        [   7];
        char            time_end        [   7];
        char            stcd    [   2];
        char            ctrl    [   2];
        char            stdt    [   9];
        char            incd    [   5];
        char            mits    [   2];
        char            con_in  [   2];
        char            con_mg  [  41];
        char            rsv_in1 [   2];
        char            rsv_in2 [   2];
        char            rsv_fld1        [   9];
        char            rsv_fld2        [  17];
        char            rsv_fld3        [  65];
} tbl_inf_pi_ctrl_def;

typedef struct {
        char            ext_seq [  33];
        char            ref_pay_no      [  33];
        char            front_seq       [  33];
        char            status  [   3];
        char            acct    [  36];
        char            pan     [  20];
        char            country_code    [   4];
        char            bank_code       [  16];
        char            currency        [   6];
        double          amt;
        char            channel [   5];
        char            tt      [   7];
        char            msgm    [  51];
        char            debt_cret       [   2];
        char            post_date       [   9];
        char            value_date      [   9];
        char            serv_code       [  21];
        char            tran_incd       [  11];
        char            cash_code       [  21];
        char            system_id       [  11];
        char            docu_type       [   8];
        char            docu_no [   9];
        char            remark  [  51];
        char            extension1      [  61];
        char            extension2      [  61];
        char            extension3      [  61];
        char            extension4      [  61];
        char            spec    [  11];
        char            usid    [   9];
        char            trdt    [   9];
        char            trtm    [   7];
        char            mgid    [   8];
        char            mgtx    [  61];
        char            tlsq    [  13];
        char            caty    [   2];
        char            basq    [  13];
        char            feeb    [  17];
        char            atnu    [   8];
        char            arin    [   2];
        char            bkin    [   2];
        char            ctin    [   2];
        char            ctrl    [   2];
        char            incd    [   5];
        char            stdt    [   9];
        char            ruzh    [   2];
        char            stcd    [   2];
        char            con_in  [   2];
        char            con_mg  [  41];
        int            rcnt;
        char            amts    [  29];
        char            flnm    [  51];
        char            rsv_in1 [   2];
        char            rsv_in2 [   2];
        char            rsv_fld1        [   9];
        char            rsv_fld2        [  17];
        char            rsv_fld3        [  65];
} tbl_log_pi_dtl_def;


typedef struct {
        char            inter_brh_code  [   11];
        char            date_settlmt    [   9];
        char            key_host        [  49];
        char            term_ssn        [  13];
        char            pan     [  20];
        char            txn_num [   5];
        char            debits_credits_flag     [   2];
        char            amt_trans       [  14];
        char            host_ssn        [  13];
        char            host_date       [   9];
        char            host_trans_time [   7];
        char            amt_trans_fee   [  14];
        char            replacement_amts        [  14];
        char            amt_add2        [  14];
        char            amt_add3        [  14];
        char            account_in      [  21];
        char            agent_num       [   8];
        char            channel_num     [   3];
        char            state   [   2];
        char            orig_date_settlmt       [   9];
        char            orig_term_ssn   [  13];
        char            reserved_host_1 [  21];
        char            reserved_host_2 [  21];
        char            reserved_host_3 [  21];
        char            reserved_host_4 [  33];
        char            reserved_host_5 [  33];
        char            act_check_stu   [   2];
} Tbl_pk_host_txn_def;

typedef struct {
        char            inter_brh_code [  11];
        char            date_settlmt [  9];
        char            key_host [  49];
        char            ext_seq [  33];
        char            ref_pay_no      [  33];
        char            front_seq       [  33];
        char            status  [   3];
        char            acct    [  36];
        char            pan     [  20];
        char            country_code    [   4];
        char            bank_code       [  16];
        char            currency        [   6];
        double          amt;
        char            channel [   5];
        char            tt      [   7];
        char            msgm    [  51];
        char            debt_cret       [   2];
        char            post_date       [   9];
        char            value_date      [   9];
        char            serv_code       [  21];
        char            tran_incd       [  11];
        char            cash_code       [  21];
        char            system_id       [  11];
        char            docu_type       [   8];
        char            docu_no [   9];
        char            remark  [  51];
        char            extension1      [  61];
        char            extension2      [  61];
        char            extension3      [  61];
        char            extension4      [  61];
        char            spec    [  11];
        char            usid    [   9];
        char            trdt    [   9];
        char            trtm    [   7];
        char            mgid    [   8];
        char            mgtx    [  61];
        char            tlsq    [  13];
        char            caty    [   2];
        char            basq    [  13];
        char            feeb    [  17];
        char            atnu    [   8];
        char            arin    [   2];
        char            bkin    [   2];
        char            ctin    [   2];
        char            ctrl    [   2];
        char            incd    [   5];
        char            stdt    [   9];
        char            ruzh    [   2];
        char            stcd    [   2];
        char            con_in  [   2];
        char            con_mg  [  41];
        int            rcnt;
        char            amts    [  29];
        char            flnm    [  51];
        char            rsv_in1 [   2];
        char            rsv_in2 [   2];
        char            rsv_fld1        [   9];
        char            rsv_fld2        [  17];
        char            rsv_fld3        [  65];
        char            act_check_stu   [  2];
} bth_pk_front_txn_def;


typedef struct {
        char            inter_brh_code  [   11];
        char            date_settlmt    [   9];
        char            key_host        [  49];
        char            ext_seq [  33];
        char            ref_pay_no      [  33];
        char            front_seq       [  33];
        char            status  [   3];
        char            acct    [  36];
        char            pan     [  20];
        char            country_code    [   4];
        char            bank_code       [  16];
        char            currency        [   6];
        double          amt;
        char            channel [   5];
        char            tt      [   7];
        char            msgm    [  51];
        char            debt_cret       [   2];
        char            post_date       [   9];
        char            value_date      [   9];
        char            serv_code       [  21];
        char            tran_incd       [  11];
        char            cash_code       [  21];
        char            system_id       [  11];
        char            docu_type       [   8];
        char            docu_no [   9];
        char            remark  [  51];
        char            extension1      [  61];
        char            extension2      [  61];
        char            extension3      [  61];
        char            extension4      [  61];
        char            spec    [  11];
        char            usid    [   9];
        char            trdt    [   9];
        char            trtm    [   7];
        char            mgid    [   8];
        char            mgtx    [  61];
        char            tlsq    [  13];
        char            caty    [   2];
        char            basq    [  13];
        char            feeb    [  17];
        char            atnu    [   8];
        char            arin    [   2];
        char            bkin    [   2];
        char            ctin    [   2];
        char            ctrl    [   2];
        char            incd    [   5];
        char            stdt    [   9];
        char            ruzh    [   2];
        char            stcd    [   2];
        char            con_in  [   2];
        char            con_mg  [  41];
        int            rcnt;
        char            amts    [  29];
        char            flnm    [  51];
        char            rsv_in1 [   2];
        char            rsv_in2 [   2];
        char            rsv_fld1        [   9];
        char            rsv_fld2        [  17];
        char            rsv_fld3        [  65];
        char            act_check_stu   [   2];
        char            term_ssn        [  13];
        char            pan2    [  20];
        char            txn_num [   5];
        char            debits_credits_flag     [   2];
        char            amt_trans       [  14];
        char            host_ssn        [  13];
        char            host_date       [   9];
        char            host_trans_time [   7];
        char            amt_trans_fee   [  14];
        char            replacement_amts        [  14];
        char            amt_add2        [  14];
        char            amt_add3        [  14];
        char            account_in      [  21];
        char            agent_num       [   8];
        char            channel_num     [   3];
        char            state   [   2];
        char            orig_date_settlmt       [   9];
        char            orig_term_ssn   [  13];
        char            reserved_host_1 [  21];
        char            reserved_host_2 [  21];
        char            reserved_host_3 [  21];
        char            reserved_host_4 [  33];
        char            reserved_host_5 [  33];
} bth_pk_result_tmp_txn_def;

typedef struct {
        char            inter_brh_code  [   11];
        char            date_settlmt    [   9];
        char            txn_num [   5];
        char            key_rsp [  33];
        char            stlm_inst       [  16];
        char            reserved_host_1 [  21];
        char            reserved_host_2 [  21];
        char            reserved_host_3 [  21];
        char            reserved_host_4 [  33];
        char            reserved_host_5 [  33];
} tbl_freeze_txn_def;

typedef struct {
        char            inter_brh_code  [   11];
        char            date_settlmt    [   9];
        char            manual_tp       [   4];
        char            acq_ins_id_cd   [  12];
        char            fwd_ins_id_cd   [  12];
        char            settle_ins_id_cd        [  12];
        char            settle_ins_role [   2];
        char            settle_mmdd     [   9];
        char            term_id [   9];
        char            mchnt_cd        [  16];
        char            card_accp_nm_loc        [  41];
        char            bus_tp  [   5];
        char            settle_curr_cd  [   4];
        char            trans_date_time [  11];
        char            pan     [  20];
        char            cup_ssn [   7];
        char            debt_settlt_num [   7];
        char            debt_settle_amt [  17];
        char            debt_settle_fee [  13];
        char            cret_settle_num [  11];
        char            cret_settle_amt [  17];
        char            cret_settlt_fee [  13];
        char            reserve [  21];
        char            rec_cpd_usr_id  [   9];
        char            rec_upd_ts      [  28];
        char            rec_crt_ts      [  28];
        char            reserve1        [  21];
        char            reserve2        [  21];
        char            reserve3        [  31];
        char            reserve4        [  51];
        char            reserve5        [  51];
} tbl_cup_fl_txn_def;


typedef struct {
        char            inter_brh_code  [   11];
        char            date_settlmt    [   9];
        char            manual_tp       [   4];
        char            acq_ins_id_cd   [  12];
        char            fwd_ins_id_cd   [  12];
        char            settle_ins_id_cd        [  12];
        char            settle_ins_role [   2];
        char            settle_mmdd     [   9];
        char            term_id [   9];
        char            mchnt_cd        [  16];
        char            card_accp_nm_loc        [  41];
        char            bus_tp  [   5];
        char            settle_curr_cd  [   4];
        char            trans_date_time [  11];
        char            pan     [  20];
        char            cup_ssn [   7];
        char            debt_settlt_num [   7];
        char            debt_settle_amt [  17];
        char            debt_settle_fee [  13];
        char            cret_settle_num [  11];
        char            cret_settle_amt [  17];
        char            cret_settlt_fee [  13];
        char            reserve [  21];
        char            rec_cpd_usr_id  [   9];
        char            rec_upd_ts      [  28];
        char            rec_crt_ts      [  28];
        char            reserve1        [  21];
        char            reserve2        [  21];
        char            reserve3        [  31];
        char            reserve4        [  51];
        char            reserve5        [  51];
} tbl_cup_fl_result_txn_def;



/*add by liliangang 20100310 begin*/
typedef struct {
    char        inner_brh_id    [   5];
    char        settle_dt   [   9];
    char        key_cup [  28];
    char        msg_tp  [   5];
    char        proc_cd [   7];
    char        pos_cd  [   3];
    char        acq_ins_id_cd   [  12];
    char        fwd_ins_id_cd   [  12];
    char        sys_tra_aud_num [   7];
    char        trans_date_time [  11];
    char        out_settle_act  [  36];
    char        in_settle_act   [  36];
    char        trans_amt   [  13];
    char        act_in_amt  [  13];
    char        trans_disc  [  10];
    char        term_cd [   9];
    char        term_phone  [  21];
    char        card_acceptor_id_cd [  16];
    char        in_host_seq [  13];
    char        act_check_host_stu  [   2];
    char        act_check_cups_stu  [   2];
    char        reserve1    [  26];
    char        reserve2    [  26];
    char        reserve3    [  26];
    char        reserve4    [  51];
    char        reserve5    [  51];
    char        reserve6    [  51];
    char        rec_crt_ts  [  15];
    char		term_ssn	[  13];
} tbl_log_xft_actche_front_payment_log_def;

extern int DbsTBL_LOG_XFT_ACTCHE_FRONT_PAYMENT_LOG(int ifunc,tbl_log_xft_actche_front_payment_log_def *pTBL_LOG_XFT_ACTCHE_FRONT_PAYMENT_LOG );

typedef struct {
	char		inter_brh_code[11];
	char  		vire_flag	[   3];
	char  		currnt_flag	[   2];
	int		seq_no;
	int		grp_no;
	char  		key_cup	[  49];
	char  		adj_key_cup	[  49];
	char  		orig_key_cup	[  49];
	char  		operate	[  11];
	char  		status	[   3];
	double		amt;
	char  		file_name	[ 257];
	char  		cre_file_name	[ 257];
	char  		opr_no	[  11];
	char  		crt_time	[  15];
	char  		misc	[ 101];
	char  		b_t_flag	[   2];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		adj_cup_ssn	[   7];
	char  		orig_cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		fwd_rcv_in	[   2];
	int  		err_flag;
	char  		sys_seq_num	[   7];
	char  		cup_batch_id	[  11];
	char  		audit_batch_id	[  11];
	char  		affirm_date	[   9];
	char  		audit_date	[   9];
	char  		cup_date	[   9];
	char  		err_state	[   2];
	char  		host_batch_id	[  11];
	char  		fld_reserved	[  31];
	double		seq_num;
} tbl_err_misn_payment_tmp_def;

extern int DbsErrMisnPayment(int nOpr, tbl_err_misn_payment_tmp_def *tErrMisn);

typedef struct {
    char        inner_brh_id    [   5];
    char        settle_dt   [   9];
    char        key_cup [  28];
    char        msg_tp  [   5];
    char        proc_cd [   7];
    char        pos_cd  [   3];
    char        acq_ins_id_cd   [  12];
    char        fwd_ins_id_cd   [  12];
    char        sys_tra_aud_num [   7];
    char        trans_date_time [  11];
    char        out_settle_act  [  36];
    char        in_settle_act   [  36];
    char        trans_amt   [  13];
    char        act_in_amt  [  13];
    char        trans_disc  [  10];
    char        term_cd [  16];
    char        term_phone  [  21];
    char        card_acceptor_id_cd [  16];
    char        in_host_seq [  13];
    char        tlsq    [  13];
    char        trdt    [   9];
    char        vino    [   3];
    char        trcd    [   5];
    char        item    [   6];
    char        cyno    [   3];
    char        acno    [  33];
    char        sbsq    [  13];
    char        caty    [   2];
    char        cuac    [  33];
    char        acnm    [  65];
    char        amcd    [   2];
    double      tram;
    double      acbl;
    char        smcd    [  23];
    char        act_check_stu   [   2];
    char        freeze_seq      [  13];
    char        freeze_amt      [  13];
    char        reserve1    [  26];
    char        reserve2    [  26];
    char        reserve3    [  26];
    char        reserve4    [  51];
    char        reserve5    [  51];
    char        reserve6    [  51];
    char        rec_crt_ts  [  15];
} tbl_log_xft_actche_payment_result_tmp_def;

extern int DbsTBL_LOG_XFT_ACTCHE_PAYMNET_RESULT_TMP(int ifunc,tbl_log_xft_actche_payment_result_tmp_def *pTBL_LOG_XFT_ACTCHE_PAYMENT_RESULT_TMP );

typedef struct {
    char        inner_brh_id    [   5];
    char        settle_dt   [   9];
    char        key_cup [  28];
    char        msg_tp  [   5];
    char        proc_cd [   7];
    char        pos_cd  [   3];
    char        acq_ins_id_cd   [  12];
    char        fwd_ins_id_cd   [  12];
    char        sys_tra_aud_num [   7];
    char        trans_date_time [  11];
    char        out_settle_act  [  36];
    char        in_settle_act   [  36];
    char        trans_amt   [  13];
    char        trans_disc  [  10];
    char        term_cd [  16];
    char        card_acceptor_id_cd [  16];
    char        act_check_stu   [   2];
    char        reserve1    [  26];
    char        reserve2    [  26];
    char        reserve3    [  26];
    char        reserve4    [  51];
    char        reserve5    [  51];
    char        reserve6    [  51];
    char        rec_crt_ts  [  15];
} tbl_log_xft_actche_cups_payment_log_def;

extern int DbsTBL_LOG_XFT_ACTCHE_CUPS_PAYMENT_LOG(int ifunc,tbl_log_xft_actche_cups_payment_log_def *pTBL_LOG_XFT_ACTCHE_CUPS_PAYMENT_LOG );

//�˻��ļ�
typedef struct {
	char        inter_brh_code [ 10+1];      //�ڲ�������
	char        settle_date    [ 8+1];      //��������
	char        key_host       [20+1];
	char		pay_card_no    [31+1]; 	    //�����˺�
	char  		pay_card_nm    [60+1];	    //�����
	char  		pay_bank_id    [12+1];      //�������к�
	char		save_bank_id   [12+1];      //�տ��к�
	char		save_card_no   [31+1];		//�տ��ʺ�
	char  		save_card_nm   [60+1];		//�տ��
	char	  	trans_amt	   [12+1];		//���׽��
	char  		ren_ssn		   [12+1];		//������ˮ��
	char  		ref_reason	   [60+1];		//�˻�ԭ��
	char  		ref_date	   [ 8+1];		//�˻�����
	char		trans_date	   [ 8+1];		//ԭ�������
	char  		trans_ssn	   [12+1];		//ԭ������ˮ��
	char  		host_date	   [ 8+1];		//ԭ������������
	char  		ref_ssn		   [12+1];		//��ˮ��
	char  		fill_date	   [ 8+1];		//ԭ��������
	char  		fill_ssn	   [12+1];		//ԭ������ˮ��
	char  		remark		   [60+1];		//��ע����ѯ�޸����ʣ����˹��˶ԣ�
	char        pan            [28+1];      //ǰ��ת���˺�
	char        flag           [ 1+1];
	char        reserve1       [25+1]; 
	char        reserve2       [25+1]; 
	char        reserve3       [25+1]; 
	char        reserve4       [50+1]; 
	char        reserve5       [50+1]; 
	char        rec_crt_ts     [14+1]; 
} tbl_refundment_def;

/*��ɽ�ƾ������ļ�ͷ�ṹ*/
typedef struct {
    char 	bank_code[30+1];
    char 	kk_date[8+1];
    char    total_rec[10+1];
    char 	total_amt[13+1];
}skkf_head_inf_def;

typedef struct {
	char    bank_code[9+1];
	char    hj_pan[50+1];
	char    fc_date[8+1];
	char    jied_rec[10+1];
	char    total_amt[16+1];
	char    gk_zh[4+1];
}fc_gk_czmx_head_inf_def;

typedef struct {
	char    bank_code[9+1];
	char    kk_date[8+1];
	char    total_num[10+1];
}fc_wtmx_head_inf_def;

typedef struct {
	char    kk_date[8+1];
	char    zsdw_code[12+1];
	char    jktz_num[20+1];
	char    bank_retri_ref[12+1];
	char    pan[19+1];
	char    wt_amt[16+1];
	char    trans_time[14+1];
	char    misc_err[500+1];
	char    flag[1+1];
}fc_wtmx_txn_inf_def;

typedef struct {
	char    fc_date[8+1];
	char    seg_code[12+1];
	char    seg_num[10+1];
	double  fc_amt;
	char    acct_name[50+1];
	char    acct_beint_bank[100+1];
	char 	acct_no[50+1];
	char    seg_seq[4+1];
	char    rz_flag[1+1];
	char    gk_zh[4+1];
}fc_gk_czmx_seg_inf_def;

typedef struct {
	char    fc_date[8+1];
	char 	dw_code[20+1];
	char  	jktz_num[50+1];
	char    fc_amt[16+1];
	char 	gk_zh[4+1];
	char    seg_seq[4+1];
	char    flag[1+1];
}fc_gk_czmx_txn_inf_def;

typedef struct {
    char    kk_date[8+1];
    char    zsdw_code[12+1];
    char    jktz_num[20+1];
    char    pj_num[20+1];
    char    trans_amt[12+1];
    char    retrivel_ref[12+1];
    char    pos_ssn[6+1];
    char    mchnt_code[15+1];
    char    pan[19+1];
    char    trans_time[14+1];
    char    flag[1+1];
}skkf_txn_inf_def;

typedef struct {
	char    kk_date[8+1];
	char    zsdw_code[12+1];
	char    jktz_num[20+1];
	char    pj_num[20+1];
	char    pan[19+1];
	char	cup_amt[16+1];
	char    host_amt[16+1];
	char    trans_time[14+1];
	char    bank_retri_ref[12+1];
	char    enable_fg[1+1];
	char    flag_result[1+1];
	char    fcwt_flag[1+1];
}zhs_guazhang_txn_inf_def;

typedef struct {
	char    kk_date[8+1];
	char    zsdw_code[12+1];
	char    jktz_num[20+1];
	char    pj_num[20+1];
	char    pan[19+1];
	char    cup_amt[16+1];
	char    host_amt[16+1];
	char    trans_time[14+1];
	char    bank_retri_ref[12+1];
	char    enable_fg[1+1];
	char    tmp_fg[1+1];
	char    flag_result[1+1];
	char    fcwt_flag[1+1];
}zhs_gz_txn_inf_def;

typedef struct {
	char        settle_dt   [   9];
	char        incd    [   5];
	char        acq_iss [   2];
	double      tr_number;
	double      tram;
	double      rev_number;
	double      rev_tram;
	double      fee;
	double      settle_tram;
	char        trans_nm    [  41];
	char        trans_id    [   5];
	double      trans_type;
	char        rsv_field1  [   5];
	char        rsv_field2  [   9];
	char        rsv_field3  [  41];
} tbl_log_cups_sumrpt_log_def;

typedef struct {
	char        trans_id    [   4];
	char        trans_tp    [  11];
	char        trans_nm    [  61];
	char        trans_class [   2];
	char        bank_cret_debt_in   [   2];
	char        cups_cret_debt_in   [   2];
	char        orig_disc_dir_in    [   2];
	char        rec_upd_usr_id  [  11];
	char        rec_upd_ts  [  15];
	char        rec_crt_ts  [  15];
} tbl_inf_trans_id_def;

typedef struct {
	char        flow_tp [   2];
	char        msg_tp  [   5];
	char        proc_cd [   7];
	char        pos_cond_cd [   3];
	char        trans_chnl  [   3];
	int     match_str_len;                              
	char        match_str   [  21];                     
	int     oth_cond_len;
	char        oth_cond    [  41];                     
	char        trans_id    [   4];                     
	char        rec_upd_usr_id  [  11];                 
	char        rec_upd_ts  [  15];
	char        rec_crt_ts  [  15];
} tbl_inf_trans_id_det_def;

typedef struct {
	char        trans_id    [   4];
	int     match_str_len;
	char        match_str   [  21];
	char        trans_id_conv   [   4];
	char        rec_upd_usr_id  [  11];
	char        rec_upd_ts  [  15];
	char        rec_crt_ts  [  15];
} tbl_inf_spec_trans_id_conv_def;

typedef struct {
	char        pri_key [  43];
	char        orig_key    [  43];
	char        related_key [  43];
	char        iss_acq_in  [   2];
	char        local_settle_in [   2];
	char        fill_disc_in    [   2];
	char        settle_dt   [   9];
	char        trans_id    [   4];
	char        raw_trans_id    [   4];
	char        trans_tp    [  11];
	char        trans_class [   2];
	char        settle_acq_ins_id_cd    [  14];
	char        settle_iss_ins_id_cd    [  14];
	char        msg_tp  [   5];
	char        pri_acct_no [  22];
	char        proc_cd [   7];
	double      trans_at;
	char        transmsn_dt_tm  [  11];
	char        sys_tra_no  [   7];
	char        mchnt_tp    [   5];
	char        pos_entry_md_cd [   4];
	char        card_seq_num    [   4];
	char        pos_cond_cd [   3];
	char        acq_ins_id_cd   [  14];
	char        fwd_ins_id_cd   [  14];
	char        retri_ref_no    [  13];
	char        auth_id_resp_cd [   7];
	char        resp_cd [   3];
	char        term_id [   9];
	char        mchnt_cd    [  16];
	char        rsn_cd  [   5];
	char        term_entry_cap  [   2];
	char        chip_cond_cd    [   2];
	char        trans_chnl  [   3];
	char        rcv_ins_id_cd   [  14];
	char        iss_ins_id_cd   [  14];
	char        tfr_out_ins_id_cd   [  14];
	char        tfr_out_acct_id [  22];
	char        tfr_in_ins_id_cd    [  14];
	char        tfr_in_acct_id  [  22];
	char        orig_settle_dt  [   9];
	double      orig_trans_at;
	char        orig_transmsn_dt_tm [  11];
	char        orig_sys_tra_no [   7];
	char        orig_retri_ref_no   [  13];
	double      cust_gold_disc_at;
	char        gold_iss_ins_id_cd  [  14];
	char        sms_dms_conv_in [   2];
	char        dom_ext_in  [   2];
	char        err_zone_in [   2];
	char        cross_dist_in   [   2];
	char        orig_disc_dir_in    [   2];
	char        orig_disc_algo_in   [   2];
	int        orig_disc_rate;
	char        orig_disc_cd    [   6];
	double      orig_cust_gold_disc_at;
	int        orig_mchnt_debt_disc_at;
	int        orig_mchnt_cret_disc_at;
	int        orig_cups_debt_disc_at;
	int        orig_cups_cret_disc_at;
	char        disc_dir_in [   2];
	char        disc_algo_in    [   2];
	int        disc_rate;
	char        disc_cd [   6];
	double      cups_debt_settle_at;
	double      cups_cret_settle_at;
	double      bank_debt_settle_at;
	double      bank_cret_settle_at;
	double      br_bank_debt_settle_at;
	double      br_bank_cret_settle_at;
	double      mchnt_debt_settle_at;
	double      mchnt_cret_settle_at;
	int        cups_debt_disc_at;
	int        cups_cret_disc_at;
	int        bank_debt_disc_at;
	int        bank_cret_disc_at;
	int        br_bank_debt_disc_at;
	int        br_bank_cret_disc_at;
	int        mchnt_debt_disc_at;
	int        mchnt_cret_disc_at;
	double      cups_debt_swt_at;
	double      cups_cret_swt_at;
	double      cust_cups_debt_disc_at;
	double      cust_cups_cret_disc_at;
	double      cups_debt_fee_at;
	double      cups_cret_fee_at;
	double      bank_debt_fee_at;
	double      bank_cret_fee_at;
	double      br_bank_debt_fee_at;
	double      br_bank_cret_fee_at;
	int        cups_rev_debt_disc_at;
	int        cups_rev_cret_disc_at;
	int        bank_rev_debt_disc_at;
	int        bank_rev_cret_disc_at;
	int        br_bank_rev_debt_disc_at;
	int        br_bank_rev_cret_disc_at;
	int        mchnt_rev_debt_disc_at;
	int        mchnt_rev_cret_disc_at;
	char        reserve [  31];
	char        reserve1    [  31];
	char        reserve2    [  61];
	char        reserve3    [ 101];
	char        rec_upd_ts  [  15];
	char        rec_crt_ts  [  15];
} tbl_log_cups_trans_rpt_log_def;

typedef struct
{
    char    pri_key[42+1];
    char    orig_key[42+1];
    char    related_key[42+1];
    char    iss_acq_in[1+1];
    char    local_settle_in[1+1];
    char    fill_disc_in[1+1];
    char    err_trans_id[3+1];
    char    settle_dt[8+1];
    char    msg_tp[4+1];
    char    pri_acct_no[21+1];
    char    proc_cd[6+1];
    char    trans_at[12+1];
    char    transmsn_dt_tm[10+1];
    char    sys_tra_no[6+1];
    char    mchnt_tp[4+1];
    char    pos_entry_md_cd[3+1];
    char    card_seq_num[3+1];
    char    pos_cond_cd[3+1];
    char    acq_ins_id_cd[13+1];
    char    fwd_ins_id_cd[13+1];
    char    retri_ref_no[12+1];
    char    auth_id_resp_cd[6+1];
    char    resp_cd[2+1];
    char    term_id[8+1];
    char    mchnt_cd[15+1];
    char    rsn_cd[4+1];
    char    term_entry_cap[1+1];
    char    chip_cond_cd[1+1];
    char    trans_chnl[2+1];
    char    rcv_ins_id_cd[13+1];
    char    iss_ins_id_cd[13+1];
    char    tfr_out_ins_id_cd[13+1];
    char    tfr_out_acct_id[21+1];
    char    tfr_in_ins_id_cd[13+1];
    char    tfr_in_acct_id[21+1];
    char    orig_settle_dt[8+1];
    char    orig_trans_at[12+1];
    char    orig_transmsn_dt_tm[10+1];
    char    orig_sys_tra_no[6+1];
    char    orig_retri_ref_no[12+1];
    char    debt_disc_at[12+1];
    char    cret_disc_at[12+1];
    char    swt_disc_at[12+1];
    char    cust_cups_disc_at[12+1];
    char    cust_gold_disc_at[12+1];
    char    debt_fee_at[12+1];
    char    cret_fee_at[12+1];
    char    gold_iss_ins_id_cd[13+1];
    char    sms_dms_conv_in[1+1];
    char    dom_ext_in[1+1];
    char    err_zone_in[1+1];
    char    cross_dist_in[1+1];
    char    reserve[30+1];
    char    reserve1[30+1];
    char    reserve2[60+1];
    char    reserve3[100+1];
}tbl_dat_cups_rpt_flow_def;

typedef struct
{
	char  		inter_brh_code	[   11];
	char  		pri_key	[  43];
	char  		orig_key	[  43];
	char  		related_key	[  43];
	char  		iss_acq_in	[   2];
	char  		local_settle_in	[   2];
	char  		fill_disc_in	[   2];
	char  		err_trans_id	[   4];
	char  		settle_dt	[   9];
	char  		msg_tp	[   5];
	char  		pri_acct_no	[  22];
	char  		proc_cd	[   7];
	char  		trans_at	[  13];
	char  		transmsn_dt_tm	[  11];
	char  		sys_tra_no	[   7];
	char  		mchnt_tp	[   5];
	char  		pos_entry_md_cd	[   4];
	char  		card_seq_num	[   4];
	char  		pos_cond_cd	[   3];
	char  		acq_ins_id_cd	[  14];
	char  		fwd_ins_id_cd	[  14];
	char  		retri_ref_no	[  13];
	char  		auth_id_resp_cd	[   7];
	char  		resp_cd	[   3];
	char  		term_id	[   9];
	char  		mchnt_cd	[  16];
	char  		rsn_cd	[   5];
	char  		term_entry_cap	[   2];
	char  		chip_cond_cd	[   2];
	char  		trans_chnl	[   3];
	char  		rcv_ins_id_cd	[  14];
	char  		iss_ins_id_cd	[  14];
	char  		tfr_out_ins_id_cd	[  14];
	char  		tfr_out_acct_id	[  22];
	char  		tfr_in_ins_id_cd	[  14];
	char  		tfr_in_acct_id	[  22];
	char  		orig_settle_dt	[   9];
	char  		orig_trans_at	[  13];
	char  		orig_transmsn_dt_tm	[  11];
	char  		orig_sys_tra_no	[   7];
	char  		orig_retri_ref_no	[  13];
	char  		debt_disc_at	[  13];
	char  		cret_disc_at	[  13];
	char  		swt_disc_at	[  13];
	char  		cust_cups_disc_at	[  13];
	char  		cust_gold_disc_at	[  13];
	char  		debt_fee_at	[  13];
	char  		cret_fee_at	[  13];
	char  		gold_iss_ins_id_cd	[  14];
	char  		sms_dms_conv_in	[   2];
	char  		dom_ext_in	[   2];
	char  		err_zone_in	[   2];
	char  		cross_dist_in	[   2];
	char  		reserve	[  31];
	char  		reserve1	[  31];
	char  		reserve2	[  61];
	char  		reserve3	[ 101];
	int		seq_num;
}tbl_dat_cups_rpt_flow_tmp_def;


typedef struct {
    char        txn_date    [   9];
    char        brh_id  [  12];
	char        acq_ist_id_cd[ 11+1];
    char        mchnt_cd    [  16];
    char        mod_kind    [   5];
    char        mod_values  [  14];
    char        txn_amt_sum [  14];
    char        txn_num_sum [  14];
    char        txn_amt_average [  14];
    char        txn_rate    [  14];
    char        sub_key_cd1 [  22];
    char        sub_key_cd2 [  22];
    char        mod_kind_desc   [ 129];
	char        deal_result [2+1];
} tbl_clc_off_result_def;


typedef struct {
    char        mchnt_cd       [  16];
    char        brh_id  	   [  12];
    char        process_time   [  15];
    char        acq_ins_id_cd  [  12];
    char        process_result [  3];
    char        enable_state   [  3];
} tbl_clc_off_proc_result_def;

typedef struct {
    char        trans_date  [   9];
    char        brh_id  [  12];
    char        mchnt_cd    [  16];
    char        trans_id    [   4];
    char        trans_num   [  14];
    char        trans_amt_sum   [  14];
    char        trans_fee_sum   [  14];
    char        trans_account_sum   [  14];
    char        fee_profit_sum  [  14];
    char        trans_amt_average   [  14];
    char        trans_desc  [  65];
} tbl_mchnt_trans_sum_def;

typedef struct {
    char        trans_date  [   9];
    char        brh_id  [  12];
    char        mchnt_cd    [  16];
    char        card_bin    [   7];
    char        trans_num   [  14];
    char        trans_amt_sum   [  14];
    char        trans_fee_sum   [  14];
    char        trans_account_sum   [  14];
    char        fee_profit_sum  [  14];
    char        trans_amt_average   [  14];
    char        card_desc   [  14];
} card_bin_trans_sum_def;

typedef struct
{
    char    sa_on_off_type[1+1];
    char    sa_branch_code[9+1];
    char    sa_model_kind[4+1];
    char    sa_be_use[2];
    char    sa_action[2];
    char    sa_limit_num[9];
    char    sa_limit_amount[13];
		char    sa_limit_rate[13];
} Tbl_risk_inf_Def;

/*jack 20101113*/
typedef struct
{
   char   	flag[2];                           
 	 char     trandate[9];                      
 	 int      serseqno;                      
 	 char     teller[11];                        
 	 char     brc[10];                           
 	 char     frnttrandate[11];                  
 	 char     frnttime[7];                      
 	 char     frntstan[9];                      
 	 char     frntno[9];                        
 	 char     frntdate[9];                      
 	 char     frnttrancode[7];                  
 	 char     settledate[11];                    
 	 char     origfrntstan[9];                  
 	 char     trancode[7];                      
 	 char     cardno1[33];                       
 	 char     acctno1[33];                       
 	 char     cardno2[33];                       
 	 char     acctno2[33];                       
 	 char			tranamt[13];                       
 	 char			ccy[4];                           
 	 char			trandevtype[3];                   
 	 char	    cardtrantype[3];                  
 	 char     mid[16];                           
 	 char     mctmcc[5];                        
 	 char     devid[9];                         
 	 char     bankgetfee[13];                    
 	 char     custsharefee[13];                  
 	 char     devstan[9];                       
 	 char     devdatetime[11];                   
 	 char			devacqins[12];                     
 	 char	    devforwins[12];                    
	char     authcode[7];                      
	char    issuebrc1[10];	  	 	             
	char    issuebrc2[10];		 		             
 	char	  text[130];                          
}	Bth_host_bdb_core_def;

typedef struct
{
	short flag           ;
	short trandate       ;
	short serseqno       ;
	short teller         ;
	short brc            ;
	short frnttrandate   ;
	short frnttime       ;
	short frntstan       ;
	short frntno         ;
	short frntdate       ;
	short frnttrancode   ;
	short settledate     ;
	short origfrntstan   ;
	short trancode       ;
	short cardno1        ;
	short acctno1        ;
	short cardno2        ;
	short acctno2        ;
	short tranamt        ;
	short ccy            ;
	short trandevtype    ;
	short cardtrantype   ;
	short mid            ;
	short mctmcc         ;
	short devid          ;
	short bankgetfee     ;
	short custsharefee   ;
	short devstan        ;
	short devdatetime    ;
	short devacqins      ;
	short devforwins     ;
	short authcode       ;
	short issuebrc1	  	 ;
	short issuebrc2		 ;
	short text           ;
} Bth_host_bdb_core_def_ind;      


typedef struct {
        char            clear_flg       [   2];
        char            tbl_name        [  65];
        char            tbl_tp  [   2];
        long            tbl_clear_gap;
        char            tbl_clear_sta   [   2];
        char            misc    [  26];
        char            rec_opr_id      [   2];
        char            rec_upd_opr     [  11];
        char            rec_crt_ts      [ 27];
        char            rec_upd_ts      [ 27];
} tbl_clear_ctl_def;

typedef struct {
        char            inst_date       [   9];
        char            sys_seq_num     [   7];
        char            inst_time       [   7];
        char            msg_src_id      [   5];
        char            txn_num [   5];
        char            trans_code      [   4];
        char            trans_chnl      [   5];
        char            trans_state     [   2];
        char            revsal_flag     [   2];
        char            revsal_ssn      [   7];
        char            cancel_flag     [   2];
        char            cancel_ssn      [   7];
        char            fw_trans_id     [   5];
        char            fw_trans_date   [   9];
        char            fw_trans_time   [   7];
        char            fw_trans_ssn    [  23];
        char            mid_time        [  11];
        char            mid_ssn [  13];
        char            mid_tag [   9];
        char            key_rsp [  33];
        char            key_revsal      [  33];
        char            key_cancel      [  33];
        char            bp_header       [  81];
        char            msg_type        [   5];
        char            pan_len [   3];
        char            pan     [  20];
        char            processing_code [   7];
        char            amt_trans       [  13];
        char            point_trans     [  13];
        char            trans_date_time [  11];
        char            time_local_trans        [   7];
        char            date_local_trans        [   5];
        char            date_settlmt    [   9];
        char            mchnt_type      [   5];
        char            pos_entry_mode  [   4];
        char            pos_cond_code   [   3];
        char            pos_pin_cap_code        [   3];
        char            acq_inst_id_code        [  12];
        char            fwd_inst_id_code        [  12];
        char            retrivl_ref     [  13];
        char            authr_id_resp   [   7];
        char            resp_code       [   3];
        char            resp_desp       [   8];
        char            card_accp_term_id       [   9];
        char            card_accp_id    [  16];
        char            card_accp_name  [  41];
        char            currcy_code_trans       [   4];
        char            addtnl_amt_len  [   4];
        char            addtnl_amt      [  41];
        char            fld_reserved_len        [   4];
        char            fld_reserved    [  31];
        char            switch_data_len [   4];
        char            switch_data     [ 201];
        char            acq_swresved_len        [   4];
        char            acq_swresved    [ 101];
        char            tom_flag_1      [   3];
        char            tom_flag_2      [  27];
        char            msq_type        [  17];
        char            amt_return      [  13];
        char            authr_id_r      [   7];
        char            order_id        [  19];
        char            bp_type [   4];
        char            consume_type    [   2];
        char            misc_flag       [  33];
        char            misc_1  [ 129];
        char            misc_2  [ 129];
        char            loop_req        [ 513];
        char            loop_rsp        [ 513];
        char            req_node        [  22];
        char            rsp_node        [  22];
        char            update_time     [  15];
} tbl_bonus_txn_def;

#endif
