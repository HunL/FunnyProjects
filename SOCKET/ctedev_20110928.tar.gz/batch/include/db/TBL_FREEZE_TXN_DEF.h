/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2010/03/08 -gendb
 */

#ifndef _TBL_FREEZE_TXN_DEF_H
#define _TBL_FREEZE_TXN_DEF_H
/*   Default values for table tbl_freeze_txn.    */
#define	inter_brh_code_DEF	"    "
#define	date_settlmt_DEF	"        "
#define	txn_num_DEF	"    "
#define	key_rsp_DEF	"                                "
#define	stlm_inst_DEF	"               "
#define	reserved_host_1_DEF	"                    "
#define	reserved_host_2_DEF	"                    "
#define	reserved_host_3_DEF	"                    "
#define	reserved_host_4_DEF	"                                "
#define	reserved_host_5_DEF	"                                "

#endif
