/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2009/10/29 -gendb
 */

#ifndef _TBL_LOG_XFT_ACTCHE_CUPS_LOG_DEF_H
#define _TBL_LOG_XFT_ACTCHE_CUPS_LOG_DEF_H
/*   Default values for table tbl_log_xft_actche_cups_log.    */
#define	inner_brh_id_DEF	"    "
#define	settle_dt_DEF	"        "
#define	key_cup_DEF	"                           "
#define	msg_tp_DEF	"    "
#define	proc_cd_DEF	"      "
#define	pos_cd_DEF	"  "
#define	acq_ins_id_cd_DEF	"           "
#define	fwd_ins_id_cd_DEF	"           "
#define	sys_tra_aud_num_DEF	"      "
#define	trans_date_time_DEF	"          "
#define	out_settle_act_DEF	"                                   "
#define	in_settle_act_DEF	"                                   "
#define	trans_amt_DEF	"            "
#define	trans_disc_DEF	"         "
#define	term_cd_DEF	"               "
#define	card_acceptor_id_cd_DEF	"               "
#define	act_check_stu_DEF	" "
#define	reserve1_DEF	"                         "
#define	reserve2_DEF	"                         "
#define	reserve3_DEF	"                         "
#define	reserve4_DEF	" "
#define	reserve5_DEF	" "
#define	reserve6_DEF	" "
#define	rec_crt_ts_DEF	"              "

#endif
