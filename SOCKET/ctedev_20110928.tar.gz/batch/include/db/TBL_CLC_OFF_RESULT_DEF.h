/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2010/10/19 -gendb
 */

#ifndef _TBL_CLC_OFF_RESULT_DEF_H
#define _TBL_CLC_OFF_RESULT_DEF_H
/*   Default values for table tbl_clc_off_result.    */
#define	txn_date_DEF	"        "
#define	brh_id_DEF	"           "
#define	mchnt_cd_DEF	"               "
#define	mod_kind_DEF	"    "
#define	mod_values_DEF	"             "
#define	txn_amt_sum_DEF	"             "
#define	txn_num_sum_DEF	"             "
#define	txn_amt_average_DEF	"             "
#define	txn_rate_DEF	"             "
#define	sub_key_cd1_DEF	"                     "
#define	sub_key_cd2_DEF	"                     "
#define	mod_kind_desc_DEF	"                                                                                                                                "

#endif
