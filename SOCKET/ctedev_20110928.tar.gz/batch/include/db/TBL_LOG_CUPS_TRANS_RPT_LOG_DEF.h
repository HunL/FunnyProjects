/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2009/09/12 -gendb
 */

#ifndef _TBL_LOG_CUPS_TRANS_RPT_LOG_DEF_H
#define _TBL_LOG_CUPS_TRANS_RPT_LOG_DEF_H
/*   Default values for table tbl_log_cups_trans_rpt_log.    */
#define	pri_key_DEF	"                                          "
#define	orig_key_DEF	"                                          "
#define	related_key_DEF	"                                          "
#define	iss_acq_in_DEF	" "
#define	local_settle_in_DEF	" "
#define	fill_disc_in_DEF	" "
#define	settle_dt_DEF	"        "
#define	trans_id_DEF	"   "
#define	raw_trans_id_DEF	"   "
#define	trans_tp_DEF	"          "
#define	trans_class_DEF	" "
#define	settle_acq_ins_id_cd_DEF	"             "
#define	settle_iss_ins_id_cd_DEF	"             "
#define	msg_tp_DEF	"    "
#define	pri_acct_no_DEF	"                     "
#define	proc_cd_DEF	"      "
#define	trans_at_DEF	0
#define	transmsn_dt_tm_DEF	"          "
#define	sys_tra_no_DEF	"      "
#define	mchnt_tp_DEF	"    "
#define	pos_entry_md_cd_DEF	"   "
#define	card_seq_num_DEF	"   "
#define	pos_cond_cd_DEF	"  "
#define	acq_ins_id_cd_DEF	"             "
#define	fwd_ins_id_cd_DEF	"             "
#define	retri_ref_no_DEF	"            "
#define	auth_id_resp_cd_DEF	"      "
#define	resp_cd_DEF	"  "
#define	term_id_DEF	"        "
#define	mchnt_cd_DEF	"               "
#define	rsn_cd_DEF	"    "
#define	term_entry_cap_DEF	" "
#define	chip_cond_cd_DEF	" "
#define	trans_chnl_DEF	"  "
#define	rcv_ins_id_cd_DEF	"             "
#define	iss_ins_id_cd_DEF	"             "
#define	tfr_out_ins_id_cd_DEF	"             "
#define	tfr_out_acct_id_DEF	"                     "
#define	tfr_in_ins_id_cd_DEF	"             "
#define	tfr_in_acct_id_DEF	"                     "
#define	orig_settle_dt_DEF	"        "
#define	orig_trans_at_DEF	0
#define	orig_transmsn_dt_tm_DEF	"          "
#define	orig_sys_tra_no_DEF	"      "
#define	orig_retri_ref_no_DEF	"            "
#define	cust_gold_disc_at_DEF	0
#define	gold_iss_ins_id_cd_DEF	"             "
#define	sms_dms_conv_in_DEF	" "
#define	dom_ext_in_DEF	" "
#define	err_zone_in_DEF	" "
#define	cross_dist_in_DEF	" "
#define	orig_disc_dir_in_DEF	" "
#define	orig_disc_algo_in_DEF	" "
#define	orig_disc_rate_DEF	0
#define	orig_disc_cd_DEF	"     "
#define	orig_cust_gold_disc_at_DEF	0
#define	orig_mchnt_debt_disc_at_DEF	0
#define	orig_mchnt_cret_disc_at_DEF	0
#define	orig_cups_debt_disc_at_DEF	0
#define	orig_cups_cret_disc_at_DEF	0
#define	disc_dir_in_DEF	" "
#define	disc_algo_in_DEF	" "
#define	disc_rate_DEF	0
#define	disc_cd_DEF	"     "
#define	cups_debt_settle_at_DEF	0
#define	cups_cret_settle_at_DEF	0
#define	bank_debt_settle_at_DEF	0
#define	bank_cret_settle_at_DEF	0
#define	br_bank_debt_settle_at_DEF	0
#define	br_bank_cret_settle_at_DEF	0
#define	mchnt_debt_settle_at_DEF	0
#define	mchnt_cret_settle_at_DEF	0
#define	cups_debt_disc_at_DEF	0
#define	cups_cret_disc_at_DEF	0
#define	bank_debt_disc_at_DEF	0
#define	bank_cret_disc_at_DEF	0
#define	br_bank_debt_disc_at_DEF	0
#define	br_bank_cret_disc_at_DEF	0
#define	mchnt_debt_disc_at_DEF	0
#define	mchnt_cret_disc_at_DEF	0
#define	cups_debt_swt_at_DEF	0
#define	cups_cret_swt_at_DEF	0
#define	cust_cups_debt_disc_at_DEF	0
#define	cust_cups_cret_disc_at_DEF	0
#define	cups_debt_fee_at_DEF	0
#define	cups_cret_fee_at_DEF	0
#define	bank_debt_fee_at_DEF	0
#define	bank_cret_fee_at_DEF	0
#define	br_bank_debt_fee_at_DEF	0
#define	br_bank_cret_fee_at_DEF	0
#define	cups_rev_debt_disc_at_DEF	0
#define	cups_rev_cret_disc_at_DEF	0
#define	bank_rev_debt_disc_at_DEF	0
#define	bank_rev_cret_disc_at_DEF	0
#define	br_bank_rev_debt_disc_at_DEF	0
#define	br_bank_rev_cret_disc_at_DEF	0
#define	mchnt_rev_debt_disc_at_DEF	0
#define	mchnt_rev_cret_disc_at_DEF	0
#define	reserve_DEF	" "
#define	reserve1_DEF	" "
#define	reserve2_DEF	" "
#define	reserve3_DEF	" "
#define	rec_upd_ts_DEF	"              "
#define	rec_crt_ts_DEF	"              "

#endif
