/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2010/08/16 -gendb
 */

#ifndef _TBL_LOG_CUPS_SUMRPT_LOG_DEF_H
#define _TBL_LOG_CUPS_SUMRPT_LOG_DEF_H
/*   Default values for table tbl_log_cups_sumrpt_log.    */
#define	settle_dt_DEF	"        "
#define	incd_DEF	"    "
#define	acq_iss_DEF	" "
#define	tr_number_DEF	0
#define	tram_DEF	0
#define	rev_number_DEF	0
#define	rev_tram_DEF	0
#define	fee_DEF	0
#define	settle_tram_DEF	0
#define	trans_nm_DEF	" "
#define	trans_id_DEF	"    "
#define	trans_type_DEF	0
#define	rsv_field1_DEF	"    "
#define	rsv_field2_DEF	"        "
#define	rsv_field3_DEF	" "

#endif
