/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2010/03/13 -gendb
 */

#ifndef _BTH_CUP_FL_RESULT_TXN_DEF_H
#define _BTH_CUP_FL_RESULT_TXN_DEF_H
/*   Default values for table bth_cup_fl_result_txn.    */
#define	inter_brh_code_DEF	"    "
#define	date_settlmt_DEF	"        "
#define	manual_tp_DEF	"   "
#define	acq_ins_id_cd_DEF	"           "
#define	fwd_ins_id_cd_DEF	"           "
#define	settle_ins_id_cd_DEF	"           "
#define	settle_ins_role_DEF	" "
#define	settle_mmdd_DEF	"        "
#define	term_id_DEF	"        "
#define	mchnt_cd_DEF	"               "
#define	card_accp_nm_loc_DEF	"                                        "
#define	bus_tp_DEF	"    "
#define	settle_curr_cd_DEF	"   "
#define	trans_date_time_DEF	"          "
#define	pan_DEF	"                   "
#define	cup_ssn_DEF	"      "
#define	debt_settlt_num_DEF	"      "
#define	debt_settle_amt_DEF	"                "
#define	debt_settle_fee_DEF	"            "
#define	cret_settle_num_DEF	"          "
#define	cret_settle_amt_DEF	"                "
#define	cret_settlt_fee_DEF	"            "
#define	reserve_DEF	"                    "
#define	rec_cpd_usr_id_DEF	"        "
#define	rec_upd_ts_DEF	"                           "
#define	rec_crt_ts_DEF	"                           "
#define	reserve1_DEF	"                    "
#define	reserve2_DEF	"                    "
#define	reserve3_DEF	"                              "
#define	reserve4_DEF	" "
#define	reserve5_DEF	" "

#endif
