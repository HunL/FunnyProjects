/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2010/03/03 -gendb
 */

#ifndef _BTH_PK_RESULT_TMP_TXN_DEF_H
#define _BTH_PK_RESULT_TMP_TXN_DEF_H
/*   Default values for table bth_pk_result_tmp_txn.    */
#define	inter_brh_code_DEF	"    "
#define	date_settlmt_DEF	"        "
#define	key_host_DEF	"                                                "
#define	ext_seq_DEF	"                                "
#define	ref_pay_no_DEF	"                                "
#define	front_seq_DEF	"                                "
#define	status_DEF	"  "
#define	acct_DEF	"                                   "
#define	pan_DEF	"                   "
#define	country_code_DEF	"   "
#define	bank_code_DEF	"               "
#define	currency_DEF	"     "
#define	amt_DEF	0
#define	channel_DEF	"    "
#define	tt_DEF	"      "
#define	msgm_DEF	" "
#define	debt_cret_DEF	" "
#define	post_date_DEF	"        "
#define	value_date_DEF	"        "
#define	serv_code_DEF	"                    "
#define	tran_incd_DEF	"          "
#define	cash_code_DEF	"                    "
#define	system_id_DEF	"          "
#define	docu_type_DEF	"       "
#define	docu_no_DEF	"        "
#define	remark_DEF	"                                                  "
#define	extension1_DEF	" "
#define	extension2_DEF	" "
#define	extension3_DEF	" "
#define	extension4_DEF	" "
#define	spec_DEF	"          "
#define	usid_DEF	"        "
#define	trdt_DEF	"        "
#define	trtm_DEF	"      "
#define	mgid_DEF	"       "
#define	mgtx_DEF	" "
#define	tlsq_DEF	"            "
#define	caty_DEF	" "
#define	basq_DEF	"            "
#define	feeb_DEF	"                "
#define	atnu_DEF	"       "
#define	arin_DEF	" "
#define	bkin_DEF	" "
#define	ctin_DEF	" "
#define	ctrl_DEF	" "
#define	incd_DEF	"    "
#define	stdt_DEF	"        "
#define	ruzh_DEF	" "
#define	stcd_DEF	" "
#define	con_in_DEF	" "
#define	con_mg_DEF	" "
#define	rcnt_DEF	0
#define	amts_DEF	"                            "
#define	flnm_DEF	"                                                  "
#define	rsv_in1_DEF	" "
#define	rsv_in2_DEF	" "
#define	rsv_fld1_DEF	"        "
#define	rsv_fld2_DEF	"                "
#define	rsv_fld3_DEF	" "
#define	act_check_stu_DEF	" "
#define	term_ssn_DEF	"            "
#define	pan2_DEF	"                   "
#define	txn_num_DEF	"    "
#define	debits_credits_flag_DEF	" "
#define	amt_trans_DEF	"             "
#define	host_ssn_DEF	"            "
#define	host_date_DEF	"        "
#define	host_trans_time_DEF	"      "
#define	amt_trans_fee_DEF	"             "
#define	replacement_amts_DEF	"             "
#define	amt_add2_DEF	"             "
#define	amt_add3_DEF	"             "
#define	account_in_DEF	"                    "
#define	agent_num_DEF	"       "
#define	channel_num_DEF	"  "
#define	state_DEF	" "
#define	orig_date_settlmt_DEF	"        "
#define	orig_term_ssn_DEF	"            "
#define	reserved_host_1_DEF	"                    "
#define	reserved_host_2_DEF	"                    "
#define	reserved_host_3_DEF	"                    "
#define	reserved_host_4_DEF	"                                "
#define	reserved_host_5_DEF	"                                "

#endif
