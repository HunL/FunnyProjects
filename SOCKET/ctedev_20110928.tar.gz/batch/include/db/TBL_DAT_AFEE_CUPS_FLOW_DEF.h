/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2009/12/23 -gendb
 */

#ifndef _TBL_DAT_AFEE_CUPS_FLOW_DEF_H
#define _TBL_DAT_AFEE_CUPS_FLOW_DEF_H
/*   Default values for table tbl_dat_afee_cups_flow.    */
#define	settle_dt_DEF	"         "
#define	iss_acq_in_DEF	" "
#define	acq_inst_id_code_DEF	"           "
#define	fwd_inst_id_code_DEF	"           "
#define	cup_ssn_DEF	"      "
#define	trans_date_time_DEF	"          "
#define	pan_DEF	"                   "
#define	amt_trans_DEF	"            "
#define	replacement_amts_DEF	"            "
#define	amt_trans_fee_DEF	"            "
#define	msg_type_DEF	"    "
#define	processing_code_DEF	"      "
#define	mchnt_type_DEF	"    "
#define	card_accp_term_id_DEF	"        "
#define	card_accp_id_DEF	"               "
#define	retrivl_ref_DEF	"            "
#define	pos_cond_code_DEF	"  "
#define	authr_id_resp_DEF	"      "
#define	rcvg_code_DEF	"           "
#define	orig_cup_ssn_DEF	"      "
#define	resp_code_DEF	"  "
#define	pos_entry_mode_DEF	"   "
#define	fee_credit_DEF	"            "
#define	fee_debit_DEF	"            "
#define	fee_xfer_DEF	"            "
#define	flag_sd_DEF	" "
#define	card_seq_num_DEF	"   "
#define	term_cap_DEF	" "
#define	chip_cond_DEF	" "
#define	orig_date_time_DEF	"          "
#define	issuer_code_DEF	"           "
#define	flag_domestic_DEF	" "
#define	channel_type_DEF	"  "
#define	falg_eci_DEF	"  "
#define	fee_divpay_DEF	"            "
#define	reserve_filed_DEF	"              "
#define	reserve_DEF	"                              "
#define	reserve1_DEF	"                              "
#define	reserve2_DEF	"                                                            "
#define	reserve3_DEF	"                                                                                                    "

#endif
