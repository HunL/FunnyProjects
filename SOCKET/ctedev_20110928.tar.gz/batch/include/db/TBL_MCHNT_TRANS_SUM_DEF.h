/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2010/10/19 -gendb
 */

#ifndef _TBL_MCHNT_TRANS_SUM_DEF_H
#define _TBL_MCHNT_TRANS_SUM_DEF_H
/*   Default values for table tbl_mchnt_trans_sum.    */
#define	trans_date_DEF	"        "
#define	brh_id_DEF	"           "
#define	mchnt_cd_DEF	"               "
#define	trans_id_DEF	"   "
#define	trans_num_DEF	"             "
#define	trans_amt_sum_DEF	"             "
#define	trans_fee_sum_DEF	"             "
#define	trans_account_sum_DEF	"             "
#define	fee_profit_sum_DEF	"             "
#define	trans_amt_average_DEF	"             "
#define	trans_desc_DEF	"                                                                "

#endif
