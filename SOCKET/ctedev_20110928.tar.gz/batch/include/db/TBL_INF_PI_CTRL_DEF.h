/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2010/02/23 -gendb
 */

#ifndef _TBL_INF_PI_CTRL_DEF_H
#define _TBL_INF_PI_CTRL_DEF_H
/*   Default values for table tbl_inf_pi_ctrl.    */
#define	batch_no_DEF	"                                "
#define	mdl_id_DEF	"                    "
#define	file_name_DEF	"                                                  "
#define	rslt_file_name_DEF	"                                                  "
#define	status_DEF	"  "
#define	rslt_status_DEF	"  "
#define	busi_type_DEF	"   "
#define	oprt_mode_DEF	" "
#define	total_amt_DEF	"                            "
#define	total_cnt_DEF	"          "
#define	succ_cnt_DEF	"          "
#define	fail_cnt_DEF	"          "
#define	debt_amt_DEF	"                            "
#define	cret_amt_DEF	"                            "
#define	debt_cnt_DEF	"          "
#define	cret_cnt_DEF	"          "
#define	rqst_date_DEF	"        "
#define	oprt_date_DEF	"        "
#define	pi_eod_DEF	" "
#define	time_bgn_DEF	"      "
#define	time_end_DEF	"      "
#define	stcd_DEF	" "
#define	ctrl_DEF	" "
#define	stdt_DEF	"        "
#define	incd_DEF	"    "
#define	mits_DEF	" "
#define	con_in_DEF	" "
#define	con_mg_DEF	"                                        "
#define	rsv_in1_DEF	" "
#define	rsv_in2_DEF	" "
#define	rsv_fld1_DEF	"        "
#define	rsv_fld2_DEF	"                "
#define	rsv_fld3_DEF	" "

#endif
