/*
 *  Copyright 2006, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  function:dbauto.h
 *
 *  Edit History:
 *
 *     2010/03/06 -gendb
 */

#ifndef _BTH_PK_HOST_TXN_DEF_H
#define _BTH_PK_HOST_TXN_DEF_H
/*   Default values for table tbl_pk_host_txn.    */
#define	inter_brh_code_DEF	"    "
#define	date_settlmt_DEF	"        "
#define	key_host_DEF	"                                                "
#define	term_ssn_DEF	"            "
#define	pan_DEF	"                   "
#define	txn_num_DEF	"    "
#define	debits_credits_flag_DEF	" "
#define	amt_trans_DEF	"             "
#define	host_ssn_DEF	"            "
#define	host_date_DEF	"        "
#define	host_trans_time_DEF	"      "
#define	amt_trans_fee_DEF	"             "
#define	replacement_amts_DEF	"             "
#define	amt_add2_DEF	"             "
#define	amt_add3_DEF	"             "
#define	account_in_DEF	"                    "
#define	agent_num_DEF	"       "
#define	channel_num_DEF	"  "
#define	state_DEF	" "
#define	orig_date_settlmt_DEF	"        "
#define	orig_term_ssn_DEF	"            "
#define	reserved_host_1_DEF	"                    "
#define	reserved_host_2_DEF	"                    "
#define	reserved_host_3_DEF	"                    "
#define	reserved_host_4_DEF	"                                "
#define	reserved_host_5_DEF	"                                "
#define	act_check_stu_DEF	" "

#endif
