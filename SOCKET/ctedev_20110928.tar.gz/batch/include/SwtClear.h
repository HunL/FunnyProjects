/*****************************************************************************/
/*                 Shanghai Huateng Software System Inc.                     */
/*****************************************************************************/
/* PROGRAM NAME: SwtLogProc.h                                                */
/* DESCRIPTIONS: The save and forward process server.                        */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/*****************************************************************************/
/*    ͷ�ļ�
 *
 *  Edit History:
 *    2009/02/04 create by  wei_chunzi
 */

static char _Batch_h_ID[]="$Id: SwtClear.h,v 1.1.1.1 2011/08/19 10:56:07 ctedev Exp $";
#ifndef _SWTCLEAR_H
#define _SWTCLEAR_H

#include <limits.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <sys/timeb.h>
#include <string.h>

#include "DbsDef.h"
#include "HtLog.h"


#define  CLEAR_FLAG_Y      '0'
#define  CLEAR_FLAG_N      '1'
#define  CLEAR_TBL_ONL     '0'
#define  CLEAR_TBL_BKE     '1'
#define  CLEAR_TBL_HIS     '2'

#define  TRANS_FLAG_Y      '0'
#define  TRANS_FLAG_N      '1'


#endif
