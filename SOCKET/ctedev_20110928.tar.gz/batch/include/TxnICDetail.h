#ifndef _TXN_IC_DETAIL_H_
#define _TXN_IC_DETAIL_H_

#define DBS_NOTFOUND 100
#define DBS_SUCCESS 0

struct tbl_txn_ic_detail_def {
	char  		msg_type	[   5];
	char  		pan_len	[   3];
	char  		pan	[  20];
	char  		processing_code	[   7];
	char  		amt_trans	[  13];
	char        sys_seq_num [   7];
	char  		inst_time	[   7];
	char  		inst_date	[   9];
	char  		date_expr	[   5];
	char  		stlm_date	[   5];
	char  		pos_entry_mode	[   4];
	char  		card_seq_num	[   4];
	char  		pos_cond_code	[   3];
	char  		pos_pin_cap_code	[   3];
	char  		acq_inst_len	[   3];
	char  		acq_inst_id_code	[  12];
	char  		retrivl_ref	[  13];
	char		authr_id_resp [ 7];
	char  		resp_code	[   3];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		addrsp_data_len	[   3];
	char  		addrsp_data	[  26];
	char  		currcy_code_trans	[   4];
	char  		pin_data	[  17];
	char  		security_inf	[  17];
	char  		f55_data_len	[   4];
	char  		f55_data	[512 + 1];
	char  		f60_data_len	[   4];
	char  		f60_data	[  101];
	char  		f62_data_len	[   4];
	char  		f62_data	[ 513];
	char  		f63_data_len	[   4];
	char  		f63_data	[ 201];
	char  		f64_mac_data	[   9];
	char		term_batch_nm	[	7];
	char  	    txn_flag		[   3];
	char  	    reserve1		[   51];
	char  	    reserve2		[   101];
} ;

#endif
