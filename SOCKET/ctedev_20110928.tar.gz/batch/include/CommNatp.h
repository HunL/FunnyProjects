typedef struct
{
    char template      [6];
    char temp_code     [6];
    char businessSystem[4];
    char channelID     [3];
    char channelDetail [1];
    char fs_tradeCode  [6];
    char orSenderId    [4];
    char orSenderSN    [22];
    char orSenderDate  [8];
    char orSenderTime  [6];
    char ooSenderId    [4];
    char ooSenderSN    [22];
    char ooSenderDate  [8];
    char terminalNo    [10];
    char utId          [10];
    char priority      [2];
    char srcFileName   [30];
    char srcFileDes    [128];
    char synchStatus   [30];
	char fileRecordLen [10];
	char reserved1[12];
	char reserved2[12];
    char fs_receivedID [4];
    char keepLineFeedAndCarriageReturn[4];
}NatpPut_req_cre;

typedef struct 
{
	char template      [6];
	char temp_code     [6];
	char hostId		   [4];
	char libOrPathName [64];
	char docName	   [15];
	char memberName    [10];
	char orSenderId    [4];
	char orSenderSN    [22];
	char orSenderDate  [8];
	char orSenderTime  [6];
	char ooSenderId    [4];
	char ooSenderSN    [22];
	char ooSenderDate  [8];
	char ooSenderTime  [6];
	char fileCategory  [4];
	char terminalNo    [10];
	char utId          [10];
	char srcFileName   [30];
	char srcFileDes    [128];
	char priority      [2];
	char synchStatus   [30];
	char reserved1     [10];
	char reserved2     [66];
}NatpPut_req;

typedef struct 
{
    char template      [6];
    char temp_code     [6];
    char orSenderId    [4];
    char orSenderSN    [22];
	char orSenderDate  [8];
	char direction     [1];
	char utId          [10];
	char hostId        [4];
	char libOrPathName [63];
	char docName       [15];
	char reserved1     [10];
}NatpFile_stat_req;

typedef struct
{
    char template      [6];
    char temp_code     [6];
    char direction     [1];
    char orSenderId    [4];
    char orSenderSN    [22];
    char channelID     [3];
    char channelDetail [1];
    char businessSystem[4];
    char orSenderDate  [8];
    char fs_tradeCode  [6];
    char utId          [10];
}NatpFile_stat_cre_req;


typedef struct 
{
char errorCode          [4];
char errorMsg           [50];
char totalRecordCount   [20];
char totalParseredCount [20];
char statField1Amount   [22];
char statField2Amount   [22];
}NatpPut_rsp;

typedef struct 
{
	char errorCode          [4];
	char errorMsg           [50];
}NatpGet_rsp;

typedef struct 
{
	char orSenderId    [4];
	char orSenderDate  [8];
	char orSenderSN    [22];
}NatpStat_req;

typedef struct 
{
	char orSenderId    [4];
	char orSenderDate  [8];
	char orSenderSN    [22];
	char rsp_code      [2];
	char succ_num      [8];
	char deal_stat     [1];
	char del_desrc     [80];
}NatpStat_rsp;
