/*****************************************************************************/
/*                   Shanghai Huateng Software System Inc.                   */
/*****************************************************************************/
/* PROGRAM NAME: glbSocket.h                                                 */
/* DESCRIPTIONS:                                                             */
/*     This is the include file of  global socket module.                    */
/* $Id: glbSocket.h,v 1.1.1.1 2011/08/19 10:56:07 ctedev Exp $                                                                      */
/*****************************************************************************/
/* MODIFICATION LOG                                                          */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-12-01  Cheng Feng     Initialize                                     */
/*****************************************************************************/

#ifndef __GLBSOCKET_H
#define __GLBSOCKET_H

static char *_glbSocket_h_ID = "$Id: glbSocket.h,v 1.1.1.1 2011/08/19 10:56:07 ctedev Exp $";

#include "glb/glbType.h"

/* ����ԭ�� */

/* ��ʱ���� */
void glbSocketTimeOutHdlr(void);

/* Socket�˿����� */
int glbSocketListen(char *tcpService, INT32 tcpPort,
                    int(*func)( ), INT32 *errCode);

/* Socket�ͻ������� */
int glbSocketConnect(char *hostName, char *tcpService, INT32 tcpPort,
                     int *fd, INT32 *errCode);

#endif
