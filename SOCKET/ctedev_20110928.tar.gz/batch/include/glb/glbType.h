/*****************************************************************************/
/*                   Shanghai Huateng Software System Inc.                   */
/*****************************************************************************/
/* PROGRAM NAME: glbType.h                                                   */
/* DESCRIPTIONS:                                                             */
/*     This is the include file of int type define                           */
/* $Id: glbType.h,v 1.1.1.1 2011/08/19 10:56:07 ctedev Exp $                                                                      */
/*****************************************************************************/
/* MODIFICATION LOG                                                          */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-12-01  Cheng Feng     Initialize                                     */
/*****************************************************************************/

#ifndef __GLBTYPE_H
#define __GLBTYPE_H

static char * _glbType_h_ID="$Id: glbType.h,v 1.1.1.1 2011/08/19 10:56:07 ctedev Exp $";

typedef short                   INT16;
typedef unsigned short          UINT16;
typedef char                    INT8;
typedef unsigned char           UINT8;

#if defined(_LP64) || defined(__64BIT__) || defined(__LP64__)
    #define  _OS_64BIT_
#endif
 
#ifdef _OS_64BIT_
    typedef int                 INT32;
    typedef unsigned int        UINT32;
    typedef long                INT64;
    typedef unsigned long       UINT64;
#else
    typedef long                INT32;
    typedef unsigned long       UINT32;
    typedef long long           INT64;
    typedef unsigned long long  UINT64;
#endif

#endif /* TYPE_H */
