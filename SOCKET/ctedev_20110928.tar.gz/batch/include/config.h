#define HSMCFG_INI "config/hsmcfg.ini"
#define HSMSVR_INI "config/hsmsrv.ini"

#define HSM_IPLEN	15
#define HSM_PORTLEN	8
#define HSM_NUMLEN	4
#define HSM_NUMBERS	255
#define HSM_MAXKEYS	10

struct data_table{
	int 	useflag;
	char 	hsmip[HSM_IPLEN+1];
	int 	hsmport;
	int 	hsmnum;
};

typedef struct {
	char	keyindex[3];
	char	index[5];
	char	bmk[33];
	char	pinkey1[33];
	char	mackey1[33];
	char	pinkey2[33];
	char	mackey2[33];
}HSM_KEYFILE;

HSM_KEYFILE	hsmSourKey;
HSM_KEYFILE hsmDestKey;
