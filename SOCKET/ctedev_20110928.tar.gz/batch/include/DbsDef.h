#ifndef _DBS_DEF_H
#define _DBS_DEF_H

#ifdef _DB_ORA
#define DBS_NOTFOUND		1403
#endif
#ifdef _DB_INFX
#define DBS_NOTFOUND		100
#endif
#ifdef _DB_DB2
#define DBS_NOTFOUND		100
#endif

#define DBS_IND_NULL		-1

/* tbl_srv_param.param_usage value */
#define SRV_PARAM_USAGE_NAME	"0"
#define SRV_PARAM_USAGE_ENV		"1"
#define SRV_PARAM_USAGE_ARG		"2"
#define DBS_SELECT4              2222
/* server env MSG_COMPRESS_FLAG value */
#define FLAG_YES				"Y"
#define FLAG_NO					"N"
#define FLAG_YES_C				'Y'
#define FLAG_NO_C				'N'

/* tbl_card_inf.used_flag */
#define CARD_USED_FLAG_ON		"1"
#define CARD_USED_FLAG_OFF		"0"

/* tbl_txn_inf.rsp_type value */
#define RSP_TYPE_NO_ACCOUNT			'1'
#define RSP_TYPE_RSP_BEFORE_ACCOUNT	'2'
#define RSP_TYPE_RSP_AFTER_ACCOUNT	'3'

/* tbl_txn_inf records num max */
#define TXN_INF_NUM_MAX	500

/* database user/password */
#define SADBSUserPwdFile "TL_HAHA_FILE"

/* tbl_sta_chg_cfg */
#define STA_CHG_IN_USE_FLAG        '1'
#define STA_CHG_UN_USE_FLAG        '0'
#define STA_CHG_NUM_MAX            200
#define STA_CHG_PRGM_FLAG          '1'

/* dbs operation defines for first argument in dbs function */
#define DBS_INIT       0
#define DBS_SELECT     1
#define DBS_LOCK       2
#define DBS_UPDATE     3
#define DBS_SELECT_H   4
#define DBS_DELETE     4
#define DBS_INSERT     5
#define DBS_INSERT_TDB 32 
#define DBS_INSERT_RFS 88 
#define DBS_INSERT_CC  46 
#define DBS_INSERT_BDT 29
#define DBS_INSERT_FCP 39
#define DBS_INSERT_SUCC 33
#define DBS_INSERT_EPOS_t0 43
#define DBS_INSERT_EPOS 44 
#define DBS_INSERT_FAIL 34
#define DBS_INSERT_FRIGN 35
#define DBS_INSERT_BCT 36
#define DBS_INSERT_GM 48 
#define DBS_INSERT_BDB 49
#define DBS_INSERT_APAI 50
#define DBS_INSERT_SCORE 51
#define DBS_INSERT_HOST_SCORE_SUCC 52
#define DBS_INSERT_IPAI_PUB 53
#define DBS_INSERT_GS 54
#define DBS_INSERT_PAY 55
#define DBS_INSERT_PAY_RESULT 56
#define DBS_INSERT1    6
#define DBS_INSERT2    7
#define DBS_INSERT3    8
#define DBS_INSERT4    9

#define DBS_INSERT_ATMP_SUCC  37
#define DBS_INSERT_ATMP_FC_SUCC  39
#define DBS_INSERT_POSP_SUCC  38
#define DBS_INSERT_POSP_SUCC  38
#define DBS_INSERT_EPOSP_SUCC 45

#define DBS_CURSOR     11
#define DBS_CURSOR1    1000
#define DBS_FETCH1     1001 
#define DBS_OPEN1      1002
#define DBS_CLOSE1     1003
#define DBS_CURSOR2    1004
#define DBS_CURSOR3    1005
#define DBS_CURSOR4    1006
#define DBS_CURSOR5    1016
#define DBS_FETCH2     1007 
#define DBS_OPEN2      1008
#define DBS_CLOSE2     1009
#define DBS_FETCH3     1010 
#define DBS_OPEN3      1011
#define DBS_CLOSE3     1012
#define DBS_FETCH4     1013 
#define DBS_OPEN4      1014
#define DBS_CLOSE4     1015
#define DBS_FETCH5     1017 
#define DBS_OPEN5      1018
#define DBS_CLOSE5     1019
#define DBS_FETCH6     1020
#define DBS_OPEN6      1021
#define DBS_CLOSE6     1022
#define DBS_CURSOR6    1023
#define DBS_OPEN       12
#define DBS_CLOSE      13
#define DBS_FETCH      14

#define DBS_SELECT1    20
#define DBS_LOCK1      21
#define DBS_UPDATE1    22
#define DBS_DELETE1	   30
#define DBS_SELECT2    23
#define DBS_LOCK2      24
#define DBS_UPDATE2    25
#define DBS_SELECT3    26
#define DBS_LOCK3      27
#define DBS_UPDATE3    28
#define DBS_INSERT_ERR_MISN 40 
#define DBS_INSERT_CUPS_FLOW 41
#define DBS_INSERT_CUPS_LOGOFEE 42

/* DBS_SELECT21: key_rsp, txn_num */
#define DBS_SELECT21   121
/* DBS_SELECT22: key_revsal, txn_num */
#define DBS_SELECT22   122
/* DBS_SELECT23: key_cancel, txn_num */
#define DBS_SELECT23   123
/* DBS_SELECT24: key_revsal */
#define DBS_SELECT24   124

#define DBS_GET_NEXT_VAL	31

#define MAX_CON_VAL_LEN		35

#define MAX_FLD_NUM		200
#define MAX_MSG_NUM		500
#define MAX_IPC_NUM		50
#define MAX_BMP_NUM		500
#define MAX_CON_NUM		500
#define MAX_CON_VAL_LEN		35
#define MAX_BMP_VAL_LEN		100
#define F000_MSG_TYPE_LEN       4
#define F129_TXN_CODE_LEN       3
#define F130_TXN_NUMBER_LEN     4
#define F131_NEW_HEAD_LEN		46

/* �ڶ��鸽�Ӳ��� */
#define OPEN2                      206 
#define CLOSE2                     207
#define FETCH2                     208

/* �����鸽�Ӳ��� */
#define OPEN4                      209
#define CLOSE4                     210
#define FETCH4                     211

typedef struct {
	short		iBeginPtr;
	short		nFldL;
	short		nFldLenL;
	short		nDataMaxL;
	short		nLenExpVal;
	short		nIndSym;
	short		nDataFormat;
	short		nLenCharSet;
	short		nDataCharSet;
} FldRuleInfDef;

typedef struct {
	short		nMsgL;
	short		naFld[MAX_FLD_NUM];
} IpcRuleInfDef;

typedef struct {
	short		nTxnNumber;
	short		iIpcIndex;
	short		iBmpIndex;
	short		iMandBmpIndex;
	unsigned char	saMsgType[F000_MSG_TYPE_LEN];
	unsigned char	saTxnCode[F129_TXN_CODE_LEN];
} MsgRuleInfDef;

typedef struct {
	unsigned char	saVal[MAX_BMP_VAL_LEN];
} BmpRuleInfDef;

typedef struct {
	short		iFldIndex;
	short		iBeginPtr;
	short		nValL;
	unsigned char	saVal[MAX_CON_VAL_LEN];
	short		nTxnNumber;
	short		iNextGrp;
} ConRuleInfDef;

typedef struct {
	FldRuleInfDef	taFldInf[MAX_FLD_NUM];
	short		nMsgNum;
	MsgRuleInfDef	taMsgInf[MAX_MSG_NUM];
	short		nConNum;
	ConRuleInfDef	taConInf[MAX_CON_NUM];
	IpcRuleInfDef	taIpcInf[MAX_IPC_NUM];
	BmpRuleInfDef	taBmpInf[MAX_BMP_NUM];
} TransRuleInfDef;

typedef struct{
	long			usage_key;
	TransRuleInfDef	tTransRule;
} T_UsageTransRuleDef;


typedef struct
{
    int txn_num;
    char    val[36];
}IPCTblConInf;

typedef struct
{
    int          nCount;
    IPCTblConInf ipcTblConInf[1000];
}IPCRuleInf;

/* Dbs functions */
int DbsConnect ();
int DbsBegin ();
int DbsCommit ();
int DbsRollback ();
int DbsDelete (char *sType,char *sDate);
#endif

