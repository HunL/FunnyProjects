#ifndef _CONVERT_H
#define _CONVERT_H

#define LFail                       -1
#define LSuccess                    0
#define LSqlSuccess                 0
#define NTrue                       -1
#define NFalse                      0

#define NIllNullFld                 1
#define NIllLenExp                  2
#define NIllDataExp                 3
#define NIllBmpNull                 4
#define NIllOutputDataExp           5
#define NIllBMPDataExp           	6
#define NIllFormatDataExp         	7
#define NIllMaxlenDataExp         	8

#define SIndNull                    'N'
#define SIndFull                    'Y'

#define NFormatANS                  0
#define NFormatAN                   1
#define NFormatN                    2
#define NFormatZ                    3
#define NFormatMMDDhhmmss           4
#define NFormatMMDD                 5
#define NFormathhmmss               6
#define NFormatYYMMDD               7
#define NFormatSN                   8
#define NFormatP1                   9
#define NFormatP2                   10
#define NFormatP3                   11

#define NCharSetAscii               0
#define NCharSetEbcdic              1
#define NCharSetBcdl                2
#define NCharSetBcdr                3
#define NCharSetBinary              4

#define NUsrErrFldInf               1
#define NUsrErrMsgInf               2
#define NUsrErrConInf               3
#define NUsrErrBmpInf               4
#define NUsrErrIpcInf               5

#define NMaxMsgBufL                 2900

#define ISSPACE(x)      (x == ' ')
#define ISALPHA(x)      ((x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z'))
#define ISNUMBER(x)     (x >= '0' && x <= '9')
#define FLDNONEXIST(x)  (x != SIndFull)

/* the number of convert tables' records, etc. */ 
#define MAX_FLD_NUM		200
#define MAX_MSG_NUM		500
#define MAX_IPC_NUM		50
#define MAX_BMP_NUM		500
#define MAX_CON_NUM		500
#define MAX_CON_VAL_LEN		35
#define MAX_BMP_VAL_LEN		100
#define F000_MSG_TYPE_LEN       4
#define F129_TXN_CODE_LEN       3
#define F130_TXN_NUMBER_LEN     4
#define F131_NEW_HEAD_LEN		46

/* BEGIN: structs for convert */
typedef struct {
	short		iBeginPtr;
	short		nFldL;
	short		nFldLenL;
	short		nDataMaxL;
	short		nLenExpVal;
	short		nIndSym;
	short		nDataFormat;
	short		nLenCharSet;
	short		nDataCharSet;
} FldRuleInfDef;

typedef struct {
	short		nMsgL;
	short		naFld[MAX_FLD_NUM];
} IpcRuleInfDef;

typedef struct {
	short		iFldIndex;
	short		iBeginPtr;
	short		nValL;
	unsigned char	saVal[MAX_CON_VAL_LEN];
	short		nTxnNumber;
	short		iNextGrp;
} ConRuleInfDef;

typedef struct {
	short		nTxnNumber;
	short		iIpcIndex;
	short		iBmpIndex;
	short		iMandBmpIndex;
	unsigned char	saMsgType[F000_MSG_TYPE_LEN];
	unsigned char	saTxnCode[F129_TXN_CODE_LEN];
} MsgRuleInfDef;

typedef struct {
	unsigned char	saVal[MAX_BMP_VAL_LEN];
} BmpRuleInfDef;

typedef struct {
	FldRuleInfDef	taFldInf[MAX_FLD_NUM];
	short		nMsgNum;
	MsgRuleInfDef	taMsgInf[MAX_MSG_NUM];
	short		nConNum;
	ConRuleInfDef	taConInf[MAX_CON_NUM];
	IpcRuleInfDef	taIpcInf[MAX_IPC_NUM];
	BmpRuleInfDef	taBmpInf[MAX_BMP_NUM];
} TransRuleInfDef;
/* END: structs for convert */

short ConvInit(long lFldInfKey, 
               long lMsgInfKey,
               long lConInfKey, 
               long lBmpInfKey,
               long lIpcInfKey,
               TransRuleInfDef *ptTransRuleInf);
short ConvOutToIn(void *psInBuf,
                  short nInBufL,
                  short nInBufCharSet,
                  short nInBufCompres,
                  TransRuleInfDef *ptTransRuleInf,
                  void *psOutBuf,
                  short *pnOutBufL);
short ConvInToOut(void *psInBuf,
                  short nInBufL,
                  short nOutBufCharSet,
                  short nOutBufCompres,
                  TransRuleInfDef *ptTransRuleInf,
                  void *psOutBuf,
                  short *pnOutBufL);

#endif
