#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/times.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <unistd.h>
#include <math.h>
#include <errno.h>
#include <string.h>
#include <memory.h>
#include <signal.h>
#include <glob.h>

#include "HtLog.h"
#include "BufChg.h"
#include "DbsDef.h"
#include "DbsTbl.h"

#define CRiskUsed  49
#define MAXMISNS            200
#define MAXCHILDS           1000
#define FLD_MISN_NUM_LEN    4
#define LOG_NAME_LEN_MAX    32
#define RECORD_LEN_MAX      2048

#define WT_STTL_STATUS      0
#define IN_STTL_STATUS      1
#define ERR_OCC_STATUS      2
#define STTL_DONE_STATUS    3
#define WT_RSP_STATUS    	4
#define WT_REDO_STATUS    	5
#define DW_EMPTY_FILE    	9

/*�⿨�����ļ�״̬*/
#define FORE_FILE_STATE     0
#define CC_FILE_STATE       6

/*tbl_proc_ctl״̬�궨��*/
#define PROC_DONE_STATUS    0
#define PROC_WAITING_STATUS 1
#define PROC_INPROC_STATUS  2
#define PROC_ERR_STATUS     3
#define PROC_CANCEL_STATUS  4

/*tbl_sta_ctl״̬�궨��*/
#define ALREADY_PROVEKED_ADJUST   "62"
#define WAITING_PROVEKE_ADJUST    "60"
#define WAITING_NEGOTIATION       "64"
#define BRACHBACKCONFIRM          "67"
#define HAVENOTANSWERED           "05"
#define CUPANSWERDAIJI            "10"
#define WAITINGTURNBACK           "11"

#define TXNTYPEE74                "E74"

#define STLM_OK                   1
#define STLM_ERROR                2
#define STLM_CUP_HAVE             3
#define STLM_HOST_HAVE            4
#define STLM_PRE_AUTH             5
#define STLM_CUP_REVSAL           6
#define STLM_DIRECT_POS			  7
#define STLM_ATM_UNKNOWN	      8
#define STLM_ATM_TFRZ	      	  9
#define STLM_BDB_HOST_HAVE	  	  0

#define STA_NULL           "zz"
#define TXN_NUM_NULL           "zzzz"

#define CARESULT_EVEN      "1"
#define CARESULT_EXCESS    "2"
#define CARESULT_SUSPECT   "3"

#define SUSPECT            "1"
#define ATMP_HAVE          "2"
#define BOTH_HAVE          "3"

#define POSP_HAVE          "2"

#define ERROR_ATMP         9
#define INIT_ATMP          0
#define SUSPECT_ATMP       1
#define EVEN_ATMP          2
#define UNNORMAL_ATMP      3
#define EVEN_POSP          2

#define ATMP_FILE_PATH "ATMP"
#define ATMP_FILE_NAME "CWDYYYYMMDDZ.del"
#define SCORE_FILE_PATH "SCORE"
#define SCORE_FILE_NAME "DZ_502_YYYYMMDD_YYYYMMDD_POS001.txt"
#define ATMP_FC_FILE_NAME "CWDYYYYMMDDFC.del"
#define POSP_FILE_PATH "POSP"
#define POSP_FILE_NAME "INDYYYYMMDDPCOM.txt"
#define CC_FILE_PATH "CRCARD"
#define HOST_CORE_BDB "csphostYYYYMMDD"

#define XMCHNT_ACCT_FILE "JLYYMMDD01MSUM"
#define XMCHNT_ACCT_RESULT_FILE "cmsposerrYYYYMMDD.txt"
#define XMCHNT_TRANSE_FEE_FILE "FEEJLYYYYMMDD"
#define SOSA_MZ      "123456"
#define IC_OFFLINE_FILE  "YYYYMMDD.OFFLINE"
#define IC_POSP_BDB_FILE "ic_bdb_YYYYMMDD"
#define IC_POSP_BDT_FILE "ONFYYMMDD01"



#define TYPE_CUP_TDB    "CUP_TDB"
#define TYPE_CUP_BDT    "CUP_BDT"
#define TYPE_RCUP       "RCUP"
#define TYPE_FE         "FE"
#define TYPE_HOST       "HOST"
#define TYPE_ERR        "ERR"
#define TYPE_RERR       "RERR"
#define TYPE_LOGO       "LOGO"

#define MZ_TXN_SUM        "SBMMDDSUM"
#define HOST_FILE_PATH       "HOST"
#define IC_FILE_PATH         "SAVE"
#define SB_FILE_PATH         "MZSB"
#define MID_TRANS_CODE       "0500104"
#define HOST_FILE_NAME       "POSHOSTYYYYMMDD"
#define HOST_BCT_FILE_NAME   "FC0001YYYYMMDD"
#define HOST_GM_FILE_NAME   "GM0001YYYYMMDD"
#define HOST_GS_FILE_NAME   "GS0001YYYYMMDD"
#define HOST_CC_FILE_NAME     "0305-GMT-YYYYMMDD"
#define CC_ERR_FILE_NAME     "0305-DFERROR-300000-YYYYMMDD"
#define FE_FILE_PATH         "FE"
#define FE_SUCC_FILE_NAME    "gcsuccgoldYYYYMMDD.data"
#define FE_FILE_NAME    	 "cspcmpYYYYMMDD"
#define EPOS_T1_FILE         "epsop-t1-YYYYMMDD.txt"
#define FE_BDB_FILE_NAME     "gcbdbgoldYYYYMMDD.data"
#define FE_FAIL_FILE_NAME    "gcfailgoldYYYYMMDD.data"
#define FE_FRIGN_FILE_NAME   "gcforeignYYYYMMDD.data"
#define FE_CRCARD_FILE_NAME    "gccrcardYYYYMMDD.data"
#define FE_HIS_FILE_NAME     "tbl_txn.txt"
#define FE_SUCC_CC_NAME      "CC_TXN_INF_YYYYMMDD.txt"
#define IC_HOST_FILE_NAME    "YYYYMMDD.TXN"
#define IC_DIFF_FILE_NAME    "YYYYMMDD.DIFF"
#define IC_CUPSERR_FILE      "YYYYMMDD.CUPSERR"
#define IC_SUBK_FILE         "SUBBANK"
#define IC_ZZ_FILE_NAME     "ICAPYYYYMMDD"
#define BDB_IC_TXN           "1255,1365,3365,5365,1385,1375"
#define TXN_CANCEL           "3101,3091"
#define CREDIT_FILE_PATH     "CREDIT"
#define CT_SUCC_NAME		 "GDBTXINP.TXT"
#define CT_SUCC_D_NAME       "GDBTXEPP.TXT"

#define BANK_CODE_PATH		 "442000002"

#define MAXTXNS             150
#define MSG_SRC_ID_ANY      "9999"
#define DATE_LEN            8
#define FILE_NAME_LEN_MAX   200
#define SAMAXCOMMITCNT      1000
#define COMP_KEY_LEN        10
#define BUF_CHG_USAGE_KEY   7
#define FILE_COUNT_MAX      100
#define PATTERN_COUNT_MAX   5
#define PATTERN_LEN_MAX     64
#define INTER_INST_ID_LEN   10
#define INTER_BRH_CODE_LEN  10
#define SQL_BUF_LEN         256
#define NMMaxPartInfN       200
#define NMMaxOprInfN        200
#define NMMaxInstN          200

#define BRH_STA_NO          "1"
#define BRH_STA_PROC        "2"
#define BRH_STA_ALL         "3"
#define BRH_STA_HANG        "4"
#define BRH_STA_CC          "6"
#define CHIEF_INST_CODE     "100093"

#define MISN_TYPE_PROC      "C"

#define TFRZ_TXN_NUM        "1131"

#define POS_UNFLAG          "0"
#define POS_FLAG            "1"

#define PR                  "0"
#define PK                  "1"

#define ERR_Y				"1"
#define	ERR_N				"0"


/*modified by brady.lee @ 2010-10-27*/

#define DBS_OK                  0

#ifdef _DB_ORA
#define DBS_NOTFOUND            1403
#define DBS_FETCHNULL           -1405
#endif
#ifdef _DB_INFX
#define DBS_NOTFOUND            100
#define DBS_FETCHNULL           -407
#endif
#ifdef _DB_DB2
#define DBS_KEYDUPLICATE            -803
#define DBS_NOTFOUND            100
#define DBS_FETCHNULL           -305
#define DBS_ROWMORE          -811
#endif
/*mod end*/

typedef struct
{
    char sCompKey[COMP_KEY_LEN+1];
    char sFileName[FILE_NAME_LEN_MAX+1];
    char sInterInstId[INTER_INST_ID_LEN + 1];
} stFileDef;

stIpcDftRuleDef     gtIpcDftRule;
bciMBufChgInfDef    gtBufChgRule;
IPCRuleInf   ipcRuleInf;

typedef struct
{
	char       inter_brh_code[10+1];
	char       brh_level[1+1];
}stInstInf;

typedef struct
{
	int             index_no;
	char    file_type[8+1];
	char    comp_key[10+1];
	char    pattern_val[64+1];
}TBL_txn_file_ptn_Def;
typedef struct
{
	int        inst_num;
	stInstInf  inst_def[NMMaxInstN];
}stInstDef;
/*
typedef struct
{
    char       mission_index[4+1];
    char       mission_name[40+1];
    int        mission_level;
    int        mission_status;
    int        data_num;
    int        child_num;
    int        commit_flag;
    int        commit_num;
}tbl_mission_inf_def;*/
typedef struct 
{
    char       inter_brh_code[10+1];
    char       settlmt_date[8+1];
	char   tbl_proc_name[60+1];
    int        tbl_proc_flag;
    int        tbl_proc_para1;
    int        tbl_proc_para2;
    int        tbl_proc_para3;
}tbl_proc_ctl_def;
typedef struct
{
    char       inter_brh_code[10+1];
    char       mission_index[4+1];
    char       mission_name[40+1];
    char       mission_date[8+1];
    char       mission_weekday[1+1];
    char       mission_hour[2+1];
    int        mission_date_adj;
    int        data_num;
    int        child_num;
    int        commit_flag;
    int        commit_num;
}tbl_mission_time_def;

typedef struct
{
	char       inter_brh_code[10+1];
    char       settlmt_date[8+1];
    char       mission_index[4+1];
    int        child_id;
    int        commit_flag;
    int        commit_num;
    int        child_begin_point;
    int        child_end_point;
    int        child_finish_point;
    int        child_err_point;
    int        child_status;
}tbl_child_inf_def;

typedef struct
{
	char       inter_brh_code[10+1];
    char       mission_index[4+1];
    char       mission_date[8+1];
    char       mission_weekday[1+1];
    char       mission_hour[2+1];
    int        mission_date_adj;
    int        child_id;
    int        commit_flag;
    int        commit_num;
    int        child_begin_point;
    int        child_end_point;
    int        child_finish_point;
    int        child_err_point;
    int        child_status;
}tbl_child_time_def;

typedef struct
{
    char    inter_brh_code[10+1];
    char    stoday[8+1];
    char    syesterday[8+1];
    char    snextdate[8+1];
    char    sstartdate[8+1];
    char    sforestartdate[8+1];
}tbl_date_inf_def;

typedef struct
{
	char trans_id[4+1];
	char p_trans_name[8+1];
	int  line_no;
}bth_id_name_def;

typedef struct
{
	char brh_id[10+1];
	char brh_level[1+1];
}tbl_brh_info_def1;
/*
typedef struct
{
	char inter_brh_code[10+1];
	char settlmt_date[8+1];
	char mission_index [4+1];
	int child_id;
	int commit_flag;         
	int commit_num;
	int child_begin_point;
	int child_end_point;
	int child_finish_point;
	int child_err_point;
	int child_status;
	int finish_point;
}tbl_child_inf_def;
*/

typedef struct
{
	char inter_brh_code[10+1];
	char settlmt_date[8+1];
	char mission_index [4+1];
	char mission_name[40+1];
	int mission_level;
	int mission_status;         
	int data_num;
	int child_num;
	int commit_flag;
	int commit_num;
	char start_time[40+1];
	char end_time[40+1];
}tbl_mission_inf_def;

typedef struct
{
	char    inter_brh_code[10+1];
    char    date_settlmt[8+1];
    char    key_cup[48+1];
    char    flag_result[1+1];
    char    txn_type[3+1];
    char    txn_num[4+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    cup_ssn[6+1];
    char    trans_date_time[10+1];
    char    pan[19+1];
    char    amt_trans[12+1];
    char    replacement_amts[12+1];
    char    amt_trans_fee[12+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    retrivl_ref[12+1];
    char    pos_cond_code[2+1];
    char    authr_id_resp[6+1];
    char    rcvg_code[11+1];
    char    orig_cup_ssn[6+1];
    char    resp_code[2+1];
    char    pos_entry_mode[3+1];
    char    fee_credit[12+1];
    char    fee_debit[12+1];
    char    fee_xfer[12+1];
    char    flag_sd[1+1];
    char    fee_cdhr[12+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[19+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[19+1];
    char    card_seq_num[3+1];
    char    term_cap[1+1];
    char    chip_cond[1+1];
    char    orig_date_time[10+1];
    char    issuer_code[11+1];
    char    flag_domestic[1+1];
    char    channel_type[2+1];
    char    reserved_cup[32+1];
    char    misc_flag[8+1];
    char    reserved_cup2[300+1];
    long     seq_num;
    char    inter_inst_id[6+1];

} bth_cup_txn_def;

typedef struct
{
	short    inter_brh_code;
    short    date_settlmt;
    short    key_cup;
    short    flag_result;
    short    txn_type;
    short    txn_num;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    cup_ssn;
    short    trans_date_time;
    short    pan;
    short    amt_trans;
    short    replacement_amts;
    short    amt_trans_fee;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    card_accp_term_id;
    short    card_accp_id;
    short    retrivl_ref;
    short    pos_cond_code;
    short    authr_id_resp;
    short    rcvg_code;
    short    orig_cup_ssn;
    short    resp_code;
    short    pos_entry_mode;
    short    fee_credit;
    short    fee_debit;
    short    fee_xfer;
    short    flag_sd;
    short    fee_cdhr;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    card_seq_num;
    short    term_cap;
    short    chip_cond;
    short    orig_date_time;
    short    issuer_code;
    short    flag_domestic;
    short    channel_type;
    short    reserved_cup;
    short    misc_flag;
    short    reserved_cup2;
    short    seq_num;
    short    inter_inst_id;

} bth_cup_txn_def_ind;

typedef struct
{
	char    inter_brh_code[10+1];
    char    date_settlmt[8+1];
    char    key_cup[48+1];
    char    flag_result[1+1];
    char    txn_type[3+1];
    char    txn_num[4+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    cup_ssn[6+1];
    char    trans_date_time[10+1];
    char    pan[19+1];
    char    amt_trans[12+1];
    char    replacement_amts[12+1];
    char    amt_trans_fee[12+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    retrivl_ref[12+1];
    char    pos_cond_code[2+1];
    char    authr_id_resp[6+1];
    char    rcvg_code[11+1];
    char    orig_cup_ssn[6+1];
    char    resp_code[2+1];
    char    pos_entry_mode[3+1];
    char    fee_credit[12+1];
    char    fee_debit[12+1];
    char    fee_xfer[12+1];
    char    flag_sd[1+1];
    char    fee_cdhr[12+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[19+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[19+1];
    char    card_seq_num[3+1];
    char    term_cap[1+1];
    char    chip_cond[1+1];
    char    orig_date_time[10+1];
    char    issuer_code[11+1];
    char    flag_domestic[1+1];
    char    channel_type[2+1];
    char    reserved_cup[32+1];
    char    misc_flag[8+1];
    char    eci_flag[2+1];
    char    stage_pay_add_fee[12+1];
    char    add_inf[14+1];
    char    fwd_sett_id_code[11+1];
    char    out_sett_id_code[11+1];
    char    in_sett_id_code[11+1];
    char    reserve_flag[1+1];
    char    cancel_flag[1+1];
    char    cups_date_settlmt[4+1];
    char    sett_count[2+1];
    char    card_accp_name[40+1];
    char    currcy_code_trans[3+1];
    char    cups_acq_sett_auto_fee[9+1];
    char    mchnt_fee[9+1];
    char    mchnt_sett_id_code[11+1];
    char    mchnt_sett_id_code_fee[9+1];
    char    acq_ser_id_1[11+1];
    char    acq_ser_id_1_fee[9+1];
    char    acq_ser_id_2[11+1];
    char    acq_ser_id_2_fee[9+1];
    char    acq_ser_id_3[11+1];
    char    acq_ser_id_3_fee[9+1];
    char    acq_ser_id_4[11+1];
    char    acq_ser_id_4_fee[9+1];
    char    acq_ser_id_5[11+1];
    char    acq_ser_id_5_fee[9+1];
    char    acq_ser_id_6[11+1];
    char    acq_ser_id_6_fee[9+1];
    char    acq_ser_id_7[11+1];
    char    acq_ser_id_7_fee[9+1];
    char    acq_ser_id_8[11+1];
    char    acq_ser_id_8_fee[9+1];
    char    acq_ser_id_9[11+1];
    char    acq_ser_id_9_fee[9+1];
    char    acq_ser_id_10[11+1];
    char    acq_ser_id_10_fee[9+1];
    char    cups_sett_acq_fee1[9+1];
    char    cups_sett_acq_fee2[9+1];
    char    cups_sett_acq_fee3[9+1];
    char    reserved_cup2[300+1];
    int     seq_num;
    char    inter_inst_id[6+1];
} bth_cup_txn_bdt_def;

typedef struct
{
	short    inter_brh_code;
    short    date_settlmt;
    short    key_cup;
    short    flag_result;
    short    txn_type;
    short    txn_num;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    cup_ssn;
    short    trans_date_time;
    short    pan;
    short    amt_trans;
    short    replacement_amts;
    short    amt_trans_fee;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    card_accp_term_id;
    short    card_accp_id;
    short    retrivl_ref;
    short    pos_cond_code;
    short    authr_id_resp;
    short    rcvg_code;
    short    orig_cup_ssn;
    short    resp_code;
    short    pos_entry_mode;
    short    fee_credit;
    short    fee_debit;
    short    fee_xfer;
    short    flag_sd;
    short    fee_cdhr;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    card_seq_num;
    short    term_cap;
    short    chip_cond;
    short    orig_date_time;
    short    issuer_code;
    short    flag_domestic;
    short    channel_type;
    short    reserved_cup;
    short    misc_flag;
    short    eci_flag;
    short    stage_pay_add_fee;
    short    add_inf;
    short    fwd_sett_id_code;
    short    out_sett_id_code;
    short    in_sett_id_code;
    short    reserve_flag;
    short    cancel_flag;
    short    cups_date_settlmt;
    short    sett_count;
    short    card_accp_name;
    short    currcy_code_trans;
    short    cups_acq_sett_auto_fee;
    short    mchnt_fee;
    short    mchnt_sett_id_code;
    short    mchnt_sett_id_code_fee;
    short    acq_ser_id_1;
    short    acq_ser_id_1_fee;
    short    acq_ser_id_2;
    short    acq_ser_id_2_fee;
    short    acq_ser_id_3;
    short    acq_ser_id_3_fee;
    short    acq_ser_id_4;
    short    acq_ser_id_4_fee;
    short    acq_ser_id_5;
    short    acq_ser_id_5_fee;
    short    acq_ser_id_6;
    short    acq_ser_id_6_fee;
    short    acq_ser_id_7;
    short    acq_ser_id_7_fee;
    short    acq_ser_id_8;
    short    acq_ser_id_8_fee;
    short    acq_ser_id_9;
    short    acq_ser_id_9_fee;
    short    acq_ser_id_10;
    short    acq_ser_id_10_fee;
    short    cups_sett_acq_fee1;
    short    cups_sett_acq_fee2;
    short    cups_sett_acq_fee3;
    short    reserved_cup2;
    short    seq_num;
    short    inter_inst_id;
} bth_cup_txn_bdt_def_ind;

typedef struct
{
	char    inter_brh_code[10+1];
    char    date_settlmt_8[9];
    char    key_cup[49];
    char    key_host[49];
    char    flag_result[2];
    char    flag_domestic[2];
    char    channel_num[3];
    char    flag_err[2];
    char    inst_date[9];
    char    sys_seq_num[7];
    char    inst_time[7];
    char    msg_src_id[5];
    char    txn_num[5];
    char    trans_code[4];
    char    trans_type[2];
    char    trans_state[2];
    char    revsal_flag[2];
    char    revsal_ssn[7];
    char    cancel_flag[2];
    char    cancel_ssn[7];
    char    host_date[9];
    char    host_ssn[13];
    char    term_ssn[13];
    char    key_rsp[33];
    char    key_revsal[33];
    char    key_cancel[33];
    char    header_buf[47];
    char    msg_type[5];
    char    pan_len[3];
    char    pan[20];
    char    processing_code[7];
    char    amt_trans[13];
    char    amt_settlmt[13];
    char    amt_cdhldr_bil[13];
    char    trans_date_time[11];
    char    conv_rate_stlm[9];
    char    conv_rate_cdhldr[9];
    char    cup_ssn[7];
    char    time_local_trans[7];
    char    date_local_trans[5];
    char    date_expr[5];
    char    date_settlmt[5];
    char    date_conv[5];
    char    mchnt_type[5];
    char    acq_cntry_code[4];
    char    pos_entry_mode[4];
    char    pos_cond_code[3];
    char    pos_pin_cap_code[3];
    char    amt_trans_fee[10];
    char    acq_inst_id_code[12];
    char    fwd_inst_id_code[12];
    char    retrivl_ref[13];
    char    authr_id_resp[7];
    char    resp_code[3];
    char    card_accp_term_id[9];
    char    card_accp_id[16];
    char    card_accp_name[41];
    char    currcy_code_trans[4];
    char    currcy_code_stlm[4];
    char    currcy_code_chldr[4];
    char    fld_reserved_len[4];
    char    fld_reserved[31];
    char    orig_data_elemts[43];
    char    replacement_amts[43];
    char    rcvg_code_len[3];
    char    rcvg_code[12];
    char    acct_id1_len[3];
    char    acct_id1[29];
    char    acct_id2_len[3];
    char    acct_id2[29];
    char    host_trans_fee1[13];
    char    host_trans_fee2[13];
    char    tlr_num[9];
    char    open_inst[16];
    char    stlm_inst[16];
    char    batch_flag[2];
    char    batch_date[9];
    char    msq_type[17];
    char    amt_return[13];
    char    authr_id_r[7];
    char    misc_flag[33];
    char    misc_1[129];
    char    misc_2[129];
    int     seq_num;

} bth_gc_txn_def;

typedef struct
{
	short    inter_brh_code;
    short     date_settlmt_8;
    short     key_cup;
    short     key_host;
    short    flag_result;
    short    flag_domestic;
    short    channel_num;
    short    flag_err;
    short    inst_date;
    short    sys_seq_num;
    short    inst_time;
    short    msg_src_id;
    short    txn_num;
    short    trans_code;
    short    trans_type;
    short    trans_state;
    short    revsal_flag;
    short    revsal_ssn;
    short    cancel_flag;
    short    cancel_ssn;
    short    host_date;
    short    host_ssn;
    short    term_ssn;
    short    key_rsp;
    short    key_revsal;
    short    key_cancel;
    short    header_buf;
    short    msg_type;
    short    pan_len;
    short    pan;
    short    processing_code;
    short    amt_trans;
    short    amt_settlmt;
    short    amt_cdhldr_bil;
    short    trans_date_time;
    short    conv_rate_stlm;
    short    conv_rate_cdhldr;
    short    cup_ssn;
    short    time_local_trans;
    short    date_local_trans;
    short    date_settlmt;
    short    date_conv;
    short    mchnt_type;
    short    acq_cntry_code;
    short    pos_entry_mode;
    short    pos_cond_code;
    short    pos_pin_cap_code;
    short    amt_trans_fee;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    retrivl_ref;
    short    authr_id_resp;
    short    resp_code;
    short    card_accp_term_id;
    short    card_accp_id;
    short    card_accp_name;
    short    currcy_code_trans;
    short    currcy_code_stlm;
    short    currcy_code_chldr;
    short    fld_reserved_len;
    short    fld_reserved;
    short    orig_data_elemts;
    short    replacement_amts;
    short    rcvg_code_len;
    short    rcvg_code;
    short    acct_id1_len;
    short    acct_id1;
    short    acct_id2_len;
    short    acct_id2;
    short    host_trans_fee1;
    short    host_trans_fee2;
    short    tlr_num;
    short    open_inst;
    short    stlm_inst;
    short    batch_flag;
    short    batch_date;
    short    msq_type;
    short    amt_return;
    short    authr_id_r;
    short    misc_flag;
    short    misc_1;
    short    misc_2;
    short    seq_num;

} bth_gc_txn_def_ind;

typedef struct
{
	char    inter_brh_code[10+1];
    char    host_date[8+1];
    char    key_host[48+1];
    char    flag_result[1+1];
    char    host_ssn[12+1];
    char    term_ssn[12+1];
    char    date_settlmt[8+1];
    char    txn_num[4+1];
    char    sys_seq_num[6+1];
    char    pan[20+1];
    char    amt_trans[13+1];
    char    replacement_amts[13+1];
    char    amt_trans_fee[13+1];
    char    host_term_id[12+1];
    char    host_tlr_num[12+1];
    char    host_accp_id[32+1];
    char    retrivl_ref[12+1];
    char    authr_id_resp[6+1];    
    char    orig_cup_ssn[6+1];
    char    reserved_host_1[32+1];
    char    reserved_host_2[32+1];
    char    misc_flag[8+1];    
    char    debits_credits_flag[1+1];
    char    host_trans_time[6+1];
    char    agent_num[7+1];
    char    channel_num[2+1];
    char    state[1+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    amt_add2[13+1];
    char    amt_add3[13+1];
    char    account_in[20+1];
    char    flag_err[2];
    int     seq_num;
} bth_host_txn_def;

typedef struct
{
	short    inter_brh_code;
    short    host_date;
    short    key_host;
    short    flag_result;
    short    host_ssn;
    short    term_ssn;
    short    date_settlmt;
    short    txn_num;
    short    sys_seq_num;
    short    pan;
    short    amt_trans;
    short    replacement_amts;
    short    amt_trans_fee;
    short    host_term_id;
    short    host_tlr_num;
    short    host_accp_id;
    short    retrivl_ref;
    short    authr_id_resp;    
    short    orig_cup_ssn;
    short    reserved_host_1;
    short    reserved_host_2;
    short    misc_flag;    
    short    debits_credits_flag;
    short    host_trans_time;
    short    agent_num;
    short    channel_num;
    short    state;
    short    orig_date_settlmt;
    short    orig_term_ssn;
    short    amt_add2;
    short    amt_add3;
    short    account_in;
    short    flag_err;
    short    seq_num;

} bth_host_txn_def_ind;

typedef struct
{
	char    inter_brh_code[10+1];
    char    date_settlmt[8+1];
    char    key_cup[48+1];
    char    flag_result[1+1];
    char    txn_type[3+1];
    char    txn_num[4+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    cup_ssn[6+1];
    char    trans_date_time[10+1];
    char    pan[19+1];
    char    amt_trans[12+1];
    char    replacement_amts[12+1];
    char    amt_trans_fee[12+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    retrivl_ref[12+1];
    char    pos_cond_code[2+1];
    char    authr_id_resp[6+1];
    char    rcvg_code[11+1];
    char    orig_cup_ssn[6+1];
    char    resp_code[2+1];
    char    pos_entry_mode[3+1];
    char    fee_credit[12+1];
    char    fee_debit[12+1];
    char    fee_xfer[12+1];
    char    flag_sd[1+1];
    char    fee_cdhr[12+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[19+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[19+1];
    char    card_seq_num[3+1];
    char    term_cap[1+1];
    char    chip_cond[1+1];
    char    orig_date_time[10+1];
    char    issuer_code[11+1];
    char    flag_domestic[1+1];
    char    channel_type[2+1];
    char    reserved_cup[32+1];
    char    misc_flag[8+1];
    char    card_accptr_name_loc[40+1];
    char    currcy_code_settlmt[3+1];
    char    amt_settlmt[12+1];
    char    conv_rate_settlmt[8+1];
    char    date_conv[4+1];
    char    fee_credit_settlmt[12+1];
    char    fee_debit_settlmt[12+1];
    char    card_type[3+1];
    char    currcy_code_trans[3+1];
    char    err_fee_credit_trans[12+1];
    char    err_fee_credit_settlmt[12+1];
    char    err_fee_debit_trans[12+1];
    char    err_fee_debit_settlmt[12+1];
    int     seq_num;
    
} bth_cup_fe_txn_def;

typedef struct
{
	short    inter_brh_code;
    short    date_settlmt;
    short    key_cup;
    short    flag_result;
    short    txn_type;
    short    txn_num;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    cup_ssn;
    short    trans_date_time;
    short    pan;
    short    amt_trans;
    short    replacement_amts;
    short    amt_trans_fee;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    card_accp_term_id;
    short    card_accp_id;
    short    retrivl_ref;
    short    pos_cond_code;
    short    authr_id_resp;
    short    rcvg_code;
    short    orig_cup_ssn;
    short    resp_code;
    short    pos_entry_mode;
    short    fee_credit;
    short    fee_debit;
    short    fee_xfer;
    short    flag_sd;
    short    fee_cdhr;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    card_seq_num;
    short    term_cap;
    short    chip_cond;
    short    orig_date_time;
    short    issuer_code;
    short    flag_domestic;
    short    channel_type;
    short    reserved_cup;
    short    misc_flag;
    short    card_accptr_name_loc;
    short    currcy_code_settlmt;
    short    amt_settlmt;
    short    conv_rate_settlmt;
    short    date_conv;
    short    fee_credit_settlmt;
    short    fee_debit_settlmt;
    short    card_type;
    short    currcy_code_trans;
    short    err_fee_credit_trans;
    short    err_fee_credit_settlmt;
    short    err_fee_debit_trans;
    short    err_fee_debit_settlmt;
    short    seq_num;
} bth_cup_fe_txn_def_ind;

typedef struct
{
	char    inter_brh_code[11];
    char    manage_inst[5];
    char    trans_date_time[11];
    char    cup_ssn[7];
    char    acq_inst_id_code[12];
    char    fwd_inst_id_code[12];
    char    term_ssn[13];
    char    inst_date[9];
    char    inst_time[7];
    char    host_ssn[13];
    char    host_date[9];
    char    date_settlmt[9];
    char    gc_txn_num[5];
    char    txn_num[5];
    char    msg_type[5];
    char    processing_code[7];
    char    mchnt_type[5];
    char    pos_cond_code[3];
    char    channel_num[3];
    char    orig_cup_ssn[7];
    char    orig_date_time[11];
    char    orig_date_settlmt[9];
    char    orig_term_ssn[13];
    char     orig_host_date[9];
    char    orig_host_ssn[13];
    char    pan[20];
    double    amt_trans;
    char    authr_id_resp[7];
    char    resp_code[3];
    char    host_recode[8];
    double    fee_credit;
    double    fee_debit;
    double    fee_cdhr;
    double    fee_inst;
    double    fee_logo;
    char    pos_entry_mode[4];
    char    card_accp_term_id[9];
    char    card_accp_id[16];
    char    card_accp_addr[41];
    char    retrivl_ref[13];
    char    rcvg_code[12];
    char    issuer_code[12];
    char    deal_flg[3];
    char    tran_flg[2];
    char    code_xfer_o[12];
    char    pan_xfer_o[29];
    char    code_xfer_i[12];
    char    pan_xfer_i[29];
    char    currcy_code_trans[4];
    char    currcy_code_stlm[4];
    double  amt_settlmt;
    char    conv_rate_stlm[9];
    char    date_conv[9];
    char    flag_domestic[2];
    char    flag_city[2];
    char    area_code[5];
    char    inst_no[12];
    char    bank_flag[7];
    char    flag_result[2];
    char    issuer_ins_id_cd[10+1];
    char    acqu_ins_id_cd[10+1];
    char    cup_ins_id[6+1];
} bth_txn_dtl_def;

typedef struct
{
	short    inter_brh_code;
    short    manage_inst;
    short    trans_date_time;
    short    cup_ssn;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    term_ssn;
    short    inst_date;
    short    inst_time;
    short    host_ssn;
    short    host_date;
    short    date_settlmt;
    short    gc_txn_num;
    short    txn_num;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    pos_cond_code;
    short    channel_num;
    short    orig_cup_ssn;
    short    orig_date_time;
    short    orig_date_settlmt;
    short    orig_term_ssn;
    short     orig_host_date;
    short    orig_host_ssn;
    short    pan;
    short    amt_trans;
    short    authr_id_resp;
    short    resp_code;
    short    host_recode;
    short    fee_credit;
    short    fee_debit;
    short    fee_cdhr;
    short    fee_inst;
    short    fee_logo;
    short    pos_entry_mode;
    short    card_accp_term_id;
    short    card_accp_id;
    short    card_accp_addr;
    short    retrivl_ref;
    short    rcvg_code;
    short    issuer_code;
    short    deal_flg;
    short    tran_flg;
    short    code_xfer_o;    
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    currcy_code_trans;
    short    currcy_code_stlm;
    short    amt_settlmt;
    short    conv_rate_stlm;
    short    date_conv;
    short    flag_domestic;
    short    flag_city;
    short    area_code;
    short    inst_no;
    short    bank_flag;
    short    flag_result;
} bth_txn_dtl_def_ind;

/*****LiQian**********/
typedef struct
{
    char  trans_type[3+1];
    char  term_teller_id[8+1];
    char  pan[19+1];
    char  trans_amt[15+1];
    char  trans_date[8+1];
    char  trans_time[8+1];
    char  term_ssn[4+1];
    char  host_ssn[12+1];
    char  cup_ssn[12+1];
    char  batch_id[4+1];
    char  stlm_result[1+1];
    char  cup_stlm_date[8+1];
    char  flag[1+1];
    int  seq_num;
}bth_atmp_txn_def;

typedef struct
{
	char  inter_brh_code[10+1];
    char  trans_type[3+1];
    char  pan[19+1];
    char  trans_amt[15+1];
    char  trans_date[8+1];
    char  trans_time[8+1];
    char  term_ssn[4+8+1];
    char  host_ssn[12+1];
    char  cup_ssn[12+1];
    char  batch_id[4+1];
    char  stlm_result[1+1];
    char  cup_stlm_date[8+1];
    char  flag[1+1];
    int  seq_num;
}bth_atmp_bdt_def;

typedef struct
{
	short  inter_brh_code;
    short  trans_type;
    short  term_teller_id;
    short  pan;
    short  trans_amt;
    short  trans_date;
    short  trans_time;
    short  term_ssn;
    short  host_ssn;
    short  cup_ssn;
    short  batch_id;
    short  stlm_result;
    short  cup_stlm_date;
    short  flag;
    short  seq_num;
}bth_atmp_txn_def_ind;


typedef struct
{
    char        inter_brh_code[10+1];
	char  		key_host[ 48+1 ];
	char  		pri_key	[  48+1];
	char  		orig_key	[  48+1];
	char  		del_key	[  48+1];
	char  		related_key	[  48+1];
	char  		local_settle_in	[   2];
	char  		settle_dt	[   9];
	char  		iss_in	[   2];
	char  		msg_tp	[   5];
	char  		pri_acct_no	[  33];
	char  		proc_cd	[   7];
	char  		trans_at	[  13];
	char  		sys_tra_no	[   7];
	char  		card_expired_date	[   9];
	char  		transmsn_dt_tm	[  15];
	char  		mchnt_tp	[   5];
	char  		pos_entry_md_cd	[   4];
	char  		card_seq_num	[   4];
	char  		pos_cond_cd	[   3];
	char  		pos_pin_cap_cd	[   3];
	char  		acq_ins_id_cd	[  14];
	char  		retri_ref_no	[  13];
	char  		auth_id_resp_cd	[   7];
	char  		resp_cd	[   3];
	char  		term_id	[   9];
	char  		mchnt_cd	[  16];
	char  		rcv_ins_id_cd	[  14];
	char  		term_seq_num	[   5];
	char  		fee_amt	[  13];
	char  		curr_cd	[   4];
	char  		acct_balance	[  13];
	char  		auth_sum_amt	[  13];
	char  		msg_type_id	[   3];
	char  		batch_num	[   7];
	char  		orig_trans_batch	[   7];
	char  		orig_pos_seq_num	[   7];
	char  		orig_trans_date	[   9];
	char  		orig_auth_md	[   3];
	char  		orig_auth_ins	[  14];
	char  		oper_id_cd	[   9];
	char  		trans_chnl	[   3];
	char  		in_bt_flag[  2];
	char  		trans_date[  9];
	char  		reserve_pan	[ 33];
	char  		flag_result[ 1+1];
    int         seq_num;
}bth_posp_txn_def;

typedef struct
{
    short          inter_brh_code;
    short          key_host;
    short          pri_key    ;
    short          orig_key    ;
    short          del_key    ;
    short          related_key    ;
    short          local_settle_in    ;
    short          settle_dt    ;
    short          iss_in    ;
    short          msg_tp    ;
    short          pri_acct_no    ;
    short          proc_cd    ;
    short          trans_at    ;
    short          sys_tra_no    ;
    short          card_expired_date    ;
    short          transmsn_dt_tm    ;
    short          mchnt_tp    ;
    short          pos_entry_md_cd    ;
    short          card_seq_num    ;
    short          pos_cond_cd    ;
    short          pos_pin_cap_cd    ;
    short          acq_ins_id_cd    ;
    short          retri_ref_no    ;
    short          auth_id_resp_cd    ;
    short          resp_cd    ;
    short          term_id    ;
    short          mchnt_cd    ;
    short          rcv_ins_id_cd    ;
    short          term_seq_num    ;
    short          fee_amt    ;
    short          curr_cd    ;
    short          acct_balance    ;
    short          auth_sum_amt    ;
    short          msg_type_id    ;
    short          batch_num    ;
    short          orig_trans_batch    ;
    short          orig_pos_seq_num    ;
    short          orig_trans_date    ;
    short          orig_auth_md    ;
    short          orig_auth_ins    ;
    short          oper_id_cd    ;
    short          trans_chnl    ;
    short          in_bt_flag;
    short          trans_date;
    short          reserve_pan    ;
    short          flag_result;
    short          seq_num;
}bth_posp_txn_def_ind;

typedef struct
{
	char  inter_brh_code[10+1];
    char  trans_type[4+1];
    char  bt_bb_flag[1+1];
    char  pan[19+1];
    char  trans_amt[15+1];
    char  trans_date[8+1];
    char  trans_time[8+1];
    char  term_ssn[4+8+1];
    char  host_ssn[12+1];
    char  cup_ssn[12+1];
    char  batch_id[4+1];
    char  stlm_result[1+1];
    char  cup_stlm_date[8+1];
	char  card_accp_id[15+1];
	char  acq_inst_id_code[11+1];
	char  term_teller_id[8+1];
	char  trans_fee[12+1];
	char  ruz_amt[12+1];
	char  ruz_pan[28+1];
	char  batch_flag[1+1];
	char  msg_type[2+1];
    char  flag[1+1];
    int  seq_num;
}bth_eposp_def;

typedef struct
{
	short  inter_brh_code;
    short  trans_type;
    short  bt_bb_flag;
    short  pan;
    short  trans_amt;
    short  trans_date;
    short  trans_time;
    short  term_ssn;
    short  host_ssn;
    short  cup_ssn;
    short  batch_id;
    short  stlm_result;
    short  cup_stlm_date;
	short  card_accp_id;
	short  acq_inst_id_code;
    short  term_teller_id;
	short  trans_fee;
	short  ruz_amt;
	short  ruz_pan;
	short  batch_flag;
	short   msg_type;
    short  flag;
    short  seq_num;
}bth_eposp_def_ind;

typedef struct
{
	short  inter_brh_code;
    short  trans_type;
    short  term_teller_id;
    short  pan;
    short  trans_amt;
    short  trans_date;
    short  trans_time;
    short  term_ssn;
    short  host_ssn;
    short  cup_ssn;
    short  batch_id;
    short  stlm_result;
    short  cup_stlm_date;
    short  flag;
    short  seq_num;
}bth_atmp_bdt_def_ind;

typedef struct
{
	char    inter_bth_code[10+1];
    char    manage_inst[4+1];
    char    trans_date_time[10+1];
    char    cup_ssn[6+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    term_ssn[12+1];
    char    inst_date[8+1];
    char    inst_time[6+1];
    char    host_ssn[12+1];
    char    host_date[8+1];
    char    date_settlmt[8+1];
    char    gc_txn_num[4+1];
    char    txn_num[4+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    pos_cond_code[2+1];
    char    channel_num[2+1];
    char    orig_data_ssn[6+1];
    char    orig_data_time[10+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    orig_host_date[8+1];
    char    orig_host_ssn[12+1];
    char    pan[19+1];
    double  amt_trans;
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    host_recode[7+1];
    double  fee_credit;
    double  fee_debit;         
    double  fee_cdhr;         
    double  fee_inst;         
    double  fee_logo;         
    char    pos_entry_mode[3+1];    
    char    card_accp_term_id[8+1]; 
    char    card_accp_id[15+1];     
    char    card_accp_addr[40+1];   
    char    retrivl_ref[12+1];      
    char    rcvg_code[11+1];        
    char    issuer_code[11+1];      
    char    deal_flg[2+1];         
    char    tran_flg[1+1];         
    char    code_xfer_o[11+1];      
    char    pan_xfer_o[28+1];       
    char    code_xfer_i[11+1];      
    char    pan_xfer_i[28+1];       
    char    currcy_code_trans[3+1]; 
    char    currcy_code_stlm[3+1];  
    double  amt_settlmt;         
    char    conv_rate_stlm[8+1];    
    char    date_conv[8+1];         
    char    flag_domestic[1+1];     
    char    flag_city[1+1];         
    char    area_code[4+1];         
    char    inst_no[11+1];         
    char    bank_flag[6+1];         
    char    flag_result[1+1];       
    int     err_flag;         
    char    sys_seq_num[6+1];       
    char    reversal_date[10+1];      
    char    cup_batch_id[6+1];      
    char    audit_batch_id[6+1];    
    char    affirm_date[8+1];       
    char    audit_date[8+1];        
    char    cup_date[8+1];         
    char    err_state[1+1];      
    char    fld_reserved[30+1];
}bth_dtl_bdt_def;

typedef struct 
{
    short    manage_inst;      
    short    trans_date_time;  
    short    cup_ssn;          
    short    acq_inst_id_code; 
    short    fwd_inst_id_code; 
    short    term_ssn;         
    short    inst_date;        
    short    inst_time;        
    short    host_ssn;         
    short    host_date;        
    short    date_settlmt;     
    short    gc_txn_num;       
    short    txn_num;          
    short    msg_type;         
    short    processing_code;  
    short    mchnt_type;       
    short    pos_cond_code;    
    short    channel_num;      
    short    orig_data_ssn;    
    short    orig_data_time;   
    short    orig_date_settlmt;
    short    orig_term_ssn;    
    short    orig_host_date;   
    short    orig_host_ssn;    
    short    pan;              
    short    amt_trans;        
    short    authr_id_resp;    
    short    resp_code;        
    short    host_recode;      
    short    fee_credit;       
    short    fee_debit;        
    short    fee_cdhr;         
    short    fee_inst;         
    short    fee_logo;         
    short    pos_entry_mode;   
    short    card_accp_term_id;
    short    card_accp_id;     
    short    card_accp_addr;   
    short    retrivl_ref;      
    short    rcvg_code;        
    short    issuer_code;      
    short    deal_flg;         
    short    tran_flg;         
    short    code_xfer_o;      
    short    pan_xfer_o;       
    short    code_xfer_i;      
    short    pan_xfer_i;       
    short    currcy_code_trans;
    short    currcy_code_stlm; 
    short    amt_settlmt;      
    short    conv_rate_stlm;   
    short    date_conv;        
    short    flag_domestic;    
    short    flag_city;        
    short    area_code;        
    short    inst_no;          
    short    bank_flag;        
    short    flag_result;      
    short    err_flag;         
    short    sys_seq_num;      
    short    reversal_date;     
    short    cup_batch_id;     
    short    audit_batch_id;   
    short    affirm_date;      
    short    audit_date;       
    short    cup_date;         
    short    err_state;        
    short    fld_reserved; 
}bth_dtl_bdt_def_ind;

typedef struct
{
    char    manage_inst[4+1];
    char    trans_date_time[10+1];
    char    cup_ssn[6+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    term_ssn[12+1];
    char    inst_date[8+1];
    char    inst_time[6+1];
    char    host_ssn[12+1];
    char    host_date[8+1];
    char    date_settlmt[8+1];
    char    gc_txn_num[4+1];
    char    txn_num[4+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    pos_cond_code[2+1];
    char    channel_num[2+1];
    char    orig_data_ssn[6+1];
    char    orig_data_time[10+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    orig_host_date[8+1];
    char    orig_host_ssn[12+1];
    char    pan[19+1];
    double  amt_trans;
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    host_recode[7+1];
    double  fee_credit;
    double  fee_debit;
    double  fee_cdhr;
    double  fee_inst;
    double  fee_logo;
    char    pos_entry_mode[3+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    card_accp_addr[40+1];
    char    retrivl_ref[12+1];
    char    rcvg_code[11+1];
    char    issuer_code[11+1];
    char    deal_flg[2+1];
    char    tran_flg[1+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[28+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[28+1];
    char    currcy_code_trans[3+1];
    char    currcy_code_stlm[3+1];
    double  amt_settlmt;
    char    conv_rate_stlm[8+1];
    char    date_conv[8+1];
    char    flag_domestic[1+1];
    char    flag_city[1+1];
    char    area_code[4+1];
    char    inst_no[11+1];
    char    bank_flag[6+1];
    char    flag_result[1+1];
    char    flag[1+1];
}bth_temp_tdb_def;

typedef struct
{
    short    manage_inst;
    short    trans_date_time;
    short    cup_ssn;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    term_ssn;
    short    inst_date;
    short    inst_time;
    short    host_ssn;
    short    host_date;
    short    date_settlmt;
    short    gc_txn_num;
    short    txn_num;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    pos_cond_code;
    short    channel_num;
    short    orig_data_ssn;
    short    orig_data_time;
    short    orig_date_settlmt;
    short    orig_term_ssn;
    short    orig_host_date;
    short    orig_host_ssn;
    short    pan;
    short    amt_trans;
    short    authr_id_resp;
    short    resp_code;
    short    host_recode;
    short    fee_credit;
    short    fee_debit;
    short    fee_cdhr;
    short    fee_inst;
    short    fee_logo;
    short    pos_entry_mode;
    short    card_accp_term_id;
    short    card_accp_id;
    short    card_accp_addr;
    short    retrivl_ref;
    short    rcvg_code;
    short    issuer_code;
    short    deal_flg;
    short    tran_flg;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    currcy_code_trans;
    short    currcy_code_stlm;
    short    amt_settlmt;
    short    conv_rate_stlm;
    short    date_conv;
    short    flag_domestic;
    short    flag_city;
    short    area_code;
    short    inst_no;
    short    bank_flag;
    short    flag_result;
    short    flag;
}bth_temp_tdb_def_ind;

typedef struct 
{
    char zwrq[8+1];
    char mita[21];
    char otnm[63+1];
    double amba;
    char miac[21];
    char acnm[63+1];
    double acbl;
}bth_temp_out_def;

/********11-26*******/

typedef struct st_MISN_FUN
{
    char    caMisnNum[FLD_MISN_NUM_LEN+1];
    int     (*pfTotlFun)();
    int     (*pfMisnFun)( int, int);
    char    caMisnDsp[50];
} MISNFUN;

/*bth_cup_err*/
typedef struct
{
	char    inter_brh_code[10+1];
    char    date_settlmt[8+1];
    char    key_cup[48+1];
    char    flag_result[1+1];
    char    txn_type[3+1];
    char    txn_num[4+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    cup_ssn[6+1];
    char    trans_date_time[10+1];
    char    pan[19+1];
    char    amt_trans[12+1];
    char    replacement_amts[12+1];
    char    amt_trans_fee[12+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    retrivl_ref[12+1];
    char    pos_cond_code[2+1];
    char    authr_id_resp[6+1];
    char    rcvg_code[11+1];
    char    orig_cup_ssn[6+1];
    char    resp_code[2+1];
    char    pos_entry_mode[3+1];
    char    fee_credit[12+1];
    char    fee_debit[12+1];
    char    fee_xfer[12+1];
    char    flag_sd[1+1];
    char    fee_cdhr[12+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[19+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[19+1];
    char    card_seq_num[3+1];
    char    term_cap[1+1];
    char    chip_cond[1+1];
    char    orig_date_time[10+1];
    char    issuer_code[11+1];
    char    flag_domestic[1+1];
    char    channel_type[2+1];
    char    reserved_cup[32+1];
    char    misc_flag[8+1];
    char    fwd_sett_id_code[11+1];
    char    out_sett_id_code[11+1];
    char    in_sett_id_code[11+1];
    char    orig_channel_type[2+1];
    char    card_accp_name[40+1];
    char    reserve1[94+1];
    char    orig_txn_type[3+1];
    char    mchnt_fee[9+1];
    char    acq_ser_id_1[11+1];
    char    acq_ser_id_1_fee[9+1];
    char    acq_ser_id_2[11+1];
    char    acq_ser_id_2_fee[9+1];
    char    acq_ser_id_3[11+1];
    char    acq_ser_id_3_fee[9+1];
    char    acq_ser_id_4[11+1];
    char    acq_ser_id_4_fee[9+1];
    char    acq_ser_id_5[11+1];
    char    acq_ser_id_5_fee[9+1];
    char    acq_ser_id_6[11+1];
    char    acq_ser_id_6_fee[9+1];
    char    acq_ser_id_7[11+1];
    char    acq_ser_id_7_fee[9+1];
    char    acq_ser_id_8[11+1];
    char    acq_ser_id_8_fee[9+1];
    char    acq_ser_id_9[11+1];
    char    acq_ser_id_9_fee[9+1];
    char    acq_ser_id_10[11+1];
    char    acq_ser_id_10_fee[9+1];
    char    cups_sett_acq_fee1[9+1];
    char    cups_sett_acq_fee2[9+1];
    char    cups_sett_acq_fee3[9+1];
    char    reserve2[200+1];
    int     seq_num;
}bth_cup_err_def;

typedef struct
{
	short    inter_brh_code;
    short    date_settlmt;
    short    key_cup;
    short    flag_result;
    short    txn_type;
    short    txn_num;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    cup_ssn;
    short    trans_date_time;
    short    pan;
    short    amt_trans;
    short    replacement_amts;
    short    amt_trans_fee;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    card_accp_term_id;
    short    card_accp_id;
    short    retrivl_ref;
    short    pos_cond_code;
    short    authr_id_resp;
    short    rcvg_code;
    short    orig_cup_ssn;
    short    resp_code;
    short    pos_entry_mode;
    short    fee_credit;
    short    fee_debit;
    short    fee_xfer;
    short    flag_sd;
    short    fee_cdhr;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    card_seq_num;
    short    term_cap;
    short    chip_cond;
    short    orig_date_time;
    short    issuer_code;
    short    flag_domestic;
    short    channel_type;
    short    reserved_cup;
    short    misc_flag;
    short    fwd_sett_id_code;
    short    out_sett_id_code;
    short    in_sett_id_code;
    short    orig_channel_type;
    short    card_accp_name;
    short    reserve1;
    short    orig_txn_type;
    short    mchnt_fee;
    short    acq_ser_id_1;
    short    acq_ser_id_1_fee;
    short    acq_ser_id_2;
    short    acq_ser_id_2_fee;
    short    acq_ser_id_3;
    short    acq_ser_id_3_fee;
    short    acq_ser_id_4;
    short    acq_ser_id_4_fee;
    short    acq_ser_id_5;
    short    acq_ser_id_5_fee;
    short    acq_ser_id_6;
    short    acq_ser_id_6_fee;
    short    acq_ser_id_7;
    short    acq_ser_id_7_fee;
    short    acq_ser_id_8;
    short    acq_ser_id_8_fee;
    short    acq_ser_id_9;
    short    acq_ser_id_9_fee;
    short    acq_ser_id_10;
    short    acq_ser_id_10_fee;
    short    cups_sett_acq_fee1;
    short    cups_sett_acq_fee2;
    short    cups_sett_acq_fee3;
    short    reserve2;
    short    reserved_cup2;
    short    seq_num;
}bth_cup_err_def_ind;

/*tbl_err_mission*/
typedef struct
{
    char    vire_flag[2+1];
    char    currnt_flag[1+1];
    int     seq_no;
    int     grp_no;
    char    key_cup[48+1];
    char    adj_key_cup[48+1];
    char    orig_key_cup[48+1];
    char    operate[10+1];
    char    status[2+1];
    double  amt;
    char    file_name[256+1];
    char    cre_file_name[256+1];
    char    opr_no[10+1];
    char    crt_time[14+1];
    char    misc[100+1];
    char    b_t_flag[1+1];
    char    manage_inst[4+1];
    char    trans_date_time[10+1];
    char    cup_ssn[6+1];
    char    adj_cup_ssn[6+1];
    char    orig_cup_ssn[6+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    term_ssn[12+1];
    char    inst_date[8+1];
    char    inst_time[6+1];
    char    host_ssn[12+1];
    char    host_date[8+1];
    char    date_settlmt[8+1];
    char    gc_txn_num[4+1];
    char    txn_num[4+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    pos_cond_code[2+1];
    char    channel_num[2+1];
    char    orig_data_ssn[6+1];
    char    orig_data_time[10+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    orig_host_date[8+1];
    char    orig_host_ssn[12+1];
    char    pan[19+1];
    double  amt_trans;
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    host_recode[7+1];
    double  fee_credit;
    double  fee_debit;
    double  fee_cdhr;
    double  fee_inst;
    double  fee_logo;
    char    pos_entry_mode[3+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    card_accp_addr[40+1];
    char    retrivl_ref[12+1];
    char    rcvg_code[11+1];
    char    issuer_code[11+1];
    char    deal_flg[2+1];
    char    tran_flg[1+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[28+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[28+1];
    char    currcy_code_trans[3+1];
    char    currcy_code_stlm[3+1];
    double  amt_settlmt;
    char    conv_rate_stlm[8+1];
    char    date_conv[8+1];
    char    flag_domestic[1+1];
    char    flag_city[1+1];
    char    area_code[4+1];
    char    inst_no[11+1];
    char    bank_flag[6+1];
    char    flag_result[1+1];
    char    fwd_rcv_in[1+1];
    int     err_flag;
    char    sys_seq_num[6+1];
    char    cup_batch_id[10+1];
    char    audit_batch_id[10+1];
    char    affirm_date[8+1];
    char    audit_date[8+1];
    char    cup_date[8+1];
    char    err_state[1+1];
    char    host_batch_id[10+1];
    char    fld_reserved[30+1];
}bth_tbl_err_misn_def;


typedef struct
{
	short    inter_brh_code;
    short    currnt_flag;
    short    seq_no;
    short    key_cup;
    short    operate;
    short    status;
    short    amt;
    short    file_name;
    short    cre_file_name;
    short    opr_no;
    short    crt_time;
    short    misc;
    short    b_t_flag;
    short    manage_inst;
    short    trans_date_time;
    short    cup_ssn;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    term_ssn;
    short    inst_date;
    short    inst_time;
    short    host_ssn;
    short    host_date;
    short    date_settlmt;
    short    gc_txn_num;
    short    txn_num;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    pos_cond_code;
    short    channel_num;
    short    orig_data_ssn;
    short    orig_data_time;
    short    orig_date_settlmt;
    short    orig_term_ssn;
    short    orig_host_date;
    short    orig_host_ssn;
    short    pan;
    short    amt_trans;
    short    authr_id_resp;
    short    resp_code;
    short    host_recode;
    short    fee_credit;
    short    fee_debit;
    short    fee_cdhr;
    short    fee_inst;
    short    fee_logo;
    short    pos_entry_mode;
    short    card_accp_term_id;
    short    card_accp_id;
    short    card_accp_addr;
    short    retrivl_ref;
    short    rcvg_code;
    short    issuer_code;
    short    deal_flg;
    short    tran_flg;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    currcy_code_trans;
    short    currcy_code_stlm;
    short    amt_settlmt;
    short    conv_rate_stlm;
    short    date_conv;
    short    flag_domestic;
    short    flag_city;
    short    area_code;
    short    inst_no;
    short    bank_flag;
    short    flag_result;
    short    fwd_rcv_in;
    short    err_flag;
    short    sys_seq_num;
    short    cup_batch_id;
    short    audit_batch_id;
    short    affirm_date;
    short    audit_date;
    short    cup_date;
    short    err_state;
    short    host_batch_id;
    short    fld_reserved;
}bth_tbl_err_misn_def_ind;

typedef struct
{
	char    inter_brh_code[10+1];
	char	date_settlmt[8+1];
	char	key_cup[48+1];
	char	flag_result[1+1];
	char	txn_type[3+1];
	char	txn_num[4+1];
	char	acq_inst_id_code[11+1];
	char	fwd_inst_id_code[11+1];
	char	cup_ssn[6+1];
	char	trans_date_time[10+1];
	char	pan[19+1];
	char	amt_trans[12+1];
	char	replacement_amts[12+1];
	char	amt_trans_fee[12+1];
	char	msg_type[4+1];
	char	processing_code[6+1];
	char	mchnt_type[4+1];
	char	card_accp_term_id[8+1];
	char	card_accp_id[15+1];
	char	retrivl_ref[12+1];
	char	pos_cond_code[2+1];
	char	authr_id_resp[6+1];
	char	rcvg_code[11+1];
	char	orig_cup_ssn[6+1];
	char	resp_code[2+1];
	char	pos_entry_mode[3+1];
	char	fee_credit[12+1];
	char	fee_debit[12+1];
	char	fee_xfer[12+1];
	char	flag_sd[1+1];
	char	fee_cdhr[12+1];
	char	code_xfer_o[11+1];
	char	pan_xfer_o[19+1];
	char	code_xfer_i[11+1];
	char	pan_xfer_i[19+1];
	char	card_seq_num[3+1];
	char	term_cap[1+1];
	char	chip_cond[1+1];
	char	orig_date_time[10+1];
	char	issuer_code[11+1];
	char	flag_domestic[1+1];
	char	channel_type[2+1];
	char	reserved_cup[32+1];
	char	misc_flag[8+1];
	char	reserved_cup2[300+1];
	int     seq_num;
	char	inter_inst_id[6+1];
}bth_cup_txn_fcp_def;

typedef struct
{
	short   inter_brh_code;
	short	date_settlmt;
	short	key_cup;
	short	flag_result;
	short	txn_type;
	short	txn_num;
	short	acq_inst_id_code;
	short	fwd_inst_id_code;
	short	cup_ssn;
	short	trans_date_time;
	short	pan;
	short	amt_trans;
	short	replacement_amts;
	short	amt_trans_fee;
	short	msg_type;
	short	processing_code;
	short	mchnt_type;
	short	card_accp_term_id;
	short	card_accp_id;
	short	retrivl_ref;
	short	pos_cond_code;
	short	authr_id_resp;
	short	rcvg_code;
	short	orig_cup_ssn;
	short	resp_code;
	short	pos_entry_mode;
	short	fee_credit;
	short	fee_debit;
	short	fee_xfer;
	short	flag_sd;
	short	fee_cdhr;
	short	code_xfer_o;
	short	pan_xfer_o;
	short	code_xfer_i;
	short	pan_xfer_i;
	short	card_seq_num;
	short	term_cap;
	short	chip_cond;
	short	orig_date_time;
	short	issuer_code;
	short	flag_domestic;
	short	channel_type;
	short	reserved_cup;
	short	misc_flag;
	short	reserved_cup2;
	short	seq_num;
	short	inter_inst_id;
}bth_cup_txn_fcp_def_ind;

/*bth_dtl_bdt*/
typedef struct
{
	char    inter_brh_code[10+1];
    char    manage_inst[4+1];
    char    trans_date_time[10+1];
    char    cup_ssn[6+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    term_ssn[12+1];
    char    inst_date[8+1];
    char    inst_time[6+1];
    char    host_ssn[12+1];
    char    host_date[8+1];
    char    date_settlmt[8+1];
    char    gc_txn_num[4+1];
    char    txn_num[4+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    pos_cond_code[2+1];
    char    channel_num[2+1];
    char    orig_data_ssn[6+1];
    char    orig_data_time[10+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    orig_host_date[8+1];
    char    orig_host_ssn[12+1];
    char    pan[19+1];
    double  amt_trans;
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    host_recode[7+1];
    double  fee_credit;
    double  fee_debit;
    double  fee_cdhr;
    double  fee_inst;
    double  fee_logo;
    char    pos_entry_mode[3+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    card_accp_addr[40+1];
    char    retrivl_ref[12+1];
    char    rcvg_code[11+1];
    char    issuer_code[11+1];
    char    deal_flg[2+1];
    char    tran_flg[1+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[28+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[28+1];
    char    currcy_code_trans[3+1];
    char    currcy_code_stlm[3+1];
    double  amt_settlmt;
    char    conv_rate_stlm[8+1];
    char    date_conv[8+1];
    char    flag_domestic[1+1];
    char    flag_city[1+1];
    char    area_code[4+1];
    char    inst_no[11+1];
    char    bank_flag[6+1];
    char    flag_result[1+1];
}bth_dtl_err_def;

typedef struct
{
	short    inter_brh_code;
    short    manage_inst;
    short    trans_date_time;
    short    cup_ssn;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    term_ssn;
    short    inst_date;
    short    inst_time;
    short    host_ssn;
    short    host_date;
    short    date_settlmt;
    short    gc_txn_num;
    short    txn_num;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    pos_cond_code;
    short    channel_num;
    short    orig_data_ssn;
    short    orig_data_time;
    short    orig_date_settlmt;
    short    orig_term_ssn;
    short    orig_host_date;
    short    orig_host_ssn;
    short    pan;
    short    amt_trans;
    short    authr_id_resp;
    short    resp_code;
    short    host_recode;
    short    fee_credit;
    short    fee_debit;
    short    fee_cdhr;
    short    fee_inst;
    short    fee_logo;
    short    pos_entry_mode;
    short    card_accp_term_id;
    short    card_accp_id;
    short    card_accp_addr;
    short    retrivl_ref;
    short    rcvg_code;
    short    issuer_code;
    short    deal_flg;
    short    tran_flg;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    currcy_code_trans;
    short    currcy_code_stlm;
    short    amt_settlmt;
    short    conv_rate_stlm;
    short    date_conv;
    short    flag_domestic;
    short    flag_city;
    short    area_code;
    short    inst_no;
    short    bank_flag;
    short    flag_result;
}bth_dtl_err_def_ind;
typedef struct
{
	char    inter_brh_code[10+1];
    char    manage_inst[4+1];
    char    trans_date_time[10+1];
    char    cup_ssn[6+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    term_ssn[12+1];
    char    inst_date[8+1];
    char    inst_time[6+1];
    char    host_ssn[12+1];
    char    host_date[8+1];
    char    date_settlmt[8+1];
    char    gc_txn_num[4+1];
    char    txn_num[4+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    pos_cond_code[2+1];
    char    channel_num[2+1];
    char    orig_data_ssn[6+1];
    char    orig_data_time[10+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    orig_host_date[8+1];
    char    orig_host_ssn[12+1];
    char    pan[19+1];
    double  amt_trans;
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    host_recode[7+1];
    double  fee_credit;
    double  fee_debit;
    double  fee_cdhr;
    double  fee_inst;
    double  fee_logo;
    char    pos_entry_mode[3+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    card_accp_addr[40+1];
    char    retrivl_ref[12+1];
    char    rcvg_code[11+1];
    char    issuer_code[11+1];
    char    deal_flg[2+1];
    char    tran_flg[1+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[28+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[28+1];
    char    currcy_code_trans[3+1];
    char    currcy_code_stlm[3+1];
    double  amt_settlmt;
    char    conv_rate_stlm[8+1];
    char    date_conv[8+1];
    char    flag_domestic[1+1];
    char    flag_city[1+1];
    char    area_code[4+1];
    char    inst_no[11+1];
    char    bank_flag[6+1];
    char    flag_result[1+1];
    char    fwd_rcv_in[1+1];
}bth_dtl_err_gc_def;
typedef struct
{
	short    inter_brh_code;
    short    manage_inst;
    short    trans_date_time;
    short    cup_ssn;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    term_ssn;
    short    inst_date;
    short    inst_time;
    short    host_ssn;
    short    host_date;
    short    date_settlmt;
    short    gc_txn_num;
    short    txn_num;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    pos_cond_code;
    short    channel_num;
    short    orig_data_ssn;
    short    orig_data_time;
    short    orig_date_settlmt;
    short    orig_term_ssn;
    short    orig_host_date;
    short    orig_host_ssn;
    short    pan;
    short    amt_trans;
    short    authr_id_resp;
    short    resp_code;
    short    host_recode;
    short    fee_credit;
    short    fee_debit;
    short    fee_cdhr;
    short    fee_inst;
    short    fee_logo;
    short    pos_entry_mode;
    short    card_accp_term_id;
    short    card_accp_id;
    short    card_accp_addr;
    short    retrivl_ref;
    short    rcvg_code;
    short    issuer_code;
    short    deal_flg;
    short    tran_flg;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    currcy_code_trans;
    short    currcy_code_stlm;
    short    amt_settlmt;
    short    conv_rate_stlm;
    short    date_conv;
    short    flag_domestic;
    short    flag_city;
    short    area_code;
    short    inst_no;
    short    bank_flag;
    short    flag_result;
    short    fwd_rcv_in;
}bth_dtl_err_gc_def_ind;
typedef struct
{
    char    manage_inst[4+1];
    char    trans_date_time[10+1];
    char    cup_ssn[6+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    term_ssn[12+1];
    char    inst_date[8+1];
    char    inst_time[6+1];
    char    host_ssn[12+1];
    char    host_date[8+1];
    char    date_settlmt[8+1];
    char    gc_txn_num[4+1];
    char    txn_num[4+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];
    char    pos_cond_code[2+1];
    char    channel_num[2+1];
    char    orig_data_ssn[6+1];
    char    orig_data_time[10+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    orig_host_date[8+1];
    char    orig_host_ssn[12+1];
    char    pan[19+1];
    double  amt_trans;
    char    authr_id_resp[6+1];
    char    resp_code[2+1];
    char    host_recode[7+1];
    double  fee_credit;
    double  fee_debit;
    double  fee_cdhr;
    double  fee_inst;
    double  fee_logo;
    char    pos_entry_mode[3+1];
    char    card_accp_term_id[8+1];
    char    card_accp_id[15+1];
    char    card_accp_addr[40+1];
    char    retrivl_ref[12+1];
    char    rcvg_code[11+1];
    char    issuer_code[11+1];
    char    deal_flg[2+1];
    char    tran_flg[1+1];
    char    code_xfer_o[11+1];
    char    pan_xfer_o[28+1];
    char    code_xfer_i[11+1];
    char    pan_xfer_i[28+1];
    char    currcy_code_trans[3+1];
    char    currcy_code_stlm[3+1];
    double  amt_settlmt;
    char    conv_rate_stlm[8+1];
    char    date_conv[8+1];
    char    flag_domestic[1+1];
    char    flag_city[1+1];
    char    area_code[4+1];
    char    inst_no[11+1];
    char    bank_flag[6+1];
    char    flag_result[1+1];
    int     err_flag;
    char    sys_seq_num[6+1];
    char    cup_batch_id[10+1];
    char    audit_batch_id[10+1];
    char    affirm_date[8+1];
    char    audit_date[8+1];
    char    cup_date[8+1];
    char    err_state[1+1];
    char    host_batch_id[10+1];
    char    fld_reserved[30+1];
    int     seq_num;
}bth_temp_bdt_def;
typedef struct
{
    short    manage_inst;
    short    trans_date_time;
    short    cup_ssn;
    short    acq_inst_id_code;
    short    fwd_inst_id_code;
    short    term_ssn;
    short    inst_date;
    short    inst_time;
    short    host_ssn;
    short    host_date;
    short    date_settlmt;
    short    gc_txn_num;
    short    txn_num;
    short    msg_type;
    short    processing_code;
    short    mchnt_type;
    short    pos_cond_code;
    short    channel_num;
    short    orig_data_ssn;
    short    orig_data_time;
    short    orig_date_settlmt;
    short    orig_term_ssn;
    short    orig_host_date;
    short    orig_host_ssn;
    short    pan;
    short    amt_trans;
    short    authr_id_resp;
    short    resp_code;
    short    host_recode;
    short    fee_credit;
    short    fee_debit;
    short    fee_cdhr;
    short    fee_inst;
    short    fee_logo;
    short    pos_entry_mode;
    short    card_accp_term_id;
    short    card_accp_id;
    short    card_accp_addr;
    short    retrivl_ref;
    short    rcvg_code;
    short    issuer_code;
    short    deal_flg;
    short    tran_flg;
    short    code_xfer_o;
    short    pan_xfer_o;
    short    code_xfer_i;
    short    pan_xfer_i;
    short    currcy_code_trans;
    short    currcy_code_stlm;
    short    amt_settlmt;
    short    conv_rate_stlm;
    short    date_conv;
    short    flag_domestic;
    short    flag_city;
    short    area_code;
    short    inst_no;
    short    bank_flag;
    short    flag_result;
    short    err_flag;
    short    sys_seq_num;
    short    cup_batch_id;
    short    audit_batch_id;
    short    affirm_date;
    short    audit_date;
    short    cup_date;
    short    err_state;
    short    host_batch_id;
    short    fld_reserved;
    short    seq_num;
}bth_temp_bdt_def_ind;

typedef struct
{
	char    inter_brh_code[10+1];
    char    pri_key[42+1];
    char    orig_key[42+1];
    char    related_key[42+1];
    char    iss_acq_in[1+1];
    char    local_settle_in[1+1];
    char    fill_disc_in[1+1];
    char    err_trans_id[3+1];
    char    settle_dt[8+1];
    char    msg_tp[4+1];
    char    pri_acct_no[21+1];
    char    proc_cd[6+1];
    char    trans_at[12+1];
    char    transmsn_dt_tm[10+1];
    char    sys_tra_no[6+1];
    char    mchnt_tp[4+1];
    char    pos_entry_md_cd[3+1];
    char    card_seq_num[3+1];
    char    pos_cond_cd[3+1];
    char    acq_ins_id_cd[13+1];
    char    fwd_ins_id_cd[13+1];
    char    retri_ref_no[12+1];
    char    auth_id_resp_cd[6+1];
    char    resp_cd[2+1];
    char    term_id[8+1];
    char    mchnt_cd[15+1];
    char    rsn_cd[4+1];
    char    term_entry_cap[1+1];
    char    chip_cond_cd[1+1];
    char    trans_chnl[2+1];
    char    rcv_ins_id_cd[13+1];
    char    iss_ins_id_cd[13+1];
    char    tfr_out_ins_id_cd[13+1];
    char    tfr_out_acct_id[21+1];
    char    tfr_in_ins_id_cd[13+1];
    char    tfr_in_acct_id[21+1];
    char    orig_settle_dt[8+1];
    char    orig_trans_at[12+1];
    char    orig_transmsn_dt_tm[10+1];
    char    orig_sys_tra_no[6+1];
    char    orig_retri_ref_no[12+1];
    char    debt_disc_at[12+1];
    char    cret_disc_at[12+1];
    char    swt_disc_at[12+1];
    char    cust_cups_disc_at[12+1];
    char    cust_gold_disc_at[12+1];
    char    debt_fee_at[12+1];
    char    cret_fee_at[12+1];
    char    gold_iss_ins_id_cd[13+1];
    char    sms_dms_conv_in[1+1];
    char    dom_ext_in[1+1];
    char    err_zone_in[1+1];
    char    cross_dist_in[1+1];
    char    reserve[30+1];
    char    reserve1[30+1];
    char    reserve2[60+1];
    char    reserve3[100+1];
}tbl_dat_cups_flow_def;

typedef struct
{
	short    inter_brh_code;
    short    pri_key;
    short    orig_key;
    short    related_key;
    short    iss_acq_in;
    short    local_settle_in;
    short    err_trans_id;
    short    settle_dt;
    short    msg_tp;
    short    pri_acct_no;
    short    proc_cd;
    short    trans_at;
    short    transmsn_dt_tm;
    short    sys_tra_no;
    short    mchnt_tp;
    short    pos_entry_md_cd;
    short    card_seq_num;
    short    pos_cond_cd;
    short    acq_ins_id_cd;
    short    fwd_ins_id_cd;
    short    retri_ref_no;
    short    auth_id_resp_cd;
    short    resp_cd;
    short    term_id;
    short    mchnt_cd;
    short    rsn_cd;
    short    term_entry_cap;
    short    chip_cond_cd;
    short    trans_chnl;
    short    rcv_ins_id_cd;
    short    iss_ins_id_cd;
    short    tfr_out_ins_id_cd;
    short    tfr_out_acct_id;
    short    tfr_in_ins_id_cd;
    short    tfr_in_acct_id;
    short    orig_settle_dt;
    short    orig_trans_at;
    short    orig_transmsn_dt_tm;
    short    orig_sys_tra_no;
    short    orig_retri_ref_no;
    short    debt_disc_at;
    short    cret_disc_at;
    short    swt_disc_at;
    short    cust_cups_disc_at;
    short    cust_gold_disc_at;
    short    debt_fee_at;
    short    cret_fee_at;
    short    gold_iss_ins_id_cd;
    short    sms_dms_conv_in;
    short    dom_ext_in;
    short    err_zone_in;
    short    cross_dist_in;
    short    reserve;
    short    reserve1;
    short    reserve2;
    short    reserve3;
}tbl_dat_cups_flow_def_ind;

typedef struct
{
	short    inter_brh_code;
    short    pri_key;
    short    orig_key;
    short    related_key;
    short    iss_acq_in;
    short    local_settle_in;
    short    err_trans_id;
    short    settle_dt;
    short    msg_tp;
    short    pri_acct_no;
    short    proc_cd;
    short    trans_at;
    short    transmsn_dt_tm;
    short    sys_tra_no;
    short    mchnt_tp;
    short    pos_entry_md_cd;
    short    card_seq_num;
    short    pos_cond_cd;
    short    acq_ins_id_cd;
    short    fwd_ins_id_cd;
    short    retri_ref_no;
    short    auth_id_resp_cd;
    short    resp_cd;
    short    term_id;
    short    mchnt_cd;
    short    rsn_cd;
    short    term_entry_cap;
    short    chip_cond_cd;
    short    trans_chnl;
    short    rcv_ins_id_cd;
    short    iss_ins_id_cd;
    short    tfr_out_ins_id_cd;
    short    tfr_out_acct_id;
    short    tfr_in_ins_id_cd;
    short    tfr_in_acct_id;
    short    orig_settle_dt;
    short    orig_trans_at;
    short    orig_transmsn_dt_tm;
    short    orig_sys_tra_no;
    short    orig_retri_ref_no;
    short    debt_disc_at;
    short    cret_disc_at;
    short    swt_disc_at;
    short    cust_cups_disc_at;
    short    cust_gold_disc_at;
    short    debt_fee_at;
    short    cret_fee_at;
    short    gold_iss_ins_id_cd;
    short    sms_dms_conv_in;
    short    dom_ext_in;
    short    err_zone_in;
    short    cross_dist_in;
    short    reserve;
    short    reserve1;
    short    reserve2;
    short    reserve3;
	short	seq_num;
}tbl_dat_cups_flow_tmp_def_ind;

typedef struct
{
	char    inter_brh_code[10+1];
	char	date_settlmt[8+1];
	char	acq_inst_id_code1[11+1];
	char	flag_cup_standard[1+1];
	char	flag_cret_debt[2+1];
	char	channel_type[2+1];
	char	kard_medium[1+1];
	char	flag_domestic[1+1];
	char	mchnt_type[4+1];
	char	acq_inst_id_code2[11+1];
	char	acq_inst_id_code[11+1];
	char	fwd_inst_id_code[11+1];
	char	card_inst_id_code[11+1];
	char	rcvg_inst_id_code[11+1];
	char	bill_inst_id_code[11+1];
	char	msg_type[4+1];
	char	processing_code[6+1];
	char	pos_cond_code[2+1];
	char	sys_trace_audit_num[6+1];
	char	transmsn_date_time[10+1];
	char	pan[19+1];
	char	acct_id1[28+1];
	char	acct_id2[28+1];
	char	orig_data_elemts[42+1];
	char	card_accptr_termnl_id[8+1];
	char	card_accptr_id[15+1];
	char	retrivl_ref_num[12+1];
	char	amt_trans[12+1];
	char	fee_acq[12+1];
	char	fee_logo[12+1];
	char	reserved_cup1[12+1];
	char	net_worth[12+1];
	char	reserved_cup2[100+1];
	char	fwd_rcv_in[1+1];
	int		seq_num;
}bth_cup_lfee_def;

typedef struct
{
	short   inter_brh_code;
	short	date_settlmt;
	short	acq_inst_id_code1;
	short	flag_cup_standard;
	short	flag_cret_debt;
	short	channel_type;
	short	kard_medium;
	short	flag_domestic;
	short	mchnt_type;
	short	acq_inst_id_code2;
	short	acq_inst_id_code;
	short	fwd_inst_id_code;
	short	card_inst_id_code;
	short	rcvg_inst_id_code;
	short	bill_inst_id_code;
	short	msg_type;
	short	processing_code;
	short	pos_cond_code;
	short	sys_trace_audit_num;
	short	transmsn_date_time;
	short	pan;
	short	acct_id1;
	short	acct_id2;
	short	orig_data_elemts;
	short	card_accptr_termnl_id;
	short	card_accptr_id;
	short	retrivl_ref_num;
	short	amt_trans;
	short	fee_acq;
	short	fee_logo;
	short	reserved_cup1[12+1];
	short	net_worth[12+1];
	short	reserved_cup2[100+1];
	short	fwd_rcv_in[1+1];
	short	seq_num;
}bth_cup_lfee_def_ind;

typedef struct
{
	char    inter_brh_code[10+1];
	char	pri_key[42+1];
	char	orig_key[42+1];
	char	related_key[42+1];
	char	iss_acq_in[1+1];
	char	local_settle_in[1+1];
	char	settle_dt[8+1];
    char    flow_ins_id_cd[13+1];
	char	acq_first_br_cd[13+1];
	char	iss_first_br_cd[13+1];
	char	is_cups_in[1+1];
	char	debt_cret_in[2+1];
	char	card_media[1+1];
	char	cross_dist_in[1+1];
	char	mchnt_tp[4+1];
	char	acq_second_br_cd[13+1];
	char	iss_second_br_cd[13+1];
	char	acq_ins_id_cd[13+1];
	char	fwd_ins_id_cd[13+1];
	char	iss_ins_id_cd[13+1];
	char	rcv_ins_id_cd[13+1];
	char	sheet_ins_id_cd[13+1];
	char	msg_tp[4+1];
	char	proc_cd[6+1];
	char	pos_cond_cd[2+1];
	char	trans_chnl[2+1];
	char	sys_tra_no[6+1];
	char	transmsn_dt_tm[10+1];
	char	pri_acct_no[19+1];
	char	tfr_out_acct_id[28+1];
	char	tfr_in_acct_id[28+1];
	char	orig_data_elem[42+1];
	char	term_id[8+1];
	char	mchnt_cd[15+1];
	char	retri_ref_no[12+1];
	char	trans_at[12+1];
	char	acq_disc_at[12+1];
	char	iss_disc_at[12+1];
	char	brand_at[12+1];
	char	rsv1[12+1];
	char	weigh_at[12+1];
	char	rsv2[100+1];
	char	cust_gold_disc_at[12+1];
	char	gold_iss_ins_id_cd[13+1];
	char	reserve[30+1];
	char	reserve1[30+1];
	char	reserve2[60+1];
	char	reserve3[100+1];
}tbl_cups_logofee_tmp_def;

typedef struct
{
	char    inter_brh_code[10+1];
	char	pri_key[42+1];
	char	orig_key[42+1];
	char	related_key[42+1];
	char	iss_acq_in[1+1];
	char	local_settle_in[1+1];
	char	settle_dt[8+1];
    char    flow_ins_id_cd[13+1];
	char	acq_first_br_cd[13+1];
	char	iss_first_br_cd[13+1];
	char	is_cups_in[1+1];
	char	debt_cret_in[2+1];
	char	card_media[1+1];
	char	cross_dist_in[1+1];
	char	mchnt_tp[4+1];
	char	acq_second_br_cd[13+1];
	char	iss_second_br_cd[13+1];
	char	acq_ins_id_cd[13+1];
	char	fwd_ins_id_cd[13+1];
	char	iss_ins_id_cd[13+1];
	char	rcv_ins_id_cd[13+1];
	char	sheet_ins_id_cd[13+1];
	char	msg_tp[4+1];
	char	proc_cd[6+1];
	char	pos_cond_cd[2+1];
	char	trans_chnl[2+1];
	char	sys_tra_no[6+1];
	char	transmsn_dt_tm[10+1];
	char	pri_acct_no[19+1];
	char	tfr_out_acct_id[28+1];
	char	tfr_in_acct_id[28+1];
	char	orig_data_elem[42+1];
	char	term_id[8+1];
	char	mchnt_cd[15+1];
	char	retri_ref_no[12+1];
	char	trans_at[12+1];
	char	acq_disc_at[12+1];
	char	iss_disc_at[12+1];
	char	brand_at[12+1];
	char	rsv1[12+1];
	char	weigh_at[12+1];
	char	rsv2[100+1];
	char	cust_gold_disc_at[12+1];
	char	gold_iss_ins_id_cd[13+1];
	char	reserve[30+1];
	char	reserve1[30+1];
	char	reserve2[60+1];
	char	reserve3[100+1];
	int		seq_num;
}tbl_cups_logofee_def;

typedef struct
{
	short   inter_brh_code;
	short	pri_key;
	short	orig_key;
	short	related_key;
	short	iss_acq_in;
	short	local_settle_in;
	short	settle_dt;
    short   flow_ins_id_cd;
	short	acq_first_br_cd;
	short	iss_first_br_cd;
	short	is_cups_in;
	short	debt_cret_in;
	short	card_media;
	short	cross_dist_in;
	short	mchnt_tp;
	short	acq_second_br_cd;
	short	iss_second_br_cd;
	short	acq_ins_id_cd;
	short	fwd_ins_id_cd;
	short	iss_ins_id_cd;
	short	rcv_ins_id_cd;
	short	sheet_ins_id_cd;
	short	msg_tp;
	short	proc_cd;
	short	pos_cond_cd;
	short	trans_chnl;
	short	sys_tra_no;
	short	transmsn_dt_tm;
	short	pri_acct_no;
	short	tfr_out_acct_id;
	short	tfr_in_acct_id;
	short	orig_data_elem;
	short	term_id;
	short	mchnt_cd;
	short	retri_ref_no;
	short	trans_at;
	short	acq_disc_at;
	short	iss_disc_at;
	short	brand_at;
	short	rsv1;
	short	weigh_at;
	short	rsv2;
	short	cust_gold_disc_at;
	short	gold_iss_ins_id_cd;
	short	reserve;
	short	reserve1;
	short	reserve2;
	short	reserve3;
}tbl_cups_logofee_def_ind;

typedef struct
{
	short   inter_brh_code;
	short	pri_key;
	short	orig_key;
	short	related_key;
	short	iss_acq_in;
	short	local_settle_in;
	short	settle_dt;
    short   flow_ins_id_cd;
	short	acq_first_br_cd;
	short	iss_first_br_cd;
	short	is_cups_in;
	short	debt_cret_in;
	short	card_media;
	short	cross_dist_in;
	short	mchnt_tp;
	short	acq_second_br_cd;
	short	iss_second_br_cd;
	short	acq_ins_id_cd;
	short	fwd_ins_id_cd;
	short	iss_ins_id_cd;
	short	rcv_ins_id_cd;
	short	sheet_ins_id_cd;
	short	msg_tp;
	short	proc_cd;
	short	pos_cond_cd;
	short	trans_chnl;
	short	sys_tra_no;
	short	transmsn_dt_tm;
	short	pri_acct_no;
	short	tfr_out_acct_id;
	short	tfr_in_acct_id;
	short	orig_data_elem;
	short	term_id;
	short	mchnt_cd;
	short	retri_ref_no;
	short	trans_at;
	short	acq_disc_at;
	short	iss_disc_at;
	short	brand_at;
	short	rsv1;
	short	weigh_at;
	short	rsv2;
	short	cust_gold_disc_at;
	short	gold_iss_ins_id_cd;
	short	reserve;
	short	reserve1;
	short	reserve2;
	short	reserve3;
	short	seq_num;
}tbl_cups_logofee_tmp_def_ind;

typedef struct
{
	char	manage_inst[4+1];
	char	trans_date_time[10+1];
	char	cup_ssn[6+1];
	char	acq_inst_id_code[11+1];
	char	fwd_inst_id_code[11+1];
	char	term_ssn[12+1];
	char	inst_date[8+1];
	char	inst_time[6+1];
	char	host_ssn[12+1];
	char	host_date[8+1];
	char	date_settlmt[8+1];
	char	gc_txn_num[4+1];
	char	txn_num[4+1];
	char	msg_type[4+1];
	char	processing_code[6+1];
	char	mchnt_type[4+1];
	char	pos_cond_code[2+1];
	char	channel_num[2+1];
	char	orig_data_ssn[6+1];
	char	orig_data_time[10+1];
	char	orig_date_settlmt[8+1];
	char	orig_term_ssn[12+1];
	char	orig_host_date[8+1];
	char	orig_host_ssn[12+1];
	char	pan[19+1];
	double	amt_trans;
	char	authr_id_resp[6+1];
	char	resp_code[2+1];
	char	host_recode[7+1];
	double	fee_credit;
	double	fee_debit;
	double	fee_cdhr;
	double	fee_inst;
	double	fee_logo;
	char	pos_entry_mode[3+1];
	char	card_accp_term_id[8+1];
	char	card_accp_id[15+1];
	char	card_accp_addr[40+1];
	char	retrivl_ref[12+1];
	char	rcvg_code[11+1];
	char	issuer_code[11+1];
	char	deal_flg[2+1];
	char	tran_flg[1+1];
	char	code_xfer_o[11+1];
	char	pan_xfer_o[28+1];
	char	code_xfer_i[11+1];
	char	pan_xfer_i[28+1];
	char	currcy_code_trans[3+1];
	char	currcy_code_stlm[3+1];
	double	amt_settlmt;
	char	conv_rate_stlm[8+1];
	char	date_conv[8+1];
	char	flag_domestic[1+1];
	char	flag_city[1+1];
	char	area_code[4+1];
	char	inst_no[11+1];
	char	bank_flag[6+1];
	char	flag_result[1+1];
	char	bk_ins_id_cd[10+1];
	char	cup_ins_id[6+1];
}bth_dtl_def;

typedef struct
{
	short	manage_inst;
	short	trans_date_time;
	short	cup_ssn;
	short	acq_inst_id_code;
	short	fwd_inst_id_code;
	short	term_ssn;
	short	inst_date;
	short	inst_time;
	short	host_ssn;
	short	host_date;
	short	date_settlmt;
	short	gc_txn_num;
	short	txn_num;
	short	msg_type;
	short	processing_code;
	short	mchnt_type;
	short	pos_cond_code;
	short	channel_num;
	short	orig_data_ssn;
	short	orig_data_time;
	short	orig_date_settlmt;
	short	orig_term_ssn;
	short	orig_host_date;
	short	orig_host_ssn;
	short	pan;
	short	amt_trans;
	short	authr_id_resp;
	short	resp_code;
	short	host_recode;
	short	fee_credit;
	short	fee_debit;
	short	fee_cdhr;
	short	fee_inst;
	short	fee_logo;
	short	pos_entry_mode;
	short	card_accp_term_id;
	short	card_accp_id;
	short	card_accp_addr;
	short	retrivl_ref;
	short	rcvg_code;
	short	issuer_code;
	short	deal_flg;
	short	tran_flg;
	short	code_xfer_o;
	short	pan_xfer_o;
	short	code_xfer_i;
	short	pan_xfer_i;
	short	currcy_code_trans;
	short	currcy_code_stlm;
	short	amt_settlmt;
	short	conv_rate_stlm;
	short	date_conv;
	short	flag_domestic;
	short	flag_city;
	short	area_code;
	short	inst_no;
	short	bank_flag;
	short	flag_result;
	short	bk_ins_id_cd;
	short	cup_ins_id;
}bth_dtl_def_ind;



typedef struct{
    char file_name_ptn[64+1];
    char stlm_inst_id[11+1];
    char file_stat[1+1];
}tbl_file_trans_stat_def;

typedef struct{
    short file_name_ptn_in;
    short stlm_inst_id_in;
    short file_stat_in;
}tbl_file_trans_stat_def_ind;

typedef struct
{
    char       sTblName[60+1];
    char       sPartName[60+1];
    char       sTblSpcName[60+1];
    int        iTblOprFlag;
    int        iIntervalDays;
} stPartInfDef;

typedef struct {
	char        cup_brh_id  [   9];
	int         inter_brh_sta;
	char        file_cfg [ 1025];
	char        file_state  [ 1025];
} tbl_file_trans_state_def;

typedef struct {
	char  		city_code	[   5];
	int		comp_len_1;
	int		begin_pos_1;
	char  		branch_code	[   5];
	char		dsp	[33];
} cst_bank_zone_def;

typedef struct {
	int         index_no;
	char        file_type	[  9];
	char        comp_key    [  11];
	char        pattern_val [  65];
	char		trans_type  [2   ];
	char		flag_1		[2];
	char		flag_2		[2];
	char		flag_3		[3];
	char		flag_4		[3];
	char		misc_1		[129];
	char		misc_2		[129];
	char		dsp			[129 ];
} cst_file_type_inf_def;

typedef struct{
    int     nPartInfN;
    stPartInfDef stPartInf[NMMaxPartInfN];
} stPartitionInfDef;

typedef struct
{
    int		   sTblOprFlag;
    char       sObjectName[60+1];
    char       sParam_1[60+1];
    char       sParam_2[60+1];
    char       sParam_3[60+1];
    char       sParam_4[60+1];
} stOprInfDef;

typedef struct{
    int     nOprInfN;
    stOprInfDef stOprInf[NMMaxOprInfN];
} stOperationInfDef;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		fwd_rcv_in	[   2];
	char  		acqu_ins_id_cd	[  11];
	char  		issuer_ins_id_cd	[  11];
	char  		cup_ins_id	[   7];
	int		seq_num;
} bth_dtl_err_gc_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		acqu_ins_id_cd	[  11];
	char  		cup_ins_id	[   7];
	int		seq_num;
} bth_dtl_bdt_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		fwd_rcv_in	[   2];
	int		seq_num;
} bth_dtl_err_bct_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		fwd_rcv_in	[   2];
	int		seq_num;
} bth_dtl_err_fc_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		inst_code1	[  12];
	char  		acct_id1	[  29];
	char  		inst_code2	[  12];
	char  		acct_id2	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	int		seq_num;
} bth_dtl_bct_tmp_def;

typedef struct {
    char        inter_brh_code  [   11];
    char        manage_inst [   5];
    char        trans_date_time [  11];
    char        cup_ssn [   7];
    char        acq_inst_id_code    [  12];
    char        fwd_inst_id_code    [  12];
    char        term_ssn    [  13];
    char        inst_date   [   9];
    char        inst_time   [   7];
    char        host_ssn    [  13];
    char        host_date   [   9];
    char        date_settlmt    [   9];
    char        gc_txn_num  [   5];
    char        txn_num [   5];
    char        msg_type    [   5];
    char        processing_code [   7];
    char        mchnt_type  [   5];
    char        pos_cond_code   [   3];
    char        channel_num [   3];
    char        orig_data_ssn   [   7];
    char        orig_data_time  [  11];
    char        orig_date_settlmt   [   9];
    char        orig_term_ssn   [  13];
    char        orig_host_date  [   9];
    char        orig_host_ssn   [  13];
    char        pan [  20];
    double      amt_trans;
    char        authr_id_resp   [   7];
    char        resp_code   [   3];
    char        host_recode [   8];
    double      fee_credit;
    double      fee_debit;
    double      fee_cdhr;
    double      fee_inst;
    double      fee_logo;
    char        pos_entry_mode  [   4];
    char        card_accp_term_id   [   9];
    char        card_accp_id    [  16];
    char        card_accp_addr  [  41];
    char        retrivl_ref [  13];
    char        rcvg_code   [  12];
    char        issuer_code [  12];
    char        deal_flg    [   3];
    char        tran_flg    [   2];
    char        inst_code1  [  12];
    char        acct_id1    [  29];
    char        inst_code2  [  12];
    char        acct_id2    [  29];
    char        currcy_code_trans   [   4];
    char        currcy_code_stlm    [   4];
    double      amt_settlmt;
    char        conv_rate_stlm  [   9];
    char        date_conv   [   9];
    char        flag_domestic   [   2];
    char        flag_city   [   2];
    char        area_code   [   5];
    char        inst_no [  12];
    char        bank_flag   [   7];
    char        flag_result [   2];
    int        seq_num;
} bth_dtl_fc_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		date_settlmt	[   9];
	char  		key_cup	[  49];
	char  		flag_result	[   2];
	char  		txn_type	[   4];
	char  		txn_num	[   5];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		cup_ssn	[   7];
	char  		trans_date_time	[  11];
	char  		pan	[  20];
	double		amt_trans;
	double		replacement_amts;
	double		amt_trans_fee;
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		retrivl_ref	[  13];
	char  		pos_cond_code	[   3];
	char  		authr_id_resp	[   7];
	char  		rcvg_code	[  12];
	char  		orig_cup_ssn	[   7];
	char  		resp_code	[   3];
	char  		pos_entry_mode	[   4];
	double		fee_credit;
	double		fee_debit;
	char  		fee_xfer	[  13];
	char  		flag_sd	[   2];
	char  		fee_cdhr	[  13];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  20];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  20];
	char  		card_seq_num	[   4];
	char  		term_cap	[   2];
	char  		chip_cond	[   2];
	char  		orig_date_time	[  11];
	char  		issuer_code	[  12];
	char  		flag_domestic	[   2];
	char  		channel_type	[   3];
	char  		reserved_cup	[  33];
	char  		misc_flag	[   9];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		reserved_cup2	[ 301];
	int		seq_num;
} bth_dtl_err_tmp_def;

typedef struct {
    char        manage_inst [   5];
    char        trans_date_time [  11];
    char        cup_ssn [   7];
    char        acq_inst_id_code    [  12];
    char        fwd_inst_id_code    [  12];
    char        term_ssn    [  13];
    char        inst_date   [   9];
    char        inst_time   [   7];
    char        host_ssn    [  13];
    char        host_date   [   9];
    char        date_settlmt    [   9];
    char        gc_txn_num  [   5];
    char        txn_num [   5];
    char        msg_type    [   5];
    char        processing_code [   7];
    char        mchnt_type  [   5];
    char        pos_cond_code   [   3];
    char        channel_num [   3];
    char        orig_data_ssn   [   7];
    char        orig_date_time  [  11];
    char        orig_date_settlmt   [   9];
    char        orig_term_ssn   [  13];
    char        orig_host_date  [   9];
    char        orig_host_ssn   [  13];
    char        pan [  20];
    double      amt_trans;
    char        authr_id_resp   [   7];
    char        resp_code   [   3];
    char        host_recode [   8];
    double      fee_credit;
    double      fee_debit;
    double      fee_cdhr;
    double      fee_inst;
    double      fee_logo;
    char        pos_entry_mode  [   4];
    char        card_accp_term_id   [   9];
    char        card_accp_id    [  16];
    char        card_accp_addr  [  41];
    char        retrivl_ref [  13];
    char        rcvg_code   [  12];
    char        issuer_code [  12];
    char        deal_flg    [   3];
    char        tran_flg    [   2];
    char        code_xfer_o [  12];
    char        pan_xfer_o  [  29];
    char        code_xfer_i [  12];
    char        pan_xfer_i  [  29];
    char        currcy_code_trans   [   4];
    char        currcy_code_stlm    [   4];
    double      amt_settlmt;
    char        conv_rate_stlm  [   9];
    char        date_conv   [   9];
    char        flag_domestic   [   2];
    char        flag_city   [   2];
    char        area_code   [   5];
    char        inst_no [  12];
    char        bank_flag   [   7];
    char        flag_result [   2];
    char        fwd_rcv_in  [   2];
    char        cup_ins_id  [   7];
} bth_dtl_rvsl_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_date_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		fwd_rcv_in	[   2];
	char  		cup_ins_id	[   7];
	int		seq_num;
} bth_dtl_rvsl_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		issuer_ins_id_cd	[  11];
	char  		cup_ins_id	[   7];
	int		seq_num;
} bth_dtl_tdb_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		issuer_ins_id_cd	[  11];
	char  		cup_ins_id	[   7];
} bth_dtl_cc_def;


typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		issuer_ins_id_cd	[  11];
	char  		cup_ins_id	[   7];
	int		seq_num;
} bth_dtl_bdb_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		date_settlmt	[   9];
	char  		key_cup	[  49];
	char  		flag_result	[   2];
	char  		txn_type	[   4];
	char  		txn_num	[   5];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		cup_ssn	[   7];
	char  		trans_date_time	[  11];
	char  		pan	[  20];
	int		amt_trans;
	double		replacement_amts;
	double		amt_trans_fee;
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		retrivl_ref	[  13];
	char  		pos_cond_code	[   3];
	char  		authr_id_resp	[   7];
	char  		rcvg_code	[  12];
	char  		orig_cup_ssn	[   7];
	char  		resp_code	[   3];
	char  		pos_entry_mode	[   4];
	double		fee_credit;
	double		fee_debit;
	double		fee_xfer;
	char  		flag_sd	[   2];
	double		fee_cdhr;
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  20];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  20];
	char  		card_seq_num	[   4];
	char  		term_cap	[   2];
	char  		chip_cond	[   2];
	char  		orig_date_time	[  11];
	char  		issuer_code	[  12];
	char  		flag_domestic	[   2];
	char  		channel_type	[   3];
	double		reserved_cup;
	char  		misc_flag	[   9];
	char  		card_accptr_name_loc	[  41];
	char  		currcy_code_settlmt	[   4];
	double		amt_settlmt;
	char  		conv_rate_settlmt	[   9];
	char  		date_conv	[   5];
	double		fee_credit_settlmt;
	int		fee_debit_settlmt;
	char  		card_type	[   4];
	char  		currcy_code_trans	[   4];
	double		err_fee_credit_trans;
	double		err_fee_credit_settlmt;
	double		err_fee_debit_trans;
	double		err_fee_debit_settlmt;
	int		seq_num;
} bth_dtl_err_iod_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		pri_key	[  43];
	char  		orig_key	[  43];
	char  		related_key	[  43];
	char  		iss_acq_in	[   2];
	char  		local_settle_in	[   2];
	char  		fill_disc_in	[   2];
	char  		err_trans_id	[   4];
	char  		settle_dt	[   9];
	char  		msg_tp	[   5];
	char  		pri_acct_no	[  22];
	char  		proc_cd	[   7];
	char  		trans_at	[  13];
	char  		transmsn_dt_tm	[  11];
	char  		sys_tra_no	[   7];
	char  		mchnt_tp	[   5];
	char  		pos_entry_md_cd	[   4];
	char  		card_seq_num	[   4];
	char  		pos_cond_cd	[   3];
	char  		acq_ins_id_cd	[  14];
	char  		fwd_ins_id_cd	[  14];
	char  		retri_ref_no	[  13];
	char  		auth_id_resp_cd	[   7];
	char  		resp_cd	[   3];
	char  		term_id	[   9];
	char  		mchnt_cd	[  16];
	char  		rsn_cd	[   5];
	char  		term_entry_cap	[   2];
	char  		chip_cond_cd	[   2];
	char  		trans_chnl	[   3];
	char  		rcv_ins_id_cd	[  14];
	char  		iss_ins_id_cd	[  14];
	char  		tfr_out_ins_id_cd	[  14];
	char  		tfr_out_acct_id	[  22];
	char  		tfr_in_ins_id_cd	[  14];
	char  		tfr_in_acct_id	[  22];
	char  		orig_settle_dt	[   9];
	char  		orig_trans_at	[  13];
	char  		orig_transmsn_dt_tm	[  11];
	char  		orig_sys_tra_no	[   7];
	char  		orig_retri_ref_no	[  13];
	char  		debt_disc_at	[  13];
	char  		cret_disc_at	[  13];
	char  		swt_disc_at	[  13];
	char  		cust_cups_disc_at	[  13];
	char  		cust_gold_disc_at	[  13];
	char  		debt_fee_at	[  13];
	char  		cret_fee_at	[  13];
	char  		gold_iss_ins_id_cd	[  14];
	char  		sms_dms_conv_in	[   2];
	char  		dom_ext_in	[   2];
	char  		err_zone_in	[   2];
	char  		cross_dist_in	[   2];
	char  		reserve	[  31];
	char  		reserve1	[  31];
	char  		reserve2	[  61];
	char  		reserve3	[ 101];
	int		seq_num;
} tbl_dat_cups_flow_tmp_def;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		pri_key	[  43];
	char  		orig_key	[  43];
	char  		related_key	[  43];
	char  		iss_acq_in	[   2];
	char  		local_settle_in	[   2];
	char  		settle_dt	[   9];
	char  		flow_ins_id_cd	[  14];
	char  		acq_first_br_cd	[  14];
	char  		iss_first_br_cd	[  14];
	char  		is_cups_in	[   2];
	char  		debt_cret_in	[   3];
	char  		card_media	[   2];
	char  		cross_dist_in	[   2];
	char  		mchnt_tp	[   5];
	char  		acq_second_br_cd	[  14];
	char  		iss_second_br_cd	[  14];
	char  		acq_ins_id_cd	[  14];
	char  		fwd_ins_id_cd	[  14];
	char  		iss_ins_id_cd	[  14];
	char  		rcv_ins_id_cd	[  14];
	char  		sheet_ins_id_cd	[  14];
	char  		msg_tp	[   5];
	char  		proc_cd	[   7];
	char  		pos_cond_cd	[   3];
	char  		trans_chnl	[   3];
	char  		sys_tra_no	[   7];
	char  		transmsn_dt_tm	[  11];
	char  		pri_acct_no	[  20];
	char  		tfr_out_acct_id	[  29];
	char  		tfr_in_acct_id	[  29];
	char  		orig_data_elem	[  43];
	char  		term_id	[   9];
	char  		mchnt_cd	[  16];
	char  		retri_ref_no	[  13];
	char  		trans_at	[  13];
	char  		acq_disc_at	[  13];
	char  		iss_disc_at	[  13];
	char  		brand_at	[  13];
	char  		rsv1	[  13];
	char  		weigh_at	[  13];
	char  		rsv2	[ 101];
	char  		cust_gold_disc_at	[  13];
	char  		gold_iss_ins_id_cd	[  14];
	char  		reserve	[  31];
	char  		reserve1	[  31];
	char  		reserve2	[  61];
	char  		reserve3	[ 101];
	int		seq_num;
} tbl_dat_cups_logofee_flow_tmp_def;

typedef struct
{
	char        cup_line_no[5+1];
	char        host_tlr_no[200+1];
} cst_cup_line_cfg_def;

typedef struct
{
	char        inter_brh_code[10+1];
	char        cup_line_no[5+1];
} tbl_brh_info_def;

typedef struct
{
	char curr_sta[2+1];
	char next_sta[2+1];
	int	 in_to_days;
	int	 out_to_days;
}tbl_awsr_to_ctl;

typedef struct
{
	tbl_awsr_to_ctl dbtbl_awsr_to_ctl[20];
	int nTotal;
}stAwsrToDef;

typedef struct 
{
	cst_bank_zone_def tbl_cst_bank_zone[3000];
	int nNum;
}stcst_bank_zone;

typedef struct
{
    char flow_tp[2];
    char msg_tp[5];
    char proc_cd[7];
    char pos_cond_cd[3];
    char trans_chnl[3];
    char trans_id[4];
    char raw_trans_id[4];
    char cross_dist_in[2];
    char fwd_ins_id_cd[14];
}tbl_trans_id_set_def;

typedef struct
{
    tbl_trans_id_set_def dbtbl_trans_id_set[256];
    int recNum;
}stTransIdSetDef;

typedef struct
{
    char trans_id[4];
    int match_str_len;
    char match_str[21];
    char trans_id_conv[4];
}tbl_spec_trans_id_conv;

typedef struct
{
    tbl_spec_trans_id_conv dbtbl_trans_id_conv[256];
    int recNum;
}stSpecTransIdConv;

typedef struct 
{
	char	date_settlmt[8+1];
	char	key_cup[48+1];
	char	flag_result[1+1];
	char	txn_type[3+1];
	char	txn_num[4+1];
	char	acq_inst_id_code[11+1];
	char	fwd_inst_id_code[11+1];
	char	cup_ssn[6+1];
	char	trans_date_time[10+1];
	char	pan[19+1];
	char	amt_trans[12+1];
	char	replacement_amts[12+1];
	char	amt_trans_fee[12+1];
	char	msg_type[4+1];
	char	processing_code[6+1];
	char	mchnt_type[4+1];
	char	card_accp_term_id[8+1];
	char	card_accp_id[15+1];
	char	retrivl_ref[12+1];
	char	pos_cond_code[2+1];
	char	authr_id_resp[6+1];
	char	rcvg_code[11+1];
	char	orig_cup_ssn[6+1];
	char	resp_code[2+1];
	char	pos_entry_mode[3+1];
	char	fee_credit[12+1];
	char	fee_debit[12+1];
	char	fee_xfer[12+1];
	char	flag_sd[1+1];
	char	fee_cdhr[12+1];
	char	code_xfer_o[11+1];
	char	pan_xfer_o[19+1];
	char	code_xfer_i[11+1];
	char	pan_xfer_i[19+1];
	char	card_seq_num[3+1];
	char	term_cap[1+1];
	char	chip_cond[1+1];
	char	orig_date_time[10+1];
	char	issuer_code[11+1];
	char	flag_domestic[1+1];
	char	channel_type[2+1];
	char	reserved_cup[32+1];
	char	misc_flag[8+1];
	char	card_accptr_name_loc[40+1];
	char	currcy_code_settlmt[3+1];
	char	amt_settlmt[12+1];
	char	conv_rate_settlmt[8+1];
	char	date_conv[4+1];
	char	fee_credit_settlmt[12+1];
	char	fee_debit_settlmt[12+1];
	char	card_type[3+1];
	char	currcy_code_trans[3+1];
	char	err_fee_credit_trans[12+1];
	char	err_fee_credit_settlmt[12+1];
	char	err_fee_debit_trans[12+1];
	char	err_fee_debit_settlmt[12+1];	
}tbl_cup_txn_Def;

typedef struct
{
    char bank_num[4];
    char brh_code[4];
    char pan[19];
    char txn_type[4];
    char curr_code[3];
    char adj_dir[1];
    char adj_amt[12];
    char adj_date[8];
    char action[1];
    char flag_result[1];
    char oirg_txn_ssn[6];
    char oirg_txn_type[4];
    char oirg_curr_code[3];
    char oirg_txn_dir[1];
    char oirg_trans_amt[12];
    char oirg_txn_date[8];
    char misc[30];
    char seq_num[6];
    char cr_str[1];
    char end_str[1];
}tbl_crcard_err_file;

typedef struct {
	char  		inter_brh_code[10+1];
	char  		pri_key	[  43];
	char  		orig_key	[  43];
	char  		related_key	[  43];
	char  		local_settle_in	[   2];
	char  		settle_dt	[   9];
	char  		iss_in	[   2];
	char  		msg_tp	[   5];
	char  		pri_acct_no	[  22];
	char  		proc_cd	[   7];
	char  		trans_at	[  13];
	char  		sys_tra_no	[   7];
	char  		card_expired_date	[   5];
	char  		transmsn_dt_tm	[  11];
	char  		mchnt_tp	[   5];
	char  		pos_entry_md_cd	[   4];
	char  		card_seq_num	[   4];
	char  		pos_cond_cd	[   3];
	char  		pos_pin_cap_cd	[   3];
	char  		acq_ins_id_cd	[  14];
	char  		retri_ref_no	[  13];
	char  		auth_id_resp_cd	[   7];
	char  		resp_cd	[   3];
	char  		term_id	[   9];
	char  		mchnt_cd	[  16];
	char  		rcv_ins_id_cd	[  14];
	char  		term_seq_num	[   5];
	char  		fee_amt	[  13];
	char  		curr_cd	[   4];
	char  		acct_balance	[  21];
	char  		auth_sum_amt	[  13];
	char  		msg_type_id	[   3];
	char  		batch_num	[   7];
	char  		orig_trans_batch	[   7];
	char  		orig_pos_seq_num	[   7];
	char  		orig_trans_date	[   5];
	char  		orig_auth_md	[   3];
	char  		orig_auth_ins	[  14];
	char  		oper_id_cd	[   9];
	char  		trans_chnl	[   3];
	char  		reserve1	[  31];
	char  		reserve2	[  61];
	char  		reserve3	[ 101];
} tbl_dat_bank_flow_def;

typedef struct {
	char  		inter_brh_code[10+1];
	char  		pri_key	[  43];
	char  		orig_key	[  43];
	char  		related_key	[  43];
	char  		local_settle_in	[   2];
	char  		settle_dt	[   9];
	char  		iss_in	[   2];
	char  		msg_tp	[   5];
	char  		pri_acct_no	[  22];
	char  		proc_cd	[   7];
	char  		trans_at	[  13];
	char  		sys_tra_no	[   7];
	char  		card_expired_date	[   5];
	char  		transmsn_dt_tm	[  11];
	char  		mchnt_tp	[   5];
	char  		pos_entry_md_cd	[   4];
	char  		card_seq_num	[   4];
	char  		pos_cond_cd	[   3];
	char  		pos_pin_cap_cd	[   3];
	char  		acq_ins_id_cd	[  14];
	char  		retri_ref_no	[  13];
	char  		auth_id_resp_cd	[   7];
	char  		resp_cd	[   3];
	char  		term_id	[   9];
	char  		mchnt_cd	[  16];
	char  		rcv_ins_id_cd	[  14];
	char  		term_seq_num	[   5];
	char  		fee_amt	[  13];
	char  		curr_cd	[   4];
	char  		acct_balance	[  21];
	char  		auth_sum_amt	[  13];
	char  		msg_type_id	[   3];
	char  		batch_num	[   7];
	char  		orig_trans_batch	[   7];
	char  		orig_pos_seq_num	[   7];
	char  		orig_trans_date	[   5];
	char  		orig_auth_md	[   3];
	char  		orig_auth_ins	[  14];
	char  		oper_id_cd	[   9];
	char  		trans_chnl	[   3];
	char  		reserve1	[  31];
	char  		reserve2	[  61];
	char  		reserve3	[ 101];
	int		seq_num;
} tbl_dat_bank_flow_tmp_def;

typedef struct
{
	char    inter_brh_code[10+1];
	char    cust_no[10+1];
    char    host_date[8+1];
    char    key_host[48+1];
    char    flag_result[1+1];
    char    trans_host_ssn_1[32+1];
    char    trans_host_ssn_2[32+1];
    char    host_ssn[12+1];
    char    term_ssn[12+1];
    char    date_settlmt[8+1];
    char    txn_num[4+1];
    char    sys_seq_num[6+1];
    char    pan[19+1];
    char    amt_trans[13+1];
    char    replacement_amts[13+1];
    char    amt_trans_fee[13+1];
	char    trans_score[15+1];
    char    host_term_id[12+1];
    char    host_tlr_num[12+1];
    char    host_accp_id[32+1];
    char    retrivl_ref[12+1];
    char    authr_id_resp[6+1];
    char    orig_cup_ssn[6+1];
    char    debits_credits_flag[1+1];
    char    host_trans_time[6+1];
    char    agent_num[7+1];
    char    channel_num[2+1];
    char    state[1+1];
    char    orig_date_settlmt[8+1];
    char    orig_term_ssn[12+1];
    char    reserved_host_1[32+1];
    char    reserved_host_2[32+1];
    char    misc_flag[8+1];
    char    amt_add2[13+1];
    char    amt_add3[13+1];
    char    account_in[20+1];
    char    flag_err[1+1];
    int    seq_num;
} bth_host_score_def;


typedef struct
{
    short    inter_brh_code;
    short    cust_no;
    short    host_date;
    short    key_host;
    short    flag_result;
    short    trans_host_ssn_1;
    short    trans_host_ssn_2;
    short    host_ssn;
    short    term_ssn;
    short    date_settlmt;
    short    txn_num;
    short    sys_seq_num;
    short    pan;
    short    amt_trans;
    short    replacement_amts;
    short    amt_trans_fee;
    short    trans_score;
    short    host_term_id;
    short    host_tlr_num;
    short    host_accp_id;
    short    retrivl_ref;
    short    authr_id_resp;
    short    orig_cup_ssn;
    short    debits_credits_flag;
    short    host_trans_time;
    short    agent_num;
    short    channel_num;
    short    state;
    short    orig_date_settlmt;
    short    orig_term_ssn;
    short    reserved_host_1;
    short    reserved_host_2;
    short    misc_flag;
    short    amt_add2;
    short    amt_add3;
    short    account_in;
    short    flag_err;
    short    seq_num;
} bth_host_score_def_ind;

typedef struct {
	char  		inter_brh_code	[   11];
	char  		manage_inst	[   5];
	char  		trans_date_time	[  11];
	char  		cup_ssn	[   7];
	char  		acq_inst_id_code	[  12];
	char  		fwd_inst_id_code	[  12];
	char  		term_ssn	[  13];
	char  		inst_date	[   9];
	char  		inst_time	[   7];
	char  		host_ssn	[  13];
	char  		host_date	[   9];
	char  		date_settlmt	[   9];
	char  		gc_txn_num	[   5];
	char  		txn_num	[   5];
	char  		msg_type	[   5];
	char  		processing_code	[   7];
	char  		mchnt_type	[   5];
	char  		pos_cond_code	[   3];
	char  		channel_num	[   3];
	char  		orig_data_ssn	[   7];
	char  		orig_data_time	[  11];
	char  		orig_date_settlmt	[   9];
	char  		orig_term_ssn	[  13];
	char  		orig_host_date	[   9];
	char  		orig_host_ssn	[  13];
	char  		pan	[  20];
	double		amt_trans;
	char  		authr_id_resp	[   7];
	char  		resp_code	[   3];
	char  		host_recode	[   8];
	double		fee_credit;
	double		fee_debit;
	double		fee_cdhr;
	double		fee_inst;
	double		fee_logo;
	char  		pos_entry_mode	[   4];
	char  		card_accp_term_id	[   9];
	char  		card_accp_id	[  16];
	char  		card_accp_addr	[  41];
	char  		retrivl_ref	[  13];
	char  		rcvg_code	[  12];
	char  		issuer_code	[  12];
	char  		deal_flg	[   3];
	char  		tran_flg	[   2];
	char  		code_xfer_o	[  12];
	char  		pan_xfer_o	[  29];
	char  		code_xfer_i	[  12];
	char  		pan_xfer_i	[  29];
	char  		currcy_code_trans	[   4];
	char  		currcy_code_stlm	[   4];
	double		amt_settlmt;
	char  		conv_rate_stlm	[   9];
	char  		date_conv	[   9];
	char  		flag_domestic	[   2];
	char  		flag_city	[   2];
	char  		area_code	[   5];
	char  		inst_no	[  12];
	char  		bank_flag	[   7];
	char  		flag_result	[   2];
	char  		issuer_ins_id_cd	[  11];
	char  		cup_ins_id	[   7];
	char  		cust_no[   11];
	char  		trans_score[   16];
	char  		trans_host_ssn[   33];
	int		seq_num;
} bth_dtl_score_tmp_def;

typedef struct {
    char date_settlmt[8];
    char manual_tp[3];
    char acq_ins_id_cd[13];
    char fwd_ins_id_cd[13];
    char settle_ins_id_cd[13];
    char settle_ins_role[1];
    char settle_mmdd[8];
    char term_id[8];
    char mchnt_cd[15];
    char card_accp_nm_loc[40];
    char bus_tp[4];
    char settle_curr_cd[3];
    char trans_date_time[10];
    char pan[21];
    char cup_ssn[6];
    char debt_settlt_num[6];
    char debt_settle_amt[16];
    char debt_settle_fee[12];
    char cret_settle_num[10];
    char cret_settle_amt[16];
    char cret_settlt_fee[12];
    char reserve[20];
    char rec_cpd_usr_id[8];
    char rec_upd_ts[27];
    char rec_crt_ts[27];
} fl_file_def;

typedef struct {
        char    tTblProcName[61];
        char    tInterBrhCode[11];
        char    sToday[8+1];
        int     iTblProcFlag;
        int     iPROC_DONE_STATUS;
        int     iPROC_WAITING_STATUS;
        int     iPROC_INPROC_STATUS;
        int     iPROC_ERR_STATUS;
        int     iPROC_CANCEL_STATUS;
        int     sWT_RSP_STATUS;
        int     sWT_REDO_STATUS;
        int     sSTTL_DONE_STATUS;
} dbs_opr_data_2000;

typedef struct {
    char        pri_key [  43];
    char        orig_key    [  43];
    char        related_key [  43];
    char        local_settle_in [   2];
    char        settle_dt   [   9];
    char        iss_in  [   2];
    char        trans_id    [   4];
    char        raw_trans_id    [   4];
    char        trans_tp    [  11];
    char        trans_class [   2];
    char        settle_ins_id_cd    [  14];
    char        msg_tp  [   5];
    char        pri_acct_no [  22];
    char        proc_cd [   7];
    double      trans_at;
    char        sys_tra_no  [   7];
    char        card_expired_date   [   5];
    char        transmsn_dt_tm  [  11];
    char        mchnt_tp    [   5];
    char        pos_entry_md_cd [   4];
    char        card_seq_num    [   4];
    char        pos_cond_cd [   3];
    char        pos_pin_cap_cd  [   3];
    char        acq_ins_id_cd   [  14];
    char        retri_ref_no    [  13];
    char        auth_id_resp_cd [   7];
    char        resp_cd [   3];
    char        term_id [   9];
    char        mchnt_cd    [  16];
    char        rcv_ins_id_cd   [  14];
    char        term_seq_num    [   5];
    double      fee_amt;
    char        curr_cd [   4];
    double      acct_balance;
    double      auth_sum_amt;
    char        msg_type_id [   3];
    char        batch_num   [   7];
    char        orig_trans_batch    [   7];
    char        orig_pos_seq_num    [   7];
    char        orig_trans_date [   5];
    char        orig_auth_md    [   3];
    char        orig_auth_ins   [  14];
    char        oper_id_cd  [   9];
    char        trans_chnl  [   3];
    char        orig_settle_dt  [   9];
    double      orig_trans_at;
    char        orig_transmsn_dt_tm [  11];
    char        orig_sys_tra_no [  13];
    char        cross_dist_in   [   2];
    char        orig_disc_dir_in    [   2];
    char        orig_disc_algo_in   [   2];
    int        orig_disc_rate;
    char        orig_disc_cd    [   6];
    char        disc_dir_in [   2];
    char        disc_algo_in    [   2];
    int        disc_rate;
    char        disc_cd [   6];
    double      bank_debt_settle_at;
    double      bank_cret_settle_at;
    double      br_bank_debt_settle_at;
    double      br_bank_cret_settle_at;
    double      mchnt_debt_settle_at;
    double      mchnt_cret_settle_at;
    int        bank_debt_disc_at;
    int        bank_cret_disc_at;
    int        br_bank_debt_disc_at;
    int        br_bank_cret_disc_at;
    int        mchnt_debt_disc_at;
    int        mchnt_cret_disc_at;
    double      cust_cups_debt_disc_at;
    double      cust_cups_cret_disc_at;
    double      bank_debt_fee_at;
    double      bank_cret_fee_at;
    double      br_bank_debt_fee_at;
    double      br_bank_cret_fee_at;
    int        bank_rev_debt_disc_at;
    int        bank_rev_cret_disc_at;
    int        br_bank_rev_debt_disc_at;
    int        br_bank_rev_cret_disc_at;
    int        mchnt_rev_debt_disc_at;
    int        mchnt_rev_cret_disc_at;
    char        reserve1    [  31];
    char        reserve2    [  61];
    char        reserve3    [ 101];
    char        rec_upd_ts  [  15];
    char        rec_crt_ts  [  15];
} tbl_log_bank_settle_def;
typedef struct {
    char        pri_key [  43];
    char        orig_key    [  43];
    char        related_key [  43];
    char        iss_acq_in  [   2];
    char        local_settle_in [   2];
    char        fill_disc_in    [   2];
    char        settle_dt   [   9];
    char        trans_id    [   4];
    char        raw_trans_id    [   4];
    char        trans_tp    [  11];
    char        trans_class [   2];
    char        settle_acq_ins_id_cd    [  14];
    char        settle_iss_ins_id_cd    [  14];
    char        msg_tp  [   5];
    char        pri_acct_no [  22];
    char        proc_cd [   7];
    double      trans_at;
    char        transmsn_dt_tm  [  11];
    char        sys_tra_no  [   7];
    char        mchnt_tp    [   5];
    char        pos_entry_md_cd [   4];
    char        card_seq_num    [   4];
    char        pos_cond_cd [   3];
    char        acq_ins_id_cd   [  14];
    char        fwd_ins_id_cd   [  14];
    char        retri_ref_no    [  13];
    char        auth_id_resp_cd [   7];
    char        resp_cd [   3];
    char        term_id [   9];
    char        mchnt_cd    [  16];
    char        rsn_cd  [   5];
    char        term_entry_cap  [   2];
    char        chip_cond_cd    [   2];
    char        trans_chnl  [   3];
    char        rcv_ins_id_cd   [  14];
    char        iss_ins_id_cd   [  14];
    char        tfr_out_ins_id_cd   [  14];
    char        tfr_out_acct_id [  22];
    char        tfr_in_ins_id_cd    [  14];
    char        tfr_in_acct_id  [  22];
    char        orig_settle_dt  [   9];
    double      orig_trans_at;
    char        orig_transmsn_dt_tm [  11];
    char        orig_sys_tra_no [   7];
    char        orig_retri_ref_no   [  13];
    double      cust_gold_disc_at;
    char        gold_iss_ins_id_cd  [  14];
    char        sms_dms_conv_in [   2];
    char        dom_ext_in  [   2];
    char        err_zone_in [   2];
    char        cross_dist_in   [   2];
    char        orig_disc_dir_in    [   2];
    char        orig_disc_algo_in   [   2];
    int        orig_disc_rate;
    char        orig_disc_cd    [   6];
    double      orig_cust_gold_disc_at;
    int        orig_mchnt_debt_disc_at;
    int        orig_mchnt_cret_disc_at;
    int        orig_cups_debt_disc_at;
    int        orig_cups_cret_disc_at;
    char        disc_dir_in [   2];
    char        disc_algo_in    [   2];
    int        disc_rate;
    char        disc_cd [   6];
    double      cups_debt_settle_at;
    double      cups_cret_settle_at;
    double      bank_debt_settle_at;
    double      bank_cret_settle_at;
    double      br_bank_debt_settle_at;
    double      br_bank_cret_settle_at;
    double      mchnt_debt_settle_at;
    double      mchnt_cret_settle_at;
    int        cups_debt_disc_at;
    int        cups_cret_disc_at;
    int        bank_debt_disc_at;
    int        bank_cret_disc_at;
    int        br_bank_debt_disc_at;
    int        br_bank_cret_disc_at;
    int        mchnt_debt_disc_at;
    int        mchnt_cret_disc_at;
    double      cups_debt_swt_at;
    double      cups_cret_swt_at;
    double      cust_cups_debt_disc_at;
    double      cust_cups_cret_disc_at;
    double      cups_debt_fee_at;
    double      cups_cret_fee_at;
    double      bank_debt_fee_at;
    double      bank_cret_fee_at;
    double      br_bank_debt_fee_at;
    double      br_bank_cret_fee_at;
    int        cups_rev_debt_disc_at;
    int        cups_rev_cret_disc_at;
    int        bank_rev_debt_disc_at;
    int        bank_rev_cret_disc_at;
    int        br_bank_rev_debt_disc_at;
    int        br_bank_rev_cret_disc_at;
    int        mchnt_rev_debt_disc_at;
    int        mchnt_rev_cret_disc_at;
    char        reserve [  31];
    char        reserve1    [  31];
    char        reserve2    [  61];
    char        reserve3    [ 101];
    char        rec_upd_ts  [  15];
    char        rec_crt_ts  [  15];
} tbl_log_cups_settle_def;


typedef struct
{
char    DevId[16];
char    CardNo[33];
char    DevTransDateTime[11];
char    SrvTransDateTime[15];
char    FrontDate[9];
char    DevStan[21];
char    ToThirdStan[21];
char    ToHostStan[9];
char    CommSrvStan[9];
int FromSerSeqNo;
char    AcqIns[12];
char    ForwIns[12];
char    TranType[7];
char    Mti[5];
double  TranAmt;
double  StlAmt;
double  CardBillAmt;
char    HostRspDate[9];
char    HostRspTime[7];
char    StlRate[9];
char    CardBillRate[9];
char    LocalTranDate[5];
char    LocalTranTime[7];
char    CardExpDate[9];
char    StlDate[5];
char    ConvDate[5];
char    POSInputType[4];
char    CardSeqNo[4];
char    POSCondCode[3];
char    Track2[38];
char    Track3[105];
char    ThirdRspCode[11];
char    HostRspCode[11];
char    PlatRspCode[11];
char    Mid[16];
char    AccptNameAddr[41];
char    RspMsg[129];
char    Ccy[4];
char    StlCCY[4];
char    CardBillCCY[4];
char    RefNo[17];
char    AddData2[129];
char    OrigData[43];
char    PureStlAmt[16];
char    StlInstitID[12];
char    AccptInstitID[12];
char    AccFrom[33];
char    AccTo[33];
char    AddStlData[129];
char    IbPrivData[256];
char    AbPrivData[256];
char    GcPrivData[256];
char    IcData[256];
char    RplAmt[43];
char    ServiceFee[18];
char    AuthRspCode[7];
char    CrDbFlg[3];
char    RevFlag[2];
char    TranStatus[3];
char    CardTranType[3];
char    CardTranTypeComm[71];
char    MctMcc[5];
char    EjectFlg[2];
char    TranCode[6];
char    TxName[71];
char    AbTxName[11];
char    SettleFlg[2];
char    SettleDateTime[15];
char    IssueBrc[13];
char    IssueBrc2[13];
char    DevBrc[13];
char    Teller[13];
char    ChannelId[3];
char    ChannelIdName[71];
char    SameAreaFlg[2];
double  BankGetFee;
double  CustShareFee;
double  BankShareFee;
double  BankAssFee;
double  BankPayFee;
double  AssFee1;
double  AssFee2;
char    TranKind[4];
char    TranKindComm[71];
char    CardDepFlag[2];
char    SettleDate[9];
char    ODevTransDateTime[11];
char    ODevStan[21];
char    OAcqIns[12];
char    OForwIns[12];
char    HostAcctFlg[2];
char    BatchNo[7];
char    AreaCode[5];
char    FrntNo[9];
char    NoStp[21];
char    Expand[256];
}tbl_cmsonltran_def;

typedef struct
{
	char front_txn[5+1];
	char inner_txn[4+1];
	char flag[1+1];
	char desc[30+1];
}tbl_txn_convert_def;
/*****************add by jack******************/
typedef struct
{
char		 BASQ[13];             		
char		 ATDT[9];                 
char		 CLSB[14];                 
char		 CATY[2];                 
char		 GTAC[33];                 
char		 CYNO[3];                 
char		 CTFG[2];                 
char		 RBNM[65];                 
char		 SBNO[14];                 
char		 OPNT[14];                 
double	 TRAM;      
double	 FEEB;      
char		 EXNO[9];   
char		 SBNM[3];   
char		 MITS[2];   
char		 SMCD[65];  
char		 MGSM[21];  
char		 USID[9];   
char		 TLSQ[13];  
char		 TRDT[9];   
char		 TRTM[7];   
char		 MGID[8];   
char		 MGTX[41];  
int				TMSP;   
char		 STCD[2];   
char		 RUZH[2];   
char		 INCD[13];       
char		 MCHT[16];       
char		 CON_IN[2];    
char		 RSV[2];        
char		 SMIN[2];       
char		 FADS[41];       
char		 TRAMSTR[16];
char		 FEEBSTR[16];
char		 RSV_IN1[2];
char		 RSV_IN2[2];
char		 RSV_FIELD1[33]; 
char		 RSV_FIELD2[65]; 
}Tbl_posp_acct_def;
typedef struct
{
char 	 BRH_ID[12];
int    NEW_MCHNT_NUM;
int    CANCEL_MCHNT_NUM;
int    BALANCE_MCHNT_NUM;
int    PURE_MCHNT_NUM;
char   INC_RED_MCHNT_RATE[11];
char   MCHNT_YEAR_RATE[11];   
int    ACTIVE_MCHNT_NUM;      
char   ACTIVE_MCHNT_RATE[11]; 
int    NEW_TERM_NUM;          
int    CANCEL_TERM_NUM;
int    BALANCE_TERM_NUM;
int    PURE_TERM_NUM;
char   INC_RED_TERM_RATE[11];
char   TERM_YEAR_RATE[11];
int    ACTIVE_TERM_NUM;
char   ACTIVE_TERM_RATE[11];
char   DATE_FALGE[2];
char   ST_DATE[9];
}Tbl_mchnt_static_def;
typedef struct
{
char     BRH_ID[12];
double   CRET_CARD_B_DISC;
double   DEBIT_CARD_B_DISC;
double   TRANS_CARD_T_DISC;
double   DISC_SUM;
double   PRI_PERIOD_DISC_RATE;
double   LASTY_CRSP_DISC_RATE;
double   CRET_CARD_B_PROFIT;
double   DEBIT_CARD_B_PROFIT;
double   TRANS_CARD_T_PROFIT;
double   PROFIT_SUM;
double   PRI_PERIOD_PROFIT_RATE;
double   LASTY_CRSP_PROFIT_RATE;
double   DEBIT_CARD_B_AMT;
double   CRET_CARD_B_AMT;
double   TRANS_CARD_T_AMT;
double   TRANS_AMT_SUM;
double   PRI_PERIOD_AMT_RATE;
double   LASTY_CRSP_AMT_RATE;
double   AMT_B_SUM;
double   AMT_B_RATE;
int      DEBIT_CARD_B_NUM;
int      CRET_CARD_B_NUM;
int      TRANS_CARD_T_NUM;
double   TRANS_NUM_SUM;
double   PRI_PERIOD_NUM_RATE;
double   LASTY_CRSP_NUM_RATE;
int		   NUM_B_SUM;
double   NUM_B_RATE;
char     DATE_FLAG[2];
char     ST_DATE[9];
}Tbl_pos_income_st_def;

typedef struct
{
	char	iss_in[1+1];
	char    inst[11+1];
	char	date_settlmt[8+1];
	int		trans_num;
	double	trans_amt;
	double	feeb;
	double	feeb_profit;
} tbl_inst_trans_sum;
typedef struct
{
    char front_txn[6+1];
    char inner_txn[4+1];
    char flag[1+1];
    char desc[12+1];
}err_txn_convert_def;

typedef struct
{
	char	inter_brh_code[10+1];
	char	sys_date[8+1];
	char	sys_time[6+1];
	char	txn_ssn[15+1];
	char	cup_ssn[8+1];
	char	processing_code[6+1];
	char	pan[32+1];
	char	account[32+1];
	char	amt_trans[17+1];
	char	ccy[3+1];
	char	date_settlmt[8+1];
	char	balance[17+1];
	char	used_bnc[17+1];
	char	resp_code[2+1];
	char	pan_o[32+1];
	char	acct_o[32+1];
	char	trans_fee[17+1];
	char	brh_inst[11+1];
	char	sub_brh_inst[11+1];
	char	acct_brh_inst[11+1];
	char	tel_num[11+1];
	char	txn_num[6+1];
	char	term_id[8+1];
	char	mchnt_cd[15+1];
	char	mchnt_tp[4+1];
	char	mchnt_nm[60+1];
	char	grp_flag[1+1];
	char	grp_num[15+1];
	char	grp_nm[60+1];
	char	sign_brh_lev[1+1];
	char	sign_brh[11+1];
	char	mchnt_acct[32+1];
	char	amt_flag[1+1];
	char	fee_flag[1+1];
	char	profit_rate[8+1];
	char	flag_result[1+1];
	int		seq_num;
}tbl_ic_txn_def;

typedef struct 
{
    char    term_id[8+1]        ;
    char    mchnt_cd[15+1]      ;
    char    ins_id_cd[13+1]     ;
    char    settle_dt[8+1]      ;
    char    trans_id[3+1]       ;
    long    settle_num          ;
    long    debt_settle_at      ;
    long    cret_settle_at      ;
    long    debt_disc_at        ;
    long    cret_disc_at        ;
    long    rev_debt_disc_at    ;
    long    rev_cret_disc_at    ;
}tbl_log_term_trans_sum_def;

typedef struct 
{
	char	inter_brh_code[10+1];
	char	acq_inst_id_code[11+1];
	char	fwd_inst_id_code[11+1];
	char	cup_ssn[6+1];
	char	trans_date_time[10+1];
	char	pan[19+1];
	char	amt_trans[12+1];
	char	msg_type[4+1];
	char	processing_code[6+1];
	char	mchnt_type[4+1];
	char	term_id[8+1];
	char	mchnt_cd[15+1];
	char	retrivl_ref[12+1];
	char	pos_con_code[2+1];
	char	auth_rsp[6+1];
	char	rcv_code[11+1];
	char	orig_cup_ssn[6+1];
	char	orig_trans_date_time[10+1];
	char	issure_inst[11+1];
	char	acq_amt_fee[12+1];
	char	card_seq[3+1];
	char	reserved[26+1];	
	char	flag_result[1+1];
	long	seq_num;
}tbl_cup_txn_alod_def;

typedef struct 
{
    char    inter_brh_code[10+1];
    char    acq_inst_id_code[11+1];
    char    fwd_inst_id_code[11+1];
    char    cup_ssn[6+1];
    char    trans_date_time[10+1];
    char    pan[19+1];
    char    amt_trans[12+1];
    char    msg_type[4+1];
    char    processing_code[6+1];
    char    mchnt_type[4+1];    
    char    term_id[8+1];   
    char    mchnt_cd[15+1]; 
    char    retrivl_ref[12+1];  
    char    pos_con_code[2+1];  
    char    auth_rsp[6+1];  
    char    fwd_code[11+1]; 
    char    orig_cup_ssn[6+1];  
    char    orig_trans_date_time[10+1]; 
    char    issure_inst[11+1];  
    char    fwd_amt_fee[12+1];  
    char    card_seq[3+1];  
    char    reserved[26+1]; 
    char    flag_result[1+1];
	long    seq_num;
}tbl_cup_txn_ilod_def;

typedef struct 
{
	char    inter_brh_code[10+1];
	char	date_settlmt[8+1];
	char	key_cup[48+1];
	char    flag_result[1+1];
	char    txn_type[3+1];
	char	bitmap[4+1];
	char	pan[19+1];
	char	amt_trans[12+1];
	char	ccy[3+1];
	char	trans_date_time[10+1];
	char	cup_ssn[6+1];
	char	authory[6+1];
	char	authory_dt[4+1];
	char	retrivl_ref[12+1];
	char	acq_inst_id_code[11+1];
	char	fwd_inst_id_code[11+1];
	char	mchnt_type[4+1];
	char	card_accp_term_id[8+1];
	char	card_accp_id[15+1];
	char	card_accp_addr[40+1];
	char	orig_txn_type[3+1];
	char	orig_trans_date_time[10+1];
	char	orig_cup_ssn[6+1];
	char	orig_date_settlmt[4+1];
	char	reason_cd[4+1];
	char	doub_flag[1+1];
	char	cups_sys_num[9+1];
	char	recv_code[11+1];
	char	issuer_code[11+1];
	char	cups_notify[1+1];
	char	channel[2+1];
	char	trans_cha[1+1];
	char	cups_resevel[8+1];
	char	pos_con_cd[2+1];
	char	trans_fee[12+1];
	char	trans_zone[1+1];
	char	eci_flag[2+1];
	char	spec_fee_flg[1+1];
	char	spec_fee_lev[1+1];
	char	resevel[11+1];
	char	appl_private[16+1];
	char	ic_pos_con_cd[3+1];
	char	card_seq[3+1];
	char	term_ability[1+1];
	char	ic_cond_code[1+1];
	char	term_property[6+1];
	char	term_ide_result[10+1];
	char	unexpect_num[8+1];
	char	inter_dev_seq[8+1];
	char	issuer_appl_data[64+1];
	char	appl_trans_count[4+1];
	char	appl_mutual_prop[4+1];
	char	trans_date[6+1];
	char	term_country_cd[3+1];
	char	resp_code[2+1];
	char	ic_trans_type[2+1];
	char	authory_amt[12+1];
	char	trans_ccy[3+1];
	char	appl_priv_check[1+1];
	char	card_valid[4+1];
	char	priv_info_data[2+1];
	char	other_amt[12+1];
	char	master_ide_rslt[6+1];
	char	term_type[2+1];
	char	spec_file_name[32+1];
	char	appl_version[4+1];
	char	trans_seq_count[8+1];
	char	card_flag_info[24+1];
	char	ic_resevel[6+1];
	long	seq_num;
}tbl_ic_offline_txn_def;


typedef struct
{
    char    date_settlmt[8+1];
    char    file_name[40+1];
    char    inst_code[11+1];
    char    reject_rs[2+1];
	char	reserve[30+1];
}bth_ic_rsf_file;

typedef struct {
    char        key_index[3];
    char        hsm_index[5];
    char        bmk[33];
    char        pinkey1[33];
    char        mackey1[33];
    char        pinkey2[33];
    char        mackey2[33];
}tbl_key_param_def;

typedef struct 
{
    char orSenderId[4+1];
    char orSenderSN[22+1];
    char orSenderDate[8+1];
    char orSenderTime[6+1];
    char utId[10+1];
    char libOrPathName[10+1];
    char docName[10+1];
    char memberName[10+1];
    char trans_date[8+1];
    char date_settlmt[8+1];
    char reserve1[30+1];
	long seq_num;
    char flag[1+1];
}bth_file_stat_def;

typedef struct 
{
    char    ins_id_cd[13+1];
    char    stlm_dt[8+1];
    char    trans_id[4+1];
    char    trans_name[32+1];
    char    fwd_rcv_in[1+1];
    long    stlm_num;
    double  stlm_at;
    long    revsal_nu;
    double  revsal_at;
    double  fee_at;
    double  net_at;
	char	ins_time[8+1];
	char	upd_time[8+1];
	char	flag[1+1];
	long	line_no;
}bth_smrt_gc_def;
typedef struct 
{
	char	txnNum[4];
	char    utId[10];
	char	libOrPathName[10];
	char	docName[10];
	char	memberName[10];
	char	date_settlmt[8];
	char	rsp_code[2];
	char	reserve[60];
}host_file_rsp;
typedef struct  
{
    char    ins_id_cd[12];
    char    acc1_offset[3];
    char    acc1_len[3];
    char    acc1_tnum[2];
    char    acc2_offset[3];
    char    acc2_len[3];
    char    acc2_tnum[2];
    char    bin_offset[3];
    long    bin_len;
    char    bin_sta_no[31];
    char    bin_end_no[31];
    char    bin_tnum[2];
    char    card_tp[2+1];
} tbl_bank_bin_inf_def;

typedef struct
{
    long bth_id;
    char req_id[4+1];
    char date_settlmt[8+1];
    char inst_id[11+1];
    char file_name[40+1];
    char status[1+1];
    char file_length[10+1];
}bth_console_inter_def;
