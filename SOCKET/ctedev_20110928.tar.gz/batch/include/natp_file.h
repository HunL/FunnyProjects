
#ifndef NATP_FILE_H
#define NATP_FILE_H

extern int NatpCliGetFile(char *sRemoteFileName,char *sLocalFileName,char *sFileServer,char *sHostName,char *sErrMsg);
extern int NatpCliPutFile(char *sRemoteFileName,char *sLocalFileName,char *sFileServer,char *sHostName,char *sErrMsg);

#endif
