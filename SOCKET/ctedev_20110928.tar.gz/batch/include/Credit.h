typedef struct
{
	char    totalLength[4]; 
	char	versionNo[1];
	char	toEncrypt[1];
	char	commCode[6];
	char	commType[1];
	char	receiverId[4];
	char	senderId[4];
	char	senderSN[22];
	char	senderDate[8];
	char	senderTime[6];
	char	tradeCode[6];
	char	gwErrorCode[2];
	char	gwErrorMessage[7];
	char    reserve1[8];
}credit_comm_header;
typedef struct 
{
    char    versionNo[1];
    char    toEncrypt[1];
    char    commCode[6];
    char    commType[1];
    char    receiverId[4];
    char    senderId[4];
    char    senderSN[22];
    char    senderDate[8];
    char    senderTime[6];
    char    tradeCode[6];
    char    gwErrorCode[2];
    char    gwErrorMessage[7];
    char    reserved1[8];
	char 	errorCode[4];
	char 	errorMsg[1024];
}credit_comm_rsp;

typedef struct
{
    char    versionNo[1];
    char    toEncrypt[1];
    char    commCode[6];
    char    commType[1];
    char    receiverId[4];
    char    senderId[4];
    char    senderSN[22];
    char    senderDate[8];
    char    senderTime[6];
    char    tradeCode[6];
    char    gwErrorCode[2];
    char    gwErrorMessage[7];
    char    reserved1[8];
    char    errorCode[4];
    char    errorMsg [50];
    char    retCount [2];
    char 	orSenderId[4];
    char 	orSenderSN[22];
    char 	orSenderDate[8];
    char 	ooSenderId[4];
    char 	ooSenderSN[22];
    char 	ooSenderDate[8];
    char 	fileTransStatus[2];
    char    statusDesc[50];
    char    transMode[1];
	char    reserved2[10];
}credit_file_stat_rsp;

typedef struct 
{
	char 	run_level[2];
	char	pack_len[4];
	char	savfwd_nu[1];
	char	version[1];
	char	sec_flag[1];
	char	file_flag[1];
	char	channel[3];
	char	chanl_detial[1];
	char	gate_num[4];
	char	busi_sys[4];
	char	trans_req[6];
	char	continue_flag[1];
	char	pack_total[6];
	char	pack_seq[6];
	char	pack_rec_num[3];
	char	pack_flag[1];
	char	term_id[10];
	char	source_id[4];
	char	source_ssn[22];
	char	source_date[8];
	char	source_tm[6];
	char	gate_ssn[10];
	char	gate_date[8];
	char	gate_tm[6];
	char	tel_num[10];
	char	spec_flag[30];
	char	host_date[8];
	char	host_time[6];
	char	affirm_code[2];
	char	info_code[7];
	char	fwd_inst_id_code[4];
	char	rcv_inst_id_code[4];
	char	reserve[66];
}credit_header;

typedef struct 
{
	char	fwd_flag[4];
	char	fwd_date[8];
	char	fwd_ssn[22];
	char	fwd_tel[10];
	char	file_type[10];
}fl0010_req;

typedef struct
{
	char    txn_num[4];
	char	trans_date_time[10];
	char	con_rsp[2];
    char    fwd_flag[4];
    char    fwd_date[8];
    char    fwd_ssn[22];
    char    fwd_tel[10];
    char    file_type[10];
    char    rsp_code[2];
    char    rsp_detial[80];
}fl0011_rsp;
typedef struct
{
    char    txn_num[4];
	char	trans_date_time[10];
	char    con_rsp[2];
    char    fwd_flag[4];
    char    fwd_date[8];
    char    fwd_ssn[22];
    char    rsp_code[2];
    char    succ_num[8];
    char    deal_stat[1];
    char    rsp_detial[80];
}fl0021_rsp;
