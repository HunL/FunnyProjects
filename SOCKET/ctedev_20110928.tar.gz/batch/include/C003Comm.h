#ifndef __C003COMM_H
#define __C003COMM_H

#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/times.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <string.h>

/********************
//#include "Switch.h"
//#include "UsrErr.h"
//#include "TblAllUse.h"
********************/

/*begin of switch.h*/
#define NHostNameL                      4
#define NInsIdL                         13
/*end of switch.h*/


/*begin of type.h*/
#define SINT2                           short
#define UINT2                           unsigned short
#define SINT4                           int
#define UINT4                           unsigned int
#define SINT8                           long
#define UCHAR                           unsigned char
#define SCHAR                           char
#define VOID                            void
#define SPNT8                           double
#define KEYT                            key_t
#define TIMET                           time_t
#define SIZET                           size_t
#define SCKLT                           int
#define PIDT                            pid_t
#define TM                              struct tm
#define MSQDS                           struct msqid_ds
#define SADDR                           struct sockaddr
#define SLNGR                           struct linger
#define STAT                            struct stat
#define SADDRIN                         struct sockaddr_in
#define UNAME                           struct utsname
/*end of type.h*/


/*#define SACEnvCommLineInfKey            "TL_COMM_LINE_INF_KEY"*/
#define SAENVHEAD                 		getenv("FILEDIR")
#define SARcvFilePath             		"/03060000/"
#define SASndFilePath             		"/Snd_center/"
#define SAInstitutionId			  	    "TY_INSTITUTION_ID"

#define NCMaxAddrL                      15
#define NCMaxSonN                       10
#define NCListenBlkLogNDft              5
#define NCRetryTimeDft			        1

#define LCTrue               	        1

#define NCFirstTimeout                  60
#define NCSecondTimeout                 180

#define LCTcpSndFlg          			0
#define	LCTcpRcvFlg						0
 
#define NCMaxDataL                      2048

#define SAFileNameL               		200
#define SACommandL                		200


#define NCBeginMsgL					    114
#define NCMaxFileMsgL				    1024
#define NCMaxFileDataL			     	1016
#define NCEndMsgL					    85
#define NCQueryReqMsgL			     	24
#define NCMaxQueryRspMsgL		     	1518
#define NCMaxQueryRspDataL	     		1500

#define SCBeginReqMsgL				    "0112"
#define SCBeginRspMsgL			     	"0114"
#define SCSrvQryErrRspMsgL				"0068"
#define SCEndReqMsgL			     	"0083"
#define SCEndRspMsgL		     		"0085"
#define SCQueryReqMsgL	     			"0024"

#define SAPutFileReq              		8000
#define SAPutFileRsp              		8010
#define SAGetFileReq	              		8100
#define SAGetFileRsp  	          	  	8110
#define SAFileTransf    	          	8200
#define SATranEndReq      	        	8300
#define SATranEndRsp        	      		8310
#define SAQryFileReq          	   	 	8400
#define SAQryFileRsp            	  	8410


#define RSP_SUCCESS					"00"
#define RSP_INSTITUTION_ERR				"D1"
#define RSP_DATE_ERR					"D2"
#define RSP_FILETYPE_ERR				"D3"
#define RSP_FILESTAT_ERR				"D4"
#define RSP_FILE_NOT_EXIST				"D5"
#define RSP_FILE_NOT_SUPPORT				"D6"
#define RSP_FILE_LOCK					"D7"
#define RSP_FAILURE					"D8"
#define RSP_LENGTH_NOT_FIT				"D9"
#define RSP_UNCOMPRESS_ERR				"DA"
#define RSP_FILENAME_ERR				"DB"
#define RSP_CAN_NOT_RCV					"DC"
#define RSP_MAC_VERIFY_ERR				"DD"


#define SAFileFlg_Snd					'S'
#define SAFileFlg_Rcv					'R'
#define SATransf_No					'0'
#define SATransf_Being					'1'
#define SATransf_Failure				'2'
#define SATransf_Success				'3'
#define SAFileType_C					'C'
#define SAFileType_D					'D'

typedef struct {
    UCHAR                               saMessageType[4];
    UCHAR                               saSettleInstitution[11];
    UCHAR                               saFileDate[8];
    UCHAR                               saFileType[1];
} FileQueryReqMsgDef;

typedef struct {
    UCHAR                               saMessageType[4];
    UCHAR                               saSettleInstitution[11];
    UCHAR                               saEndFlag[1];
    UCHAR                               saFileInfoNum[2];
    UCHAR                               saFileInfoData[1500];
} FileQueryRspMsgDef;

typedef struct {
    UCHAR                               saMessageType[4];
    UCHAR                               saFileName[40];
    UCHAR                               saSettleInstitution[11];
    UCHAR                               saDate[8];
    UCHAR                               saCompressFlag[1];
    UCHAR                               saInitialPosition[10];
    UCHAR                               saTotalLength[10];
    UCHAR                               saFileTimeStamp[10];
    UCHAR                               saCurrentTimeStamp[10];
    UCHAR                               saSelfDefine[8];
} FiletransfBeginReqMsgDef;

typedef struct {
    UCHAR                               saMessageType[4];
    UCHAR                               saFileName[40];
    UCHAR                               saSettleInstitution[11];
    UCHAR                               saDate[8];
    UCHAR                               saCompressFlag[1];
    UCHAR                               saResponseCode[2];
    UCHAR                               saInitialPosition[10];
    UCHAR                               saTotalLength[10];
    UCHAR                               saFileTimeStamp[10];
    UCHAR                               saCurrentTimeStamp[10];
    UCHAR                               saSelfDefine[8];
} FiletransfBeginRspMsgDef;

typedef struct {
    UCHAR                               saMessageType[4];
    UCHAR                               saFileDataLength[4];
    UCHAR                               saFileData[1016];
} FiletransfDataMsgDef;

typedef struct {
    UCHAR                               saMessageType[4];
    UCHAR                               saFileName[40];
    UCHAR                               saSettleInstitution[11];
    UCHAR                               saDate[8];
    UCHAR                               saFileLength[10];
    UCHAR                               saSelfDefine[10];
} FiletransfEndReqMsgDef;

typedef struct {
    UCHAR                               saMessageType[4];
    UCHAR                               saFileName[40];
    UCHAR                               saSettleInstitution[11];
    UCHAR                               saDate[8];
    UCHAR                               saFileLength[10];
    UCHAR                               saResponseCode[2];
    UCHAR                               saSelfDefine[10];
} FiletransfEndRspMsgDef;


/*begin of M021DebugOpr.h*/
long        l_times;
struct tms  tagTMS;

static SCHAR							gsaDebugLogFileName[100]; 
static SCHAR							gsaMsgLogFileName[100]; 
static SCHAR							gsaErrLogFileName[100]; 
static SINT2							gnMLineDebugStat = -1;
static SINT2							gnDebugLogLevel = -1;

#define DEBUG_INIT(x)                   vMDebugInit(x)
#define DEBUG_INF(x, y, z)              vMDebugInf(x, y, z, __LINE__, __FILE__)
#define DEBUG_MSG(x, y)      			vMDebugMsg(x, y, __LINE__, __FILE__)

#define SAMEnvDebugLogName              "TL_DEBUG_LOG_NAME"
#define SAMEnvDebugLogLevel             "TL_DEBUG_LOG_LEVEL"
#define SAMEnvMsgLogName                "TL_MSG_LOG_NAME"
#define SAMEnvErrLogName				"TL_ERR_LOG_NAME"

#define NDebugLogOptFail                0x0001
#define NDebugLogOptSucceed             0x0002
#define NMsgLogOpt                      0x0004
#define NMsgLogOpt1                     0x0008
/*end of M021DebugOpr.h*/


/*begin of M005MsqOpr.c*/
#define SAMEnvHostName                  "TL_HOST_NAME"
#define SAMEnvRspMsqKey                 "TL_RSP_MSQ_KEY"
#define SAMEnvMsqMsgN                   "TL_MAX_MSG_IN_QUE"
#define SAMEnvMsqGapN                   "TL_MSQ_GAP_N"
#define SAMEnvMsqShmKey                 "TL_MSQ_SHM_KEY"
#define SAMEnvHostMsqDefKey             "TL_HOST_MSQ_DEF_KEY"
#define SAMEnvSrvMsqDefKey              "TL_SRV_MSQ_DEF_KEY"

#define NMMaxHostN                      20
#define NMMaxSrvN                       100
#define NMMaxMsqN                       100

#define m_va12                       	6
#define m_va13                      	8
#define m_va14                        	4

typedef struct {
    SINT4                               lSrvId;
    SINT2                               iSrvIndex;
    UCHAR                               saHostName[NHostNameL];
    KEYT                                keytMsqKey;
    long                                lMsqType;
    SINT4                               lMsqFreq;
} smrMSrvMsqRltDef;
typedef struct {
    UCHAR                               saHostName[NHostNameL];
    long                                lMsqType;
    KEYT                                keytMsqKey;
} hmrMHostMsqRltDef;
typedef struct {
    KEYT                                keytMsqKey;
    int                                 hMsqId;
} mhrMMsqHandlerRltDef;
typedef struct {
    SINT2                               nSrvN;
    smrMSrvMsqRltDef                    smraSrvMsqRlt[NMMaxSrvN];
} ssiMSrvSndInfDef;
typedef struct {
    SINT2                               nHostN;
    hmrMHostMsqRltDef                   hmraHostMsqRlt[NMMaxHostN];
} hsiMHostSndInfDef;
typedef struct {
    SINT2                               nMsqN;
    mhrMMsqHandlerRltDef                mhraMsqHandlerRlt[NMMaxMsqN];
} muiMMsqUseInfDef;
typedef struct {
    SINT2                               nTmp;
    ssiMSrvSndInfDef                    ssiSrvSndInf;
    hsiMHostSndInfDef                   hsiHostSndInf;
    muiMMsqUseInfDef                    muiMsqUseInf;
} smiMShmMsqInfDef;
typedef struct {
    UCHAR                               saReqHostName[NHostNameL];
    UCHAR                               saReqMsqKey[m_va12];
    UCHAR                               saReqMsqType[m_va13];
    UCHAR                               saReqSrvId[m_va14];
    UCHAR                               saRspHostName[NHostNameL];
    UCHAR                               saRspMsqKey[m_va12];
    UCHAR                               saRspMsqType[m_va13];
    SINT4                               lRspTag;
} mohMMsqOprHdrDef;

static ssiMSrvSndInfDef*                 m_VAL1;
static muiMMsqUseInfDef*                 m_VAL2;
static hsiMHostSndInfDef*                m_VAL3;
static smiMShmMsqInfDef*                 m_VAL4;
static SINT4                             m_VAL5 = 0;
static mohMMsqOprHdrDef                  m_VAL6;
static mohMMsqOprHdrDef                  m_VAL7;
static KEYT                              m_VAL8;
static long                              m_VAL9;
static SINT2                             m_VALa;
static SINT2                             m_VALb;
static SINT2                             m_VALc = 1;
#define m_va11(x)          				 (x == m_va17)
#define m_va12              		     6
#define m_va13             				 8
#define m_va14                 		     4
#define m_va15                 			 0660
#define m_va16               			 IPC_NOWAIT
#define m_va17                 			 998
#define m_va18                		 	 997
#define m_va19                			 999
/*end of M005MsqOpr.c*/

/*begin of M005EncOpr.h M005EncOpr.c*/
#define SAMEnvEncOprSrvId               "TL_ENC_OPR_SRV_ID"
#define SAMEnvEncOprTimeout             "TL_ENC_OPR_TIMEOUT"
#define SAMEnvEncOprShmKey              "TL_ENC_OPR_SHM_KEY"
#define SAMEnvEncOprEncOptKey           "TL_ENC_OPR_ENC_OPT_KEY"

typedef struct {
    SINT2                               nTxnType;
    SINT2                               nMsgIndex;
    SINT2                               nFeature;
    SINT2                               nStepNumber;
    SINT4                               nReqCode;
    SINT2                               nDblOpr;
} eoeMEncOptEleDef;

typedef struct {
    SINT2                               nEncOptN;
    eoeMEncOptEleDef                    eoeaEle[200]; /*NMMaxEncOptN*/
} eoiMEncOptInfDef;

static eoiMEncOptInfDef*                geoipEncOptInf;

/*end of C003Comm.h */

#endif

