find . -name "*.o" -exec rm -f {} \;
find . -name "*.bnd" -exec rm -f {} \;
   