/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_2210.pc                                                */
/* DESCRIPTIONS: Confirm bth_dtl_bdt									 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"
#include "DbsTbl.h"


char	gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[INTER_BRH_CODE_LEN + 1];

int Total_2210()
{
    int nTotalNum=0 ;
	int nReturnCode=0;
     bth_dtl_bdt_tmp_def dbbth_dtl_bdt_tmp;
     memset(&dbbth_dtl_bdt_tmp,0x00,sizeof(dbbth_dtl_bdt_tmp));
     HtMemcpy(dbbth_dtl_bdt_tmp.inter_brh_code,ext_inter_brh_code,10);
    nReturnCode=DbsBTH_DTL_BDT_TMP_UNI(DBS_SELECT1,&dbbth_dtl_bdt_tmp);

    if(nReturnCode && nReturnCode != DBS_FETCHNULL)
    {
        HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"select from bth_cup_txn_bdt error, sqlcode=[%d].", nReturnCode);
        return-1 ;
    }
    nTotalNum=dbbth_dtl_bdt_tmp.seq_num;
    HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"nTotalNum =[%d].",nTotalNum);
    return nTotalNum;
}

int Task_2210 ( int nBeginOffset, int nEndOffset )
{
	bth_dtl_bdt_tmp_def dbbth_dtl_bdt_tmp; 
	int 	nReturnCode = 0; 
	char    sqlstr[1024];
	memset(sqlstr,0,sizeof(sqlstr));
	HtSprintf(sqlstr,"SELECT * FROM BTH_DTL_BDT_TMP WHERE INTER_BRH_CODE='%s' AND SEQ_NUM <=%d AND SEQ_NUM >= %d order by seq_num",ext_inter_brh_code,nEndOffset,nBeginOffset);

	nReturnCode=OpenCursorBTH_DTL_BDT_TMP(sqlstr);
	if(nReturnCode)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "OPEN CURSOR bth_dtl_bdt error sqlcode=[%d].\n", nReturnCode);
		return nBeginOffset;
	}
	
	while(1)
	{
		memset(&dbbth_dtl_bdt_tmp,0x00,sizeof(dbbth_dtl_bdt_tmp));
		nReturnCode=FetchCursorBTH_DTL_BDT_TMP(&dbbth_dtl_bdt_tmp);
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "FETCH CURSOR bth_dtl_bdt error sqlcode=[%d][%s][%s].\n", nReturnCode, dbbth_dtl_bdt_tmp.cup_ssn, dbbth_dtl_bdt_tmp.date_settlmt);

		if(nReturnCode && nReturnCode != DBS_FETCHNULL)
		{
			if(nReturnCode==DBS_NOTFOUND)
			{
				break;
			}
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "FETCH CURSOR bth_dtl_bdt error sqlcode=[%d].\n", nReturnCode);
			CloseCursorBTH_DTL_BDT_TMP();
			return dbbth_dtl_bdt_tmp.seq_num;
		}
		nReturnCode = DbsBTH_DTL_BDT_UNI(DBS_INSERT, &dbbth_dtl_bdt_tmp);
		if (nReturnCode)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Insert into bth_dtl_bdt error sqlcode=[%d].\n", nReturnCode);
			CloseCursorBTH_DTL_BDT_TMP();
			return dbbth_dtl_bdt_tmp.seq_num;
		}
		DbsCommit ();
	}
	CloseCursorBTH_DTL_BDT_TMP();
	return 0;
}
