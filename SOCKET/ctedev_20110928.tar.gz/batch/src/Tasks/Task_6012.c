/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_2602.pc                                                */
/* DESCRIPTIONS: load cup bdt file											 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23                                                                */
/*****************************************************************************/

#include "batch.h"
#include "tbl_opr.h"

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;

char cup_brh_id[8 + 1];
static int nModifyPosSumCN(char *sType, char *sDate, stFileDef *pstFile);

/*****************************************************************************/
/* FUNC:   int Total_6001()                                                  */
/* INPUT:  ��                                                                */
/* OUTPUT: nFileCount: ��ˮ�ļ�����                                          */
/* RETURN: nFileCount: �ɹ�, -1: ʧ��                                        */
/* DESC:   ���Ҫ�����������ˮ�ļ��ĸ���                                    */
/*****************************************************************************/
int Total_6012()
{
    return 1;
}

/*****************************************************************************/
/* FUNC:   int Task_6001(int nBeginOffset, int nEndOffset)                   */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   װ������LOGO����                                                */
/*****************************************************************************/
int Task_6012 ( int nBeginOffset, int nEndOffset )
{
    int     	i;
    int     	nReturnCode;
    char    	sDate[DATE_LEN + 1];              /*����*/
    char    	sType[8];                         /*������ˮ�ļ�����--bdt*/
    int     	nFileCount;                       /*Ҫ��õ�����bdt��ˮ�ļ�����*/
    stFileDef   stFile[FILE_COUNT_MAX];       /*һ�������ļ���Ϣ�Ľṹ������*/
	char   sPath[300];
	char   *p;

    memset(sType,0,sizeof(sType));

    /*�������*/
    HtStrcpy(sDate,dbtbl_date_inf.stoday);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Task_6011:sDate=%s\n",sDate);
	memset(sPath,0,sizeof(sPath));
	HtSprintf(sPath, "%s/%8.8s/%s/CUP/03065800/INOYYMMDD99SUMCN", getenv("BATCH_FILE_PATH"), sDate, getenv("CUP_ID"));
	p=strstr(sPath,"YYMMDD");
	if(p) HtMemcpy(p,sDate+2,6);

	memset(stFile,0x00,sizeof(stFile));
	HtStrcpy (stFile[0].sFileName, sPath);
	HtMemcpy (stFile[0].sInterInstId, ext_inter_brh_code, 6);

    /*װ���ļ������ݿ����*/
    for (i = nBeginOffset - 1; i < nEndOffset; i++)
    {
        nReturnCode = nModifyPosSumCN (sType, sDate, &stFile[i]);
        if (nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nModifyPosAcom for %s error, %d.", stFile[i].sFileName, nReturnCode);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nModifyPosAcom for %s success.", stFile[i].sFileName);
    }

    return 0;
}

/*****************************************************************************/
/* FUNC:   int nModifyPosSumCN (char *sType, char *sDate,                   */
/*                               stFileDef *pstFile)                         */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP_BDT,CUP_TDB,RCUP,ERR,RERR,LOGO   */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/*         pstFile: ��ˮ�ļ���Ϣ                                             */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ĳ����ˮ�ļ�������װ�ص����ݿ���                                */
/*****************************************************************************/
static int nModifyPosSumCN (char *sType, char *sDate, stFileDef *pstFile)
{
    int   i;
    char    sTxnNum[5];
    char	file_name[FILE_NAME_LEN_MAX+1];
    char	afile_name[FILE_NAME_LEN_MAX+1];
    char	afile_bak[FILE_NAME_LEN_MAX+1];
    char    sFileRecord[RECORD_LEN_MAX+1];
    char    sDbRecord[RECORD_LEN_MAX+1];
    char    query_num[12+1];
	char	trans_feeb[12+1];
    char    amt_sum[16+1];
    char    str_tmp[40+1];
	char	str_recv[16+1];
	char	str_send[16+1];
	char	cmd[1024];
        struct stat stat_buf;
        tbl_file_trans_def dbTblfiletrans;
	long    file_size;
	bth_cup_txn_def dbbth_cup_txn;
	bth_cup_err_def dbbth_cup_err;
    int 	nReturnCode;
    int 	nRecordLen;
	int		trans_num;
	double  recv_amt;
	double  amt_trans;
	double  exp_feeb;
	double  exh_fee;
	double 	rvl_feeb; 
	double  total_feeb;
	double  total_amt;
	double  exp_amt;
	double 	rvl_amt; 
	double  recv_exp;
	double  recv_cel;
	double  recv_ret;
	double  err_amt;
    FILE    *fp;
    FILE    *fp1;
    char	*p;
    int     nFlag;
    i  			= 1;
    nRecordLen  = 0;
	exh_fee=0;
	err_amt=0;
    memset(afile_name,0x00,sizeof(afile_name));
    p=strrchr(pstFile->sFileName,'/');
    memcpy(afile_name,pstFile->sFileName,p-(pstFile->sFileName));
    strcat(afile_name,"/");
    strcat(afile_name,"POSMD");
    nReturnCode = CheckDir( afile_name );
    if(nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Create directory error: [%s].", file_name );
    }
	
    sprintf(afile_name,"%s%s",afile_name,p);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"afile directory [%s].", afile_name );
	memset(file_name,0x00,sizeof(file_name));
	memset(afile_bak,0,sizeof(afile_bak));
	sprintf(afile_bak,"%s.bak.union",afile_name);
	sprintf(file_name,"%s",pstFile->sFileName);

	fp1 = fopen (afile_name, "wb+");
    if (!fp1)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", afile_name,errno);
        return -1;
    }
	fp = fopen (pstFile->sFileName, "r");
    if (!fp)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", pstFile->sFileName, errno);
        fclose (fp1);
        return -1;
    }
    /* get file record */
    while (1)
    {
        memset(sFileRecord	, 0, sizeof(sFileRecord));
		memset(&dbbth_cup_txn,0x00,sizeof(dbbth_cup_txn));
		memset(&dbbth_cup_err,0x00,sizeof(dbbth_cup_err));
		memset(query_num,0,sizeof(query_num));
		memset(str_tmp,0,sizeof(str_tmp));
		HtMemcpy(dbbth_cup_txn.date_settlmt,dbtbl_date_inf.stoday,8);
		HtMemcpy(dbbth_cup_txn.inter_brh_code,ext_inter_brh_code,10);
		HtMemcpy(dbbth_cup_err.date_settlmt,dbtbl_date_inf.stoday,8);
		HtMemcpy(dbbth_cup_err.inter_brh_code,ext_inter_brh_code,10);
        if (fgets (sFileRecord, RECORD_LEN_MAX, fp) == NULL)
        {
            break;
        }
		if(i==12)
		{
			HtMemcpy(dbbth_cup_txn.txn_num,"1303",4);
			nReturnCode=DbsBthcuptxnTdb(DBS_SELECT3,&dbbth_cup_txn,&nFlag,0);
			if(nReturnCode)
			{
				HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
				fclose (fp1);
				fclose (fp);
				return -1;
			}
			HtMemcpy(query_num,sFileRecord+22,12);
			HtSprintf(str_tmp,"%d",atoi(query_num)-nFlag);
			memset(sFileRecord+22,' ',12);
			HtMemcpy(sFileRecord+22+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
			
		}
        if(i==30)
        {       
            HtMemcpy(dbbth_cup_txn.txn_num,"1313",4);
            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {       
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            } 
			if(nFlag)
			{
				memset(amt_sum,0,sizeof(amt_sum));
				memset(str_tmp,0,sizeof(str_tmp));
				HtMemcpy(query_num,sFileRecord+22,12);
				trans_num=atoi(query_num);
				memset(query_num,0,12);
				HtSprintf(query_num,"%d",trans_num-nFlag);
				memset(sFileRecord+22,' ',12);
				HtMemcpy(sFileRecord+22+12-strlen(query_num),query_num,strlen(query_num));
				HtMemcpy(amt_sum,sFileRecord+36,16);
				amt_trans=atof(amt_sum);
				exp_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
				exp_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
				memset(str_tmp,0,16);
				HtSprintf(str_tmp,"%.2f",amt_trans+exp_amt);
				memset(sFileRecord+36,' ',16);
				HtMemcpy(sFileRecord+36+16-strlen(str_tmp),str_tmp,strlen(str_tmp));
				
				nFlag=0;
				HtMemcpy(dbbth_cup_txn.txn_num,"2313",4);
	            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
	            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
	            {      
	                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
	                fclose (fp1);
	                fclose (fp);
	                return -1;
	            }
	            if(nFlag)
	            {
					memset(query_num,0,sizeof(query_num));
					memset(str_tmp,0,sizeof(str_tmp));
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(query_num,sFileRecord+53,10);
	                trans_num=atoi(query_num);
	                memset(query_num,0,10);
	                HtSprintf(query_num,"%d",trans_num-nFlag);
					memset(sFileRecord+53,' ',10);
					HtMemcpy(sFileRecord+53+10-strlen(query_num),query_num,strlen(query_num));
					HtMemcpy(amt_sum,sFileRecord+65,16);
					amt_trans=atof(amt_sum);
	                rvl_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
	                rvl_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
					memset(str_tmp,0,16);
					HtSprintf(str_tmp,"%.2f",amt_trans-rvl_amt);
					memset(sFileRecord+65,' ',16);
					HtMemcpy(sFileRecord+65+16-strlen(str_tmp),str_tmp,strlen(str_tmp));
					memset(trans_feeb,0,sizeof(trans_feeb));
					HtMemcpy(trans_feeb,sFileRecord+83,12);
					total_feeb=atof(trans_feeb)-(exp_feeb+rvl_feeb);				
					memset(str_tmp,0,12);
					HtSprintf(str_tmp,"%.2f",total_feeb);
					memset(sFileRecord+83,' ',12);
					HtMemcpy(sFileRecord+83+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(amt_sum,sFileRecord+97,16);
					total_amt=atof(amt_sum)+exp_amt-rvl_amt-(exp_feeb+rvl_feeb);
					memset(amt_sum,0,16);
					HtSprintf(amt_sum,"%.2f",total_amt);
					memset(sFileRecord+97,' ',16);
					HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
					recv_exp=-exp_amt+rvl_amt+(exp_feeb+rvl_feeb);
				}
				else
				{
                                        memset(trans_feeb,0,sizeof(trans_feeb));
                                        HtMemcpy(trans_feeb,sFileRecord+83,12);
                                        total_feeb=atof(trans_feeb)-(exp_feeb);
                                        memset(str_tmp,0,12);
                                        HtSprintf(str_tmp,"%.2f",total_feeb);
					memset(sFileRecord+83,' ',12);
                                        HtMemcpy(sFileRecord+83+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(amt_sum,sFileRecord+97,16);
					total_amt=atof(amt_sum)+exp_amt-exp_feeb;
					memset(amt_sum,0,16);
					HtSprintf(amt_sum,"%.2f",total_amt);
					memset(sFileRecord+97,' ',16);
					HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
					recv_exp=-exp_amt+exp_feeb;
				}
			}
		}
        if(i==31)
        {       
            HtMemcpy(dbbth_cup_txn.txn_num,"3313",4);
            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {       
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            } 
			if(nFlag)
			{
				memset(amt_sum,0,sizeof(amt_sum));
				memset(str_tmp,0,sizeof(str_tmp));
				HtMemcpy(query_num,sFileRecord+22,12);
				trans_num=atoi(query_num);
				memset(query_num,0,12);
				HtSprintf(query_num,"%d",trans_num-nFlag);
				memset(sFileRecord+22,' ',12);
				HtMemcpy(sFileRecord+22+12-strlen(query_num),query_num,strlen(query_num));
				HtMemcpy(amt_sum,sFileRecord+36,16);
				amt_trans=atof(amt_sum);
				exp_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
				exp_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
				memset(str_tmp,0,16);
				HtSprintf(str_tmp,"%.2f",amt_trans-exp_amt);
				memset(sFileRecord+36,' ',16);
				HtMemcpy(sFileRecord+36+16-strlen(str_tmp),str_tmp,strlen(str_tmp));
				
				nFlag=0;
				HtMemcpy(dbbth_cup_txn.txn_num,"4313",4);
	            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
	            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
	            {      
	                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
	                fclose (fp1);
	                fclose (fp);
	                return -1;
	            }
	            if(nFlag)
	            {
					memset(query_num,0,sizeof(query_num));
					memset(str_tmp,0,sizeof(str_tmp));
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(query_num,sFileRecord+53,10);
	                trans_num=atoi(query_num);
	                memset(query_num,0,10);
	                HtSprintf(query_num,"%d",trans_num-nFlag);
					HtMemcpy(sFileRecord+53,query_num,10);
					memset(sFileRecord+53,' ',10);
					HtMemcpy(sFileRecord+53+10-strlen(query_num),query_num,strlen(query_num));
					HtMemcpy(amt_sum,sFileRecord+65,16);
					amt_trans=atof(amt_sum);
	                rvl_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
	                rvl_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
					memset(str_tmp,0,16);
					HtSprintf(str_tmp,"%.2f",amt_trans+rvl_amt);
					memset(sFileRecord+65,' ',16);
					HtMemcpy(sFileRecord+65+16-strlen(str_tmp),str_tmp,strlen(str_tmp));
					memset(trans_feeb,0,sizeof(trans_feeb));
					HtMemcpy(trans_feeb,sFileRecord+83,12);
					total_feeb=atof(trans_feeb)-(exp_feeb+rvl_feeb);				
					memset(str_tmp,0,12);
					HtSprintf(str_tmp,"%.2f",total_feeb);
					memset(sFileRecord+83,' ',12);
					HtMemcpy(sFileRecord+83+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(amt_sum,sFileRecord+97,16);
					total_amt=atof(amt_sum)-exp_amt+rvl_amt-(exp_feeb+rvl_feeb);
					memset(amt_sum,0,16);
					HtSprintf(amt_sum,"%.2f",total_amt);
					memset(sFileRecord+97,' ',16);
					HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
					recv_cel=exp_amt-rvl_amt+(exp_feeb+rvl_feeb);
				}
				else
				{
                                        memset(trans_feeb,0,sizeof(trans_feeb));
                                        HtMemcpy(trans_feeb,sFileRecord+83,12);
                                        total_feeb=atof(trans_feeb)-(exp_feeb);
                                        memset(str_tmp,0,12);
                                        HtSprintf(str_tmp,"%.2f",total_feeb);
                                        memset(sFileRecord+83,' ',12);
                                        HtMemcpy(sFileRecord+83+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(amt_sum,sFileRecord+97,16);
					total_amt=atof(amt_sum)-exp_amt-exp_feeb;
					memset(amt_sum,0,16);
					HtSprintf(amt_sum,"%.2f",total_amt);
					memset(sFileRecord+97,' ',16);
					HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
					recv_cel=exp_amt+exp_feeb;
				}
			}
		}
        if(i==33)
        {       
            HtMemcpy(dbbth_cup_txn.txn_num,"5153",4);
            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {       
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            }       
            if(nFlag)
            {       
                memset(amt_sum,0,sizeof(amt_sum));
                memset(str_tmp,0,sizeof(str_tmp));
                HtMemcpy(query_num,sFileRecord+22,12);
                trans_num=atoi(query_num);        
                memset(query_num,0,12);
                HtSprintf(query_num,"%d",trans_num-nFlag);
                memset(sFileRecord+22,' ',12);
                HtMemcpy(sFileRecord+22+12-strlen(query_num),query_num,strlen(query_num));
                HtMemcpy(amt_sum,sFileRecord+36,16);
                amt_trans=atof(amt_sum);
                exp_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
                exp_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
                memset(str_tmp,0,16);
                HtSprintf(str_tmp,"%.2f",amt_trans-exp_amt);
                memset(sFileRecord+36,' ',16);
				HtMemcpy(sFileRecord+36+16-strlen(str_tmp),str_tmp,strlen(str_tmp));
                memset(trans_feeb,0,sizeof(trans_feeb));
                HtMemcpy(trans_feeb,sFileRecord+83,12);
				total_feeb=atof(trans_feeb)-exp_feeb;
                memset(str_tmp,0,sizeof(str_tmp));
                memset(str_tmp,0,12);
                HtSprintf(str_tmp,"%.2f",total_feeb);
                memset(sFileRecord+83,' ',12);
                HtMemcpy(sFileRecord+83+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
            	memset(amt_sum,0,sizeof(amt_sum));
            	HtMemcpy(amt_sum,sFileRecord+97,16);
            	total_amt=atof(amt_sum)-exp_amt-exp_feeb;
            	memset(amt_sum,0,16);
            	HtSprintf(amt_sum,"%.2f",total_amt);
            	memset(sFileRecord+97,' ',16);
            	HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
				recv_ret=exp_amt+exp_feeb;
			}
		}
		if(i==37)
		{
            memset(str_send,0,sizeof(str_send));
            memset(amt_sum,0,sizeof(amt_sum));
            HtMemcpy(str_send,sFileRecord+97,16);
            recv_amt=atof(str_send);
			memset(amt_sum,0,16);
			HtSprintf(amt_sum,"%.2f",recv_amt-(recv_exp+recv_cel+recv_ret));
			memset(sFileRecord+97,' ',16);
            HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
		}
		if(i==38)
		{
			memset(str_send,0,sizeof(str_send));
            memset(amt_sum,0,sizeof(amt_sum));
            HtMemcpy(str_send,sFileRecord+97,16);
			memset(amt_sum,0,16);
			HtSprintf(amt_sum,"%.2f",atof(str_send)-(recv_exp+recv_cel+recv_ret));
			memset(sFileRecord+97,' ',16);
            HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
		}
		if(i==77||i==80||i==92)
		{
			HtMemcpy(dbbth_cup_err.txn_type,sFileRecord,3);
			nReturnCode=DbsBthcupErr(DBS_SELECT1,&dbbth_cup_err);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {      
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            } 
			if(dbbth_cup_err.seq_num)
			{
                memset(amt_sum,0,sizeof(amt_sum));
                memset(str_tmp,0,sizeof(str_tmp));
                HtMemcpy(query_num,sFileRecord+22,12);
                trans_num=atoi(query_num);
                memset(query_num,0,12);
                HtSprintf(query_num,"%d",trans_num-dbbth_cup_err.seq_num);
                memset(sFileRecord+22,' ',12);
                HtMemcpy(sFileRecord+22+12-strlen(query_num),query_num,strlen(query_num));
                HtMemcpy(amt_sum,sFileRecord+36,16);
                amt_trans=atof(amt_sum);
                exp_feeb=atof(dbbth_cup_err.reserved_cup)/100;
                exp_amt=atof(dbbth_cup_err.reserve1)/100;
                memset(str_tmp,0,16);
                HtSprintf(str_tmp,"%.2f",amt_trans+exp_amt);
                memset(sFileRecord+36,' ',16);
                HtMemcpy(sFileRecord+36+16-strlen(str_tmp),str_tmp,strlen(str_tmp));
				memset(trans_feeb,0,sizeof(trans_feeb));
                HtMemcpy(trans_feeb,sFileRecord+83,12);
                total_feeb=atof(trans_feeb)-exp_feeb;
                memset(str_tmp,0,sizeof(str_tmp));
                memset(str_tmp,0,12);
                HtSprintf(str_tmp,"%.2f",total_feeb);
                memset(sFileRecord+83,' ',12);
                HtMemcpy(sFileRecord+83+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
                memset(amt_sum,0,sizeof(amt_sum));
                HtMemcpy(amt_sum,sFileRecord+97,16);
                total_amt=atof(amt_sum)+exp_amt-exp_feeb;
                memset(amt_sum,0,16);
                HtSprintf(amt_sum,"%.2f",total_amt);
                memset(sFileRecord+97,' ',16);
                HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
				err_amt=err_amt-exp_amt+exp_feeb;
				exh_fee=exh_fee+atof(dbbth_cup_err.reserve2);
			}
		}
        if(i==78||i==79||i==81||i==88||i==91)
        {
            HtMemcpy(dbbth_cup_err.txn_type,sFileRecord,3);
            nReturnCode=DbsBthcupErr(DBS_SELECT1,&dbbth_cup_err);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {     
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            }
            if(dbbth_cup_err.seq_num)
            {
                memset(amt_sum,0,sizeof(amt_sum));
                memset(str_tmp,0,sizeof(str_tmp));
                HtMemcpy(query_num,sFileRecord+22,12);
                trans_num=atoi(query_num);
                memset(query_num,0,12);
                HtSprintf(query_num,"%d",trans_num-dbbth_cup_err.seq_num);
                memset(sFileRecord+22,' ',12);
                HtMemcpy(sFileRecord+22+12-strlen(query_num),query_num,strlen(query_num));
                HtMemcpy(amt_sum,sFileRecord+36,16);
                amt_trans=atof(amt_sum);
                exp_feeb=atof(dbbth_cup_err.reserved_cup)/100;
                exp_amt=atof(dbbth_cup_err.reserve1)/100;
                memset(str_tmp,0,16);
                HtSprintf(str_tmp,"%.2f",amt_trans-exp_amt);
                memset(sFileRecord+36,' ',16);
                HtMemcpy(sFileRecord+36+16-strlen(str_tmp),str_tmp,strlen(str_tmp));
                memset(trans_feeb,0,sizeof(trans_feeb));
                HtMemcpy(trans_feeb,sFileRecord+83,12);
                total_feeb=atof(trans_feeb)-exp_feeb;
                memset(str_tmp,0,sizeof(str_tmp));
                memset(str_tmp,0,12);
                HtSprintf(str_tmp,"%.2f",total_feeb);
                memset(sFileRecord+83,' ',12);
                HtMemcpy(sFileRecord+83+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
                memset(amt_sum,0,sizeof(amt_sum));
                HtMemcpy(amt_sum,sFileRecord+97,16);
                total_amt=atof(amt_sum)-exp_amt-exp_feeb;
                memset(amt_sum,0,16);
                HtSprintf(amt_sum,"%.2f",total_amt);
                memset(sFileRecord+97,' ',16);
                HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
                err_amt=err_amt+exp_amt+exp_feeb;
				exh_fee=exh_fee+atof(dbbth_cup_err.reserve2);
            }
        }
		if(i==93)
		{
        	memset(trans_feeb,0,sizeof(trans_feeb));
            HtMemcpy(trans_feeb,sFileRecord+83,12);
            total_feeb=atof(trans_feeb)-exh_fee;
            memset(str_tmp,0,sizeof(str_tmp));
            memset(str_tmp,0,12);
            HtSprintf(str_tmp,"%.2f",total_feeb);
            memset(sFileRecord+83,' ',12);
            HtMemcpy(sFileRecord+83+12-strlen(str_tmp),str_tmp,strlen(str_tmp));
            memset(amt_sum,0,sizeof(amt_sum));
            HtMemcpy(amt_sum,sFileRecord+97,16);
            memset(amt_sum,0,16);
            HtSprintf(amt_sum,"%.2f",total_feeb);
            memset(sFileRecord+97,' ',16);
            HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
		}	
		if(i==94)
		{
            memset(amt_sum,0,sizeof(amt_sum));
			memset(str_send,0,sizeof(str_send));
            HtMemcpy(str_send,sFileRecord+97,16);
            memset(amt_sum,0,16);
            HtSprintf(amt_sum,"%.2f",atof(str_send)-err_amt-exh_fee);
            memset(sFileRecord+97,' ',16);
            HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
		}
		if(i==95)
		{
            memset(str_send,0,sizeof(str_send));
            memset(amt_sum,0,sizeof(amt_sum));
            HtMemcpy(str_send,sFileRecord+97,16);
            memset(amt_sum,0,16);
            HtSprintf(amt_sum,"%.2f",atof(str_send)-err_amt-exh_fee);
            memset(sFileRecord+97,' ',16);
            HtMemcpy(sFileRecord+97+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
		}
		
		if(i==97)
		{
            memset(str_send,0,sizeof(str_send));
            memset(amt_sum,0,sizeof(amt_sum));
            HtMemcpy(str_send,sFileRecord+74,16);
            memset(amt_sum,0,16);
            HtSprintf(amt_sum,"%.2f",atof(str_send)-err_amt-exh_fee-(recv_exp+recv_cel+recv_ret));
            memset(sFileRecord+74,' ',16);
            HtMemcpy(sFileRecord+74+16-strlen(amt_sum),amt_sum,strlen(amt_sum));
		}
		
		nRecordLen=fwrite(sFileRecord,strlen(sFileRecord),1,fp1);
		if(nRecordLen<0)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "write to file error");
			fclose (fp1);
    		fclose (fp);
			return -1;
		}
		i++;
    }
    fclose (fp1);
    fclose (fp);
    memset(&stat_buf,0x00,sizeof(stat_buf));
    if(stat(afile_name,&stat_buf)==-1)
    {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "����stat error[%s][%d]",afile_name,errno);
            return -1;
    }
    file_size=stat_buf.st_size;
    memset(&dbTblfiletrans,0,sizeof(dbTblfiletrans));
    p=strrchr(afile_name,'/');
    strcpy(dbTblfiletrans.inter_brh_code,"03060000");
    strcpy(dbTblfiletrans.sa_file_name,p+1);
    strcpy(dbTblfiletrans.sa_stlm_inst_id,"03065800");
    strcpy(dbTblfiletrans.sa_file_flg,"R");
    strcpy(dbTblfiletrans.sa_compress_flg,"N");
    strcpy(dbTblfiletrans.sa_file_stat,"3");
    strcpy(dbTblfiletrans.sa_trace_log,"����POS�����޸�");
    HtSprintf(dbTblfiletrans.sa_file_length,"%010ld",file_size);
    nReturnCode=lQTblFileTransOpr(NTblUpdate1,&dbTblfiletrans);
    if(nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_file_name[%s]",dbTblfiletrans.sa_file_name);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_file_flg[%s]",dbTblfiletrans.sa_file_flg);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_stlm_inst_id[%s]",dbTblfiletrans.sa_stlm_inst_id);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "update tbl_file_trans error[%d]",glSysError);
        return -1;
    }
	memset(cmd,0,sizeof(cmd));
	HtSprintf(cmd,"mv %s %s",file_name,afile_bak);
	system(cmd);
    memset(cmd,0,sizeof(cmd));
    HtSprintf(cmd,"cp %s %s",afile_name,file_name);
    system(cmd);
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file sum success");
    return 0;
}
