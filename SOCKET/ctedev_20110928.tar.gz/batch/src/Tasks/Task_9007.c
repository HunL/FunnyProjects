/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_1907.pc                                                */
/* DESCRIPTIONS: Generate CC success txn file                                */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  char    ext_child_date[8+1];
extern	char	ext_inter_brh_code[10+1];
extern	int 	ext_inter_brh_sta;
static    tbl_txn_def dbtbl_txn;
static    tbl_txn_def dbtbl_txn_rvs;
int Total_9007()
{
    return 1;
}

int Task_9007 ( int nBeginOffset, int nEndOffset )
{
    int     nReturn;
    char    *pstr;
    char    file_name[200];
    char    sRecord[RECORD_LEN_MAX];
    struct  stat    lstatDataTmpPathStat;
    FILE    *fp;
    int     i=0;
    int     iTotal=0;
	int		nTotalNum;
    int nReturnCode;
	bth_file_stat_def       dbfilestatus;
	char    sSqlBuf[SQL_BUF_LEN];
	char	amt_tmp[20+1];
	char	amt_str[20+1];
	char    ssn_tmp[8+1];
	char	hour_front[6+1];
	char	hour_later[6+1];
	char	yesterday[8+1];
	double   amt_trans;
	char	txn_num[4+1];
	time_t  lTime;
    char    cTime[15];
	char	val_tmp[200];
	struct tm   *tTmLocal;
	char	tail[50+1];
	char    sret[2+1];
	char    cfgFileName[200];
	tbl_txn_def dbtbl_txn_cl;
	tbl_inf_mchnt_inf_def   tbl_mchnt_inf;
    struct tms tTMS;
    long    lBeginTime, lEndTime;


    memset(cfgFileName,0,sizeof(cfgFileName));
    memset(hour_front,0,sizeof(hour_front));
    memset(hour_later,0,sizeof(hour_later));
    HtSprintf(cfgFileName,"%s/config/credit.cfg",getenv("MKHOME"));
	glbPflGetString("CREDIT_TIME","HOUR_FRONT",cfgFileName,hour_front);
	glbPflGetString("CREDIT_TIME","HOUR_LATER",cfgFileName,hour_later);
    memset(yesterday,0,sizeof(yesterday));
    CalNewDate(ext_child_date,-1,yesterday);

    memset( file_name, 0, 200);
    HtSprintf(file_name, "%s/YYYYMMDD/%s/%s", getenv("BATCH_FILE_PATH"), getenv("CUP_ID"), CREDIT_FILE_PATH);
    pstr = strstr (file_name, "YYYYMMDD");
    if(pstr) HtMemcpy (pstr, ext_child_date, 8);

    nReturn = CheckDir( file_name );
    if(nReturn)
    {
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Create directory error: [%s].", file_name );
        return -1;
    }

    HtStrcat( file_name, "/");
    HtStrcat( file_name, CT_SUCC_NAME);
    HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "file_name=[%s].", file_name);

    fp = fopen (file_name, "w+");
    if (!fp)
    {
        fp = fopen(file_name, "wr+");
        if( !fp )
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", file_name);
            return -1;
        }
    }
	memset(tail,'T',50);
	tail[50]='\0';
	memset(sret,0,sizeof(sret));
	sret[0]=0x0D;
	sret[1]=0x0A;
	
	memset(&dbtbl_txn,0x00,sizeof(dbtbl_txn));
    HtMemcpy(dbtbl_txn.inst_date,yesterday,8);
    HtMemcpy(dbtbl_txn.host_date,ext_child_date,8);
    HtMemcpy(dbtbl_txn.misc_1,hour_front,6);
    HtMemcpy(dbtbl_txn.misc_1+6,hour_later,6);
    nReturnCode=DbsTblTxn(DBS_CURSOR5,&dbtbl_txn);

	nReturnCode=DbsTblTxn(DBS_OPEN5,&dbtbl_txn);
	if(nReturnCode)
	{
    	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "OPEN sqlcode=[%d].", nReturnCode);
    	fclose(fp);
    	return -1;
	}

    while(1)
    { 
		memset(&dbtbl_txn,0x00,sizeof(dbtbl_txn));
lBeginTime = times( &tTMS);
        nReturnCode=DbsTblTxn(DBS_FETCH5,&dbtbl_txn);   
        if( nReturnCode &&nReturnCode != DBS_FETCHNULL )
        {
            if(nReturnCode==DBS_NOTFOUND)
            {
                break;
            }
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sqlcode=[%d].", nReturnCode);
            DbsTblTxn(DBS_CLOSE5,&dbtbl_txn);
            fclose(fp);
			return -1;
        }
		if((!memcmp(dbtbl_txn.txn_num,"1107",4)||!memcmp(dbtbl_txn.txn_num,"1097",4))&&!memcmp(dbtbl_txn.cancel_flag,"1",1))
		{
			memset(&dbtbl_txn_cl,0x00,sizeof(dbtbl_txn_cl));
			HtMemcpy(dbtbl_txn_cl.key_cancel,dbtbl_txn.key_cancel,32);
			HtMemcpy(dbtbl_txn_cl.txn_num,dbtbl_txn.txn_num,4);
			nReturnCode=DbsTblTxn(DBS_SELECT3,&dbtbl_txn_cl);
			if(nReturnCode)
			{
				HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sqlcode=[%d].",nReturnCode);
            	DbsTblTxn(DBS_CLOSE5,&dbtbl_txn);
            	fclose(fp);
				return -1;	
			}
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "[%s][%s]",dbtbl_txn_cl.inst_date,dbtbl_txn.inst_date);
			if(!memcmp(dbtbl_txn_cl.inst_date,ext_child_date,8))
			{
				if(memcmp(dbtbl_txn_cl.inst_time,hour_front,6)<0)
				{
					continue;
				}
			}
			else
			{
				continue;	
			}
		}
		if(!memcmp(dbtbl_txn.txn_num,"1107",4)&&!memcmp(dbtbl_txn.trans_state,"R",1))
		{
            memset(&dbtbl_txn_cl,0x00,sizeof(dbtbl_txn_cl));
            HtMemcpy(dbtbl_txn_cl.key_cancel,dbtbl_txn.key_cancel,32);
            HtMemcpy(dbtbl_txn_cl.txn_num,dbtbl_txn.txn_num,4);
            nReturnCode=DbsTblTxn(DBS_SELECT3,&dbtbl_txn_cl);
            if(nReturnCode&&nReturnCode!=DBS_ROWMORE)
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sqlcode=[%d].",nReturnCode);
                DbsTblTxn(DBS_CLOSE5,&dbtbl_txn);
                fclose(fp);
                return -1;
            }
            if(!memcmp(dbtbl_txn_cl.inst_date,ext_child_date,8))
            {
				if(memcmp(dbtbl_txn_cl.inst_time,hour_front,6)<0)
				{
					if(!memcmp(dbtbl_txn_cl.amt_trans,dbtbl_txn.amt_trans,12))
                		continue;
				}
            }
			else
			{
				if(!memcmp(dbtbl_txn_cl.amt_trans,dbtbl_txn.amt_trans,12))	
					continue;
			}
		}
        if(!memcmp(dbtbl_txn.txn_num,"5157",4))
        {
            memset(&dbtbl_txn_cl,0x00,sizeof(dbtbl_txn_cl));
            HtMemcpy(dbtbl_txn_cl.key_cancel,dbtbl_txn.key_cancel,32);
            HtMemcpy(dbtbl_txn_cl.txn_num,dbtbl_txn.txn_num,4);
            nReturnCode=DbsTblTxn(DBS_SELECT3,&dbtbl_txn_cl);
            if(nReturnCode)
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sqlcode=[%d][%s].",nReturnCode,dbtbl_txn_cl.key_cancel);
                DbsTblTxn(DBS_CLOSE5,&dbtbl_txn);
                fclose(fp);
                return -1;
            }
			if(!memcmp(dbtbl_txn_cl.inst_date,ext_child_date,8))
			{
				if(!memcmp(dbtbl_txn_cl.amt_trans,dbtbl_txn.amt_trans,12))
					continue;
			}
			else
			{
				if(!memcmp(dbtbl_txn_cl.inst_date,yesterday,8)&&memcmp(dbtbl_txn_cl.inst_time,hour_front,6)>0)
                {
                    if(!memcmp(dbtbl_txn_cl.amt_trans,dbtbl_txn.amt_trans,12))
                        continue;
                }	
			}
        }
		if(!memcmp(dbtbl_txn.txn_num,"3097",4)||!memcmp(dbtbl_txn.txn_num,"3107",4))
		{
			if(!memcmp(dbtbl_txn.revsal_flag,"1",1))
			{
				continue;
			}
			else
			{
            			memset(&dbtbl_txn_cl,0x00,sizeof(dbtbl_txn_cl));
            			HtMemcpy(dbtbl_txn_cl.key_cancel,dbtbl_txn.key_cancel,32);
            			HtMemcpy(dbtbl_txn_cl.txn_num,dbtbl_txn.txn_num,4);
            			nReturnCode=DbsTblTxn(DBS_SELECT3,&dbtbl_txn_cl);
            			if(nReturnCode)
            			{
                			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sqlcode=[%d].",nReturnCode);
                			DbsTblTxn(DBS_CLOSE5,&dbtbl_txn);
                			fclose(fp);
                			return -1;
            			}
            			if(!memcmp(dbtbl_txn_cl.inst_date,ext_child_date,8))
            			{
                			continue;
            			}
				else
				{
					if(!memcmp(dbtbl_txn_cl.inst_date,yesterday,8)&&memcmp(dbtbl_txn_cl.inst_time,hour_front,6)>0)
					continue;
				}
			}
		}
		
        i++;
		rtrim(dbtbl_txn.authr_id_r);
        memset(txn_num,0,sizeof(txn_num));
        if(!memcmp(dbtbl_txn.txn_num,"1097",4)||!memcmp(dbtbl_txn.txn_num,"1107",4)||!memcmp(dbtbl_txn.txn_num,"5167",4))
        {
			if(!memcmp(dbtbl_txn.txn_num,"1107",4))
			{
				if(strlen(dbtbl_txn.authr_id_r)==0)
				{
					HtSprintf(dbtbl_txn.authr_id_resp,"T%05d",i);
				}
				else
				{
					HtMemcpy(dbtbl_txn.authr_id_resp,dbtbl_txn.authr_id_r,6);
				}
			}
			if(!memcmp(dbtbl_txn.txn_num,"1097",4)||!memcmp(dbtbl_txn.txn_num,"5167",4))
			{
				if(strlen(dbtbl_txn.authr_id_resp)==0)
                {
                    HtSprintf(dbtbl_txn.authr_id_resp,"T%05d",i);
                }
			}
        	HtMemcpy(txn_num,"1005",4);
        }
        else
        {
			if(!memcmp(dbtbl_txn.txn_num,"3097",4))
			{
				if(strlen(dbtbl_txn.authr_id_resp)==0)
            	{
                	HtSprintf(dbtbl_txn.authr_id_resp,"T%05d",i);
            	}   
			}
			else
			{
            	if(strlen(dbtbl_txn.authr_id_r)==0)
            	{
                	HtSprintf(dbtbl_txn.authr_id_resp,"T%05d",i);
            	}
            	else
            	{
                	HtMemcpy(dbtbl_txn.authr_id_resp,dbtbl_txn.authr_id_r,6);
            	}
			}
			
			if(!memcmp(dbtbl_txn.txn_num,"3097",4)||!memcmp(dbtbl_txn.txn_num,"3107",4))
			{
        		HtMemcpy(txn_num,"1025",4);
			}
			else
			{
        		HtMemcpy(txn_num,"1006",4);
			}
        }

		memset(&tbl_mchnt_inf,0x00,sizeof(tbl_mchnt_inf));
        HtMemcpy(tbl_mchnt_inf.MCHNT_CD,dbtbl_txn.card_accp_id,15);
        nReturnCode=XTblMchntInf(DBS_SELECT,&tbl_mchnt_inf);
        if(nReturnCode)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select tbl_inf_mchnt_inf error[%d][%s]",nReturnCode,dbtbl_txn.card_accp_id);
        	DbsTblTxn(DBS_CLOSE5,&dbtbl_txn);
        	fclose(fp);
        	return -1;
		}
		rtrim(tbl_mchnt_inf.MCHNT_NM);
		memset(dbtbl_txn.card_accp_id,0,15);
		HtMemcpy(dbtbl_txn.card_accp_id,dbtbl_txn.acq_swresved+40,15);
		memset(amt_tmp,0,sizeof(amt_tmp));
		amt_trans=atof(dbtbl_txn.amt_trans);
		sprintf(amt_tmp,"%13.2f",amt_trans/100);
		memset(amt_str,0,sizeof(amt_str));
		sprintf(amt_str,"%15.15s",amt_tmp);
		rtrim(dbtbl_txn.authr_id_resp);

		if(!memcmp(dbtbl_txn.revsal_flag,"1",1)&&!memcmp(txn_num,"1005",4))
		{
			memset(&dbtbl_txn_rvs,0x00,sizeof(dbtbl_txn_rvs));
			HtMemcpy(dbtbl_txn_rvs.key_revsal,dbtbl_txn.key_revsal,32);
			HtMemcpy(dbtbl_txn_rvs.inst_date,dbtbl_txn.inst_date,8);
			HtMemcpy(dbtbl_txn_rvs.txn_num,dbtbl_txn.txn_num,4);
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "key_revsal[%s],inst_date[%s],txn_num[%s]",dbtbl_txn_rvs.key_revsal,dbtbl_txn_rvs.inst_date,dbtbl_txn_rvs.txn_num);
			nReturnCode=DbsTblTxn(DBS_SELECT2,&dbtbl_txn_rvs);
			if(!nReturnCode)
			{
				HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "resp_code[%s]",dbtbl_txn_rvs.resp_code);
				if(!memcmp(dbtbl_txn_rvs.resp_code,"00",2)||!memcmp(dbtbl_txn_rvs.resp_code,"A2",2)||!memcmp(dbtbl_txn_rvs.resp_code,"A4",2) \
					||!memcmp(dbtbl_txn_rvs.resp_code,"A5",2)||!memcmp(dbtbl_txn_rvs.resp_code,"A6",2)) 
				{
					i--;
					continue;
				}
				else
				{
			fprintf(fp,"%-2.2s%010d%-4.4s%-11.11s%-19.19s%-4.4s%-19.19s%-8.8s%-4.4s%-3.3s%15.15s%-12.12s%-6.6s%-40.40s%-4.4s%-20.20s%-4.4s%-3.3s%-6.6s%-11.11s%-23.23s%-50.50s%-50.50s%-2.2s", \
			"AS",i,dbtbl_txn.card_accp_id,dbtbl_txn.card_accp_id+4,dbtbl_txn.pan,"0000"," ",dbtbl_txn.inst_date,txn_num,"156",amt_str,"ACQ SYSTEM  ",dbtbl_txn.authr_id_resp,tbl_mchnt_inf.MCHNT_NM,tbl_mchnt_inf.MCHNT_TP, \
			dbtbl_txn.mchnt_type," "," "," "," ",dbtbl_txn.retrivl_ref," ",tail,sret);
					i++;
					fprintf(fp,"%-2.2s%010d%-4.4s%-11.11s%-19.19s%-4.4s%-19.19s%-8.8s%-4.4s%-3.3s%15.15s%-12.12s%-6.6s%-40.40s%-4.4s%-20.20s%-4.4s%-3.3s%-6.6s%-11.11s%-23.23s%-50.50s%-50.50s%-2.2s", \
					"AS",i,dbtbl_txn.card_accp_id,dbtbl_txn.card_accp_id+4,dbtbl_txn.pan,"0000"," ",dbtbl_txn_rvs.inst_date,"1025","156",amt_str,"ACQ SYSTEM  ",dbtbl_txn.authr_id_resp,tbl_mchnt_inf.MCHNT_NM,tbl_mchnt_inf.MCHNT_TP, \
					dbtbl_txn.mchnt_type," "," "," "," ",dbtbl_txn.retrivl_ref," ",tail,sret);
				}
			}
			else
			{
				HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "���ҳ彻��ʧ��[%d]key_rsvl[%s]",nReturnCode,dbtbl_txn.key_revsal);
				DbsTblTxn(DBS_CLOSE5,&dbtbl_txn);
				fclose(fp);
				return -1;
			}
			
		}
		else
		{
			fprintf(fp,"%-2.2s%010d%-4.4s%-11.11s%-19.19s%-4.4s%-19.19s%-8.8s%-4.4s%-3.3s%15.15s%-12.12s%-6.6s%-40.40s%-4.4s%-20.20s%-4.4s%-3.3s%-6.6s%-11.11s%-23.23s%-50.50s%-50.50s%-2.2s", \
			"AS",i,dbtbl_txn.card_accp_id,dbtbl_txn.card_accp_id+4,dbtbl_txn.pan,"0000"," ",dbtbl_txn.inst_date,txn_num,"156",amt_str,"ACQ SYSTEM  ",dbtbl_txn.authr_id_resp,tbl_mchnt_inf.MCHNT_NM,tbl_mchnt_inf.MCHNT_TP, \
			dbtbl_txn.mchnt_type," "," "," "," ",dbtbl_txn.retrivl_ref," ",tail,sret);
		}
lEndTime = times( &tTMS); 
HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,"cancel use [%ld] ticks.", lEndTime - lBeginTime);
    }
    DbsTblTxn(DBS_CLOSE5,&dbtbl_txn);
    
    HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "����Ԥ��Ȩ�������ǵ��յ���ˮ");
	memset(&dbtbl_txn,0x00,sizeof(dbtbl_txn));
    HtMemcpy(dbtbl_txn.inst_date,yesterday,8);
    HtMemcpy(dbtbl_txn.host_date,ext_child_date,8);
    HtMemcpy(dbtbl_txn.misc_1,hour_front,6);
    HtMemcpy(dbtbl_txn.misc_1+6,hour_later,6);
    nReturnCode=DbsTblTxn(DBS_CURSOR3,&dbtbl_txn);
	nReturnCode=DbsTblTxn(DBS_OPEN3,&dbtbl_txn);
	if(nReturnCode)
	{
    	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "OPEN sqlcode=[%d].", nReturnCode);
    	fclose(fp);
    	return -1;
	}
    while(1)
    { 
		memset(&dbtbl_txn,0x00,sizeof(dbtbl_txn));
        nReturnCode=DbsTblTxn(DBS_FETCH3,&dbtbl_txn);   
        if( nReturnCode &&nReturnCode != DBS_FETCHNULL )
        {
            if(nReturnCode==DBS_NOTFOUND)
            {
				if(i!=0)
				{
            		fprintf(fp,"%-2.2s%010d%-4.4s%-11.11s%-19.19s%-4.4s%-19.19s%-8.8s%-4.4s%-3.3s%15.15s%-12.12s%-6.6s%-40.40s%-4.4s%-20.20s%-4.4s%-3.3s%-6.6s%-11.11s%-23.23s%-50.50s%-50.50s%-2.2s", \
			"AS",i," "," ","ZZZZZZZZZZZZZZZZZZZ"," "," "," "," "," ","+0000000000.00"," "," "," "," ", \
			" "," "," "," "," "," "," ",tail,sret);
				}
                break;
            }
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sqlcode=[%d].", nReturnCode);
            DbsTblTxn(DBS_CLOSE2,&dbtbl_txn);
			return -1;
        }
        i++;
        memset(&tbl_mchnt_inf,0x00,sizeof(tbl_mchnt_inf));
        HtMemcpy(tbl_mchnt_inf.MCHNT_CD,dbtbl_txn.card_accp_id,15);
        nReturnCode=XTblMchntInf(DBS_SELECT,&tbl_mchnt_inf);
        if(nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select tbl_inf_mchnt_inf error[%d][%s]",nReturnCode,dbtbl_txn.card_accp_id);
            DbsTblTxn(DBS_CLOSE2,&dbtbl_txn);
            fclose(fp);
            return -1;
        }
        rtrim(tbl_mchnt_inf.MCHNT_NM);
		memset(dbtbl_txn.card_accp_id,0,15);
		HtMemcpy(dbtbl_txn.card_accp_id,dbtbl_txn.acq_swresved+40,15);
		rtrim(dbtbl_txn.authr_id_r);
        memset(txn_num,0,sizeof(txn_num));
		if(!memcmp(dbtbl_txn.txn_num,"3017",4))
		{
			if(strlen(dbtbl_txn.authr_id_resp)==0)
            {
                HtSprintf(dbtbl_txn.authr_id_resp,"T%05d",i);
            }
		}
		memset(amt_tmp,0,sizeof(amt_tmp));
		amt_trans=atof(dbtbl_txn.amt_trans);
		sprintf(amt_tmp,"%13.2f",amt_trans/100);
		memset(amt_str,0,sizeof(amt_str));
		sprintf(amt_str,"%15.15s",amt_tmp);
		rtrim(dbtbl_txn.authr_id_resp);

		fprintf(fp,"%-2.2s%010d%-4.4s%-11.11s%-19.19s%-4.4s%-19.19s%-8.8s%-4.4s%-3.3s%15.15s%-12.12s%-6.6s%-40.40s%-4.4s%-20.20s%-4.4s%-3.3s%-6.6s%-11.11s%-23.23s%-50.50s%-50.50s%-2.2s", \
					"AS",i,dbtbl_txn.card_accp_id,dbtbl_txn.card_accp_id+4,dbtbl_txn.pan,"0000"," ",dbtbl_txn.misc_flag,"9700","156",amt_str,"ACQ SYSTEM  ",dbtbl_txn.authr_id_resp,tbl_mchnt_inf.MCHNT_NM,tbl_mchnt_inf.MCHNT_TP, \
					dbtbl_txn.mchnt_type," "," "," "," ",dbtbl_txn.retrivl_ref," ",tail,sret);
    }
    DbsTblTxn(DBS_CLOSE3,&dbtbl_txn);
    fclose(fp);
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file success");
    return 0;
}
