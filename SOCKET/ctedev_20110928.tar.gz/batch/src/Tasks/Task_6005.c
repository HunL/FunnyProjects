/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_2602.pc                                                */
/* DESCRIPTIONS: load cup bdt file											 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23                                                                */
/*****************************************************************************/

#include "batch.h"
#include "tbl_opr.h"

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;

char cup_brh_id[8 + 1];
char inter_inst_id[6+1];
static int nModifyPosAerra(char *sType, char *sDate, stFileDef *pstFile);

/* get all existing filenames */
static int nGetAllFiles(char *sPath, int nPattern, Tbl_txn_file_ptn_Def astTxnFilePtn[],
                 int *pnFileCount, stFileDef  *pstTmpFile, char *sDate, char *sCupBrhId)
{
    char    *pstr;
    int     i, j, k;
    char    sPatternName[FILE_NAME_LEN_MAX+1];
    int     nReturnCode;
    glob_t  globbuf;

    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "nPattern[%d]", nPattern);
    for( k=0; k< (*pnFileCount); k++) pstTmpFile ++;

    for (i = 0; i < nPattern; i++)
    {
        /* replace YYYYMMDD with date */
        pstr = strstr (astTxnFilePtn[i].pattern_val, "YYYY");
        if (pstr) HtMemcpy (pstr, sDate, 4);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "YY");
        if (pstr) HtMemcpy (pstr, sDate+2, 2);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "MM");
        if (pstr) HtMemcpy (pstr, sDate+4, 2);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "DD");
        if (pstr) HtMemcpy (pstr, sDate+6, 2);

        /* get file name compatible with pattern */
        HtSprintf (sPatternName, "%s/%s", sPath, astTxnFilePtn[i].pattern_val);
        CommonRTrim (sPatternName);
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "search for pattern %s.", sPatternName);
        nReturnCode = glob (sPatternName, GLOB_NOSORT, NULL, &globbuf);
        if (nReturnCode && nReturnCode != GLOB_NOMATCH)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "glob error, %d.", nReturnCode);
            globfree (&globbuf);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "find %d matched files.", globbuf.gl_pathc);

        /* save file name */
        for (j = 0; j < globbuf.gl_pathc; j++)
        {
            HtStrcpy (pstTmpFile->sCompKey, astTxnFilePtn[i].comp_key);
            if (strlen (globbuf.gl_pathv[j]) < FILE_NAME_LEN_MAX)
            {
                HtStrcpy (pstTmpFile->sFileName, globbuf.gl_pathv[j]);
                HtMemcpy (pstTmpFile->sInterInstId, sCupBrhId, 6);
            }
            else
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file name too long.");
                globfree (&globbuf);
                return -1;
            }
            pstTmpFile ++;
            *pnFileCount = *pnFileCount + 1;
            if (*pnFileCount >= FILE_COUNT_MAX)
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "too many matched files.");
                globfree (&globbuf);
                return -1;
            }
        }
        globfree (&globbuf);
        
    }
    return 0;
}

/*****************************************************************************/
/* FUNC:   int nGetFileName (char *sType, char *sDate, int *pnFileCount,     */
/*                           stFileDef *pstFileDef)                          */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP, RCUP, ERR,RERR ,LOGO            */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/* OUTPUT: pnFileCount: ��ˮ�ļ�����                                         */
/*         stFileDef: ��ˮ�ļ���Ϣ                                           */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���ĳ����ˮ�ļ����ļ���                                          */
/*****************************************************************************/
static int nGetFileName (char *sType, char *sDate, int *pnFileCount, stFileDef *pstFile)
{

    char    sPath[FILE_NAME_LEN_MAX+1];
    char    sTmpPath[FILE_NAME_LEN_MAX+1];
    int     nReturnCode = 0;
    int     nPattern;

    Tbl_txn_file_ptn_Def    astTxnFilePtn[PATTERN_COUNT_MAX];
    stFileDef               *pstTmpFile;

    *pnFileCount = 0;
    pstTmpFile 	 = pstFile;

    memset(cup_brh_id,0x00,sizeof(cup_brh_id));
    nReturnCode = DbsTblcst_brh_cup_inf(DBS_CURSOR, ext_inter_brh_code, cup_brh_id);
    if (nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DECLARE cursor ERROR! sqlcode[%d].", nReturnCode);
        return -1;
    }


        DbsTblcst_brh_cup_inf(DBS_OPEN, ext_inter_brh_code,cup_brh_id);
	while(1)
	{
           nReturnCode = DbsTblcst_brh_cup_inf(DBS_FETCH, ext_inter_brh_code,cup_brh_id);
        if(nReturnCode)
            break;

        memset( &astTxnFilePtn, 0, sizeof(Tbl_txn_file_ptn_Def)*PATTERN_COUNT_MAX);
        nPattern = 0;
		/* get file path */
		memset (sPath, 0, sizeof (sPath));
		HtSprintf(sPath, "%s/%8.8s/%s/CUP/%s", getenv("BATCH_FILE_PATH"), sDate, getenv("CUP_ID"), cup_brh_id);
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sPath %s ", sPath);
		HtStrcpy(astTxnFilePtn[0].pattern_val,"INDYYMMDD*AERRN");
		memset (sTmpPath, 0, sizeof(sTmpPath));
		HtMemcpy (sTmpPath, sPath, sizeof(sPath));
		HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTmpPath[%s]", sTmpPath);            

		nReturnCode = nGetAllFiles(sTmpPath, 1, astTxnFilePtn, pnFileCount, pstTmpFile, sDate, ext_inter_brh_code);
		if(nReturnCode != 0)
		{
			return nReturnCode;
		}
	}

        DbsTblcst_brh_cup_inf(DBS_CLOSE, ext_inter_brh_code,cup_brh_id);
    return 0;
}


/*****************************************************************************/
/* FUNC:   int Total_6001()                                                  */
/* INPUT:  ��                                                                */
/* OUTPUT: nFileCount: ��ˮ�ļ�����                                          */
/* RETURN: nFileCount: �ɹ�, -1: ʧ��                                        */
/* DESC:   ���Ҫ�����������ˮ�ļ��ĸ���                                    */
/*****************************************************************************/
int Total_6005()
{
    return 1;
}

/*****************************************************************************/
/* FUNC:   int Task_6001(int nBeginOffset, int nEndOffset)                   */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   װ������LOGO����                                                */
/*****************************************************************************/
int Task_6005 ( int nBeginOffset, int nEndOffset )
{
    int     	i;
    int     	nReturnCode;
    char    	sDate[DATE_LEN + 1];              /*����*/
    char    	sType[8];                         /*������ˮ�ļ�����--bdt*/
    int     	nFileCount;                       /*Ҫ��õ�����bdt��ˮ�ļ�����*/
    stFileDef   stFile[FILE_COUNT_MAX];       /*һ�������ļ���Ϣ�Ľṹ������*/

    memset(sType,0,sizeof(sType));

    /*�������*/
    HtStrcpy(sDate,dbtbl_date_inf.stoday);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Task_6001:sDate=%s\n",sDate);

    /*�����ˮ�ļ������������Ϣ*/
    memset( (char *)&stFile, 0, sizeof(stFile));
    nReturnCode = nGetFileName (sType, sDate, &nFileCount, stFile);
    if (nReturnCode)
    {
          HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nGetFileName for %s on %s error, %d.", sType, sDate, nReturnCode);
          return -1;
    }
      HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nGetFileName for %s success, find %d files.", sType, nFileCount);

    /*װ���ļ������ݿ����*/
    for (i = nBeginOffset - 1; i < nEndOffset; i++)
    {
        nReturnCode = nModifyPosAerra (sType, sDate, &stFile[i]);
        if (nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nModifyPosAcom for %s error, %d.", stFile[i].sFileName, nReturnCode);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nModifyPosAcom for %s success.", stFile[i].sFileName);
    }

    return 0;
}

/*****************************************************************************/
/* FUNC:   int nModifyPosAerra (char *sType, char *sDate,                   */
/*                               stFileDef *pstFile)                         */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP_BDT,CUP_TDB,RCUP,ERR,RERR,LOGO   */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/*         pstFile: ��ˮ�ļ���Ϣ                                             */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ĳ����ˮ�ļ�������װ�ص����ݿ���                                */
/*****************************************************************************/
static int nModifyPosAerra (char *sType, char *sDate, stFileDef *pstFile)
{
    int   i;
    char    sTxnNum[5];
    char	file_name[FILE_NAME_LEN_MAX+1];
    char	afile_name[FILE_NAME_LEN_MAX+1];
    char	afile_bak[FILE_NAME_LEN_MAX+1];
    char    sFileRecord[RECORD_LEN_MAX+1];
    char    sDbRecord[RECORD_LEN_MAX+1];
	tbl_file_trans_def dbTblfiletrans;
	struct stat stat_buf;
    char    mchnt_feeb[9+1];
	char	cmd[1024];
	tbl_err_misn_tmp_def  dberrmission;
    tbl_inf_mchnt_inf_def dbmchntinf;
	tbl_txn_convert_def   dbconvert;
	stFileDef   Afile[FILE_COUNT_MAX];
    Tbl_txn_file_ptn_Def    astTxnFilePtn_tmp[PATTERN_COUNT_MAX];
    char    sPath1[FILE_NAME_LEN_MAX+1];
    char    sTmpPath1[FILE_NAME_LEN_MAX+1];
	char	str_tmp[20];
    char    *ap;
	int     AfileCount;
    int 	nReturnCode;
    int 	nRecordLen;
    FILE    *fp;
    FILE    *fp1;
    char	*p;
    int     nFlag;
	long    file_size;
    i  			= 0;
    nRecordLen  = 0;

    memset(afile_name,0x00,sizeof(afile_name));
    p=strrchr(pstFile->sFileName,'/');
    memcpy(afile_name,pstFile->sFileName,p-(pstFile->sFileName));
    strcat(afile_name,"/");
    strcat(afile_name,"POSMD");
    nReturnCode = CheckDir( afile_name );
    if(nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Create directory error: [%s].", file_name );
    }
	
        memset (sPath1, 0, sizeof (sPath1));
        memcpy(sPath1,pstFile->sFileName,p-(pstFile->sFileName));
        HtStrcpy(astTxnFilePtn_tmp[0].pattern_val,"INDYYMMDD*AERRA");
        memset (sTmpPath1, 0, sizeof(sTmpPath1));
        HtMemcpy (sTmpPath1, sPath1, sizeof(sPath1));
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTmpPath[%s]", sTmpPath1);
        nReturnCode = nGetAllFiles(sTmpPath1, 1, astTxnFilePtn_tmp, &AfileCount, Afile, dbtbl_date_inf.stoday, ext_inter_brh_code);
        if(nReturnCode != 0)
        {
            return nReturnCode;
        } 
    ap=strrchr(Afile[0].sFileName,'/');
    sprintf(afile_name,"%s%s",afile_name,ap);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"afile directory [%s].", afile_name );
	memset(file_name,0x00,sizeof(file_name));
	memset(afile_bak,0,sizeof(afile_bak));
	sprintf(afile_bak,"%s.bak.union",afile_name);
	sprintf(file_name,"%s",Afile[0].sFileName);

	fp1 = fopen (afile_name, "wb+");
    if (!fp1)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", afile_name,errno);
        return -1;
    }
    fp = fopen (file_name, "r");
    if (!fp)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", file_name, errno);
        return -1;
    }
    while (1)
    {
        memset(sFileRecord	, 0, sizeof(sFileRecord));
        if (fgets (sFileRecord, RECORD_LEN_MAX, fp) == NULL)
        {
            break;
        }
		nRecordLen=fwrite(sFileRecord,strlen(sFileRecord),1,fp1);   
		if(nRecordLen<0)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "write to file error[%d]",errno);
			fclose (fp1);
    		fclose (fp);
			return -1;
		}
	}
	fflush(fp1);
	fclose(fp);
	
	fp = fopen (pstFile->sFileName, "r");
    if (!fp)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", pstFile->sFileName, errno);
        fclose (fp1);
        return -1;
    }
    /* get file record */
    while (1)
    {
        memset(sFileRecord	, 0, sizeof(sFileRecord));
        memset(mchnt_feeb, 0, sizeof(mchnt_feeb));
        if (fgets (sFileRecord, RECORD_LEN_MAX, fp) == NULL)
        {
            break;
        }
		if(!memcmp(sFileRecord,"E74",3)&&!memcmp(sFileRecord+4,"0306",4))
		{
			memset(&dbmchntinf,0x00,sizeof(dbmchntinf));
			HtMemcpy(dbmchntinf.MCHNT_CD,sFileRecord+355,15);
			nReturnCode=XTblMchntInf(DBS_SELECT,&dbmchntinf);
			if(nReturnCode)
			{
				HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select mchnt error[%d]",nReturnCode);
				fclose (fp1);
				fclose (fp);
				return -1;
			}
		}
		else
		{
			if(memcmp(sFileRecord+4,"0306",4)|| memcmp(sFileRecord+407,"03",2))
			{
				continue;
			}
		}
		memset(&dberrmission,0x00,sizeof(dberrmission));
		HtMemcpy(dberrmission.date_settlmt,dbtbl_date_inf.stoday,8);	
		HtMemcpy(dberrmission.cup_ssn,sFileRecord+28,6);	
		HtMemcpy(dberrmission.trans_date_time,sFileRecord+35,10);	
		dberrmission.err_flag=0;	
		HtMemcpy(dberrmission.b_t_flag,"0",1);	
		nReturnCode=DbsErrMisn(DBS_SELECT,&dberrmission);
		if(nReturnCode)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select tbl_err_mission error[%d]",nReturnCode);
			fclose (fp1);
			fclose (fp);
			return -1;
		}
		if(dberrmission.fee_cdhr>0.001)
		{
			memset(str_tmp,0,sizeof(str_tmp));
			HtSprintf(str_tmp,"%012d",0);
			HtMemcpy(sFileRecord+166,str_tmp,12);
			memset(str_tmp,0,sizeof(str_tmp));
			HtSprintf(str_tmp,"%012.0f",dberrmission.fee_cdhr*100);
			HtMemcpy(sFileRecord+179,str_tmp,12);
			HtSprintf(mchnt_feeb,"C%08.0f",dberrmission.fee_cdhr*100);
			
		}	
		else if (dberrmission.fee_cdhr<-0.001)
		{
            memset(str_tmp,0,sizeof(str_tmp));
            HtSprintf(str_tmp,"%012d",0);
            HtMemcpy(sFileRecord+179,str_tmp,12);
            memset(str_tmp,0,sizeof(str_tmp));
            HtSprintf(str_tmp,"%012.0f",-dberrmission.fee_cdhr*100);
            HtMemcpy(sFileRecord+166,str_tmp,12);
			HtSprintf(mchnt_feeb,"D%08.0f",-dberrmission.fee_cdhr*100);
		}
		else
		{
			HtMemcpy(sFileRecord+166,"000000000000",12);
			HtMemcpy(sFileRecord+179,"000000000000",12);
			HtMemcpy(mchnt_feeb," 00000000",9);
		}
		sFileRecord[strlen(sFileRecord)-2]='\0';
		
		
		memset(&dbconvert,0x00,sizeof(dbconvert));	
		HtMemcpy(dbconvert.inner_txn,dberrmission.gc_txn_num,4);
		nReturnCode=SbsTxnConvert(DBS_SELECT1,&dbconvert);
		if(nReturnCode==DBS_NOTFOUND)
		{
			HtMemcpy(dbconvert.front_txn,"UNK",3);
		}
		else if(nReturnCode)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select tbl_txn_convert error[%d]",nReturnCode);
            fclose (fp1);
            fclose (fp);
			return -1;
		}
        memset(sDbRecord , 0, sizeof(sDbRecord));
		HtSprintf(sDbRecord,"%s %-3.3s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-11.11s %-9.9s %-9.9s %-9.9s %-9.9s %-200.200s\r\n", \
		sFileRecord,dbconvert.front_txn,mchnt_feeb,dberrmission.acq_inst_id_code," 00000000","           "," 00000000","           "," 00000000","           ", \
		" 00000000","           "," 00000000","           "," 00000000","           "," 00000000","           "," 00000000","           "," 00000000", \
		"           "," 00000000"," 00000000"," 00000000"," 00000000"," ");	
		nRecordLen=fputs(sDbRecord,fp1);   
		if(nRecordLen<0)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "write to file error");
			fclose (fp1);
    		fclose (fp);
			return -1;
		}
    }
    fclose (fp1);
    fclose (fp);

    memset(&stat_buf,0x00,sizeof(stat_buf));
    if(stat(afile_name,&stat_buf)==-1)
    {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "����stat error[%s][%d]",file_name,errno);
            return -1;
    }
    file_size=stat_buf.st_size;
    memset(&dbTblfiletrans,0,sizeof(dbTblfiletrans));
    p=strrchr(afile_name,'/');
    strcpy(dbTblfiletrans.inter_brh_code,"03060000");
    strcpy(dbTblfiletrans.sa_file_name,p+1);
    strcpy(dbTblfiletrans.sa_stlm_inst_id,"03060000");
    strcpy(dbTblfiletrans.sa_file_flg,"R");
    strcpy(dbTblfiletrans.sa_compress_flg,"N");
    strcpy(dbTblfiletrans.sa_file_stat,"3");
    strcpy(dbTblfiletrans.sa_trace_log,"����POS�����޸�");
    HtSprintf(dbTblfiletrans.sa_file_length,"%010ld",file_size);
    nReturnCode=lQTblFileTransOpr(NTblUpdate1,&dbTblfiletrans);
    if(nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_file_name[%s]",dbTblfiletrans.sa_file_name);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_file_flg[%s]",dbTblfiletrans.sa_file_flg);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_stlm_inst_id[%s]",dbTblfiletrans.sa_stlm_inst_id);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "update tbl_file_trans error[%d]",glSysError);
        return -1;
    }
	memset(cmd,0,sizeof(cmd));
	HtSprintf(cmd,"mv %s %s",file_name,afile_bak);
	system(cmd);
    memset(cmd,0,sizeof(cmd));
    HtSprintf(cmd,"cp %s %s",afile_name,file_name);
    system(cmd);
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file sum success");
    return 0;
}
