/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_0401.pc                                                */
/* DESCRIPTIONS: load FE success txn                                         */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"

extern	char	gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[10+1];
extern  int     ext_inter_brh_sta;
static int getValueByDelim(char *sSrc, char *sDest, char *sDelim );

int Total_0401()
{
	char	sFileRecord[RECORD_LEN_MAX];
	int		nTotalNum = 0;
	char	today[8+1];
	char	file_name[200];
	char    *pstr;

	FILE *fp;

	memset( today, 0, 9);
	HtMemcpy( today, dbtbl_date_inf.stoday, 8);

	memset( file_name, 0, 200);
    HtStrcpy(file_name, getenv("BATCH_FILE_PATH"));
    HtStrcat(file_name, "/");
    HtStrcat(file_name, "YYYYMMDD");
    HtStrcat(file_name, "/");
    HtStrcat(file_name, getenv("CUP_ID"));
    HtStrcat(file_name, "/");
    HtStrcat(file_name, FE_FILE_PATH);
    pstr = strstr (file_name, "YYYYMMDD");
    if (pstr)
        HtMemcpy (pstr, today, 8);

    HtStrcat(file_name, "/");
    HtStrcat(file_name, FE_SUCC_FILE_NAME);
	pstr = strstr (file_name, "YYYYMMDD");
	if (pstr)
		HtMemcpy (pstr, today, 8);
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file_name=[%s].", file_name);

	/* ȡ�ļ����� */
	fp = fopen (file_name, "r");
	if (!fp)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", file_name);
		return -1;
	}

	while( fgets( sFileRecord, RECORD_LEN_MAX, fp) != NULL)
	{
		if( strlen( sFileRecord) == 0)
			continue;
		nTotalNum++;
	}
	fclose (fp);

	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nTotalNum =[%d].", nTotalNum);
	return nTotalNum;

}

int Task_0401 ( int nBeginOffset, int nEndOffset)
{
	int		nReturnCode;
	int	i = 1;
	char	today[8+1];
	char    *pstr;
	char	file_name[200];
	char    sDelim[] = "&*";
	char	sFileRecord[RECORD_LEN_MAX];
	FILE    *fp;
	Tbl_gc_txn_Def dbtbl_gc_txn;
	int 	lOffset = 0;

	memset( today, 0, 9);
	HtMemcpy( today, dbtbl_date_inf.stoday, 8);

	memset( file_name, 0, 200);
	HtStrcpy(file_name, getenv("BATCH_FILE_PATH"));
	HtStrcat(file_name, "/");
	HtStrcat(file_name, "YYYYMMDD");
	HtStrcat(file_name, "/");
	HtStrcat(file_name, getenv("CUP_ID"));
	HtStrcat(file_name, "/");
	HtStrcat(file_name, FE_FILE_PATH);
	pstr = strstr (file_name, "YYYYMMDD");
	if (pstr)
		HtMemcpy (pstr, today, 8);

	HtStrcat(file_name, "/");
	HtStrcat(file_name, FE_SUCC_FILE_NAME);
	pstr = strstr (file_name, "YYYYMMDD");
	if (pstr)
		HtMemcpy (pstr, today, 8);
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file_name=[%s].", file_name);

	fp = fopen (file_name, "r");
	if (!fp)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", file_name);
		return -1;
	}

	HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nBeginOffset=[%d],nEndOffset=[%d].", nBeginOffset,nEndOffset);

	/* ���ļ���ʼ�� */
	while( i < nBeginOffset && fgets( sFileRecord, RECORD_LEN_MAX, fp) != NULL)
	{
		if( strlen( sFileRecord) == 0)
			continue;
		i++;
	}
	HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "start point = [%d].", i);

	while( i < nEndOffset + 1)
	{
		memset(&dbtbl_gc_txn, 0, sizeof(dbtbl_gc_txn));
		if( fgets(sFileRecord, RECORD_LEN_MAX, fp) == NULL)
			break;
		getValueByDelim(sFileRecord, dbtbl_gc_txn.inter_brh_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.inst_date,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.cup_ssn,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.inst_time,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.msg_src_id,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.txn_num,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.trans_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.trans_type,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.trans_state,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.revsal_flag,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.revsal_ssn,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.cancel_flag,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.cancel_ssn,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.host_date,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.host_ssn,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.term_ssn,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.key_rsp,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.key_revsal,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.key_cancel,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.header_buf,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.msg_type,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.pan_len,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.pan,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.processing_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.amt_trans,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.amt_settlmt,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.amt_cdhldr_bil,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.trans_date_time,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.conv_rate_stlm,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.conv_rate_cdhldr,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.sys_seq_num,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.time_local_trans,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.date_local_trans,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.date_settlmt,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.date_conv,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.mchnt_type,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.acq_cntry_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.pos_entry_mode,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.pos_cond_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.pos_pin_cap_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.amt_trans_fee,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.acq_inst_id_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.fwd_inst_id_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.retrivl_ref,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.authr_id_resp,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.resp_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.card_accp_term_id,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.card_accp_id,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.card_accp_name,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.currcy_code_trans,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.currcy_code_stlm,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.currcy_code_chldr,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.fld_reserved_len,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.fld_reserved,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.orig_data_elemts,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.replacement_amts,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.rcvg_code_len,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.rcvg_code,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.acct_id1_len,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.acct_id1,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.acct_id2_len,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.acct_id2,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.host_trans_fee1,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.host_trans_fee2,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.tlr_num,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.open_inst,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.stlm_inst,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.batch_flag,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.batch_date,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.msq_type,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.amt_return,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.authr_id_r,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.misc_flag,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.misc_1,sDelim);
		getValueByDelim(sFileRecord, dbtbl_gc_txn.misc_2,sDelim);

		nReturnCode = DbsGcTxn( DBS_INSERT_SUCC, &dbtbl_gc_txn, i);
		if ( nReturnCode )
		{
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.inter_brh_code   =[%s].", dbtbl_gc_txn.inter_brh_code   );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.inst_date        =[%s].", dbtbl_gc_txn.inst_date        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.sys_seq_num      =[%s].", dbtbl_gc_txn.sys_seq_num      );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.inst_time        =[%s].", dbtbl_gc_txn.inst_time        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.msg_src_id       =[%s].", dbtbl_gc_txn.msg_src_id       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.txn_num          =[%s].", dbtbl_gc_txn.txn_num          );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.trans_code       =[%s].", dbtbl_gc_txn.trans_code       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.trans_type       =[%s].", dbtbl_gc_txn.trans_type       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.trans_state      =[%s].", dbtbl_gc_txn.trans_state      );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.revsal_flag      =[%s].", dbtbl_gc_txn.revsal_flag      );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.revsal_ssn       =[%s].", dbtbl_gc_txn.revsal_ssn       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.cancel_flag      =[%s].", dbtbl_gc_txn.cancel_flag      );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.cancel_ssn       =[%s].", dbtbl_gc_txn.cancel_ssn       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.host_date        =[%s].", dbtbl_gc_txn.host_date        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.host_ssn         =[%s].", dbtbl_gc_txn.host_ssn         );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.term_ssn         =[%s].", dbtbl_gc_txn.term_ssn         );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.key_rsp          =[%s].", dbtbl_gc_txn.key_rsp          );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.key_revsal       =[%s].", dbtbl_gc_txn.key_revsal       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.key_cancel       =[%s].", dbtbl_gc_txn.key_cancel       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.header_buf       =[%s].", dbtbl_gc_txn.header_buf       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.msg_type         =[%s].", dbtbl_gc_txn.msg_type         );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.pan_len          =[%s].", dbtbl_gc_txn.pan_len          );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.pan              =[%s].", dbtbl_gc_txn.pan              );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.processing_code  =[%s].", dbtbl_gc_txn.processing_code  );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.amt_trans        =[%s].", dbtbl_gc_txn.amt_trans        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.amt_settlmt      =[%s].", dbtbl_gc_txn.amt_settlmt      );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.amt_cdhldr_bil   =[%s].", dbtbl_gc_txn.amt_cdhldr_bil   );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.trans_date_time  =[%s].", dbtbl_gc_txn.trans_date_time  );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.conv_rate_stlm   =[%s].", dbtbl_gc_txn.conv_rate_stlm   );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.conv_rate_cdhldr =[%s].", dbtbl_gc_txn.conv_rate_cdhldr );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.cup_ssn          =[%s].", dbtbl_gc_txn.cup_ssn          );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.time_local_trans =[%s].", dbtbl_gc_txn.time_local_trans );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.date_local_trans =[%s].", dbtbl_gc_txn.date_local_trans );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.date_settlmt     =[%s].", dbtbl_gc_txn.date_settlmt     );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.date_conv        =[%s].", dbtbl_gc_txn.date_conv        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.mchnt_type       =[%s].", dbtbl_gc_txn.mchnt_type       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.acq_cntry_code   =[%s].", dbtbl_gc_txn.acq_cntry_code   );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.pos_entry_mode   =[%s].", dbtbl_gc_txn.pos_entry_mode   );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.pos_cond_code    =[%s].", dbtbl_gc_txn.pos_cond_code    );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.pos_pin_cap_code =[%s].", dbtbl_gc_txn.pos_pin_cap_code );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.amt_trans_fee    =[%s].", dbtbl_gc_txn.amt_trans_fee    );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.acq_inst_id_code =[%s].", dbtbl_gc_txn.acq_inst_id_code );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.fwd_inst_id_code =[%s].", dbtbl_gc_txn.fwd_inst_id_code );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.retrivl_ref      =[%s].", dbtbl_gc_txn.retrivl_ref      );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.authr_id_resp    =[%s].", dbtbl_gc_txn.authr_id_resp    );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.resp_code        =[%s].", dbtbl_gc_txn.resp_code        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.card_accp_term_id=[%s].", dbtbl_gc_txn.card_accp_term_id);
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.card_accp_id     =[%s].", dbtbl_gc_txn.card_accp_id     );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.card_accp_name   =[%s].", dbtbl_gc_txn.card_accp_name   );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.currcy_code_trans=[%s].", dbtbl_gc_txn.currcy_code_trans);
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.currcy_code_stlm =[%s].", dbtbl_gc_txn.currcy_code_stlm );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.currcy_code_chldr=[%s].", dbtbl_gc_txn.currcy_code_chldr);
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.fld_reserved_len =[%s].", dbtbl_gc_txn.fld_reserved_len );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.fld_reserved     =[%s].", dbtbl_gc_txn.fld_reserved     );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.orig_data_elemts =[%s].", dbtbl_gc_txn.orig_data_elemts );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.replacement_amts =[%s].", dbtbl_gc_txn.replacement_amts );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.rcvg_code_len    =[%s].", dbtbl_gc_txn.rcvg_code_len    );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.rcvg_code        =[%s].", dbtbl_gc_txn.rcvg_code        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.acct_id1_len     =[%s].", dbtbl_gc_txn.acct_id1_len     );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.acct_id1         =[%s].", dbtbl_gc_txn.acct_id1         );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.acct_id2_len     =[%s].", dbtbl_gc_txn.acct_id2_len     );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.acct_id2         =[%s].", dbtbl_gc_txn.acct_id2         );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.host_trans_fee1  =[%s].", dbtbl_gc_txn.host_trans_fee1  );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.host_trans_fee2  =[%s].", dbtbl_gc_txn.host_trans_fee2  );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.tlr_num          =[%s].", dbtbl_gc_txn.tlr_num          );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.open_inst        =[%s].", dbtbl_gc_txn.open_inst        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.stlm_inst        =[%s].", dbtbl_gc_txn.stlm_inst        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.batch_flag       =[%s].", dbtbl_gc_txn.batch_flag       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.batch_date       =[%s].", dbtbl_gc_txn.batch_date       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.msq_type         =[%s].", dbtbl_gc_txn.msq_type         );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.amt_return       =[%s].", dbtbl_gc_txn.amt_return       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.authr_id_r       =[%s].", dbtbl_gc_txn.authr_id_r       );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.misc_flag        =[%s].", dbtbl_gc_txn.misc_flag        );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.misc_1           =[%s].", dbtbl_gc_txn.misc_1           );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "dbtbl_gc_txn.misc_2           =[%s].", dbtbl_gc_txn.misc_2           );
			HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsCupTxn DBS_INSERT error, nReturnCode=[%d], i=[%d].", nReturnCode, i);
			return i;
		}
		else
		{
			i++;
		}
	}
	HtLog( gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsCupTxn DBS_INSERT succ, i=[%d].",  i);

	return 0;
}

/***** 
 * �������� getValueByDelim
 * �������� ���ݷָ�����Դ�ַ���sSrc�е�һ���ָ���sDelim֮ǰ���ַ������Ƶ�Ŀ�Ĵ�sDest��
 *          ����Դ�ַ���sSrc��ָ���ƶ�����һ���ָ���֮��
 *��������  sSrc  Դ�ַ���
 *          sDest Ŀ���ַ���
 *          sDelim �ָ���
 *��������  0 - �ɹ�
 *          1 - Դ�ַ����ѵ���β��
 *          2 - ����
 ***/       
static int getValueByDelim(char *sSrc, char *sDest, char *sDelim )
{
	char *sEnd;

	if( *sSrc == '\0')
	{
		return 1;
	}

	sEnd = strstr(sSrc, sDelim);
	if(sEnd == NULL)
	{   
		return 2;
	}

	HtMemcpy(sDest, sSrc, sEnd-sSrc);
	HtStrcpy(sSrc, sEnd + (int)strlen(sDelim));
	return 0;
}
