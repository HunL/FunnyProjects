/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_1001.pc                                                */
/* DESCRIPTIONS: ����������ǰ�öཻ�׵����                                  */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-27  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"

extern	char	gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[INTER_BRH_CODE_LEN + 1];

static bth_gc_txn_def dbbth_gc_txn;
static bth_gc_txn_def_ind dbbth_gc_txn_ind;
static tbl_dat_bank_flow_tmp_def dbbth_bank_flow;

static bth_txn_dtl_def dbbth_txn_dtl;

static char today[8+1];
static char area_code[4+1];
static char ins_id_cd[13+1];
static char inter_ins_id_cd[10+1];
static char sSTLM_OK[1+1];
static char sSTLM_ERROR[1+1];
static char sSTLM_CUP_HAVE[1+1];
static char sSTLM_HOST_HAVE[1+1];
static char sSTLM_CUP_REVSAL[1+1];

static void init_bth_txn_dtl()
{
	memset(dbbth_txn_dtl.inter_brh_code, 0, sizeof(dbbth_txn_dtl.inter_brh_code));
	memset(dbbth_txn_dtl.manage_inst, 0, sizeof(dbbth_txn_dtl.manage_inst));
	memset(dbbth_txn_dtl.trans_date_time, 0, sizeof(dbbth_txn_dtl.trans_date_time));
	memset(dbbth_txn_dtl.cup_ssn, 0, sizeof(dbbth_txn_dtl.cup_ssn));
	memset(dbbth_txn_dtl.acq_inst_id_code, 0, sizeof(dbbth_txn_dtl.acq_inst_id_code));
	memset(dbbth_txn_dtl.fwd_inst_id_code, 0, sizeof(dbbth_txn_dtl.fwd_inst_id_code));
	memset(dbbth_txn_dtl.term_ssn, 0, sizeof(dbbth_txn_dtl.term_ssn));
	memset(dbbth_txn_dtl.inst_date, 0, sizeof(dbbth_txn_dtl.inst_date));
	memset(dbbth_txn_dtl.inst_time, 0, sizeof(dbbth_txn_dtl.inst_time));
	memset(dbbth_txn_dtl.host_ssn, 0, sizeof(dbbth_txn_dtl.host_ssn));
	memset(dbbth_txn_dtl.host_date, 0, sizeof(dbbth_txn_dtl.host_date));
	memset(dbbth_txn_dtl.date_settlmt, 0, sizeof(dbbth_txn_dtl.date_settlmt));
	memset(dbbth_txn_dtl.gc_txn_num, 0, sizeof(dbbth_txn_dtl.gc_txn_num));
	memset(dbbth_txn_dtl.txn_num, 0, sizeof(dbbth_txn_dtl.txn_num));
	memset(dbbth_txn_dtl.msg_type, 0, sizeof(dbbth_txn_dtl.msg_type));
	memset(dbbth_txn_dtl.processing_code, 0, sizeof(dbbth_txn_dtl.processing_code));
	memset(dbbth_txn_dtl.mchnt_type, 0, sizeof(dbbth_txn_dtl.mchnt_type));
	memset(dbbth_txn_dtl.pos_cond_code, 0, sizeof(dbbth_txn_dtl.pos_cond_code));
	memset(dbbth_txn_dtl.channel_num, 0, sizeof(dbbth_txn_dtl.channel_num));
	memset(dbbth_txn_dtl.orig_cup_ssn, 0, sizeof(dbbth_txn_dtl.orig_cup_ssn));
	memset(dbbth_txn_dtl.orig_date_time, 0, sizeof(dbbth_txn_dtl.orig_date_time));
	memset(dbbth_txn_dtl.orig_date_settlmt, 0, sizeof(dbbth_txn_dtl.orig_date_settlmt));
	memset(dbbth_txn_dtl.orig_term_ssn, 0, sizeof(dbbth_txn_dtl.orig_term_ssn));
	memset(dbbth_txn_dtl.orig_host_date, 0, sizeof(dbbth_txn_dtl.orig_host_date));
	memset(dbbth_txn_dtl.orig_host_ssn, 0, sizeof(dbbth_txn_dtl.orig_host_ssn));
	memset(dbbth_txn_dtl.pan, 0, sizeof(dbbth_txn_dtl.pan));

	dbbth_txn_dtl.amt_trans = 0;
	memset(dbbth_txn_dtl.authr_id_resp, 0, sizeof(dbbth_txn_dtl.authr_id_resp));
	memset(dbbth_txn_dtl.resp_code, 0, sizeof(dbbth_txn_dtl.resp_code));
	memset(dbbth_txn_dtl.host_recode, 0, sizeof(dbbth_txn_dtl.host_recode));
	dbbth_txn_dtl.fee_credit = 0;
	dbbth_txn_dtl.fee_debit = 0;
	dbbth_txn_dtl.fee_cdhr = 0;
	dbbth_txn_dtl.fee_inst = 0;
	dbbth_txn_dtl.fee_logo = 0;
	memset(dbbth_txn_dtl.pos_entry_mode, 0, sizeof(dbbth_txn_dtl.pos_entry_mode));
	memset(dbbth_txn_dtl.card_accp_term_id, 0, sizeof(dbbth_txn_dtl.card_accp_term_id));
	memset(dbbth_txn_dtl.card_accp_id, 0, sizeof(dbbth_txn_dtl.card_accp_id));
	memset(dbbth_txn_dtl.card_accp_addr, 0, sizeof(dbbth_txn_dtl.card_accp_addr));
	memset(dbbth_txn_dtl.retrivl_ref, 0, sizeof(dbbth_txn_dtl.retrivl_ref));
	memset(dbbth_txn_dtl.rcvg_code, 0, sizeof(dbbth_txn_dtl.rcvg_code));
	memset(dbbth_txn_dtl.issuer_code, 0, sizeof(dbbth_txn_dtl.issuer_code));
	memset(dbbth_txn_dtl.deal_flg, 0, sizeof(dbbth_txn_dtl.deal_flg));
	memset(dbbth_txn_dtl.tran_flg, 0, sizeof(dbbth_txn_dtl.tran_flg));
	memset(dbbth_txn_dtl.code_xfer_o, 0, sizeof(dbbth_txn_dtl.code_xfer_o));
	memset(dbbth_txn_dtl.pan_xfer_o, 0, sizeof(dbbth_txn_dtl.pan_xfer_o));
	memset(dbbth_txn_dtl.code_xfer_i, 0, sizeof(dbbth_txn_dtl.code_xfer_i));
	memset(dbbth_txn_dtl.pan_xfer_i, 0, sizeof(dbbth_txn_dtl.pan_xfer_i));
	memset(dbbth_txn_dtl.currcy_code_trans, 0, sizeof(dbbth_txn_dtl.currcy_code_trans));
	memset(dbbth_txn_dtl.currcy_code_stlm, 0, sizeof(dbbth_txn_dtl.currcy_code_stlm));
	dbbth_txn_dtl.amt_settlmt = 0;
	memset(dbbth_txn_dtl.conv_rate_stlm, 0, sizeof(dbbth_txn_dtl.conv_rate_stlm));
	memset(dbbth_txn_dtl.date_conv, 0, sizeof(dbbth_txn_dtl.date_conv));
	memset(dbbth_txn_dtl.flag_domestic, 0, sizeof(dbbth_txn_dtl.flag_domestic));
	memset(dbbth_txn_dtl.flag_city, 0, sizeof(dbbth_txn_dtl.flag_city));
	memset(dbbth_txn_dtl.area_code, 0, sizeof(dbbth_txn_dtl.area_code));
	memset(dbbth_txn_dtl.inst_no, 0, sizeof(dbbth_txn_dtl.inst_no));
	memset(dbbth_txn_dtl.bank_flag, 0, sizeof(dbbth_txn_dtl.bank_flag));
	memset(dbbth_txn_dtl.flag_result, 0, sizeof(dbbth_txn_dtl.flag_result));
    memset(dbbth_txn_dtl.acqu_ins_id_cd, 0, sizeof(dbbth_txn_dtl.acqu_ins_id_cd));
    memset(dbbth_txn_dtl.issuer_ins_id_cd, 0, sizeof(dbbth_txn_dtl.issuer_ins_id_cd));
}

static int gc_in_dtl_err_gc(int flag_result)
{
	char tmp[10];
    char sCupBrhId[7];
	int nReturn;

    bth_dtl_err_gc_tmp_def dbbth_dtl_err_gc_tmp;

    memset(sCupBrhId, 0, sizeof(sCupBrhId));
	init_bth_txn_dtl();

	dbbth_txn_dtl.amt_trans = atof(dbbth_gc_txn.amt_trans)/100;
	memset(tmp, 0, sizeof(tmp));
	HtMemcpy(tmp, &dbbth_gc_txn.amt_trans_fee[1], 9);
	dbbth_txn_dtl.fee_cdhr  = atof(tmp)/100;
	dbbth_txn_dtl.amt_settlmt= atof(dbbth_gc_txn.amt_trans)/100;
	HtMemcpy(dbbth_txn_dtl.orig_cup_ssn, dbbth_gc_txn.orig_data_elemts+4,6);
	HtMemcpy(dbbth_txn_dtl.orig_date_time, dbbth_gc_txn.orig_data_elemts+10,10);

	/**ͬ����ر�־**/
	HtMemcpy(dbbth_txn_dtl.flag_city, "0", 1);

	/**������������**/
	HtMemcpy(dbbth_txn_dtl.area_code, dbbth_gc_txn.acq_inst_id_code+4,4 );

	HtMemcpy(dbbth_txn_dtl.inst_no, dbbth_gc_txn.acq_inst_id_code+4,4 );
	HtSprintf(dbbth_txn_dtl.flag_result, "%d", flag_result );
    /* �����е��ڲ������� */
    memset(area_code, 0x00, sizeof(area_code));
    memset(ins_id_cd, 0x00, sizeof(ins_id_cd));
    HtMemcpy(area_code, &dbbth_gc_txn.misc_1[117], 4);
    HtSprintf(dbbth_txn_dtl.issuer_ins_id_cd , "04%s", area_code);


	memset(area_code, 0, 5);
    HtMemcpy(area_code, dbbth_gc_txn.acq_inst_id_code + 4, 4);

    HtMemcpy(sCupBrhId, dbbth_txn_dtl.acqu_ins_id_cd, 6);

    memset( (char*)&dbbth_dtl_err_gc_tmp, 0, sizeof(bth_dtl_err_gc_tmp_def));

    HtMemcpy(dbbth_dtl_err_gc_tmp.inter_brh_code       , dbbth_gc_txn.inter_brh_code    , 10      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.manage_inst          , "0094"                         , 4      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.trans_date_time      , dbbth_gc_txn.trans_date_time   , 10     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.cup_ssn              , dbbth_gc_txn.cup_ssn           , 6      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.acq_inst_id_code     , dbbth_gc_txn.acq_inst_id_code  , 11     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.fwd_inst_id_code     , dbbth_gc_txn.fwd_inst_id_code  , 11     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.term_ssn             , dbbth_gc_txn.term_ssn          , 12     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.inst_date            , dbbth_gc_txn.inst_date         , 8      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.inst_time            , dbbth_gc_txn.inst_time         , 6      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.host_ssn             , dbbth_gc_txn.host_ssn          , 12     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.host_date            , dbbth_gc_txn.host_date         , 8      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.date_settlmt         , dbbth_gc_txn.date_settlmt_8    , 8      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.gc_txn_num           , dbbth_gc_txn.txn_num           , 4      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.txn_num              , dbbth_gc_txn.trans_code        , 4      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.msg_type             , dbbth_gc_txn.msg_type          , 4      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.processing_code      , dbbth_gc_txn.processing_code   , 6      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.mchnt_type           , dbbth_gc_txn.mchnt_type        , 4      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.pos_cond_code        , dbbth_gc_txn.pos_cond_code     , 2      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.channel_num          , dbbth_gc_txn.channel_num       , 2      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.orig_data_ssn        , dbbth_txn_dtl.orig_cup_ssn     , 6      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.orig_data_time       , dbbth_txn_dtl.orig_date_time   , 10     );
    memset(dbbth_dtl_err_gc_tmp.orig_date_settlmt    , 0                             , 8      );
    memset(dbbth_dtl_err_gc_tmp.orig_term_ssn        , 0                             , 12     );
    memset(dbbth_dtl_err_gc_tmp.orig_host_date       , 0                             , 8      );
    memset(dbbth_dtl_err_gc_tmp.orig_host_ssn        , 0                             , 12     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.pan                  , dbbth_gc_txn.pan               , 19     );
    dbbth_dtl_err_gc_tmp.amt_trans = dbbth_txn_dtl.amt_trans;
    HtMemcpy(dbbth_dtl_err_gc_tmp.authr_id_resp        , dbbth_gc_txn.authr_id_resp     , 6      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.resp_code            , dbbth_gc_txn.resp_code         , 2      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.host_recode          , "00"                           , 7      );
    dbbth_dtl_err_gc_tmp.fee_credit = 0;
    dbbth_dtl_err_gc_tmp.fee_debit = 0;
    dbbth_dtl_err_gc_tmp.fee_cdhr = dbbth_txn_dtl.fee_cdhr;
    dbbth_dtl_err_gc_tmp.fee_inst = dbbth_txn_dtl.fee_inst;
    dbbth_dtl_err_gc_tmp.fee_logo = 0;
    HtMemcpy(dbbth_dtl_err_gc_tmp.pos_entry_mode       , dbbth_gc_txn.pos_entry_mode    , 3      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.card_accp_term_id    , dbbth_gc_txn.card_accp_term_id , 8      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.card_accp_id         , dbbth_gc_txn.card_accp_id      , 15     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.card_accp_addr       , dbbth_gc_txn.card_accp_name    , 40     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.retrivl_ref          , dbbth_gc_txn.retrivl_ref       , 12     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.rcvg_code            , dbbth_gc_txn.rcvg_code         , 11     );
    memset(dbbth_dtl_err_gc_tmp.issuer_code          , 0                             , 11     );
    memset(dbbth_dtl_err_gc_tmp.deal_flg             , 0                             , 2      );
    memset(dbbth_dtl_err_gc_tmp.tran_flg             , 0                             , 1      );
    memset(dbbth_dtl_err_gc_tmp.code_xfer_o          , 0                             , 11     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.pan_xfer_o           , dbbth_gc_txn.acct_id1          , 28     );
    memset(dbbth_dtl_err_gc_tmp.code_xfer_i          , 0                             , 11     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.pan_xfer_i           , dbbth_gc_txn.acct_id2          , 28     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.currcy_code_trans    , dbbth_gc_txn.currcy_code_trans , 3      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.currcy_code_stlm     , dbbth_gc_txn.currcy_code_stlm  , 3      );
    dbbth_dtl_err_gc_tmp.amt_settlmt = dbbth_txn_dtl.amt_trans;
    HtMemcpy(dbbth_dtl_err_gc_tmp.conv_rate_stlm       , dbbth_gc_txn.conv_rate_stlm    , 8      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.date_conv            , dbbth_gc_txn.date_conv         , 8      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.flag_domestic        , dbbth_gc_txn.flag_domestic     , 1      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.flag_city            , dbbth_txn_dtl.flag_city        , 1      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.area_code            , dbbth_txn_dtl.area_code        , 4      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.inst_no              , dbbth_txn_dtl.inst_no          , 11     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.bank_flag            , dbbth_txn_dtl.bank_flag        , 6      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.flag_result          , dbbth_txn_dtl.flag_result      , 1      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.fwd_rcv_in           , "1"                            , 1      );
    HtMemcpy(dbbth_dtl_err_gc_tmp.acqu_ins_id_cd       , dbbth_txn_dtl.acqu_ins_id_cd   , 10     );
    memset(dbbth_dtl_err_gc_tmp.issuer_ins_id_cd     , 0                             , 10     );
    HtMemcpy(dbbth_dtl_err_gc_tmp.cup_ins_id           , sCupBrhId                      , 6      );
    dbbth_dtl_err_gc_tmp.seq_num = 0;

    nReturn = DbsBTH_DTL_ERR_GC_TMP_UNI(DBS_INSERT, &dbbth_dtl_err_gc_tmp);
	if ( nReturn)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Insert into bth_dtl_err_gc_tmp error2 [%d].",nReturn);
		return -1;
	}
	return 0;
}
static int gc_in_dtl_bdt(int flag_result)
{
	char tmp[10];
    char sCupBrhId[7];
	int nReturn;

    bth_dtl_bdt_tmp_def dbbth_dtl_bdt_tmp;

    memset(sCupBrhId, 0, sizeof(sCupBrhId));
	init_bth_txn_dtl();

	dbbth_txn_dtl.amt_trans = atof(dbbth_gc_txn.amt_trans)/100;
	memset(tmp, 0, sizeof(tmp));
	HtMemcpy(tmp, &dbbth_gc_txn.amt_trans_fee[1], 9);
	dbbth_txn_dtl.fee_cdhr  = atof(tmp)/100;
	dbbth_txn_dtl.amt_settlmt= atof(dbbth_gc_txn.amt_trans)/100;
	HtMemcpy(dbbth_txn_dtl.orig_cup_ssn, dbbth_gc_txn.orig_data_elemts+4,6);
	HtMemcpy(dbbth_txn_dtl.orig_date_time, dbbth_gc_txn.orig_data_elemts+10,10);

	/**ͬ����ر�־**/
	HtMemcpy(dbbth_txn_dtl.flag_city, "0", 1);

	/**������������**/
	HtMemcpy(dbbth_txn_dtl.area_code, dbbth_gc_txn.acq_inst_id_code+4,4 );

	HtMemcpy(dbbth_txn_dtl.inst_no, dbbth_gc_txn.acq_inst_id_code+4,4 );
	HtSprintf(dbbth_txn_dtl.flag_result, "%d", flag_result );
    /* �����е��ڲ������� */
    memset(area_code, 0x00, sizeof(area_code));
    memset(ins_id_cd, 0x00, sizeof(ins_id_cd));
    HtMemcpy(area_code, &dbbth_gc_txn.misc_1[117], 4);
    HtSprintf(dbbth_txn_dtl.issuer_ins_id_cd , "04%s", area_code);

	memset(area_code, 0, 5);
    HtMemcpy(area_code, dbbth_gc_txn.acq_inst_id_code + 4, 4);

    HtMemcpy(sCupBrhId, dbbth_txn_dtl.acqu_ins_id_cd, 6);

    memset( (char*)&dbbth_dtl_bdt_tmp, 0, sizeof(bth_dtl_bdt_tmp_def));

    HtMemcpy( dbbth_dtl_bdt_tmp.inter_brh_code     , dbbth_gc_txn.inter_brh_code    , 10       );
    HtMemcpy( dbbth_dtl_bdt_tmp.manage_inst        , "0094"                         , 4       );
    HtMemcpy( dbbth_dtl_bdt_tmp.trans_date_time    , dbbth_gc_txn.trans_date_time   , 10      );
    HtMemcpy( dbbth_dtl_bdt_tmp.cup_ssn            , dbbth_gc_txn.cup_ssn           , 6       );
    HtMemcpy( dbbth_dtl_bdt_tmp.acq_inst_id_code   , dbbth_gc_txn.acq_inst_id_code  , 11      );
    HtMemcpy( dbbth_dtl_bdt_tmp.fwd_inst_id_code   , dbbth_gc_txn.fwd_inst_id_code  , 11      );
    HtMemcpy( dbbth_dtl_bdt_tmp.term_ssn           , dbbth_gc_txn.term_ssn          , 12      );
    HtMemcpy( dbbth_dtl_bdt_tmp.inst_date          , dbbth_gc_txn.inst_date         , 8       );
    HtMemcpy( dbbth_dtl_bdt_tmp.inst_time          , dbbth_gc_txn.inst_time         , 6       );
    HtMemcpy( dbbth_dtl_bdt_tmp.host_ssn           , dbbth_gc_txn.host_ssn          , 12      );
    HtMemcpy( dbbth_dtl_bdt_tmp.host_date          , dbbth_gc_txn.host_date         , 8       );
    HtMemcpy( dbbth_dtl_bdt_tmp.date_settlmt       , dbbth_gc_txn.date_settlmt_8    , 8       );
    HtMemcpy( dbbth_dtl_bdt_tmp.gc_txn_num         , dbbth_gc_txn.txn_num           , 4       );
    HtMemcpy( dbbth_dtl_bdt_tmp.txn_num            , dbbth_gc_txn.trans_code        , 4       );
    HtMemcpy( dbbth_dtl_bdt_tmp.msg_type           , dbbth_gc_txn.msg_type          , 4       );
    HtMemcpy( dbbth_dtl_bdt_tmp.processing_code    , dbbth_gc_txn.processing_code   , 6       );
    HtMemcpy( dbbth_dtl_bdt_tmp.mchnt_type         , dbbth_gc_txn.mchnt_type        , 4       );
    HtMemcpy( dbbth_dtl_bdt_tmp.pos_cond_code      , dbbth_gc_txn.pos_cond_code     , 2       );
    HtMemcpy( dbbth_dtl_bdt_tmp.channel_num        , dbbth_gc_txn.channel_num       , 2       );
    HtMemcpy( dbbth_dtl_bdt_tmp.orig_data_ssn      , dbbth_txn_dtl.orig_cup_ssn     , 6       );
    HtMemcpy( dbbth_dtl_bdt_tmp.orig_data_time     , dbbth_txn_dtl.orig_date_time   , 10      );
    memset( dbbth_dtl_bdt_tmp.orig_date_settlmt  , 0                             , 8       );
    memset( dbbth_dtl_bdt_tmp.orig_term_ssn      , 0                             , 12      );
    memset( dbbth_dtl_bdt_tmp.orig_host_date     , 0                             , 8       );
    memset( dbbth_dtl_bdt_tmp.orig_host_ssn      , 0                             , 12      );
    HtMemcpy( dbbth_dtl_bdt_tmp.pan                , dbbth_gc_txn.pan               , 19      );
    dbbth_dtl_bdt_tmp.amt_trans = dbbth_txn_dtl.amt_trans;
    HtMemcpy( dbbth_dtl_bdt_tmp.authr_id_resp      , dbbth_gc_txn.authr_id_resp     , 6       );
    HtMemcpy( dbbth_dtl_bdt_tmp.resp_code          , dbbth_gc_txn.resp_code         , 2       );
    HtMemcpy( dbbth_dtl_bdt_tmp.host_recode        , "00"                           , 7       );
    dbbth_dtl_bdt_tmp.fee_credit = 0;
    dbbth_dtl_bdt_tmp.fee_debit = 0;
    dbbth_dtl_bdt_tmp.fee_cdhr = dbbth_txn_dtl.fee_cdhr;
    dbbth_dtl_bdt_tmp.fee_inst = dbbth_txn_dtl.fee_inst;
    dbbth_dtl_bdt_tmp.fee_logo = 0;
    HtMemcpy( dbbth_dtl_bdt_tmp.pos_entry_mode     , dbbth_gc_txn.pos_entry_mode    , 3       );
    HtMemcpy( dbbth_dtl_bdt_tmp.card_accp_term_id  , dbbth_gc_txn.card_accp_term_id , 8       );
    HtMemcpy( dbbth_dtl_bdt_tmp.card_accp_id       , dbbth_gc_txn.card_accp_id      , 15      );
    HtMemcpy( dbbth_dtl_bdt_tmp.card_accp_addr     , dbbth_gc_txn.card_accp_name    , 40      );
    HtMemcpy( dbbth_dtl_bdt_tmp.retrivl_ref        , dbbth_gc_txn.retrivl_ref       , 12      );
    HtMemcpy( dbbth_dtl_bdt_tmp.rcvg_code          , dbbth_gc_txn.rcvg_code         , 11      );
    memset( dbbth_dtl_bdt_tmp.issuer_code        , 0                             , 11      );
    memset( dbbth_dtl_bdt_tmp.deal_flg           , 0                             , 2       );
    memset( dbbth_dtl_bdt_tmp.tran_flg           , 0                             , 1       );
    memset( dbbth_dtl_bdt_tmp.code_xfer_o        , 0                             , 11      );
    HtMemcpy( dbbth_dtl_bdt_tmp.pan_xfer_o         , dbbth_gc_txn.acct_id1          , 28      );
    memset( dbbth_dtl_bdt_tmp.code_xfer_i        , 0                             , 11      );
    HtMemcpy( dbbth_dtl_bdt_tmp.pan_xfer_i         , dbbth_gc_txn.acct_id2          , 28      );
    HtMemcpy( dbbth_dtl_bdt_tmp.currcy_code_trans  , dbbth_gc_txn.currcy_code_trans , 3       );
    HtMemcpy( dbbth_dtl_bdt_tmp.currcy_code_stlm   , dbbth_gc_txn.currcy_code_stlm  , 3       );
    dbbth_dtl_bdt_tmp.amt_settlmt = dbbth_txn_dtl.amt_trans;
    HtMemcpy( dbbth_dtl_bdt_tmp.conv_rate_stlm     , dbbth_gc_txn.conv_rate_stlm    , 8       );
    HtMemcpy( dbbth_dtl_bdt_tmp.date_conv          , dbbth_gc_txn.date_conv         , 8       );
    HtMemcpy( dbbth_dtl_bdt_tmp.flag_domestic      , dbbth_gc_txn.flag_domestic     , 1       );
    HtMemcpy( dbbth_dtl_bdt_tmp.flag_city          , dbbth_txn_dtl.flag_city        , 1       );
    HtMemcpy( dbbth_dtl_bdt_tmp.area_code          , dbbth_txn_dtl.area_code        , 4       );
    HtMemcpy( dbbth_dtl_bdt_tmp.inst_no            , dbbth_txn_dtl.inst_no          , 11      );
    HtMemcpy( dbbth_dtl_bdt_tmp.bank_flag          , dbbth_txn_dtl.bank_flag        , 6       );
    HtMemcpy( dbbth_dtl_bdt_tmp.flag_result        , dbbth_txn_dtl.flag_result      , 1       );
    HtMemcpy( dbbth_dtl_bdt_tmp.acqu_ins_id_cd     , dbbth_txn_dtl.acqu_ins_id_cd   , 10      );
    HtMemcpy( dbbth_dtl_bdt_tmp.cup_ins_id         , sCupBrhId                      , 6       );
    dbbth_dtl_bdt_tmp.seq_num = 0;
 
    nReturn = DbsBTH_DTL_BDT_TMP_UNI( DBS_INSERT, &dbbth_dtl_bdt_tmp);
	if (nReturn)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Insert into bth_dtl_tdb_tmp error2 [%d].",nReturn);
		return -1;
	}
	return 0;
}

static int in_dat_bank_flow( int sett_flag )
{
    int nReturnCode = 0;
	if(!memcmp(dbbth_gc_txn.txn_num,"1201",4))
	{
		return 0;
	}
    memset(&dbbth_bank_flow,0x00,sizeof(dbbth_bank_flow));
/*
    memset(&dbbth_bank_flow_orig,0x00,sizeof(dbbth_bank_flow_orig));
    memset(&dbbth_gc_txn_orig,0x00,sizeof(dbbth_gc_txn_orig));
    if(((memcmp(dbbth_gc_txn.txn_num,"5151",4))==0) && (sett_flag==1))
    {
        HtMemcpy(dbbth_bank_flow_orig.orig_key,dbbth_gc_txn.key_cancel,32);
        HtMemcpy(dbbth_bank_flow_orig.mchnt_cd,dbbth_gc_txn.card_accp_id,15);
        nReturnCode=DbsTBL_DAT_BANK_FLOW(DBS_SELECT1,&dbbth_bank_flow_orig);
        if(nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "settle_dt [%s]", dbbth_bank_flow_orig.settle_dt);
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "orig_key [%s]", dbbth_bank_flow_orig.pri_key);
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select from tbl_dat_bank_flow error [%d]",nReturnCode);
            HtMemcpy(dbbth_gc_txn_orig.misc_1,dbbth_gc_txn.orig_data_elemts+10,10);
            HtMemcpy(dbbth_gc_txn_orig.misc_1+10,dbbth_gc_txn.orig_data_elemts+4,6);
			HtMemcpy(dbbth_gc_txn_orig.txn_num,dbbth_gc_txn.txn_num,4);
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "txn_num[%s]", dbbth_gc_txn_orig.txn_num);
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "misc_1[%s]", dbbth_gc_txn_orig.msic_1);
            nReturnCode=DbsBthgctxnSucc(DBS_SELECT4,&dbbth_gc_txn_orig,0,0);
            if(nReturnCode)
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "retrivl_ref[%s]", dbbth_gc_txn_orig.retrivl_ref);
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select from bth_gc_txn_bdt error [%d]",nReturnCode);
                return -1;
            }
            HtMemcpy(dbbth_bank_flow.orig_pos_seq_num,dbbth_gc_txn_orig.cup_ssn,6);
            HtMemcpy(dbbth_bank_flow.auth_sum_amt,dbbth_gc_txn_orig.trans_date_time,10);
            sprintf(dbbth_bank_flow.orig_auth_ins,"%.0f",atof(dbbth_gc_txn_orig.amt_trans),12);
        }
        else
        {
            HtMemcpy(dbbth_bank_flow.orig_pos_seq_num,dbbth_bank_flow_orig.sys_tra_no,6);
            HtMemcpy(dbbth_bank_flow.auth_sum_amt,dbbth_bank_flow_orig.transmsn_dt_tm,10);
            memcpy(dbbth_bank_flow.orig_auth_ins,dbbth_bank_flow_orig.trans_at,12);
        }
    }
*/
    memcpy(dbbth_bank_flow.pri_key,  dbbth_gc_txn.key_cup, 42);
    memcpy(dbbth_bank_flow.orig_key, dbbth_gc_txn.key_cancel, 32);
	memcpy(dbbth_bank_flow.card_expired_date, "03", 2);
    HtMemcpy(dbbth_bank_flow.related_key,dbbth_gc_txn.orig_data_elemts+23,8);
    HtMemcpy(dbbth_bank_flow.related_key+11,dbbth_gc_txn.orig_data_elemts+34,8);
    HtMemcpy(dbbth_bank_flow.related_key+22,dbbth_gc_txn.orig_data_elemts+4,6);
    HtMemcpy(dbbth_bank_flow.related_key+28,dbbth_gc_txn.orig_data_elemts+10,10);
    HtMemcpy(dbbth_bank_flow.related_key+38,"0000",4);
    HtSprintf(dbbth_bank_flow.local_settle_in,"%d",sett_flag);
    memcpy(dbbth_bank_flow.settle_dt,dbbth_gc_txn.date_settlmt_8,8);
    memcpy(dbbth_bank_flow.iss_in,"T", 1);            /* e */
    memcpy(dbbth_bank_flow.msg_tp, dbbth_gc_txn.msg_type, 4);
    rtrim(dbbth_gc_txn.pan);
    memcpy(dbbth_bank_flow.pri_acct_no, dbbth_gc_txn.pan, 21);
    memcpy(dbbth_bank_flow.proc_cd, dbbth_gc_txn.processing_code, 6);
    rtrim(dbbth_gc_txn.amt_trans);
	memcpy(dbbth_bank_flow.trans_at, dbbth_gc_txn.amt_trans,12);
    memcpy(dbbth_bank_flow.sys_tra_no, dbbth_gc_txn.cup_ssn, 6);

    memcpy(dbbth_bank_flow.transmsn_dt_tm, dbbth_gc_txn.trans_date_time, 10);
    memcpy(dbbth_bank_flow.mchnt_tp, dbbth_gc_txn.mchnt_type, 4);
    memcpy(dbbth_bank_flow.pos_entry_md_cd, dbbth_gc_txn.pos_entry_mode, 2);
    memcpy(dbbth_bank_flow.card_seq_num, "   ", 3);
    memcpy(dbbth_bank_flow.pos_cond_cd, dbbth_gc_txn.pos_cond_code, 2);
    memcpy(dbbth_bank_flow.pos_pin_cap_cd, dbbth_gc_txn.pos_pin_cap_code, 2);
    memcpy(dbbth_bank_flow.acq_ins_id_cd, dbbth_gc_txn.acq_inst_id_code, 13);
    memcpy(dbbth_bank_flow.retri_ref_no,  dbbth_gc_txn.retrivl_ref, 12);
    memcpy(dbbth_bank_flow.auth_id_resp_cd, dbbth_gc_txn.authr_id_resp, 6);
    memcpy(dbbth_bank_flow.resp_cd, dbbth_gc_txn.resp_code, 2);
    memcpy(dbbth_bank_flow.term_id, dbbth_gc_txn.card_accp_term_id, 8);
    memcpy(dbbth_bank_flow.mchnt_cd, dbbth_gc_txn.card_accp_id, 15);
    memcpy(dbbth_bank_flow.rcv_ins_id_cd, dbbth_gc_txn.rcvg_code, 13);
    memcpy(dbbth_bank_flow.term_seq_num, "    ", 4);
    memcpy(dbbth_bank_flow.fee_amt, "0", 12);
    memcpy(dbbth_bank_flow.curr_cd, dbbth_gc_txn.currcy_code_trans, 3);
    memcpy(dbbth_bank_flow.acct_balance, "0", 12);
    memcpy(dbbth_bank_flow.msg_type_id, dbbth_gc_txn.fld_reserved, 2); /* #60.1 */
    memcpy(dbbth_bank_flow.batch_num, "000000", 6);
    memcpy(dbbth_bank_flow.orig_trans_batch, "000000", 6);
    memcpy(dbbth_bank_flow.orig_trans_date,  dbbth_gc_txn.orig_data_elemts+10, 4);
    memcpy(dbbth_bank_flow.oper_id_cd,       dbbth_gc_txn.tlr_num, 8);
    strcpy(dbbth_bank_flow.trans_chnl,       "03");


    nReturnCode=DbsBankFlow(DBS_INSERT,&dbbth_bank_flow);

    if(nReturnCode)
    {
        HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"insert into tbl_dat_bank_flow error sqlcode=[%d]",nReturnCode);
        return-1 ;
    }
    return 0 ;

}

int Total_1001()
{
    int nTotalNum=0 ;
    int nReturnCode=0;
    memset(&dbbth_gc_txn,0x00,sizeof(dbbth_gc_txn));
    /*
    EXEC SQL SELECT NVL(MAX(seq_num),0) INTO :nTotalNum FROM BTH_GC_TXN_SUCC;
	*/
    nReturnCode=DbsBthgctxnSucc(DBS_SELECT1,&dbbth_gc_txn,0,0);
    if(nReturnCode && nReturnCode != DBS_FETCHNULL)
    {
        HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"select from bth_cup_txn_bdt error, sqlcode=[%d].", nReturnCode);
        return -1 ;
    }
    nTotalNum=dbbth_gc_txn.seq_num;
    HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"nTotalNum =[%d].",nTotalNum);
    return nTotalNum;
}

int Task_1001( int nBeginOffset, int nEndOffset)
{
	int		nReturnCode=0;
	char	sFl_Flag_Pan[1+1],sFl_Flag_Amt[1+1];
	char	host_amt_trans[13];
	char	cup_amt_trans[13];
	int		iPanTag,iAmtTag;
	float 	m_host;
	float 	m_cup;

	memset(sSTLM_OK,0,sizeof(sSTLM_OK));
	memset(sSTLM_ERROR,0,sizeof(sSTLM_ERROR));
	memset(sSTLM_CUP_HAVE,0,sizeof(sSTLM_CUP_HAVE));
	memset(sSTLM_HOST_HAVE,0,sizeof(sSTLM_HOST_HAVE));
	memset(sSTLM_CUP_REVSAL,0,sizeof(sSTLM_CUP_REVSAL));

	HtSprintf(sSTLM_OK,"%d",STLM_OK);
	HtSprintf(sSTLM_ERROR,"%d",STLM_ERROR);
	HtSprintf(sSTLM_CUP_HAVE,"%d",STLM_CUP_HAVE);
	HtSprintf(sSTLM_HOST_HAVE,"%d",STLM_HOST_HAVE);
	HtSprintf(sSTLM_CUP_REVSAL,"%d",STLM_CUP_REVSAL);

	memset( today, 0, 9);
	HtMemcpy( today, dbtbl_date_inf.stoday, 8);

    memset(&dbbth_gc_txn,0x00,sizeof(dbbth_gc_txn));
    HtMemcpy(dbbth_gc_txn.inter_brh_code,ext_inter_brh_code,10);
    HtMemcpy(dbbth_gc_txn.flag_result,sSTLM_HOST_HAVE,1);
    HtMemcpy(dbbth_gc_txn.date_settlmt_8,today,8);

	DbsBthgctxnSucc(DBS_CURSOR1,&dbbth_gc_txn,nBeginOffset,nEndOffset);

	nReturnCode= DbsBthgctxnSucc(DBS_OPEN1,&dbbth_gc_txn,nBeginOffset,nEndOffset);
	if ( nReturnCode)
	{
		HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"open gc_txn_cursor error[%d]!",nReturnCode);
		return -1;
	}

	while(1)
	{
		memset(&dbbth_gc_txn, 0x00, sizeof(dbbth_gc_txn));
		nReturnCode=DbsBthgctxnSucc(DBS_FETCH1,&dbbth_gc_txn,nBeginOffset,nEndOffset);
		if( nReturnCode)
		{
			if(nReturnCode==DBS_NOTFOUND)
				break;
			HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"fetch error[%d]",nReturnCode);
			return -1;
		}
		HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"-------------key_cup------------[%s]!",dbbth_gc_txn.key_cup);
		
		nReturnCode=in_dat_bank_flow(0);
		if(nReturnCode)
		{
			HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"insert into dat_bank_flow_tmp error");
			return -1;
		}
/*del by sunyd@20110718********	
		if(!HtMemcpy(dbbth_gc_txn.txn_num, "1011",4) || !HtMemcpy(dbbth_gc_txn.txn_num, "3011", 4))
		{
			nReturnCode = gc_in_dtl_bdt(5 );
			if( nReturnCode)
				return dbbth_gc_txn.seq_num;
		}
		else
		{
**del by sunyd@20110718********/
			nReturnCode = gc_in_dtl_err_gc(4 );
			if( nReturnCode)
				return dbbth_gc_txn.seq_num;
            nReturnCode = gc_in_dtl_bdt(4 );
            if( nReturnCode)
                return dbbth_gc_txn.seq_num;
/*
		}

*/
	}
	DbsBthgctxnSucc(DBS_CLOSE1,&dbbth_gc_txn,nBeginOffset,nEndOffset);
	return 0;
}
