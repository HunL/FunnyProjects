/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_2602.pc                                                */
/* DESCRIPTIONS: load cup bdt file											 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23                                                                */
/*****************************************************************************/

#include "batch.h"

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;

char cup_brh_id[8 + 1];
static int nModifyPosSum(char *sType, char *sDate, stFileDef *pstFile);

/* get all existing filenames */
static int nGetAllFiles(char *sPath, int nPattern, Tbl_txn_file_ptn_Def astTxnFilePtn[],
                 int *pnFileCount, stFileDef  *pstTmpFile, char *sDate, char *sCupBrhId)
{
    char    *pstr;
    int     i, j, k;
    char    sPatternName[FILE_NAME_LEN_MAX+1];
    int     nReturnCode;
    glob_t  globbuf;

    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "nPattern[%d]", nPattern);
    for( k=0; k< (*pnFileCount); k++) pstTmpFile ++;

    for (i = 0; i < nPattern; i++)
    {
        /* replace YYYYMMDD with date */
        pstr = strstr (astTxnFilePtn[i].pattern_val, "YYYY");
        if (pstr) HtMemcpy (pstr, sDate, 4);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "YY");
        if (pstr) HtMemcpy (pstr, sDate+2, 2);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "MM");
        if (pstr) HtMemcpy (pstr, sDate+4, 2);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "DD");
        if (pstr) HtMemcpy (pstr, sDate+6, 2);

        /* get file name compatible with pattern */
        HtSprintf (sPatternName, "%s/%s", sPath, astTxnFilePtn[i].pattern_val);
        CommonRTrim (sPatternName);
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "search for pattern %s.", sPatternName);
        nReturnCode = glob (sPatternName, GLOB_NOSORT, NULL, &globbuf);
        if (nReturnCode && nReturnCode != GLOB_NOMATCH)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "glob error, %d.", nReturnCode);
            globfree (&globbuf);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "find %d matched files.", globbuf.gl_pathc);

        /* save file name */
        for (j = 0; j < globbuf.gl_pathc; j++)
        {
            HtStrcpy (pstTmpFile->sCompKey, astTxnFilePtn[i].comp_key);
            if (strlen (globbuf.gl_pathv[j]) < FILE_NAME_LEN_MAX)
            {
                HtStrcpy (pstTmpFile->sFileName, globbuf.gl_pathv[j]);
                HtMemcpy (pstTmpFile->sInterInstId, sCupBrhId, 6);
            }
            else
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file name too long.");
                globfree (&globbuf);
                return -1;
            }
            pstTmpFile ++;
            *pnFileCount = *pnFileCount + 1;
            if (*pnFileCount >= FILE_COUNT_MAX)
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "too many matched files.");
                globfree (&globbuf);
                return -1;
            }
        }
        globfree (&globbuf);
        
    }
    return 0;
}

/*****************************************************************************/
/* FUNC:   int nGetFileName (char *sType, char *sDate, int *pnFileCount,     */
/*                           stFileDef *pstFileDef)                          */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP, RCUP, ERR,RERR ,LOGO            */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/* OUTPUT: pnFileCount: ��ˮ�ļ�����                                         */
/*         stFileDef: ��ˮ�ļ���Ϣ                                           */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���ĳ����ˮ�ļ����ļ���                                          */
/*****************************************************************************/
static int nGetFileName (char *sType, char *sDate, int *pnFileCount, stFileDef *pstFile)
{

    char    sPath[FILE_NAME_LEN_MAX+1];
    char    sTmpPath[FILE_NAME_LEN_MAX+1];
    int     nReturnCode = 0;
    int     nPattern;

    Tbl_txn_file_ptn_Def    astTxnFilePtn[PATTERN_COUNT_MAX];
    stFileDef               *pstTmpFile;

    *pnFileCount = 0;
    pstTmpFile 	 = pstFile;

    memset(cup_brh_id,0x00,sizeof(cup_brh_id));
    nReturnCode = DbsTblcst_brh_cup_inf(DBS_CURSOR, ext_inter_brh_code, cup_brh_id);
    if (nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DECLARE cursor ERROR! sqlcode[%d].", nReturnCode);
        return -1;
    }


        DbsTblcst_brh_cup_inf(DBS_OPEN, ext_inter_brh_code,cup_brh_id);
	while(1)
	{
           nReturnCode = DbsTblcst_brh_cup_inf(DBS_FETCH, ext_inter_brh_code,cup_brh_id);
        if(nReturnCode)
            break;

        memset( &astTxnFilePtn, 0, sizeof(Tbl_txn_file_ptn_Def)*PATTERN_COUNT_MAX);
        nPattern = 0;
		/* get file path */
		memset (sPath, 0, sizeof (sPath));
		HtSprintf(sPath, "%s/%8.8s/%s/CUP/%s", getenv("BATCH_FILE_PATH"), sDate, getenv("CUP_ID"), cup_brh_id);
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sPath %s ", sPath);
		HtStrcpy(astTxnFilePtn[0].pattern_val,"INOYYMMDD*SUM");
		memset (sTmpPath, 0, sizeof(sTmpPath));
		HtMemcpy (sTmpPath, sPath, sizeof(sPath));
		HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTmpPath[%s]", sTmpPath);            

		nReturnCode = nGetAllFiles(sTmpPath, 1, astTxnFilePtn, pnFileCount, pstTmpFile, sDate, ext_inter_brh_code);
		if(nReturnCode != 0)
		{
			return nReturnCode;
		}
	}

        DbsTblcst_brh_cup_inf(DBS_CLOSE, ext_inter_brh_code,cup_brh_id);
    return 0;
}


/*****************************************************************************/
/* FUNC:   int Total_6001()                                                  */
/* INPUT:  ��                                                                */
/* OUTPUT: nFileCount: ��ˮ�ļ�����                                          */
/* RETURN: nFileCount: �ɹ�, -1: ʧ��                                        */
/* DESC:   ���Ҫ�����������ˮ�ļ��ĸ���                                    */
/*****************************************************************************/
int Total_6006()
{
    return 1;
}

/*****************************************************************************/
/* FUNC:   int Task_6001(int nBeginOffset, int nEndOffset)                   */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   װ������LOGO����                                                */
/*****************************************************************************/
int Task_6006 ( int nBeginOffset, int nEndOffset )
{
    int     	i;
    int     	nReturnCode;
    char    	sDate[DATE_LEN + 1];              /*����*/
    char    	sType[8];                         /*������ˮ�ļ�����--bdt*/
    int     	nFileCount;                       /*Ҫ��õ�����bdt��ˮ�ļ�����*/
    stFileDef   stFile[FILE_COUNT_MAX];       /*һ�������ļ���Ϣ�Ľṹ������*/

    memset(sType,0,sizeof(sType));

    /*�������*/
    HtStrcpy(sDate,dbtbl_date_inf.stoday);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Task_6001:sDate=%s\n",sDate);

    /*�����ˮ�ļ������������Ϣ*/
    memset( (char *)&stFile, 0, sizeof(stFile));
    nReturnCode = nGetFileName (sType, sDate, &nFileCount, stFile);
    if (nReturnCode)
    {
          HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nGetFileName for %s on %s error, %d.", sType, sDate, nReturnCode);
          return -1;
    }
      HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nGetFileName for %s success, find %d files.", sType, nFileCount);

    /*װ���ļ������ݿ����*/
    for (i = nBeginOffset - 1; i < nEndOffset; i++)
    {
        nReturnCode = nModifyPosSum (sType, sDate, &stFile[i]);
        if (nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nModifyPosAcom for %s error, %d.", stFile[i].sFileName, nReturnCode);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nModifyPosAcom for %s success.", stFile[i].sFileName);
    }

    return 0;
}

/*****************************************************************************/
/* FUNC:   int nModifyPosSum (char *sType, char *sDate,                   */
/*                               stFileDef *pstFile)                         */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP_BDT,CUP_TDB,RCUP,ERR,RERR,LOGO   */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/*         pstFile: ��ˮ�ļ���Ϣ                                             */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ĳ����ˮ�ļ�������װ�ص����ݿ���                                */
/*****************************************************************************/
static int nModifyPosSum (char *sType, char *sDate, stFileDef *pstFile)
{
    int   i;
    char    sTxnNum[5];
    char	file_name[FILE_NAME_LEN_MAX+1];
    char	afile_name[FILE_NAME_LEN_MAX+1];
    char	afile_bak[FILE_NAME_LEN_MAX+1];
    char    sFileRecord[RECORD_LEN_MAX+1];
    char    sDbRecord[RECORD_LEN_MAX+1];
    char    query_num[12+1];
	char	trans_feeb[12+1];
    char    amt_sum[16+1];
    char    str_tmp[40+1];
	char	str_recv[16+1];
	char	str_send[16+1];
	char	cmd[1024];
	bth_cup_txn_def dbbth_cup_txn;
	bth_cup_err_def dbbth_cup_err;
    int 	nReturnCode;
    int 	nRecordLen;
	int		trans_num;
	double  recv_amt;
	double  send_amt;
	double  amt_trans;
	double  exp_feeb;
	double  exh_fee;
	double 	rvl_feeb; 
	double  total_feeb;
	double  total_amt;
	double  exp_amt;
	double 	rvl_amt; 
	double  recv_exp;
	double  recv_cel;
	double  recv_ret;
	double  err_amt;
    FILE    *fp;
    FILE    *fp1;
    char	*p;
    int     nFlag;
    i  			= 1;
    nRecordLen  = 0;
	exh_fee=0;
	err_amt=0;
    memset(afile_name,0x00,sizeof(afile_name));
    p=strrchr(pstFile->sFileName,'/');
    memcpy(afile_name,pstFile->sFileName,p-(pstFile->sFileName));
    strcat(afile_name,"/");
    strcat(afile_name,"POSMD");
    nReturnCode = CheckDir( afile_name );
    if(nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Create directory error: [%s].", file_name );
    }
	
    sprintf(afile_name,"%s%s",afile_name,p);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"afile directory [%s].", afile_name );
	memset(file_name,0x00,sizeof(file_name));
	memset(afile_bak,0,sizeof(afile_bak));
	sprintf(afile_bak,"%s.bak.union",afile_name);
	sprintf(file_name,"%s",pstFile->sFileName);

	fp1 = fopen (afile_name, "wb+");
    if (!fp1)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", afile_name,errno);
        return -1;
    }
	fp = fopen (pstFile->sFileName, "r");
    if (!fp)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", pstFile->sFileName, errno);
        fclose (fp1);
        return -1;
    }
    /* get file record */
    while (1)
    {
        memset(sFileRecord	, 0, sizeof(sFileRecord));
		memset(&dbbth_cup_txn,0x00,sizeof(dbbth_cup_txn));
		memset(&dbbth_cup_err,0x00,sizeof(dbbth_cup_err));
		memset(query_num,0,sizeof(query_num));
		memset(str_tmp,0,sizeof(str_tmp));
		HtMemcpy(dbbth_cup_txn.date_settlmt,dbtbl_date_inf.stoday,8);
		HtMemcpy(dbbth_cup_err.date_settlmt,dbtbl_date_inf.stoday,8);
        if (fgets (sFileRecord, RECORD_LEN_MAX, fp) == NULL)
        {
            break;
        }
		if(i==12)
		{
			HtMemcpy(dbbth_cup_txn.txn_num,"1253",4);
			nReturnCode=DbsBthcuptxnTdb(DBS_SELECT3,&dbbth_cup_txn,&nFlag,0);
			if(nReturnCode)
			{
				HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
				fclose (fp1);
				fclose (fp);
				return -1;
			}
			HtMemcpy(query_num,sFileRecord+22,12);
			HtSprintf(str_tmp,"%d",atoi(query_num)-nFlag);
			memset(sFileRecord+22,' ',12);
			HtMemcpy(sFileRecord+22-strlen(str_tmp),str_tmp,strlen(str_tmp));
			
		}
		if(i==26)
		{
			memset(str_send,0,sizeof(str_send));
			HtMemcpy(str_send,sFileRecord+97,16);
			send_amt=atof(str_send);
		}
        if(i==30)
        {       
            HtMemcpy(dbbth_cup_txn.txn_num,"1363",4);
            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {       
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            } 
			if(nFlag)
			{
				memset(amt_sum,0,sizeof(amt_sum));
				memset(str_tmp,0,sizeof(str_tmp));
				HtMemcpy(query_num,sFileRecord+22,12);
				trans_num=atoi(query_num);			
				memset(query_num,' ',12);
				HtSprintf(query_num,"%d",trans_num-nFlag);
				HtMemcpy(sFileRecord+22,query_num,12);
				HtMemcpy(amt_sum,sFileRecord+36,16);
				amt_trans=atof(amt_sum);
				exp_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
				exp_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
				memset(str_tmp,' ',16);
				HtSprintf(str_tmp,"%.2f",amt_trans+exp_amt);
				HtMemcpy(sFileRecord+36,str_tmp,16);
				
				nFlag=0;
				HtMemcpy(dbbth_cup_txn.txn_num,"2363",4);
	            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
	            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
	            {      
	                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
	                fclose (fp1);
	                fclose (fp);
	                return -1;
	            }
	            if(nFlag)
	            {
					memset(query_num,0,sizeof(query_num));
					memset(str_tmp,0,sizeof(str_tmp));
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(query_num,sFileRecord+53,10);
	                trans_num=atoi(query_num);
	                memset(query_num,' ',10);
	                HtSprintf(query_num,"%d",trans_num-nFlag);
					HtMemcpy(sFileRecord+53,query_num,10);
					HtMemcpy(amt_sum,sFileRecord+65,16);
					amt_trans=atof(amt_sum);
	                rvl_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
	                rvl_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
					memset(str_tmp,' ',16);
					HtSprintf(str_tmp,"%.2f",amt_trans-rvl_amt);
					HtMemcpy(sFileRecord+65,str_tmp,16);
					memset(trans_feeb,0,sizeof(trans_feeb));
					HtMemcpy(trans_feeb,sFileRecord+83,12);
					total_feeb=atof(trans_feeb)-(exp_feeb+rvl_feeb);				
					memset(str_tmp,' ',12);
					HtSprintf(str_tmp,"%.2f",total_feeb);
					HtMemcpy(sFileRecord+83,str_tmp,12);
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(amt_sum,sFileRecord+97,16);
					total_amt=atof(amt_sum)+exp_amt-rvl_amt-(exp_feeb+rvl_feeb);
					memset(amt_sum,' ',16);
					HtSprintf(amt_sum,"%.2f",total_amt);
					HtMemcpy(sFileRecord+97,amt_sum,16);
					recv_exp=-exp_amt+rvl_amt+(exp_feeb+rvl_feeb);
				}
				else
				{
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(amt_sum,sFileRecord+97,16);
					total_amt=atof(amt_sum)+exp_amt-exp_feeb;
					memset(amt_sum,' ',16);
					HtSprintf(amt_sum,"%.2f",total_amt);
					HtMemcpy(sFileRecord+97,amt_sum,16);
					recv_exp=-exp_amt+exp_feeb;
				}
			}
		}
        if(i==31)
        {       
            HtMemcpy(dbbth_cup_txn.txn_num,"3363",4);
            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {       
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            } 
			if(nFlag)
			{
				memset(amt_sum,0,sizeof(amt_sum));
				memset(str_tmp,0,sizeof(str_tmp));
				HtMemcpy(query_num,sFileRecord+22,12);
				trans_num=atoi(query_num);			
				memset(query_num,' ',12);
				HtSprintf(query_num,"%d",trans_num-nFlag);
				HtMemcpy(sFileRecord+22,query_num,12);
				HtMemcpy(amt_sum,sFileRecord+36,16);
				amt_trans=atof(amt_sum);
				exp_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
				exp_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
				memset(str_tmp,' ',16);
				HtSprintf(str_tmp,"%.2f",amt_trans-exp_amt);
				HtMemcpy(sFileRecord+36,str_tmp,16);
				
				nFlag=0;
				HtMemcpy(dbbth_cup_txn.txn_num,"4363",4);
	            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
	            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
	            {      
	                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
	                fclose (fp1);
	                fclose (fp);
	                return -1;
	            }
	            if(nFlag)
	            {
					memset(query_num,0,sizeof(query_num));
					memset(str_tmp,0,sizeof(str_tmp));
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(query_num,sFileRecord+53,10);
	                trans_num=atoi(query_num);
	                memset(query_num,' ',10);
	                HtSprintf(query_num,"%d",trans_num-nFlag);
					HtMemcpy(sFileRecord+53,query_num,10);
					HtMemcpy(amt_sum,sFileRecord+65,16);
					amt_trans=atof(amt_sum);
	                rvl_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
	                rvl_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
					memset(str_tmp,' ',16);
					HtSprintf(str_tmp,"%.2f",amt_trans+rvl_amt);
					HtMemcpy(sFileRecord+65,str_tmp,16);
					memset(trans_feeb,0,sizeof(trans_feeb));
					HtMemcpy(trans_feeb,sFileRecord+83,12);
					total_feeb=atof(trans_feeb)-(exp_feeb+rvl_feeb);				
					memset(str_tmp,' ',12);
					HtSprintf(str_tmp,"%.2f",total_feeb);
					HtMemcpy(sFileRecord+83,str_tmp,12);
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(amt_sum,sFileRecord+97,16);
					total_amt=atof(amt_sum)-exp_amt+rvl_amt-(exp_feeb+rvl_feeb);
					memset(amt_sum,' ',16);
					HtSprintf(amt_sum,"%.2f",total_amt);
					HtMemcpy(sFileRecord+97,amt_sum,16);
					recv_cel=exp_amt-rvl_amt+(exp_feeb+rvl_feeb);
				}
				else
				{
					memset(amt_sum,0,sizeof(amt_sum));
					HtMemcpy(amt_sum,sFileRecord+97,16);
					total_amt=atof(amt_sum)-exp_amt-exp_feeb;
					memset(amt_sum,' ',16);
					HtSprintf(amt_sum,"%.2f",total_amt);
					HtMemcpy(sFileRecord+97,amt_sum,16);
					recv_cel=exp_amt+exp_feeb;
				}
			}
		}
        if(i==33)
        {       
            HtMemcpy(dbbth_cup_txn.txn_num,"5363",4);
            nReturnCode=DbsBthcuptxnTdb(DBS_SELECT4,&dbbth_cup_txn,&nFlag,0);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {       
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            }       
            if(nFlag)
            {       
                memset(amt_sum,0,sizeof(amt_sum));
                memset(str_tmp,0,sizeof(str_tmp));
                HtMemcpy(query_num,sFileRecord+22,12);
                trans_num=atoi(query_num);        
                memset(query_num,' ',12);
                HtSprintf(query_num,"%d",trans_num-nFlag);
                HtMemcpy(sFileRecord+22,query_num,12);
                HtMemcpy(amt_sum,sFileRecord+36,16);
                amt_trans=atof(amt_sum);
                exp_feeb=atof(dbbth_cup_txn.reserved_cup)/100;
                exp_amt=atof(dbbth_cup_txn.reserved_cup2)/100;
                memset(str_tmp,' ',16);
                HtSprintf(str_tmp,"%.2f",amt_trans-exp_amt);
                HtMemcpy(sFileRecord+36,str_tmp,16);
                memset(trans_feeb,0,sizeof(trans_feeb));
                HtMemcpy(trans_feeb,sFileRecord+83,12);
				total_feeb=atof(trans_feeb)-exp_feeb;
                memset(str_tmp,0,sizeof(str_tmp));
                memset(str_tmp,' ',12);
                HtSprintf(str_tmp,"%.2f",total_feeb);
                HtMemcpy(sFileRecord+83,str_tmp,12);
            	memset(amt_sum,0,sizeof(amt_sum));
            	HtMemcpy(amt_sum,sFileRecord+97,16);
            	total_amt=atof(amt_sum)-exp_amt-exp_feeb;
            	memset(amt_sum,' ',16);
            	HtSprintf(amt_sum,"%.2f",total_amt);
            	HtMemcpy(sFileRecord+97,amt_sum,16);
				recv_ret=exp_amt+exp_feeb;
			}
		}
		if(i==37)
		{
            memset(str_send,0,sizeof(str_send));
            memset(amt_sum,0,sizeof(amt_sum));
            HtMemcpy(str_send,sFileRecord+97,16);
            recv_amt=atof(str_send);
			memset(amt_sum,' ',16);
			HtSprintf(amt_sum,"%.2f",recv_amt-(recv_exp+recv_cel+recv_ret));
			HtMemcpy(sFileRecord+97,amt_sum,16);
		}
		if(i==38)
		{
			memset(str_send,0,sizeof(str_send));
            memset(amt_sum,0,sizeof(amt_sum));
            HtMemcpy(str_send,sFileRecord+97,16);
			memset(amt_sum,' ',16);
			HtSprintf(amt_sum,"%.2f",atof(str_send)-(recv_exp+recv_cel+recv_ret));
			HtMemcpy(sFileRecord+97,amt_sum,16);
		}
		if(i==77||i==80||i==92)
		{
			HtMemcpy(dbbth_cup_err.txn_type,sFileRecord,3);
			nReturnCode=DbsBthcupErr(DBS_SELECT1,&dbbth_cup_err);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {      
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            } 
			if(dbbth_cup_err.seq_num)
			{
                memset(amt_sum,0,sizeof(amt_sum));
                memset(str_tmp,0,sizeof(str_tmp));
                HtMemcpy(query_num,sFileRecord+22,12);
                trans_num=atoi(query_num);
                memset(query_num,' ',12);
                HtSprintf(query_num,"%d",trans_num-dbbth_cup_err.seq_num);
                HtMemcpy(sFileRecord+22,query_num,12);
                HtMemcpy(amt_sum,sFileRecord+36,16);
                amt_trans=atof(amt_sum);
                exp_feeb=atof(dbbth_cup_err.reserved_cup)/100;
                exp_amt=atof(dbbth_cup_err.reserve2)/100;
                memset(str_tmp,' ',16);
                HtSprintf(str_tmp,"%.2f",amt_trans+exp_amt);
                HtMemcpy(sFileRecord+36,str_tmp,16);
				memset(trans_feeb,0,sizeof(trans_feeb));
                HtMemcpy(trans_feeb,sFileRecord+83,12);
                total_feeb=atof(trans_feeb)-exp_feeb;
                memset(str_tmp,0,sizeof(str_tmp));
                memset(str_tmp,' ',12);
                HtSprintf(str_tmp,"%.2f",total_feeb);
                HtMemcpy(sFileRecord+83,str_tmp,12);
                memset(amt_sum,0,sizeof(amt_sum));
                HtMemcpy(amt_sum,sFileRecord+97,16);
                total_amt=atof(amt_sum)+exp_amt-exp_feeb;
                memset(amt_sum,' ',16);
                HtSprintf(amt_sum,"%.2f",total_amt);
                HtMemcpy(sFileRecord+97,amt_sum,16);
				err_amt=err_amt-exp_amt+exp_feeb;
				exh_fee=exh_fee+atof(dbbth_cup_err.reserve2);
			}
		}
        if(i==78||i==79||i==81||i==88||i==91)
        {
            HtMemcpy(dbbth_cup_err.txn_type,sFileRecord,3);
            nReturnCode=DbsBthcupErr(DBS_SELECT1,&dbbth_cup_err);
            if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
            {     
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select bth_cup_txn_tdb error[%d]",nReturnCode);
                fclose (fp1);
                fclose (fp);
                return -1;
            }
            if(dbbth_cup_err.seq_num)
            {
                memset(amt_sum,0,sizeof(amt_sum));
                memset(str_tmp,0,sizeof(str_tmp));
                HtMemcpy(query_num,sFileRecord+22,12);
                trans_num=atoi(query_num);
                memset(query_num,' ',12);
                HtSprintf(query_num,"%d",trans_num-dbbth_cup_err.seq_num);
                HtMemcpy(sFileRecord+22,query_num,12);
                HtMemcpy(amt_sum,sFileRecord+36,16);
                amt_trans=atof(amt_sum);
                exp_feeb=atof(dbbth_cup_err.reserved_cup)/100;
                exp_amt=atof(dbbth_cup_err.reserve2)/100;
                memset(str_tmp,' ',16);
                HtSprintf(str_tmp,"%.2f",amt_trans-exp_amt);
                HtMemcpy(sFileRecord+36,str_tmp,16);
                memset(trans_feeb,0,sizeof(trans_feeb));
                HtMemcpy(trans_feeb,sFileRecord+83,12);
                total_feeb=atof(trans_feeb)-exp_feeb;
                memset(str_tmp,0,sizeof(str_tmp));
                memset(str_tmp,' ',12);
                HtSprintf(str_tmp,"%.2f",total_feeb);
                HtMemcpy(sFileRecord+83,str_tmp,12);
                memset(amt_sum,0,sizeof(amt_sum));
                HtMemcpy(amt_sum,sFileRecord+97,16);
                total_amt=atof(amt_sum)-exp_amt-exp_feeb;
                memset(amt_sum,' ',16);
                HtSprintf(amt_sum,"%.2f",total_amt);
                HtMemcpy(sFileRecord+97,amt_sum,16);
                err_amt=err_amt+exp_amt+exp_feeb;
				exh_fee=exh_fee+atof(dbbth_cup_err.reserve2);
            }
        }
		if(i==93)
		{
        	memset(trans_feeb,0,sizeof(trans_feeb));
            HtMemcpy(trans_feeb,sFileRecord+83,12);
            total_feeb=atof(trans_feeb)-exh_fee;
            memset(str_tmp,0,sizeof(str_tmp));
            memset(str_tmp,' ',12);
            HtSprintf(str_tmp,"%.2f",total_feeb);
            HtMemcpy(sFileRecord+83,str_tmp,12);
            memset(amt_sum,0,sizeof(amt_sum));
            HtMemcpy(amt_sum,sFileRecord+97,16);
            memset(amt_sum,' ',16);
            HtSprintf(amt_sum,"%.2f",total_feeb);
            HtMemcpy(sFileRecord+97,amt_sum,16);
		}	
		
		nRecordLen=fwrite(sFileRecord,strlen(sFileRecord),1,fp1);
		if(nRecordLen<0)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "write to file error");
			fclose (fp1);
    		fclose (fp);
			return -1;
		}
		i++;
    }
    fclose (fp1);
    fclose (fp);
	memset(cmd,0,sizeof(cmd));
	HtSprintf(cmd,"mv %s %s",file_name,afile_bak);
	system(cmd);
    memset(cmd,0,sizeof(cmd));
    HtSprintf(cmd,"cp %s %s",afile_name,file_name);
    system(cmd);
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file sum success");
    return 0;
}
