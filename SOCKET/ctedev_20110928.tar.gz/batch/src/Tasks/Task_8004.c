/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_8001.pc                                                */
/* DESCRIPTIONS: check downloaded CUP files                                  */ 
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2009-12-04                                                                */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <netdb.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include "batch.h"
#include "glb/glbCommon.h"
#include "glb/glbSocket.h"

#define EID_GLB_DB               9902   
#define EID_GLB_INVALIDPARA      9918     /*��Ч����*/
#define EID_GLB_DAEMONRUNING     9919     /*���̳�ͻ*/
#define EID_GLB_UNKNOWHOST       9920     /*δ֪����*/
#define EID_GLB_SOCKETINIT       9921     /*��Ϣ���г�ʼ������*/

static int glbTimeOut = FALSE;

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;


/* TCP������ñ���*/
typedef struct {
    char txnNum[4];
    char utId[10];
    char libOrPathName[10];
    char docName[10];  
    char memberName[10];
    char date_settlmt[8];
    char rsp_code[2];
    char reserve1[60];  
} TCP_PKG_DEF;


/*****************************************************************************/
/* FUNC:   int Total_0210()                                                */
/* INPUT:  ��                                                                */
/* OUTPUT: nFileCount: ��ˮ�ļ�����                                          */
/* RETURN: nFileCount: �ɹ�, -1: ʧ��                                        */
/* DESC:   �������                                                          */
/*****************************************************************************/
int Total_8004()
{
    return 1;
}

/*****************************************************************************/
/* FUNC:   int Task_0210(int nBeginOffset, int nEndOffset)                 */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   �������                                                          */
/*****************************************************************************/
int Task_8004 ( int nBeginOffset, int nEndOffset )
{
    int     f=0;
    int     i;
    int     nReturnCode;
    int     fd;
    char    lenBuf[5], bodyBuf[1024];
    char    svrIp[15];
	char    sTcpPort[10];

    INT32 ret;
    INT32 tcpPort;
    TCP_PKG_DEF tcpPkg;

	bth_file_stat_def dbfilestat;
	host_file_rsp   filersp;

    memset(&tcpPkg, 0, sizeof(tcpPkg));
	memset(&dbfilestat,0,sizeof(dbfilestat));
	HtMemcpy(dbfilestat.date_settlmt,dbtbl_date_inf.stoday,8);
	HtMemcpy(dbfilestat.flag,"2",1);
	dbfilestat.seq_num=1;
	nReturnCode=DbsBthFileTransState(DBS_SELECT,&dbfilestat,0);
	if(nReturnCode)
	{
		HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "select DbsBthFileTransState error[%d]",nReturnCode);
		return -1;
	}

	memset(svrIp, 0, sizeof(svrIp));
	memset(sTcpPort, 0, sizeof(sTcpPort));
	HtStrcpy(sTcpPort, getenv("CGB_FILE_PORT"));
	tcpPort = atoi(sTcpPort);
	HtStrcpy(svrIp, getenv("CGB_FILE"));
    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPort:[%d]", tcpPort);
    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "IP:[%s]", svrIp);

    HtSprintf(lenBuf, "%04d", sizeof(tcpPkg));
    while(1)
    {
        if(glbSocketConnect(svrIp, NULL, tcpPort, &fd, &ret) != SUCCESS)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"svrIp:[%s], tcpPort:[%d], ret[%d], errno[%d], strerror(errno)[%s]", svrIp, tcpPort, ret, errno, strerror(errno));

            return FAILURE;
        }
        memset(bodyBuf, 0, sizeof(bodyBuf));
        memset(&tcpPkg, ' ', sizeof(tcpPkg));
        HtMemcpy(tcpPkg.txnNum,"ZK01",4);
        HtMemcpy(tcpPkg.utId,dbfilestat.utId,10);
        HtMemcpy(tcpPkg.date_settlmt,dbfilestat.trans_date,8);
        HtMemcpy(tcpPkg.libOrPathName,dbfilestat.libOrPathName,strlen(dbfilestat.libOrPathName));
        HtMemcpy(tcpPkg.docName,dbfilestat.docName,strlen(dbfilestat.docName));
        HtMemcpy(tcpPkg.memberName,dbfilestat.memberName,strlen(dbfilestat.memberName));
		HtMemcpy(bodyBuf,lenBuf,4);
		HtMemcpy(bodyBuf+4,(char *)&tcpPkg,sizeof(tcpPkg));

        if(send(fd, (char *)bodyBuf, sizeof(tcpPkg)+4, 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }

        if(recv(fd, lenBuf, 4, 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }
        lenBuf[4] = '\0';

        if(recv(fd, bodyBuf, atoi(lenBuf), 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }
		memset(&filersp,0x00,sizeof(filersp));
		HtMemcpy(&filersp,bodyBuf,sizeof(filersp));

        if(memcmp(filersp.rsp_code, "00", 2)==0)
        {
            break;
        }else {
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPkg.respCode:[%s]",bodyBuf);
            return FAILURE;
        }
    }
    close(fd);
	HtMemcpy(dbfilestat.flag,"3",1);
	nReturnCode=DbsBthFileTransState(DBS_UPDATE,&dbfilestat,0);
    if(nReturnCode)
    {
        HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "select DbsBthFileTransState error[%d]",nReturnCode);
        return -1;
    }
    return SUCCESS;
}

/*socket����*/
int glbSocketConnect(char *hostName, char *tcpService, INT32 tcpPort,
        int *fd, INT32 *errCode)
{       
    struct sockaddr_in server;
    struct servent *sp; 
    struct hostent *hp;
    struct sigaction act, oact;
    unsigned long hostaddr;
    int mfd, oldalarm, ret;

    memset((char *)&server, 0, sizeof server);

    if(tcpService != NULL && strlen(rtrim(tcpService)) != 0)
    {       
        if((sp = (struct servent *)getservbyname(tcpService, "tcp")) == NULL)
        {
            *errCode = EID_GLB_INVALIDPARA;

            return FAILURE;
        }
        if(tcpPort > 0)
            server.sin_port = htons(tcpPort);
        else
            server.sin_port = sp->s_port;
    } else {
        if(tcpPort <= 0)
        {
            *errCode = EID_GLB_INVALIDPARA;

            return FAILURE;
        }

        server.sin_port = htons(tcpPort);
    }

    if((hostaddr = inet_addr(hostName)) != INADDR_NONE)
    {
        HtMemcpy((char *)&server.sin_addr, (char *)&hostaddr, sizeof(hostaddr));
        server.sin_family = AF_INET;
    } else {
        if((hp = (struct hostent *)gethostbyname(hostName)) == NULL)
        {
            *errCode = EID_GLB_UNKNOWHOST;

            return FAILURE;
        }
        HtMemcpy((char *)&server.sin_addr, hp->h_addr, hp->h_length);
        server.sin_family = hp->h_addrtype;
    }

    if((mfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        *errCode = EID_GLB_SOCKETINIT;

        return FAILURE;
    }

    sigaction(SIGALRM, NULL, &oact);
    act.sa_handler = (void (*)( ))glbSocketTimeOutHdlr;
    act.sa_mask = oact.sa_mask;
    act.sa_flags = oact.sa_flags;
    sigaction(SIGALRM, &act, NULL);

    glbTimeOut = FALSE;
    oldalarm = alarm(20);
    ret = connect(mfd, (struct sockaddr *)&server, sizeof server);
    sigaction(SIGALRM, &oact, NULL);
    alarm(oldalarm);
    if(ret < 0 || glbTimeOut)
    {
        *errCode = EID_GLB_SOCKETINIT;

        return FAILURE;
    }

    *fd = mfd;

    return SUCCESS;
}

void glbSocketTimeOutHdlr(void)
{
    glbTimeOut = TRUE;
}
