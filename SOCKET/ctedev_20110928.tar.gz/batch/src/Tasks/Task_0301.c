/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_0301.pc                                                */
/* DESCRIPTIONS: init GC 													 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"
#include "DbsTbl.h"

/*EXEC SQL INCLUDE sqlca;*/

extern  char	gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;

int Total_0301()
{
    return 1;
}

int Task_0301 ( int nBeginOffset, int nEndOffset)
{
    int     nReturnCode;
    int     iHandleFlag;
    char    settle_date[8+1];
    char    yesterday[8+1];
    stOperationInfDef    stOprInf;
    stPartitionInfDef    stPartInf;

    memset(yesterday, 0, 9);
	HtMemcpy(settle_date, dbtbl_date_inf.stoday, 9);
	HtMemcpy(yesterday, dbtbl_date_inf.syesterday, 8);

	/*��ʱ�� OPERATION*/
	memset(&stPartInf, 0, sizeof(stPartitionInfDef));
	stPartInf.stPartInf[0].iTblOprFlag = 2;
	nReturnCode = PartInfLoad(&stPartInf);
	if(nReturnCode)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"PartInfLoad:Err:[%d].", nReturnCode);
		return -1;
	}


	HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "---------------��յ��ձ��ռ俪ʼ----------------\n");
	nReturnCode = TruncateCurrPartition(settle_date, &stPartInf);
	if(nReturnCode)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
				"DropPartition:Err:[%d].", nReturnCode);
		return -1;
	}
    return 0;
}

int OprInfLoad( stOperationInfDef* vfripOprInf, int iHandleFlag)
{
    int          liFldX;
    int          nReturnCode;
    Tbl_opr_inf_Def vtpOprInf;

    HtLog( gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "OprInfLoad iHandleFlag[%d]", iHandleFlag);

    memset( &vtpOprInf, 0, sizeof(stOprInfDef));

	vtpOprInf.sTblOprFlag = iHandleFlag;
    nReturnCode = DbsOprInf( DBS_CURSOR, &vtpOprInf);

    nReturnCode = DbsOprInf( DBS_OPEN, &vtpOprInf);

    liFldX = 0;
    while(1)
    {
        nReturnCode = DbsOprInf( DBS_FETCH, &vtpOprInf);
        HtLog( gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nReturnCode = [%d].", nReturnCode);
        if(nReturnCode == DBS_NOTFOUND)
            break;
        HtMemcpy( vfripOprInf->stOprInf[liFldX].sObjectName, &vtpOprInf.sObjectName, 60);

        liFldX++;
    } /* end of while */

    nReturnCode = DbsOprInf( DBS_CLOSE, &vtpOprInf);
    if(nReturnCode)
        return nReturnCode;

    vfripOprInf->nOprInfN = liFldX;

    return 0;
} /* end of OprInfLoad */

int PartInfLoad( stPartitionInfDef* vfripPartInf)
{
    int          liFldX;
    int          nReturnCode;
    Tbl_part_inf_Def vtpPartInf;

    HtLog( gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "PartInfLoad started.");

    memset( &vtpPartInf, 0, sizeof( Tbl_part_inf_Def));

	vtpPartInf.tbl_opr_flag = vfripPartInf->stPartInf[0].iTblOprFlag;

    nReturnCode = DbsPartInf( DBS_CURSOR, &vtpPartInf);

    nReturnCode = DbsPartInf( DBS_OPEN, &vtpPartInf);

    liFldX = 0;
    while(1)
    {
        nReturnCode = DbsPartInf( DBS_FETCH, &vtpPartInf);
        HtLog( gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "nReturnCode = [%d].", nReturnCode);
        if(nReturnCode == DBS_NOTFOUND)
            break;
        HtMemcpy( vfripPartInf->stPartInf[liFldX].sTblName, vtpPartInf.tbl_name, 60);
        HtMemcpy( vfripPartInf->stPartInf[liFldX].sPartName,vtpPartInf.part_name,60);
        HtMemcpy( vfripPartInf->stPartInf[liFldX].sTblSpcName, vtpPartInf.tbl_spc_name, 60);
        vfripPartInf->stPartInf[liFldX].iIntervalDays = vtpPartInf.tbl_interval_days;

        liFldX++;
    } /* end of while */

    nReturnCode = DbsPartInf( DBS_CLOSE, &vtpPartInf);
    if(nReturnCode)
        return nReturnCode;

    vfripPartInf->nPartInfN = liFldX;

    return 0;
} /* end of PartInfLoad */



int TruncateCurrPartition(char* sStlmDate, stPartitionInfDef* vfripPartInf)
{
    int     nReturnCode;
    int     iHandleFlag;
    int     i;
	int     count;
    char    sBuf[256+1];

    iHandleFlag = 1;
	count=0;

    /* truncate ���ձ����� */
    for( i=0; i < vfripPartInf->nPartInfN; i++)
    {
        memset(sBuf, 0, sizeof(sBuf));
		HtSprintf(sBuf,"delete from ( SELECT ROW_NUMBER() OVER() as rownum FROM %s where inter_brh_code='%s') t WHERE t.rownum <= 1000",vfripPartInf->stPartInf[i].sTblName,ext_inter_brh_code);
		while(1)
		{
			nReturnCode=ExecuteSql(sBuf);
			if( nReturnCode&&nReturnCode!= DBS_NOTFOUND)
        	{
            	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
                	"ExecuteSql: ִ��Sqlʧ��  nReturnCode:[%d], sBuf:[%s]", nReturnCode, sBuf);
            	return -1;
        	}
			else if( nReturnCode&&nReturnCode== DBS_NOTFOUND)
			{
        		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,
            		"ExecuteSql: ִ��Sql�ɹ�  nReturnCode:[%d], sBuf:[%s]\n", nReturnCode, sBuf);
				break;
			}
			DbsCommit();
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"deleting[%d]",++count);
		}
    }

    return 0;
}
