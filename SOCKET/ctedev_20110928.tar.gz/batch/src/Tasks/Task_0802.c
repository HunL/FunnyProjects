/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_0802.pc                                                */
/* DESCRIPTIONS: tdb_Stlm_Preprocess                                         */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-27  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"


/*EXEC SQL INCLUDE sqlca;*/

extern	char	gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[INTER_BRH_CODE_LEN + 1];

/*EXEC SQL BEGIN DECLARE SECTION;*/
	static bth_cup_err_def dbbth_cup_txn;
	static bth_cup_err_def_ind dbbth_cup_txn_ind;
	static bth_dtl_err_tmp_def dbbth_bth_dtl_err_tmp;

	static bth_gc_txn_def dbbth_gc_txn;

	static bth_txn_dtl_def dbbth_txn_dtl;
	static bth_txn_dtl_def_ind dbbth_txn_dtl_ind;

    static tbl_dat_cups_flow_tmp_def dbbth_cups_flow;
    static tbl_dat_cups_flow_tmp_def_ind dbbth_cups_flow_inf;
/*EXEC SQL END DECLARE SECTION;*/

/*EXEC SQL BEGIN DECLARE SECTION;*/
	static char today[8+1];
	static char branch_code[5];
	static char branch_city_code[5];
	static char branch_no[3];
	static char sSTLM_OK[1+1];
	static char sSTLM_ERROR[1+1];
	static char sSTLM_CUP_HAVE[1+1];
	static char sSTLM_HOST_HAVE[1+1];
	static char sSTLM_CUP_REVSAL[1+1];
/*EXEC SQL END DECLARE SECTION;*/

static int ins_bth_dtl_err()
{
/*	EXEC SQL BEGIN DECLARE SECTION;*/
		double amt_trans;
		double replacement_amts;
		double amt_trans_fee;
		double fee_credit;
		double fee_debit;
/*	EXEC SQL END DECLARE SECTION;*/
	int		nReturnCode;
	char tmp[14];

    DbsBTH_DTL_ERR_TMP_UNI(DBS_INIT, &dbbth_bth_dtl_err_tmp,&nReturnCode,0);
           
	amt_trans = atof(dbbth_cup_txn.amt_trans)/100;

	memset(tmp, 0, sizeof(tmp));
	HtMemcpy(tmp, dbbth_cup_txn.replacement_amts+1, 11 );
	replacement_amts = atof(tmp)/100;

	memset(tmp, 0, sizeof(tmp));
	HtMemcpy(tmp, dbbth_cup_txn.amt_trans_fee+1, 11 );
	amt_trans_fee = atof(tmp)/100;

	fee_credit = atof(dbbth_cup_txn.fee_credit)/100;
	fee_debit = atof(dbbth_cup_txn.fee_debit)/100;

	HtMemcpy(dbbth_bth_dtl_err_tmp.inter_brh_code    ,          ext_inter_brh_code,        10  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.date_settlmt      ,          dbbth_cup_txn.date_settlmt,          8  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.key_cup  	 				,	                  dbbth_cup_txn.key_cup,    48 )    ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.flag_result       ,              dbbth_cup_txn.flag_result,       1  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.txn_type          ,              dbbth_cup_txn.txn_type,          3  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.txn_num           ,                  dbbth_cup_txn.txn_num,       4  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.acq_inst_id_code  ,      dbbth_cup_txn.acq_inst_id_code,          11 )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.fwd_inst_id_code  ,      dbbth_cup_txn.fwd_inst_id_code,          11 )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.cup_ssn           ,                  dbbth_cup_txn.cup_ssn,       6  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.trans_date_time   ,          dbbth_cup_txn.trans_date_time,       10 )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.pan                                     , dbbth_cup_txn.pan,                 19 )              ;
	dbbth_bth_dtl_err_tmp.amt_trans                     =amt_trans      ;     
	dbbth_bth_dtl_err_tmp.replacement_amts               =replacement_amts      ;     
	dbbth_bth_dtl_err_tmp.amt_trans_fee                 =amt_trans_fee         ;     
	HtMemcpy(dbbth_bth_dtl_err_tmp.msg_type          ,                dbbth_cup_txn.msg_type,        4  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.processing_code   ,            dbbth_cup_txn.processing_code,     6  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.mchnt_type        ,                dbbth_cup_txn.mchnt_type,      4  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.card_accp_term_id ,        dbbth_cup_txn.card_accp_term_id,       8  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.card_accp_id      ,            dbbth_cup_txn.card_accp_id,        15 )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.retrivl_ref       ,                dbbth_cup_txn.retrivl_ref,     12 )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.pos_cond_code     ,            dbbth_cup_txn.pos_cond_code,       2  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.authr_id_resp     ,            dbbth_cup_txn.authr_id_resp,       6  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.rcvg_code         ,                dbbth_cup_txn.rcvg_code,       11 )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.orig_cup_ssn      ,            dbbth_cup_txn.orig_cup_ssn,        6  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.resp_code         ,                dbbth_cup_txn.resp_code,       2  )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.pos_entry_mode    ,            dbbth_cup_txn.pos_entry_mode,      3  )   ;
	dbbth_bth_dtl_err_tmp.fee_credit                      =fee_credit     ;      
	dbbth_bth_dtl_err_tmp.fee_debit                       =fee_debit     ;      
	HtMemcpy(dbbth_bth_dtl_err_tmp.fee_xfer          ,             dbbth_cup_txn.fee_xfer,         12   )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.flag_sd           ,                 dbbth_cup_txn.flag_sd,      1    )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.fee_cdhr          ,             dbbth_cup_txn.fee_cdhr,         12   )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.code_xfer_o       ,             dbbth_cup_txn.code_xfer_o,      11   )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.pan_xfer_o        ,             dbbth_cup_txn.pan_xfer_o,       19   )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.code_xfer_i       ,             dbbth_cup_txn.code_xfer_i,      11   )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.pan_xfer_i        ,             dbbth_cup_txn.pan_xfer_i,       19   )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.card_seq_num      ,         dbbth_cup_txn.card_seq_num,         3    )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.term_cap          ,             dbbth_cup_txn.term_cap,         1    )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.chip_cond         ,             dbbth_cup_txn.chip_cond,        1    )   ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.orig_date_time    ,        dbbth_cup_txn.orig_date_time,       10   )    ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.issuer_code       ,            dbbth_cup_txn.issuer_code,      11   )    ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.flag_domestic     ,        dbbth_cup_txn.flag_domestic,        1    )    ;

    //������2009��8��28�����ӣ��Ƕ����е��޸�
	HtMemcpy(dbbth_bth_dtl_err_tmp.channel_type      ,        dbbth_cup_txn.channel_type,         2    )    ;

	HtMemcpy(dbbth_bth_dtl_err_tmp.reserved_cup      ,        dbbth_cup_txn.reserved_cup,         32   )    ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.misc_flag         ,            dbbth_cup_txn.misc_flag,        8    )    ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.orig_host_date    ,        dbbth_txn_dtl.orig_host_date,       8    )    ;
	HtMemcpy(dbbth_bth_dtl_err_tmp.orig_host_ssn     ,        dbbth_txn_dtl.orig_host_ssn,        12   )    ;
	dbbth_bth_dtl_err_tmp.seq_num = 0;                                                          

    nReturnCode = DbsBTH_DTL_ERR_TMP_UNI(DBS_INSERT, &dbbth_bth_dtl_err_tmp,&nReturnCode,0);
    if ( nReturnCode )
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "insert into bth_dtl_err_tmp error for in_dtl_err_tmp sqlcode=[%d]",nReturnCode);
        return -1;
    }

	return 0;
}

static int dat_cups_flow_bdt()
{
	int nReturnCode;

	memset( today, 0, 9);
	HtMemcpy( today, dbtbl_date_inf.stoday, 8);

	/***  pri_key ***/
	memset(dbbth_cups_flow.pri_key,' ',42);
	HtMemcpy(dbbth_cups_flow.pri_key,"08",2);
	HtMemcpy(dbbth_cups_flow.pri_key+2,dbbth_cup_txn.acq_inst_id_code,  11);
	HtMemcpy(dbbth_cups_flow.pri_key+13,dbbth_cup_txn.cup_ssn,          6);
	HtMemcpy(dbbth_cups_flow.pri_key+19,dbbth_cup_txn.trans_date_time, 10);

	/*** orig_key ***/
	memset(dbbth_cups_flow.orig_key,' ',                             42);
	HtMemcpy(dbbth_cups_flow.orig_key,"08",                             2);
	HtMemcpy(dbbth_cups_flow.orig_key+2 , dbbth_cup_txn.acq_inst_id_code,11);
	HtMemcpy(dbbth_cups_flow.orig_key+13, dbbth_cup_txn.orig_cup_ssn,    6);
	HtMemcpy(dbbth_cups_flow.orig_key+19, dbbth_cup_txn.orig_date_time,  10);

	/*** related_key ***/
	memset(dbbth_cups_flow.related_key,' ',                             42);

   	if(!memcmp(dbbth_cup_txn.reserve2+2,"LER",3))
    {
        HtMemcpy(dbbth_cups_flow.iss_acq_in,"R",                              1);
    }
    else
    {
		HtMemcpy(dbbth_cups_flow.iss_acq_in,"A",                              1);
	}
	HtMemcpy(dbbth_cups_flow.local_settle_in,dbbth_cup_txn.flag_result,   1);

	/**������ѱ�־**/
	HtMemcpy(dbbth_cups_flow.fill_disc_in, "0",                           1);

	/** ��������� **/
	HtMemcpy(dbbth_cups_flow.err_trans_id, dbbth_cup_txn.txn_type ,       3);

	HtMemcpy(dbbth_cups_flow.settle_dt,today,                             8);
	HtMemcpy(dbbth_cups_flow.msg_tp,dbbth_cup_txn.msg_type,               4);

	HtMemcpy (dbbth_cups_flow.pri_acct_no,"19",                           2);
	HtMemcpy (dbbth_cups_flow.pri_acct_no+2, dbbth_cup_txn.pan,           19);

	HtMemcpy(dbbth_cups_flow.proc_cd,        dbbth_cup_txn.processing_code,  6);
	HtMemcpy(dbbth_cups_flow.trans_at,       dbbth_cup_txn.amt_trans,        12);
	HtMemcpy(dbbth_cups_flow.transmsn_dt_tm, dbbth_cup_txn.trans_date_time,  10);
	HtMemcpy(dbbth_cups_flow.sys_tra_no,     dbbth_cup_txn.cup_ssn,          6);
	HtMemcpy(dbbth_cups_flow.mchnt_tp,       dbbth_cup_txn.mchnt_type,       6);
	HtMemcpy(dbbth_cups_flow.pos_entry_md_cd,dbbth_gc_txn.pos_entry_mode,    3);
	HtMemcpy(dbbth_cups_flow.card_seq_num,   dbbth_cup_txn.card_seq_num,     3);
	HtMemcpy(dbbth_cups_flow.pos_cond_cd,    dbbth_cup_txn.pos_cond_code,    2);

	memset(dbbth_cups_flow.acq_ins_id_cd,' ',13);
	if(dbbth_cup_txn.acq_inst_id_code[0] !=' ')
	{
		HtMemcpy(dbbth_cups_flow.acq_ins_id_cd,  "08",                           2);
		HtMemcpy(dbbth_cups_flow.acq_ins_id_cd+2,  dbbth_cup_txn.acq_inst_id_code,11);
	}

	memset(dbbth_cups_flow.fwd_ins_id_cd,' ',13);
	if(dbbth_cup_txn.fwd_inst_id_code[0]!=' ')
	{
		HtMemcpy(dbbth_cups_flow.fwd_ins_id_cd,  "08",                            2);
		HtMemcpy(dbbth_cups_flow.fwd_ins_id_cd+2, dbbth_cup_txn.fwd_inst_id_code, 11);
	}

	HtMemcpy(dbbth_cups_flow.retri_ref_no,    dbbth_cup_txn.retrivl_ref,      12);
	HtMemcpy(dbbth_cups_flow.auth_id_resp_cd, dbbth_cup_txn.authr_id_resp,    6);
	HtMemcpy(dbbth_cups_flow.resp_cd,         dbbth_cup_txn.resp_code,        2);
	HtMemcpy(dbbth_cups_flow.term_id,         dbbth_cup_txn.card_accp_term_id,8);
	HtMemcpy(dbbth_cups_flow.mchnt_cd,        dbbth_cup_txn.card_accp_id,     15);
	HtMemcpy(dbbth_cups_flow.rsn_cd,          dbbth_cup_txn.txn_num,          4);
	HtMemcpy(dbbth_cups_flow.term_entry_cap,  dbbth_cup_txn.term_cap,         1);
	HtMemcpy(dbbth_cups_flow.chip_cond_cd,    dbbth_cup_txn.chip_cond,        1);
	HtMemcpy(dbbth_cups_flow.trans_chnl,      dbbth_cup_txn.channel_type,     2);

	memset(dbbth_cups_flow.rcv_ins_id_cd, ' ',13);
	if(dbbth_cup_txn.rcvg_code[0]!=' ')
	{
		HtMemcpy(dbbth_cups_flow.rcv_ins_id_cd,    "08",                          2);
		HtMemcpy(dbbth_cups_flow.rcv_ins_id_cd+2,  dbbth_cup_txn.rcvg_code,      11);
	}

	memset(dbbth_cups_flow.iss_ins_id_cd, ' ',13);
	if(dbbth_cup_txn.issuer_code[0]!=' ')
	{
		HtMemcpy(dbbth_cups_flow.iss_ins_id_cd,    "08",                           2);
		HtMemcpy(dbbth_cups_flow.iss_ins_id_cd+2,  dbbth_cup_txn.issuer_code,     11);
	}

	memset(dbbth_cups_flow.tfr_out_ins_id_cd,' ',13);
	if(dbbth_cup_txn.code_xfer_o[0]!=' ')
	{
		HtMemcpy(dbbth_cups_flow.tfr_out_ins_id_cd,"08",                         2);
		HtMemcpy(dbbth_cups_flow.tfr_out_ins_id_cd+2, dbbth_cup_txn.code_xfer_o, 11);
	}

	memset(dbbth_cups_flow.tfr_out_acct_id,' ',21);
	if(dbbth_cup_txn.pan_xfer_o[0]!=' ')
	{
		HtMemcpy(dbbth_cups_flow.tfr_out_acct_id,    "19",                         2);
		HtMemcpy(dbbth_cups_flow.tfr_out_acct_id+2,  dbbth_cup_txn.pan_xfer_o,     19);
	}

	memset(dbbth_cups_flow.tfr_in_ins_id_cd,' ',13);
	if(dbbth_cup_txn.code_xfer_i[0]!=' ')
	{
		HtMemcpy(dbbth_cups_flow.tfr_in_ins_id_cd,    "08",                        2);
		HtMemcpy(dbbth_cups_flow.tfr_in_ins_id_cd+2,  dbbth_cup_txn.code_xfer_i,   11);
	}

	memset(dbbth_cups_flow.tfr_in_acct_id,' ',21);
	if(dbbth_cup_txn.pan_xfer_i[0]!=' ')
	{
		HtMemcpy(dbbth_cups_flow.tfr_in_acct_id,      "19",                        2);
		HtMemcpy(dbbth_cups_flow.tfr_in_acct_id+2,    dbbth_cup_txn.pan_xfer_i,    19);
	}

	/*** ?ԭʼ��������  ***/
	memset(dbbth_cups_flow.orig_settle_dt,      ' ',  8);

	/*** ԭ���׽��  ***/
	HtMemcpy(dbbth_cups_flow.orig_trans_at,       dbbth_cup_txn.reserved_cup,  12);

	HtMemcpy(dbbth_cups_flow.orig_transmsn_dt_tm, dbbth_cup_txn.orig_date_time, 10);

	/*** ԭ����ϵͳ���ٺ� ***/
	HtMemcpy(dbbth_cups_flow.orig_sys_tra_no,     dbbth_cup_txn.orig_cup_ssn,   6 );

	/***? ԭ���׼����ο��� ***/
	memset(dbbth_cups_flow.orig_retri_ref_no,  ' ',                           12);

	HtMemcpy(dbbth_cups_flow.debt_disc_at,       dbbth_cup_txn.fee_credit,       12);
	HtMemcpy(dbbth_cups_flow.cret_disc_at,       dbbth_cup_txn.fee_debit,        12);
	HtMemcpy(dbbth_cups_flow.swt_disc_at,        dbbth_cup_txn.fee_xfer,         12);
	HtMemcpy(dbbth_cups_flow.cust_cups_disc_at,  dbbth_cup_txn.amt_trans_fee,    12);

	/*** �ֿ��˽�������  ***/
	memset(dbbth_cups_flow.cust_gold_disc_at,  ' ',12);
	/*** �𿨷��������� ***/
	memset(dbbth_cups_flow.gold_iss_ins_id_cd, ' ',13);

	HtMemcpy(dbbth_cups_flow.debt_fee_at,        dbbth_cup_txn.replacement_amts, 12);
	HtMemcpy(dbbth_cups_flow.cret_fee_at,        dbbth_cup_txn.amt_trans_fee,    12);

	HtMemcpy(dbbth_cups_flow.sms_dms_conv_in,    dbbth_cup_txn.flag_sd,          1);
	HtMemcpy(dbbth_cups_flow.dom_ext_in,         dbbth_txn_dtl.flag_city,        1);

	/** ?������׵����־  **/
	memset(dbbth_cups_flow.err_zone_in,        ' ',                            1);

	HtMemcpy(dbbth_cups_flow.cross_dist_in,      dbbth_cup_txn.flag_domestic,    1);
	memset(dbbth_cups_flow.reserve,            ' ',                            30);
    /*�̻�������x+n8, DΪ��������Ϊ0*/
    if(memcmp(dbbth_cup_txn.mchnt_fee, "D", 1)==0)
        HtMemcpy(dbbth_cups_flow.reserve, "-", 1);
    else
        HtMemcpy(dbbth_cups_flow.reserve, "0", 1);
    HtMemcpy(dbbth_cups_flow.reserve+1, dbbth_cup_txn.mchnt_fee+1, 8);
	memset(dbbth_cups_flow.reserve1,           ' ',                            30);
	memset(dbbth_cups_flow.reserve2,           ' ',                            60);
    HtMemcpy(dbbth_cups_flow.reserve2+1+1, dbbth_cup_txn.orig_txn_type, 3);
	memset(dbbth_cups_flow.reserve3,           ' ',                           100);

	nReturnCode=DbsCupFlow(DBS_INSERT_CUPS_FLOW,&dbbth_cups_flow);

	if ( nReturnCode )
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "insert into tbl_dat_cups_flow error sqlcode=[%d]",nReturnCode);
		return -1;
	}
	return 0; 
}

int Total_0802()
{
    int nTotalNum=0 ;
    int nReturnCode=0;
	memset(&dbbth_cup_txn,0x00,sizeof(dbbth_cup_txn));
	memcpy(dbbth_cup_txn.inter_brh_code,ext_inter_brh_code,10);
	nReturnCode=DbsBthcupErr(DBS_SELECT,&dbbth_cup_txn,0,0);
	nTotalNum=dbbth_cup_txn.seq_num;
    if(nReturnCode && nReturnCode != DBS_FETCHNULL)
    {
        HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"select from bth_cup_txn_bdt error, sqlcode=[%d].", nReturnCode);
        return-1 ;
    }
    HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"nTotalNum =[%d].",nTotalNum);
    return nTotalNum;
}

int Task_0802( int nBeginOffset, int nEndOffset)
{
	char	sFl_Flag_Pan[1+1],sFl_Flag_Amt[1+1];
	char	host_amt_trans[13];
	char	cup_amt_trans[13];
	int		iPanTag,iAmtTag;
	int		nReturnCode;
	float 	m_host;
	float 	m_cup;

	memset(sSTLM_OK,0,sizeof(sSTLM_OK));
	memset(sSTLM_ERROR,0,sizeof(sSTLM_ERROR));
	memset(sSTLM_CUP_HAVE,0,sizeof(sSTLM_CUP_HAVE));
	memset(sSTLM_HOST_HAVE,0,sizeof(sSTLM_HOST_HAVE));
	memset(sSTLM_CUP_REVSAL,0,sizeof(sSTLM_CUP_REVSAL));

	HtSprintf(sSTLM_OK,"%d",STLM_OK);
	HtSprintf(sSTLM_ERROR,"%d",STLM_ERROR);
	HtSprintf(sSTLM_CUP_HAVE,"%d",STLM_CUP_HAVE);
	HtSprintf(sSTLM_HOST_HAVE,"%d",STLM_HOST_HAVE);
	HtSprintf(sSTLM_CUP_REVSAL,"%d",STLM_CUP_REVSAL);

	memset( today, 0, 9);
	HtMemcpy( today, dbtbl_date_inf.stoday, 8);
	memset(&dbbth_cup_txn,0x00,sizeof(dbbth_cup_txn));
	HtMemcpy(dbbth_cup_txn.date_settlmt,today,8);
	HtMemcpy(dbbth_cup_txn.key_cup+45,"1",1);
	HtMemcpy(dbbth_cup_txn.inter_brh_code,ext_inter_brh_code,10);
	/*
	EXEC SQL DECLARE bdt_Err_Find_Process CURSOR
		FOR
		SELECT * FROM bth_cup_err
		WHERE 	inter_brh_code = :ext_inter_brh_code
		and txn_type in ( 'E05','E32','E22','E23','E33','E34','E35','E36','E73','E74','E84','E24','E25')
		and substr(key_cup,46,1)='1'
		and date_settlmt=:today
		and seq_num >= :nBeginOffset
		and seq_num <= :nEndOffset;

	EXEC SQL OPEN bdt_Err_Find_Process;
	*/
	nReturnCode=DbsBthcupErr(DBS_CURSOR,&dbbth_cup_txn,nBeginOffset,nEndOffset);
	if ( nReturnCode)
	{
		HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"open bdt_Err_Find_Process error[%d]!",nReturnCode);
		return -1;
	}

	while(1)
	{
		memset(&dbbth_cup_txn, 0, sizeof(dbbth_cup_txn));
		nReturnCode=DbsBthcupErr(DBS_FETCH,&dbbth_cup_txn,nBeginOffset,nEndOffset);
		/*
		EXEC SQL FETCH bdt_Err_Find_Process into :dbbth_cup_txn :dbbth_cup_txn_ind;
		*/
		if ( nReturnCode)
		{
			break;
		}

		HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__,__LINE__, "------------key_cup---------------[%s]",dbbth_cup_txn.key_cup);
		memset(&dbbth_txn_dtl, 0, sizeof(dbbth_txn_dtl));

		/**�ǼǱ� bth_dtl_err_tmp **/
		HtMemcpy(dbbth_cup_txn.flag_result, "3", 1 );
		HtMemcpy(dbbth_cups_flow.local_settle_in, "0", 1);
		nReturnCode = ins_bth_dtl_err();
		if( nReturnCode != 0 )
		{
			HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__,__LINE__, "insert into dtl_err err,sqlcode[%d]",nReturnCode );
			return dbbth_cup_txn.seq_num;
		}

		/**���tbl_dat_cups_flow�в������� */
		nReturnCode = dat_cups_flow_bdt();
		if( nReturnCode != 0 )
		{
			HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"insert into tbl_dat_cups_flow err,sqlcode=[%d]",nReturnCode);
			return dbbth_cup_txn.seq_num;
		}
		
	}
	DbsBthcupErr(DBS_CLOSE,&dbbth_cup_txn,nBeginOffset,nEndOffset);
	return 0;
}
