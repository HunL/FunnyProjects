/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_8001.pc                                                */
/* DESCRIPTIONS: check downloaded CUP files                                  */ 
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2009-12-04                                                                */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <netdb.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include "batch.h"
#include "glb/glbCommon.h"
#include "glb/glbSocket.h"
#include "Credit.h"

#define EID_GLB_DB               9902   
#define EID_GLB_INVALIDPARA      9918     /*��Ч����*/
#define EID_GLB_DAEMONRUNING     9919     /*���̳�ͻ*/
#define EID_GLB_UNKNOWHOST       9920     /*δ֪����*/
#define EID_GLB_SOCKETINIT       9921     /*��Ϣ���г�ʼ������*/

static int glbTimeOut = FALSE;
static int callTimeOut=0;

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_child_date[8+1];
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;


/* TCP������ñ���*/
typedef struct {
	char trans_date_time[10];
    char orSenderId[4];
    char orSenderDate[8];
    char orSenderSN[22];
    char utId[10];
	char fileType[10];
} TCP_PKG_DEF;

void callTimeOutHdlr(void)
{
    callTimeOut=1 ;
}

/*****************************************************************************/
/* FUNC:   int Total_0210()                                                */
/* INPUT:  ��                                                                */
/* OUTPUT: nFileCount: ��ˮ�ļ�����                                          */
/* RETURN: nFileCount: �ɹ�, -1: ʧ��                                        */
/* DESC:   �������                                                          */
/*****************************************************************************/
int Total_9013()
{
    return 1;
}

/*****************************************************************************/
/* FUNC:   int Task_0210(int nBeginOffset, int nEndOffset)                 */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   �������                                                          */
/*****************************************************************************/
int Task_9013 ( int nBeginOffset, int nEndOffset )
{
    int     f=0;
    int     i;
    int     nReturnCode;
    int     fd;
	int		oldAlarm;
    char    lenBuf[5], bodyBuf[1024];
	char	yesterday[8+1];
    char    svrIp[15];
	char    sTcpPort[10];
	char	tm_mt[2+1];
	fl0011_rsp ct_rsp;

    INT32 ret;
    INT32 tcpPort;
    TCP_PKG_DEF tcpPkg;

	bth_file_stat_def dbfilestat;
	tbl_child_time_def      dbtbl_child_tm;
	struct sigaction        act,oact;
    time_t  lTime;
    char    cTime[15];
    struct tm   *tTmLocal;
	tbl_child_time_def      dbtbl_child_time;
    sleep(10);
    memset(&dbtbl_child_time,0x00,sizeof(dbtbl_child_time));
    HtMemcpy(dbtbl_child_time.mission_date,ext_child_date,8);
    HtMemcpy(dbtbl_child_time.mission_index,"9012",4);
    while(1)
    {
        nReturnCode=XbsCldTime(DBS_SELECT3,&dbtbl_child_time);
        if(nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"select task status error[%d]",nReturnCode);
            return -1;
        }
        if(dbtbl_child_time.child_status==3||dbtbl_child_time.child_status==DW_EMPTY_FILE)
        {
            break;
        }
        else if(dbtbl_child_time.child_status==2)
        {
            HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"upload task excute error,please check");
            return -1;
        }
        else
        {
            HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"upload task excuting,please hold o moment");
            sleep(30);
        }
    }
	if(dbtbl_child_time.child_status==DW_EMPTY_FILE)
	{
		HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"file is empty,not upload");
		return 0;
	}

    memset(&tcpPkg, 0, sizeof(tcpPkg));
	memset(&dbfilestat,0,sizeof(dbfilestat));
	HtMemcpy(dbfilestat.date_settlmt,ext_child_date,8);
	HtMemcpy(dbfilestat.flag,"F",1);
	dbfilestat.seq_num=nBeginOffset;
	nReturnCode=DbsBthFileTransState(DBS_SELECT,&dbfilestat,0);
	if(nReturnCode)
	{
		HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "select DbsBthFileTransState error[%d]",nReturnCode);
		return -1;
	}

	memset(svrIp, 0, sizeof(svrIp));
	memset(sTcpPort, 0, sizeof(sTcpPort));
	HtStrcpy(sTcpPort, getenv("CGB_FILE_PORT"));
	tcpPort = atoi(sTcpPort);
	HtStrcpy(svrIp, getenv("CGB_FILE"));
    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPort:[%d]", tcpPort);
    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "IP:[%s]", svrIp);

    memset(cTime,0,15);                                                      
    lTime = time (NULL);
    tTmLocal = localtime (&lTime);                                           
    strftime(cTime, sizeof(cTime), "%Y%m%d%H%M%S",tTmLocal);

    HtSprintf(lenBuf, "%04d", sizeof(tcpPkg)+4);
    while(1)
    {
        if(glbSocketConnect(svrIp, NULL, tcpPort, &fd, &ret) != SUCCESS)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"svrIp:[%s], tcpPort:[%d], ret[%d], errno[%d], strerror(errno)[%s]", svrIp, tcpPort, ret, errno, strerror(errno));

            return FAILURE;
        }
        memset(bodyBuf, 0, sizeof(bodyBuf));
        memset(&tcpPkg, ' ', sizeof(tcpPkg));
		HtMemcpy(tcpPkg.trans_date_time,cTime+4,10);
		HtMemcpy(tcpPkg.orSenderId,dbfilestat.orSenderId,4);
		HtMemcpy(tcpPkg.orSenderDate,dbfilestat.orSenderDate,8);
		HtMemcpy(tcpPkg.orSenderSN,dbfilestat.orSenderSN,22);
		HtMemcpy(tcpPkg.utId,dbfilestat.utId,10);
		HtMemcpy(tcpPkg.fileType,"GDBTXINP  ",10);
		HtMemcpy(bodyBuf,lenBuf,4);
		HtMemcpy(bodyBuf+4,"CCF1",4);
		HtMemcpy(bodyBuf+8,(char *)&tcpPkg,sizeof(tcpPkg));

		HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,"bodyBuf[%s]",bodyBuf+4);
        if(send(fd, (char *)&bodyBuf, sizeof(tcpPkg)+8, 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));
			close(fd);
            return FAILURE;
        }

        sigaction(SIGALRM,NULL, &oact);
        act.sa_handler = (void(*)())callTimeOutHdlr;
        act.sa_mask = oact.sa_mask;
        act.sa_flags = oact.sa_flags;
        sigaction(SIGALRM, &act, NULL);

        callTimeOut = 0;
        oldAlarm = alarm(60);

        nReturnCode=recv(fd, lenBuf, 4, 0);
        if(nReturnCode!=4&&errno!=EINTR)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));
			close(fd);
            return FAILURE;
        }
        sigaction(SIGALRM, &oact, NULL);
        alarm(oldAlarm);
        if(callTimeOut)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ȴ�Ӧ��ʱ");
            close(fd);
            continue;
        }
        lenBuf[4] = '\0';
		memset(&bodyBuf,0x00,sizeof(bodyBuf));
        if(recv(fd, bodyBuf, atoi(lenBuf), 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));
			close(fd);
            return FAILURE;
        }
		
		memset(&ct_rsp,0x00,sizeof(ct_rsp));
		HtMemcpy((char *)&ct_rsp,bodyBuf,sizeof(ct_rsp));
        if(memcmp(ct_rsp.rsp_code, "00", 2)==0)
        {
            break;
        }else {
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPkg.respCode:[%s]",bodyBuf);
    		close(fd);
            return FAILURE;
        }
    }
    close(fd);
	HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "notify success");
    memset(cTime,0,15);
    lTime = time (NULL);
    tTmLocal = localtime (&lTime);
    strftime(cTime, sizeof(cTime), "%Y%m%d%H%M%S",tTmLocal);
	memset(&dbtbl_child_tm,0x00,sizeof(dbtbl_child_tm));
    HtMemcpy(dbtbl_child_tm.inter_brh_code,ext_inter_brh_code,10);
    HtMemcpy(dbtbl_child_tm.mission_index,"8007",4);
    HtMemcpy(dbtbl_child_tm.mission_date,ext_child_date,8);
    HtMemcpy(dbtbl_child_tm.mission_weekday,"*",1);
	memset(tm_mt,0,sizeof(tm_mt));
	HtMemcpy(tm_mt,cTime+10,2);
	if(atoi(tm_mt)==59)
	{
		memset(tm_mt,0,sizeof(tm_mt));
		HtMemcpy(tm_mt,cTime+8,2);
		HtSprintf(dbtbl_child_tm.mission_hour,"%02d",atoi(tm_mt)+1);
	}
	else
	{
    	HtMemcpy(dbtbl_child_tm.mission_hour,cTime+8,2);
	}
    dbtbl_child_tm.mission_date_adj=0;
    dbtbl_child_tm.child_id=1;
    dbtbl_child_tm.commit_flag=1;
    dbtbl_child_tm.commit_num=1;
    dbtbl_child_tm.child_begin_point=1;
    dbtbl_child_tm.child_end_point=1;
    dbtbl_child_tm.child_finish_point=0;
    dbtbl_child_tm.child_err_point=0;
    dbtbl_child_tm.child_status=0;

    nReturnCode=XbsCldTime(DBS_INSERT,&dbtbl_child_tm);
    if ( nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"insert into tbl_child_time error, %d.", nReturnCode);
        return -1;
    }
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"notify success");
    return SUCCESS;
}

/*socket����*/
int glbSocketConnect(char *hostName, char *tcpService, INT32 tcpPort,
        int *fd, INT32 *errCode)
{       
    struct sockaddr_in server;
    struct servent *sp; 
    struct hostent *hp;
    struct sigaction act, oact;
    unsigned long hostaddr;
    int mfd, oldalarm, ret;

    memset((char *)&server, 0, sizeof server);

    if(tcpService != NULL && strlen(rtrim(tcpService)) != 0)
    {       
        if((sp = (struct servent *)getservbyname(tcpService, "tcp")) == NULL)
        {
            *errCode = EID_GLB_INVALIDPARA;

            return FAILURE;
        }
        if(tcpPort > 0)
            server.sin_port = htons(tcpPort);
        else
            server.sin_port = sp->s_port;
    } else {
        if(tcpPort <= 0)
        {
            *errCode = EID_GLB_INVALIDPARA;

            return FAILURE;
        }

        server.sin_port = htons(tcpPort);
    }

    if((hostaddr = inet_addr(hostName)) != INADDR_NONE)
    {
        HtMemcpy((char *)&server.sin_addr, (char *)&hostaddr, sizeof(hostaddr));
        server.sin_family = AF_INET;
    } else {
        if((hp = (struct hostent *)gethostbyname(hostName)) == NULL)
        {
            *errCode = EID_GLB_UNKNOWHOST;

            return FAILURE;
        }
        HtMemcpy((char *)&server.sin_addr, hp->h_addr, hp->h_length);
        server.sin_family = hp->h_addrtype;
    }

    if((mfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        *errCode = EID_GLB_SOCKETINIT;

        return FAILURE;
    }

    sigaction(SIGALRM, NULL, &oact);
    act.sa_handler = (void (*)( ))glbSocketTimeOutHdlr;
    act.sa_mask = oact.sa_mask;
    act.sa_flags = oact.sa_flags;
    sigaction(SIGALRM, &act, NULL);

    glbTimeOut = FALSE;
    oldalarm = alarm(20);
    ret = connect(mfd, (struct sockaddr *)&server, sizeof server);
    sigaction(SIGALRM, &oact, NULL);
    alarm(oldalarm);
    if(ret < 0 || glbTimeOut)
    {
        *errCode = EID_GLB_SOCKETINIT;

        return FAILURE;
    }

    *fd = mfd;

    return SUCCESS;
}

void glbSocketTimeOutHdlr(void)
{
    glbTimeOut = TRUE;
}
