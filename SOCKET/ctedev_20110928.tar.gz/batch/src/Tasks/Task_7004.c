/*******************************************/
/**        �ϴ������������ļ�             **/
/*******************************************/
#include "batch.h"
#include "natp_file.h"
#include "Credit.h"
#include "CommNatp.h"
#include <sys/socket.h>
#include <dirent.h>

#define LEN_REQ  555

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern          tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[10+1];
extern  int     ext_inter_brh_sta;
static  int     callTimeOut=0;
static int file_num=0;

void callTimeOutHdlr(void)
{
    callTimeOut=1 ;
}

int Total_7004()
{
    return 1;
}

int Task_7004 ( int nBeginOffset, int nEndOffset )
{
	int 	nReturn;
	int 	nReturnCode;
	int 	nTotalNum;
	int 	count;
	int 	sock;
	int 	oldAlarm;
	char 	sErrMsg[100];
	int  	lenth;
	int		sleep_tm;
	time_t 	lTime;
    char 	cTime[15];
	char	*pstr;
	char    file_name[200];
	char	file_tmp[20];
	char	remote_path[100+1];
	char	cfgFileName[200];
	char	cfgtmp[200];
	char	sSqlBuf[SQL_BUF_LEN];
	char 	DataBuffer[1024];
	char	err_msg[1024];
	char	sFileServer[100];
	char	ssn_tmp[8+1];
	char	mem_name[10+1];
	char	descr_tmp[100+1];
	char	val_tmp[200];
	char	host_id[10+1];
	char	rece_id[10+1];
	char    uid[10+1];
	char	*p;
	char	tmp;
    struct tm 	*tTmLocal;
	struct sigaction 		act,oact;
	NatpPut_req 			put_bdb_req;
	credit_comm_rsp         gate_comm_rsp;
	credit_comm_header 		comm_header;
	credit_file_stat_rsp 	gate_file_rsp;
	NatpFile_stat_req  		file_stat;
	bth_file_stat_def       dbfilestatus;
    char    file_dir[200];
    DIR        *lp;
    struct dirent *file_nm;
	struct stat stat_buf;
	int file_size;
	count =0;
	memset(file_name,0,sizeof(file_name));
	memset(file_tmp,0,sizeof(file_tmp));
    memset(sErrMsg,0x00,sizeof(sErrMsg));
    memset(mem_name,0,sizeof(mem_name));
    strcpy(mem_name,"*FIRST");
    HtSprintf(file_name, "%s/%s/%s/%s/%s", getenv("BATCH_FILE_PATH"),dbtbl_date_inf.stoday,getenv("CUP_ID"),SB_FILE_PATH,MZ_TXN_SUM);
    pstr = strstr (file_name, "MMDD");
    if(pstr) HtMemcpy (pstr, dbtbl_date_inf.stoday+4, 4);
    HtStrcpy(file_tmp,MZ_TXN_SUM);
    pstr = strstr (file_tmp, "MMDD");
    if(pstr) HtMemcpy (pstr, dbtbl_date_inf.stoday+4, 4);
    HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "file_name=[%s].", file_name);

    memset(&stat_buf,0,sizeof(stat_buf));
    if(stat(file_name,&stat_buf)==-1)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "����stat error[%s][%d][%s]",file_name,errno,strerror(errno));
        return -1;
    }
    file_size=stat_buf.st_size;
    if(file_size==0)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "[%s] is empty file",file_name);
        return 0;
    }
   	memset(remote_path,0,sizeof(remote_path)); 
    memset(cfgFileName,0,sizeof(cfgFileName));
	HtSprintf(cfgFileName,"%s/config/natp.cfg",getenv("MKHOME"));
/*
	strcpy(remote_path,"SWTC>0000000025>CGB101000");
*/
	memset(val_tmp,0,sizeof(val_tmp));
	glbPflGetString("NATPFILE_SB","FILECATEGORY",cfgFileName,val_tmp);
	memset(host_id,0,sizeof(host_id));
	memset(rece_id,0,sizeof(rece_id));
	glbPflGetString("NATPFILE_SB","HOSTID",cfgFileName,host_id);
	glbPflGetString("NATPFILE_SB","RECEIVERID",cfgFileName,rece_id);
	memset(uid,0,sizeof(uid));
	glbPflGetString("NATPFILE_SB","UTID",cfgFileName,uid);
	sprintf(remote_path,"%s>%s>%s",val_tmp,uid,file_tmp);
/*
    nReturn=NatpCliPutFile( remote_path,file_name, "FS01", "S29B", sErrMsg);
*/

    nReturn=NatpCliPutFile( remote_path,file_name, rece_id, host_id, sErrMsg);
    if(nReturn)
    {
    	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ϴ������ļ�ʧ��");
    	return -1;
    }
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ϴ��ļ����ķ��ɹ�");
    
    memset(sSqlBuf, 0, SQL_BUF_LEN);
    sprintf(sSqlBuf, "select nextval for NATP_FILE_SSN_%s  from SYSIBM.SYSDUMMY1",ext_inter_brh_code);
    nReturnCode = SelectSequence(sSqlBuf, &nTotalNum);
    if( nReturnCode )
    {
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select error[%d]",nReturnCode);
        return nReturnCode;
    }
	memset(ssn_tmp,0,sizeof(ssn_tmp));
	sprintf(ssn_tmp,"%05d",nTotalNum);
    memset(cTime,0,15);
    lTime = time (NULL);
    tTmLocal = localtime (&lTime);
    strftime(cTime, sizeof(cTime), "%Y%m%d%H%M%S",tTmLocal);
    
    /**���������ϴ��ļ��������Ľӿ�**/
    memset(&put_bdb_req,' ',sizeof(put_bdb_req));
    memset(&comm_header,' ',sizeof(comm_header));
    comm_header.totalLength[0]=0x00; 
    comm_header.totalLength[1]=0x00;
    comm_header.totalLength[2]=0x02;
    comm_header.totalLength[3]=0x27;
	HtMemcpy(comm_header.versionNo,"1",1);
	HtMemcpy(comm_header.toEncrypt,"0",1);
	HtMemcpy(comm_header.commCode,"500001",6);
	HtMemcpy(comm_header.commType,"0",1);
	memset(val_tmp,0,sizeof(val_tmp));
	glbPflGetString("NATPFILE_SB","RECEIVERID",cfgFileName,val_tmp);
	HtMemcpy(comm_header.receiverId,val_tmp,strlen(val_tmp));
/*
	HtMemcpy(comm_header.receiverId,"FS01",4);
*/
	memset(val_tmp,0,sizeof(val_tmp));
	glbPflGetString("NATPFILE_SB","SENDERID",cfgFileName,val_tmp);
	HtMemcpy(comm_header.senderId,val_tmp,strlen(val_tmp));
/*
	HtMemcpy(comm_header.senderId,"SWTCH",4);
*/
	HtMemcpy(comm_header.senderSN,"108",3);
	HtMemcpy(comm_header.senderSN+3,cTime,14);
	HtMemcpy(comm_header.senderSN+17,ssn_tmp,5);
	HtMemcpy(comm_header.senderDate,cTime,8);
	HtMemcpy(comm_header.senderTime,cTime+8,6);
	HtMemcpy(comm_header.tradeCode,"FS2001",6);
	HtMemcpy(comm_header.gwErrorCode,"  ",2);
	HtMemcpy(comm_header.gwErrorMessage,"       ",7);
	
	HtMemcpy(put_bdb_req.template,"FS2000",6);
	HtMemcpy(put_bdb_req.temp_code,"FS2001",6);

	memset(val_tmp,0,sizeof(val_tmp));
	glbPflGetString("NATPFILE_SB","HOSTID",cfgFileName,val_tmp);
	HtMemcpy(put_bdb_req.hostId,val_tmp,strlen(val_tmp));
/*
	HtMemcpy(put_bdb_req.hostId,"S29B",4);
*/
	memset(val_tmp,0,sizeof(val_tmp));
	glbPflGetString("NATPFILE_SB","LIBORPATHNAME",cfgFileName,val_tmp);
	HtMemcpy(put_bdb_req.libOrPathName,val_tmp,strlen(val_tmp));
	
	memset(val_tmp,0,sizeof(val_tmp));
	glbPflGetString("NATPFILE_SB","DOCNAME",cfgFileName,val_tmp);
	HtMemcpy(put_bdb_req.docName,val_tmp,strlen(val_tmp));

	HtMemcpy(put_bdb_req.orSenderId,comm_header.senderId,4);
/*
	HtMemcpy(put_bdb_req.libOrPathName,"BANP#SPDP",9);
	HtMemcpy(put_bdb_req.docName,"PBYSUMP",7);
	HtMemcpy(put_bdb_req.orSenderId,"SWTC",4);
*/

	HtMemcpy(put_bdb_req.memberName,mem_name,strlen(mem_name));
    HtMemcpy(put_bdb_req.orSenderSN,comm_header.senderSN,22);
    HtMemcpy(put_bdb_req.orSenderDate,cTime,8);
    HtMemcpy(put_bdb_req.orSenderTime,cTime+8,6);
    HtMemcpy(put_bdb_req.ooSenderId, put_bdb_req.orSenderId,4);
    HtMemcpy(put_bdb_req.ooSenderSN, put_bdb_req.orSenderSN,22);
    HtMemcpy(put_bdb_req.ooSenderDate, put_bdb_req.orSenderDate,8);
	HtMemcpy(put_bdb_req.ooSenderTime, put_bdb_req.orSenderTime,6);

	memset(val_tmp,0,sizeof(val_tmp));
	glbPflGetString("NATPFILE_SB","FILECATEGORY",cfgFileName,val_tmp);
	HtMemcpy(put_bdb_req.fileCategory,val_tmp,strlen(val_tmp));
    memset(val_tmp,0,sizeof(val_tmp));
    glbPflGetString("NATPFILE_SB","UTID",cfgFileName,val_tmp);
    HtMemcpy(put_bdb_req.utId,val_tmp,strlen(val_tmp));
/*
	HtMemcpy(put_bdb_req.fileCategory,"SWTC",4);
	HtMemcpy(put_bdb_req.utId,"0000000025",10);
*/
    HtMemcpy(put_bdb_req.srcFileName,file_tmp,strlen(file_tmp));
	memset(descr_tmp,0,sizeof(descr_tmp));
	strcpy(descr_tmp,"÷���籣�ļ�");
    HtMemcpy(put_bdb_req.srcFileDes,descr_tmp,strlen(descr_tmp));
	HtMemcpy(put_bdb_req.priority,"01",2);
    memset(DataBuffer,0,sizeof(DataBuffer));

    HtMemcpy(DataBuffer,(char *)&comm_header,80);
    HtMemcpy(DataBuffer+80,(char *)&put_bdb_req,475);
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DataBuffer[%s]",DataBuffer+4);
    count=0;
    while(1)
    {
		memset(sFileServer,0,sizeof(sFileServer));
		strcpy(sFileServer,"FS002");
	    sock = NatpFileConnect(sFileServer);
	    if(sock < 0)
	    {
	
	        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ں���NatpGetFile�У����������������ʧ��[%d]",sock);
	        if(count<5)
	        {
	        	sleep(10);
	        	continue;
	        }
	        else
	        {
	        	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "������������");
	        	return -1;
	        }
	    }
	    HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "connect success");
	    break;
	}
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DataBuffer[%s]",DataBuffer);
    nReturnCode=send(sock,DataBuffer,LEN_REQ,0);
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nReturnCode[%d]",nReturnCode);
    if(nReturnCode<=0||nReturnCode!=LEN_REQ)
    {
    	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ִ��writeϵͳ��������terrno=[%d]\tErrMsg=[%s]", errno, strerror(errno));
		close(sock);
    	return -1;
    }

    sigaction(SIGALRM,NULL, &oact);
    act.sa_handler = (void(*)())callTimeOutHdlr;
    act.sa_mask = oact.sa_mask;
    act.sa_flags = oact.sa_flags;
    sigaction(SIGALRM, &act, NULL);

    callTimeOut = 0;
	oldAlarm = alarm(600);
    memset(DataBuffer,0,sizeof(DataBuffer));
    nReturnCode=recv(sock,DataBuffer,4,0);
    if(nReturnCode!=4&&errno!=EINTR)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "��ȡ���ȳ���[%d][%d]",errno,nReturnCode);
        close(sock);
        return -1;
    }
    sigaction(SIGALRM, &oact, NULL);
    alarm(oldAlarm);
    if(callTimeOut)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ȴ�����Ӧ��ʱ");
    }
    else
    {
        nReturnCode=nMCalcIn(&lenth,DataBuffer,4);
		if(nReturnCode)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�������ĳ��ȳ���");
			close(sock);
        	return -1;
		}
	    nReturnCode=recv(sock,DataBuffer,lenth,0);
		if(nReturnCode!=lenth)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"recv_len=[%d],lenth=[%d]errno[%d]",nReturnCode,lenth,errno);
			close(sock);
            return -1;
		}
		close(sock);
		memset(&gate_comm_rsp,0x00,sizeof(gate_comm_rsp));
		HtMemcpy(&gate_comm_rsp,DataBuffer,strlen(DataBuffer));
		if(!memcmp(gate_comm_rsp.gwErrorCode,"01",2)&&!memcmp(gate_comm_rsp.errorCode,"0000",4))
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"�ļ��������Ѿ������������Ժ��ѯ�ļ�״̬");
		}
		else
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"�ϴ��ļ����������������%s��",DataBuffer);
			return -1;
		}
		sleep(10);
	}
	
	while(1)	
	{
	    memset(sSqlBuf, 0, SQL_BUF_LEN);
	    sprintf(sSqlBuf, "select nextval for NATP_FILE_SSN_%s  from SYSIBM.SYSDUMMY1",ext_inter_brh_code);
	    nReturnCode = SelectSequence(sSqlBuf, &nTotalNum);
	    if( nReturnCode )
	    {
	        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select error[%d]",nReturnCode);
	        return nReturnCode;
	    }
	
	    memset(ssn_tmp,0,sizeof(ssn_tmp));
	    sprintf(ssn_tmp,"%05d",nTotalNum);
	    memset(cTime,0,15);
	    lTime = time (NULL);
	    tTmLocal = localtime (&lTime);
	    strftime(cTime, sizeof(cTime), "%Y%m%d%H%M%S",tTmLocal);
	
	    memset(&comm_header,' ',sizeof(comm_header));
	    comm_header.totalLength[0]=0x00;
	    comm_header.totalLength[1]=0x00;
	    comm_header.totalLength[2]=0x00;
	    comm_header.totalLength[3]=0xE1;
	    HtMemcpy(comm_header.versionNo,"1",1);
	    HtMemcpy(comm_header.toEncrypt,"0",1);
	    HtMemcpy(comm_header.commCode,"500001",6);
	    HtMemcpy(comm_header.commType,"0",1);
	    HtMemcpy(comm_header.receiverId,rece_id,4);
	    HtMemcpy(comm_header.senderId,put_bdb_req.orSenderId,4);
	    HtMemcpy(comm_header.senderSN,"108",3);
	    HtMemcpy(comm_header.senderSN+3,cTime,14);
	    HtMemcpy(comm_header.senderSN+17,ssn_tmp,5);
	    HtMemcpy(comm_header.senderDate,cTime,8);
	    HtMemcpy(comm_header.senderTime,cTime+8,6);
	    HtMemcpy(comm_header.tradeCode,"FS2005",6);
	    HtMemcpy(comm_header.gwErrorCode,"  ",2);
	    HtMemcpy(comm_header.gwErrorMessage,"       ",7);
		memset(&file_stat,' ',sizeof(file_stat));
		HtMemcpy(file_stat.template,"FS2000",6);
		HtMemcpy(file_stat.temp_code,"FS2005",6);
		HtMemcpy(file_stat.orSenderId,put_bdb_req.orSenderId,4);
		HtMemcpy(file_stat.orSenderSN,put_bdb_req.orSenderSN,22);
		HtMemcpy(file_stat.orSenderDate,put_bdb_req.orSenderDate,8);
		HtMemcpy(file_stat.direction,"1",1);
		HtMemcpy(file_stat.utId,put_bdb_req.utId,10);
		HtMemcpy(file_stat.hostId,put_bdb_req.hostId,4);
        memset(val_tmp,0,sizeof(val_tmp));
        glbPflGetString("NATPFILE_SB","LIBORPATHNAME",cfgFileName,val_tmp);
        HtMemcpy(file_stat.libOrPathName,val_tmp,strlen(val_tmp));
        memset(val_tmp,0,sizeof(val_tmp));
        glbPflGetString("NATPFILE_SB","DOCNAME",cfgFileName,val_tmp);
        HtMemcpy(file_stat.docName,val_tmp,strlen(val_tmp));
/*
		HtMemcpy(file_stat.libOrPathName,put_bdb_req.libOrPathName,9);
		HtMemcpy(file_stat.docName,put_bdb_req.docName,7);
*/
	
	    HtMemcpy(DataBuffer,(char *)&comm_header,80);
	    HtMemcpy(DataBuffer+80,(char *)&file_stat,149);
	    count=0;
	    while(1)
	    {
	        memset(sFileServer,0,sizeof(sFileServer));
	        strcpy(sFileServer,"FS002");
	        sock = NatpFileConnect(sFileServer);
	        if(sock < 0)
	        {       
	    
	            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ں���NatpGetFile�У����������������ʧ��[%d]",sock);
	            if(count<5)
	            {       
	                sleep(10);
	                continue;
	            }       
	            else    
	            {       
	                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "������������");
	                return -1;
	            }       
	        }       
	        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "connect success");
	        break;  
	    }
	    HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DataBuffer[%s]",DataBuffer+4);
	    nReturnCode=send(sock,DataBuffer,229,0);
	    HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nReturnCode[%d]",nReturnCode);
	    if(nReturnCode<=0||nReturnCode!=229)
	    {
	        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ִ��recvϵͳ��������errno=[%d]\tErrMsg=[%s]", errno, strerror(errno));
	        close(sock);
	        return -1;
	    }
	
	    sigaction(SIGALRM,NULL, &oact); 
	    act.sa_handler = (void(*)())callTimeOutHdlr;
	    act.sa_mask = oact.sa_mask;
	    act.sa_flags = oact.sa_flags;
	    sigaction(SIGALRM, &act, NULL);
	
	    callTimeOut = 0;
	    oldAlarm = alarm(600);
	    memset(DataBuffer,0,sizeof(DataBuffer));
	    nReturnCode=recv(sock,DataBuffer,4,0);
	    if(nReturnCode!=4&&errno!=EINTR)
	    {
	        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "��ȡ���ȳ���[%d][%d]",errno,nReturnCode);
	        close(sock);
	        return -1;
	    }
	    sigaction(SIGALRM, &oact, NULL);
	    alarm(oldAlarm);
	    if(callTimeOut)
	    {
	        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ȴ�����Ӧ��ʱ,�ļ�״̬δ֪");
			close(sock);
			return -1;
	    }
	    else
	    {
	        nReturnCode=nMCalcIn(&lenth,DataBuffer,4);
			if(nReturnCode)
	        {
	            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�������ĳ��ȳ���");
	            close(sock);
	            return -1;
	        }
	        nReturnCode=recv(sock,DataBuffer,lenth,0);
	        if(nReturnCode!=lenth)
	        {
	        	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"lenth=[%d],nReturnCode[%d]",lenth,nReturnCode);
	            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "ִ��recvϵͳ��������terrno=[%d]\tErrMsg=[%s]", errno, strerror(errno));
	            close(sock);
	            return -1;
	        }
	        close(sock);
	        memset(&gate_file_rsp,0x00,sizeof(gate_file_rsp));
	        HtMemcpy((char *)&gate_file_rsp,DataBuffer,lenth);
	        if(!memcmp(gate_file_rsp.gwErrorCode,"01",2)&&!memcmp(gate_file_rsp.errorCode,"0000",4))
			{
				if(!memcmp(gate_file_rsp.fileTransStatus,"02",2))
				{
					HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__,"�ϴ��ļ��ɹ�");
					break;
				}
				else
		        {
					if(!memcmp(gate_file_rsp.fileTransStatus,"0E",2)||!memcmp(gate_file_rsp.fileTransStatus,"0F",2)||!memcmp(gate_file_rsp.fileTransStatus,"12",2))
					{
						HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ļ������ϴ��У����Ժ��ѯ[%s]",DataBuffer);
						sleep(20);
						continue;
					}
					else
					{
		            	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ϴ��ļ�����[%s]",DataBuffer);
		            	return -1;
					}
		        }
			}
			else
			{
				HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ϴ��ļ�����������[%s]",DataBuffer);
				return -1;
			}
	    }
	}
	memset(&dbfilestatus,0x00,sizeof(dbfilestatus));
	HtMemcpy(dbfilestatus.orSenderId,put_bdb_req.orSenderId,4);
	HtMemcpy(dbfilestatus.orSenderSN,put_bdb_req.orSenderSN,22);
	HtMemcpy(dbfilestatus.date_settlmt,dbtbl_date_inf.stoday,8);
	HtMemcpy(dbfilestatus.trans_date,put_bdb_req.orSenderDate,8);
	HtMemcpy(dbfilestatus.orSenderDate,put_bdb_req.orSenderDate,8);
	HtMemcpy(dbfilestatus.orSenderTime,put_bdb_req.orSenderTime,6);
	HtMemcpy(dbfilestatus.utId,put_bdb_req.utId,10);
	HtMemcpy(dbfilestatus.libOrPathName,put_bdb_req.libOrPathName,10);
	HtMemcpy(dbfilestatus.docName,put_bdb_req.docName,10);
	HtMemcpy(dbfilestatus.memberName,put_bdb_req.memberName,10);
	HtMemcpy(dbfilestatus.reserve1," ",1);
	HtMemcpy(dbfilestatus.flag,"M",1);
    nReturnCode=DbsBthFileTransState(DBS_DELETE,&dbfilestatus,nBeginOffset);
    if(nReturnCode&&nReturnCode!=DBS_NOTFOUND)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "inser into BthFileTransStatus error[%d]",nReturnCode);
        return -1;
    }
	nReturnCode=DbsBthFileTransState(DBS_INSERT,&dbfilestatus,nBeginOffset);
	if(nReturnCode)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "inser into BthFileTransStatus error[%d]",nReturnCode);
		return -1;
	}
	return 0;
}
