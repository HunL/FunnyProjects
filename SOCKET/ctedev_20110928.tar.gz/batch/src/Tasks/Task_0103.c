/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_0109.pc                                                */
/* DESCRIPTIONS: download POSP txn  										 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"
#include "tbl_opr.h"

#define SAVE_INST       "03060000"
extern char	gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern	char ext_inter_brh_code[10+1];
extern	char ext_inter_brh_sta;

int Total_0103()
{
        return 1;
}

int Task_0103 ( int nBeginOffset, int nEndOffset )
{
	int		nReturn;
	int		iFlag = 0;
	char	today[8+1];
	char    *pstr;
	char	host_file_name[200];
	char	sa_file[50];
	FILE    *fp;
    char    sFileRecord[RECORD_LEN_MAX];
    char    sEndStr[3];
	tbl_file_trans_def dbTblfiletrans;

	memset( today, 0, 9);
	HtMemcpy( today, dbtbl_date_inf.stoday, 8);
	memset( host_file_name, 0, 200);
    HtSprintf(host_file_name, "%s/YYYYMMDD/%s/%s/%s", getenv("BATCH_FILE_PATH"), getenv("CUP_ID"),IC_FILE_PATH, getenv("CUP_ID"));
	pstr = strstr (host_file_name, "YYYYMMDD");
	if(pstr) HtMemcpy (pstr, today, 8);

	nReturn = CheckDir( host_file_name );
	if(nReturn)
	{
		HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Create directory error: [%s].", host_file_name );
		return -1;
	}

	HtStrcat(host_file_name, "/");
	HtStrcat( host_file_name, IC_HOST_FILE_NAME);
	pstr = strstr (host_file_name, "YYYYMMDD");
	if(pstr) HtMemcpy (pstr, today, 8);
	
	memset(sa_file,0x00,sizeof(sa_file));
	HtStrcpy(sa_file,IC_HOST_FILE_NAME);
	pstr = strstr (sa_file, "YYYYMMDD");
	if(pstr) HtMemcpy (pstr, today, 8);


	memset(&dbTblfiletrans,0x00,sizeof(dbTblfiletrans));
	HtStrcpy(dbTblfiletrans.inter_brh_code, (char *)getenv("CUP_ID"));
	HtStrcpy(dbTblfiletrans.sa_file_name,sa_file);
	HtStrcpy(dbTblfiletrans.sa_stlm_inst_id,SAVE_INST);
	HtMemcpy(dbTblfiletrans.sa_file_flg,"R",1);
	HtMemcpy(dbTblfiletrans.sa_file_date,today,8);

	
	HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"host_file_name = [%s].", host_file_name );

	while(1)
	{
        if( ((fp = fopen( host_file_name, "r")) == NULL ))
        {
			HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"file not found, file = [%s].",
            host_file_name );
			sleep(30);
            continue;
        }
        else
        {
			fclose (fp);
			nReturn=lQSaveFileTransOpr(NTblSelect1,&dbTblfiletrans);
			if(nReturn)
			{
				HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"select task status error[%d]",nReturn);
				return -1;
			}
			if(dbTblfiletrans.sa_file_stat[0]=='3')
			{
				break;
			}
			else if(dbTblfiletrans.sa_file_stat[0]=='2')
			{
				HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"download task excute error,please check");
				return -1;
			}
			else
			{
				HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"download task excuting,please hold o moment");
			}
		}
	}

	HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"host_file_name = [%s].", host_file_name );

	return 0;
}
