/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_0210.pc                                                */
/* DESCRIPTIONS: check downloaded CUP files                                  */ 
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2009-12-04                                                                */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <netdb.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include "batch.h"
#include "glb/glbCommon.h"
#include "glb/glbSocket.h"

#define EID_GLB_DB               9902   
#define EID_GLB_INVALIDPARA      9918     /*��Ч����*/
#define EID_GLB_DAEMONRUNING     9919     /*���̳�ͻ*/
#define EID_GLB_UNKNOWHOST       9920     /*δ֪����*/
#define EID_GLB_SOCKETINIT       9921     /*��Ϣ���г�ʼ������*/

#define PFL_LINE_BUFFER_SIZE     1024

static int glbTimeOut = FALSE;

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
static tbl_date_inf_def dbtbl_date_inf_dbs;
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;


/* TCP������ñ���*/
typedef struct {
    char reqId[5];       /* �����ʶ*/
    char settleDate[9];  /* �������ڨ� */
    char checkFlag[2];   /* ����־ */
    char redoFlag[2];    /* ������־ */
    char para[513];      /* ���� */
    char respCode[3];    /* ������ */
} TCP_PKG_DEF;


/*****************************************************************************/
/* FUNC:   int Total_0210()                                                */
/* INPUT:  ��                                                                */
/* OUTPUT: nFileCount: ��ˮ�ļ�����                                          */
/* RETURN: nFileCount: �ɹ�, -1: ʧ��                                        */
/* DESC:   �������                                                          */
/*****************************************************************************/
int Total_4001()
{
    return 1;
}

/*****************************************************************************/
/* FUNC:   int Task_0210(int nBeginOffset, int nEndOffset)                 */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   �������                                                          */
/*****************************************************************************/
int Task_4001 ( int nBeginOffset, int nEndOffset )
{
    int     f=0;
    int     i;
    int     nReturnCode;
    int     fd;
    char    lenBuf[5], bodyBuf[1024];
    char    svrIp[15];
	char    sTcpPort[10];

    INT32 ret;
    INT32 tcpPort;
    TCP_PKG_DEF tcpPkg;

    char    settleDate[9];
    char    cleanSt[2];

    memset(&tcpPkg, 0, sizeof(tcpPkg));
    memset(settleDate, 0, sizeof(settleDate));
    memset(cleanSt, 0, sizeof(cleanSt));

	memset(&dbtbl_date_inf_dbs,0x00,sizeof(dbtbl_date_inf_dbs));
	HtMemcpy(dbtbl_date_inf_dbs.inter_brh_code,ext_inter_brh_code,6);
	nReturnCode=DbsTbldateInf(DBS_SELECT2,&dbtbl_date_inf_dbs);
	HtMemcpy(settleDate,dbtbl_date_inf_dbs.sforestartdate,8);
    if(nReturnCode)
    {
        HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "sqlcode:[%d]", nReturnCode);
        return FAILURE;
    }

    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "[%s]��������㿪ʼ", settleDate);

	memset(svrIp, 0, sizeof(svrIp));
	memset(sTcpPort, 0, sizeof(sTcpPort));
	HtStrcpy(sTcpPort, getenv("SETTLE_PORT"));
	tcpPort = atoi(sTcpPort);
	HtStrcpy(svrIp, getenv("SETTLE_IP"));
    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPort:[%d]", tcpPort);
    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "IP:[%s]", svrIp);

    HtSprintf(lenBuf, "%04d", sizeof(TCP_PKG_DEF));
    while(1)
    {
        if(glbSocketConnect(svrIp, NULL, tcpPort, &fd, &ret) != SUCCESS)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"svrIp:[%s], tcpPort:[%d], ret[%d], errno[%d], strerror(errno)[%s]", svrIp, tcpPort, ret, errno, strerror(errno));

            return FAILURE;
        }
        if(send(fd, lenBuf, 4, 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }

        memset(bodyBuf, 0, sizeof(bodyBuf));

        memset(&tcpPkg, '\0', sizeof(TCP_PKG_DEF));
        strncpy(tcpPkg.reqId, "1001", 4);
        strncpy(tcpPkg.settleDate, settleDate, 8);
        strncpy(tcpPkg.redoFlag, "0", 1);

        /** ��������״̬ **/
        tcpPkg.checkFlag[0] = NO;
        /** ADD END **/

        HtStrcpy(bodyBuf, "111111");
        HtMemcpy(bodyBuf + 6, &tcpPkg, sizeof(TCP_PKG_DEF));

        if(send(fd, (char *)bodyBuf, sizeof(TCP_PKG_DEF), 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }

        if(recv(fd, lenBuf, 4, 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }
        lenBuf[4] = '\0';

        if(recv(fd, bodyBuf, atoi(lenBuf), 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }

        HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "f=:[%d]", f++); 
        memset(&tcpPkg, 0, sizeof(tcpPkg));
        HtMemcpy((char *)&tcpPkg, bodyBuf+6, sizeof(TCP_PKG_DEF));
        tcpPkg.reqId[4] = 0;
        tcpPkg.settleDate[8] = 0;
        tcpPkg.checkFlag[1] = 0;
        tcpPkg.redoFlag[1] = 0;
        tcpPkg.para[512] = 0;
        tcpPkg.respCode[2] = 0;

        HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPkg.respCode:[%s]",tcpPkg.respCode);
        if(memcmp(tcpPkg.respCode, "00", 2)==0)
        {
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, 
					"ret_len[%s], req_id[%s], settle_date[%s], check_flag[%s], redo_flag[%s], resp_code[%s], para[%s]",
					    lenBuf, tcpPkg.reqId, tcpPkg.settleDate, tcpPkg.checkFlag, tcpPkg.redoFlag, tcpPkg.respCode, tcpPkg.para);

            break;
        }else if(memcmp(tcpPkg.respCode,"01", 2)==0){
            return FAILURE;
        }else if(memcmp(tcpPkg.respCode, "04", 2)==0){
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "���·��ͱ���"); 
            sleep(30);
        }else {
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPkg.respCode:[%s]",tcpPkg.respCode);
            return FAILURE;
        }
    }
    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "�����ѷ���");

    close(fd);
#if 0
            printf("ret_len     = [%s] \n", lenBuf);

            printf("req_id      = [%s] \n", tcpPkg.reqId);
            printf("settle_date = [%s] \n", tcpPkg.settleDate);
            printf("check_flag  = [%s] \n", tcpPkg.checkFlag);
            printf("redo_flag   = [%s] \n", tcpPkg.redoFlag);
            printf("resp_code   = [%s] \n", tcpPkg.respCode);
            printf("para        = [%s] \n", tcpPkg.para);
#endif
    sleep(30);

    while(1)
    {
    	nReturnCode=DbsTblinfnodeStat(DBS_SELECT,cleanSt);
    	/*
        EXEC SQL select clean_st 
            into :cleanSt
            from tbl_inf_node_stat
            where ins_class='0';
		*/
        if(nReturnCode)
        {  
#if 0 
            if(nReturnCode==DBS_NOTFOUND)
                break;
            else 
            {
                HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "nReturnCode:[%d]", nReturnCode);
                break;
            }
#endif
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "nReturnCode:[%d]", nReturnCode);
            return FAILURE;
        }
        if (cleanSt[0] == '1'){
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "��������������У�");
            sleep(30);
        }
        else if(cleanSt[0] == '2'){
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "�������ɹ�������");
            break;
        }else if(cleanSt[0] == '3'){
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "��������쳣������");
            return FAILURE;
        }
    }
    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "����������");
    return SUCCESS;
}

/*socket����*/
int glbSocketConnect(char *hostName, char *tcpService, INT32 tcpPort,
        int *fd, INT32 *errCode)
{       
    struct sockaddr_in server;
    struct servent *sp; 
    struct hostent *hp;
    struct sigaction act, oact;
    unsigned long hostaddr;
    int mfd, oldalarm, ret;

    memset((char *)&server, 0, sizeof server);

    if(tcpService != NULL && strlen(rtrim(tcpService)) != 0)
    {       
        if((sp = (struct servent *)getservbyname(tcpService, "tcp")) == NULL)
        {
            *errCode = EID_GLB_INVALIDPARA;

            return FAILURE;
        }
        if(tcpPort > 0)
            server.sin_port = htons(tcpPort);
        else
            server.sin_port = sp->s_port;
    } else {
        if(tcpPort <= 0)
        {
            *errCode = EID_GLB_INVALIDPARA;

            return FAILURE;
        }

        server.sin_port = htons(tcpPort);
    }

    if((hostaddr = inet_addr(hostName)) != INADDR_NONE)
    {
        /* It is dotted_decimal */
        HtMemcpy((char *)&server.sin_addr, (char *)&hostaddr, sizeof(hostaddr));
        server.sin_family = AF_INET;
    } else {
        if((hp = (struct hostent *)gethostbyname(hostName)) == NULL)
        {
            *errCode = EID_GLB_UNKNOWHOST;

            return FAILURE;
        }
        HtMemcpy((char *)&server.sin_addr, hp->h_addr, hp->h_length);
        server.sin_family = hp->h_addrtype;
    }

    if((mfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        *errCode = EID_GLB_SOCKETINIT;

        return FAILURE;
    }

    sigaction(SIGALRM, NULL, &oact);
    act.sa_handler = (void (*)( ))glbSocketTimeOutHdlr;
    act.sa_mask = oact.sa_mask;
    act.sa_flags = oact.sa_flags;
    sigaction(SIGALRM, &act, NULL);

    glbTimeOut = FALSE;
    oldalarm = alarm(20);
    ret = connect(mfd, (struct sockaddr *)&server, sizeof server);
    sigaction(SIGALRM, &oact, NULL);
    alarm(oldalarm);
    if(ret < 0 || glbTimeOut)
    {
        *errCode = EID_GLB_SOCKETINIT;

        return FAILURE;
    }

    /*
       setNodelay(mfd);
     */
    *fd = mfd;

    return SUCCESS;
}

void glbSocketTimeOutHdlr(void)
{
    glbTimeOut = TRUE;
}
