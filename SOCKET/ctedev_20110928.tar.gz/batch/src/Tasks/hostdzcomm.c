/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_8001.pc                                                */
/* DESCRIPTIONS: check downloaded CUP files                                  */ 
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2009-12-04                                                                */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <netdb.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include "batch.h"
#include "glb/glbCommon.h"
#include "glb/glbSocket.h"
#include "Credit.h"

#define EID_GLB_DB               9902   
#define EID_GLB_INVALIDPARA      9918     /*��Ч����*/
#define EID_GLB_DAEMONRUNING     9919     /*���̳�ͻ*/
#define EID_GLB_UNKNOWHOST       9920     /*δ֪����*/
#define EID_GLB_SOCKETINIT       9921     /*��Ϣ���г�ʼ������*/
#define SLEEP_TIME               10

static int glbTimeOut = FALSE;

char    gLogFile[]="creditcomm.log";
char    ext_inter_brh_code[10+1];
int     ext_inter_brh_sta=0;

/* TCP������ñ���*/
typedef struct {
    char txnNum[4];
    char utId[10];
    char libOrPathName[10];
    char docName[10]; 
    char memberName[10];
    char date_settlmt[8];
    char rsp_code[2];
    char reserve1[60];
} TCP_PKG_DEF;
    

/*****************************************************************************/
/* FUNC:   int Task_0210(int nBeginOffset, int nEndOffset)                 */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   �������                                                          */
/*****************************************************************************/
int main( int argc, char **argv)
{
    int     f=0;
    int     i;
    int     nReturnCode;
    int     fd;
    char    lenBuf[5], bodyBuf[1024];
    char    svrIp[15];
	char    sTcpPort[10];
	fl0011_rsp ct_rsp;

    INT32 ret;
    INT32 tcpPort;
    TCP_PKG_DEF tcpPkg;

	bth_file_stat_def dbfilestat;
	host_file_rsp   filersp;
    char    sSqlBuf[SQL_BUF_LEN];
    char    swt_ssn[22+1];
    time_t  lTime;
    char    cTime[15];
    struct tm   *tTmLocal;
    char    ssn_tmp[6+1];
    int     seq_num;
    int     nTotalNum;


    memset(&tcpPkg, 0, sizeof(tcpPkg));
	memset(&dbfilestat,0,sizeof(dbfilestat));
	HtMemcpy(dbfilestat.date_settlmt,"20110329",8);
	HtMemcpy(dbfilestat.flag,"1",1);
	HtMemcpy(dbfilestat.libOrPathName,"BANK#SPDP",9);
	HtMemcpy(dbfilestat.docName,"PBYSUMP",7);
	HtMemcpy(dbfilestat.memberName,"CGB101000",9);
	HtMemcpy(dbfilestat.utId,"0000000025",10);
	dbfilestat.seq_num=1;
/*
	DbsConnect();
	nReturnCode=DbsBthFileTransState(DBS_SELECT,&dbfilestat,0);
	if(nReturnCode)
	{
		HtLog("creditcomm", HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "select DbsBthFileTransState error[%d]",nReturnCode);
		return -1;
	}
	DbsDisconnect();
*/

	memset(svrIp, 0, sizeof(svrIp));
	memset(sTcpPort, 0, sizeof(sTcpPort));
	HtStrcpy(sTcpPort, getenv("CGB_FILE_PORT"));
	tcpPort = atoi(sTcpPort);
	HtStrcpy(svrIp, getenv("CGB_FILE"));
    HtLog("creditcomm", HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPort:[%d]", tcpPort);
    HtLog("creditcomm", HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "IP:[%s]", svrIp);


    DbsConnect();
    memset(sSqlBuf, 0, SQL_BUF_LEN);
    sprintf(sSqlBuf, "select nextval for NATP_FILE_SSN_03060000  from SYSIBM.SYSDUMMY1");
    nReturnCode = SelectSequence(sSqlBuf, &nTotalNum);
    if( nReturnCode )
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select error[%d]",nReturnCode);
        return nReturnCode;
    }
    DbsDisconnect();
    memset(ssn_tmp,0,sizeof(ssn_tmp));
    sprintf(ssn_tmp,"%06d",nTotalNum);

    memset(svrIp, 0, sizeof(svrIp));
    memset(sTcpPort, 0, sizeof(sTcpPort));
    HtStrcpy(sTcpPort, getenv("CGB_FILE_PORT"));
    tcpPort = atoi(sTcpPort);
    HtStrcpy(svrIp, getenv("CGB_FILE"));
    HtLog("creditcomm", HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "tcpPort:[%d]", tcpPort);
    HtLog("creditcomm", HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "IP:[%s]", svrIp);

    memset(cTime,0,15);
    lTime = time (NULL);
    tTmLocal = localtime (&lTime);
    strftime(cTime, sizeof(cTime), "%Y%m%d%H%M%S",tTmLocal);
    memset(swt_ssn,0,sizeof(swt_ssn));
    HtSprintf(swt_ssn,"00%-14.14s%-6.6s",cTime,ssn_tmp);


    HtSprintf(lenBuf, "%04d", sizeof(tcpPkg));
    while(1)
    {
        if(glbSocketConnect(svrIp, NULL, tcpPort, &fd, &ret) != SUCCESS)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"svrIp:[%s], tcpPort:[%d], ret[%d], errno[%d], strerror(errno)[%s]", svrIp, tcpPort, ret, errno, strerror(errno));

            return FAILURE;
        }

        memset(bodyBuf, 0, sizeof(bodyBuf));
        memset(&tcpPkg, ' ', sizeof(tcpPkg));
        if(seq_num==0)
        {   
            HtMemcpy(tcpPkg.txnNum,"ZK02",4);
        }
        else
        {   
            HtMemcpy(tcpPkg.txnNum,"ZK03",4);
        }
        HtMemcpy(tcpPkg.utId,dbfilestat.utId,10);
        HtMemcpy(tcpPkg.date_settlmt,"20110426",8);
        HtMemcpy(tcpPkg.reserve1,"218",3);
        HtMemcpy(tcpPkg.reserve1+10,"FPSICAP",7);
		HtMemcpy(tcpPkg.reserve1+30,swt_ssn,22);
        HtMemcpy(bodyBuf,lenBuf,4);
        HtMemcpy(bodyBuf+4,(char *)&tcpPkg,sizeof(tcpPkg));
        if(send(fd, (char *)bodyBuf, sizeof(tcpPkg)+4, 0) <= 0)
        {
			HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }
		HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,"tcpPkg[%s]",bodyBuf+4);
		HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__,"msg is send,please waiting recv");

        if(recv(fd, lenBuf, 4, 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }
        lenBuf[4] = '\0';

        HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "lenth[%d]",atoi(lenBuf));
        if(recv(fd, bodyBuf, atoi(lenBuf), 0) <= 0)
        {
			HtLog(gLogFile, HT_LOG_MODE_ERROR, __FILE__, __LINE__, 
					"errno[%d], strerror(errno)[%s]", errno, strerror(errno));

            return FAILURE;
        }
        memset(&filersp,0x00,sizeof(filersp));
        HtMemcpy(&filersp,bodyBuf,sizeof(filersp));

        if(memcmp(filersp.rsp_code, "01", 2)==0)
        {
			HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "generate the file success[%s]",bodyBuf);
            close(fd);
            sleep(SLEEP_TIME);
            seq_num=1; 
        }
        else if(memcmp(filersp.rsp_code, "00", 2)==0)
        {
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "generate the file success[%s]",bodyBuf);
            break;
        }
        else
        {
            HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "generate the file failed[%s]",bodyBuf);
            close(fd); 
            return FAILURE; 
        }

    }
    close(fd);
    return SUCCESS;
}

/*socket����*/
int glbSocketConnect(char *hostName, char *tcpService, INT32 tcpPort,
        int *fd, INT32 *errCode)
{       
    struct sockaddr_in server;
    struct servent *sp; 
    struct hostent *hp;
    struct sigaction act, oact;
    unsigned long hostaddr;
    int mfd, oldalarm, ret;

    memset((char *)&server, 0, sizeof server);

    if(tcpService != NULL && strlen(rtrim(tcpService)) != 0)
    {       
        if((sp = (struct servent *)getservbyname(tcpService, "tcp")) == NULL)
        {
            *errCode = EID_GLB_INVALIDPARA;

            return FAILURE;
        }
        if(tcpPort > 0)
            server.sin_port = htons(tcpPort);
        else
            server.sin_port = sp->s_port;
    } else {
        if(tcpPort <= 0)
        {
            *errCode = EID_GLB_INVALIDPARA;

            return FAILURE;
        }

        server.sin_port = htons(tcpPort);
    }

    if((hostaddr = inet_addr(hostName)) != INADDR_NONE)
    {
        HtMemcpy((char *)&server.sin_addr, (char *)&hostaddr, sizeof(hostaddr));
        server.sin_family = AF_INET;
    } else {
        if((hp = (struct hostent *)gethostbyname(hostName)) == NULL)
        {
            *errCode = EID_GLB_UNKNOWHOST;

            return FAILURE;
        }
        HtMemcpy((char *)&server.sin_addr, hp->h_addr, hp->h_length);
        server.sin_family = hp->h_addrtype;
    }

    if((mfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        *errCode = EID_GLB_SOCKETINIT;

        return FAILURE;
    }

    sigaction(SIGALRM, NULL, &oact);
    act.sa_handler = (void (*)( ))glbSocketTimeOutHdlr;
    act.sa_mask = oact.sa_mask;
    act.sa_flags = oact.sa_flags;
    sigaction(SIGALRM, &act, NULL);

    glbTimeOut = FALSE;
    oldalarm = alarm(20);
    ret = connect(mfd, (struct sockaddr *)&server, sizeof server);
    sigaction(SIGALRM, &oact, NULL);
    alarm(oldalarm);
    if(ret < 0 || glbTimeOut)
    {
        *errCode = EID_GLB_SOCKETINIT;

        return FAILURE;
    }

    *fd = mfd;

    return SUCCESS;
}

void glbSocketTimeOutHdlr(void)
{
    glbTimeOut = TRUE;
}
