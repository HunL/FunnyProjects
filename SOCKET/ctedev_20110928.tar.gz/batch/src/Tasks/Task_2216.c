/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_2201.pc                                                */
/* DESCRIPTIONS: Confirm posp_ic_offline_dtl_tmp									 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2011-05-05  sunyd          initial                                        */
/*****************************************************************************/

#include "batch.h"
#include "DbsTbl.h"


char	gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[INTER_BRH_CODE_LEN + 1];

int Total_2216()
{
    int nReturnCode=0;
    int nTotalNum=0 ;
    tbl_ic_offline_txn_def dbdtl_offline_tmp;
    memset(&dbdtl_offline_tmp,0x00,sizeof(dbdtl_offline_tmp));
    nReturnCode=gfDtlOfflineTmp(DBS_SELECT,&dbdtl_offline_tmp,0,0);
    nTotalNum=dbdtl_offline_tmp.seq_num;
    if(nReturnCode && nReturnCode != DBS_FETCHNULL)
    {
        HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"select from posp_ic_offline_dtl_tmp error, sqlcode=[%d].", nReturnCode);
        return-1 ;
    }
    HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"nTotalNum =[%d].",nTotalNum);
    return nTotalNum;
}
int Task_2216 ( int nBeginOffset, int nEndOffset )
{
	tbl_ic_offline_txn_def dbdtl_offline_tmp; 

    int nReturnCode = 0; 

    memset(&dbdtl_offline_tmp,0x00,sizeof(dbdtl_offline_tmp));
    HtMemcpy(dbdtl_offline_tmp.inter_brh_code,ext_inter_brh_code,10);
    HtMemcpy(dbdtl_offline_tmp.date_settlmt,dbtbl_date_inf.stoday,8);
	gfDtlOfflineTmp(DBS_CURSOR,&dbdtl_offline_tmp,nBeginOffset,nEndOffset); 
	nReturnCode=gfDtlOfflineTmp(DBS_OPEN,&dbdtl_offline_tmp,nBeginOffset,nEndOffset);
	if(nReturnCode)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "OPEN CURSOR posp_ic_offline_dtl_tmp error sqlcode=[%d].\n", nReturnCode);
		return -1;
	}
	while(1)
	{
		memset(&dbdtl_offline_tmp,0x00,sizeof(dbdtl_offline_tmp));
		nReturnCode=gfDtlOfflineTmp(DBS_FETCH,&dbdtl_offline_tmp,nBeginOffset,nEndOffset);  

		if(nReturnCode && nReturnCode != DBS_FETCHNULL)
		{
			if(nReturnCode ==DBS_NOTFOUND)
			{
				break;
			}
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "FETCH CURSOR posp_ic_offline_dtl_tmp error sqlcode=[%d].\n", nReturnCode);
			return -1;
		}
		nReturnCode = gfDtlOfflineTmp(DBS_INSERT1, &dbdtl_offline_tmp,nBeginOffset,nEndOffset);
		if (nReturnCode)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Insert into posp_ic_offline_dtl error sqlcode=[%d].\n", nReturnCode);
			gfDtlOfflineTmp(DBS_CLOSE,&dbdtl_offline_tmp,nBeginOffset,nEndOffset);
			return -1;
		}
		DbsCommit ();
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Success~ Import into posp_ic_offline_dtl_tmp from posp_ic_offline_dtl_tmp_tmp sqlcode=[%d].\n", nReturnCode);
	}
	gfDtlOfflineTmp(DBS_CLOSE,&dbdtl_offline_tmp,nBeginOffset,nEndOffset);
	return 0;
}
