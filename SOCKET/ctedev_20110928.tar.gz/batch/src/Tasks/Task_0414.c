/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_2602.pc                                                */
/* DESCRIPTIONS: load cup bdt file											 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23                                                                */
/*****************************************************************************/

#include "batch.h"
#include "tbl_opr.h"

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;

char cup_brh_id[8 + 1];
char inter_inst_id[6+1];
static int nLoadTxnFromFile (char *sType, char *sDate, stFileDef *pstFile);

/* get all existing filenames */
static int nGetAllFiles(char *sPath, int nPattern, Tbl_txn_file_ptn_Def astTxnFilePtn[],
                 int *pnFileCount, stFileDef  *pstTmpFile, char *sDate, char *sCupBrhId)
{
    char    *pstr;
    int     i, j, k;
    char    sPatternName[FILE_NAME_LEN_MAX+1];
    int     nReturnCode;
    glob_t  globbuf;

    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "nPattern[%d]", nPattern);
    for( k=0; k< (*pnFileCount); k++) pstTmpFile ++;

    for (i = 0; i < nPattern; i++)
    {
        /* replace YYYYMMDD with date */
        pstr = strstr (astTxnFilePtn[i].pattern_val, "YYYY");
        if (pstr) HtMemcpy (pstr, sDate, 4);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "YY");
        if (pstr) HtMemcpy (pstr, sDate+2, 2);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "MM");
        if (pstr) HtMemcpy (pstr, sDate+4, 2);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "DD");
        if (pstr) HtMemcpy (pstr, sDate+6, 2);

        /* get file name compatible with pattern */
        HtSprintf (sPatternName, "%s/%s", sPath, astTxnFilePtn[i].pattern_val);
        CommonRTrim (sPatternName);
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "search for pattern %s.", sPatternName);
        nReturnCode = glob (sPatternName, GLOB_NOSORT, NULL, &globbuf);
        if (nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "glob error, %d.", nReturnCode);
            globfree (&globbuf);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "find %d matched files.", globbuf.gl_pathc);

        /* save file name */
        for (j = 0; j < globbuf.gl_pathc; j++)
        {
            HtStrcpy (pstTmpFile->sCompKey, astTxnFilePtn[i].comp_key);
            if (strlen (globbuf.gl_pathv[j]) < FILE_NAME_LEN_MAX)
            {
                HtStrcpy (pstTmpFile->sFileName, globbuf.gl_pathv[j]);
                HtMemcpy (pstTmpFile->sInterInstId, sCupBrhId, 10);
            }
            else
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file name too long.");
                globfree (&globbuf);
                return -1;
            }
            pstTmpFile ++;
            *pnFileCount = *pnFileCount + 1;
            if (*pnFileCount >= FILE_COUNT_MAX)
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "too many matched files.");
                globfree (&globbuf);
                return -1;
            }
        }
        globfree (&globbuf);
        
    }
    return 0;
}

/*****************************************************************************/
/* FUNC:   int nGetFileName (char *sType, char *sDate, int *pnFileCount,     */
/*                           stFileDef *pstFileDef)                          */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP, RCUP, ERR,RERR ,LOGO            */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/* OUTPUT: pnFileCount: ��ˮ�ļ�����                                         */
/*         stFileDef: ��ˮ�ļ���Ϣ                                           */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���ĳ����ˮ�ļ����ļ���                                          */
/*****************************************************************************/
static int nGetFileName (char *sType, char *sDate, int *pnFileCount, stFileDef *pstFile)
{

    char    sPath[FILE_NAME_LEN_MAX+1];
    char    sTmpPath[FILE_NAME_LEN_MAX+1];
    int     nReturnCode = 0;
    int     nPattern;

    Tbl_txn_file_ptn_Def    astTxnFilePtn[PATTERN_COUNT_MAX];
    stFileDef               *pstTmpFile;

    *pnFileCount = 0;
    pstTmpFile 	 = pstFile;

    memset(cup_brh_id,0x00,sizeof(cup_brh_id));
    nReturnCode = DbsTblcst_brh_cup_inf(DBS_CURSOR, ext_inter_brh_code, cup_brh_id);
    if (nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DECLARE cursor ERROR! sqlcode[%d].", nReturnCode);
        return -1;
    }


    DbsTblcst_brh_cup_inf(DBS_OPEN, ext_inter_brh_code,cup_brh_id);
	while(1)
	{
        nReturnCode = DbsTblcst_brh_cup_inf(DBS_FETCH, ext_inter_brh_code,cup_brh_id);
        if(nReturnCode)
            break;

        memset( &astTxnFilePtn, 0, sizeof(Tbl_txn_file_ptn_Def)*PATTERN_COUNT_MAX);
        nPattern = 1;
		/* get file path */
		memset (sPath, 0, sizeof (sPath));
		HtSprintf(sPath, "%s/%8.8s/%s/CUP/%s", getenv("BATCH_FILE_PATH"), sDate, getenv("CUP_ID"), cup_brh_id);
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sPath %s ", sPath);
		HtStrcpy(astTxnFilePtn[0].pattern_val,"INDYYMMDD*IERRN");
		HtStrcpy(astTxnFilePtn[0].comp_key,"ERR");

		memset (sTmpPath, 0, sizeof(sTmpPath));
		HtMemcpy (sTmpPath, sPath, sizeof(sPath));
		HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTmpPath[%s]", sTmpPath);            

		nReturnCode = nGetAllFiles(sTmpPath, nPattern, astTxnFilePtn, pnFileCount, pstTmpFile, sDate, cup_brh_id);
		if(nReturnCode != 0)
		{
			return nReturnCode;
		}
	}

    DbsTblcst_brh_cup_inf(DBS_CLOSE, ext_inter_brh_code,cup_brh_id);
    return 0;
}


/*****************************************************************************/
/* FUNC:   int Total_0404()                                                  */
/* INPUT:  ��                                                                */
/* OUTPUT: nFileCount: ��ˮ�ļ�����                                          */
/* RETURN: nFileCount: �ɹ�, -1: ʧ��                                        */
/* DESC:   ���Ҫ�����������ˮ�ļ��ĸ���                                    */
/*****************************************************************************/
int Total_0414()
{
    char       sDate[DATE_LEN + 1];        /*����*/
    int        nReturnCode;
    stFileDef  stFile[FILE_COUNT_MAX];     /*һ�������ļ���Ϣ�Ľṹ������*/
    int        nFileCount;                 /*Ҫ��õ�����tdb��ˮ�ļ�����*/
    char       sType[8];                   /*������ˮ�ļ�����--bdt */

    memset(sType,0,sizeof(sType));
    HtMemcpy(sType,"ERR",3);

    /*�������*/
    HtStrcpy(sDate,dbtbl_date_inf.stoday);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Task_0405:sDate=%s\n",sDate);

    /*�����ˮ�ļ������������Ϣ*/
	memset(&stFile,0x00,sizeof(stFile));
    nReturnCode = nGetFileName (sType, sDate, &nFileCount, stFile);
    if (nReturnCode)
    {
          HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nGetFileName for %s on %s error, %d.", sType, sDate, nReturnCode);
          return -1;
    }

    HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nGetFileName for %s success, find %d files.", sType, nFileCount);

    if( nFileCount == 0)
       return -1;

    return nFileCount;
}

/*****************************************************************************/
/* FUNC:   int Task_0404(int nBeginOffset, int nEndOffset)                   */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   װ������LOGO����                                                */
/*****************************************************************************/
int Task_0414 ( int nBeginOffset, int nEndOffset )
{
    int     	i;
    int     	nReturnCode;
    char    	sDate[DATE_LEN + 1];              /*����*/
    char    	sType[8];                         /*������ˮ�ļ�����--bdt*/
    int     	nFileCount;                       /*Ҫ��õ�����tdb��ˮ�ļ�����*/
    stFileDef   stFile[FILE_COUNT_MAX];       /*һ�������ļ���Ϣ�Ľṹ������*/

    memset(sType,0,sizeof(sType));
    HtMemcpy(sType,"ERR",3);

    /*�������*/
    HtStrcpy(sDate,dbtbl_date_inf.stoday);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Task_0405:sDate=%s\n",sDate);

    /*�����ˮ�ļ������������Ϣ*/
    memset( (char *)&stFile, 0, sizeof(stFile));
    nReturnCode = nGetFileName (sType, sDate, &nFileCount, stFile);
    if (nReturnCode)
    {
          HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nGetFileName for %s on %s error, %d.", sType, sDate, nReturnCode);
          return -1;
    }
      HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nGetFileName for %s success, find %d files.", sType, nFileCount);

    /*װ���ļ������ݿ����*/
    for (i = nBeginOffset - 1; i < nEndOffset; i++)
    {
        nReturnCode = nLoadTxnFromFile (sType, sDate, &stFile[i]);
        if (nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nLoadTxnFromFile for %s error, %d.", stFile[i].sFileName, nReturnCode);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nLoadTxnFromFile for %s success.", stFile[i].sFileName);
    }

    return 0;
}


/*****************************************************************************/
/* FUNC:   int nLoadTxnFromFile (char *sType, char *sDate,                   */
/*                               stFileDef *pstFile)                         */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP_BDT,CUP_TDB,RCUP,ERR,RERR,LOGO   */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/*         pstFile: ��ˮ�ļ���Ϣ                                             */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ĳ����ˮ�ļ�������װ�ص����ݿ���                                */
/*****************************************************************************/
static int nLoadTxnFromFile (char *sType, char *sDate, stFileDef *pstFile)
{
    int   	i;
	int		j;
	int  	bin_num; 
    char    sTxnNum[5];
    char    sFileRecord[RECORD_LEN_MAX+1];
    char    sDbRecord[RECORD_LEN_MAX+1];
	char	sFileNameMz[FILE_NAME_LEN_MAX+1];
    char        afile_name[FILE_NAME_LEN_MAX+1];
        char        afile_bak[FILE_NAME_LEN_MAX+1];
    char    file_type[9];
	char cmd[200];
        struct stat stat_buf;
        tbl_file_trans_def dbTblfiletrans;
    int     nBufChgIndex;
    int 	nDestMsgLen;
    int 	nReturnCode;
    int 	nRecordNum;
	long    file_size;
	char    *p;
    FILE    *fp;
    FILE    *fp1;
    FILE    *fp_mz;
    int     nFlag;
	tbl_bank_bin_inf_def bank_bin[MAXMISNS];
	tbl_bank_bin_inf_def dbbank_bin;

    nRecordNum  = 0;

    fp = fopen (pstFile->sFileName, "r");
    if (!fp)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", pstFile->sFileName, errno);
        return -1;
    }
    memset( file_type, 0, sizeof(file_type));
    HtMemcpy(file_type,pstFile->sFileName+strlen(pstFile->sFileName)-5,5);
	
    p=strrchr(pstFile->sFileName,'/');
    memcpy(afile_name,pstFile->sFileName,p-(pstFile->sFileName));
    strcat(afile_name,"/");
    strcat(afile_name,"POSMD");
    nReturnCode = CheckDir( afile_name );
    if(nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Create directory error: [%s].", afile_name );
    }
        strcat(afile_name,p);
        memset(afile_bak,0,sizeof(afile_bak));
        sprintf(afile_bak,"%s.bak.union",afile_name);
    memset(sFileNameMz,0,sizeof(sFileNameMz));
    sprintf(sFileNameMz,"%s/%s/%s/%s",getenv("BATCH_FILE_PATH"),dbtbl_date_inf.stoday,getenv("CUP_ID"),SB_FILE_PATH);
    nReturnCode=CheckDir(sFileNameMz);
    if(nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__,"Create directory error: [%s].", sFileNameMz);
        return -1;
    }       
    strcat(sFileNameMz,"/");
    strcat(sFileNameMz,p+1);

	fp_mz=fopen(sFileNameMz,"wb");
	if(!fp_mz)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.",sFileNameMz,errno);
		return -1;
	}	
        fp1=fopen(afile_name,"wb");
        if(!fp1)
        {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.",afile_name,errno);
                fclose(fp_mz);
                return -1;
        }

	bin_num= 0;
	memset(bank_bin,0x00,sizeof(bank_bin));
	memset(&dbbank_bin,0x00,sizeof(dbbank_bin));
	HtMemcpy(dbbank_bin.ins_id_cd,"03060000",8);
	HtMemcpy(dbbank_bin.card_tp,"04",2);
	DbsBankBinInf(DBS_CURSOR,&dbbank_bin);
	nReturnCode=DbsBankBinInf(DBS_OPEN,&dbbank_bin);
	while(1)
	{
		memset(bank_bin,0x00,sizeof(bank_bin));
		nReturnCode=DbsBankBinInf(DBS_FETCH,&dbbank_bin);
		if(nReturnCode)
		{
			if(nReturnCode==DBS_NOTFOUND)
			{
				break;
			}
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fetch bank bin error[%d]",nReturnCode);
			DbsBankBinInf(DBS_CLOSE,&dbbank_bin);
			return -1;
		}
		bank_bin[bin_num].bin_len=dbbank_bin.bin_len;
		HtMemcpy(bank_bin[bin_num].bin_sta_no,dbbank_bin.bin_sta_no,strlen(dbbank_bin.bin_sta_no));
		HtMemcpy(bank_bin[bin_num].bin_end_no,dbbank_bin.bin_end_no,strlen(dbbank_bin.bin_end_no));
		bin_num++;
	}
	DbsBankBinInf(DBS_CLOSE,&dbbank_bin);

    /* get file record */
	i=0;
    while (1)
    {
        memset(sFileRecord	, 0, sizeof(sFileRecord));
        memset(sDbRecord	, ' ', sizeof(sDbRecord)	);

        if (fgets (sFileRecord, RECORD_LEN_MAX, fp) == NULL)
        {
            nReturnCode = 0;
            break;
        }

		for(j=0;j<bin_num;j++)
		{
			if((memcmp(sFileRecord+46,bank_bin[j].bin_sta_no,bank_bin[j].bin_len)>=0) \
				&&(memcmp(sFileRecord+46,bank_bin[j].bin_end_no,bank_bin[j].bin_len)<=0))
			{
				break;
			}
		}	
		if(j==bin_num)
		{
			fprintf(fp1,"%s",sFileRecord);
			continue;
		}
		else
		{
			fprintf(fp_mz,"%s",sFileRecord);
		}

        /* change file record to db record */
        nReturnCode = IpcDftOpr(pstFile->sCompKey, &nDestMsgLen, sDbRecord,
                                sTxnNum, &nBufChgIndex, &gtIpcDftRule);
        if (nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "IpcDftOpr error, %d.", nReturnCode);
            break;
        }

        nReturnCode = BufChgOpr(nBufChgIndex,
                                sFileRecord,
                                sDbRecord,
                                &gtBufChgRule);
        if(nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "BufChgOpr error, %d.", nReturnCode);
            HtDebugString (gLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, sDbRecord, sizeof (sDbRecord));
            break;
        }

        HtMemcpy (sDbRecord, sDate, DATE_LEN);
        /* �����ݿ��в����¼ʱ���������ϵ���������ֶ� */
        i ++;

        /* insert into db */
        /*�����������ˮ���� bth_cup_err ����*/
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file_type[%s]",file_type);
        nReturnCode = DbsCupTxn (DBS_INSERT1, sDbRecord, file_type, &ipcRuleInf, 1, i, pstFile->sInterInstId,ext_inter_brh_code);
        if (nReturnCode==DBS_KEYDUPLICATE)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsCupTxn DBS_INSERT error, %d.sDbRecord=%s", nReturnCode,sDbRecord);
            continue;
        }
        if (nReturnCode!=0 && nReturnCode!=DBS_KEYDUPLICATE )
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsCupTxn DBS_INSERT error, %d.", nReturnCode);
            HtDebugString (gLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, sDbRecord, sizeof (sDbRecord));
            break;
        }

        nRecordNum ++;
    }
    /* close file */
    fclose (fp);
    fclose (fp_mz);
	fclose(fp1);

    memset(&stat_buf,0x00,sizeof(stat_buf));
    if(stat(afile_name,&stat_buf)==-1)
    {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "����stat error[%s][%d]",afile_name,errno);
            return -1;
    }
    file_size=stat_buf.st_size;
    memset(&dbTblfiletrans,0,sizeof(dbTblfiletrans));
    p=strrchr(afile_name,'/');
    strcpy(dbTblfiletrans.inter_brh_code,"03060000");
    strcpy(dbTblfiletrans.sa_file_name,p+1);
    strcpy(dbTblfiletrans.sa_stlm_inst_id,"03065800");
    strcpy(dbTblfiletrans.sa_file_flg,"R");
    strcpy(dbTblfiletrans.sa_compress_flg,"N");
    strcpy(dbTblfiletrans.sa_file_stat,"3");
    strcpy(dbTblfiletrans.sa_trace_log,"����POS�����޸�");
    HtSprintf(dbTblfiletrans.sa_file_length,"%010ld",file_size);
    nReturnCode=lQTblFileTransOpr(NTblUpdate1,&dbTblfiletrans);
    if(nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_file_name[%s]",dbTblfiletrans.sa_file_name);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_file_flg[%s]",dbTblfiletrans.sa_file_flg);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sa_stlm_inst_id[%s]",dbTblfiletrans.sa_stlm_inst_id);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "update tbl_file_trans error[%d]",glSysError);
        return -1;
    }
        memset(cmd,0,sizeof(cmd));
        HtSprintf(cmd,"mv %s %s",pstFile->sFileName,afile_bak);
        system(cmd);
    memset(cmd,0,sizeof(cmd));
    HtSprintf(cmd,"cp %s %s",afile_name,pstFile->sFileName);
    system(cmd);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file sum success");
    return nReturnCode;
}
