/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_2602.pc                                                */
/* DESCRIPTIONS: load cup bdt file											 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-23                                                                */
/*****************************************************************************/

#include "batch.h"

extern  char    gLogFile[LOG_NAME_LEN_MAX];
extern  		tbl_date_inf_def dbtbl_date_inf;
extern	char	ext_inter_brh_code[10+1];
extern	int		ext_inter_brh_sta;

char cup_brh_id[8 + 1];
char inter_inst_id[6+1];
static int nLoadTxnFromFile (char *sType, char *sDate, stFileDef *pstFile);

/* get all existing filenames */
static int nGetAllFiles(char *sPath, int nPattern, Tbl_txn_file_ptn_Def astTxnFilePtn[],
                 int *pnFileCount, stFileDef  *pstTmpFile, char *sDate, char *sCupBrhId)
{
    char    *pstr;
    int     i, j, k;
    char    sPatternName[FILE_NAME_LEN_MAX+1];
    int     nReturnCode;
    glob_t  globbuf;

    HtLog(gLogFile, HT_LOG_MODE_NORMAL, __FILE__, __LINE__, "nPattern[%d]", nPattern);
    for( k=0; k< (*pnFileCount); k++) pstTmpFile ++;

    for (i = 0; i < nPattern; i++)
    {
        /* replace YYYYMMDD with date */
        pstr = strstr (astTxnFilePtn[i].pattern_val, "YYYY");
        if (pstr) HtMemcpy (pstr, sDate, 4);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "YY");
        if (pstr) HtMemcpy (pstr, sDate+2, 2);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "MM");
        if (pstr) HtMemcpy (pstr, sDate+4, 2);
        pstr = strstr (astTxnFilePtn[i].pattern_val, "DD");
        if (pstr) HtMemcpy (pstr, sDate+6, 2);

        /* get file name compatible with pattern */
        HtSprintf (sPatternName, "%s/%s", sPath, astTxnFilePtn[i].pattern_val);
        CommonRTrim (sPatternName);
        HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "search for pattern %s.", sPatternName);
        nReturnCode = glob (sPatternName, GLOB_NOSORT, NULL, &globbuf);
        if (nReturnCode && nReturnCode != GLOB_NOMATCH)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "glob error, %d.", nReturnCode);
            globfree (&globbuf);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "find %d matched files.", globbuf.gl_pathc);

        /* save file name */
        for (j = 0; j < globbuf.gl_pathc; j++)
        {
            HtStrcpy (pstTmpFile->sCompKey, astTxnFilePtn[i].comp_key);
            if (strlen (globbuf.gl_pathv[j]) < FILE_NAME_LEN_MAX)
            {
                HtStrcpy (pstTmpFile->sFileName, globbuf.gl_pathv[j]);
                HtMemcpy (pstTmpFile->sInterInstId, sCupBrhId, 10);
            }
            else
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file name too long.");
                globfree (&globbuf);
                return -1;
            }
            pstTmpFile ++;
            *pnFileCount = *pnFileCount + 1;
            if (*pnFileCount >= FILE_COUNT_MAX)
            {
                HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "too many matched files.");
                globfree (&globbuf);
                return -1;
            }
        }
        globfree (&globbuf);
        
    }
    return 0;
}

/*****************************************************************************/
/* FUNC:   int nGetFileName (char *sType, char *sDate, int *pnFileCount,     */
/*                           stFileDef *pstFileDef)                          */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP, RCUP, ERR,RERR ,LOGO            */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/* OUTPUT: pnFileCount: ��ˮ�ļ�����                                         */
/*         stFileDef: ��ˮ�ļ���Ϣ                                           */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ���ĳ����ˮ�ļ����ļ���                                          */
/*****************************************************************************/
static int nGetFileName (char *sType, char *sDate, int *pnFileCount, stFileDef *pstFile)
{

    char    sPath[FILE_NAME_LEN_MAX+1];
    char    sTmpPath[FILE_NAME_LEN_MAX+1];
    int     nReturnCode = 0;
    int     nPattern;

    Tbl_txn_file_ptn_Def    astTxnFilePtn[PATTERN_COUNT_MAX];
    stFileDef               *pstTmpFile;

    *pnFileCount = 0;
    pstTmpFile 	 = pstFile;

    memset(cup_brh_id,0x00,sizeof(cup_brh_id));
    nReturnCode = DbsTblcst_brh_cup_inf(DBS_CURSOR, ext_inter_brh_code, cup_brh_id);
    if (nReturnCode)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DECLARE cursor ERROR! sqlcode[%d].", nReturnCode);
        return -1;
    }


        DbsTblcst_brh_cup_inf(DBS_OPEN, ext_inter_brh_code,cup_brh_id);
	while(1)
	{
           nReturnCode = DbsTblcst_brh_cup_inf(DBS_FETCH, ext_inter_brh_code,cup_brh_id);
        if(nReturnCode)
            break;

        memset( &astTxnFilePtn, 0, sizeof(Tbl_txn_file_ptn_Def)*PATTERN_COUNT_MAX);
        nPattern = 0;
		/* get file pattern */
		HtStrcpy (astTxnFilePtn[0].file_type, sType);
		nReturnCode = DbsTxnFilePtnLoad (&nPattern, astTxnFilePtn, cup_brh_id);
		if (nReturnCode)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsTxnFilePtnLoad %s error, %d.", sType, nReturnCode);
			return -1;
		}

		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nPattern %d ", nPattern);
		if (nPattern == 0)
            continue;

		/* get file path */
		memset (sPath, 0, sizeof (sPath));
		HtSprintf(sPath, "%s/%8.8s/%s/CUP/%s", getenv("BATCH_FILE_PATH"), sDate, getenv("CUP_ID"), cup_brh_id);
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sPath %s ", sPath);

		memset (sTmpPath, 0, sizeof(sTmpPath));
		HtMemcpy (sTmpPath, sPath, sizeof(sPath));
		HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "sTmpPath[%s]", sTmpPath);            

		nReturnCode = nGetAllFiles(sTmpPath, nPattern, &astTxnFilePtn, pnFileCount, pstTmpFile, sDate, ext_inter_brh_code);
		if(nReturnCode != 0)
		{
			return nReturnCode;
		}
	}

        DbsTblcst_brh_cup_inf(DBS_CLOSE, ext_inter_brh_code,cup_brh_id);
    return 0;
}


/*****************************************************************************/
/* FUNC:   int Total_0405()                                                  */
/* INPUT:  ��                                                                */
/* OUTPUT: nFileCount: ��ˮ�ļ�����                                          */
/* RETURN: nFileCount: �ɹ�, -1: ʧ��                                        */
/* DESC:   ���Ҫ�����������ˮ�ļ��ĸ���                                    */
/*****************************************************************************/
int Total_0405()
{
    char       sDate[DATE_LEN + 1];        /*����*/
    int        nReturnCode;
    stFileDef  stFile[FILE_COUNT_MAX];     /*һ�������ļ���Ϣ�Ľṹ������*/
    int        nFileCount;                 /*Ҫ��õ�����bdt��ˮ�ļ�����*/
    char       sType[8];                   /*������ˮ�ļ�����--bdt */

    memset(sType,0,sizeof(sType));
    HtMemcpy(sType,"CUP_BDT",7);

    /*�������*/
    HtStrcpy(sDate,dbtbl_date_inf.stoday);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Task_0405:sDate=%s\n",sDate);

    /*�����ˮ�ļ������������Ϣ*/
	memset(&stFile,0x00,sizeof(stFile));
    nReturnCode = nGetFileName (sType, sDate, &nFileCount, stFile);
    if (nReturnCode)
    {
          HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nGetFileName for %s on %s error, %d.", sType, sDate, nReturnCode);
          return -1;
    }

    HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nGetFileName for %s success, find %d files.", sType, nFileCount);

    if( nFileCount == 0)
       return -1;

    return nFileCount;
}

/*****************************************************************************/
/* FUNC:   int Task_0405(int nBeginOffset, int nEndOffset)                   */
/* INPUT:  nBeginOffset:�ύ��ʼ�㣬nEndOffset:�ύ������                    */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, -1: ʧ��                                                 */
/* DESC:   װ������LOGO����                                                */
/*****************************************************************************/
int Task_0405 ( int nBeginOffset, int nEndOffset )
{
    int     	i;
    int     	nReturnCode;
    char    	sDate[DATE_LEN + 1];              /*����*/
    char    	sType[8];                         /*������ˮ�ļ�����--bdt*/
    int     	nFileCount;                       /*Ҫ��õ�����bdt��ˮ�ļ�����*/
    stFileDef   stFile[FILE_COUNT_MAX];       /*һ�������ļ���Ϣ�Ľṹ������*/

    memset(sType,0,sizeof(sType));
    HtMemcpy(sType,"CUP_BDT",7);

    /*�������*/
    HtStrcpy(sDate,dbtbl_date_inf.stoday);
    HtLog (gLogFile, HT_LOG_MODE_DEBUG, __FILE__,__LINE__, "Task_0405:sDate=%s\n",sDate);

    /*�����ˮ�ļ������������Ϣ*/
    memset( (char *)&stFile, 0, sizeof(stFile));
    nReturnCode = nGetFileName (sType, sDate, &nFileCount, stFile);
    if (nReturnCode)
    {
          HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nGetFileName for %s on %s error, %d.", sType, sDate, nReturnCode);
          return -1;
    }
      HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nGetFileName for %s success, find %d files.", sType, nFileCount);

    /*װ���ļ������ݿ����*/
    for (i = nBeginOffset - 1; i < nEndOffset; i++)
    {
        nReturnCode = nLoadTxnFromFile (sType, sDate, &stFile[i]);
        if (nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "nLoadTxnFromFile for %s error, %d.", stFile[i].sFileName, nReturnCode);
            return -1;
        }
        HtLog (gLogFile, HT_LOG_MODE_NORMAL, __FILE__,__LINE__, "nLoadTxnFromFile for %s success.", stFile[i].sFileName);
    }

    return 0;
}

/*****************************************************************************/
/* FUNC:   int nLoadTxnFromFile (char *sType, char *sDate,                   */
/*                               stFileDef *pstFile)                         */
/* INPUT:  sType: ��ˮ�ļ�����, �Ϸ�ֵ: CUP_BDT,CUP_TDB,RCUP,ERR,RERR,LOGO   */
/*         sDate: ��ˮ�ļ�����, YYYYMMDD                                     */
/*         pstFile: ��ˮ�ļ���Ϣ                                             */
/* OUTPUT: ��                                                                */
/* RETURN: 0: �ɹ�, ����: ʧ��                                               */
/* DESC:   ��ĳ����ˮ�ļ�������װ�ص����ݿ���                                */
/*****************************************************************************/
static int nLoadTxnFromFile (char *sType, char *sDate, stFileDef *pstFile)
{
    int   i;
    char    sTxnNum[5];
    char    sFileRecord[RECORD_LEN_MAX+1];
    char    sDbRecord[RECORD_LEN_MAX+1];
	char    sFileNameMz[FILE_NAME_LEN_MAX+1];
    char    file_type[9];
    int     nBufChgIndex;
    int 	nDestMsgLen;
    int 	nReturnCode;
    int 	nRecordNum;
    FILE    *fp;
    FILE    *fp_mz;
    int     nFlag;

    i  			= 0;
    nRecordNum  = 0;

	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "pstFile[%s]",pstFile->sFileName);		
	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "pstFile[%s]",pstFile->sCompKey);		
    fp = fopen (pstFile->sFileName, "r");
    if (!fp)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.", pstFile->sFileName, errno);
        return -1;
    }
    memset( file_type, 0, sizeof(file_type));
    if(!strcmp (sType, TYPE_RCUP))
        HtMemcpy(file_type,pstFile->sFileName+strlen(pstFile->sFileName)-9,5);
    else
        HtMemcpy(file_type,pstFile->sFileName+strlen(pstFile->sFileName)-5,5);

#if 0
    if(!memcmp(file_type+1,"ACOM",4))
    {   
        memset(sFileNameMz,0,sizeof(sFileNameMz));
        sprintf(sFileNameMz,"%s%s",pstFile->sFileName,"_MZ");
        fp_mz=fopen(sFileNameMz,"wb");
        if(!fp_mz)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fopen %s error, %d.",sFileNameMz,errno);
            return -1;
        }
    }
#endif
    /* get file record */
    while (1)
    {
        memset(sFileRecord	, 0, sizeof(sFileRecord));
        memset(sDbRecord	, ' ', sizeof(sDbRecord)	);

        if (fgets (sFileRecord, RECORD_LEN_MAX, fp) == NULL)
        {
            nReturnCode = 0;
            break;
        }

		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "sFileRecord[%s]",sFileRecord);
        if (strlen (sFileRecord) == 0)
            break;
#if 0
        if(!memcmp(file_type+1,"ACOM",4)&&!memcmp(sFileRecord+42,SOSA_MZ,6))
        {
            /*÷����ᱣ�Ͽ�*/
            fprintf(fp_mz,"%s",sFileRecord);
            continue;
        }
#endif
     
        /* change file record to db record */
        nReturnCode = IpcDftOpr(pstFile->sCompKey, &nDestMsgLen, sDbRecord,
                                sTxnNum, &nBufChgIndex, &gtIpcDftRule);
        if (nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "IpcDftOpr error, %d.", nReturnCode);
            break;
        }

        nReturnCode = BufChgOpr(nBufChgIndex,
                                sFileRecord,
                                sDbRecord,
                                &gtBufChgRule);
        if(nReturnCode)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "BufChgOpr error, %d.", nReturnCode);
            HtDebugString (gLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, sDbRecord, sizeof (sDbRecord));
            break;
        }

        HtMemcpy (sDbRecord, sDate, DATE_LEN);

        /* �����ݿ��в����¼ʱ���������ϵ���������ֶ� */
        i++;
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "file_type[%s][%s]",file_type,sDbRecord);		
        /*������һ�㱾�������׺�ת������������ˮ����bth_cup_txn_bdt����*/
        nReturnCode = DbsCupTxn (DBS_INSERT_BDT, sDbRecord, file_type, &ipcRuleInf, 0, i, pstFile->sInterInstId, ext_inter_brh_code);
        if (nReturnCode==DBS_KEYDUPLICATE)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsCupTxn DBS_INSERT error, %d.sDbRecord=%s", nReturnCode,sDbRecord);
            continue;
        }
        if (nReturnCode!=0 && nReturnCode!=DBS_KEYDUPLICATE)
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "DbsCupTxn DBS_INSERT error, %d.", nReturnCode);
			HtDebugString (gLogFile, HT_LOG_MODE_DEBUG, __FILE__, __LINE__, sDbRecord, sizeof (sDbRecord));
            break;
        }
        nRecordNum++;
		if(nRecordNum==5000)
		{
			DbsCommit();
		}
    }

#if 0
    /* close file */
    if(!memcmp(file_type+1,"ACOM",4))
    {
    	fclose (fp_mz);
	}
#endif
    fclose (fp);
    return nReturnCode;
}
