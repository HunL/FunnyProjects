/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_0601.pc                                                */
/* DESCRIPTIONS: tdb stlm preprocess                                         */
/*****************************************************************************/
/*                          MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-27  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"


extern    char    gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[INTER_BRH_CODE_LEN + 1];

static bth_cup_txn_def dbbth_cup_txn;
static bth_cup_txn_def dbbth_orig_cup_txn;
static bth_cup_txn_def_ind dbbth_cup_txn_ind;

static bth_dtl_rvsl_tmp_def dbbth_dtl_rvsl_tmp;

static bth_gc_txn_def dbbth_gc_txn;
static bth_gc_txn_def dbbth_orig_gc_txn;
static bth_gc_txn_def_ind dbbth_gc_txn_ind;

static bth_txn_dtl_def dbbth_txn_dtl;

static char today[8+1];
static char sSTLM_OK[1+1];
static char sSTLM_ERROR[1+1];
static char sSTLM_CUP_HAVE[1+1];
static char sSTLM_HOST_HAVE[1+1];
static char sSTLM_CUP_REVSAL[1+1];

static void init_bth_txn_dtl()
{
    memset(dbbth_txn_dtl.manage_inst, 0, sizeof(dbbth_txn_dtl.manage_inst));
    memset(dbbth_txn_dtl.trans_date_time, 0, sizeof(dbbth_txn_dtl.trans_date_time));
    memset(dbbth_txn_dtl.cup_ssn, 0, sizeof(dbbth_txn_dtl.cup_ssn));
    memset(dbbth_txn_dtl.acq_inst_id_code, 0, sizeof(dbbth_txn_dtl.acq_inst_id_code));
    memset(dbbth_txn_dtl.fwd_inst_id_code, 0, sizeof(dbbth_txn_dtl.fwd_inst_id_code));
    memset(dbbth_txn_dtl.term_ssn, 0, sizeof(dbbth_txn_dtl.term_ssn));
    memset(dbbth_txn_dtl.inst_date, 0, sizeof(dbbth_txn_dtl.inst_date));
    memset(dbbth_txn_dtl.inst_time, 0, sizeof(dbbth_txn_dtl.inst_time));
    memset(dbbth_txn_dtl.host_ssn, 0, sizeof(dbbth_txn_dtl.host_ssn));
    memset(dbbth_txn_dtl.host_date, 0, sizeof(dbbth_txn_dtl.host_date));
    memset(dbbth_txn_dtl.date_settlmt, 0, sizeof(dbbth_txn_dtl.date_settlmt));
    memset(dbbth_txn_dtl.gc_txn_num, 0, sizeof(dbbth_txn_dtl.gc_txn_num));
    memset(dbbth_txn_dtl.txn_num, 0, sizeof(dbbth_txn_dtl.txn_num));
    memset(dbbth_txn_dtl.msg_type, 0, sizeof(dbbth_txn_dtl.msg_type));
    memset(dbbth_txn_dtl.processing_code, 0, sizeof(dbbth_txn_dtl.processing_code));
    memset(dbbth_txn_dtl.mchnt_type, 0, sizeof(dbbth_txn_dtl.mchnt_type));
    memset(dbbth_txn_dtl.pos_cond_code, 0, sizeof(dbbth_txn_dtl.pos_cond_code));
    memset(dbbth_txn_dtl.channel_num, 0, sizeof(dbbth_txn_dtl.channel_num));
    memset(dbbth_txn_dtl.orig_cup_ssn, 0, sizeof(dbbth_txn_dtl.orig_cup_ssn));
    memset(dbbth_txn_dtl.orig_date_time, 0, sizeof(dbbth_txn_dtl.orig_date_time));
    memset(dbbth_txn_dtl.orig_date_settlmt, 0, sizeof(dbbth_txn_dtl.orig_date_settlmt));
    memset(dbbth_txn_dtl.orig_term_ssn, 0, sizeof(dbbth_txn_dtl.orig_term_ssn));
    memset(dbbth_txn_dtl.orig_host_date, 0, sizeof(dbbth_txn_dtl.orig_host_date));
    memset(dbbth_txn_dtl.orig_host_ssn, 0, sizeof(dbbth_txn_dtl.orig_host_ssn));
    memset(dbbth_txn_dtl.pan, 0, sizeof(dbbth_txn_dtl.pan));

    dbbth_txn_dtl.amt_trans = 0;
    memset(dbbth_txn_dtl.authr_id_resp, 0, sizeof(dbbth_txn_dtl.authr_id_resp));
    memset(dbbth_txn_dtl.resp_code, 0, sizeof(dbbth_txn_dtl.resp_code));
    memset(dbbth_txn_dtl.host_recode, 0, sizeof(dbbth_txn_dtl.host_recode));
    dbbth_txn_dtl.fee_credit = 0;
    dbbth_txn_dtl.fee_debit = 0;
    dbbth_txn_dtl.fee_cdhr = 0;
    dbbth_txn_dtl.fee_inst = 0;
    dbbth_txn_dtl.fee_logo = 0;
    memset(dbbth_txn_dtl.pos_entry_mode, 0, sizeof(dbbth_txn_dtl.pos_entry_mode));
    memset(dbbth_txn_dtl.card_accp_term_id, 0, sizeof(dbbth_txn_dtl.card_accp_term_id));
    memset(dbbth_txn_dtl.card_accp_id, 0, sizeof(dbbth_txn_dtl.card_accp_id));
    memset(dbbth_txn_dtl.card_accp_addr, 0, sizeof(dbbth_txn_dtl.card_accp_addr));
    memset(dbbth_txn_dtl.retrivl_ref, 0, sizeof(dbbth_txn_dtl.retrivl_ref));
    memset(dbbth_txn_dtl.rcvg_code, 0, sizeof(dbbth_txn_dtl.rcvg_code));
    memset(dbbth_txn_dtl.issuer_code, 0, sizeof(dbbth_txn_dtl.issuer_code));
    memset(dbbth_txn_dtl.deal_flg, 0, sizeof(dbbth_txn_dtl.deal_flg));
    memset(dbbth_txn_dtl.tran_flg, 0, sizeof(dbbth_txn_dtl.tran_flg));
    memset(dbbth_txn_dtl.code_xfer_o, 0, sizeof(dbbth_txn_dtl.code_xfer_o));
    memset(dbbth_txn_dtl.pan_xfer_o, 0, sizeof(dbbth_txn_dtl.pan_xfer_o));
    memset(dbbth_txn_dtl.code_xfer_i, 0, sizeof(dbbth_txn_dtl.code_xfer_i));
    memset(dbbth_txn_dtl.pan_xfer_i, 0, sizeof(dbbth_txn_dtl.pan_xfer_i));
    memset(dbbth_txn_dtl.currcy_code_trans, 0, sizeof(dbbth_txn_dtl.currcy_code_trans));
    memset(dbbth_txn_dtl.currcy_code_stlm, 0, sizeof(dbbth_txn_dtl.currcy_code_stlm));
    dbbth_txn_dtl.amt_settlmt = 0;
    memset(dbbth_txn_dtl.conv_rate_stlm, 0, sizeof(dbbth_txn_dtl.conv_rate_stlm));
    memset(dbbth_txn_dtl.date_conv, 0, sizeof(dbbth_txn_dtl.date_conv));
    memset(dbbth_txn_dtl.flag_domestic, 0, sizeof(dbbth_txn_dtl.flag_domestic));
    memset(dbbth_txn_dtl.flag_city, 0, sizeof(dbbth_txn_dtl.flag_city));
    memset(dbbth_txn_dtl.area_code, 0, sizeof(dbbth_txn_dtl.area_code));
    memset(dbbth_txn_dtl.inst_no, 0, sizeof(dbbth_txn_dtl.inst_no));
    memset(dbbth_txn_dtl.bank_flag, 0, sizeof(dbbth_txn_dtl.bank_flag));
    memset(dbbth_txn_dtl.flag_result, 0, sizeof(dbbth_txn_dtl.flag_result));
}

int tdb_in_dtl_rvsl(int flag_result )
{
    char tmp[14];
    int nReturn;

    init_bth_txn_dtl();

    HtMemcpy(dbbth_txn_dtl.orig_cup_ssn, dbbth_gc_txn.orig_data_elemts+4, 6 );
    HtMemcpy(dbbth_txn_dtl.orig_date_time, dbbth_gc_txn.orig_data_elemts+10, 10 );
    dbbth_txn_dtl.amt_trans = atof(dbbth_cup_txn.amt_trans )/100;
    dbbth_txn_dtl.fee_credit = atof(dbbth_cup_txn.fee_credit )/100;
    dbbth_txn_dtl.fee_debit  = atof(dbbth_cup_txn.fee_debit )/100;

    memset(tmp, 0, sizeof(tmp));
    HtMemcpy(tmp, dbbth_cup_txn.replacement_amts+1, 11 );
    dbbth_txn_dtl.fee_inst = atof(tmp)/100;

    memset(tmp, 0, sizeof(tmp));
    HtMemcpy(tmp, dbbth_cup_txn.amt_trans_fee+1, 11 );
    dbbth_txn_dtl.fee_cdhr = atof(tmp)/100;

    dbbth_txn_dtl.amt_settlmt= atof(dbbth_gc_txn.amt_trans)/100;

    if(flag_result == 3 )
        HtMemcpy(dbbth_gc_txn.flag_domestic, dbbth_cup_txn.flag_domestic, 1 );

    /**ͬ����ر�־**/
    HtMemcpy(dbbth_txn_dtl.flag_city, dbbth_gc_txn.misc_1+4, 1);

    /**������������**/
    HtMemcpy(dbbth_txn_dtl.area_code, dbbth_cup_txn.acq_inst_id_code+4,4 );

    memset(dbbth_txn_dtl.inst_no, ' ', 4 );

    /***ǰ�ý�����***/
    if((memcmp(dbbth_cup_txn.msg_type, "0200", 4) == 0 )&&(memcmp(dbbth_cup_txn.processing_code, "47", 2) == 0 ))
    {
        memset(dbbth_cup_txn.txn_num, 0, sizeof(dbbth_cup_txn.txn_num));
        HtMemcpy(dbbth_cup_txn.txn_num, "1143", 4 );
    }
    if((memcmp(dbbth_cup_txn.msg_type, "0220", 4) == 0 )&&(memcmp(dbbth_cup_txn.processing_code, "47", 2) == 0 ))
    {
        memset(dbbth_cup_txn.txn_num, 0, sizeof(dbbth_cup_txn.txn_num));
        HtMemcpy(dbbth_cup_txn.txn_num, "2143", 4 );
    }

    /**���ʱ�־**/
    HtSprintf(dbbth_txn_dtl.flag_result, "%d", flag_result );

    memset(&dbbth_dtl_rvsl_tmp, 0x00, sizeof(dbbth_dtl_rvsl_tmp));

    HtMemcpy( dbbth_dtl_rvsl_tmp.inter_brh_code                ,          ext_inter_brh_code,                           4       );
    HtMemcpy( dbbth_dtl_rvsl_tmp.manage_inst                ,          "0000",                                       4    );
    HtMemcpy( dbbth_dtl_rvsl_tmp.trans_date_time            ,          dbbth_cup_txn.trans_date_time,               10      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.cup_ssn                    ,          dbbth_cup_txn.cup_ssn,                       6 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.acq_inst_id_code            ,          dbbth_cup_txn.acq_inst_id_code,              11      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.fwd_inst_id_code            ,          dbbth_cup_txn.fwd_inst_id_code,               11     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.term_ssn                    ,          "            ",                     12 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.inst_date                    ,          dbbth_gc_txn.inst_date,                      8     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.inst_time                    ,          dbbth_gc_txn.inst_time,                      6     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.date_settlmt               ,          dbbth_cup_txn.date_settlmt,                   8    );
    HtMemcpy( dbbth_dtl_rvsl_tmp.gc_txn_num                    ,          dbbth_cup_txn.txn_num,                       4     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.msg_type                    ,          dbbth_cup_txn.msg_type,                       4);
    HtMemcpy( dbbth_dtl_rvsl_tmp.processing_code            ,          dbbth_cup_txn.processing_code,               6      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.mchnt_type                    ,          dbbth_cup_txn.mchnt_type,                    4     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.pos_cond_code                ,          dbbth_cup_txn.pos_cond_code,                  2     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.channel_num                ,          dbbth_cup_txn.channel_type,                  2     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.orig_data_ssn                ,          dbbth_txn_dtl.orig_cup_ssn,                  6      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.orig_date_time                ,          dbbth_txn_dtl.orig_date_time,                10      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.orig_host_date                ,          dbbth_txn_dtl.orig_host_date,                 8     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.orig_host_ssn                ,          dbbth_txn_dtl.orig_host_ssn,                  12     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.pan                        ,          dbbth_cup_txn.pan,                            19      );
    dbbth_dtl_rvsl_tmp.amt_trans                 =           dbbth_txn_dtl.amt_trans;
    HtMemcpy( dbbth_dtl_rvsl_tmp.authr_id_resp                ,          dbbth_cup_txn.authr_id_resp,                 6      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.resp_code                  ,          dbbth_cup_txn.resp_code,                     2     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.host_recode                ,          dbbth_txn_dtl.host_recode,                    7    );
    dbbth_dtl_rvsl_tmp.fee_credit           =                 dbbth_txn_dtl.fee_credit;
    dbbth_dtl_rvsl_tmp.fee_debit=          dbbth_txn_dtl.fee_debit;
    dbbth_dtl_rvsl_tmp.fee_cdhr     =          dbbth_txn_dtl.fee_cdhr;
    dbbth_dtl_rvsl_tmp.fee_inst     =          dbbth_txn_dtl.fee_inst;
    dbbth_dtl_rvsl_tmp.fee_logo     =          dbbth_txn_dtl.fee_logo;
    HtMemcpy( dbbth_dtl_rvsl_tmp.pos_entry_mode                ,          dbbth_gc_txn.pos_entry_mode,                  3     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.card_accp_term_id          ,          dbbth_gc_txn.card_accp_term_id,              8      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.card_accp_id                ,          dbbth_gc_txn.card_accp_id,                   15     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.card_accp_addr                ,          dbbth_gc_txn.card_accp_name,                 40      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.retrivl_ref                ,          dbbth_gc_txn.retrivl_ref,                    12     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.rcvg_code                    ,          dbbth_gc_txn.rcvg_code,                      11     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.issuer_code                ,          dbbth_cup_txn.issuer_code,                    11    );
    HtMemcpy( dbbth_dtl_rvsl_tmp.deal_flg                    ,          dbbth_txn_dtl.deal_flg,                      2 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.tran_flg                    ,          dbbth_cup_txn.flag_sd,                       1 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.code_xfer_o                ,          dbbth_cup_txn.code_xfer_o,                   11     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.pan_xfer_o                 ,          dbbth_cup_txn.pan_xfer_o,                    28     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.code_xfer_i                ,          dbbth_cup_txn.code_xfer_i,                   11     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.pan_xfer_i                    ,          dbbth_cup_txn.pan_xfer_i,                     28    );
    HtMemcpy( dbbth_dtl_rvsl_tmp.currcy_code_trans            ,          dbbth_gc_txn.currcy_code_trans,              3      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.currcy_code_stlm            ,          dbbth_gc_txn.currcy_code_stlm,               3      );
    dbbth_dtl_rvsl_tmp.amt_settlmt                =          dbbth_txn_dtl.amt_trans;
    HtMemcpy( dbbth_dtl_rvsl_tmp.conv_rate_stlm                ,          dbbth_gc_txn.conv_rate_stlm,                 8      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.date_conv                    ,          dbbth_gc_txn.date_conv,                      8     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.flag_domestic                ,          dbbth_gc_txn.flag_domestic,                   1     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.flag_city                    ,          dbbth_txn_dtl.flag_city,                     1     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.area_code                    ,          dbbth_txn_dtl.area_code,                     4     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.inst_no                    ,          dbbth_txn_dtl.inst_no,                       11 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.bank_flag                    ,          dbbth_txn_dtl.bank_flag,                     6     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.flag_result                ,          dbbth_txn_dtl.flag_result,                   1     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.fwd_rcv_in                    ,          "3",                                           1   );
    HtMemcpy( dbbth_dtl_rvsl_tmp.cup_ins_id                    ,          dbbth_cup_txn.inter_inst_id ,                 6     );


    nReturn = DbsBTH_DTL_RVSL_TMP_UNI(DBS_INSERT, &dbbth_dtl_rvsl_tmp);
    if ( nReturn )
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "insert into bth_dtl_rvsl error for tdb_in_dtl_err_gc sqlcode=[%d]",nReturn);
        return -1;
    }
    return 0;
}

int tdb_in_orig_dtl_rvsl(int flag_result )
{
    char tmp[14];
    int nReturn;
    init_bth_txn_dtl();

    HtMemcpy(dbbth_txn_dtl.orig_cup_ssn, dbbth_orig_gc_txn.orig_data_elemts+4, 6 );
    HtMemcpy(dbbth_txn_dtl.orig_date_time, dbbth_orig_gc_txn.orig_data_elemts+10, 10 );
    dbbth_txn_dtl.amt_trans = atof(dbbth_orig_cup_txn.amt_trans )/100;
    dbbth_txn_dtl.fee_credit = atof(dbbth_orig_cup_txn.fee_credit )/100;
    dbbth_txn_dtl.fee_debit  = atof(dbbth_orig_cup_txn.fee_debit )/100;

    memset(tmp, 0, sizeof(tmp));
    HtMemcpy(tmp, dbbth_orig_cup_txn.amt_trans_fee+1, 11 );
    dbbth_txn_dtl.fee_cdhr   = atof(tmp )/100;

    memset(tmp, 0, sizeof(tmp));
    HtMemcpy(tmp, dbbth_orig_cup_txn.replacement_amts+1, 11 );
    dbbth_txn_dtl.fee_inst   = atof(tmp)/100;

    dbbth_txn_dtl.amt_settlmt= atof(dbbth_orig_gc_txn.amt_trans)/100;

    if(flag_result == 3 )
        HtMemcpy(dbbth_orig_gc_txn.flag_domestic, dbbth_orig_cup_txn.flag_domestic, 1 );

    /**ͬ����ر�־**/
    HtMemcpy(dbbth_txn_dtl.flag_city, dbbth_orig_gc_txn.misc_1+4, 1);

    /**������������**/
    HtMemcpy(dbbth_txn_dtl.area_code, dbbth_orig_cup_txn.acq_inst_id_code+4,4 );

    memset(dbbth_txn_dtl.inst_no, ' ', 4 );

    /***ǰ�ý�����***/
    if((memcmp(dbbth_orig_cup_txn.msg_type, "0200", 4) == 0 )&&(memcmp(dbbth_orig_cup_txn.processing_code, "47", 2) == 0 ))
    {
        memset(dbbth_orig_cup_txn.txn_num, 0, sizeof(dbbth_orig_cup_txn.txn_num));
        HtMemcpy(dbbth_orig_cup_txn.txn_num, "1143", 4 );
    }
    if((memcmp(dbbth_orig_cup_txn.msg_type, "0220", 4) == 0 )&&(memcmp(dbbth_orig_cup_txn.processing_code, "47", 2) == 0 ))
    {
        memset(dbbth_orig_cup_txn.txn_num, 0, sizeof(dbbth_orig_cup_txn.txn_num));
        HtMemcpy(dbbth_orig_cup_txn.txn_num, "2143", 4 );
    }

    /**���ʱ�־**/
    HtSprintf(dbbth_txn_dtl.flag_result, "%d", flag_result );
    memset(&dbbth_dtl_rvsl_tmp, 0x00, sizeof(dbbth_dtl_rvsl_tmp));
    HtMemcpy(   dbbth_dtl_rvsl_tmp.inter_brh_code                ,        ext_inter_brh_code,                                  4       );
    HtMemcpy( dbbth_dtl_rvsl_tmp.manage_inst                ,        "0000",                                               4    );
    HtMemcpy( dbbth_dtl_rvsl_tmp.trans_date_time            ,        dbbth_orig_cup_txn.trans_date_time,                 10      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.cup_ssn                    ,        dbbth_orig_cup_txn.cup_ssn,                         6 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.acq_inst_id_code            ,        dbbth_orig_cup_txn.acq_inst_id_code,                11      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.fwd_inst_id_code            ,        dbbth_orig_cup_txn.fwd_inst_id_code,                 11     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.term_ssn                    ,        "            ",                            12 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.inst_date                    ,        dbbth_orig_gc_txn.inst_date,                        8     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.inst_time                    ,        dbbth_orig_gc_txn.inst_time,                        6     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.date_settlmt               ,        dbbth_orig_cup_txn.date_settlmt,                     8    );
    HtMemcpy( dbbth_dtl_rvsl_tmp.gc_txn_num                    ,        dbbth_orig_cup_txn.txn_num,                         4     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.msg_type                    ,        dbbth_orig_cup_txn.msg_type,                         4);
    HtMemcpy( dbbth_dtl_rvsl_tmp.processing_code            ,        dbbth_orig_cup_txn.processing_code,                 6      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.mchnt_type                    ,        dbbth_orig_cup_txn.mchnt_type,                      4     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.pos_cond_code                ,        dbbth_orig_cup_txn.pos_cond_code,                    2     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.channel_num                ,        dbbth_orig_cup_txn.channel_type,                    2     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.orig_data_ssn                ,        dbbth_txn_dtl.orig_cup_ssn,                         6      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.orig_date_time                ,        dbbth_txn_dtl.orig_date_time,                       10      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.orig_host_date                ,        dbbth_txn_dtl.orig_host_date,                        8     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.orig_host_ssn                ,        dbbth_txn_dtl.orig_host_ssn,                         12     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.pan                        ,        dbbth_orig_cup_txn.pan,                              19      );
    dbbth_dtl_rvsl_tmp.amt_trans                 =         dbbth_txn_dtl.amt_trans;
    HtMemcpy( dbbth_dtl_rvsl_tmp.authr_id_resp                ,        dbbth_orig_cup_txn.authr_id_resp,                   6      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.resp_code                  ,        dbbth_orig_cup_txn.resp_code,                       2     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.host_recode                ,        dbbth_txn_dtl.host_recode,                           7    );
    dbbth_dtl_rvsl_tmp.fee_credit          =              dbbth_txn_dtl.fee_credit;
    dbbth_dtl_rvsl_tmp.fee_debit=        dbbth_txn_dtl.fee_debit;
    dbbth_dtl_rvsl_tmp.fee_cdhr     =        dbbth_txn_dtl.fee_cdhr;
    dbbth_dtl_rvsl_tmp.fee_inst     =        dbbth_txn_dtl.fee_inst;
    dbbth_dtl_rvsl_tmp.fee_logo     =        dbbth_txn_dtl.fee_logo;
    HtMemcpy( dbbth_dtl_rvsl_tmp.pos_entry_mode                ,        dbbth_orig_gc_txn.pos_entry_mode,                    3     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.card_accp_term_id          ,        dbbth_orig_gc_txn.card_accp_term_id,                8      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.card_accp_id                ,        dbbth_orig_gc_txn.card_accp_id,                     15     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.card_accp_addr                ,        dbbth_orig_gc_txn.card_accp_name,                   40      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.retrivl_ref                ,        dbbth_orig_gc_txn.retrivl_ref,                      12     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.rcvg_code                    ,        dbbth_orig_gc_txn.rcvg_code,                        11     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.issuer_code                ,        dbbth_orig_cup_txn.issuer_code,                      11    );
    HtMemcpy( dbbth_dtl_rvsl_tmp.deal_flg                    ,        dbbth_txn_dtl.deal_flg,                             2 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.tran_flg                    ,        dbbth_orig_cup_txn.flag_sd,                         1 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.code_xfer_o                ,        dbbth_orig_cup_txn.code_xfer_o,                     11     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.pan_xfer_o                 ,        dbbth_orig_cup_txn.pan_xfer_o,                      28     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.code_xfer_i                ,        dbbth_orig_cup_txn.code_xfer_i,                     11     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.pan_xfer_i                    ,        dbbth_orig_cup_txn.pan_xfer_i,                       28    );
    HtMemcpy( dbbth_dtl_rvsl_tmp.currcy_code_trans            ,        dbbth_orig_gc_txn.currcy_code_trans,                3      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.currcy_code_stlm            ,        dbbth_orig_gc_txn.currcy_code_stlm,                 3      );
    dbbth_dtl_rvsl_tmp.amt_settlmt                =        dbbth_txn_dtl.amt_trans;
    HtMemcpy( dbbth_dtl_rvsl_tmp.conv_rate_stlm                ,        dbbth_orig_gc_txn.conv_rate_stlm,                   8      );
    HtMemcpy( dbbth_dtl_rvsl_tmp.date_conv                    ,        dbbth_orig_gc_txn.date_conv,                        8     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.flag_domestic                ,        dbbth_orig_gc_txn.flag_domestic,                     1     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.flag_city                    ,        dbbth_txn_dtl.flag_city,                            1     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.area_code                    ,        dbbth_txn_dtl.area_code,                            4     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.inst_no                    ,        dbbth_txn_dtl.inst_no,                              11 );
    HtMemcpy( dbbth_dtl_rvsl_tmp.bank_flag                    ,        dbbth_txn_dtl.bank_flag,                            6     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.flag_result                ,        dbbth_txn_dtl.flag_result,                          1     );
    HtMemcpy( dbbth_dtl_rvsl_tmp.fwd_rcv_in                    ,        "3",                                                   1   );
    HtMemcpy( dbbth_dtl_rvsl_tmp.cup_ins_id                    ,        dbbth_orig_cup_txn.inter_inst_id   ,                  6     );

    nReturn = DbsBTH_DTL_RVSL_TMP_UNI(DBS_INSERT, &dbbth_dtl_rvsl_tmp);
    if ( nReturn )
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "insert into bth_dtl_rvsl error for tdb_in_dtl_err_gc sqlcode=[%d]",nReturn);
        return -1;
    }
    return 0;
}

int Total_0601()
{
    int nTotalNum=0 ;
	int nReturnCode;
	nReturnCode=DbsBthcuptxnTdb(DBS_SELECT,&dbbth_cup_txn,&nTotalNum,0);
    if(nReturnCode && nReturnCode != DBS_FETCHNULL)
    {
        HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"select from bth_cup_txn_bdt error, sqlcode=[%d].", nReturnCode);
        return -1 ;
    }
    HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"nTotalNum =[%d].",nTotalNum);
    return nTotalNum;
}

int Task_0601( int nBeginOffset, int nEndOffset)
{
    int        nReturnCode;
    char    iFlag;

    memset( &dbbth_cup_txn, 0, sizeof( dbbth_cup_txn));
    memset( &dbbth_orig_cup_txn, 0, sizeof( dbbth_orig_cup_txn));
    memset( &dbbth_gc_txn, 0, sizeof( dbbth_gc_txn));
    memset( &dbbth_orig_gc_txn, 0, sizeof( dbbth_orig_gc_txn));
    memset( &dbbth_txn_dtl, 0, sizeof( dbbth_txn_dtl));

    memset(sSTLM_OK,0,sizeof(sSTLM_OK));
    memset(sSTLM_ERROR,0,sizeof(sSTLM_ERROR));
    memset(sSTLM_CUP_HAVE,0,sizeof(sSTLM_CUP_HAVE));
    memset(sSTLM_HOST_HAVE,0,sizeof(sSTLM_HOST_HAVE));
    memset(sSTLM_CUP_REVSAL,0,sizeof(sSTLM_CUP_REVSAL));

    HtSprintf(sSTLM_OK,"%d",STLM_OK);
    HtSprintf(sSTLM_ERROR,"%d",STLM_ERROR);
    HtSprintf(sSTLM_CUP_HAVE,"%d",STLM_CUP_HAVE);
    HtSprintf(sSTLM_HOST_HAVE,"%d",STLM_HOST_HAVE);
    HtSprintf(sSTLM_CUP_REVSAL,"%d",STLM_CUP_REVSAL);

    iFlag = 0;

    memset( today, 0, 9);
    HtMemcpy( today, dbtbl_date_inf.stoday, 8);
	memset(&dbbth_cup_txn, 0, sizeof(dbbth_cup_txn));
	HtMemcpy( dbbth_cup_txn.inter_brh_code, ext_inter_brh_code,6);
	HtMemcpy( dbbth_cup_txn.date_settlmt, today, 8);
	DbsBthcuptxnTdb(DBS_CURSOR,&dbbth_cup_txn,&nBeginOffset,nEndOffset);
	DbsBthcuptxnTdb(DBS_OPEN,&dbbth_cup_txn,&nBeginOffset,nEndOffset);
	/*
    EXEC SQL DECLARE rev_cur CURSOR
        FOR
        SELECT * FROM bth_cup_txn_tdb
        WHERE inter_brh_code = :ext_inter_brh_code
        and msg_type = '0420'
        and date_settlmt= :today
        and seq_num between :nBeginOffset and  :nEndOffset
        FOR UPDATE;

    EXEC SQL OPEN rev_cur;
*/
    while(1)
    {
        memset(&dbbth_cup_txn, 0, sizeof(dbbth_cup_txn));
        memset(&dbbth_gc_txn, 0, sizeof(dbbth_gc_txn));

        memset(&dbbth_orig_cup_txn, 0, sizeof(dbbth_orig_cup_txn));
        memset(&dbbth_orig_gc_txn, 0, sizeof(dbbth_orig_gc_txn));
		
		nReturnCode=DbsBthcuptxnTdb(DBS_FETCH,&dbbth_cup_txn,&nBeginOffset,nEndOffset);
		/*
		EXEC SQL FETCH bdt_rev_cur into :dbbth_cup_txn :dbbth_cup_txn_ind;
		*/
		if( nReturnCode)
		{
			HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fetch bth_cup_txn_bdt sqlcode[%d]", nReturnCode );
			break;
		}

        /***�Ǽǳ�����ˮ***/
        nReturnCode = tdb_in_dtl_rvsl(6);
        if( nReturnCode)
        {
            HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__,__LINE__, "tdb_in_dtl_rvsl error");
            return dbbth_cup_txn.seq_num;
        }

        /***ԭ������ˮ
        EXEC SQL SELECT * into :dbbth_orig_cup_txn :dbbth_cup_txn_ind
            FROM bth_cup_txn_tdb
        	WHERE inter_brh_code = :ext_inter_brh_code
            and cup_ssn=:dbbth_cup_txn.orig_cup_ssn
            and trans_date_time=:dbbth_cup_txn.orig_date_time
            and acq_inst_id_code=:dbbth_cup_txn.acq_inst_id_code
            and fwd_inst_id_code=:dbbth_cup_txn.fwd_inst_id_code
            and date_settlmt = :dbbth_cup_txn.date_settlmt
			and msg_type != '0420'
            and processing_code=:dbbth_cup_txn.processing_code;
        ***/
		HtMemcpy(dbbth_orig_cup_txn.inter_brh_code,ext_inter_brh_code, 6);
		HtMemcpy(dbbth_orig_cup_txn.cup_ssn,dbbth_cup_txn.orig_cup_ssn,6);
		HtMemcpy(dbbth_orig_cup_txn.trans_date_time,dbbth_cup_txn.orig_date_time,10);
		HtMemcpy(dbbth_orig_cup_txn.acq_inst_id_code,dbbth_cup_txn.acq_inst_id_code,11);
		HtMemcpy(dbbth_orig_cup_txn.fwd_inst_id_code,dbbth_cup_txn.fwd_inst_id_code,11);
		HtMemcpy(dbbth_orig_cup_txn.date_settlmt,dbbth_cup_txn.date_settlmt,8);
		HtMemcpy(dbbth_orig_cup_txn.processing_code,dbbth_cup_txn.processing_code,6);
		nReturnCode=DbsBthcuptxnTdb(DBS_SELECT1,&dbbth_orig_cup_txn,&nBeginOffset,nEndOffset);					
		if(nReturnCode== 0 )
			iFlag = 1;
        /***�Ǽ�ԭ��ˮ***/
        if(iFlag == 1 )
        {
            iFlag = 0;
            nReturnCode = tdb_in_orig_dtl_rvsl(6);
            if( nReturnCode)
            {
                HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__,__LINE__, "tdb_in_orig_dtl_rvsl error");
                return dbbth_cup_txn.seq_num;
            }
            /***����ԭ������ˮ
            EXEC SQL UPDATE bth_cup_txn_tdb
                SET flag_result= :sSTLM_CUP_REVSAL
                WHERE inter_brh_code = :ext_inter_brh_code
                and cup_ssn=:dbbth_orig_cup_txn.cup_ssn
                and trans_date_time=:dbbth_orig_cup_txn.trans_date_time
                and acq_inst_id_code=:dbbth_orig_cup_txn.acq_inst_id_code
                and fwd_inst_id_code=:dbbth_orig_cup_txn.fwd_inst_id_code
                and date_settlmt = :dbbth_orig_cup_txn.date_settlmt
				and msg_type != '0420'
                and processing_code=:dbbth_orig_cup_txn.processing_code;
                ***/
			HtMemcpy(dbbth_orig_cup_txn.flag_result,sSTLM_CUP_REVSAL,1);
			nReturnCode=DbsBthcuptxnTdb(DBS_UPDATE,&dbbth_orig_cup_txn,&nBeginOffset,nEndOffset);	
			if ( nReturnCode == 0  )
			{
				/*
                EXEC SQL UPDATE bth_cup_txn_tdb
                    SET flag_result= :sSTLM_CUP_REVSAL
                    WHERE
                    CURRENT OF rev_cur;
                HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__,__LINE__, "update bth_cup_txn_tdb, sqlcode[%d]", nReturnCode);
				*/

				HtMemcpy(dbbth_cup_txn.flag_result,sSTLM_CUP_REVSAL,1);
				nReturnCode=DbsBthcuptxnTdb(DBS_UPDATE1,&dbbth_cup_txn,&nBeginOffset,nEndOffset);
                if( nReturnCode == 0)
                {
                    continue;
                }
                else
                {
					HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__,__LINE__, "update bth_cup_txn_bdt error[%d]",nReturnCode);
					DbsBthcuptxnTdb(DBS_CLOSE,&dbbth_cup_txn,&nBeginOffset,nEndOffset);
					return dbbth_cup_txn.seq_num;
                }

            }
            if ( nReturnCode == DBS_NOTFOUND )
                continue;
            if ( nReturnCode != 0 )
            {
				HtLog(gLogFile,HT_LOG_MODE_ERROR, __FILE__,__LINE__, "update bth_cup_txn_bdt error[%d]",nReturnCode);
				DbsBthcuptxnTdb(DBS_CLOSE,&dbbth_cup_txn,&nBeginOffset,nEndOffset);
				return nReturnCode;
            }
        }

    }
	DbsBthcuptxnTdb(DBS_CLOSE,&dbbth_cup_txn,&nBeginOffset,nEndOffset);
    return 0;
}
