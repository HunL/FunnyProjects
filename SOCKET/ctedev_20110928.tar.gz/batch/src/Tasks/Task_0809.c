/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_0809.pc                                                */
/* DESCRIPTIONS: bdb_Stlm_Preprocess                                         */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2008-10-27  harrison       initial                                        */
/*****************************************************************************/

#include "batch.h"


/*EXEC SQL INCLUDE sqlca; */

extern    char    gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[INTER_BRH_CODE_LEN + 1];


static bth_dtl_err_gc_tmp_def dbbth_dtl_err_gc_tmp ;
static bth_dtl_bdb_tmp_def dbbth_dtl_bdb_tmp ;


static Tbl_host_txn_Def dbbth_host_txn;
static bth_txn_dtl_def dbbth_txn_dtl;
static	tbl_txn_def dbtbl_txn;




static char today[8+1];
static char area_code[4+1];

static char sSTLM_HOST_HAVE[1+1];



static int in_dtl_err_gc(int flag_result)
{
    int nReturn;

    memset(&dbbth_dtl_err_gc_tmp, 0x00, sizeof(dbbth_dtl_err_gc_tmp));
    HtMemcpy(dbbth_dtl_err_gc_tmp.inter_brh_code,                    ext_inter_brh_code,               10    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.manage_inst,                       "0094",                                    4    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.trans_date_time,                   dbbth_host_txn.trans_date_time,              10   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.cup_ssn,                           dbbth_host_txn.cup_ssn+16,                      6    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.acq_inst_id_code,                  dbbth_host_txn.acq_inst_id_code,             11   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.fwd_inst_id_code,                  dbbth_host_txn.fwd_inst_id_code,             11  );
    HtMemcpy(dbbth_dtl_err_gc_tmp.term_ssn,                          dbtbl_txn.term_ssn,                     12   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.inst_date,                         dbbth_host_txn.date_settlmt,                    8    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.inst_time,                         dbbth_host_txn.trans_date_time+4,                    6    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.host_ssn,                          dbbth_host_txn.cup_ssn,6   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.host_date,                         dbbth_host_txn.date_settlmt,                  8    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.date_settlmt,                      dbtbl_date_inf.stoday,               8    );
    
    HtMemcpy(dbbth_dtl_err_gc_tmp.gc_txn_num,                        dbtbl_txn.txn_num,                      4    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.txn_num,                           dbtbl_txn.txn_num,                    4    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.msg_type,                          dbtbl_txn.msg_type,                     4    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.processing_code,                   dbtbl_txn.processing_code,              6    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.mchnt_type,                        dbtbl_txn.mchnt_type,                   4    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.pos_cond_code,                     dbtbl_txn.pos_cond_code,                2    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.channel_num,                       "03",                  2    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.orig_data_ssn,                     " ",                6    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.orig_data_time,                    " ",              1   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.orig_date_settlmt ,                " ",          1    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.orig_term_ssn  ,                   " ",              1   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.pan,                               dbbth_host_txn.pan,                          19   );
    dbbth_dtl_err_gc_tmp.amt_trans=dbbth_host_txn.amt_trans;
    HtMemcpy(dbbth_dtl_err_gc_tmp.authr_id_resp,                     "  ",                6    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.resp_code,                         "  ",                    2    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.host_recode,                       "00",                                      7    );
    dbbth_dtl_err_gc_tmp.fee_credit=                                 0 ;
    dbbth_dtl_err_gc_tmp.fee_debit=                                  0 ;
    dbbth_dtl_err_gc_tmp.fee_cdhr=                                   0;
    dbbth_dtl_err_gc_tmp.fee_inst=                                   0 ;
    dbbth_dtl_err_gc_tmp.fee_logo=                                   0 ;
    HtMemcpy(dbbth_dtl_err_gc_tmp.pos_entry_mode,                    "   ",               3    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.card_accp_term_id,                 dbbth_host_txn.term_id,            8    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.card_accp_id,                      dbbth_host_txn.mchnt_cd,                 15   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.card_accp_addr,                    " ",               5   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.retrivl_ref,                       " ",                   12   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.rcvg_code,                         " ",                     11   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.pan_xfer_o,                        " ",                     28   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.pan_xfer_i,                        " ",                     28   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.currcy_code_trans,                 " ",            3    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.currcy_code_stlm,                  " ",             3    );
    dbbth_dtl_err_gc_tmp.amt_settlmt=                                dbbth_host_txn.amt_trans;
    HtMemcpy(dbbth_dtl_err_gc_tmp.conv_rate_stlm,                    " ",               8    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.date_conv,                         " ",                    8    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.flag_domestic,                     " ",                1    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.flag_city,                         " ",                   1    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.area_code,                         " ",                   4    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.inst_no,                           " ",                     11   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.bank_flag,                         dbtbl_txn.acq_swresved+30,                   6    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.flag_result,                       "0",                 1    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.fwd_rcv_in,                        "5",                                       1    );
    HtMemcpy(dbbth_dtl_err_gc_tmp.acqu_ins_id_cd,                    " ",              10   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.issuer_ins_id_cd,                  dbbth_host_txn.acct_bno,6   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.issuer_code,                  	 " ",            6   );
    HtMemcpy(dbbth_dtl_err_gc_tmp.cup_ins_id,                        " ",             7   );

    nReturn = DbsBTH_DTL_ERR_GC_TMP_UNI(DBS_INSERT,&dbbth_dtl_err_gc_tmp);
    if (nReturn)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Insert into bth_dtl_err_gc_tmp error [%d].",nReturn);
        return 1;
    }
    return 0;
}
static int in_dtl_bdb(int flag_result)
{
    int nReturn;
    HtMemcpy(dbbth_txn_dtl.orig_cup_ssn, dbbth_host_txn.cup_ssn,6);
    HtMemcpy(dbbth_txn_dtl.orig_date_time, dbbth_host_txn.trans_date_time,10);

    /**ͬ����ر�־**/
    HtMemcpy(dbbth_txn_dtl.flag_city, "0", 1);

    /**������������**/
    HtMemcpy(dbbth_txn_dtl.area_code, dbbth_host_txn.acq_inst_id_code+4,4 );

    HtMemcpy(dbbth_txn_dtl.inst_no, dbbth_host_txn.acq_inst_id_code+4,4 );
    HtSprintf(dbbth_txn_dtl.flag_result, "%d", flag_result );

    /* �����е��ڲ������� */
    memset(area_code, 0x00, sizeof(area_code));
    HtMemcpy(area_code, dbbth_host_txn.acq_inst_id_code+4, 4);
    HtSprintf(dbbth_txn_dtl.issuer_ins_id_cd, "04%s", area_code);

	memset(area_code, 0, 5);
    HtMemcpy(area_code, dbbth_host_txn.acq_inst_id_code + 4, 4);
    memset(&dbbth_dtl_bdb_tmp,0x00,sizeof(dbbth_dtl_bdb_tmp));

	HtMemcpy( dbbth_dtl_bdb_tmp.inter_brh_code  	   ,  ext_inter_brh_code,        10  );
	HtMemcpy( dbbth_dtl_bdb_tmp.manage_inst     	   ,  "0094",                             4  );
	HtMemcpy( dbbth_dtl_bdb_tmp.trans_date_time 	   ,  dbbth_host_txn.trans_date_time,       10 );
	HtMemcpy( dbbth_dtl_bdb_tmp.cup_ssn 			   ,  dbbth_host_txn.cup_ssn+16,               6  );
	HtMemcpy( dbbth_dtl_bdb_tmp.acq_inst_id_code       ,  dbbth_host_txn.acq_inst_id_code,      8 );
	HtMemcpy( dbbth_dtl_bdb_tmp.fwd_inst_id_code       ,  dbbth_host_txn.fwd_inst_id_code,      8 );
	HtMemcpy( dbbth_dtl_bdb_tmp.term_ssn        	   ,  dbtbl_txn.term_ssn,12 );
	HtMemcpy( dbbth_dtl_bdb_tmp.inst_date       	   ,  dbbth_host_txn.date_settlmt,             8  );
	HtMemcpy( dbbth_dtl_bdb_tmp.inst_time       	   ,  dbbth_host_txn.trans_date_time+4,             6  );
	HtMemcpy( dbbth_dtl_bdb_tmp.host_ssn        	   , "  " ,6 );
	HtMemcpy( dbbth_dtl_bdb_tmp.host_date       	   ,  dbbth_host_txn.date_settlmt,           8  );
	HtMemcpy( dbbth_dtl_bdb_tmp.date_settlmt    	   ,  dbtbl_date_inf.stoday,        8  );
	HtMemcpy( dbbth_dtl_bdb_tmp.gc_txn_num      	   ,  dbtbl_txn.txn_num,               4  );
	HtMemcpy( dbbth_dtl_bdb_tmp.txn_num 			   ,  dbtbl_txn.txn_num,             4  );
	HtMemcpy( dbbth_dtl_bdb_tmp.msg_type        	   ,  dbtbl_txn.msg_type,              4  );
	HtMemcpy( dbbth_dtl_bdb_tmp.processing_code 	   ,  dbtbl_txn.processing_code,       6  );
	HtMemcpy( dbbth_dtl_bdb_tmp.mchnt_type      	   ,  dbtbl_txn.mchnt_type,            4  );
	HtMemcpy( dbbth_dtl_bdb_tmp.pos_cond_code   	   ,  " ",         2  );
	HtMemcpy( dbbth_dtl_bdb_tmp.channel_num     	   ,  "03",           2  );
	HtMemcpy( dbbth_dtl_bdb_tmp.orig_data_ssn   	   ,  " ",         6  );
	HtMemcpy( dbbth_dtl_bdb_tmp.orig_data_time  	   ,  " ",       10 );
	HtMemcpy( dbbth_dtl_bdb_tmp.orig_date_settlmt      ,  " ",   8  );
	HtMemcpy( dbbth_dtl_bdb_tmp.orig_term_ssn   	   ,  " ",       12 );
	memset  ( dbbth_dtl_bdb_tmp.orig_host_date  	   ,  ' ',                                8  );
	memset  ( dbbth_dtl_bdb_tmp.orig_host_ssn   	   ,  ' ',                                12 );
	HtMemcpy( dbbth_dtl_bdb_tmp.pan     			   ,  dbbth_host_txn.pan,                   19 );
	dbbth_dtl_bdb_tmp.amt_trans            =  dbbth_host_txn.amt_trans                ; 
	HtMemcpy( dbbth_dtl_bdb_tmp.authr_id_resp   	   ,  " ",         6  );
	HtMemcpy( dbbth_dtl_bdb_tmp.resp_code       	   ,  "00",             2  );
	memset  ( dbbth_dtl_bdb_tmp.host_recode     	   ,  'A',                                7  );
	dbbth_dtl_bdb_tmp.fee_credit           =  0                                      ;
	dbbth_dtl_bdb_tmp.fee_debit            =  0                                      ; 
	dbbth_dtl_bdb_tmp.fee_cdhr             = 0                ; 
	dbbth_dtl_bdb_tmp.fee_inst             =  0                 ; 
	dbbth_dtl_bdb_tmp.fee_logo             =  0                                      ; 
	HtMemcpy( dbbth_dtl_bdb_tmp.pos_entry_mode  	   ,  " ",        3  );
	HtMemcpy( dbbth_dtl_bdb_tmp.card_accp_term_id      ,  dbbth_host_txn.term_id,     8  );
	HtMemcpy( dbbth_dtl_bdb_tmp.card_accp_id    	   ,  dbbth_host_txn.mchnt_cd,          15 );
	HtMemcpy( dbbth_dtl_bdb_tmp.card_accp_addr  	   ,  "  ",        40 );
	HtMemcpy( dbbth_dtl_bdb_tmp.retrivl_ref     	   ,  " ",           12 );
	HtMemcpy( dbbth_dtl_bdb_tmp.rcvg_code       	   ,  " ",             11 );
	memset  ( dbbth_dtl_bdb_tmp.issuer_code     	   ,  ' ',                                11 );
	memset  ( dbbth_dtl_bdb_tmp.deal_flg        	   ,  ' ',                                2  );
	memset  ( dbbth_dtl_bdb_tmp.tran_flg        	   ,  ' ',                                1  );
	memset  ( dbbth_dtl_bdb_tmp.code_xfer_o     	   ,  ' ',                                11 );
	HtMemcpy( dbbth_dtl_bdb_tmp.pan_xfer_o      	   ,  " ",              28 );
	memset  ( dbbth_dtl_bdb_tmp.code_xfer_i     	   ,  ' ',                                11 );
	HtMemcpy( dbbth_dtl_bdb_tmp.pan_xfer_i      	   ,  " ",              28 );
	HtMemcpy( dbbth_dtl_bdb_tmp.currcy_code_trans      ,  "156",     3  );
	HtMemcpy( dbbth_dtl_bdb_tmp.currcy_code_stlm       ,  "156",      3  );
	dbbth_dtl_bdb_tmp.amt_settlmt          =  dbbth_host_txn.amt_trans; 
	HtMemcpy( dbbth_dtl_bdb_tmp.conv_rate_stlm  	   ,  " ",        8  );
	HtMemcpy( dbbth_dtl_bdb_tmp.date_conv       	   ,  " ",             8  );
	HtMemcpy( dbbth_dtl_bdb_tmp.flag_domestic   	   ,  " ",         1  );
	HtMemcpy( dbbth_dtl_bdb_tmp.flag_city       	   ,  " ",            1  );
	HtMemcpy( dbbth_dtl_bdb_tmp.area_code       	   ,  " ",            4  );
	HtMemcpy( dbbth_dtl_bdb_tmp.inst_no 			   ,  " ",              11 );
	HtMemcpy( dbbth_dtl_bdb_tmp.bank_flag       	   ,  dbtbl_txn.acq_swresved+30,            6  );
	HtMemcpy( dbbth_dtl_bdb_tmp.flag_result     	   ,  dbbth_txn_dtl.flag_result,          1  );
	HtMemcpy( dbbth_dtl_bdb_tmp.issuer_ins_id_cd       ,  dbbth_host_txn.acct_bno,6 );
	HtMemcpy( dbbth_dtl_bdb_tmp.cup_ins_id      	   ,  " ",      6  );
	dbbth_dtl_bdb_tmp.seq_num              =  0                                       ;

    nReturn=DbsBTH_DTL_BDB_TMP_UNI(DBS_INSERT,&dbbth_dtl_bdb_tmp);

    if ( nReturn)
    {
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Insert into bth_dtl_bdb_tmp error [%d].",nReturn);
        HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, 
            "Insert into bth_dtl_bdb_tmp error inter_brh_code = [%s].", dbbth_dtl_bdb_tmp.inter_brh_code);
        return 1;
    }
    return 0;
}

int Total_0809()
{
	return 1;
}

int Task_0809( int nBeginOffset, int nEndOffset)
{
    int nReturn;


    memset(sSTLM_HOST_HAVE,0,sizeof(sSTLM_HOST_HAVE));
    HtSprintf(sSTLM_HOST_HAVE,"%d",STLM_BDB_HOST_HAVE);
    
	memset(&dbbth_host_txn,0x00,sizeof(dbbth_host_txn));
	HtMemcpy(dbbth_host_txn.flag_result,sSTLM_HOST_HAVE,1);
    DbsHostTxn(DBS_CURSOR,&dbbth_host_txn,0,ext_inter_brh_code);
    nReturn=DbsHostTxn(DBS_OPEN,&dbbth_host_txn,0,ext_inter_brh_code); 
    if ( nReturn)
    {
        HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"open host_txn_cursor error[%d]!",nReturn);
        return -1;
    }

    while(1)
    {
        memset(&dbbth_host_txn, 0x00, sizeof(dbbth_host_txn));
        memset(&dbtbl_txn, 0x00, sizeof(dbtbl_txn));

		nReturn=DbsHostTxn(DBS_FETCH,&dbbth_host_txn,0,ext_inter_brh_code);
		if(nReturn )
        {
            HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "fetch host_txn_cursor error[%d]",nReturn);
            break;
        }
		HtMemcpy(dbtbl_txn.sys_seq_num,dbbth_host_txn.cup_ssn+16,6);
		HtMemcpy(dbtbl_txn.trans_date_time,dbbth_host_txn.trans_date_time,10);
		HtMemcpy(dbtbl_txn.acq_inst_id_code,dbbth_host_txn.acq_inst_id_code+3,8);
		HtMemcpy(dbtbl_txn.date_settlmt,dbtbl_date_inf.stoday+4,4);
		nReturn=DbsTblTxn(DBS_SELECT,&dbtbl_txn);
		if(nReturn)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "select tbl_txn error[%d]",nReturn);
			return -1;
		}

		nReturn = in_dtl_err_gc(0 );            
        if(nReturn )
        {
        	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "in_dtl_err_gc_4 [%d]", nReturn);
            return -1;
        }
        nReturn = in_dtl_bdb(0 );
        if(nReturn )
        {
        	HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "in_dtl_bdb_4 [%d]", nReturn);
            return -1;
        }
    }
	DbsHostTxn(DBS_CLOSE,&dbbth_host_txn,0,ext_inter_brh_code);
    return 0;
}
