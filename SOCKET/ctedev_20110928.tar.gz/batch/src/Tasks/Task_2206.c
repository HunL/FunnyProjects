/*****************************************************************************/
/*                NCUP -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Task_2206.pc                                                */
/* DESCRIPTIONS: Confirm bth_dtl_err_gc									 */
/*****************************************************************************/
/*                        MODIFICATION LOG                                   */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2011-05-05  sunyd          initial                                        */
/*****************************************************************************/

#include "batch.h"
#include "DbsTbl.h"

char	gLogFile[LOG_NAME_LEN_MAX];
extern  tbl_date_inf_def dbtbl_date_inf;
extern  char    ext_inter_brh_code[INTER_BRH_CODE_LEN + 1];
bth_dtl_err_gc_tmp_def dbbth_dtl_err_gc_tmp;
int Total_2206()
{
    int nTotalNum=0 ;
    int nReturnCode=0;
	memset(&dbbth_dtl_err_gc_tmp,0x00,sizeof(dbbth_dtl_err_gc_tmp));
	HtMemcpy(dbbth_dtl_err_gc_tmp.inter_brh_code,ext_inter_brh_code,10);
	nReturnCode=DbsBTH_DTL_ERR_GC_TMP_UNI(DBS_SELECT1,&dbbth_dtl_err_gc_tmp);
	nTotalNum=dbbth_dtl_err_gc_tmp.seq_num;
    if(nReturnCode && nReturnCode != DBS_FETCHNULL)
    {
        HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"select from bth_cup_txn_bdt error, sqlcode=[%d].", nReturnCode);
        return-1 ;
    }
    HtLog(gLogFile,HT_LOG_MODE_ERROR,__FILE__,__LINE__,"nTotalNum =[%d].",nTotalNum);
    return nTotalNum;
}

int Task_2206 ( int nBeginOffset, int nEndOffset )
{

    int 	nReturnCode = 0; 
	char    sqlstr[1024];
	memset(sqlstr,0x00,sizeof(sqlstr));
	HtSprintf(sqlstr,"SELECT * FROM bth_dtl_err_gc_tmp where inter_brh_code ='%s' and seq_num <= %d and seq_num >=%d order by seq_num",ext_inter_brh_code,nEndOffset,nBeginOffset);
	nReturnCode=OpenCursorBTH_DTL_ERR_GC_TMP(sqlstr);
	if(nReturnCode)
	{
		HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "OPEN CURSOR bth_dtl_err_gc error sqlcode=[%d].\n", nReturnCode);
		return nBeginOffset;
	}
	while(1)
	{
		memset(&dbbth_dtl_err_gc_tmp,0x00,sizeof(dbbth_dtl_err_gc_tmp));
		nReturnCode=FetchCursorBTH_DTL_ERR_GC_TMP(&dbbth_dtl_err_gc_tmp);
		if(nReturnCode && nReturnCode != DBS_FETCHNULL)
		{
			if(nReturnCode == DBS_NOTFOUND)
			{
				break;
			}
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "FETCH CURSOR bth_dtl_err_gc error sqlcode=[%d].\n", nReturnCode);
			CloseCursorBTH_DTL_ERR_GC_TMP();
			return dbbth_dtl_err_gc_tmp.seq_num;
		}

		if(!memcmp(dbbth_dtl_err_gc_tmp.flag_domestic,"0",1)&&(!memcmp(dbbth_dtl_err_gc_tmp.gc_txn_num,"1201",4)||!memcmp(dbbth_dtl_err_gc_tmp.gc_txn_num,"1023",4)||!memcmp(dbbth_dtl_err_gc_tmp.gc_txn_num,"1253",4)||!memcmp(dbbth_dtl_err_gc_tmp.gc_txn_num,"1163",4)))
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "�ñʽ���Ϊ���ڲ�ѯ���ڲ�������Ϊ[%4.4s].\n", dbbth_dtl_err_gc_tmp.gc_txn_num);
			continue;
		}

		nReturnCode = DbsBTH_DTL_ERR_GC_UNI(DBS_INSERT, &dbbth_dtl_err_gc_tmp);
		if (nReturnCode)
		{
			HtLog (gLogFile, HT_LOG_MODE_ERROR, __FILE__,__LINE__, "Insert into bth_dtl_err_gc error sqlcode=[%d].\n", nReturnCode);
			CloseCursorBTH_DTL_ERR_GC_TMP();
			return dbbth_dtl_err_gc_tmp.seq_num;
		}
		DbsCommit ();
	}
	CloseCursorBTH_DTL_ERR_GC_TMP();
	return 0;
}
