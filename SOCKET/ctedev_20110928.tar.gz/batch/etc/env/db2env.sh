# set environment variables
# database
# for db2

#==========================#
# Set DB2 Environment      #
#==========================#
#DBNAME=gcfront;export DBNAME
DBNAME=posstd;export DBNAME
DBUSER=gbatch;export DBUSER
DBPWD=gbatch;export DBPWD
export DBLINK="$DBNAME user $DBUSER using $DBPWD"

DB2_HOME=/opt/IBM/db2/V9.7
export DB2_HOME
DB2PATH=/opt/IBM/db2/V9.7
export DB2PATH
DB2INSTPATH=/home/db2inst1
export DB2INSTPATH
DB2INSTANCE=db2inst1
export DB2INSTANCE

DB2DBDFT=posstd
export DB2DBDFT
SQLCMD=db2
export SQLCMD

#source ${DB2INSTPATH}/sqllib
. ${DB2INSTPATH}/sqllib/db2profile

# path
PATH=$PATH:$DB2INSTPATH/sqllib/bin
export PATH
